# Create localeCountryLanguage table
#  This is just a join and copy of three other tables country,locale,language
#  We do this for performance reasons only when staging the userAccount table
#
#  Revision History
#  2014-02-20

drop table if exists ref_localeCountryLanguage;
create table if not exists ref_localeCountryLanguage as
select rl.*
	  ,rc.*
      ,rlg.*
from ref_locale rl
left outer join ref_country rc
   on substr(rl.localeCode,4) = rc.countryCode
left outer join ref_language rlg
   on substr(rl.localeCode,1,2) = rlg.languageCode;

alter table ref_localeCountryLanguage add primary key (localeCode);
create index idx_refLocaleCountryLanguage_countryCode on ref_localeCountryLanguage (countryCode);
create index idx_refLocaleCountryLanguage_currencyCode on ref_localeCountryLanguage (currencyCode);
create index idx_refLocaleCountryLanguage_languageCode on ref_localeCountryLanguage (languageCode);



