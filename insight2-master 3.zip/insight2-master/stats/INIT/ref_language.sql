

/******************  language lookup data ******************/
# WARNING:  MUST REBUILD table ref_localCountryLanguage after rebuilding this table;
# Revision History
#
# 2014-03-05: BMW: Create new table which is a composite of ref_country, ref_locale, ref_language.accessible

DROP TABLE IF EXISTS rpt_main_02.ref_language;
CREATE TABLE IF NOT EXISTS rpt_main_02.ref_language(languageCode NVARCHAR(2), languageName NVARCHAR(100), PRIMARY KEY(languageCode)) ENGINE = MYISAM;

INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("en","English");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("sq","Albanian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ar","Arabic");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("be","Belarusian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("bg","Bulgarian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ca","Catalan");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("zh","Chinese");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("hr","Croatian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("cs","Czech");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("da","Danish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("nl","Dutch");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("es","Spanish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("et","Estonian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("fi","Finnish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("fr","French");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("de","German");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("el","Greek");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("iw","Hebrew");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("hi","Hindi");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("hu","Hungarian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("is","Icelandic");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("in","Indonesian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ga","Irish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("it","Italian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ja","Japanese");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ko","Korean");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("lv","Latvian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("lt","Lithuanian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("mk","Macedonian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ms","Malay");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("mt","Maltese");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("no","Norwegian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("pl","Polish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("pt","Portuguese");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ro","Romanian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("ru","Russian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("sr","Serbian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("sk","Slovak");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("sl","Slovenian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("sv","Swedish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("th","Thai");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("tr","Turkish");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("uk","Ukrainian");
INSERT rpt_main_02.ref_language (languageCode, languageName) VALUES ("vi","Vietnamese");

select 'WARNING:  MUST REBUILD table ref_localCountryLanguage after rebuilding this table' from dual;
