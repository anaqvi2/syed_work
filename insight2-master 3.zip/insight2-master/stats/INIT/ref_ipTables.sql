

DROP TABLE IF EXISTS rpt_main_02.ref_ipNumber;
CREATE TABLE IF NOT EXISTS rpt_main_02.ref_ipNumber(ipNumber INT, locId INT, PRIMARY KEY(ipNumber)) ENGINE = MYISAM;



DROP TABLE IF EXISTS ref_ipLocation;
CREATE TABLE `ref_ipLocation` (
  `locId` INT(11) NOT NULL,
  `country` VARCHAR(2) DEFAULT NULL,
  `region` VARCHAR(50) DEFAULT NULL,
  `city` VARCHAR(50) DEFAULT NULL,
  `postalCode` VARCHAR(20) DEFAULT NULL,
  `latitude` DECIMAL(14,8) DEFAULT NULL,
  `longitude` DECIMAL(14,8) DEFAULT NULL,
  `metroCode` VARCHAR(8) DEFAULT NULL,
  `areaCode` VARCHAR(8) DEFAULT NULL,
  PRIMARY KEY (`locId`)
) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE 'c:/Location.csv' 
  INTO TABLE ref_ipLocation FIELDS TERMINATED BY ','
  ENCLOSED BY '"'
  IGNORE 2 LINES;
  

  
DROP TABLE IF EXISTS ref_ipAddressInfo;
  CREATE TABLE ref_ipAddressInfo (
  ipAddress VARCHAR(20) NOT NULL,
  countryName VARCHAR(100) DEFAULT NULL,
  regionName VARCHAR(80) DEFAULT NULL,
  city VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (ipAddress)
) DEFAULT CHARSET=utf8;

  
  
