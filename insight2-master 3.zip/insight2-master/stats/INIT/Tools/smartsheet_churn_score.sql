DROP FUNCTION  SMARTSHEET_CHURN_SCORE;

DELIMITER $$
CREATE FUNCTION `SMARTSHEET_CHURN_SCORE`(paymentTerm varchar(50), product varchar(50), weekNum INT, teamSize INT, FACTOR1 INT, FACTOR2 INT, FACTOR3 INT ) RETURNS int(11)
BEGIN

DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE P DECIMAL(20,10);

DECLARE X1 INT;
DECLARE X2 INT;
DECLARE X3 INT;


DECLARE willChurn INT;

DECLARE pT varchar(50);
DECLARE prod varchar(50);
DECLARE wN INT;
DECLARE tS INT;
DECLARE wC INT;

SET pT = paymentTerm, prod = product, wN=weekNum, ts=teamSize;


-- Basic Monthly at Week 5
IF pT = 'Monthly' AND prod = 'Basic' AND wN = 5
THEN
SET betaZero = 1.5276, beta1 = -0.42473, beta2 = -0.95765, beta3 = -0.13272, X1 = FACTOR1, X2=FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;



-- Monthly Team > 10 Users at Week 4
ELSEIF
pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS > 10
THEN
SET X1 = FACTOR1;
SET P = CASE WHEN X1 = 0 THEN .70 ELSE 0 END;
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;

-- Annual Team > 10 Users at Week 8 
ELSEIF
pT = 'Annual' AND prod = 'Team' AND wN = 8 AND tS > 10
THEN
SET X1 = FACTOR1;
SET P = CASE WHEN X1 = 0 THEN .70 ELSE 0 END;
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;




-- Monthly Team 3 to 5 Users at Week 1
ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 1 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 2.529, beta1 = -1.969, beta2 = -1.773, beta3 = -0.882, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;

-- Monthly Team 3 to 5 Users at Week 4
ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 3.056, beta1 = -1.67, beta2 = -2.242, beta3 = -1.008, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;

-- Monthly Team 3 to 5 Users at Week 20
ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 20 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 3.1146, beta1 = -2.7529, beta2 = -1.5029, beta3 = -0.0507, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;




-- Monthly Team 6 to 10 Users at Week 4
ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS BETWEEN 6 AND 10
THEN 
SET betaZero = 2.8936, beta1 = -0.00239, beta2 = -1.7831, beta3 = -1.7043, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;

-- Monthly Team 6 to 10 Users at Week 20
ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 20 AND tS BETWEEN 6 AND 10
THEN 
SET betaZero = 4.7011, beta1 = -3.4382, beta2 = -0.00083, beta3= -2.1459, X1 = FACTOR1, X2 = FACTOR2,
P=EXP(betaZero+(beta1*X1)+(beta2*X2))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;


ELSE
SET betaZero = 0, beta1 = 0, beta2 = 0, beta3 = 0, X1 = 0, X2 = 0, X3 = 0, P = 0, wC = 0;
END IF;

SET willChurn = wC;

#RETURN P;
RETURN willChurn;


END$$
DELIMITER ;
