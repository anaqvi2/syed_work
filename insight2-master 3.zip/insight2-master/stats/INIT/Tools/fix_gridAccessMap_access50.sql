# grid access map fix
# Data in rpt_main_02.gridAccessMap does not match ss_core_02
##########################################
# Execute this in production.

-- Mark records as deleted that were removed in source table
-- We want to retain history on these
update rpt_main_02.gridAccessMap
SET rpt_main_02.gridAccessMap.deleteStatus = 0
where deleteStatus = 1;

UPDATE rpt_main_02.gridAccessMap
LEFT JOIN ss_core_02.gridAccessMap 
    ON rpt_main_02.gridAccessMap.gridID=ss_core_02.gridAccessMap.gridID
	AND rpt_main_02.gridAccessMap.userID=ss_core_02.gridAccessMap.userID
SET rpt_main_02.gridAccessMap.deleteStatus = 1
WHERE ss_core_02.gridAccessMap.gridID IS NULL;

##########################################
# we expect that there is only one userId where access=50
# That is, there can only be one owner per grid
select gridId, count(*)
from rpt_main_02.gridAccessMap
where access = 50
and deletestatus = 0
group by gridID
having count(*) > 1
order by gridId desc;

select gridId, count(*)
from ss_core_02.gridAccessMap
where access = 50
group by gridID
having count(*) > 1;

select 'rpt_main_02' as db, a.*
from rpt_main_02.gridAccessMap a
where access = 50
and gridId in (8029166,
1009109,
1013510,
1021828,
1021834,
1021836,
1021838,
1021839
)
union
select 'ss_core_02' as db, a.*, null as deletestatus
from ss_core_02.gridAccessMap a
where access = 50
and gridId in (8029166,
1009109,
1013510,
1021828,
1021834,
1021836,
1021838,
1021839
)
order by db, gridId;


select 'rpt_main_02' as db, a.*
from rpt_main_02.gridAccessMap a
where access = 50
and gridId in 
(8387606,
8387603,
387602,
8387601,
8387600,
8387599,
8387597)
union
select 'ss_core_02' as db, a.*, null as deletestatus
from ss_core_02.gridAccessMap a
where access = 50
and gridId in 
(8387606,
8387603,
387602,
8387601,
8387600,
8387599,
8387597);

select 'rpt_main_02' as db, a.*
from rpt_main_02.gridAccessMap a
#where access = 50
where gridId in (8029166)
union
select 'ss_core_02' as db, a.*, null as deletestatus
from ss_core_02.gridAccessMap a
#where access = 50
where gridId in (8029166
)
order by db, gridId;

##########################################


drop table tmpMain;
create temporary table tmpMain as 
select y.*
from rpt_main_02.gridAccessMap y
inner join
(select gridId, userId
from  rpt_main_02.gridAccessMap
where gridId between (select max(gridId) -20000 from rpt_main_02.gridAccessMap) and (select max(gridId) -10000 from rpt_main_02.gridAccessMap)
) x
on y.gridId = x.gridId
and y.userId = x.userId;

drop table tmpCore;
create temporary table tmpCore as 
select y.*
from ss_core_02.gridAccessMap y
inner join tmpMain x
on y.gridId = x.gridId
and y.userId = x.userId;


########################  testing on made up data   #########################
#  This clause should prvent all updates to rpt_main_02.gridAccessMap.deleteStatus
#  ss_core_02.gridAccessMap.modifyDateTime <= CONCAT(CURRENT_DATE(), ' 00:15:00')


drop table tmpGAMcore;
create temporary table tmpGAMcore as
select *
from ss_core_02.gridAccessMap
where gridId > (select max(gridID)-100 from ss_core_02.gridAccessMap);

drop table tmpGAMmain;
create temporary table tmpGAMmain as
select a.*, 0 as ds 
from tmpGAMcore a;


select * from tmpGAMcore;
select * from tmpGAMmain;

delete from tmpGAMcore where userId = 1049979;

select *
 from tmpGAMmain
LEFT JOIN tmpGAMcore 
   ON tmpGAMmain.gridID=tmpGAMcore.gridID
  AND tmpGAMmain.userID=tmpGAMcore.userID
WHERE tmpGAMcore.gridID IS NULL
 AND tmpGAMcore.modifyDateTime <= CONCAT(CURRENT_DATE(), '19:15:00');

select CONCAT(CURRENT_DATE(), ' 19:15:00'), CURRENT_DATE()
from dual
where null<= CONCAT(CURRENT_DATE(), '19:15:00') ;


drop table tmpGAMmainDeletes;
create temporary table tmpGAMmainDeletes as
select *
from rpt_main_02.gridAccessMap
where gridId > (select max(gridID)-4000000 from rpt_main_02.gridAccessMap)
and deleteStatus = 1
limit 100;

select * 
from tmpGAMmainDeletes;

select deleteStatus, count(*), max(modifyDateTime)
from rpt_main_02.gridAccessMap
where gridId > (select max(gridID)-4000000 from rpt_main_02.gridAccessMap)
group by deleteStatus;



select 'rpt_main_02' as db, a.*
from rpt_main_02.gridAccessMap a
#where access = 50
where gridId in (4409294)
union
select 'ss_core_02' as db, a.*, null as deletestatus
from ss_core_02.gridAccessMap a
#where access = 50
where gridId in (4409294)
order by db, insertDateTime;

drop table tmpDSDiffs;
create temporary table tmpDSDiffs as 
select y.*,x.*
from rpt_main_02.gridAccessMap y
inner join
(
select a.gridId gid, a.userid uid, access ac, insertDateTime idt, insertbyuserid ibu, modifydatetime mdt, modifybyuserid mbu, sessionlogid sess, datatimestamp dts, 0 as ds
from  ss_core_02.gridAccessMap a
#where gridId between (select max(gridId) -2000000 from rpt_main_02.gridAccessMap) and (select max(gridId) from rpt_main_02.gridAccessMap)
) x
on y.gridId = x.gid
and y.userId = x.uid
#where y.gridId between (select max(gridId) -2000000 from rpt_main_02.gridAccessMap) and (select max(gridId) from rpt_main_02.gridAccessMap)
where y.deleteStatus != x.ds;

select *
from tmpDSDiffs;



	