# These test cases are used while developing new etl processes in schema 'test'.
# As our dev process includes pushing copies of data from rpt_main_02 to 'test'
# we always run test cases(generally table diffs) against rpt_main_02.accessible
# Once code is released to production we use test cases between ss_core/log and 
# rpt_main_02. See file etl_prodTestCases.sql
use test;


#######################################################################
# User Account

set @idTestRange = 100000;
set @rptMainMaxUserId = (select max(userID) from rpt_main_02.userAccount);
set @ssCoreMaxUserId = (select max(userID) from ss_core_02.userAccount);
set @testMaxUserId = (select max(userID) from test.userAccount);
set @rptMainMaxModifyDate = (select modifyDateTime from rpt_main_02.userAccount where userId = @rptMainMaxUserId);
set @ssCoreMaxModifyDate = (select modifyDateTime from ss_core_02.userAccount where userId = @ssCoreMaxUserId);
set @testMaxModifyDate = (select modifyDateTime from test.userAccount where userId = @testMaxUserId);

#print variables
select @rptMainMaxUserId- @idTestRange, @idTestRange, @rptMainMaxUserId ,@ssCoreMaxUserId , @testMaxUserId, @rptMainMaxModifyDate,@ssCoreMaxModifyDate,@testMaxModifyDate from dual;

# Check to see if updates/inserts copied over correctly.
# Table checksums should be identical
# Execute within seconds after 'call etl_userAccount() executes.
#  ie; minimize the chance that replication updates the table ss_core_02.userAccount before the test.
drop table if exists tmp5;

create temporary table tmp5 as 
select * from ss_core_02.userAccount 
where userId between  @ssCoreMaxUserId - @idTestRange and @ssCoreMaxUserId - 10;

drop table if exists tmp6;
create temporary table tmp6 as 
select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,    
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from test.userAccount 
where userId between  @ssCoreMaxUserId - @idTestRange and @ssCoreMaxUserId - 10;

CHECKSUM TABLE tmp5;
CHECKSUM TABLE tmp6;
###################

# Check to see if updates/inserts copied over correctly.
# Counts and max ids should be identical.
select 'ss_core_02 count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from ss_core_02.userAccount ua1
where ua1.userID >= @ssCoreMaxUserId-@idTestRange 
union
select 'test count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from test.userAccount ua2
where ua2.userID >= @ssCoreMaxUserId-@idTestRange  
union
select 'union count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from
(select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from ss_core_02.userAccount
where userID >=  (@ssCoreMaxUserId-@idTestRange)
union
select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from test.userAccount
where userID >=  (@ssCoreMaxUserId-@idTestRange)
) x;

# check to see if our additional 4 columns were added correctly.
# rowcounts should be non-zero and identical.
select 'rpt_main count', count(*) rowCount
from rpt_main_02.userAccount
where userID >= @rptMainMaxUserId- @idTestRange
    and userID not in (select userId from test.userAccount where modifyDateTime > @rptMainMaxModifyDate)
union
select 'test count', count(*) rowCount
from test.userAccount 
where userID  between  @rptMainMaxUserId- @idTestRange and @rptMainMaxUserId
    and modifyDateTime <=  @rptMainMaxModifyDate
union
select 'union count', count(*) rowCount
from
(select userAccount.userID,
	userAccount.localeFriendly,
	userAccount.languageFriendly,
	userAccount.countryFriendly,
	userAccount.domain
from rpt_main_02.userAccount 
where userID >=  @rptMainMaxUserId-@idTestRange
    and userID not in (select userId from test.userAccount where modifyDateTime >= @rptMainMaxModifyDate)
    and userId is not null
union
select userAccount.userID,
	userAccount.localeFriendly,
	userAccount.languageFriendly,
	userAccount.countryFriendly,
	userAccount.domain
from test.userAccount
where userID  between  @rptMainMaxUserId-@idTestRange and @rptMainMaxUserId
    and modifyDateTime <=  @rptMainMaxModifyDate
    and userId is not null
) x
where userId is not null;

#######  hist_userAccount  ############################################################
/*
drop table if exists tmpHUA5;
create temporary table tmpHUA5 as 
select * 
from ss_core_02.hist_userAccount 
where userId >= (select min(userId) from test.hist_userAccount);

drop table if exists tmpHUA6;
create temporary table tmpHUA6 as 
select hist_userAccount.userID,
    hist_userAccount.firstName,
    hist_userAccount.lastName,
    hist_userAccount.nickName,
    hist_userAccount.accountType,
    hist_userAccount.emailAddress,    
    hist_userAccount.loginPassword,
    hist_userAccount.locale,
    hist_userAccount.timeZone,
    hist_userAccount.newsFlags,
    hist_userAccount.statusFlags,
    hist_userAccount.insertByUserID,
    hist_userAccount.insertDateTime,
    hist_userAccount.modifyByUserID,
    hist_userAccount.modifyDateTime,
    hist_userAccount.sessionLogID,
	hist_userAccount.hist_effectiveThruDateTime
from test.hist_userAccount;

CHECKSUM TABLE tmpHUA6;
CHECKSUM TABLE tmpHUA6;
*/
######################################################################
###########   GRID  ##############################################
select 'grid rpt_main', max(gridId) from rpt_main_02.grid
union
select 'grid test', max(gridId) from test.grid
union
select 'grid ss_log_02',max(gridId) from ss_core_02.grid
union
select 'difference test-->sslog',  a-b as diff
from
(select max(gridId)  a
from test.grid) xx
inner join 
(select max(gridId)  b
from ss_core_02.grid) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(gridId)  a
from  test.grid) xx
inner join 
(select max(gridId)  b
from rpt_main_02.grid)yy
union
select 'difference rptmain-->ssLog',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.grid) xx
inner join 
(select max(gridId)  b
from ss_core_02.grid) yy
 ;
###########   gridAccessMap ##############################################
select 'gridAccessMap rpt_main', max(gridId) from rpt_main_02.gridAccessMap
union
select 'gridAccessMap test', max(gridId) from test.gridAccessMap
union
select 'gridAccessMap ss_core_02',max(gridId) from ss_core_02.gridAccessMap
union
select 'difference test-->ssCore',  a-b as diff
from
(select max(gridId)  a
from test.gridAccessMap) xx
inner join 
(select max(gridId)  b
from ss_core_02.gridAccessMap) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(gridId)  a
from  test.gridAccessMap) xx
inner join 
(select max(gridId)  b
from rpt_main_02.gridAccessMap)yy
union
select 'difference rptmain-->ssCore',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.gridAccessMap) xx
inner join 
(select max(gridId)  b
from ss_core_02.gridAccessMap) yy
 ;

/* Debugging
select *
from rpt_main_02.gridAccessMap
where gridId between 8395723-100000 and 8395723
and deleteStatus = 1;


select deleteStatus, count(*), min(gridId), max(gridId), min(modifyDateTime), max(modifyDateTime), min(insertDateTime), max(insertDateTime)
from rpt_main_02.gridAccessMap
#where gridId between 8395723-100000 and 8395723
#where deleteStatus = 1
group by deleteStatus;
*/

############################################################################################
select 'rpt_main_02 arc_serverActionLookup', count(*) rowCount
from rpt_main_02.arc_serverActionLookup ua1
union
select 'test arc_serverActionLookup', count(*) rowCount
from test.arc_serverActionLookup ua2;

/*
select *
from rpt_main_02.arc_serverActionLookup a
left outer join test.arc_serverActionLookup b
    on a.actionID = b.actionID and a.urlActionID = b.urlActionID and a.formAction = b.formAction and a.formName = b.formname;

select *
from rpt_main_02.arc_serverActionLookup a
right outer join test.arc_serverActionLookup b
    on a.actionID = b.actionID and a.urlActionID = b.urlActionID and a.formAction = b.formAction and a.formName = b.formname;
*/
select 'requestLog test' as tab, max(requestLogId) from test.arc_requestLog
union
select 'requestLog ss_core_02',max(requestLogId) from ss_log_02.requestLog
union
select 'difference',  a-b as diff
from
(select max(requestLogId) a
from test.arc_requestLog) x
inner join 
(select max(requestLogId) b
from ss_log_02.requestLog)
 y;


######################################################################
select 'clientEvent rpt_main', max(clientEventId) from rpt_main_02.arc_clientEvent
union
select 'clientEvent test', max(clientEventId) from test.arc_clientEvent
union
select 'clientEvent ss_log_02',max(clientEventId) from ss_log_02.clientEvent
union
select 'difference test-->sslog',  a-b as diff
from
(select max(clientEventId)  a
from test.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from ss_log_02.clientEvent) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(clientEventId)  a
from  test.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from rpt_main_02.arc_clientEvent)yy
union
select 'difference rptmain-->ssLog',  a-b as diff
from
(select max(clientEventId)  a
from  rpt_main_02.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from ss_log_02.clientEvent) yy
 ;


######################################################################
## Testing Fails as of 3/4/2014  --> I believe this has to do with
## duplicate rows getting created based on gridId=displayObjId
## do we really want duplicate containerIds in this table?

/*
use test;
CHECKSUM TABLE rpt_main_02.container extended;  #784932799
CHECKSUM TABLE test.container extended;         #784932799
CHECKSUM TABLE rpt_main_02.grid;  #3489912372
CHECKSUM TABLE test.grid;         #3489912372
CHECKSUM TABLE rpt_main_02.gridAccessMap;  #3508264395
CHECKSUM TABLE test.gridAccessMap;         #3508264395
CHECKSUM TABLE rpt_main_02.rpt_containerList extended;  #443622671

drop table if exists test.tmp7;

create temporary table test.tmp7 as 
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from test.rpt_containerList;


CHECKSUM TABLE test.tmp7 extended;  #443622671
*/
# First make sure that the data was actually moved over
# Counts should be identical
/*
select 'rpt_containerList test' as tab, max(containerId), count(*) as rowcnt 
from test.rpt_containerList c
union
select 'rpt_containerList rpt_main_02' as tab, max(containerId), count(*) as rowcnt 
from rpt_main_02.rpt_containerList c
union
select 'union' as tab, max(containerId), count(*) as rowcnt 
from 
(
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from test.rpt_containerList
union
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from rpt_main_02.rpt_containerList
) x;
*/

/*  
##### debugging queries 
select max(containerId) from test.rpt_containerList;

select 'test', r.* from test.rpt_containerList r where containerId = 1079562
union
select 'rptmain',r.*, '', '' from rpt_main_02.rpt_containerList r where containerId = 1079562
union
select 'sscore',r.*, '', '' from rpt_main_02.rpt_containerList r where containerId = 1079562
;

create table tmpContainerDups as 
select containerID, count(*) rowcnt
from (
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from test.rpt_containerList
union
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from rpt_main_02.rpt_containerList
) x
group by containerId
having count(*) > 1;
*/

###########   GRID  ##############################################
select 'grid rpt_main', max(gridId) from rpt_main_02.grid
union
select 'grid test', max(gridId) from test.grid
union
select 'grid ss_log_02',max(gridId) from ss_core_02.grid
union
select 'difference test-->sslog',  a-b as diff
from
(select max(gridId)  a
from test.grid) xx
inner join 
(select max(gridId)  b
from ss_core_02.grid) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(gridId)  a
from  test.grid) xx
inner join 
(select max(gridId)  b
from rpt_main_02.grid)yy
union
select 'difference rptmain-->ssLog',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.grid) xx
inner join 
(select max(gridId)  b
from ss_core_02.grid) yy
 ;
###########   gridAccessMap ##############################################
select 'gridAccessMap rpt_main', max(gridId) from rpt_main_02.gridAccessMap
union
select 'gridAccessMap test', max(gridId) from test.gridAccessMap
union
select 'gridAccessMap ss_core_02',max(gridId) from ss_core_02.gridAccessMap
union
select 'difference test-->ssCore',  a-b as diff
from
(select max(gridId)  a
from test.gridAccessMap) xx
inner join 
(select max(gridId)  b
from ss_core_02.gridAccessMap) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(gridId)  a
from  test.gridAccessMap) xx
inner join 
(select max(gridId)  b
from rpt_main_02.gridAccessMap)yy
union
select 'difference rptmain-->ssCore',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.gridAccessMap) xx
inner join 
(select max(gridId)  b
from ss_core_02.gridAccessMap) yy
 ;


select deleteStatus, count(*), min(gridId), max(gridId), min(modifyDateTime), max(modifyDateTime), min(insertDateTime), max(insertDateTime)
from rpt_main_02.gridAccessMap
#where gridId between 8395723-100000 and 8395723
#where deleteStatus = 1
group by deleteStatus;


select deleteStatus, count(*), min(gridId), max(gridId), min(modifyDateTime), max(modifyDateTime), min(insertDateTime), max(insertDateTime)
from test.gridAccessMap
#where gridId between 8395723-100000 and 8395723
#where deleteStatus = 1
group by deleteStatus;




######################################################################
## Testing Fails as of 3/7/2014  --> This is due to 
## duplicate grid owners in rpt_main_02.gridAccessMap.  Run these queries for details:
/*
select gridId, count(*)
from rpt_main_02.gridAccessMap
where access = 50
group by gridID
having count(*) > 1;

select gridId, count(*)
from ss_core_02.gridAccessMap
where access = 50
group by gridID
having count(*) > 1;
*/

/*
use test;
CHECKSUM TABLE rpt_main_02.container extended;  #784932799
CHECKSUM TABLE test.container extended;         #784932799
CHECKSUM TABLE rpt_main_02.grid;  #3489912372
CHECKSUM TABLE test.grid;         #3489912372
CHECKSUM TABLE rpt_main_02.gridAccessMap;  #3508264395
CHECKSUM TABLE test.gridAccessMap;         #3508264395
CHECKSUM TABLE rpt_main_02.rpt_containerList extended;  #443622671

drop table if exists test.tmp7;

create temporary table test.tmp7 as 
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from test.rpt_containerList;

CHECKSUM TABLE test.tmp7 extended;  #443622671
*/

# First make sure that the data was actually moved over
# Counts should be identical
/*
select 'rpt_containerList test' as tab, max(containerId), count(*) as rowcnt 
from test.rpt_containerList c
union
select 'rpt_containerList rpt_main_02' as tab, max(containerId), count(*) as rowcnt 
from rpt_main_02.rpt_containerList c
union
select 'union' as tab, max(containerId), count(*) as rowcnt 
from 
(
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from test.rpt_containerList
union
select 	`rpt_containerList`.`containerID`,
    `rpt_containerList`.`containerName`,
    `rpt_containerList`.`gridID`,
    `rpt_containerList`.`gridDataTimestamp`,
    `rpt_containerList`.`ownerUserID`,
    `rpt_containerList`.`shareCount`,
    `rpt_containerList`.`loadCount`,
    `rpt_containerList`.`sourceContainerID`,
    `rpt_containerList`.`sourceContainerName`   
from rpt_main_02.rpt_containerList
) x;
*/



