# While testing code changes in proc_syncUserAccount,
# Use this to reset test.userAccount back to state in rpt_main_02

delete 
from test.userAccount 
where userId > (select max(userId) from rpt_main_02.userAccount);

update test.userAccount
set modifyDateTime = (select modifyDateTime from rpt_main_02.userAccount where userId = (select max(userId) from rpt_main_02.userAccount))
where modifyDateTime > (select modifyDateTime from rpt_main_02.userAccount where userId = (select max(userId) from rpt_main_02.userAccount));

delete from test.grid 
where gridId > (select max(gridId) from rpt_main_02.grid);

update test.grid
set modifyDateTime = (select modifyDateTime from rpt_main_02.grid where gridId = (select max(gridId) from rpt_main_02.grid))
where modifyDateTime > (select modifyDateTime from rpt_main_02.grid where gridId = (select max(gridId) from rpt_main_02.grid));

delete from test.gridAccessMap 
where gridId > (select max(gridId) from rpt_main_02.gridAccessMap);

update test.gridAccessMap
set modifyDateTime = (select modifyDateTime from rpt_main_02.gridAccessMap where gridId = (select max(gridId) from rpt_main_02.gridAccessMap))
where modifyDateTime > (select modifyDateTime from rpt_main_02.gridAccessMap where gridId = (select max(gridId) from rpt_main_02.gridAccessMap));

delete from test.arc_clientEvent 
where clientEventId > (select max(clientEventId) from rpt_main_02.arc_clientEvent);

delete from test.arc_requestLog
where requestLogId > (select max(requestLogId) from rpt_main_02.arc_requestLog);

drop table if exists test.arc_serverActionLookup;
create table if not exists test.arc_serverActionLookup like rpt_main_02.arc_serverActionLookup;
insert into test.arc_serverActionLookup select * from rpt_main_02.arc_serverActionLookup;

create table if not exists test.rpt_signupSource like rpt_main_02.rpt_signupSource;
insert into test.rpt_signupSource select * from rpt_main_02.rpt_signupSource where signupInsertDateTime > '2014-03-20';




select count(*) from test.rpt_signupRequestTrackingItem;
drop table if exists test.rpt_signupRequestTrackingItem;
create table if not exists test.rpt_signupRequestTrackingItem like rpt_main_02.rpt_signupRequestTrackingItem;
insert into test.rpt_signupRequestTrackingItem select * from rpt_main_02.rpt_signupRequestTrackingItem where signupRequestID >= 4000000;

create table if not exists test.rpt_userIPLocation like rpt_main_02.rpt_userIPLocation;
create table if not exists test.ref_campaignLookup like rpt_main_02.ref_campaignLookup;
create table if not exists test.ref_campaignSegmentLookup like rpt_main_02.ref_campaignSegmentLookup;
create table if not exists test.ref_ipAddressInfo like rpt_main_02.ref_ipAddressInfo;

insert into test.rpt_userIPLocation select * from rpt_main_02.rpt_userIPLocation;
insert into test.ref_campaignLookup select * from rpt_main_02.ref_campaignLookup;
insert into test.ref_campaignSegmentLookup select * from rpt_main_02.ref_campaignSegmentLookup;
insert into test.ref_ipAddressInfo select * from rpt_main_02.ref_ipAddressInfo;


##################################################################################################################
select 'test', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate from test.userAccount
union
select 'core', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate  from ss_core_02.userAccount
union
select 'main', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate  from rpt_main_02.userAccount;
#################################################################################################################
select 'test', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate from test.hist_userAccount
union
select 'core', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate  from ss_core_02.hist_userAccount
union
select 'main', count(*) cnt, max(userId) maxUser, max(insertDateTime) insDate, max(modifyDateTime) modDate  from rpt_main_02.hist_userAccount;
##################################################################################################################
select 'test', count(*) cnt, max(clientEventId) maxClientEventId, max(eventDateTime) maxEvDate from test.arc_clientEvent
union
select 'log', count(*) cnt, max(clientEventId) maxClientEventId, max(eventDateTime) maxEvDate from ss_log_02.clientEvent
union
select 'main', count(*) cnt, max(clientEventId) maxClientEventId, max(eventDateTime) maxEvDate from rpt_main_02.arc_clientEvent;
##################################################################################################################
select 'test', count(*) cnt, max(requestLogId) maxRequestLogId, max(insertDateTime) maxEvDate from test.arc_requestLog
union
select 'log', count(*) cnt, max(requestLogId) maxRequestLogId, max(insertDateTime) maxEvDate from ss_log_02.requestLog
union
select 'main', count(*) cnt, max(requestLogId) maxRequestLogId, max(insertDateTime) maxEvDate from rpt_main_02.arc_requestLog;
##################################################################################################################

/*
drop table if exists test.rpt_paymentProfileMaster;
create table if not exists test.rpt_paymentProfileMaster like rpt_main_02.rpt_paymentProfileMaster;
insert into test.rpt_paymentProfileMaster select * from rpt_main_02.rpt_paymentProfileMaster;

drop table if exists test.rpt_paymentProfile;
create table if not exists test.rpt_paymentProfile like rpt_main_02.rpt_paymentProfile;
insert into test.rpt_paymentProfile select * from rpt_main_02.rpt_paymentProfile;

select 'test', count(*) cnt, max(paymentProfileId) maxUser, max(eventDateTime) evDate from test.rpt_paymentProfileMaster
union
select 'core', count(*) cnt, max(paymentProfileId) maxUser, max(eventDateTime) evDate from ss_core_02.rpt_paymentProfileMaster
union
select 'main', count(*) cnt, max(paymentProfileId) maxUser, max(eventDateTime) evDate from rpt_main_02.rpt_paymentProfileMaster;
*/




