#Create test Schema
# start development with 7 tables to populate: 98 minutes of execution time.
use test;

drop table if exists test.userAccount;
create table if not exists test.userAccount like rpt_main_02.userAccount;
insert into test.userAccount select * from rpt_main_02.userAccount;

drop table if exists test.hist_userAccount;
create table if not exists test.hist_userAccount like rpt_main_02.hist_userAccount;
insert into test.hist_userAccount
(
    hist_userAccount.userID,
    hist_userAccount.firstName,
    hist_userAccount.lastName,
    hist_userAccount.nickName,
    hist_userAccount.accountType,
    hist_userAccount.emailAddress,
    hist_userAccount.loginPassword,
    hist_userAccount.locale,
    hist_userAccount.timeZone,
    hist_userAccount.newsFlags,
    hist_userAccount.statusFlags,
    hist_userAccount.insertByUserID,
    hist_userAccount.insertDateTime,
    hist_userAccount.modifyByUserID,
    hist_userAccount.modifyDateTime,
    hist_userAccount.sessionLogID,
    hist_userAccount.hist_effectiveThruDateTime
	
) select * from ss_core_02.hist_userAccount
where userId > (select max(userId) - 100000 from ss_core_02.userAccount);


drop table if exists test.arc_clientEvent;
create table if not exists test.arc_clientEvent like rpt_main_02.arc_clientEvent;

drop table if exists test.grid;
create table if not exists test.grid like rpt_main_02.grid;
insert into test.grid
select * from rpt_main_02.grid;


insert into test.arc_clientEvent
select *
from rpt_main_02.arc_clientEvent
where clientEventID > (select max(clientEventId)-5000000 from rpt_main_02.arc_clientEvent);

drop table if exists test.rpt_paymentProfile;
create table if not exists test.rpt_paymentProfile like rpt_main_02.rpt_paymentProfile;
insert into test.rpt_paymentProfile select * from rpt_main_02.rpt_paymentProfile;

drop table if exists test.arc_requestLog;
create table if not exists test.arc_requestLog like ss_log_02.requestLog;
insert into test.arc_requestLog
select *
from rpt_main_02.arc_requestLog
where requestLogID > (select max(requestLogId)-1000000 from rpt_main_02.arc_requestLog);

drop table if exists test.arc_serverActionLookup;
create table if not exists test.arc_serverActionLookup like rpt_main_02.arc_serverActionLookup;
insert into test.arc_serverActionLookup select * from rpt_main_02.arc_serverActionLookup;

drop table if exists test.container;
create table if not exists test.container as
select *
from rpt_main_02.container;

#where containerId > (select max(containerId) - 100000 from ss_core_02.container)
#or modifyDateTime > (select modifyDateTime from ss_core_02.container where containerId = (select max(containerId) - 100000 from ss_core_02.container));

select modifyDateTime from ss_core_02.container where containerId = (select max(containerId) - 100000 from ss_core_02.container);

drop table if exists test.rpt_containerList;
CREATE TABLE IF NOT EXISTS test.rpt_containerList(
	containerID BIGINT primary key, 
	containerName VARCHAR(50), 
	gridID BIGINT, 
	gridDataTimestamp INT, 
	ownerUserID BIGINT, 
	shareCount INT, 
	loadCount INT, 
	sourceContainerID BIGINT, 
	sourceContainerName VARCHAR(50),
	containerInsertDateTime datetime,
    containerModifyDateTime datetime
)
;

	
CREATE INDEX rpt_containerList_idx1 ON test.rpt_containerList (gridID);

INSERT test.rpt_containerList
SELECT c.*, InsertDateTime,ModifyDateTime
FROM rpt_main_02.rpt_containerList c
join ss_core_02.container ssc
on c.containerID = ssc.containerID;

drop table if exists test.gridAccessMap;

CREATE TABLE test.gridAccessMap (
  `gridID` bigint(20) NOT NULL DEFAULT '0',
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `access` tinyint(4) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `insertByUserID` bigint(20) DEFAULT NULL,
  `modifyDateTime` datetime DEFAULT NULL,
  `modifyByUserID` bigint(20) DEFAULT NULL,
  `sessionLogID` bigint(20) DEFAULT NULL,
  `dataTimestamp` int(11) DEFAULT NULL,
  `deleteStatus` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`gridID`,`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
insert into test.gridAccessMap
select * from rpt_main_02.gridAccessMap;

select count(*) from rpt_main_02.gridAccessMap;

drop table if exists test.arc_prepV2QueryHistory;
create table if not exists test.arc_prepV2QueryHistory like rpt_main_02.arc_prepV2QueryHistory;
insert into test.arc_prepV2QueryHistory select * from rpt_main_02.arc_prepV2QueryHistory;

################################### 

select 'arc_clientEvent',count(*) from arc_clientEvent
union
select 'userAccount',count(*) from userAccount
union
select 'arc_requestLog',count(*) from arc_requestLog
union
select 'rpt_paymentProfile',count(*) from rpt_paymentProfile
union
select 'rpt_paymentProfileMaster',count(*) from rpt_paymentProfileMaster
union
select 'rpt_containerList',count(*) from rpt_containerList
union
select 'arc_serverActionLookup',count(*) from arc_serverActionLookup;


##################################################
# find primary keys for all tables 







