# List of custom Insight indexes for ss_core_02 and ss_account_02 databases
# 2017-10-29 - jmarzinke added file

# Core
CREATE INDEX idx_modifyDate ON ss_core_02.paymentProfile (modifyDateTime);
CREATE INDEX idx_modifyDate ON ss_core_02.hist_paymentProfile (modifyDateTime);
CREATE INDEX idx_userID ON ss_core_02.accessToken (userID);
CREATE INDEX idx_apiClientID ON ss_core_02.accessToken (apiClientID);
CREATE INDEX idx_contactID ON ss_core_02.organization (mainContactUserID);
CREATE INDEX idx_modifyDateTime ON ss_core_02.userAccount (modifyDateTime);
CREATE INDEX idx_product ON ss_core_02.hist_paymentProfile (productID);
CREATE INDEX idx_planRate ON ss_core_02.hist_paymentProfile (planRate);
CREATE INDEX idx_orgid ON ss_core_02.domain (organizationID);
CREATE INDEX idx_insdatetime ON ss_core_02.userAccount (insertDateTime);
CREATE INDEX marz_organizationID_role_state_idx ON ss_core_02.organizationUserRole (organizationID, role, state);
CREATE INDEX marz_modifyDateTime_idx ON ss_core_02.organizationUserRole (modifyDateTime);
CREATE INDEX marz_organizationID_role_state_insertDateTime_idx ON ss_core_02.organizationUserRole (organizationID, role, state, insertDateTime);
CREATE INDEX userAccount_insertByUserID ON ss_core_02.userAccount (insertByUserID);

# Account
CREATE INDEX marz_userID ON ss_account_02.bulletinUser (userID);
CREATE INDEX marz_modifyDateTime ON ss_account_02.orgConfigSetting (modifyDateTime);
CREATE INDEX marz_modifyDateTime ON ss_account_02.userConfigSetting (modifyDateTime);