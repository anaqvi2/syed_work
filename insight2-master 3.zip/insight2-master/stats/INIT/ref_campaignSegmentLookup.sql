DROP TABLE IF EXISTS rpt_main_02.ref_campaignSegmentLookup;
CREATE TABLE IF NOT EXISTS rpt_main_02.ref_campaignSegmentLookup(segmentID INT, segmentDescription nvarchar(500), PRIMARY KEY(segmentID))  ENGINE = MYISAM;

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1, 'New Hire Checklist');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2, 'Employee Exit');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3, 'Relocation');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4, 'Technical Recruiting');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5, 'HR Dashboard');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (6, 'Office Move');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (7, 'Master Recruiting');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (8, 'Job Offer');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (9, 'Performance Reviews');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (10, 'Employee Termination');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (11, 'HR');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (12, 'Direct Mail');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (13, 'Promoting Blog');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (14, 'Webcast/Podcast Planning');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (15, 'Customer Needs Analysis');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (16, 'Pay-per-click Advertising');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (17, 'Product Launch');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (18, 'Branding Campaign');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19, 'Customer Case Study');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (20, 'Editorial Checklist');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (21, 'Marketing Goals');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (22, 'Tradeshow Planning');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (23, 'Event Planning');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (24, 'Customer Testimonial');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (25, 'Networld + Interop Planning');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (26, 'Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (27, 'SDLC Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (28, 'Architecture Macro');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (29, 'Architecture other');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (30, 'Jotspot Micro Segment');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (31, 'EditGrid Micro Segment');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (32, 'Sharepoint');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (33, 'Collaboration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (34, 'Wedding Planning Checklist');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (35, 'Wedding Planning Other');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (36, 'Sales Training');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (37, 'Marketing Survey');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (38, 'KMS System');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (39, 'Online Business Startup Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (40, 'Marketing Plan Development');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (41, 'Bug Tracking');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (46, 'Basecamp Templates');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (47, 'Basecamp Flexible Lists');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (48, 'Non Profit Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (49, 'Task Management OPT');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (50, 'Collaboration Tool OPT');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (51, 'Templates');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (52, 'Productivity Linking to Book');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (53, 'VA Organization');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (54, 'To Do List');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (55, 'Simple Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (56, 'Project Development');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (57, 'Project Execution');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (58, 'Kick-Off Meeting');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (99, 'iPad');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (100, 'Animoto Video');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (101, 'Sept 2008 - 12mo for $99');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (102, 'Mark email to Classic customers that have not merged to Beta');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (103, 'Office Apps');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (104, 'Smartsheet Sales');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (105, 'Coordinate');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (106, 'Office Apps - Chrome - Gantt'); /*Added "2012-04-10"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (107, 'Forms'); /*Added "2012-05-29"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (108, 'Education - Academic Resources - Group Project - Chrome Web Store - Free Sheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (109, 'Education - Teacher & Admin Tools - Syllabus - Chrome Web Store - Free Sheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (111, 'Packaged App - Chrome Web Store'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (112, 'Google Apps Marketplace - v2'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (113, 'GWD - Animated Image Ads'); 

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (110, 'twitter.com/smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (120, 'twitter.com/markmader');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (130, 'twitter.com/');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (134, 'Blist');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (135, 'Basecamp');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (136, 'LiquidPlanner');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (137, 'Zoho');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (138, 'TeamSpace');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (139, 'Daptive');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (140, 'Attask');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (141, 'Wrike');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (142, 'DeskAway');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (143, 'Clarizen');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (144, 'Central Desktop');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (145, 'Manymoon');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (146, 'Office365');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (147, 'QuickBase');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (148, 'Resourcr');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (149, 'Podio');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (150, 'GeniusInside');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (151, 'ProWorkFlow');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (152, 'Atlassian');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (153, 'Vertabase');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (154, 'PlanningForce');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (155, 'JXProject');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (156, 'FogCreek');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (157, 'Confluence');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (158, 'MS Project');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (159, 'Paymo');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (160, 'Sprintly');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (161, 'TeamworkPM');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (162, 'Trello');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (163, 'Asana');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (164, '5PM');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (165, 'Smartdraw');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (166, 'Robohead');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (167, 'Sharepoint');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (168, 'ProjectPlace (Frankfurt, Germany)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (169, 'PlanIO (Berlin, Germany)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (170, 'Easy-PM (Germany)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (171, 'Werkstatt42 (Germany)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (172, 'Projecterus (Koln, Germany)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (173, 'Mavenlink');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (174, 'Huddle');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (175, 'Yammer');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (176, 'MS Project Viewer');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (177, 'Competitor Macro Segment');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (178, 'MS Project for Mac');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (179, 'Office 365 Planner');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (186, 'ServiceNow');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (200, 'RFP Coordination and Document Management');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (210, 'Due Diligence'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (211, 'Job Search'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (212, 'Month End Close'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (213, 'Loan Amortization');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (214, 'Mergers & Acquisitions');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (215, 'Financial Reporting Templates');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (216, 'Scheduling (non PM)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (217, 'Balanced Scorecard');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (250, 'Credit Unions');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (300, 'Smartsourcing main page');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (301, 'Smartsourcing landing page');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (302, 'Crowdwork webinar');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (303, 'Google Crowdsourcing solution page');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (350, 'Google Drive');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (351, 'Mechanical Turk');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (352, 'Salesforce');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (353, 'Zimbra');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (354, 'Box');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (355, 'Dropbox');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (400, 'Project Management - Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (401, 'Online Project Collaboration Tool');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (402, 'OPCT - To Do List');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (403, 'OPCT - Team');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (404, 'OPCT - Productivity');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (405, 'Project Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (406, 'Google Solutions Marketplace - Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (410, 'Online Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (411, 'Project Management Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (412, 'Project Management Tool');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (413, 'Simple Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (414, 'Gantt');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (415, 'Gantt - Competitors');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (416, 'Gantt Chart (exact match)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (417, 'Gantt Ads on other keywords');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (418, 'Work Breakdown Structure');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (419, 'Project Management Software (exact match)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (420, 'Gantt (Image)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (421, 'Gantt Examples');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (422, 'Gantt Excel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (423, 'Gantt Pert');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (424, 'Gantt Project');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (425, 'Gantt Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (426, 'Gantt Templates');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (427, 'Gantt Timeline');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (428, 'Gantt Tools');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (429, 'Gantt (only)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (430, 'Gantt (no keywords)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (431, 'Gantt (misspellings)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (432, 'Project Management Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (433, 'Project Planning');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (434, 'Gantt Graph');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (435, 'Google Apps Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (436, 'Gantt Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (437, 'Gantt Mac');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (438, 'Gantt Free');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (439, 'Project Management Excel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (440, 'Project Management Broad');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (441, 'Project Timeline');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (442, 'Project Scheduling');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (443, 'Agile Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (444, 'IT Project Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (445, 'Project Manager');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (446, 'Project Report');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (447, 'Enterprise');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (448, 'Centralized Work Management for Government');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (450, 'Agile Generic');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (451, 'Kanban Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (452, 'Scrum Software');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (500, 'Sales Pipeline');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (501, 'Sales Pipeline - Customer');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (502, 'Sales Pipeline - Marketing');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (503, 'Sales Pipeline - Small Business');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (504, 'Sales Pipeline - Goldmine alternative');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (505, 'Sales Funnel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (507, 'Sales Tracking');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (508, 'Sales Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (509, 'Google Marketplace Sales Pipeline Solution');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (510, 'Sales Pipeline (with keywords)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (511, 'Sales Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (512, 'Sales Software');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (550, 'Contact Management System');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (551, 'Contact Management for Business');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (552, 'Contact Management Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (553, 'Contact Management Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (554, 'Contact Management Free');




INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (600, 'Expense Tracking');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (700, 'Online Team Collaboration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (701, 'Collaboration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (702, 'Collaboration for Business');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (703, 'Collaboration Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (704, 'Holding Down Office');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (705, 'Collaboration for Google Apps');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (710, 'Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (711, 'Tool Overload');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (712, 'Explore Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (714, 'Promoting Marketing Solutions Center');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (715, 'Get with the Times - Outdated Items');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (800, 'Run Your Small Business');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (801, 'Small Business Template Pack');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (802, 'Small Business Template Pack - template keywords');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (803, 'Cash for Clunkers');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (810, 'Business Software');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (900, 'Generic blog entry');  /* Added "2012-03-22*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (901, 'Collaboration Tools List');  /* Added "2012-03-22*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (902, 'Document Management Tools List');  /* Added "2012-03-22*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (903, 'CRM Tools List');  /* Added "2012-03-22*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (904, 'Project Management Tools List');  /* Added "2012-03-22*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (905, 'Crowdsourcing Tools List');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (906, 'Surveying Tools List'); /* Added "2012-03-22*/

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1100, 'Mac PM');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1150, 'Scheduling - Generic');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1151, 'Scheduling - Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1152, 'Scheduling - Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1153, 'Scheduling - Online');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1200, 'Task Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1201, 'Task Management - Broad - Two terms');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1202, 'Task Management - Broad - Three terms');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1203, 'Task Lists');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1204, 'Task Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1205, 'Task Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1206, 'Task Share');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1207, 'Task Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1208, 'Task Generic');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1209, 'Task Scheduling');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1210, 'Task Management for Google Apps');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1300, 'Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1301, 'Next Gen. Spreadsheet (Executive Keywords)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1302, 'Spreadsheet Hell');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1303, 'Spreadsheet Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1304, 'Spreadsheet Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1305, 'Death By Spreadsheet (blackwing)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1306, 'Trapped in Spreadsheet Hell? (blackwing)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1307, 'Spreadsheet for Work - Google Apps');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1400, 'Marketing');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1401, 'Marketing Tools');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1500, 'Property Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1600, 'Work Management');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1700, 'File Sharing');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1800, 'Salesforce');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1801, 'Google Drive');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1802, 'Evernote');

-- Remarketing Segments
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1900, '9 out of 10 Colleges Use Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1901, 'Gantt ad and landing page');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1902, 'Image');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1903, 'text');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1904, 'Animated image');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (1905, 'Card View');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2000, 'Business & Industrial');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2001, 'Computers & Electronics');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2002, 'Internet & Telecom');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2003, 'Law & Government');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2004, 'Business News');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2100, 'Business News');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2101, 'ERP');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2102, 'Finance');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2103, 'News');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2104, 'Opinion');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2501, 'Senior UI Designer');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2600, 'No cape required');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (2601, 'Leave office on time');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3000, 'Generic');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3001, 'Broad Match');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3002, 'Exact Match');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3100, 'Project');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3101, 'Manage');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3102, 'Gantt');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3103, 'Software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3104, 'Chart');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3105, 'Online');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3106, 'Task');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3107, 'Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3108, 'Free');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3109, 'Excel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3110, 'Plan');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3111, 'List');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3112, 'Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3113, 'Track');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3114, 'Tool');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3115, 'Mac');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3116, 'Share');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3117, 'Sales');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3118, 'Simple');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3119, 'Funnel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3120, 'Pipeline');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3121, 'Team');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3122, 'Create/Build');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3123, 'Forms');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3124, 'Collaboration');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3125, 'Product Launch'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3126, 'Calendar'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3127, 'video');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3128, 'app');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3129, '91% - techvalidate');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3130, 'SWOT');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3131, 'promoting gantt-chart-software');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3132, 'promoting top 3 secrets to selecting ms project replacement');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3133, 'I Can');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3134, 'Bar Graph in Excel');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3135, 'promoting 5 tips for online collaboration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3136, 'gigaom');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3137, 'Calendar in Excel blog post');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3138, 'Marketing Webinar Signup Form');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3139, 'Gantt chart in Excel blog post');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3200, 'Webinar Today');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3201, 'Webinar Tomorrow');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3202, 'Webinar');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (3301, 'Populous');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4001, 'A Tale of Two Sheets - Chapter 1');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4002, 'A Tale of Two Sheets - Chapter 2');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4003, 'A Tale of Two Sheets - Chapter 3');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4004, 'Smartsheet Integrates with Amazon Mechanical Turk');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4005, 'Event Planning Using Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4006, 'Smartsheet Overview - Manage Any Kind of Work');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4007, 'Notifications and Reminders in Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4008, 'Sending Files with Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4009, 'Smartsheet-Google Integration for Sales Pipeline Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4010, 'Smartsheet-Google Integration for Crowdsourcing');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4011, 'Smartsheet for Google Apps');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4012, 'Smartsheet + GoogleApps - Contextual Gmail Integration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4013, 'Smartsheet Gantt Feature Overview');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4014, 'Smartsheet Gmail integration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4015, 'Zimbra + Smartsheet Demo');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4016, 'Smartsheet Project Management for Google Apps (HD)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4017, 'Business Apps for the iPad: Chatter with Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4018, 'iPad Business Apps in the Wild - Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4019, 'Salesforce');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4020, 'Sharing');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4021, 'Smartforms');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4022, 'Smartsheet 101');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4023, 'Overview - General');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4024, 'Reporting');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4025, 'Formulas');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4026, 'Smartsheet - The Best Online Spreadsheet for Managing Work');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4027, 'Calendar View');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4028, 'Attachments');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4029, 'Conditional Formatting');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4030, 'Mobile');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4031, 'Asana vs Smartsheet Drag Race');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4032, 'Row Hierarchies');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4033, 'Gantt Chart View');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4034, 'Visceral PM focused');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4035, 'Box & Smartsheet = Easy project collaboration');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4036, 'Box Integration with Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4037, 'Alerts');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4038, 'Branding');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4039, 'Discussions');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4040, 'Contacts');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4041, 'Business Apps for Google Drive (Brent)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4042, 'Smartsheet Integrates with Google Apps and Google Drive');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4043, 'Ironman 1.5');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4044, 'Highlight Changes');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4045, 'Ironman 1.5e');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4046, 'Smartsheet Overview (with cell linking)');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4047, 'Send Row & Update Request video');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4048, 'Smartsheet Overview'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4049, 'Smartsheet Overview for New Collaborators'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4050, 'Using the Camera with Smartsheet App for iPhone & iPad'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4051, 'Smartsheet Project Management Overview'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4052, 'Smartsheet and Google Project Management:  An Overview'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4053, 'Smartsheet and Google:  An Overview'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4054, 'Smartsheet Additional Features'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4055, 'Smartsheet CEO on Growth & Market Opportunity'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4056, 'Ski Club Coordinates Races, Athletes and More with Smartsheet'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4057, 'Create a Simple Sales Pipeline with Smartsheet'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4058, 'Smartsheet:  One Stop Shop for Commercial Property Management Firm'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4059, 'Teaching the Next Generation of Business Professionals with Smartsheet'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4060, 'Attachments & File Sharing in Smartsheet'); /*Added "2012-04-10"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4061, 'Sharing Your Sheet in Smartsheet'); /*Added "2012-04-10"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4062, 'Collaborating on Sheets in Smartsheet'); /*Added "2012-04-10"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4063, 'Alerts & Reminders in Smartsheet'); /*Added "2012-04-10"*/

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4064, 'Discussions in Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4065, 'Smarter, Easier Web Forms from Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4066, 'Web Forms in Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4067, 'Smartsheet and Web Forms:  An Overview'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4068, 'Simple Gantt View in Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4069, 'Gantt with Dependencies in Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4070, 'Tracking Changes in Smartsheet'); /*Added "2013-06-24"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4071, 'Custom Branding in Smartsheet'); /*Added "2013-06-24"*/

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4072, 'Columns in Smartsheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4073, 'How to Set Up a Sheet in Smartsheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4074, 'Managing Franchise Growth in Smartsheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4075, 'Contacts in Smartsheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4076, 'Rows & Hierarchy in Smartsheet'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4077, 'File Sharing in Smartsheet and Dropbox'); 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4078, 'Work Anywhere with Smartsheet Mobile Apps');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4079, 'Project Management with Gantt Template Tutorial');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4080, 'Government Agency Manages Operations in Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4081, 'Smartsheet and Google');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4082, 'Google Apps at Cypress Grove Chevre');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4083, 'Smartsheet Resource Management');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4084, 'Smartsheet Resource Management Help Video');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4085, 'Webinar: Smartsheet 101: Getting Started');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4086, 'Architects Collaborate Efficiently with Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4087, 'Data Tracker - Start in Jira');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4088, 'Data Tracker - Start in Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4089, 'Working in Smartsheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4090, 'Intro to Smartsheet: Customers Share Favorite Features');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4093, 'OceanGate teaser');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4094, 'Evernote & Smartsheet YT');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4095, 'Coordinate Sales with South Water Signs');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4099, 'Google Apps for Work 30 sec teaser');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4100, 'Smartsheet Overview w/ cardview - 30 sec teaser');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4101, 'CTA Overlay - Smartsheet with cardview - 30 sec');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4102, 'CTA annotation - Smartsheet with cardview - 30 sec');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4103, 'Say hello to Smartsheet - 15 sec');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4104, 'CTA Overlay - Say hello - 15 sec');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4105, 'CTA annotation - Say hello - 15 sec');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (4106, 'Simplicity At Scale');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5000, 'Washington State Manufacturers');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5001, 'Want to boost team productivity?');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5700, 'ISR1');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5701, 'ISR2');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5702, 'ISR3');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5703, 'Strategic Accounts');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5704, 'Services');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5501, 'Smartsheet Account'); /*Added "2012-03-22"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5502, 'Smartsheet Apps'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5503, 'Smartsheet Business'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5504, 'Smartsheet Company'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5505, 'Smartsheet Corporate'); /*Added "2012-03-21"*/ 
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5506, 'Smartsheet Event Planning'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5507, 'Smartsheet Inc'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5508, 'Smartsheet Mobile'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5509, 'Smartsheet Online Collaboration'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5510, 'Smartsheet Project Management'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5511, 'Smartsheet Software'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5512, 'Smartsheet Solutions'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5513, 'Smartsheet Tool'); /*Added "2012-03-21"*/

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5600, 'Daily Project Tracking with Task Filters');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5601, 'Gradebook');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5602, 'Monthly Budget');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5603, 'Project Initiation Checklist');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5604, 'Sales Pipeline Template');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5605, 'Team Project with Gantt Chart'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5606, 'Client Contact List'); /*Added "2012-04-16"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5607, '4 Month Product Launch with Timeline'); /*Added "2012-04-16"*/
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5608, 'Wedding Budget Planner'); /*Added "2012-04-16"*/

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5609, 'Project Management Schedule and Budget');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5610, 'Client Contact Form');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5611, 'Home Improvement Planner');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5612, 'Simple Project Task List');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5613, 'College Application Sheet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5614, 'Dinner Party Planner');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5615, 'Fundraising Project');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5616, 'German Gantt Chart');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5617, 'German Home Improvement Planner');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (5618, 'German Project Management - Marketing Example');

INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (6600, 'Client On-boarding');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (6601, 'Professional Services Automation');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (18801, 'The Power of Done');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19901, '8 PM Blunders');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19902, 'PM for Non-PM Ebook');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19903, 'PMO Webinar');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19904, 'Agile 101 Ebook');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (19905, 'Top 3 Challenges of JIRA Ebook');


INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127260, 'Project - General');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127261, 'Project - Gestion de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127262, 'Project - Logiciel Gestion de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127263, 'Project - Logiciel Management de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127264, 'Project - Management de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127265, 'Project - Programme Gestion de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127266, 'Project - Programme Management de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127267, 'Project - Suivi de Projet');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127414, 'Gantt - General');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127415, 'Gantt - Digramme de Gantt');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127416, 'Gantt - Logiciel Diagramme de Gantt');
INSERT INTO rpt_main_02.ref_campaignSegmentLookup(segmentID, segmentDescription) VALUES (127417, 'Gantt - Programme Diagramme de Gantt');



