DROP TABLE IF EXISTS rpt_main_02.ref_campaignLookup;
CREATE TABLE IF NOT EXISTS rpt_main_02.ref_campaignLookup(campaignID INT, campaignDescription nvarchar(500), PRIMARY KEY(campaignID)) ENGINE = MYISAM;

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1, 'Human Resources');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2, 'Marketing Macro Segment');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3, 'Project Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4, 'Site Targeted: Event Marketing Micro Segment');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5, 'Architecture Macro Segment');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (6, 'Competitors');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (7, 'Site Targeted: Customer Testimonial');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8, 'Non-Business Macro Segment');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (9, 'Collaboration');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (10, 'Product Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (11, 'Groupware Software <BCOM>');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (12, 'Project Management Software <BCOM>');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (13, 'Marketing - Process Focus');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (14, 'Basecamp Enhancement Campaign');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (15, 'Non Profit Management Campaign');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16, 'Sharepoint Competitor');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (17, 'Document / RFP');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (18, 'Task and To Do');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19, 'Workflow');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (20, 'Online');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (21, 'Branding');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (22, 'Process');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (23, 'Productivity');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (24, 'Content - Image');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (25, 'Content - Text');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (26, 'Basex - Book');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (27, 'Basex - BETA');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (28, 'Sign In Email');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (29, 'Templates');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (30, 'Newsletter');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (31, 'HR Email');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (32, 'SEO Goddess posts / Phil email');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (33, 'Jenns Blog');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (34, 'Signup /b');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (35, 'Meeting');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (36, '?');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (46, '?');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (50, 'YouTube');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (51, 'Small Business List - January 09 Mail');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (52, 'Smartsourcing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (54, 'Sales');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (53, 'Mechanical Turk');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (55, 'Content Network - Display Ad Builder');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (56, 'Content - Animated Gif');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (57, 'Land and Expand');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (58, 'Brents Blog');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (59, 'Content Network - Flash');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (60, 'Task Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (61, 'Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (62, 'Event Planning');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (63, 'Manufacturing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (64, 'Property Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (65, 'Work Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (66, 'Top 5 Project tools (TJ McCue)');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (67, 'Google - DCO');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (68, 'File Sharing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (69, 'Integration Partners');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (70, 'NearStream');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (71, 'Generic');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (72, 'Credit Unions');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (73, 'Gantt');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (74, 'Coordination');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (75, 'Operations');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (76, 'Contacts');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (77, 'Human Resources');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (78, 'Surveys');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (79, 'Public Relations');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (80, 'Marketing');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (80, 'Marketing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (81, 'Planning');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (82, 'Spanish'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (83, 'French'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (84, 'Portuguese'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (85, 'German'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (86, 'Italian'); /*Added "2012-03-21"*/

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (87, 'Small Business'); /*Added "2012-04-17"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (88, 'Real Estate'); 
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (89, 'Paid Placement on Website'); 

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (90, 'Android App'); 
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (91, 'iOS App'); 
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (92, 'iPad App'); 
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (93, 'iPhone App');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (94, 'Misc'); 

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (100, 'Timeline');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (101, '?');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (102, '?');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (103, '?');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (150, 'MS Project (KW only)');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (160, 'PM website');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (170, 'Software > Business & Productivity Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (171, 'Business Services > Business Technology > Enterprise Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (172, 'Business Services > Business Technology');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (173, 'Business Services > Business Technology > Enterprise Software > CRM Solutions');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (174, 'Business Services > Business Technology > Enterprise Software > Collaboration & Conferencing Tools');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (175, 'Business Services > Business Technology > Enterprise Software > ERP Solutions');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (200, 'Google Interest - Business & Industrial');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (201, 'Google Interest - Business Operations');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (202, 'Google Interest - Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (203, 'Google Interest - Project Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (210, 'Google Interest - Computers & Electronics');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (211, 'Google Interest - Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (212, 'Google Interest - Business & Productivity Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (213, 'Google Interest - Calendar & Scheduling Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (214, 'Google Interest - Project Management Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (215, 'Google Interest - Spreadsheet Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (216, 'Google Interest - Finance');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (217, 'Google Interest - Enterprise Targeting'); /*Added "2012-03-21"*/
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (218, 'Google Interest - Large Business Targeting'); /*Added "2012-04-10"*/

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (219, '3rd party: eXelate - Bizo: Professional - Small Business Owners');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (220, '3rd party: BlueKai & Eyeota PM targets');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (221, 'In-market audience (ROI) - Business & Productivity Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (222, 'Engagement Campaign');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (223, 'Law & Government');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (224, 'Business Computing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (225, 'Business Finance');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (226, 'Ad placement in weekly email');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (300, 'Right Media - Business');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (301, 'Yahoo - Business & Tech');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (302, 'Custom Affinity: Project Management Software');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (303, 'ROS');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (304, 'Site Roadblock');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (350, 'Solutions');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (400, 'Forbes.com');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (401, 'WSJ.com');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (500, 'Referral Rewards - Bare Link');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (501, 'Referral Rewards - Badges');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (502, 'Referral Rewards - Email');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (503, 'Referral Rewards - Twitter');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (504, 'Referral Rewards - Facebook');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (505, 'Referral Rewards - Google+');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (506, 'Referral Rewards - LinkedIn');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (600, 'Scheduling');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (701, 'Professional Services Management');


INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1104, 'April 2011');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1105, 'December 2011');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1106, 'January 2013');


INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1201, 'Cloud Alliance - Email List');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1540, 'Web Form -Powered by Smartsheet- link');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1541, 'Web Form confirmation message -Powered by Smartsheet- link');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1542, 'Web Form email confirmation -Powered by Smartsheet- link');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (1543, 'Send Web Form link email -Try Smartsheet Web Forms- link');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2000, 'Gantt - Content');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2001, 'Project Management - Content');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2002, 'Online Gantt Chart - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2003, 'Gantt Chart Template - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2004, 'Project Management Template & Spreadsheet - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2005, 'Project Management Software - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2006, 'Project Management Generic - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2007, 'Project Management Excel - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2008, 'Project Management Plan - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2009, 'Project Management Track - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2010, 'Project Management Tool - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2011, 'Project Management Simple - Search');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2012, 'Webinars - Project Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2013, 'Webinars - Branding');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2014, 'Webinars - Human Resources');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2200, 'Promoted Tweet - Timeline - Keyword');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2201, 'Promoted Tweet - Search - Keyword');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2300, 'gCon');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2501, 'English speaking college graduates');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2502, 'Project related interests');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2503, 'Sales & Marketing related interests');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2504, 'Graphic Design, Web Design, Graphic Designer interests');


INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2601, 'LinkedIn - Everyone');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2602, 'LinkedIn - Managers and up');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2603, 'LinkedIn - Project Managers');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2604, 'LinkedIn - Project Managers - Job Title');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2605, 'LinkedIn - Program Managers - Job Title');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2606, 'Government Employees - Operations & Administrative');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2607, 'Linkedin - Project Managers - Job Title - Canada');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2608, 'Linkedin - Sponsored Update - Skill - Excel/Spreadsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2609, 'Linkedin - Sponsored Update - Job Function - Funding Announcement');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2610, 'Linkedin - Sponsored Update - Company Category Government - GSA Blog Post');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2611, 'Linkedin - Sponsored Update - Evernote chooses Smartsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2612, 'Linkedin - Sponsored Update - Gantt Chart Software');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2613, 'Linkedin - Sponsored Update - Top 3 secrets to selecting MS project replacement');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2614, 'Linkedin - Sponsored Update - Gantt Chart for Mac blog post');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2615, 'Linkedin - Sponsored Update - French Webinars');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2616, 'Linkedin - Sponsored Update - Spanish Webinars');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2617, 'Linkedin - 5 tips for online collaboration');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2618, 'Linkedin - Work Management for Government');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2619, 'Linkedin - Work Visualization - GigaOM');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2620, 'Linkedin - Netflix Employees');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2621, 'Linkedin - a monthly budget sheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2622, 'Linkedin - Sephora Marketing Webinar');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2623, 'Linkedin - Calendar in Excel');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2624, 'Linkedin - Coordinate: Marketing Webinar');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2625, 'LinkedIn - Sponsored Update - Marketing Job Function - Director +');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2626, 'LinkedIn - Offsite Managed Display');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2627, 'LinkedIn - Sponsored Update - Marketing Groups/Company Size');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2628, 'Linkedin - Sponsored Update - Select Companies');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2629, 'Twitter - Sponsored #ContentMarketing');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2700, 'Facebook - News Feed - Job Title - Project Manager');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2701, 'Facebook - free trial button within Facebook Apps category');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2702, 'Facebook - Promoted Post - GSA chooses Smartsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2703, 'Facebook - Promoted Post - OceanGate - PM new depths');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2704, 'Facebook - Promoted Post - Evernote chooses Smartsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2705, 'Facebook - News Feed - gantt-chart-software promotion');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2706, 'Facebook - Promoted Post - Top 3 secrets to selecting MS project replacement');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2707, 'Facebook - Gantt Chart for Mac blog post');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2708, 'Facebook - French Webinar');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2709, 'Facebook - Spanish Webinar');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2710, 'Promoted Tweet - Search - Keyword');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2711, 'Facebook - Work Management with Google Apps');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2712, 'Facebook - Wedding Timeline Template');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2750, 'Work Collaboration Startups Valuation');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2800, 'Twitter - Promoted Post - GSA chooses Smartsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2801, 'Twitter - Promoted Post - Evernote chooses Smartsheet');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2802, 'Twitter - Promoted Post - Gantt chart page');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2803, 'Twitter - Smartsheet branded keyword targeting');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2804, 'Twitter - Promoted Post - Top 3 secrets to selecting MS project replacement');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2805, 'Twitter - Competitor branded keyword targeting');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (2806, 'Twitter - a monthly budget sheet');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3101, 'Waiting for Spanish');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3301, 'Serchen - US PM Spotlight');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3302, 'Serchen - Front Page 160 wide');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3303, 'Serchen - Front Page 300 wide');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3304, 'Serchen - Project Collaboration');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3305, 'Card-View US Promotion: Agile');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3306, 'Card-View INTL-EN Promotion: Agile');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3307, 'Card-View US Promotion: Jira');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3308, 'Card-View INTL-EN Promotion: Jira');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3309, 'Card-View US Promotion: PM');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3310, 'Card-View INTL-EN Promotion: PM');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3311, 'Card-View US Promotion: Marketing/Design');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3312, 'Card-View INTL-EN Promotion: Marketing/Design');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3313, 'Card-View US-EN Promotion: Microsoft Project');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3314, 'Card-View INTL-EN Promotion: Microsoft Project');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3315, 'Card-View US Promotion');


INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (3400, 'Slideshare - Marketing Case Study Highlights');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4000, 'Trial User');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4001, 'Non Trial User');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4002, 'Trial User - No Login 7 days');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4003, 'Trial User - No Login 30 days');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (4004, 'All Users last 365 - using A,B Buckets from GA');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5700, 'LP - Spreadsheet No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5701, 'LP - Gantt, No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5702, 'LP - Simple PM, No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5703, 'LP - Project Management, No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5704, 'LP - Task Management, No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5705, 'LP - Gantt - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5706, 'LP - Project Management - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5707, 'Project Management Page View');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5708, 'LP - Task Management - Search');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5709, 'ProvConfirm Page');


INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5801, 'Pricing - No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5802, 'Try it Free - No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5803, 'Project Management - No Signup');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (5804, 'Generic - Signup Completed');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (6106, 'Template Specific Campaign'); /*Added "2012-03-21"*/

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (6200, 'Inventory Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (6300, 'Asset Tracking');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8701, 'Smartforms');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8702, 'Ironman Video');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8703, 'In-Stream, US, core Topic and Interest targeted');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8704, 'YT: In-Stream.US.Male.Interest.35-54.Daypart');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8705, 'YT: In-Search.Top Gantt & PM kws');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8706, 'YT: In-Stream.US.Male.Topic.24x7');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8707, 'YT: In-Stream.US.Female.Topic.24x7');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8708, 'YT: US Topics. Evernote');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8709, 'YT: US Topics. Sales');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8710, 'YT: EN International - Tier 1');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8711, 'YT: International - Japan');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8712, 'YT: US.Gantt.keywords');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8713, 'YT: Customers');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8714, 'YT: Affinity audience - business professionals');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (8715, 'YT: In-Stream');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (9000, 'Signup Link for Box Sales Team - sales enablement');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16001, 'BlueKai - C-Level');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16002, 'BlueKai - Exec/Upper Management');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16003, 'BlueKai - Information Technology & Computing');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16004, 'BlueKai - IT Professionals');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (16005, 'BlueKai - Management');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (18201, 'USA Today - First Run');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (18202, 'USA Today iPad - First Run');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19501, 'DemandMetric.com - Members');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19502, 'DemandMetric.com - Base');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19503, 'ProjectManagers.net - Members');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19504, 'ProjectsAtWork.com - Members');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (19505, 'ProjectManagement.com - Members');

INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (22001, 'Evernote Conference');
INSERT INTO rpt_main_02.ref_campaignLookup(campaignID, campaignDescription) VALUES (22002, 'Dreamforce (with Evernote)');
