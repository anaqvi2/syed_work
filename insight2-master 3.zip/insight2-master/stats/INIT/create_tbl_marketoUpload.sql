-- Create table used in uploading lead data to marketo
-- Revision History
-- 2014-04-22: TWJ:  Init
-- 2016-01-28: jmarzinke:  Add lead activity tables
-- 2016-06-23: jmarzinke:  Updates




CREATE TABLE arc_marketo_upload (
	-- primary key
	userID BIGINT (20),
	
	-- syncing mechanism fields
	pushToMarketo TINYINT (1),
	insertDateTime DATETIME,
	updateDateTime DATETIME,
	uploadDateTime DATETIME,
	uploadStatus VARCHAR (25),
	userAccountModifyDateTime DATETIME,	
	ppModifyDateTime DATETIME,
	trialModifyDateTime DATETIME,
	
	-- sales force fields	
	salesforceOwnerAtImport VARCHAR (50),
	salesforceStatus VARCHAR (25),
	smartscoreCode VARCHAR (50),
	salesforceLeadSource VARCHAR (25),
	
	-- userAccount fields
	firstName VARCHAR (50),
	lastName VARCHAR (50),
	emailAddress VARCHAR (100),
	emailDomain VARCHAR (100),
	isOrgDomain TINYINT (1),
	website VARCHAR (100),
	newsFlags INT (11),
	statusFlags INT (11),
	locale VARCHAR (5),
	timeZone VARCHAR (50),
	ABTests VARCHAR (1000),
	ipCountry VARCHAR (100),
	usedGoogleAuthentication TINYINT (1),
	isGoogleAppsInstalledDomain TINYINT (1),
	domainsHighestPlan VARCHAR (50),
	domainUseInPastYear INT (11),
	currentDomainTrials INT (11),
	wasSharedToPriorToTrial TINYINT (1),
	
	-- paymentProfile fields
	paymentProfileID BIGINT (20),
	parentPaymentProfileID BIGINT (20),
	productName VARCHAR (50),
	accountRole VARCHAR (50),
	userLimit INT (11),
	paymentStartDateTime DATETIME,
	nextPaymentDate DATETIME,
	paymentTerm TINYINT (4),
	planRate DECIMAL (41,2),
	monthlyPlanRate_USD DECIMAL (41,2),
	currencyCode VARCHAR (10),
	teamTrial TINYINT (1),
	trialStartDateTime DATETIME,
	trialEndDateDateTime DATETIME,
	isTrialRestart TINYINT (1),
	primaryContactPhone VARCHAR (20),
	billToAddress VARCHAR (101),  -- contains contents of billToAddress1 & billToAddress2
	billToCity VARCHAR (50),
	billToRegionCode VARCHAR (50),
	billToPostCode VARCHAR (50),
	billToCountryCode VARCHAR (50),
	organizationName VARCHAR (100),
	historyHighestPlan VARCHAR (50),
		
	-- signup tracking
	signupTrackingKeyword VARCHAR (100),
	signupTracking_s_code VARCHAR (100),
	signupTracking_c_code VARCHAR (100),
	signupTracking_m_code VARCHAR (100),
	signupBucket VARCHAR (50),
	signupSource VARCHAR (50),
	signupSubSource VARCHAR (100),
	marketoTrackingCookie VARCHAR (1500),
		
	-- usage
	lastLogin DATETIME,
	lastMobileLogin DATETIME,
	isEverWellQualified TINYINT (1),
	isStrongLead TINYINT (1),
	eventLogCount INT (11),
	loginCount INT (11),
	sheetCount INT (11),
	sharingCount INT (11),
	reportCount INT (11),
		
	-- supplemental data
	company VARCHAR (150),
	numberOfEmployees INT (11),
	
	churnRiskCategory VARCHAR (100),
	role VARCHAR (100),

	usedReminders TINYINT (1),
	usedBrandedWorkspace TINYINT (1),
	usedDriveAttachment TINYINT (1),
	usedEvernoteAttachment TINYINT (1),
	usedCellLinking TINYINT (1),
	usedChangeView TINYINT (1),
	
	discussionCount INT (11),
	importedSheetCount INT (11),
	templateCount INT (11),
	webFormCount INT (11),
	columnPropertyFormCount INT (11),
	hierarchyCount INT (11),
	attachmentCount INT (11),
	upgradeWizardProgress VARCHAR (100),
	insertSource VARCHAR (30),
	
	fitScore TINYINT (3),
	fitRating VARCHAR (10),
	appBehaviorScore INT (11),
	appBehaviorScoreOld INT (11),
	appBehaviorScoreNew INT (11),
	recurringBillingCancelled TINYINT (1),

	domainOptOut TINYINT (1),
	appOptOut TINYINT (1),
	containerCount INT (1),
	signupRequestID BIGINT(20),
	signupTrackingAppLaunchType TINYINT (1),
	userAccountInsertByUserID BIGINT (20),
	parentPaymentStartDateTime DATETIME,
	persona VARCHAR (25),
	ipRegion VARCHAR (200),
	organizationRoles VARCHAR (200),
	inferredTitle VARCHAR (100),

	iOSAppLoginCount INT(11),
	androidAppLoginCount INT(11),
	highestSharedSheetPermission VARCHAR(25),
	solutionsUsed VARCHAR(1000),
	salesforceOwnerRoleAtImport VARCHAR(50),
	ipCity VARCHAR(200),
	isUserAgreementAccepted TINYINT(1),
	imagesInGridCount INT(11),
	organizationID BIGINT(20),
    inferredRole VARCHAR(100),
    dashboardsEnabledDateTime DATETIME,
    dashboardCount INT(11),
    successRepEmail VARCHAR(100),
    successRepFirstName VARCHAR(50),
    successRepLastName VARCHAR(50),
    successRepPhoneNumber VARCHAR(25),
    accountHealth VARCHAR(25),
    accountTier VARCHAR(5),
    accountCSADripBucket VARCHAR(50),
    domainOwnerEmail VARCHAR(100),
    domainOwnerFirstName VARCHAR(50),
    domainOwnerLastName VARCHAR(50),
    domainOwnerTitle VARCHAR(80),
    domainOwnerPhoneNumber VARCHAR(25),
    orgProductName VARCHAR(50),
    bonusLicenseLimit INT(11),
    assignedLicenseCount INT(11),
    pendingLicenseCount INT(11),
    licenseTags VARCHAR(256),
    cardViewViewCount INT(11),
	PRIMARY KEY (userID),
	KEY idx_emailAddress (emailAddress),
  	KEY idx_paymentProfileId (paymentProfileId),
  	KEY idx_insertDateTime (insertDateTime),
  	KEY idx_emailDomain (emailDomain),
  	KEY idx_ppModifyDateTime (ppModifyDateTime),
  	KEY idx_push_to_marketo (pushToMarketo),
  	KEY idx_isOrgDomain (isOrgDomain),
    KEY idx_dashboardsEnabledDateTime (dashboardsEnabledDateTime)
) -- ENGINE=TokuDB  DEFAULT CHARSET=utf8
;



create index idx_emailDomain on rpt_main_02.arc_marketo_upload(emailDomain);
create index idx_ppModifyDateTime on rpt_main_02.arc_marketo_upload(ppModifyDateTime);


-- tracks the history of all inserts/updates/deletes on arc_marketo_upload
CREATE TABLE leadflow.arc_marketo_upload_journal(
  journalDateTime DATETIME(5) NOT NULL DEFAULT CURRENT_TIMESTAMP(5),
  journalAction VARCHAR(16) NOT NULL,
  userID BIGINT(20) NOT NULL DEFAULT 0,
  -- Rest of the fields mirror arc_marketo_upload exactly

  PRIMARY KEY (journalDateTime, userID)
);


CREATE TABLE IF NOT EXISTS leadflow.arc_marketo_upload_sync_history(
	insertDateTime	DATETIME, 
	processName 	VARCHAR (100),
	syncFlag		INT,
	recordCount		INT,

	KEY(insertDateTime));

CREATE TABLE leadflow.arc_marketo_upload_flags (
  priority tinyint(4) NOT NULL,
  PRIMARY KEY (priority)
) -- ENGINE=TokuDB  DEFAULT CHARSET=utf8
;


CREATE TABLE leadflow.arc_marketo_upload_control (
  executionDateTime datetime DEFAULT CURRENT_TIMESTAMP,
  active int(11) DEFAULT '1',
  max_amu_insertDateTime datetime DEFAULT NULL,
  max_amu_updateDateTime datetime DEFAULT NULL,
  max_amu_uaId bigint(20) DEFAULT NULL,
  max_amu_uaModifyDateTime datetime DEFAULT NULL,
  max_amu_ppId bigint(20) DEFAULT NULL,
  max_amu_ppModifyDateTime datetime DEFAULT NULL,
  max_amu_TrialStartDateTime datetime DEFAULT NULL,
  max_sscore_uaId bigint(20) DEFAULT NULL,
  max_sscore_uaModifyDateTime datetime DEFAULT NULL,
  max_sscore_uaInsertDateTime datetime DEFAULT NULL,
  max_sscore_ppId bigint(20) DEFAULT NULL,
  max_sscore_ppModifyDateTime datetime DEFAULT NULL,
  max_sscore_ppInsertDateTime datetime DEFAULT NULL,
  max_leadseed_ppModifyDateTime datetime DEFAULT NULL,
  max_sscore_slSessionLogID bigint(20) DEFAULT NULL
) -- ENGINE=TokuDB DEFAULT CHARSET=utf8
;

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_domainEmailExclusionExceptions(
  emailAddress VARCHAR(100) NOT NULL,
  insertDateTime DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  includeForSalesEmail TINYINT,
  includeForMarketingEmail TINYINT,
  PRIMARY KEY (emailAddress)
);


CREATE TABLE leadflow.arc_marketo_lead_activity (
  ID bigint(20) NOT NULL,
  leadId bigint(20) DEFAULT NULL,
  activityDateTime datetime DEFAULT NULL,
  activityTypeId smallint(6) DEFAULT NULL,
  primaryAttributeValueId mediumint(9) DEFAULT NULL,
  primaryAttributeValue varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  mailingId mediumint(9) DEFAULT NULL,
  choiceNumber smallint(6) DEFAULT NULL,
  device varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  isMobileDevice smallint(6) DEFAULT NULL,
  platform varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  stepId mediumint(9) DEFAULT NULL,
  testVariant mediumint(9) DEFAULT NULL,
  userAgent varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  category tinyint(4) DEFAULT NULL,
  details varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  email varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  subcategory smallint(6) DEFAULT NULL,
  clientIpAddress varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  formFields varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  queryParameters varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  referrerUrl varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  webformId smallint(6) DEFAULT NULL,
  webpageId mediumint(9) DEFAULT NULL,
  link varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  linkId varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  type varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  date datetime DEFAULT NULL,
  description varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  source varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  friendLeadId bigint(20) DEFAULT NULL,
  searchEngine varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  searchQuery varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  webpageUrl varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (ID),
  KEY activityTypeID_idx (activityTypeId),
  KEY activityDateTime_idx (activityDateTime)
);

CREATE TABLE leadflow.arc_marketo_email_activity (
  ID bigint(20) NOT NULL AUTO_INCREMENT,
  sendActivityID bigint(20) NOT NULL,
  leadID bigint(20) NOT NULL,
  primaryAttributeValueID mediumint(9) NOT NULL,
  primaryAttributeValue varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  sendDateTime datetime DEFAULT NULL,
  deliverDateTime datetime DEFAULT NULL,
  openDateTime datetime DEFAULT NULL,
  clickDateTime datetime DEFAULT NULL,
  bounceDateTime datetime DEFAULT NULL,
  softBounceDateTime datetime DEFAULT NULL,
  unsubscribeDateTime datetime DEFAULT NULL,
  insertDateTime datetime NOT NULL,
  modifyDateTime datetime NOT NULL,
  PRIMARY KEY (ID),
  KEY sendDateTime_idx (sendDateTime),
  KEY leadID_primaryAttributeValueID_idx (leadID,primaryAttributeValueID)
) -- ENGINE=TokuDB 
AUTO_INCREMENT=25261929 
-- DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
;

CREATE TABLE leadflow.arc_marketo_lead_activity_types (
  ID smallint(6) NOT NULL,
  name varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  description varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  attributeName varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  attributeDataType varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  isPrimary tinyint(4) DEFAULT NULL,
  databaseName varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL
);

CREATE TABLE leadflow.arc_marketo_lead_activity_query_history (
  startDateTime datetime NOT NULL,
  endDateTime datetime NOT NULL,
  activityTypeID smallint(6) NOT NULL,
  PRIMARY KEY (startDateTime,endDateTime,activityTypeID)
);

CREATE TABLE leadflow.arc_marketo_lead_lists (
  listID int(11) NOT NULL,
  listName varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  emailAddress varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  userID bigint(20) DEFAULT NULL,
  leadID bigint(20) NOT NULL,
  leadStatus varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  acceptedDateTime datetime DEFAULT NULL,
  2StarDateTime datetime DEFAULT NULL,
  3StarDateTime datetime DEFAULT NULL,
  activityCount mediumint(9) DEFAULT NULL,
  createdDateTime datetime DEFAULT NULL,
  newLeadTriggerDateTime datetime DEFAULT NULL,
  PRIMARY KEY (listID,emailAddress)
);

-- Used for tracking query times for Marketo nightly builds
CREATE TABLE leadflow.arc_marketo_query_history (
  buildID int(11) DEFAULT NULL,
  buildSequence smallint(6) DEFAULT NULL,
  tableName varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  startTime datetime NOT NULL,
  endTime datetime DEFAULT NULL,
  timeElapsed int(11) DEFAULT NULL,
  PRIMARY KEY (tableName,startTime),
  KEY buldID_idx (buildID,buildSequence)
);
