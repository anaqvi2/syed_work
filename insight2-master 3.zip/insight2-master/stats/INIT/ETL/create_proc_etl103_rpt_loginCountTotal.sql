# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_loginCountTotal table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_loginCountTotal()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_loginCountTotal//

create procedure etl_rpt_loginCountTotal(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_rpt_loginCountTotal',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(userId) from userAccount);
set v_destMaxModTime = (select modifyDateTime from userAccount where userId = v_destMaxId);

DROP TABLE IF EXISTS rpt_loginCountTotal;
CREATE TABLE IF NOT EXISTS rpt_loginCountTotal(
	userID 	BIGINT, 
	firstSessionLogID INT, 
	firstLogin DATETIME, 
	firstLoginYear INT, 
	firstLoginMonth VARCHAR(12), 
	firstLoginWeek VARCHAR(10), 	
	firstLoginDay VARCHAR(10), 
	lastSessionLogID INT,
	lastLogin DATETIME, 	
	lastLoginYear INT, 
	lastLoginMonth VARCHAR(12), 
	lastLoginWeek VARCHAR(10), 	
	lastLoginDay VARCHAR(10), 
	daysSinceFirstLogin INT, 
	daysSinceLastLogin INT, 
	daysActive INT, 
	loginCount INT, 
	loginStrength NUMERIC(38,18), 
	userLoggedInAtLeastOnce TINYINT, 
	userLoggedInAtLeastTwice TINYINT, 
	userLoggedInAtLeast4times TINYINT, 
	userLoggedInAtLeast8times TINYINT, 
	PRIMARY KEY(userID));
	
INSERT rpt_loginCountTotal(
	userID, 
	firstSessionLogID, 
	firstLogin, 
	firstLoginYear,
	firstLoginMonth, 
	firstLoginWeek, 
	firstLoginDay,
	lastSessionLogID,
	lastLogin, 
	lastLoginYear,
	lastLoginMonth, 
	lastLoginWeek, 
	lastLoginDay,	
	daysSinceFirstLogin, 
	daysSinceLastLogin, 
	daysActive,
	loginCount, 
	loginStrength,
	userLoggedInAtLeastOnce,
	userLoggedInAtLeastTwice,
	userLoggedInAtLeast4times,
	userLoggedInAtLeast8times)
SELECT 
	usa.userID, 
	usa.firstSessionID, 
	
	usa.firstSessionDateTime, 
	DATE_FORMAT(usa.firstSessionDateTime, '%Y'), 
	DATE_FORMAT(usa.firstSessionDateTime, '%Y*%m(%b)'),
	SMARTSHEET_WEEK(usa.firstSessionDateTime), 
	CONCAT(DATE_FORMAT(usa.firstSessionDateTime , '%Y'), "*", 
	       LPAD(MONTH(usa.firstSessionDateTime),2,"0"), "*", 
	       LPAD(DAYOFMONTH(usa.firstSessionDateTime),2,"0")), 
	
	usa.lastSessionID,	       
	usa.lastSessionDateTime,
	DATE_FORMAT(usa.lastSessionDateTime, '%Y'), 
	DATE_FORMAT(usa.lastSessionDateTime, '%Y*%m(%b)'),
	SMARTSHEET_WEEK(usa.lastSessionDateTime), 
	CONCAT(DATE_FORMAT(usa.lastSessionDateTime , '%Y'), "*", 
	       LPAD(MONTH(usa.lastSessionDateTime),2,"0"), "*", 
	       LPAD(DAYOFMONTH(usa.lastSessionDateTime),2,"0")), 
	       	
	DATEDIFF(CURRENT_DATE(), usa.firstSessionDateTime),
	DATEDIFF(CURRENT_DATE(), usa.lastSessionDateTime),
	DATEDIFF(usa.lastSessionDateTime, usa.firstSessionDateTime),
	
	usa.sessionCount, 
	usa.sessionCount / (DATEDIFF(v_destMaxModTime, usa.lastSessionDateTime) + 3),

	CASE usa.sessionCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 2 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 8 
		WHEN 1 THEN 1
		ELSE 0
	END

FROM arc_userSessionActivity usa
;

/* Update lastLoginUserDate for a payment profile - we use the user's last login for standard accounts and the last login for all users in an org */
UPDATE rpt_paymentProfile rp
  JOIN rpt_loginCountTotal lc ON rp.sourceUserID = lc.userID
SET lastUserLoginDate = lc.lastLogin WHERE rp.accountType != 3
;

UPDATE rpt_paymentProfile rp
SET rp.lastUserLoginDate =
 (SELECT MAX(lc.lastLogin) 
	FROM rpt_loginCountTotal lc
	  JOIN rpt_paymentProfileContact cp ON lc.userID = cp.userID
	WHERE rp.paymentProfileID = cp.parentPaymentProfileID)
WHERE rp.accountType = 3
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;