# Insight
# Stored Procedure for ETL from ss_log_02
# Moves new rows from clientEvent table to arc_clinetEvent.
# Does not consider updates or deletes on ss_log_02.clientEvent.
# Can be executed at any time.  It is idempotent.  accessible
# Approx 10 seconds when run hourly.  Approx 5 minutes when run daily.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure etl_ClientEvent()' as '' from dual;
delimiter //

drop procedure if exists etl_clientEvent//
create procedure etl_clientEvent(a_parentProcessId int
								,a_levelCtrlNum tinyint)
begin

declare v_processId int;
call utl_logProcessStart( 'etl_clientEvent',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set transaction isolation level read committed;

INSERT arc_clientEvent 
SELECT * 
FROM ss_log_02.clientEvent 
WHERE clientEventID > (SELECT MAX(clientEventID) FROM arc_clientEvent)
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;


