# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the currencyExchange table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_currencyExchange()' as '' from dual;

delimiter //

drop procedure if exists etl_currencyExchange//

create procedure etl_currencyExchange(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

declare v_processId int;
call utl_logProcessStart( 'etl_currencyExchange',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

DROP TABLE currencyExchange;
DROP TABLE hist_currencyExchange; 
CREATE TABLE IF NOT EXISTS currencyExchange LIKE ss_core_02.currencyExchange;
CREATE TABLE IF NOT EXISTS hist_currencyExchange LIKE ss_core_02.hist_currencyExchange;
INSERT INTO currencyExchange SELECT * FROM ss_core_02.currencyExchange;
INSERT INTO hist_currencyExchange SELECT * FROM ss_core_02.hist_currencyExchange;

call utl_logProcessEnd(v_processId);

end//

delimiter ;