select now() from dual;
select LAST_ALTERED, ROUTINE_SCHEMA,ROUTINE_NAME,ROUTINE_TYPE
from information_schema.ROUTINES
where SPECIFIC_NAME like 'etl%';

