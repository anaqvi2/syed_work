# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure etl_gridAccessMap()' as '' from dual;
delimiter //

drop procedure if exists etl_gridAccessMap//

create procedure etl_gridAccessMap(a_parentProcessId int
						          ,a_levelCtrlNum tinyint)
begin

# Use this variable to determine the rows we havent moved from the source table yet.
declare v_destMaxGridId int default (select max(gridId) from gridAccessMap);
declare v_destMaxInsTime datetime default (select max(insertDateTime) from gridAccessMap where gridId = v_destMaxGridId);
declare v_destMaxModTime datetime default (select max(modifyDateTime) from gridAccessMap where gridId = v_destMaxGridId);

declare v_processId int;
call utl_logProcessStart( 'etl_gridAccessMap',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set transaction isolation level read committed;

replace into gridAccessMap
select g.*, 0 as deleteStatus
from ss_core_02.gridAccessMap g
where modifyDateTime >= v_destMaxModTime
	or insertDateTime >= v_destMaxInsTime;

-- Mark records as deleted that were removed in source table
-- We want to retain history on these
drop table if exists tmp_gamDeletes;
set transaction isolation level read committed;
create temporary table tmp_gamDeletes as
select mGAM.gridId, mGAM.userID       
from gridAccessMap mGAM
left outer join ss_core_02.gridAccessMap cGAM
     ON mGAM.gridID=cGAM.gridID
	AND mGAM.userID=cGAM.userID
where cGAM.gridID IS NULL
and deleteStatus !=1;

UPDATE gridAccessMap g
INNER JOIN tmp_gamDeletes tg
     ON g.gridID=tg.gridID
	AND g.userID=tg.userID
SET g.deleteStatus = 1;
drop table if exists tmp_gamDeletes;

call utl_logProcessEnd(v_processId);

end//

delimiter ;
