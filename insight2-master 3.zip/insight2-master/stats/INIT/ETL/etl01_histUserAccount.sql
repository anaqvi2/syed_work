# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the hist_userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_histUserAccount()' as '' from dual;

delimiter //

drop procedure if exists etl_histUserAccount//

create procedure etl_hist_UserAccount(a_parentProcessId int
                                     ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_hist_UserAccount',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxModTime = (SELECT max(modifyDateTime) FROM hist_userAccount);

INSERT hist_userAccount (
	userID, 
	firstName, 
	lastName, 
	nickName, 
	accountType, 
	emailAddress, 
	loginPassword, 
	locale, 
	timeZone, 
	newsFlags, 
	statusFlags, 
	insertByUserID, 
	insertDateTime, 
	modifyByUserID, 
	modifyDateTime, 
	sessionLogID,
	domain,
	hist_effectiveThruDateTime)
SELECT
	ua.userID, 
	ua.firstName, 
	ua.lastName, 
	ua.nickName, 
	ua.accountType, 
	ua.emailAddress, 
	ua.loginPassword, 
	ua.locale, 
	ua.timeZone, 
	ua.newsFlags, 
	ua.statusFlags, 
	ua.insertByUserID, 
	ua.insertDateTime, 
	ua.modifyByUserID, 
	ua.modifyDateTime, 
	ua.sessionLogID,
    SUBSTR(ua.emailAddress, INSTR(ua.emailAddress,'@') + 1),
    ua.hist_effectiveThruDateTime
FROM ss_core_02.hist_userAccount ua 
LEFT JOIN hist_userAccount hua on
	ua.userID=hua.userID AND	
	ua.modifyDateTime=hua.modifyDateTime
WHERE hua.userID IS NULL
AND ua.modifyDateTime >= v_destMaxModTime;

truncate TABLE stg_histuserAccount_update;

INSERT INTO stg_histuserAccount_update
SELECT userID, modifyDateTime, hist_effectiveThruDateTime
FROM ss_core_02.hist_userAccount
WHERE modifyDateTime >= v_destMaxModTime;

CREATE INDEX ix_userID ON stg_histuserAccount_update (userID);
CREATE INDEX ix_modifyDateTime ON stg_histuserAccount_update (modifyDateTime);

-- Update hist_effectiveThruDateTime of previous paymentProfileIDs
UPDATE hist_userAccount hpp
JOIN ss_core_02.hist_userAccount coreHPP ON hpp.userID = coreHPP.userID
	AND hpp.modifyDateTime = coreHPP.modifyDateTime
JOIN rpt_main_02.stg_histuserAccount_update stg ON coreHPP.userID = stg.userID 
	AND DATE_ADD(stg.modifyDateTime, INTERVAL -1 SECOND) = coreHPP.hist_effectiveThruDateTime
	AND DATE_ADD(stg.modifyDateTime, INTERVAL -1 SECOND) != stg.hist_effectiveThruDateTime /*Do not update with new hist_effectiveThruDateTime in case of Negative 1 second effective time*/
SET hpp.hist_effectiveThruDateTime = coreHPP.hist_effectiveThruDateTime
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;