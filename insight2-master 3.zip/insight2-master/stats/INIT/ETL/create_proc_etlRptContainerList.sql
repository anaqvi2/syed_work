# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.

select '### Compiling procedure etl_RptContainerList()' as '' from dual;

delimiter //

drop procedure if exists etl_rptContainerList//

create procedure etl_rptContainerList(a_parentProcessId int
								,a_levelCtrlNum tinyint)
SQL security invoker
begin

declare v_processId int;
call utl_logProcessStart( 'etl_rptContainerList',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

drop table if exists tmpContainerMods;
create temporary table tmpContainerMods as
select c.containerID, c.name, c.displayObjectID, c.sourceID, c.insertDateTime, c.modifyDateTime
from container c
WHERE c.containerType = 2 
  AND (c.templateStatus IS NULL OR c.templateStatus = 0) 
  AND c.deleteStatus = 0
  AND c.modifyDateTime > (select containerModifyDateTime from rpt_containerList where containerId = (select max(containerId) from rpt_containerList));

create index idx_tempContainerMods_disObj on tmpContainerMods(displayObjectID);
create index idx_tempContainerMods_src on tmpContainerMods(sourceId);
create index idx_tempContainerMods_name on tmpContainerMods(name);


drop table if exists tmpGrid;
create temporary table tmpGrid as
select g.gridId, g.dataTimestamp, g.deleteStatus 
from grid g
join tmpContainerMods cm on g.gridId = cm.displayObjectId
where deleteStatus = 0;
create index idx_tmpGrid on tmpGrid(gridId);

drop table if exists tmpGridAccessMap;
create temporary table tmpGridAccessMap as
select gam.gridId, gam.dataTimestamp, gam.access, gam.userID
from gridAccessMap gam
join tmpContainerMods cm on gam.gridId= cm.displayObjectID;

create index idx_tmpGridAccessMap on tmpGridAccessMap(gridId);

drop table if exists tmpGridAccessMapCounts;
create temporary table tmpGridAccessMapCounts as
SELECT gamm.gridId, COUNT(*) accessCount
   FROM tmpGridAccessMap gamm
   WHERE gamm.access < 50
   group by gamm.gridId;
create index idx_tmpGridAccessMapCounts on tmpGridAccessMapCounts(gridId);

replace into rpt_containerList(
	containerID, 
	containerName, 
	gridID, 
	gridDataTimestamp, 
    ownerUserId,
    shareCount,
	loadCount,
	sourceContainerID,
    sourceContainerName,
    containerInsertDateTime,
    containerModifyDateTime
)
select cm.containerID
	  ,cm.name
      ,g.gridID
      ,g.dataTimestamp
	  ,gam.userID as ownerUserId
      ,gamc.accessCount
	  ,NULL as loadCount
      ,cm.sourceID
      ,case when c.name LIKE 'nd_%' then l.display else c.name end
      ,cm.insertDateTime
      ,cm.modifyDateTime
from tmpContainerMods cm
JOIN tmpGrid g ON cm.displayObjectID = g.gridID
JOIN container c ON cm.sourceId = c.containerId
JOIN tmpGridAccessMap gam ON cm.displayObjectID = gam.gridID
left outer JOIN ss_core_02.languageElement l ON c.name = l.languageElementKey
join tmpGridAccessMapCounts gamc on cm.displayObjectID = gamc.gridId
WHERE gam.access = 50
AND l.locale = 'en_US';

drop table if exists tmpContainerMods;
drop table if exists tmpGrid;
drop table if exists tmpGridAccessMap;
drop table if exists tmpGridAccessMapCounts;

call utl_logProcessEnd(v_processId);

end//

delimiter ;
