# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_userIPLocation table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_userIPLocation()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_userIPLocation//

create procedure etl_rpt_userIPLocation(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_rpt_userIPLocation',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT MAX(userID) FROM rpt_userIPLocation);

INSERT INTO rpt_userIPLocation (userID)
SELECT DISTINCT ua.userID
FROM userAccount ua
LEFT OUTER JOIN rpt_userIPLocation ins ON ua.userID=ins.userID
WHERE ins.userID IS NULL
AND ua.userID >= @maxUserID
ORDER BY userID
;

-- Add userIP addresses from signup source
UPDATE rpt_userIPLocation uic
JOIN rpt_signupSource ss ON uic.userID=ss.userID
SET 
	uic.ipType = 'Signup Source',
	uic.ipNumber  = ss.ipAddress,
	uic.ipCountry = ss.IPCountry,
	uic.ipRegion = ss.IPRegion,
	uic.ipCity = ss.IPCity
WHERE uic.ipCountry IS NULL
;

-- Add userIP addresses from first sessions
UPDATE rpt_userIPLocation uic2
JOIN
	(
		SELECT 
		lct.userID, lct.firstSessionLogID, lct.firstLogin, sl.sourceIP, ref.countryName, ref.regionName, ref.city
		FROM rpt_loginCountTotal lct
		JOIN rpt_userIPLocation uic ON lct.userID=uic.userID
		LEFT JOIN arc_sessionLog sl ON lct.firstSessionLogID=sl.sessionLogID
		LEFT JOIN ref_ipAddressInfo ref ON sl.sourceIP=ref.ipAddress
		WHERE uic.ipCountry IS NULL
		AND sl.sourceIP IS NOT NULL
	) ip 
ON uic2.userID=ip.userID
SET 
	uic2.ipType = 'First Session',
	uic2.ipNumber = ip.sourceIP,
	uic2.ipCountry = ip.countryName,
	uic2.ipRegion = ip.regionName,
	uic2.ipCity = ip.city
WHERE uic2.ipCountry IS NULL
;

-- Add userIP addresses from last sessions
DROP TABLE IF EXISTS stg_users_no_ip_country;

CREATE TABLE stg_users_no_ip_country LIKE rpt_userIPLocation;

INSERT INTO stg_users_no_ip_country
SELECT *
FROM rpt_userIPLocation
WHERE ipCountry IS NULL
;

-- ALTER TABLE stg_users_no_ip_country ADD PRIMARY KEY (userID);

DROP TABLE IF EXISTS stg_users_noIP_lastSession;

CREATE TABLE stg_users_noIP_lastSession (userID bigint, maxSessionLogID bigint);

INSERT INTO stg_users_noIP_lastSession (userID, maxSessionLogID)
SELECT np.userID, MAX(sessionLogID) AS maxSessionLogID
FROM stg_users_no_ip_country np
JOIN arc_sessionLog sl ON np.userID=sl.userID
GROUP BY 1
;

ALTER TABLE stg_users_noIP_lastSession ADD PRIMARY KEY (userID);

UPDATE rpt_userIPLocation uic2
JOIN
	(
		SELECT ms.userID, ms.maxSessionLogID, asl.sourceIP, ref.countryName, ref.regionName, ref.city
		FROM stg_users_noIP_lastSession ms
		LEFT JOIN arc_sessionLog asl ON asl.userID=ms.userID AND asl.sessionLogID=ms.maxSessionLogID
		LEFT JOIN ref_ipAddressInfo ref ON asl.sourceIP=ref.ipAddress
	) ip 
ON uic2.userID=ip.userID
SET 
	uic2.ipType = 'Last Session',
	uic2.ipNumber = ip.sourceIP,
	uic2.ipCountry = ip.countryName,
	uic2.ipRegion = ip.regionName,
	uic2.ipCity = ip.city
WHERE uic2.ipCountry IS NULL
;

-- Remove users with no IP type or no IP number
DELETE FROM rpt_userIPLocation WHERE ipType IS NULL;

DELETE FROM rpt_userIPLocation WHERE ipNumber IS NULL;


/*Create Table of NULL IPCountry users*/
CREATE TABLE stg_userIPLocationUpdate (userID bigint);
INSERT INTO stg_userIPLocationUpdate (userID)
SELECT userAccount.userID
FROM userAccount
LEFT OUTER JOIN rpt_userIPLocation ON userAccount.userID = rpt_userIPLocation.userID
WHERE ipNumber IS NULL; 

/*Insert those with a signup*/
INSERT rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
rpt_signupSource.userID, 
'Signup Source',
ipAddress, 
IPCountry, 
IPRegion, 
IPCity
FROM rpt_signupSource
JOIN stg_userIPLocationUpdate ON rpt_signupSource.userID = stg_userIPLocationUpdate.userID
WHERE ipCountry IS NOT NULL;

/*Insert those with a firstSession*/
INSERT rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
stg_userIPLocationUpdate.userID, 'First Session', sl.sourceIP, ref.countryName, ref.regionName, ref.city
FROM rpt_loginCountTotal lct 
JOIN stg_userIPLocationUpdate ON lct.userID = stg_userIPLocationUpdate.userID
LEFT OUTER JOIN arc_sessionLog sl ON lct.firstSessionLogID = sl.sessionLogID
LEFT OUTER JOIN ref_ipAddressInfo ref ON sl.sourceIP = ref.ipAddress
LEFT OUTER JOIN rpt_userIPLocation uic ON stg_userIPLocationUpdate.userID = uic.userID
WHERE uic.ipNumber IS NULL
AND sl.sourceIP IS NOT NULL
AND ref.countryName IS NOT NULL;

/*Insert those with a lastSession*/
INSERT rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
stg_userIPLocationUpdate.userID, 'Last Session', sl.sourceIP, ref.countryName, ref.regionName, ref.city
FROM rpt_loginCountTotal lct 
JOIN stg_userIPLocationUpdate ON lct.userID = stg_userIPLocationUpdate.userID
LEFT OUTER JOIN arc_sessionLog sl ON lct.lastSessionLogID = sl.sessionLogID
LEFT OUTER JOIN ref_ipAddressInfo ref ON sl.sourceIP = ref.ipAddress
LEFT OUTER JOIN rpt_userIPLocation uic ON stg_userIPLocationUpdate.userID = uic.userID
WHERE uic.ipNumber IS NULL
AND sl.sourceIP IS NOT NULL
AND ref.countryName IS NOT NULL;

DROP TABLE stg_userIPLocationUpdate;

call utl_logProcessEnd(v_processId);

end//

delimiter ;