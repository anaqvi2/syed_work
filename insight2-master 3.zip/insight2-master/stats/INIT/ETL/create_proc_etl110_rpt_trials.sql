# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_trials table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_trials()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_trials//

create procedure etl_rpt_trials(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_rpt_trials',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxModTime = (SELECT MAX(trialDateTime) FROM rpt_trials);

SET AUTOCOMMIT = 0;
INSERT rpt_trials(
	paymentProfileID,
	trialType,
	userID, 
	trialDateTime,
	trialEndDateTime,
	firstTrial,
	trialSessionID)

SELECT  
	hpp.paymentProfileID,
	hpp.accountType,
	ppc.userID,
	hpp.modifyDateTime,
	MIN(hppNext.modifyDateTime),
	CASE WHEN hppOld.productID IS NULL THEN 1 ELSE 0 END, /* First time is a trial in which the user did not previously have a payment Profile*/
	hpp.sessionLogID
	
FROM hist_paymentProfile hpp
LEFT OUTER JOIN hist_paymentProfile hppOld ON hpp.paymentProfileID = hppOld.paymentProfileID 
	AND hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND    /*Compare to previous hist_paymentProfile entry */
LEFT OUTER JOIN hist_paymentProfile hppNext ON hppNext.paymentProfileID = hpp.paymentProfileID 
	AND hppNext.modifyDateTime > hpp.modifyDateTime AND hppNext.productID != 1 /*Compare to next non-trial hist_paymentProfile entry */
JOIN rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hpp.paymentProfileID

WHERE hpp.productID = 1
AND (hppOld.productID != 1 OR hppOld.productID IS NULL) /*Eliminates instance of trials being extended, previous hist_paymentProfile was also a trial  */
AND hpp.modifyDateTime > v_destMaxModTime 

GROUP BY 1,4  /*Group to avoid the bug where a PP is not properly updated in hist_paymentProfile (example: PPid: 3054062)*/

ORDER BY hpp.modifyDateTime
;
COMMIT;

UPDATE rpt_trials
	SET trialEndDateTime = (SELECT MIN(hppNext.modifyDateTime) FROM hist_paymentProfile hppNext 
	WHERE hppNext.paymentProfileID = rpt_trials.paymentProfileID AND hppNext.modifyDateTime > rpt_trials.trialDateTime AND hppNext.productID != 1)
	WHERE trialEndDateTime IS NULL
;
COMMIT;

UPDATE rpt_trials
	SET gettingStartedOpen = (SELECT MIN(arc_clientEvent.eventDateTime) FROM arc_clientEvent 
	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 1)
	WHERE gettingStartedOpen IS NULL AND trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND trialSessionID != 0
;
COMMIT;

UPDATE rpt_trials
	SET gettingStartedClose = (SELECT MIN(arc_clientEvent.eventDateTime) FROM arc_clientEvent 
	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 2)
	WHERE gettingStartedClose IS NULL AND trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND trialSessionID != 0
;
COMMIT;
	
UPDATE rpt_trials
SET rpt_trials.restartFirstDayLogCount  =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	WHERE r.insertByUserID = rpt_trials.userID AND r.logDate <= DATE_ADD(rpt_trials.trialDateTime, INTERVAL 12 HOUR))
WHERE restartFirstDayLogCount IS NULL AND trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND firstTrial = 0
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;