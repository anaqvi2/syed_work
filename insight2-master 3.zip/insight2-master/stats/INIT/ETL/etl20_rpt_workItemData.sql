# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_workItemData table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_workItemData()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_workItemData//

create procedure etl_rpt_workItemData(a_parentProcessId int
                                ,a_levelCtrlNum tinyint
								,a_newMaxworkItemId int
								,a_newMaxworkItemGroupId int
								,a_newMaxworkItemResultId int)
begin

# Variable Declaration

declare v_processId int;
#declare v_destMaxId int; 

declare v_workItemGroupMaxInsTime datetime; 
declare v_workItemGroupMaxModTime datetime; 

call utl_logProcessStart('etl_rpt_workItemData',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

#set v_destMaxId = (select max(rpt_workItemDataId) from rpt_workItemData);
set v_workItemGroupMaxInsTime = (SELECT max(insertDateTime) FROM workItemGroup);
set v_workItemGroupMaxModTime = (SELECT max(modifyDateTime) FROM workItemGroup);

DROP TABLE IF EXISTS rpt_workItemResultSummary;
CREATE TABLE IF NOT EXISTS rpt_workItemResultSummary(
	workItemID BIGINT, 
	maxAutoApproveDateTime DATETIME, 
	AnswerCount INT, 
	ManualApproveCount INT, 
	RejectCount INT, 
	TotalBonus INT)
;
	
INSERT rpt_workItemResultSummary(
	workItemID, 
	maxAutoApproveDateTime, 
	AnswerCount, 
	ManualApproveCount, 
	RejectCount, 
	TotalBonus)
SELECT  r.workItemID, 
	MAX(r.autoApproveDateTime) AS MaxAutoApprove,
	COUNT(*) AS AnswerCount,
	SUM(CASE r.approveRejectStatus
		WHEN 3 THEN 1
		ELSE 0 END) AS ManualApproveCount,
	SUM(CASE r.approveRejectStatus
		WHEN 5 THEN 1
		ELSE 0 END) AS RejectCount,
	SUM(IFNULL(r.approveBonusAmount,0))
FROM ss_core_02.workItemResult r
WHERE workItemResultID <= a_newMaxworkItemResultId
GROUP BY 1
;

CREATE INDEX rpt_workItemResultSummary_idx1 ON rpt_workItemResultSummary (workItemID);

DROP TABLE IF EXISTS rpt_workItemSummary;
CREATE TABLE IF NOT EXISTS rpt_workItemSummary(
	workItemGroupID BIGINT, 
	PendingCount INT, 
	ErrorCount INT, 
	CompleteCount INT, 
	AssignmentCount INT, 
	AssignmentCompleteCount INT, 
	AnswerCount INT, 
	ManualApproveCount INT, 
	RejectCount INT, 
	TotalBonus INT, 
	MaxAutoApproveDateTime DATETIME);

INSERT rpt_workItemSummary(
	workItemGroupID, 
	PendingCount, 
	ErrorCount, 
	CompleteCount, 
	AssignmentCount, 
	AssignmentCompleteCount, 
	AnswerCount, 
	ManualApproveCount, 
	RejectCount, 
	TotalBonus, 
	MaxAutoApproveDateTime)
SELECT  w.workItemGroupID, 
	SUM(CASE w.processingStatus 
		WHEN 0 THEN 1
		WHEN 1 THEN 1
		WHEN 10 THEN 1
		WHEN 11 THEN 1
		ELSE 0 END) AS PendingCount,
	SUM(CASE w.processingStatus 
		WHEN 2 THEN 1
		WHEN 12 THEN 1
		ELSE 0 END) AS ErrorCount,
	SUM(CASE w.processingStatus 
		WHEN 20 THEN 1
		WHEN 127 THEN 1
		ELSE 0 END) AS CompleteCount,
	SUM(w.assignmentCount) AS AssignmentCount, 
	SUM(IFNULL(w.assignmentCompleteCount,0)) AS AssignmentCompleteCount,
	SUM(IFNULL(r.answerCount,0)) AS AnswerCount,
	SUM(IFNULL(r.manualApproveCount,0)) AS ManualApproveCount,
	SUM(IFNULL(r.rejectCount,0)) AS RejectCount,
	SUM(IFNULL(r.TotalBonus,0)) AS TotalBonus,
	MAX(r.maxAutoApproveDateTime) AS MaxAutoApproveDateTime
FROM ss_core_02.workItem w 
LEFT OUTER JOIN rpt_workItemResultSummary r ON w.workItemID = r.workItemID
WHERE w.workItemID <= a_newMaxworkItemId
GROUP BY 1
;

CREATE INDEX rpt_workItemSummary_idx1 ON rpt_workItemSummary (workItemGroupID);

DROP TABLE IF EXISTS rpt_workItemGroupInfo;
CREATE TABLE IF NOT EXISTS rpt_workItemGroupInfo(
	workItemGroupID BIGINT, 
	gridID BIGINT, 
	containerID BIGINT, 
	containerName VARCHAR(50), 
	userID BIGINT, 
	paymentProfileID BIGINT, 
	billToRecurringBillingID VARCHAR(20), 
	userEmailAddress VARCHAR(100))
;


/*
 * Need to be careful if the gridRow has been deleted so roll up the gridID first
 */
INSERT rpt_workItemGroupInfo(workItemGroupID, gridID, userID)
SELECT  g.workItemGroupID,
        MAX(IFNULL(i.displayObjectID,0)),
        MAX(IFNULL(g.insertByUserID,0))
FROM ss_core_02.workItemGroup g
JOIN ss_core_02.workItem i ON g.workItemGroupID = i.workItemGroupID 
     and i.workItemID <= a_newMaxworkItemId
WHERE g.workItemGroupID <= a_newMaxworkItemGroupId
GROUP BY 1
;
	
CREATE INDEX rpt_workItemGroupInfo_idx1 ON rpt_workItemGroupInfo (workItemGroupID);

UPDATE rpt_workItemGroupInfo r 
JOIN container c ON r.gridID = c.displayObjectID
SET    r.containerID = c.containerID,
       r.containerName = c.name
WHERE  r.gridID > 0
;

UPDATE rpt_workItemGroupInfo r 
JOIN userAccount u ON r.userID = u.userID
SET    r.userEmailAddress = u.emailAddress
;

UPDATE rpt_workItemGroupInfo r 
JOIN rpt_paymentProfile p ON r.userID = p.mainContactUserID AND p.accountType != 3
SET    r.paymentProfileID = p.paymentProfileID,
       r.billToRecurringBillingID = p.billToRecurringBillingID
;

CREATE TABLE IF NOT EXISTS workItemGroup
(
	workItemGroupID BIGINT,
	externalID VARCHAR(50),
	displayObjectID BIGINT,
	title VARCHAR(100),
	keywords VARCHAR(100),
	description VARCHAR(4000),
	itemCount INT,
	assignmentCount INT,
	assignmentCompleteCount INT,
	assignmentApprovedCount INT,
	reconcileDateTime DATETIME,
	totalBonusCents INT,
	parm1Int INT,
	parm2Int INT,
	parm3Int INT,
	parm4Int INT,
	parm1Numeric DECIMAL,
	parm2Numeric DECIMAL,
	insertDateTime DATETIME,
	insertByUserID BIGINT,
	modifyDateTime DATETIME,
	modifyByUserID BIGINT,
	sessionLogID BIGINT,
	dataTimestamp INT,
	PRIMARY KEY (workItemGroupID),
	KEY ix_displayObjectID (displayObjectID),
	KEY ix_insertByUserID (insertByUserID)
)
;

CREATE TABLE IF NOT EXISTS stg_workItemGroup_data LIKE workItemGroup;
TRUNCATE TABLE stg_workItemGroup_data;

INSERT INTO stg_workItemGroup_data
(
	workItemGroupID,
	externalID,
	displayObjectID,
	title,
	keywords,
	description,
	itemCount,
	assignmentCount,
	assignmentCompleteCount,
	assignmentApprovedCount,
	reconcileDateTime,
	totalBonusCents,
	parm1Int,
	parm2Int,
	parm3Int,
	parm4Int,
	parm1Numeric,
	parm2Numeric,
	insertDateTime,
	insertByUserID,
	modifyDateTime,
	modifyByUserID,
	sessionLogID,
	dataTimestamp
)
SELECT
	wig.workItemGroupID,
	wig.externalID,
	wig.displayObjectID,
	wig.title,
	wig.keywords,
	wig.description,
	wig.itemCount,
	wig.assignmentCount,
	wig.assignmentCompleteCount,
	wig.assignmentApprovedCount,
	wig.reconcileDateTime,
	wig.totalBonusCents,
	wig.parm1Int,
	wig.parm2Int,
	wig.parm3Int,
	wig.parm4Int,
	wig.parm1Numeric,
	wig.parm2Numeric,
	wig.insertDateTime,
	wig.insertByUserID,
	wig.modifyDateTime,
	wig.modifyByUserID,
	wig.sessionLogID,
	wig.dataTimestamp
FROM ss_core_02.workItemGroup wig
LEFT OUTER JOIN workItemGroup ins ON wig.workItemGroupID=ins.workItemGroupID
WHERE ins.workItemGroupID IS NULL
AND wig.insertDateTime > v_workItemGroupMaxInsTime 
and wig.workItemGroupID <= a_newMaxworkItemGroupId
;

INSERT INTO workItemGroup
SELECT wig.*
FROM stg_workItemGroup_data wig
LEFT OUTER JOIN workItemGroup ins ON wig.workItemGroupID=ins.workItemGroupID
WHERE ins.workItemGroupID IS NULL
;

INSERT INTO stg_workItemGroup_data
(
	workItemGroupID,
	externalID,
	displayObjectID,
	title,
	keywords,
	description,
	itemCount,
	assignmentCount,
	assignmentCompleteCount,
	assignmentApprovedCount,
	reconcileDateTime,
	totalBonusCents,
	parm1Int,
	parm2Int,
	parm3Int,
	parm4Int,
	parm1Numeric,
	parm2Numeric,
	insertDateTime,
	insertByUserID,
	modifyDateTime,
	modifyByUserID,
	sessionLogID,
	dataTimestamp
)
SELECT
	wig.workItemGroupID,
	wig.externalID,
	wig.displayObjectID,
	wig.title,
	wig.keywords,
	wig.description,
	wig.itemCount,
	wig.assignmentCount,
	wig.assignmentCompleteCount,
	wig.assignmentApprovedCount,
	wig.reconcileDateTime,
	wig.totalBonusCents,
	wig.parm1Int,
	wig.parm2Int,
	wig.parm3Int,
	wig.parm4Int,
	wig.parm1Numeric,
	wig.parm2Numeric,
	wig.insertDateTime,
	wig.insertByUserID,
	wig.modifyDateTime,
	wig.modifyByUserID,
	wig.sessionLogID,
	wig.dataTimestamp
FROM ss_core_02.workItemGroup wig
LEFT OUTER JOIN stg_workItemGroup_data ins ON wig.workItemGroupID=ins.workItemGroupID
WHERE wig.modifyDateTime > v_workItemGroupMaxModTime 
and wig.workItemGroupID <= a_newMaxworkItemGroupId
AND ins.workItemGroupID IS NULL
;


UPDATE workItemGroup u
JOIN stg_workItemGroup_data wig ON u.workItemGroupID=wig.workItemGroupID
SET
	u.workItemGroupID=wig.workItemGroupID,
	u.externalID=wig.externalID,
	u.displayObjectID=wig.displayObjectID,
	u.title=wig.title,
	u.keywords=wig.keywords,
	u.description=wig.description,
	u.itemCount=wig.itemCount,
	u.assignmentCount=wig.assignmentCount,
	u.assignmentCompleteCount=wig.assignmentCompleteCount,
	u.assignmentApprovedCount=wig.assignmentApprovedCount,
	u.reconcileDateTime=wig.reconcileDateTime,
	u.totalBonusCents=wig.totalBonusCents,
	u.parm1Int=wig.parm1Int,
	u.parm2Int=wig.parm2Int,
	u.parm3Int=wig.parm3Int,
	u.parm4Int=wig.parm4Int,
	u.parm1Numeric=wig.parm1Numeric,
	u.parm2Numeric=wig.parm2Numeric,
	u.insertDateTime=wig.insertDateTime,
	u.insertByUserID=wig.insertByUserID,
	u.modifyDateTime=wig.modifyDateTime,
	u.modifyByUserID=wig.modifyByUserID,
	u.sessionLogID=wig.sessionLogID,
	u.dataTimestamp=wig.dataTimestamp
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;