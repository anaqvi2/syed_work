# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_clientLogCountsByUserArchived table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_clientLogCountsByUserArchived()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_clientLogCountsByUserArchived//

create procedure etl_rpt_clientLogCountsByUserArchived(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_rpt_clientLogCountsByUserArchived',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT MAX(clientEventID) FROM stg_dailyClientEvents);

CREATE TABLE IF NOT EXISTS stg_dailyClientEvents LIKE arc_clientEvent;

INSERT stg_dailyClientEvents
SELECT * FROM arc_clientEvent
WHERE clientEventID > v_destMaxId;

DROP TABLE if EXISTS stg_dailyClientEventRollup;
CREATE TABLE IF NOT EXISTS stg_dailyClientEventRollup (userID BIGINT, dailyClientEvents INT);

INSERT stg_dailyClientEventRollup SELECT arc_sessionLog.userID, COUNT(clientEventID) AS dailyClientEvents 
FROM stg_dailyClientEvents 
JOIN arc_sessionLog ON stg_dailyClientEvents.sessionlogID = arc_sessionLog.sessionLogID
GROUP BY arc_sessionLog.userID;

INSERT rpt_clientLogCountsByUserArchived (userID, lifetimeLogCount)
SELECT u.userID, 0 FROM userAccount u 
LEFT JOIN rpt_clientLogCountsByUserArchived r ON u.userID=r.userID
WHERE r.userID IS NULL;

UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN stg_dailyClientEventRollup ON clcua.userID = stg_dailyClientEventRollup.userID 
SET clcua.lifetimeLogCount = clcua.lifetimeLogCount + stg_dailyClientEventRollup.dailyClientEvents;

UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN userAccount u ON clcua.userID = u.userID
SET clcua.firstDayLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	WHERE r.insertByUserID = u.userID AND r.logDate <= DATE_ADD(u.insertDateTime, INTERVAL 12 HOUR)
	)
WHERE u.insertDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -12 DAY)
;
        
UPDATE rpt_clientLogCountsByUserArchived clcua
  JOIN rpt_paymentProfile p ON clcua.userID = p.ownerID AND p.accountType IN (1,2)
SET clcua.paymentProfileID = p.paymentProfileID
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;