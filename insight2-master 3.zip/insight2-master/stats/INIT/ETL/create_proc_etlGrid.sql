# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure etl_grid()' as '' from dual;

DELIMITER $$
CREATE DEFINER=`bwood`@`%` PROCEDURE `etl_grid`(a_parentProcessId int
						 ,a_levelCtrlNum tinyint)
begin

# Use this variable to determine the rows we havent moved from the source table yet.
declare v_destMaxGridId int default (select max(gridId) from grid);
declare v_destMaxModTime datetime default (select modifyDateTime from grid where gridId = v_destMaxGridId);
declare v_processId int;
call utl_logProcessStart( 'etl_grid',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);


set transaction isolation level read uncommitted;

replace into grid
select g.*
from ss_core_02.grid g
where modifyDateTime > v_destMaxModTime
	or gridId > v_destMaxGridId;

set transaction isolation level repeatable read;

call utl_logProcessEnd(v_processId);

end$$
DELIMITER ;
