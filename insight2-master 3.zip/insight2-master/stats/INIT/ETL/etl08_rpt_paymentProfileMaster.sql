# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_paymentProfileMaster table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_paymentProfileMaster()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_paymentProfileMaster//

create procedure etl_rpt_paymentProfileMaster(a_parentProcessId int
                                             ,a_levelCtrlNum tinyint
                                             ,a_newMaxPaymentProfileId int
                                             ,a_newMaxContainerId int
                                             ,a_newMaxBrandId int
                                             ,a_newMaxWorkspaceId int)
begin

# Variable Declaration

declare v_processId int;
call utl_logProcessStart('etl_rpt_paymentProfileMaster',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

DROP TABLE IF EXISTS rpt_paymentProfileMaster;
CREATE TABLE IF NOT EXISTS rpt_paymentProfileMaster
	(masterPaymentProfileID BIGINT, paymentProfileID BIGINT, profileCount INT, sheetCount INT, ganttCount INT, hasCustomBrand TINYINT);

/* Insert all child paymentProfiles */
INSERT rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT parentPaymentProfileID, paymentProfileID, 1
FROM ss_core_02.paymentProfile p 
WHERE p.parentPaymentProfileID IS NOT NULL and paymentProfileID <= a_newMaxPaymentProfileId
;

/* Insert put in the child profiles again so their counts will get rolled up, but don't incease the profileCount*/
INSERT rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT paymentProfileID, paymentProfileID, 0
FROM ss_core_02.paymentProfile p 
WHERE p.parentPaymentProfileID IS NOT NULL and paymentProfileID <= a_newMaxPaymentProfileId
;

/* Insert the parent profiles  */
/* Put in 0 for profile count so they are not counted in the profile count rollup  */
INSERT rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT DISTINCT paymentProfileID, paymentProfileID, 0 
FROM ss_core_02.paymentProfile p
WHERE p.parentPaymentProfileID IS NULL and paymentProfileID <= a_newMaxPaymentProfileId
AND productID IN (6,7,8); /* 7 team, 8 team plus, 6 enterprise */

/* Insert the individual (non-team) profiles as well */
INSERT rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT DISTINCT paymentProfileID, paymentProfileID, 1 
FROM ss_core_02.paymentProfile p
WHERE p.parentPaymentProfileID IS NULL and paymentProfileID <= a_newMaxPaymentProfileId
AND productID NOT IN (6,7,8); /* 7 team, 8 team plus, 6 enterprise */
	
CREATE INDEX idx_paymentProfileMasterPaymentProfileID ON rpt_paymentProfileMaster (paymentProfileID);

/* Update sheet counts on each record */
UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.sheetCount = 
	(SELECT COUNT(*) FROM rpt_main_02.container c 
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= a_newMaxContainerId)
; 

/* Update gantt counts on each record */
UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.ganttCount = 
	(SELECT COUNT(*) FROM rpt_main_02.container c 
	JOIN rpt_main_02.grid g ON gridID = c.displayObjectID AND g.ganttState = 1
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= a_newMaxContainerId)
; 

/* Update brand usage counts on each record */
UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.hasCustomBrand = 
	(SELECT MAX(b.isCustom) FROM rpt_main_02.container c 
	JOIN rpt_main_02.workspace w ON w.workspaceID = c.workspaceID
	JOIN rpt_main_02.brand b ON b.brandID = w.brandID
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= a_newMaxContainerId
	AND b.brandID <= a_newMaxBrandId
	AND w.workspaceID <= a_newMaxWorkspaceId
)
; 
call utl_logProcessEnd(v_processId);

end//

delimiter ;