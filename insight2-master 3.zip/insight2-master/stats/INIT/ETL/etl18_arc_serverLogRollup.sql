# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_serverLogRollup table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_serverLogRollup()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_serverLogRollup//

create procedure etl_arc_serverLogRollup(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxLogDate datetime; 
call utl_logProcessStart('etl_arc_serverLogRollup',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxLogDate = (SELECT MAX(logDate) FROM arc_serverLogRollup);

/******* roll up the server log data  - start *******/
INSERT arc_serverLogRollup(insertByUserID, actionID, logDate, logCount, totalRequestDuration)
select r.insertByUserID, 
        l.actionID,
        date(r.insertDateTime),
        count(*),
        sum(requestDuration)
from ss_log_02.requestLog r 
JOIN arc_serverActionLookup l ON r.urlActionID = l.urlActionID 
	AND r.formName = l.formName 
	AND r.formAction = l.formAction
where r.insertDateTime >= v_destMaxLogDate
  #and r.insertDateTime <= CONCAT(CURRENT_DATE(), ' 00:15:00')  BMW: unclear how this is relevant: note that curdate+15min evals to 12:15 AM every day.  I don't believe thats the desired effect.
group by 1,2,3
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;arc_serverLogRollup