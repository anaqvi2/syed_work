# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_sessionLog table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_sessionLog()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_sessionLog//

create procedure etl_rpt_sessionLog(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_rpt_sessionLog',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

/* find starting point for new users */
set v_destMaxId = (SELECT IFNULL(MAX(sessionLogID),0) FROM rpt_main_02.rpt_sessionLog);

INSERT rpt_sessionLog(
	sessionLogID, 
	userID, 
	emailAddress, 
	loginType, 
	loginAuthResult, 
	sourceIP, 
	insertDateTime, 
	signoutDateTime, 
	insertDateTimePT, 
	signoutDateTimePT, 
	sessionLength, 
	sessionActionCount, 
	sessionErrorCount, 
	browser, 
	browserBucket, 
	operatingSystem, 
	device, 
	userAgent)
SELECT sessionLog.sessionLogID,
	sessionLog.userID,
	sessionLog.emailAddress,
	SMARTSHEET_LOGINTYPENAME(sessionLog.loginType) AS "loginType",
	SMARTSHEET_AUTHRESULT(sessionLog.loginAuthResult) AS "loginAuthResult",
	sessionLog.sourceIP,
	sessionLog.insertDateTime,
	sessionLog.signoutDateTime,

	ADDTIME(sessionLog.insertDateTime, '-8:00:00'),
	ADDTIME(sessionLog.signOutDateTime, '-8:00:00'),
	CASE sessionLog.signOutDateTime IS NULL
		WHEN 0 THEN SEC_TO_TIME(UNIX_TIMESTAMP(sessionLog.signOutDateTime) - UNIX_TIMESTAMP(sessionLog.insertDateTime))
		ELSE NULL
	END,
	0, /*(select count(*) from ss_log_02.requestLog rl where formAction = 'gl' and rl.sessionLogID = sessionLog.sessionLogID), */
	0, /*(select count(*) from ss_log_02.requestLog rl where formAction = 'gl' and rl.sessionLogID = sessionLog.sessionLogID
														and rl.parm3 like 'js_stack_trace%'),  */
  SMARTSHEET_BROWSERNAME(sessionLog.userAgent) AS "Browser",
  SMARTSHEET_BROWSERBUCKET(sessionLog.userAgent) AS "Browser Bucket",
  SMARTSHEET_BROWSEROS(sessionLog.userAgent) AS "Operating System",
  SMARTSHEET_BROWSERDEVICE(sessionLog.userAgent) AS "Device",
	userAgent
        
FROM arc_sessionLog sessionLog
WHERE sessionLogID > v_destMaxId
;
call utl_logProcessEnd(v_processId);

end//

delimiter ;