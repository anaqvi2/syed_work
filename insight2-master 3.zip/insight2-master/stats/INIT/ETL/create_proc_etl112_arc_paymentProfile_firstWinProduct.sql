# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_paymentProfile_firstWinProduct table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_paymentProfile_firstWinProduct()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_paymentProfile_firstWinProduct//

create procedure etl_arc_paymentProfile_firstWinProduct(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
call utl_logProcessStart('etl_arc_paymentProfile_firstWinProduct',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

drop table if exists arc_paymentProfile_firstWinProduct;

create table if not exists arc_paymentProfile_firstWinProduct
(
	paymentProfileID bigint,
	productID int,
	paymentTerm int,
	paymentType int,
	planRate_USD decimal (38,10),
	PRIMARY KEY (paymentProfileID)
)
;

drop table if exists stg_minWinProduct;
create table if not exists stg_minWinProduct
(
	paymentProfileID bigint,
	sourceUserID bigint,
	minModifyDateTime datetime,
	PRIMARY KEY (paymentProfileID),
		KEY ix_sourceUser (sourceUserID),
        KEY ix_mdt (minModifyDateTime)
)
;

insert into stg_minWinProduct (paymentProfileId, sourceUserID, minModifyDateTime)
select hpp.paymentProfileID, pp.sourceUserID, min(hpp.modifyDateTime) as minModifyDateTime
from hist_paymentProfile hpp
left join rpt_paymentProfile pp on hpp.paymentProfileID=pp.paymentProfileID
where hpp.productID >=3
and hpp.planRate > 0
group by 1,2
;

update stg_minWinProduct stg
join
(
	select sourceUserID, min(minModifyDateTime) as minModifyDateTime
	from stg_minWinProduct m
	group by sourceUserID
) s
on stg.sourceUserID=s.sourceUserID
set stg.minModifyDateTime = s.minModifyDateTime
;

insert ignore arc_paymentProfile_firstWinProduct
select hpp.paymentProfileID, hpp.productID, hpp.paymentTerm, hpp.paymentType, hpp.planRate_USD
from hist_paymentProfile hpp
join stg_minWinProduct mwp on hpp.paymentProfileID=mwp.paymentProfileID 
	and hpp.modifyDateTime=mwp.minModifyDateTime
where hpp.productID >= 3
and hpp.planRate > 0
and hist_effectiveThruDateTime <= '9999-12-31 23:59:59'
;

drop table if exists stg_minWinProduct;


call utl_logProcessEnd(v_processId);

end//

delimiter ;