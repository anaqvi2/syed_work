#!/usr/bin/ruby
require 'rubygems' 
require 'graphviz'
require 'mysql2'

# initialize new Graphviz graph
g = GraphViz::new( "structs", "type" => "graph" )
g[:rankdir] = "LR"

# set global node options
g.node[:color]    = "#ddaa66"
g.node[:style]    = "filled"
g.node[:shape]    = "box"
g.node[:penwidth] = "1"
g.node[:fontname] = "Trebuchet MS"
g.node[:fontsize] = "8"
g.node[:fillcolor]= "#ffeecc"
g.node[:fontcolor]= "#775500"
g.node[:margin]   = "0.0"

# set global edge options
g.edge[:color]    = "#999999"
g.edge[:weight]   = "1"
g.edge[:fontsize] = "6"
g.edge[:fontcolor]= "#444444"
g.edge[:fontname] = "Verdana"
g.edge[:dir]      = "forward"
g.edge[:arrowsize]= "0.5"

thread = Array.new
node = Array.new

begin
db = Mysql2::Client.new(:host => 'localhost', :username => '', :password => '', :database => 'test',:flags => Mysql2::Client::MULTI_STATEMENTS)

  db.query("SELECT distinct concat(sourceDB,'.',sourceTable) src, concat(destDb,'.',destTable) dest,storedProcedure sp FROM etl_dbThread limit 500").each do |row|

   g.add_nodes(row['src'])
   g.add_nodes(row['dest'])
   g.add_edges(row['src'], row['dest'])
   end

g.output( :png => "insightETL.png" )

rescue Mysql2::Error => e
    puts e.errno
    puts e.error


end
