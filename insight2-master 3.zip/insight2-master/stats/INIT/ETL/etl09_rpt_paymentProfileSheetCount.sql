# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_paymentProfileSheetCount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_paymentProfileSheetCount()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_paymentProfileSheetCount//

create procedure etl_rpt_paymentProfileSheetCount(a_parentProcessId int
                                                 ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
declare v_processId int;
call utl_logProcessStart('etl_rpt_paymentProfileSheetCount',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

/* Sum the sheet counts */
DROP TABLE IF EXISTS rpt_paymentProfileSheetCount;
CREATE TABLE IF NOT EXISTS rpt_paymentProfileSheetCount
(paymentProfileID BIGINT, sheetCount INT, ganttCount INT, profileCount INT, hasCustomBrand TINYINT, PRIMARY KEY(paymentProfileID))
;

INSERT rpt_paymentProfileSheetCount (paymentProfileID, sheetCount, ganttCount, profileCount, hasCustomBrand)
SELECT masterPaymentProfileID, SUM(sheetCount), SUM(ganttCount), SUM(profileCount), MAX(hasCustomBrand)
FROM rpt_paymentProfileMaster 
GROUP BY 1
;


call utl_logProcessEnd(v_processId);

end//

delimiter ;