# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_requestLogRESTSessions()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_requestLogRESTSessions//

create procedure etl_arc_requestLogRESTSessions(a_parentProcessId int
                                               ,a_levelCtrlNum tinyint
												)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_arc_requestLogRESTSessions',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT MAX(requestLogID) FROM rpt_main_02.arc_requestLogRESTSessions);

INSERT arc_requestLogRESTSessions
SELECT * 
FROM ss_log_02.requestLog
WHERE sessionType = 9 
AND requestLogID > v_destMaxId
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;