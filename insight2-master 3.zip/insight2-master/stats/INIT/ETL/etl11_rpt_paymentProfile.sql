# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_paymentProfile table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_paymentProfile()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_paymentProfile//

create procedure etl_rpt_paymentProfile(a_parentProcessId int
                                       ,a_levelCtrlNum tinyint
                                       ,a_newMaxPaymentProfileId int
                                       ,a_newMaxOrganizationId int
									   ,a_newMaxUserId int)
begin

# Variable Declaration
call utl_logProcessStart('etl_rpt_paymentProfile',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

DROP TABLE IF EXISTS rpt_paymentProfile;

CREATE TABLE IF NOT EXISTS rpt_paymentProfile(
	paymentProfileID		BIGINT, 
	ownerID					BIGINT,
	sourceUserID			BIGINT NOT NULL,
	hasOrgProfile		    BIGINT,
	mainContactUserID		BIGINT,
	mainContactEmailAddress	NVARCHAR(100),
	mainContactDomain		NVARCHAR(100),
	companyName				NVARCHAR(100),
	lastUserLoginDate		DATETIME,
	accountType   			TINYINT NOT NULL,
	accountTypeFriendly 	NVARCHAR(50),
	paymentType      		NVARCHAR(50),
	paymentTypeFriendly		NVARCHAR(50),
	parentPaymentProfileID	BIGINT,

	paymentInsertDate		DATETIME,
	paymentInsertMonth		NVARCHAR(20),
	paymentInsertWeek		NVARCHAR(20),
	paymentInsertDay		INT,

	paymentStartDateRaw		DATETIME NOT NULL,
	paymentStartDateClean	DATETIME NOT NULL,
	paymentStartMonth 		NVARCHAR(20),
	paymentStartWeek		NVARCHAR(20),
	paymentStartDay			INT,

	productID				INT	NOT NULL,
	productName				NVARCHAR(50),
	userLimit				INT,
	productPriceID			INT,
	promoCode				NVARCHAR(50),
	bonusSheetCount			INT NOT NULL,
	bonusUserCount			INT NOT NULL,
	
	paymentTerm 			TINYINT NOT NULL,
	paymentTermFriendly 	NVARCHAR(50),
	paymentTotal			NUMERIC(38,10) NOT NULL,
	planRate_USD		NUMERIC(38,10),
	currencyCode 			VARCHAR(10),
	
	primaryContactPhone		NVARCHAR(20),
	referralEmailAddress	NVARCHAR(100),
	reportingSeatCount  	INT,
	billToRecurringBillingID  NVARCHAR(50),
	billToCountryFriendly NVARCHAR(50),

	firstPaymentDate      DATETIME,     /* first time customer ever paid */
	cancelPaymentDate     DATETIME,     /* date the customer cancelled */
	cancelPaymentComment  NVARCHAR(1000),     /* cancel comments */
	maxPaidDate           DATETIME,     /* the last hist_paymentProfile record that is paid */   
	lastPaidProductID     INT,          /* MAX product ID customer ever paid for */
	lastPaidProductName   NVARCHAR(50), /* Name of max product */
  
	/* calculated fields */
	seatCount 				INT,
	countAsPaid				TINYINT,
	recurringMonthlyRevenue	NUMERIC(38,10),
	annualRevenue			NUMERIC(38,10),
	daysToBuy				INT,
	sheetCount				INT,
	activeProfileCount			INT,
	hasPaid					TINYINT,
	lastPaidMonthlyPayment NUMERIC(38,10),
	
 	PRIMARY KEY(paymentProfileID),
 	KEY ix_currencyCode (currencyCode)
);

INSERT rpt_paymentProfile(
	paymentProfileID,
	ownerID, 
	sourceUserID,
	hasOrgProfile,
	companyName,
	accountType,
	accountTypeFriendly,
	paymentType,
	paymentTypeFriendly,
	parentPaymentProfileID,
	
	paymentInsertDate,
	paymentInsertMonth,
	paymentInsertWeek,
	paymentInsertDay,
	
	paymentStartDateRaw,
	paymentStartDateClean,
	paymentStartMonth, 
	paymentStartWeek, 
	paymentStartDay,
	
	productID,
	productName,
	userLimit,
	productPriceID,
	promoCode,
	bonusSheetCount,
	bonusUserCount,
	paymentTerm,
	paymentTermFriendly,
	paymentTotal,
	planRate_USD,
	currencyCode,
	
	primaryContactPhone,
	referralEmailAddress,
	reportingSeatCount,
	billToRecurringBillingID,
	billToCountryFriendly,
	
	cancelPaymentDate, 
	seatCount,
	countAsPaid,
	recurringMonthlyRevenue,
	annualRevenue,
	daysToBuy,
	sheetCount,
	activeProfileCount,
	hasPaid) 

SELECT 	pp.paymentProfileID, 
	pp.ownerID,	
	ppc.userID,
	ppc.hasOrgProfile,
	/* default companyName to the non-profit name if we have one - overwritten with org name later if it is an org*/
	pp.billToCompany, 
	pp.accountType,
	SMARTSHEET_ACCOUNTTYPE(pp.accountType) AS AccountTypeFriendly,
	pp.paymentType AS PaymentType,
	SMARTSHEET_PAYMENTTYPE(pp.paymentType) AS PaymentTypeFriendly,
	pp.parentPaymentProfileID,
	
	/*paymentInsertDate*/
	ppc.paymentProfileInsertDateTime,
	DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'),
	
	SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), 

	DAYOFYEAR(ppc.paymentProfileInsertDateTime),

	/*paymentStartDateRaw*/
	pp.paymentStartDateTime,
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', pp.paymentStartDateTime) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', ppc.paymentProfileInsertDateTime, '2008-09-29')
	END,

	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008*09(Sep)', DATE_FORMAT(pp.paymentStartDateTime, '%Y*%m(%b)')) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'), '2008*09(Sep)')
	END,
	
	/*paymentStartWeek*/
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', SMARTSHEET_WEEK('2008-09-30 00:00:00'), 
			 SMARTSHEET_WEEK(pp.paymentStartDateTime))
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), SMARTSHEET_WEEK('2008-09-30 00:00:00'))
	END,

	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', DAYOFYEAR('2008-09-30'), DAYOFYEAR(pp.paymentStartDateTime)) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DAYOFYEAR(ppc.paymentProfileInsertDateTime), DAYOFYEAR('2008-09-30'))
	END,
	
	/*productID*/
	pp.productID,
	SMARTSHEET_PRODUCTNAME(pp.productID) AS ProductName,
	pp.userLimit,
	pp.productPriceID,
	pp.promoCode,
	pp.bonusSheetCount,
	IFNULL(pp.bonusUserCount,0),
	pp.paymentTerm,
	SMARTSHEET_PAYMENTTERM(pp.paymentTerm) AS paymentTermFriendly,
	pp.planRate,
	pp.planRate/hce.exchangeRate,
	pp.currencyCode,
	
	/*primaryContactPhone*/
	pp.primaryContactPhone,
	pp.referralEmailAddress,
	pp.reportingSeatCount,
	pp.billToRecurringBillingID,
	SMARTSHEET_COUNTRYNAME(pp.billToCountryCode),
	
	CASE pp.productID
		WHEN 0 THEN pp.paymentStartDateTime
		ELSE NULL END AS cancelPaymentDate,
/*Seat Count*/
	CASE pp.accountType
		WHEN 3 THEN	/* organization */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise accountType */  
				ELSE (SELECT COUNT(ss_core_02.organizationUserRole.organizationUserRoleID) 
					FROM ss_core_02.organizationUserRole JOIN ss_core_02.organization ON ss_core_02.organization.organizationID = ss_core_02.organizationUserRole.organizationID
					WHERE organization.paymentProfileID = pp.paymentProfileID AND role = "LICENSE_USER")
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IF (pp.planRate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IF (pp.planRate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IF (pp.planRate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IF (pp.planRate > 0 , 1, 0)	/* PAYPAL */
				ELSE 0 END
			END,

	CASE (pp.PromoCode = 'HAYEMPL' OR pp.PromoCode = 'EXECMBA09' OR pp.PromoCode = 'TESTPAY')
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE CASE pp.productID
			WHEN 0 THEN  0 /* "Cancelled" */
			WHEN 1 THEN  0 /* "Trial" */
			WHEN 2 THEN  0 /* "Free" */
			ELSE
				CASE pp.paymentType
					WHEN 0 THEN 0	/* none */
					WHEN 1 THEN     /* cc */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 2 THEN 	/* bill to */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
						IF (pp.planRate > 0, 1, 0)
					WHEN 4 THEN 0	/* promo */
					WHEN 5 THEN 0	/* paid by other */						
					WHEN 6 THEN 	/* THIRD_PARTY */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 7 THEN 0	/* THIRD_PARTY_BY_OTHER */		
					WHEN 8 THEN 	/* PAYPAL */
						IF (pp.planRate > 0, 1, 0)		
					ELSE 0 END
				END
	END,

	CASE pp.paymentTerm
		WHEN 1 THEN (pp.planRate/hce.exchangeRate) / pp.paymentTerm
		ELSE "0" END,
		
	CASE pp.paymentTerm
		WHEN 12 THEN (pp.planRate/hce.exchangeRate)
		ELSE "0" END,
		
	CASE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) END,
		
	ppsc.sheetCount,
	ppsc.profileCount,
	0/* default hasPaid to 0 and we will update later based on history */
	
FROM ss_core_02.paymentProfile pp
LEFT OUTER JOIN hist_paymentProfile hpp ON hpp.paymentProfileID = pp.paymentProfileID 
	AND hpp.productID > 2 AND hpp.modifyDateTime <= a_newMaxPaymentProfileID 
LEFT OUTER JOIN hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
	AND pp.paymentStartDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
JOIN rpt_paymentProfileSheetCount ppsc ON ppsc.paymentProfileID = pp.paymentProfileID
JOIN rpt_paymentProfileContact ppc ON ppc.paymentProfileID = pp.paymentProfileID

WHERE pp.paymentProfileID <= a_newMaxPaymentProfileID

GROUP BY 1
;

	
/******* idx_rpt_paymentProfileSourceUserID - start *******/
CREATE INDEX idx_rpt_paymentProfileSourceUserID ON rpt_paymentProfile (sourceUserID);

/******* idx_rpt_paymentProfileMainContactUserID - start *******/
CREATE INDEX idx_rpt_paymentProfileMainContactUserID ON rpt_paymentProfile (mainContactUserID);
CREATE INDEX idx_rpt_paymentProfileMainContactDomain ON rpt_paymentProfile(mainContactDomain);
CREATE INDEX idx_rpt_paymentProfileMainContactEmailAddress ON rpt_paymentProfile (mainContactEmailAddress);
CREATE INDEX idx_rpt_paymentProfileParentPaymentProfileID ON rpt_paymentProfile (parentPaymentProfileID);


/*Set planRate_USD to paymentTotal for all USD transactions*/
UPDATE rpt_paymentProfile SET planRate_USD = paymentTotal WHERE currencyCode = 'USD';
UPDATE rpt_paymentProfile SET planRate_USD = 0 WHERE paymentTotal = 0 AND currencyCode != 'USD';
UPDATE rpt_paymentProfile SET AnnualRevenue = 0 WHERE paymentTotal = 0 AND paymentTerm = 12 AND currencyCode != 'USD';

/* Set main contact based on account type - pull userID from sourceUserID for standard acccounts and from org main contact for orgs */
UPDATE rpt_paymentProfile SET mainContactUserID = sourceUserID WHERE accountType != 3;

/* Also overwrite the company name with the OrgName for Organizations */
UPDATE rpt_paymentProfile rp
  -- JOIN ss_core_02.paymentProfile pp ON rp.paymentProfileID = pp.paymentProfileID and pp.paymentProfileID <= @NEWmaxPaymentProfileID
  JOIN ss_core_02.organization o ON rp.ownerID = o.organizationID and o.organizationID <= a_newMaxOrganizationID
SET rp.mainContactUserID = o.mainContactUserID,
     rp.companyName = o.name
WHERE rp.accountType = 3 

;

UPDATE rpt_paymentProfile rp
  JOIN ss_core_02.userAccount u ON rp.mainContactUserID = u.userID AND u.userID <= a_newMaxuserID
SET  rp.mainContactEmailAddress = u.emailAddress,
     rp.mainContactDomain = SUBSTR(u.emailAddress, INSTR(u.emailAddress,'@') + 1)

;

/* Flip hasPaid flag and firstPaymentDate for anyone that ever was a paid account */
UPDATE rpt_paymentProfile rp
  JOIN ss_core_02.hist_paymentProfile hp ON rp.paymentProfileID = hp.paymentProfileID 
    AND hp.modifyDateTime <= a_newMaxHPPmodifyDateTime
SET rp.hasPaid = 1
WHERE hp.paymentType IN (1,2,3,6,8,10)
;

/* Get the first hist_paymentProfile date where the user was paid */
UPDATE rpt_paymentProfile rp
SET rp.firstPaymentDate = (SELECT MIN(hp.paymentStartDateTime) 
FROM ss_core_02.hist_paymentProfile hp 
WHERE rp.paymentProfileID = hp.paymentProfileID 
AND hp.productID >= 3 
AND hp.paymentType IN (1,2,3,6,8,10)
AND hp.modifyDateTime <= a_newMaxHPPmodifyDateTime)
;

/* Get the last hist_paymentProfile record that is paid */
UPDATE rpt_paymentProfile rp
SET rp.maxPaidDate = (SELECT MAX(hp.modifyDateTime) 
FROM ss_core_02.hist_paymentProfile hp 
WHERE rp.paymentProfileID = hp.paymentProfileID 
AND hp.productID >= 3 
AND hp.paymentType IN (1,2,3,6,8,10)
AND hp.modifyDateTime <= a_newMaxHPPmodifyDateTime)
;

/* Get the productID of the last paid product - we want to know what product they were on when they cancelled */
UPDATE rpt_paymentProfile rp
  JOIN ss_core_02.hist_paymentProfile hp ON rp.paymentProfileID = hp.paymentProfileID 
  	AND rp.maxPaidDate = hp.modifyDateTime 
  	AND hp.modifyDateTime <= a_newMaxHPPmodifyDateTime
SET rp.lastPaidProductID = hp.productID
WHERE rp.maxPaidDate IS NOT NULL 
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;