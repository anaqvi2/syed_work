# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_signupSource()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_signupSource//

create procedure etl_rpt_signupSource(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
                              ,a_newMaxContainerIDModify int
                              ,a_newMaxSignupRequestId int)
begin

# Variable Declaration
declare v_processId int;
declare v_signupRequestId int;

call utl_logProcessStart('etl_rpt_signupSource',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_signupRequestId = (select ifnull(MAX(signupRequestID),0) from rpt_signupSource);

INSERT rpt_signupSource(
	userID, 
	email, 
	signupRequestID, 
	signupInsertDateTime, 
	signupInsertDateTimePT, 
	signupMonth, 
	signupWeek, 
	signupDay, 
	source, 
	bucket, 
	sourceFriendly, 
	subSourceFriendly, 
	campaign, 
	segment, 
	adVersion, 
	captcha, 
	landingPageVersion, 
	submitButtonStyle, 
	signupExtraText,  
	keyword, 
	referrer, 
	appLaunchType, 
	appLaunchParm1, 
	appLaunchParm1Friendly, 
	queryValue, 
	mySmartsheetReferralLink, 
	mySmartsheetReferralLinkFriendly, 
	ipAddress, 
	url, 
	webPage, 
	webSite,
	placement,
	adPosition,
	matchType,
	network)
SELECT 
	r.userID,
	r.emailAddress,
	r.signupRequestID,
	r.insertDateTime,
	ADDTIME(r.insertDateTime, '-7:00:00'),
	DATE_FORMAT(r.insertDateTime, '%Y*%m(%b)'), 
	SMARTSHEET_WEEK(r.insertDateTime), 
	DATE_FORMAT(r.insertDateTime, '%Y*%m*%d'), 
    source.itemValue AS Source, 
	
	NULL AS Bucket,  			/* this is now set later using the function SMARTSHEET_GET_BUCKET */
	NULL SourceFriendly,		/* this is now set later using the function SMARTSHEET_GET_SOURCE */
	
	CASE userAccount.insertByUserID = 0 
		WHEN 0 THEN "Signup Inserted by Smartsheet User"
		ELSE CASE myreferralValue.itemValue 
			WHEN "HS1018297" THEN "Office Arrow" 
			WHEN "RI1018541" THEN "A Clayton's Secretary"  
			ELSE CASE source.itemValue
				WHEN 1 THEN "_Google Search"
				WHEN 2 THEN				/* put office arrow signups with bad tracking info into right bucket */
					
					CASE (r.insertDateTime > "2009-10-12" AND r.insertDateTime < "2009-10-17" AND referrerValue.itemValue LIKE "%officeArrow%")
						WHEN 1 THEN "Office Arrow"
						ELSE "_Google Display Network"		/* Google Content Network */
					END
				WHEN 3 THEN "Yahoo"
				WHEN 4 THEN "YouTube (unpaid)"  /* "Youtube" */
				WHEN 5 THEN "Referral Rewards"
				WHEN 6 THEN "Ask.com"
				WHEN 7 THEN "Email"
				WHEN 8 THEN "_Google Search"
				WHEN 9 THEN "VANetworking.com"
				WHEN 10 THEN "Twitter (unpaid)"  /* "Twitter" */
				WHEN 11 THEN "Social Media (generic)"  /* "Social Media" */
				WHEN 12 THEN "Facebook (unpaid)"
				WHEN 13 THEN "LinkedIn (unpaid)"
				WHEN 14 THEN "Google+ (unpaid)"
				WHEN 15 THEN "Go2Web20.net"
				WHEN 16 THEN "_Bing Search"
				WHEN 17 THEN "smallbiztrends.com"
				WHEN 18 THEN "Public template gallery"
				WHEN 19 THEN "Google App. Marketplace"
				WHEN 20 THEN "Google App. Marketplace"
				WHEN 21 THEN "Intuit"
				WHEN 22 THEN "_Bing Content Network"
				WHEN 23 THEN "Ad Ready Network"
				WHEN 24 THEN "Zimbra"
				WHEN 25 THEN "Facebook"
				WHEN 26 THEN "LinkedIn"
				WHEN 27 THEN "TJ McCue"
				WHEN 28 THEN "Salesforce.com"
				WHEN 29 THEN "Sage Non-Profit"
				WHEN 30 THEN "Spanish - Google Search Test"
				WHEN 31 THEN "Spanish - Google Display Network Test"
				WHEN 32 THEN "Chrome Web Store"
				WHEN 33 THEN "Serchen"
				WHEN 34 THEN "The Deck"
				WHEN 35 THEN "South Africa - Google Display"
				WHEN 36 THEN "_Google Display (iPad only)"
				WHEN 37 THEN "_Google Search (iPad only)"
				WHEN 38 THEN "Germany - Google Display"
				WHEN 39 THEN "Germany - Google Search"
				WHEN 40 THEN "France - Google Display"
				WHEN 41 THEN "France - Google Search"
				WHEN 42 THEN "Brazil - Google Display"
				WHEN 43 THEN "Brazil - Google Search"
				WHEN 44 THEN "India - Google Display"
				WHEN 45 THEN "India - Google Search"
				WHEN 46 THEN "South Africa - Google Search"
				WHEN 47 THEN "Hong Kong - Google Search"
				WHEN 48 THEN "Hong Kong - Google Display"
				WHEN 49 THEN "Denmark - Google Display"
				WHEN 50 THEN "Denmark - Google Search"
				WHEN 51 THEN "Finland - Google Display"
				WHEN 52 THEN "Finland - Google Search"
				WHEN 53 THEN "Netherlands - Google Display"
				WHEN 54 THEN "Netherlands - Google Search"
				WHEN 55 THEN "Smartsheet Paid Google Search"		
				WHEN 56 THEN "Google Templates"
				WHEN 57 THEN "Google Remarketing (Paid Visitors)"
				WHEN 58 THEN "Google Remarketing (Non-paid Visitors)"
				WHEN 59 THEN "Google Remarketing (Nurture Signups)"
				WHEN 60 THEN "Bing Search (Canada)"
				WHEN 61 THEN "Bing Search (Singapore)"
				WHEN 62 THEN "Bing Search (UK)"
				WHEN 63 THEN "Bing Search (French - Canada)"
				WHEN 64 THEN "Bing Search (French - France)"
				WHEN 65 THEN "Singapore - Google Display"
				WHEN 66 THEN "Singapore - Google Search"
				WHEN 67 THEN "Norway - Google Display"
				WHEN 68 THEN "Norway - Google Search"
				WHEN 69 THEN "Sweden - Google Display"
				WHEN 70 THEN "Sweden - Google Search"
				WHEN 71 THEN "Indonesia - Google Display"
				WHEN 72 THEN "Indonesia - Google Search"
				WHEN 73 THEN "Mexico - Google Display"
				WHEN 74 THEN "Mexico - Google Search"
				WHEN 75 THEN "Japan - Google Display"
				WHEN 76 THEN "Japan - Google Search"
				WHEN 77 THEN "Israel - Google Display"
				WHEN 78 THEN "Israel - Google Search"
				WHEN 79 THEN "Malaysia - Google Display"
				WHEN 80 THEN "Malaysia - Google Search"
				WHEN 81 THEN "Philippines - Google Display"
				WHEN 82 THEN "Philippines - Google Search"
				WHEN 83 THEN "Spain - Google Display"
				WHEN 84 THEN "Spain - Google Search"
				WHEN 85 THEN "Belgium - Google Display"
				WHEN 86 THEN "Belgium - Google Search"
				WHEN 87 THEN "Youtube (promoted videos)"
				WHEN 88 THEN "Italy - Google Display"
				WHEN 89 THEN "Italy - Google Search"
				WHEN 90 THEN "Turkey - Google Display"
				WHEN 91 THEN "Turkey - Google Search"
				WHEN 92 THEN "South Korea - Google Display"
				WHEN 93 THEN "South Korea - Google Search"
				WHEN 94 THEN "Columbia - Google Display"
				WHEN 95 THEN "Columbia - Google Search"
				WHEN 96 THEN "Argentina - Google Display"
				WHEN 97 THEN "Argentina - Google Search"
				WHEN 98 THEN "Saudi Arabia - Google Display"
				WHEN 99 THEN "Saudi Arabia - Google Search"
				WHEN 100 THEN "Spanish (US) - Google Display"
				WHEN 101 THEN "Spanish (US) - Google Search"
				WHEN 102 THEN "Spanish (Mexico) - Google Display"
				WHEN 103 THEN "Spanish (Mexico) - Google Search"
				WHEN 104 THEN "Spanish (Spain) - Google Display"
				WHEN 105 THEN "Spanish (Spain) - Google Search"
				WHEN 106 THEN "Spanish (Other) - Google Display"
				WHEN 107 THEN "Spanish (Other) - Google Search"
				WHEN 108 THEN "Spanish (Argentina)  Google Display"
				WHEN 109 THEN "Spanish (Argentina)  Google Search"
				WHEN 110 THEN "Spanish (Peru)  Google Display"
				WHEN 111 THEN "Spanish (Peru)  Google Search"
				WHEN 112 THEN "Spanish (Venezuela)  Google Display"
				WHEN 113 THEN "Spanish (Venezuela)  Google Search"
				WHEN 114 THEN "Spanish (Chile)  Google Display"
				WHEN 115 THEN "Spanish (Chile)  Google Search"
				WHEN 116 THEN "Spanish (Guatemala)  Google Display"
				WHEN 117 THEN "Spanish (Guatemala)  Google Search"
				WHEN 118 THEN "Spanish (Ecuador)  Google Display"
				WHEN 119 THEN "Spanish (Ecuador)  Google Search"
				WHEN 120 THEN "GetApp.com"
				WHEN 121 THEN "Cloud Alliance for Google Apps"			
				WHEN 122 THEN "China - Google Display"
				WHEN 123 THEN "China - Google Search"
				WHEN 124 THEN "Russia - Google Display"
				WHEN 125 THEN "Russia - Google Search"
				WHEN 126 THEN "French (Tier 1) - Google Display"
				WHEN 127 THEN "French (Tier 1) - Google Search"
				WHEN 128 THEN "French (Tier 2) - Google Display"
				WHEN 129 THEN "French (Tier 2) - Google Search"
				WHEN 130 THEN "Portuguese (Brazil) - Google Display"
				WHEN 131 THEN "Portuguese (Brazil) - Google Search"
				WHEN 132 THEN "Portuguese (Portugal) - Google Display"
				WHEN 133 THEN "Portuguese (Portugal) - Google Search"
				WHEN 134 THEN "Box"
				WHEN 135 THEN "_Display - Managed Placements"
				WHEN 136 THEN "Sitepoint"
				WHEN 137 THEN "Brad Egeland"
				WHEN 138 THEN "Google Drive"
				WHEN 139 THEN "Crowdsourcing.org"
				WHEN 140 THEN "Berklee School of Music"
				WHEN 141 THEN "Google Adwords Sitelinks"
				WHEN 142 THEN "AWS Marketplace"
				WHEN 143 THEN "Google Mobile Search (iphone)"
				WHEN 144 THEN "Google Mobile Search (non-iphone)"
				WHEN 145 THEN "German - Google Display"
				WHEN 146 THEN "German - Google Search"
				WHEN 147 THEN "Italian - Google Display"
				WHEN 148 THEN "Italian - Google Search"
				WHEN 149 THEN "Enterprise Display Test - Spreadsheet Hell - Desktop"
				WHEN 150 THEN "Enterprise Display Test - Spreadsheet Hell - Mobile"
				WHEN 151 THEN "_Display - Managed Placements - Tier 1 International"
				WHEN 152 THEN "_Display - Managed Placements - Tier 2 International"
				WHEN 153 THEN "Google Display - Interest Targeted"
				WHEN 154 THEN "Web Forms - Powered by Smartsheet"
				WHEN 155 THEN "Published Sheet - Powered by Smartsheet"
				WHEN 156 THEN "_Google Search - International - Tier 1"
				WHEN 157 THEN "_Google Search - International - Tier 2"
				WHEN 158 THEN "Apple App Store"
				WHEN 159 THEN "Android App Store"
				WHEN 160 THEN "BlueKai - (Google)"
				WHEN 161 THEN "Similar Audiences - (Google)"	
				WHEN 162 THEN "Gmail Ads"	
				WHEN 163 THEN "Smartsheet Paid Bing Search"	
				WHEN 164 THEN "Google Business Category Display"
				WHEN 165 THEN "Elizabeth Harrin (blog posse)"
				WHEN 166 THEN "Video for Adwords"
				WHEN 167 THEN "Robert Kelly (blog posse)"
				WHEN 168 THEN "Lindsay Scott (blog posse)"
				WHEN 169 THEN "Seattle GEO Target (Google Search)"
				WHEN 170 THEN "Seattle GEO Target (Bing Search)"
				WHEN 171 THEN "Seattle GEO Target (Google Display Image)"
				WHEN 172 THEN "Seattle GEO Target (Bing Content)"
				WHEN 173 THEN "Seattle GEO Target (Google Text Display)"
				WHEN 174 THEN "Google Display - Image Ads"
				WHEN 175 THEN "Google Display - Text Ads"
				WHEN 176 THEN "Google Display International - Text Ads"
				WHEN 177 THEN "Google Display International - Image Ads"
				WHEN 178 THEN "thesmallbusinessweb.com"
				WHEN 179 THEN "Centrify"
				WHEN 180 THEN "Social Media Coordinator - Keri"
				WHEN 181 THEN "Geekwire"
				WHEN 182 THEN "USA Today"
				WHEN 183 THEN "Pac NW Soccer"
				WHEN 184 THEN "LinkedIn InMail"
				WHEN 185 THEN "NAPS"
				WHEN 186 THEN "Google Search Companion Marketing"
				WHEN 187 THEN "Google Search Companion Marketing (International)"
				WHEN 188 THEN "Kindle"
				WHEN 189 THEN "Google Play Store"
				WHEN 190 THEN "Zapier"
				WHEN 191 THEN "Dropbox"
				WHEN 192 THEN "123 Contact Form"
				WHEN 193 THEN "Twitter (paid)"
				WHEN 194 THEN "Stack Overflow"
				WHEN 195 THEN "DemandMetric.com"
				WHEN 196 THEN "Similar Audiences (Google) - International"
				WHEN 197 THEN "Google Display - Interest Targeted (International)"
				WHEN 198 THEN "ProjectManagers.net"
				WHEN 199 THEN "ProjectsAtWork.com"
				WHEN 200 THEN "ProjectManagement.com"
				WHEN 201 THEN "Slideshare.net"
				WHEN 202 THEN "LinkedIn International (paid)"
				ELSE CASE (src.itemValue = "pm-sherpa")
					WHEN 1 THEN "PM Sherpa"
					ELSE CASE appLaunchParm1.itemValue
						/* Distributed container IDs for affiliates only*/
						WHEN 1007049 THEN "VA Network"
						WHEN 1003002 THEN "VA Network"
						WHEN 1004022 THEN "Veronica Conway"
						WHEN 1043072 THEN "Veronica Conway"
						WHEN 1002982 THEN "Officebundle.com"
						WHEN 1018093 THEN "Regina Minger"
						WHEN 1024411 THEN "Tradeshow Coach"
						WHEN 1034796 THEN "Ki-Work"
						WHEN 1034806 THEN "OnlineBizU"
						WHEN 1040910 THEN "Success Connections"
						WHEN 1041452 THEN "Baird Consulting"
						WHEN 1045303 THEN "Biz Recipes"
						WHEN 1051958 THEN "Assistant Match"
						WHEN 1053162 THEN "Caroline Melville Society of Virtual Assistants"
						WHEN 1053163 THEN "Caroline Melville Virtually Sorted"
					ELSE CASE myreferralValue.itemValue  IS NOT NULL  /* somebodys My Smartsheet Referral Link */
							WHEN 1 THEN "My Smartsheet Referral"																					
							ELSE CASE referrerValue.itemValue LIKE "%aws.%"		/* considering amazon web services links as affiliate */
								WHEN 1 THEN "Amazon Web Services"					
								ELSE CASE referrerValue.itemValue LIKE "%jott%"		/* considering jott links as affiliate */
									WHEN 1 THEN "Jott"					
									ELSE CASE referrerValue.itemValue LIKE "%search%" OR referrerValue.itemValue LIKE "%www.google%" OR queryValue.itemValue IS NOT NULL 		/* link opened from natural search */
										WHEN 1 THEN
											/* user searched on "smart sheet" or variation put into special sub-category */
											CASE (queryValue.extraInfo = "SmartsheetSearch") 
												WHEN 1 THEN "Smartsheet Search"
												ELSE CASE (queryValue.extraInfo = "DeepLink-NotProvided") 
													WHEN 1 THEN "SEO (Not Provided)"
													ELSE CASE queryValue.itemValue IS NULL OR queryValue.itemValue = ""
														WHEN 1 THEN "Smartsheet Search (Not Provided)"
														ELSE "SEO"
													END 
												END 
											END 				
										ELSE CASE appLaunchType.itemValue
											WHEN 2 THEN "Signup with Sharing Tracking Codes" 		/* grid - the user was shared a sheet, but the auto-login did not work so user signed up */
											/* WHEN 5 THEN "Direct Navigation" 	- distributed container - let referral and search logic below apply */
											WHEN 6 THEN "Signup with Sharing Tracking Codes"		/* workspace - the user was shared a workspace, but the auto-login did not work so user signed up */
											WHEN 10 THEN "Google Drive - Import"		/* IMPORT_GOOGLE_DRIVE_FILE */
											WHEN 11 THEN "Google Drive - New File"		/* NEW_GOOGLE_DRIVE_FILE */		
											ELSE CASE referrerValue.itemValue LIKE "%mail%"	 AND referrerValue.itemValue NOT LIKE "%-email%"	/* link opened from web mail client - not an article about email, someone sent them the link without other source info on link */
												WHEN 1 THEN "Mail Link"			
												ELSE CASE referrerValue.itemValue IS NOT NULL AND referrerValue.itemValue NOT LIKE "smartsheet"
													WHEN 1 THEN "External Source Links" 
													ELSE CASE appLaunchType.itemValue 
													  WHEN 5 THEN "Distributed Container" 		
													  ELSE "Direct Navigation"
													END																								
												END
											END
										END
									END
								END
							END
						END
					END
				END
			END
		END
	END AS SubSourceFriendly,

   CONCAT(campaign.itemValue, " - ", IF(campaignLookup.campaignDescription IS NULL, "not found", campaignLookup.campaignDescription)) AS Campaign, 
   CONCAT(segment.itemValue, " - ", IF(segmentLookup.segmentDescription IS NULL, "not found", segmentLookup.segmentDescription)) AS Segment, 
   adVersion.itemValue AS adVersion, 
   NULL, /* toddj - not really used anymore - captcha.itemValue AS captcha, */
   landingPageVersion.itemValue AS landingPageVersion, 
   NULL, /* toddj - not really used anymore - submitButtonStyle.itemValue AS submitButtonStyle, */
   NULL, /* toddj - not really used anymore - signupExtraText.itemValue AS signupExtraText, */
   NULL AS Keyword,  /* process keyword in later UPDATE */
   referrerValue.itemValue AS Referrer, 
   appLaunchType.itemValue AS TYPE,
   appLaunchParm1.itemValue AS Parm1,
   container.name AS Parm1Friendly,
	
	SUBSTRING(queryValue.itemValue, 1, 150)  AS "QUERY",

	myreferralValue.itemValue AS mySmartsheetReferralLink,
	(SELECT emailAddress FROM ss_core_02.userAccount WHERE userID = SUBSTR(myreferralValue.itemValue, 3)) AS mySmartsheetReferralLinkFriendly,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
       
FROM ss_core_02.signupRequest r 
	LEFT OUTER JOIN rpt_signupSource 								ON rpt_signupSource.userID = r.userID
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	source 				ON r.signupRequestID = source.signupRequestID AND source.itemType = 1 AND source.itemName = "s"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem	referrerValue 		ON referrerValue.signupRequestID = r.signupRequestID AND referrerValue.itemType = 1 AND referrerValue.itemName = "referrerValue"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	queryValue 			ON queryValue.signupRequestID 		= r.signupRequestID AND queryValue.itemType = 1 AND queryValue.itemName = "queryValue"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	myreferralValue 	ON myreferralValue.signupRequestID 	= r.signupRequestID AND myreferralValue.itemType = 1 AND myreferralValue.itemName = "u"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	src 				ON src.signupRequestID 	= r.signupRequestID AND src.itemType = 1 AND src.itemName = "src"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	appLaunchType 		ON appLaunchType.signupRequestID = r.signupRequestID AND appLaunchType.itemType = 2 AND appLaunchType.itemName = "Type"
	LEFT OUTER JOIN userAccount					 	userAccount 		ON userAccount.userID = r.userID

	/* remaining joins are not needed for the bucketing process, they just provide extra info that could be done after this big query */
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	campaign 			ON r.signupRequestID = campaign.signupRequestID AND campaign.itemType = 1 AND campaign.itemName = "c"
		LEFT OUTER JOIN ref_campaignLookup 			campaignLookup 		ON campaign.itemValue = campaignLookup.campaignID
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	appLaunchParm1 		ON r.signupRequestID = appLaunchParm1.signupRequestID AND appLaunchParm1.itemType = 2 AND appLaunchParm1.itemName = "Parm1"
		LEFT OUTER JOIN ss_core_02.container 		container 			ON appLaunchParm1.itemValue = container.containerID AND container.containerID <= a_newMaxContainerIDModify
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	segment 			ON r.signupRequestID = segment.signupRequestID	AND segment.itemType = 1 AND segment.itemName = "m"
		LEFT OUTER JOIN ref_campaignSegmentLookup 	segmentLookup 		ON segment.itemValue = segmentLookup.segmentID		
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	landingPageVersion 	ON landingPageVersion.signupRequestID = r.signupRequestID AND landingPageVersion.itemType = 1 AND landingPageVersion.itemName = "lpv"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	adVersion 			ON r.signupRequestID = adVersion.signupRequestID AND adVersion.itemType = 1 AND adVersion.itemName = "a"

	/* toddj - not really used anymore, commented out for now */
/*	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	captcha 			ON captcha.signupRequestID = r.signupRequestID AND captcha.itemType = 1 AND captcha.itemName = "cv"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	submitButtonStyle 	ON submitButtonStyle.signupRequestID = r.signupRequestID AND submitButtonStyle.itemType = 1 AND submitButtonStyle.itemName = "sbs"
	LEFT OUTER JOIN rpt_signupRequestTrackingItem 	signupExtraText 	ON signupExtraText.signupRequestID = r.signupRequestID AND signupExtraText.itemType = 1 AND signupExtraText.itemName = "sxt"
*/
WHERE r.resultStatus = 1 AND  r.userID IS NOT NULL 	/* only process good records */
	AND r.signupRequestID > v_signupRequestId		/* only process those that have not yet been processed */
	AND r.signupRequestID <= a_newMaxSignupRequestId
	AND rpt_signupSource.userID IS NULL			/* if one only exists for the user, don't process another, it will error out */
GROUP BY r.userID
;

/* fix sub-source for these outliers before looking up the source, buckt */
UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem 	appLaunchType 		ON appLaunchType.signupRequestID = rpt_signupSource.signupRequestID AND appLaunchType.itemType = 2 AND appLaunchType.itemName = 'Type'
SET rpt_signupSource.subSourceFriendly = "Chrome Web Store"
WHERE rpt_signupSource.subSourceFriendly = "Direct Navigation" 
AND rpt_signupSource.signupInsertDateTime < DATE("2013-03-01")   /* don't assume all going forward are from Chrome Web Store, but all from past are. */
AND appLaunchType.itemValue = 12  /* GETTING_STARTED_SHEET */
AND rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

/* Set the source based on the subsource */
UPDATE rpt_signupSource rpt_signupSource
SET rpt_signupSource.sourceFriendly = SMARTSHEET_GET_SOURCE(rpt_signupSource.subSourceFriendly)
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

/* Now set the bucket based on the source */
UPDATE rpt_signupSource rpt_signupSource
SET rpt_signupSource.bucket = SMARTSHEET_GET_BUCKET(rpt_signupSource.sourceFriendly)
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem ipAddress ON rpt_signupSource.signupRequestID = ipAddress.signupRequestID AND ipAddress.itemType = 3 AND ipAddress.itemName = 'ip'
SET rpt_signupSource.ipAddress = 
	CASE WHEN INSTR (ipAddress.itemValue, "," ) > 0
		THEN SUBSTRING_INDEX(ipAddress.itemValue, ",", 1) 
		ELSE ipAddress.itemValue
	END
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'url'
SET rpt_signupSource.url = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'plc'
SET rpt_signupSource.placement =  TRIM(LEADING 'www.' FROM srti.itemValue)
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'adp'
SET rpt_signupSource.adPosition = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'mtp'
SET rpt_signupSource.matchtype = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'net'
SET rpt_signupSource.network = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'dev'
SET rpt_signupSource.dev = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'devm'
SET rpt_signupSource.devm = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'mkwid'
SET rpt_signupSource.mkwid = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'gclid'
SET rpt_signupSource.gclid = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'k'
SET rpt_signupSource.keyword = srti.itemValue
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
SET rpt_signupSource.webPage = 
	CASE rpt_signupSource.url IS NULL
		WHEN 1 THEN TRIM(LEADING 'https://' FROM TRIM(LEADING 'http://' FROM rpt_signupSource.referrer))
		ELSE  TRIM(LEADING 'https://' FROM TRIM(LEADING 'http://' FROM rpt_signupSource.url))
	END
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

UPDATE rpt_signupSource rpt_signupSource
SET rpt_signupSource.webSite = SUBSTRING_INDEX(webPage, '/', 1)
WHERE rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

/* push the new ipAddresses into the info table */
INSERT rpt_main_02.ref_ipAddressInfo(ipAddress)
SELECT DISTINCT
  rpt_signupSource.ipAddress
FROM rpt_main_02.rpt_signupSource       
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = rpt_signupSource.ipAddress 
WHERE rpt_signupSource.ipAddress IS NOT NULL AND ref_ipAddressInfo.ipAddress IS NULL /* only do ipAddresses we have not looked up already */
AND rpt_signupSource.signupRequestID > v_signupRequestId;		/* only process those that have not yet been processed */

INSERT IGNORE rpt_main_02.ref_ipAddressInfo (ipAddress)
SELECT DISTINCT rpt_userIPLocation.ipNumber
FROM rpt_main_02.rpt_userIPLocation
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = rpt_userIPLocation.ipNumber
WHERE ref_ipAddressInfo.ipAddress IS NULL
;

/* update the batch that was marked, we do this in two steps because you cannot put a LIMIT clause on an UPDATE that has a JOIN */
UPDATE rpt_main_02.ref_ipAddressInfo AS ref_ipAddressInfo
LEFT OUTER JOIN rpt_main_02.ref_ipNumber ref_ipNumber ON INET_ATON(ref_ipAddressInfo.ipAddress) = ref_ipNumber.ipNumber 
LEFT OUTER JOIN rpt_main_02.ref_ipLocation ref_ipLocation ON ref_ipNumber.locId = ref_ipLocation.locId
LEFT OUTER JOIN rpt_main_02.ref_country ref_country ON ref_ipLocation.country = ref_country.countryCode
LEFT OUTER JOIN rpt_main_02.ref_region ref_region ON ref_ipLocation.country = ref_region.countryCode AND ref_ipLocation.region = ref_region.regionCode
  SET 
  ref_ipAddressInfo.countryName = ref_country.countryName,
  ref_ipAddressInfo.regionName = ref_region.regionName,
  ref_ipAddressInfo.city = ref_ipLocation.city
WHERE ref_ipAddressInfo.countryName IS NULL;  /* only do ipAddresses we have not looked up already */

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPCountry=ref.countryName
WHERE ss.IPCountry IS NULL
;

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPRegion=ref.regionName
WHERE ss.IPRegion IS NULL
;

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPCity=ref.city
WHERE ss.IPCity IS NULL;


call utl_logProcessEnd(v_processId);

end//

delimiter ;