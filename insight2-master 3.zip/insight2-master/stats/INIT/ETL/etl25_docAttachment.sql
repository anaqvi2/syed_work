# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_docAttachment()' as '' from dual;

delimiter //

drop procedure if exists etl_docAttachment//

create procedure etl_docAttachment(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
                              ,a_newMaxDocAttachmentId int)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_docAttachment',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(docAttachmentId) from docAttachment);
set v_destMaxModTime = (select modifyDateTime from docAttachment where docAttachmentId = v_destMaxId);

replace into docAttachment
select g.*
from ss_core_02.docAttachment g
where modifyDateTime >= v_destMaxModTime
or docAttachmentId between v_destMaxId and a_newMaxDocAttachmentId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;