# Insight
# Stored Procedure for ETL from corehist_paymentProfile
# Moves all inserts and modifications from the hist_paymentProfile table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_hist_paymentProfile()' as '' from dual;

delimiter //

drop procedure if exists etl_hist_paymentProfile//

create procedure etl_hist_paymentProfile(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
                              ,a_NewMaxHPPmodifyDateTime datetime)
begin

declare v_processId int;
#declare v_destMaxId int; 
#declare v_destMaxInsTime datetime; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_hist_paymentProfile',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

#set v_destMaxId = (select max(hist_paymentProfileId) from hist_paymentProfile);
#set v_desMaxInsTime = (select insertDateTime from container where hist_paymentProfileId = v_destMaxId);
set v_destMaxModTime = (SELECT max(modifyDateTime) FROM hist_paymentProfile);

INSERT hist_paymentProfile  
SELECT MIN(pp.paymentProfileID),
pp.ownerID,
pp.accountType,
pp.paymentType,
pp.paymentFlags,
pp.parentPaymentProfileID,
pp.paymentStartDateTime,
pp.paymentEndDateTime,
pp.estimatedLastPaymentDate,
pp.actualLastPaymentDate,
pp.nextPaymentDate,
pp.productID,
pp.productPriceID,
pp.promoCode,
pp.userLimit,
pp.bonusSheetCount,
pp.bonusUserCount,
pp.bonusStorageKb,
pp.loyaltyBonusSheetCount,
pp.loyaltyBonusStorageKb,
pp.loyaltyNextBonusDateTime,
pp.loyaltyNextBonusSheetCount,
pp.loyaltyNextBonusStorageKb,
pp.paymentTerm,
pp.currencyCode,
pp.planRate,
pp.planTaxRate,
pp.taxCalculatedRate,
pp.taxLastCalcDateTime,
pp.primaryContactPhone,
pp.referralEmailAddress,
pp.reportingSeatCount,
pp.billToRecurringBillingID,
pp.billToCCNumber,
pp.billToCCExpMonth,
pp.billToCCExpYear,
pp.billToCCName,
pp.billToFirstName,
pp.billToLastName,
pp.billToEmailAddress,
pp.billToCompany,
pp.billToPO,
pp.billToAddress1,
pp.billToAddress2,
pp.billToCity,
pp.billToRegionCode,
pp.billToPostCode,
pp.billToCountryCode,
pp.billToPPPayerID,
pp.billToPPAgreementID,
pp.insertDateTime,
pp.insertByUserID,
pp.modifyDateTime,
pp.modifyByUserID,
pp.sessionLogID,
pp.dataTimestamp,
pp.hist_effectiveThruDateTime,
pp.planRate/hce.exchangeRate
	
FROM ss_core_02.hist_paymentProfile pp
LEFT JOIN hist_paymentProfile hpp on
	pp.ownerID=hpp.ownerID AND
	pp.accountType=hpp.accountType AND
	pp.modifyDateTime=hpp.modifyDateTime AND
	pp.hist_effectiveThruDateTime=hpp.hist_effectiveThruDateTime
LEFT OUTER JOIN hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
	AND pp.paymentStartDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE pp.modifyDateTime >= v_destMaxModTime 
   and pp.modifyDateTime <= a_NewMaxHPPmodifyDateTime
   AND hpp.ownerID IS NULL
GROUP BY pp.ownerID, pp.accountType, pp.modifyDateTime, pp.hist_effectiveThruDateTime
;

/*Set planRate_USD to planRate for all USD based transactions*/
UPDATE hist_paymentProfile SET planRate_USD = planRate WHERE currencyCode = 'USD';
UPDATE hist_paymentProfile SET planRate_USD = 0 WHERE planRate = 0 AND currencyCode != 'USD';

-- Create staging table to identify previously exisiting records that need to be updated
DROP TABLE IF EXISTS stg_histpaymentProfile_update;

CREATE TABLE IF NOT EXISTS stg_histpaymentProfile_update 
(
	paymentProfileID bigint,
	modifyDateTime datetime,
	hist_effectiveThruDateTime datetime
)
;

INSERT INTO stg_histpaymentProfile_update
SELECT paymentProfileID, modifyDateTime, hist_effectiveThruDateTime
FROM ss_core_02.hist_paymentProfile
WHERE modifyDateTime >= v_destMaxModDate 
and hist_paymentProfile.modifyDateTime <= a_NewMaxHPPmodifyDateTime
;

CREATE INDEX ix_ppID ON stg_histpaymentProfile_update (paymentProfileID);
CREATE INDEX ix_modifyDateTime ON stg_histpaymentProfile_update (modifyDateTime);


-- Update hist_effectiveThruDateTime of previous paymentProfileIDs
UPDATE rpt_main_02.hist_paymentProfile hpp
JOIN ss_core_02.hist_paymentProfile coreHPP ON hpp.paymentProfileID = coreHPP.paymentProfileID
	AND hpp.modifyDateTime = coreHPP.modifyDateTime
JOIN rpt_main_02.stg_histpaymentProfile_update stg ON coreHPP.paymentProfileID = stg.paymentProfileID 
	AND DATE_ADD(stg.modifyDateTime, INTERVAL -1 SECOND) = coreHPP.hist_effectiveThruDateTime
SET hpp.hist_effectiveThruDateTime = coreHPP.hist_effectiveThruDateTime
WHERE DATE_ADD(hpp.modifyDateTime, INTERVAL -1 SECOND) != hpp.hist_effectiveThruDateTime 
   AND hpp.modifyDateTime < v_destMaxModTime
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;