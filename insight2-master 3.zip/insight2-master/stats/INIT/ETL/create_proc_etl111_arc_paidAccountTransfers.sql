# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_paidAccountTransfers table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_paidAccountTransfers()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_paidAccountTransfers//

create procedure etl_arc_paidAccountTransfers(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_arc_paidAccountTransfers',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxModTime = (SELECT max(transferDate) FROM arc_paidAccountTransfers);

INSERT INTO arc_paidAccountTransfers (requestLogID, transferDate, transferStatus, transferFromUserID, transferToUserID, transferType)
SELECT 
requestLog.requestLogID,
requestLog.insertDateTime AS TransferDate,
requestLog.parm4 as TransferStatus,
FROMUSER.userID as FromUserID,
TOUSER.userID as ToUserID,
requestLog.parm3 as TransferType
FROM arc_requestLog requestLog FORCE INDEX (idx_requestLogInsertDateTime)
LEFT OUTER JOIN userAccount FROMUSER ON FROMUSER.userID = requestLog.parm1
LEFT OUTER JOIN userAccount TOUSER ON TOUSER.userID = requestLog.parm2
WHERE requestLog.parm3 LIKE 'TRANSFER_PAID_ACCOUNT:%' 
/*and requestLog.parm4 = 'true' currently including both successful and failed attempts. This line would only take Successful attempts*/
and requestLog.insertDateTime > v_destMaxModTime
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;