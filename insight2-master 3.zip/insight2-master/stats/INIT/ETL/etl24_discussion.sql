# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#discussion
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_discussion()' as '' from dual;

delimiter //

drop procedure if exists etl_discussion//

create procedure etl_discussion(a_parentProcessId int
                               ,a_levelCtrlNum tinyint
							   ,a_newMaxDiscussionId int)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_discussion',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(discussionId) from discussion);
set v_destMaxModTime = (select modifyDateTime from discussion where discussionId = v_destMaxId);

replace into discussion
select g.*
from ss_core_02.discussion g
where modifyDateTime >= v_destMaxModTime
or discussionId between v_destMaxId and a_newMaxDiscussionId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;