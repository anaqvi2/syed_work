# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_featureCountRollupByUser table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_featureCountRollupByUser()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_featureCountRollupByUser//

create procedure etl_rpt_featureCountRollupByUser(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
call utl_logProcessStart('etl_rpt_featureCountRollupByUser',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

	INSERT rpt_featureCountRollupByUser(
		userID, 
		emailAddress, 
		domain,
		contactCount, 
		sharingCount, 
		attachmentCount, 
		attachmentSizeSum,
		attachmentCreatedCount,
		discussionCount, 
		discussionCreatedCount,
		smartsourcingCount, 
		reminderCount, 
		cellLinkCount)

	SELECT u.userID, 
		u.emailAddress, 
		SUBSTR(u.emailAddress, INSTR(u.emailAddress,'@') + 1) AS domain,
		(SELECT COUNT(*) FROM contact contact WHERE contact.userID = u.userID),
		(SELECT COUNT(*) FROM gridAccessMap gam WHERE gam.insertByUserID = u.userID AND u.userID != gam.userID AND gam.deleteStatus = 0),       
		(SELECT COUNT(*) FROM docAttachment WHERE docAttachment.insertByUserID = u.userID),
		(SELECT SUM(fileSizeKb) FROM docAttachment WHERE docAttachment.insertByUserID = u.userID),
		(SELECT COUNT(*) FROM docAttachment JOIN container ON container.containerID = docAttachment.containerID 
			AND containerType = 2 AND TO_SECONDS(docAttachment.insertDateTime) - TO_SECONDS(container.insertDateTime) > 3 
			/*exclude docs attached added 3 seconds after a sheet being created */
			WHERE docAttachment.insertByUserID = u.userID and docAttachment.docAttachmentID),
		(SELECT COUNT(*) FROM discussion  WHERE discussion.insertByUserID = u.userID),      
		(SELECT COUNT(*) FROM discussion JOIN container ON container.containerID = discussion.containerID 
			AND containerType = 2 AND TO_SECONDS(discussion.insertDateTime) - TO_SECONDS(container.insertDateTime) > 3 
			/*exclude discussions added within 3 seconds of a sheet being created */
			WHERE discussion.insertByUserID = u.userID), 
		(SELECT COUNT(*) FROM workItemGroup WHERE insertByUserID = u.userID),
		(SELECT COUNT(*) FROM reminder WHERE insertByUserID = u.userID),
		 /* and some login counts from the sessionLog */
		NULL/* Temporarily remove sheetlink count to improve time (SELECT COUNT(*) FROM sheetLink WHERE insertByUserID = u.userID)*/
	FROM userAccount u
	LEFT OUTER JOIN rpt_featureCountRollupByUser fcru ON u.userID=fcru.userID
	WHERE fcru.userID IS NULL
	;

-- Update contactCount for existing users
UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT contact.userID, COUNT(contact.userID) AS contactCount
	FROM contact
	JOIN (SELECT DISTINCT userID FROM stg_contact_data) stg ON contact.userID=stg.userID
	GROUP BY contact.userID
) cc ON u.userID=cc.userID
SET u.contactCount = cc.contactCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT gam.insertByUserID, COUNT(*) AS sharingCount
	FROM gridAccessMap gam
	JOIN (SELECT DISTINCT insertByUserID FROM stg_gridAccessMap_data) stg ON gam.insertByUserID=stg.insertByUserID
	WHERE gam.deleteStatus != 0
	AND gam.insertByUserID != gam.userID
	GROUP BY gam.insertByUserID
) ns ON u.userID=ns.insertByUserID
SET u.sharingCount = ns.sharingCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN 
(
	SELECT da.insertByUserID, COUNT(DISTINCT da.docAttachmentID) AS attachmentCount
	FROM docAttachment da
	JOIN (SELECT DISTINCT insertByUserID FROM stg_docAttachment_data) stg ON da.insertByUserID=stg.insertByUserID
	GROUP BY da.insertByUserID
) da ON u.userID=da.insertByUserID
SET u.attachmentCount=da.attachmentCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT a.insertbyUserID, SUM(a.filesizekb) AS fileSizeKB
	FROM
		(
			SELECT da.insertByUserID, da.docAttachmentID, SUM(fileSizeKB) AS fileSizeKB
			FROM docAttachment da
			JOIN (SELECT DISTINCT insertByUserID FROM stg_docAttachment_data) stg ON da.insertByUserID=stg.insertByUserID
			GROUP BY da.insertByUserID, da.docAttachmentID
		) a
	GROUP BY a.insertByUserID
) fs ON u.userID=fs.insertByUserID
SET u.attachmentSizeSum=fs.fileSizeKb
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT da.insertByUserID, COUNT(DISTINCT da.docAttachmentID) AS attachmentCreatedCount
	FROM docAttachment da
	JOIN container c ON c.containerID=da.containerID AND containerType=2 AND TO_SECONDS(da.insertDateTime)-TO_SECONDS(c.insertDateTime) > 3
	JOIN (SELECT DISTINCT insertByUserID FROM stg_docAttachment_data) stg ON da.insertByUserID=stg.insertByUserID
	GROUP BY da.insertByUserID
) ac ON u.userID=ac.insertByUserID
SET u.attachmentCreatedCount = ac.attachmentCreatedCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT discussion.insertByUserID, COUNT(DISTINCT discussion.discussionID) AS discussionCount
	FROM discussion
	JOIN (SELECT DISTINCT insertByUserID FROM stg_discussion_data) stg ON discussion.insertByUserID=stg.insertByUserID
	GROUP BY discussion.insertByUserID
) dc ON u.userID=dc.insertByUserID
SET u.discussionCount = dc.discussionCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT d.insertByUserID, COUNT(DISTINCT d.discussionID) AS discussionCreatedCount
	FROM discussion d
	JOIN container c ON c.containerID=d.containerID AND containerType=2 AND TO_SECONDS(d.insertDateTime)-TO_SECONDS(c.insertDateTime) > 3
	JOIN (SELECT DISTINCT insertByUserID FROM stg_discussion_data) stg ON d.insertByUserID=stg.insertByUserID
	GROUP BY d.insertByUserID
) dc ON u.userID=dc.insertByUserID
SET u.discussionCreatedCount=dc.discussionCreatedCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT wig.insertByUserID, COUNT(DISTINCT wig.workItemGroupID) AS smartsourcingCount
	FROM workItemGroup wig
	JOIN (SELECT DISTINCT insertByUserID FROM stg_workItemGroup_data) stg ON wig.insertByUserID=stg.insertByUserID
	GROUP BY wig.insertByUserID
) ss ON u.userID=ss.insertByUserID
SET u.smartsourcingCount=ss.smartsourcingCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT r.insertByUserID, COUNT(DISTINCT r.reminderID) AS reminderCount
	FROM reminder r
	JOIN (SELECT DISTINCT insertByUserID FROM stg_reminder_data) stg ON r.insertByUserID=stg.insertByUserID
	GROUP BY r.insertByUserID
) rc ON u.userID=rc.insertByUserID
SET u.reminderCount=rc.reminderCount
;

UPDATE rpt_featureCountRollupByUser u
JOIN
(
	SELECT sl.insertByUserID, COUNT(DISTINCT sl.sheetLinkID) AS cellLinkCount
	FROM sheetLink sl
	JOIN (SELECT DISTINCT insertByUserID FROM stg_sheetLink_data) stg ON sl.insertByUserID=stg.insertByUserID
	GROUP BY sl.insertByUserID
) cl ON u.userID=cl.insertByUserID
SET u.cellLinkCount=cl.cellLinkCount
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;