# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.

select '### Compiling procedure etl_userAccount()' as '' from dual;

delimiter //

drop procedure if exists etl_userAccount//

create procedure etl_userAccount(a_sourceMaxUserId int
                                ,a_parentProcessId int
								,a_levelCtrlNum tinyint)
begin

# Use this variable to determine the rows we havent moved from the source table yet.
declare v_destMaxUserId int default (select max(userId) from userAccount);
declare v_destMaxModTime datetime default (select max(modifyDateTime) from userAccount where userId = v_destMaxUserId);
declare v_processId int;
call utl_logProcessStart( 'etl_userAccount',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);


set transaction isolation level read committed;

REPLACE INTO userAccount(
    userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID,
	userAccount.localeFriendly,
	userAccount.languageFriendly,
	userAccount.countryFriendly,
	userAccount.domain,
    userAccount.profileImage
)
SELECT ua.userID, ua.firstName, ua.lastName, ua.nickName, ua.accountType, ua.emailAddress, ua.loginPassword, ua.locale, 
	ua.timeZone, ua.newsFlags, ua.statusFlags, ua.insertByUserID, ua.insertDateTime, ua.modifyByUserID, ua.modifyDateTime,
	ua.sessionLogID
      ,localeName
      ,languageName
	  ,countryName
	  ,SUBSTR(emailAddress,INSTR(emailAddress,'@')+1) AS domain
      ,ua.profileImage
from
   (select *
    from ss_core_02.userAccount
    where (modifyDateTime > v_destMaxModTime
        or userId > v_destMaxUserId
           )
        and userId <= a_sourceMaxUserId
   ) ua
left outer join ref_localeCountryLanguage rlcl
    on ua.locale = rlcl.localeCode;

call utl_logProcessEnd(v_processId);

end//

delimiter ;
