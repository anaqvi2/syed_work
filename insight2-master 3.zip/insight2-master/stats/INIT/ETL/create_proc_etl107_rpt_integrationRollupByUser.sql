# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_integrationRollupByUser table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_integrationRollupByUser()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_integrationRollupByUser//

create procedure etl_rpt_integrationRollupByUser(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
call utl_logProcessStart('etl_rpt_integrationRollupByUser',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);


DROP TABLE IF EXISTS rpt_integrationRollupByUser;
CREATE TABLE IF NOT EXISTS 
rpt_integrationRollupByUser(
	userID BIGINT, 
	googleOpenID INT, 
	googleFlag TINYINT,
	googleAppsOpenID INT, 
	googleAppsFlag TINYINT,
	salesforceOpenID INT, 
	salesforceSignup INT, 
	salesforceFlag TINYINT,
	zimbraSignup INT,
	zimbraFlag TINYINT,
	PRIMARY KEY(userID));

INSERT rpt_integrationRollupByUser(userID, googleFlag, googleAppsFlag, salesforceFlag, zimbraFlag)
SELECT u.userID,0,0,0,0 
FROM userAccount u
;

UPDATE rpt_integrationRollupByUser r 
  JOIN openIDIdentifier o ON o.userID = r.userID AND o.provider = 'Google'
SET googleOpenID = 1;

UPDATE rpt_integrationRollupByUser r 
  JOIN openIDIdentifier o ON o.userID = r.userID AND o.provider = 'GoogleApps'
SET googleAppsOpenID = 1;

UPDATE rpt_integrationRollupByUser r 
  JOIN openIDIdentifier o ON o.userID = r.userID AND o.provider = 'Salesforce'
SET salesforceOpenID = 1;

UPDATE rpt_integrationRollupByUser r 
  JOIN rpt_signupSource s ON s.userID = r.userID AND s.source = 28
SET salesforceSignup = 1;

UPDATE rpt_integrationRollupByUser r 
  JOIN rpt_signupSource s ON s.userID = r.userID AND s.source = 24
SET zimbraFlag = 1;

UPDATE rpt_integrationRollupByUser SET googleFlag = 1 WHERE googleOpenID > 0;

UPDATE rpt_integrationRollupByUser SET googleAppsFlag = 1 WHERE googleAppsOpenID > 0;

UPDATE rpt_integrationRollupByUser SET salesforceFlag = 1 WHERE salesforceOpenID > 0 OR salesforceSignup > 0;

UPDATE rpt_integrationRollupByUser SET zimbraFlag = 1 WHERE zimbraSignup > 0;

call utl_logProcessEnd(v_processId);

end//

delimiter ;