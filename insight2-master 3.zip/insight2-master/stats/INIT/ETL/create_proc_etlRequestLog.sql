# Insight
# Stored Procedure for ETL from ss_log_02
# Moves new rows from requestLog table.
# Does not consider updates or deletes on source table.
# Can be executed anytime.  Idempotent.
#
# Revision History
# 2014-02-20:  BMW:  Init.

select '### Compiling procedure etl_requestLog()' as '' from dual;

delimiter //

drop procedure if exists etl_requestLog//
create procedure etl_requestLog(a_parentProcessId int
								,a_levelCtrlNum tinyint)
begin

declare maxRequestLogId bigint;
declare v_processId int;
declare v_processIdChild int;
call utl_logProcessStart( 'etl_RequestLog',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set @maxRequestLogId = (SELECT MAX(requestLogID) FROM arc_requestLog);

# First, identify and copy the distinct set of urlActions and formActions
# but do it only on the request logs that we havent migrated

call utl_logProcessStart('etl_RequestLog',v_processId,'arc_serverActionLookup','DEBUG',a_levelCtrlNum, v_processIdChild);

INSERT IGNORE arc_serverActionLookup(urlActionID, formName, formAction)
select rl.urlActionId, rl.formName, rl.formAction
from
(
SELECT DISTINCT r.urlActionID, r.formName, r.formAction 
FROM ss_log_02.requestLog r 
where  requestLogID > @maxRequestLogId 
) rl
LEFT OUTER JOIN arc_serverActionLookup l 
    ON  rl.urlActionID = l.urlActionID 
	AND rl.formName = l.formName
	AND rl.formAction = l.formAction
where l.urlActionID IS NULL;

call utl_logProcessEnd(v_processIdChild);

# Second, move the request logs
INSERT INTO arc_requestLog 
SELECT * 
FROM ss_log_02.requestLog 
WHERE requestLogID > @maxRequestLogId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;



