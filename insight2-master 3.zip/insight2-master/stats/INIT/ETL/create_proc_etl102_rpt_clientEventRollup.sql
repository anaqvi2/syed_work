# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_clientEventRollup table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_clientEventRollup()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_clientEventRollup//

create procedure etl_arc_clientEventRollup(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
call utl_logProcessStart('etl_arc_clientEventRollup',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxInsTime = (SELECT MAX(logDate) FROM rpt_main_02.arc_clientEventRollup);

TRUNCATE TABLE rpt_main_02.rpt_clientEvent_clean;

INSERT rpt_clientEvent_clean 
SELECT ce.*, sl.userID
FROM arc_clientEvent ce
LEFT JOIN arc_sessionLog sl ON ce.sessionLogID=sl.sessionLogID 
WHERE eventDateTime >= v_destMaxInsTime
;

SELECT 1 	INTO @LOG_ID_OPEN; 
SELECT 20 	INTO @LOG_ID_MOUSE_DOWN;
SELECT 22	INTO @LOG_ID_CLICK;
SELECT 31 	INTO @LOG_ID_SHORTCUT_KEY;
SELECT 60 	INTO @LOG_ID_LAUNCH_UPGRADE;
SELECT 61 	INTO @LOG_ID_COMPLETE_UPGRADE;
SELECT 62 	INTO @LOG_ID_CANCEL_UPGRADE;
SELECT 99 	INTO @LOG_ID_DIAGNOSTIC;

SELECT 101 	INTO @LOG_ID_DESKTOP;
SELECT 200 	INTO @LOG_ID_MY_ACCOUNT_LINK;

SELECT 500 	INTO @LOG_ID_HOMEPAGE_TREE_NODE;
SELECT 551 	INTO @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_CATEGORY;
SELECT 552 	INTO @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_SEARCH;

SELECT 564 	INTO @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE;

SELECT 1801 	INTO @LOG_ID_HELPOVERLAY_PAGE_CONTROL;
SELECT 1805 	INTO @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK;
SELECT 1806 	INTO @LOG_ID_HELPOVERLAY_VIDEO_LINK;
SELECT 2001 	INTO @LOG_ID_STANDARD_BUTTON_GENERIC;
SELECT 5001 	INTO @LOG_ID_TOOLBAR_BUTTON_SAVE;
SELECT 12001 	INTO @LOG_ID_GETTINGSTARTED_ABCTEST;

UPDATE rpt_clientEvent_clean cec 
SET cec.parm1String = NULL ,  cec.parm1Int = NULL
WHERE NOT	/* we are NOT blanking out the list below... i.e. below is a list of the items where we are keeing the parameters */
	(
	(cec.objectID >= @LOG_ID_MY_ACCOUNT_LINK AND cec.actionID = @LOG_ID_OPEN) OR  /* want to keep everything higher than the desktop and tabs */
	(cec.objectID = @LOG_ID_STANDARD_BUTTON_GENERIC) OR 
	(cec.actionID = @LOG_ID_LAUNCH_UPGRADE OR cec.actionID = @LOG_ID_COMPLETE_UPGRADE OR cec.actionID = @LOG_ID_CANCEL_UPGRADE) OR 
	(cec.objectID = @LOG_ID_HELPOVERLAY_PAGE_CONTROL OR cec.objectID = @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK OR cec.objectID = @LOG_ID_HELPOVERLAY_VIDEO_LINK) OR 
	(cec.actionID = @LOG_ID_SHORTCUT_KEY) OR 
	(cec.objectID = @LOG_ID_GETTINGSTARTED_ABCTEST) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TREE_NODE) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_CATEGORY) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_SEARCH) OR 
	(cec.objectID = @LOG_ID_DESKTOP AND cec.actionID = @LOG_ID_DIAGNOSTIC) OR 
	(cec.objectID >= @LOG_ID_TOOLBAR_BUTTON_SAVE AND cec.actionID = @LOG_ID_MOUSE_DOWN) OR
	(cec.objectID = @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE AND @LOG_ID_CLICK)
	)
;

INSERT arc_clientEventRollup(insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)	/* roll up the data */
SELECT sl.userID, 
	DATE(eventDateTime),
	objectID,
	actionID,
	parm1String,
	parm1Int,
	COUNT(*)
FROM rpt_clientEvent_clean cec
JOIN arc_sessionLog sl ON cec.sessionLogID = sl.sessionLogID
GROUP BY 1,2,3,4,5,6
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;