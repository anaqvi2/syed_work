DELIMITER $$

DROP FUNCTION IF EXISTS MARKETO_ACCOUNT_ROLE$$
CREATE FUNCTION `MARKETO_ACCOUNT_ROLE`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT) RETURNS VARCHAR(50)
    DETERMINISTIC
BEGIN
DECLARE accountRole VARCHAR(50);
SET accountRole =
	CASE
		WHEN  parentPaymentProfileID IS NULL THEN "Individual"  -- this is the user who created the organization and team
		WHEN orgMainContactUserID = userID THEN "Owner"  -- this is the user who created the organization and team
		ELSE "Member"								-- this is the user added to the team
	END;
RETURN accountRole;
END
$$

-- 2015-11-16: Corrected character encoding to 'utf-8'. Default was 'latin-1' which was causing many characters to be
-- incorrectly represented in leadflow.arc_marketo_upload
DROP FUNCTION IF EXISTS `MARKETO_LAST_NAME`$$
CREATE FUNCTION `MARKETO_LAST_NAME`(lastName VARCHAR(50)) RETURNS VARCHAR(50)
    DETERMINISTIC
BEGIN
DECLARE processedLastName VARCHAR(50);
SET processedLastName =
	CASE WHEN lastName IS NULL 	THEN NULL -- "No Last Name"   -- "No Last Name" processing is now done inside Marketo
		WHEN lastName = "" 		THEN NULL -- "No Last Name"
		WHEN lastName = " " 	THEN NULL -- "No Last Name"
		ELSE lastName
  END;
RETURN processedLastName;
END
$$

-- 2015-11-16: Corrected character encoding to 'utf-8'. Default was 'latin-1' which was causing many characters to be
-- incorrectly represented in leadflow.arc_marketo_upload
DROP FUNCTION IF EXISTS `MARKETO_BILLING_ADDRESS`$$
CREATE FUNCTION `MARKETO_BILLING_ADDRESS`(address1 VARCHAR(50), address2 VARCHAR(50)) RETURNS VARCHAR(101)
    DETERMINISTIC
BEGIN
DECLARE billingAddress VARCHAR(101);
	SET billingAddress = TRIM(CONCAT(COALESCE(address1,"") ," ", COALESCE(address2,"")));  -- handle nulls with coalesce, add space in between but don't allow space at ends
RETURN billingAddress;
END
$$


DROP FUNCTION IF EXISTS MARKETO_EXTRACT_DOMAIN$$
CREATE FUNCTION `MARKETO_EXTRACT_DOMAIN`(emailAddress VARCHAR(100)) RETURNS VARCHAR(100)
    DETERMINISTIC
BEGIN
DECLARE domain VARCHAR(100);
	SET domain = SUBSTR(emailAddress, INSTR(emailAddress,'@') + 1);
RETURN domain;
END
$$


DROP FUNCTION IF EXISTS MARKETO_CLEAN_IPADDRESS$$
CREATE FUNCTION `MARKETO_CLEAN_IPADDRESS`(ipAddress VARCHAR(50)) RETURNS VARCHAR(50)
    DETERMINISTIC
BEGIN
DECLARE cleanIpAddress VARCHAR(50);
	SET cleanIpAddress =
		CASE WHEN INSTR (ipAddress, "," ) > 0
			THEN SUBSTRING_INDEX(ipAddress, ",", 1)
			ELSE ipAddress
		END;
RETURN cleanIpAddress;
END
$$


DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `MARKETO_SHARE_PERMISSION`$$

CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_SHARE_PERMISSION`(sharePermission INT) RETURNS VARCHAR(25) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
    BEGIN
        DECLARE sharePermissionName VARCHAR(25);
        SET sharePermissionName =
        CASE WHEN sharePermission IS NULL THEN "None"
        WHEN sharePermission = 0 THEN "None"
        WHEN sharePermission = 10 THEN "View"
        WHEN sharePermission = 20 THEN "Editor"
        WHEN sharePermission = 30 THEN "EditorCanShare"
        WHEN sharePermission = 40 THEN "Admin"
        WHEN sharePermission = 50 THEN "Owner"
        ELSE CONCAT('Permission ', sharePermission)
        END;
        RETURN sharePermissionName;
    END$$

DELIMITER ;

DROP FUNCTION IF EXISTS MARKETO_UPGRADE_WIZARD_PROGRESS$$
CREATE FUNCTION `MARKETO_UPGRADE_WIZARD_PROGRESS`(ViewedConfirmPage TINYINT, PayPalComplete TINYINT, PayPalStart TINYINT, ViewedStep3 TINYINT, ViewedStep2 TINYINT, ViewedStep1 TINYINT) RETURNS VARCHAR(100)
    DETERMINISTIC
BEGIN
DECLARE friendlyProgressValue VARCHAR(100);
SET friendlyProgressValue =
	CASE
		WHEN ViewedConfirmPage > 0 THEN "Complete"
		WHEN PayPalComplete > 0 THEN "PayPalComplete"
		WHEN PayPalStart > 0 THEN "PayPalStart"
		WHEN ViewedStep3 > 0 THEN "Step3"
		WHEN ViewedStep2 > 0 THEN "Step2"
		WHEN ViewedStep1 > 0 THEN "Step1"
		ELSE ""
	END;
RETURN friendlyProgressValue;
END
$$


DROP FUNCTION IF EXISTS MARKETO_RECURRING_BILLING_CANCELLED$$
CREATE FUNCTION MARKETO_RECURRING_BILLING_CANCELLED(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT, usersPaymentFlags TINYINT, parentPaymentFlags TINYINT)
RETURNS TINYINT(1) DETERMINISTIC
BEGIN

DECLARE isBillingCancelled TINYINT(1);
DECLARE paymentFlags TINYINT(1);

SET paymentFlags =
	CASE
		WHEN  parentPaymentProfileID IS NULL THEN usersPaymentFlags  	-- no parent, individual plan so use the users payment flag
		WHEN orgMainContactUserID = userID THEN parentPaymentFlags  	-- the user is the main contact so use the parents payment flag
		ELSE usersPaymentFlags								-- this is the user added to the team, just use the users payment flag, shouldn't ever be true
	END;

SET isBillingCancelled =
	CASE
		WHEN paymentFlags & 16 = 16 THEN 1
		ELSE 0
	END;

RETURN isBillingCancelled;

END
$$

DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `SMARTSHEET_SFDCNAME`$$

CREATE FUNCTION `SMARTSHEET_SFDCNAME`(sfdcName VARCHAR(50)) RETURNS VARCHAR(20)
    DETERMINISTIC
BEGIN
DECLARE DBName VARCHAR(200);
SET DBName =
	CASE sfdcName
		WHEN '00540000002I1xUAAS' THEN 'Annika'
		WHEN '00540000002r9VrAAI' THEN 'Brian'
		WHEN '00540000002HJjdAAG' THEN 'Chad'
		WHEN '00540000002n53kAAA' THEN 'Colton'
		WHEN '00540000003TBobAAG' THEN 'Dan'
		WHEN '00533000003ftWzAAI' THEN 'Daniel'
		WHEN '00540000001V66HAAS' THEN 'Darren'
		WHEN '00540000002nyKdAAI' THEN 'David'
		WHEN '00540000002pgcUAAQ' THEN 'Diana'
		WHEN '00533000003Tx3EAAS' THEN 'DrewJ'
		WHEN '00540000002qo7CAAQ' THEN 'Drew'
		WHEN '00540000002pPx6AAE' THEN 'Evan'
		WHEN '00540000002pD6KAAU' THEN 'Gary'
		WHEN '00540000002qWBaAAM' THEN 'Jeana'
		WHEN '00540000001V65sAAC' THEN 'Jennifer'
		WHEN '00533000003UqHGAA0' THEN 'Joel'
		WHEN '00540000002HFLrAAO' THEN 'Kara'
		WHEN '00540000002IYVtAAO' THEN 'Ken'
		WHEN '00540000002qXdzAAE' THEN 'Kevin'
		WHEN '00533000003ftXEAAY' THEN 'Lee'
		WHEN '00540000002n544AAA' THEN 'Liz'
		WHEN '00540000002pPwrAAE' THEN 'Maddie'
		WHEN '00540000002oaOPAAY' THEN 'Matthew'
		WHEN '00540000001TpXDAA0' THEN 'Max'
		WHEN '00533000003X6qpAAC' THEN 'Nate'
		WHEN '00540000002q7KrAAI' THEN 'Nick'
		WHEN '00540000002qXeiAAE' THEN 'NickN'
		WHEN '00533000003UqHLAA0' THEN 'PaulC'
		WHEN '00540000002orVSAAY' THEN 'Roman'
		WHEN '00540000002HLLxAAO' THEN 'Ryaire'
		WHEN '00540000002pgcPAAQ' THEN 'Ryan'
		WHEN '00533000003ftX4AAI' THEN 'SamH'
		WHEN '00533000003U473AAC' THEN 'SarahB'
		WHEN '00540000002FcZIAA0' THEN 'Sarah'
		WHEN '00540000002Fm0cAAC' THEN 'Sean'
		WHEN '00540000002J7pjAAC' THEN 'Steve'
		WHEN '00540000001UFtyAAG' THEN 'Tyler'
		WHEN '00540000002qf8LAAQ' THEN 'Tom'
		WHEN '00540000001U30SAAS' THEN 'Taryn'
		WHEN '00540000001U6hoAAC' THEN 'Desk Integration'
		WHEN '00540000002nu18AAA' THEN 'Andrew Imhoff'
		WHEN '00540000001UHNaAAO' THEN 'Leads Uploader'
		WHEN '00540000002HoCGAA0' THEN 'Marketo Integration'

		WHEN '00533000003Tx39AAC' THEN 'Sam'
		WHEN '00533000003UaPiAAK' THEN 'Nick'
		WHEN '00540000001U30XAAS' THEN 'Tim'
		WHEN '00540000001UcZXAA0' THEN 'AJ'
		WHEN '00540000001UFlaAAG' THEN 'Kevin'
		WHEN '00540000001UFlfAAG' THEN 'Taylor'
		WHEN '00540000001UFlVAAW' THEN 'Ben'
		WHEN '00540000001UiO2AAK' THEN 'Eric'
		WHEN '00540000002Fqe3AAC' THEN 'Joe'
		WHEN '00540000002GeyBAAS' THEN 'Jeff'
		WHEN '00540000002GeyGAAS' THEN 'Chris'
		WHEN '00540000002HJwXAAW' THEN 'ChrisK'
		WHEN '00540000002I1xKAAS' THEN 'Karrin'
		WHEN '00540000002IocCAAS' THEN 'Michael'
		WHEN '00540000002Iuo4AAC' THEN 'JeffD'
		WHEN '00540000002JDUTAA4' THEN 'Anthony'
		WHEN '00540000002nfpCAAQ' THEN 'Alex'
		WHEN '00540000002nyKnAAI' THEN 'Paul'
		WHEN '00540000002pPwwAAE' THEN 'Alex'
		WHEN '00540000002r9XiAAI' THEN 'Sebrina'
		WHEN '00540000002IJzPAAW' THEN 'Platform'
		WHEN '00533000003X6quAAC' THEN 'BenL'
		WHEN '00533000003X6qzAAC' THEN 'MattS'
		WHEN '00533000003X6r4AAC' THEN 'Mark'
		WHEN '00533000003UqH6AAK' THEN 'Lauren'
		WHEN '00540000002r9WkAAI' THEN 'SeanM'

	ELSE sfdcName
	END;
RETURN DBName;
END$$

DELIMITER ;


DELIMITER $$

USE `rpt_main_02`$$

DROP FUNCTION IF EXISTS `SMARTSHEET_SOLUTIONDEPT`$$

CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SOLUTIONDEPT`(department VARCHAR(19)) RETURNS VARCHAR(4)
    DETERMINISTIC
BEGIN
DECLARE solutionDept VARCHAR(4);
SET solutionDept =
    CASE department
        WHEN 'Human Resources' THEN 'HR'
        WHEN 'IT & Operations' THEN 'IT'
        WHEN 'Marketing' THEN 'MA'
        WHEN 'Product Development' THEN 'PD'
        WHEN 'Project Management' THEN 'PM'
        WHEN 'Sales' THEN 'SA'

END;
RETURN solutionDept;
END$$

DELIMITER ;


-- 2016-01-05: Added function to convert SFDC Owner Name to corresponding ID. Basically the reverse of SMARTSHEET_SFDCNAME.
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `SMARTSHEET_SFDCNAMECONVERT`$$

CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_SFDCNAMECONVERT`(sfdcName VARCHAR(50)) RETURNS VARCHAR(20)
    DETERMINISTIC
BEGIN
DECLARE DBName VARCHAR(200);
SET DBName =
	CASE sfdcName
		WHEN 'Annika' THEN  '00540000002I1xUAAS'
WHEN 'Brian' THEN '00540000002r9VrAAI'
WHEN 'Chad' THEN '00540000002HJjdAAG'
WHEN 'Colton' THEN '00540000002n53kAAA'
WHEN 'Dan' THEN '00540000003TBobAAG'
WHEN 'Daniel' THEN '00533000003ftWzAAI'
WHEN 'Darren' THEN '00540000001V66HAAS'
WHEN 'David' THEN '00540000002nyKdAAI'
WHEN 'Diana' THEN '00540000002pgcUAAQ'
WHEN 'DrewJ' THEN '00533000003Tx3EAAS'
WHEN 'Drew' THEN '00540000002qo7CAAQ'
WHEN 'Evan' THEN '00540000002pPx6AAE'
WHEN 'Gary' THEN '00540000002pD6KAAU'
WHEN 'Jeana' THEN '00540000002qWBaAAM'
WHEN 'Jennifer' THEN '00540000001V65sAAC'
WHEN 'Joel' THEN '00533000003UqHGAA0'
WHEN 'Kara' THEN '00540000002HFLrAAO'
WHEN 'Ken' THEN '00540000002IYVtAAO'
WHEN 'Kevin' THEN '00540000002qXdzAAE'
WHEN 'Lee' THEN '00533000003ftXEAAY'
WHEN 'Liz' THEN '00540000002n544AAA'
WHEN 'Maddie' THEN '00540000002pPwrAAE'
WHEN 'Matthew' THEN '00540000002oaOPAAY'
WHEN 'Max' THEN '00540000001TpXDAA0'
WHEN 'Nate' THEN '00533000003X6qpAAC'
WHEN 'Nick' THEN '00540000002q7KrAAI'
WHEN 'NickN' THEN '00540000002qXeiAAE'
WHEN 'PaulC' THEN '00533000003UqHLAA0'
WHEN 'Roman' THEN '00540000002orVSAAY'
WHEN 'Ryaire' THEN '00540000002HLLxAAO'
WHEN 'Ryan' THEN '00540000002pgcPAAQ'
WHEN 'SamH' THEN '00533000003ftX4AAI'
WHEN 'SarahB' THEN '00533000003U473AAC'
WHEN 'Sarah' THEN '00540000002FcZIAA0'
WHEN 'Sean' THEN '00540000002Fm0cAAC'
WHEN 'Steve' THEN '00540000002J7pjAAC'
WHEN 'Tyler' THEN '00540000001UFtyAAG'
WHEN 'Tom' THEN '00540000002qf8LAAQ'
WHEN 'Taryn' THEN '00540000001U30SAAS'
WHEN 'Desk' THEN '00540000001U6hoAAC'
WHEN 'Andrew Imhoff' THEN '00540000002nu18AAA'
WHEN 'Leads Uploader' THEN '00540000001UHNaAAO'
WHEN 'Marketo Integration' THEN '00540000002HoCGAA0'
WHEN 'Sam' THEN '00533000003Tx39AAC'
WHEN 'NickC' THEN '00533000003UaPiAAK'
WHEN 'Tim' THEN '00540000001U30XAAS'
WHEN 'AJ' THEN '00540000001UcZXAA0'
WHEN 'Taylor' THEN '00540000001UFlfAAG'
WHEN 'Ben' THEN '00540000001UFlVAAW'
WHEN 'Eric' THEN '00540000001UiO2AAK'
WHEN 'Joe' THEN '00540000002Fqe3AAC'
WHEN 'Jeff' THEN '00540000002GeyBAAS'
WHEN 'Chris' THEN '00540000002GeyGAAS'
WHEN 'ChrisK' THEN '00540000002HJwXAAW'
WHEN 'Karrin' THEN '00540000002I1xKAAS'
WHEN 'Michael' THEN '00540000002IocCAAS'
WHEN 'JeffD' THEN '00540000002Iuo4AAC'
WHEN 'Anthony' THEN '00540000002JDUTAA4'
WHEN 'Alex' THEN '00540000002nfpCAAQ'
WHEN 'Paul' THEN '00540000002nyKnAAI'
WHEN 'Alex' THEN '00540000002pPwwAAE'
WHEN 'Sebrina' THEN '00540000002r9XiAAI'
WHEN 'Platform' THEN '00540000002IJzPAAW'
WHEN 'BenL' THEN '00533000003X6quAAC'
WHEN 'MattS' THEN '00533000003X6qzAAC'
WHEN 'MarkL' THEN '00533000003X6r4AAC'
WHEN 'Lauren' THEN '00533000003UqH6AAK'
WHEN 'SeanM' THEN '00540000002r9WkAAI'
WHEN 'Jana' THEN '00533000003U0iyAAC'
WHEN 'Mason' THEN '00533000003ft2kAAA'
WHEN 'Cassie' THEN '00533000003gDpNAAU'
WHEN 'JeffDy' THEN '00533000003qkhHAAQ'
WHEN 'Glenn' THEN '00533000003g3CLAAY'
WHEN 'JeffB' THEN '00533000003rC4mAAE'


	ELSE sfdcName
	END;
RETURN DBName;
END$$

DELIMITER ;

-- 2016-07-05: Added function to calculate License Tags for a lead.
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `MARKETO_LICENSE_TAG`$$

CREATE DEFINER =`jmarzinke`@`%` FUNCTION `MARKETO_LICENSE_TAG`(assignedLicenseCount INT, pendingLicenseCount      INT,
                                                               paidLicenseLimit     INT, previousPaidLicenseLimit INT,
                                                               licenseUserCount     INT)
    RETURNS VARCHAR(256)
DETERMINISTIC
    BEGIN
        DECLARE licenseTags VARCHAR(256);
        SET licenseTags =
        CONCAT_WS(
            ';',
            CASE
                WHEN assignedLicenseCount + pendingLicenseCount >= paidLicenseLimit
                    THEN 'assigned100Percent'
            END,
            CASE
                WHEN licenseUserCount >= 3
                    THEN 'assigned3OrMoreLast7Days'
            END,
            CASE
                WHEN paidLicenseLimit - previousPaidLicenseLimit < 0
                    THEN 'licenseLimitTrendingDown'
            END
        );
        RETURN
        CASE
        WHEN licenseTags = ''
            THEN NULL
        ELSE licenseTags
        END;
    END$$

DELIMITER ;


-- 2016-08-11: Added function to calculate User Tags for a lead.
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `MARKETO_USER_TAG`$$

CREATE DEFINER =`jmarzinke`@`%` FUNCTION `MARKETO_USER_TAG`(isInsertedByOrgDomain TINYINT, insertedEmailDomain VARCHAR(100),
                                                            insertedByEmailDomain VARCHAR(100), signupContactMe VARCHAR(100),
                                                            signupEmail           VARCHAR(100))
    RETURNS VARCHAR(255)
    CHARSET utf8mb4
    COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
    BEGIN
        DECLARE userTags VARCHAR(255);
        SET userTags =
        CONCAT_WS(
            ';',
            CASE
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain != insertedByEmailDomain
                THEN CONCAT('insertedByOutDomain', ':@', insertedByEmailDomain)
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain = insertedByEmailDomain
                THEN 'insertedByInDomain'
            WHEN isInsertedByOrgDomain = 0
                THEN 'insertedByISPDomain'
            WHEN isInsertedByOrgDomain = -1
                THEN 'insertedBySelf'
            END,
            CASE
            WHEN signupContactMe = 'on'
                THEN 'contactMe:1'
            WHEN signupEmail IS NOT NULL
                THEN 'contactMe:0'
            END
        );
        RETURN CASE WHEN userTags = ''
            THEN NULL
               ELSE userTags END;
    END$$

DELIMITER ;

-- 2017-09-20: Added function to calculate combined userTags and clickedProjectImportCount fields
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `MARKETO_IMPORT_MS_PROJECT`$$

CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_IMPORT_MS_PROJECT`(userTags VARCHAR(255), clickedImportProjectCount INT) RETURNS VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
    BEGIN
        DECLARE projectImport VARCHAR(255);
        DECLARE userTagsClean VARCHAR(255);
        SET userTagsClean = TRIM(TRAILING ';clickedImportMSProject' FROM userTags); # Strip existing clicked tag
        SET projectImport =
        CONCAT_WS(
            ';',
            userTagsClean,
            CASE WHEN COALESCE(clickedImportProjectCount, 0) > 0
                THEN 'clickedImportMSProject' END
        );
        RETURN CASE WHEN projectImport = ''
            THEN NULL
               ELSE projectImport END;
    END$$

DELIMITER ;

-- 2016-01-04: Added function to calculate payment start datetime
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `SMARTSHEET_PAYMENTSTARTDATETIME`$$

# Use parent paymentStartDateTime if certain account conditions are met, otherwise use individual paymentStartDateTime
CREATE FUNCTION `SMARTSHEET_PAYMENTSTARTDATETIME`(accountType                TINYINT,
                                                  productID                  INT,
                                                  paymentStartDateTime       DATETIME,
                                                  parentPaymentStartDateTime DATETIME)
    RETURNS DATETIME
DETERMINISTIC
    BEGIN

        DECLARE newPaymentStartDateTime DATETIME;

        SET newPaymentStartDateTime =
        CASE
            WHEN
                accountType = 2 AND
                productID = 7 AND
                paymentStartDateTime < COALESCE(parentPaymentStartDateTime, "")
                THEN parentPaymentStartDateTime
            ELSE paymentStartDateTime
        END;

        RETURN newPaymentStartDateTime;

    END$$

DELIMITER ;

-- 2017-01-05: Added function to calculate next payment date
DELIMITER $$

USE `leadflow`$$

DROP FUNCTION IF EXISTS `SMARTSHEET_NEXTPAYMENTDATE`$$

CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_NEXTPAYMENTDATE`(currentDateTime                DATETIME,
                                                                     iNextPaymentDate              DATETIME,
                                                                     pNextPaymentDate              DATETIME,
                                                                     paymentTerm                   TINYINT,
                                                                     iActualLastPaymentDate        DATETIME,
                                                                     pActualLastPaymentDate        DATETIME,
                                                                     accountType                   TINYINT,
                                                                     iPaymentStartDateTime         DATETIME,
                                                                     pPaymentStartDateTime         DATETIME,
                                                                     iPromoCode                    VARCHAR(50),
                                                                     pPromoCode                    VARCHAR(50),
                                                                     iPaymentProfileInsertDateTime DATETIME,
                                                                     pPaymentProfileInsertDateTime DATETIME) RETURNS DATETIME
DETERMINISTIC
    BEGIN
        DECLARE newNextPaymentDate DATETIME;
        DECLARE nextPaymentDate DATETIME;
        DECLARE actualLastPaymentDate DATETIME;
        DECLARE paymentStartDateTime DATETIME;
        DECLARE paymentStartDateTimeClean DATETIME;
        DECLARE promoCode VARCHAR(50);
        DECLARE paymentProfileInsertDateTime DATETIME;


        SET nextPaymentDate = CASE WHEN accountType = 2 THEN pNextPaymentDate ELSE iNextPaymentDate END;
        SET actualLastPaymentDate = CASE WHEN accountType = 2 THEN pActualLastPaymentDate ELSE iActualLastPaymentDate END;
        SET paymentStartDateTime = CASE WHEN accountType = 2 THEN pPaymentStartDateTime ELSE ipaymentStartDateTime END;
        SET promoCode = CASE WHEN accountType = 2 THEN pPromoCode ELSE iPromoCode END;
        SET paymentProfileInsertDateTime = CASE WHEN accountType = 2 THEN pPaymentProfileInsertDateTime ELSE iPaymentProfileInsertDateTime END;


        SET paymentStartDateTimeClean =
        CASE paymentStartDateTime > '2008-09-30'
        WHEN 1
            THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
        ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
        END;


        SET newNextPaymentDate =
        CASE
        WHEN nextPaymentDate > currentDateTime
            THEN nextPaymentDate
        ELSE
            CASE
            WHEN paymentTerm = 12
                THEN
                    CASE
                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN
                            IF(STR_TO_DATE(CONCAT(YEAR(currentDateTime), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s') > currentDateTime,
                               STR_TO_DATE(CONCAT(YEAR(currentDateTime), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s'),
                               STR_TO_DATE(CONCAT(YEAR(currentDateTime) + 1, '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s'))
                    WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                         > currentDateTime
                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
                    END
            WHEN paymentTerm IN (1, 6)
                THEN
                    CASE
                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                        rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
                    WHEN paymentTerm = 1
                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                            rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
                    END
            ELSE NULL
            END
        END;
        RETURN newNextPaymentDate;
    END$$

DELIMITER ;

-- 2017-08-24: updated function to calculate account role
DELIMITER $$

USE `rpt_main_02`$$

DROP FUNCTION IF EXISTS `MARKETO_ACCOUNT_ROLE`$$

CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_ACCOUNT_ROLE`(paymentProfileID BIGINT, parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT) RETURNS VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
    BEGIN
        DECLARE accountRole VARCHAR(50);
        SET accountRole =
        CASE
        WHEN paymentProfileID IS NOT NULL AND parentPaymentProfileID IS NULL THEN "Individual"
        WHEN paymentProfileID IS NULL AND parentPaymentProfileID IS NULL THEN NULL
        WHEN orgMainContactUserID = userID THEN "Owner"
        ELSE "Member"
        END;
        RETURN accountRole;
    END$$

DELIMITER ;