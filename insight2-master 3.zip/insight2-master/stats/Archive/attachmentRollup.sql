SELECT 
	userAccount.emailAddress AS 'Email Address',
	DATE_FORMAT(docAttachment.insertDateTime, '%Y*%m*%d') AS 'Attachment Insert Day', 
	DATE_FORMAT(docAttachment.insertDateTime, '%Y*%U') AS 'Attachment Insert Week', 
	DATE_FORMAT(docAttachment.insertDateTime, '%Y*%m(%b)') AS 'Attachment Insert Month',
	DATE_FORMAT(docAttachment.insertDateTime, '%Y') AS 'Attachment Insert Year', 
	COUNT(*) AS 'Attachment Count',
	SUM(fileSizeKb) AS 'Sum of KB',
	SUM(fileSizeKb)/1024 AS 'Sum of MB',
	rpt_main_02.SMARTSHEET_PRODUCTNAME(paymentProfile.productID) AS 'Product Name'
FROM ss_core_02.docAttachment 
LEFT OUTER JOIN rpt_main_02.userAccount ON docAttachment.insertByUserID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  paymentProfile ON userAccount.userID = paymentProfile.mainContactUserID AND paymentProfile.accountType != 3
GROUP BY 1,2;