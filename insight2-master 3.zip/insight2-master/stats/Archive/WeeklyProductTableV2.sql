/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_weekEndCustomerProduct");

DROP TABLE IF EXISTS rpt_main_02.rpt_weekEndCustomerProduct;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_weekEndCustomerProduct
(weekFriendly VARCHAR (15),
startWeek DATETIME,
endWeek DATETIME,
weekSequence INT,
paymentProfileID BIGINT,
ownerID BIGINT,
sourceUserID BIGINT,
accountType INT,
paymentType INT,
paymentFlags INT,
parentPaymentProfileID BIGINT,
paymentStartDateTime DATETIME,
productID INT,
paymentTerm int,
paymentTotal NUMERIC(38,10),
userLimit INT,
billToRecurringBillingID VARCHAR(20),
modifyDateTime DATETIME,
hist_effectiveThruDateTime DATETIME,
isWin BOOLEAN,
isUpgrade BOOLEAN,
isDowngrade BOOLEAN,
isLoss BOOLEAN,
KEY idx_rpt_weekEndCustomerProduct (paymentProfileID),
KEY idx_rpt_weekEndCustomerProductmodifyDateTime (modifyDateTime),
KEY idx_rpt_weekEndCustomerProductEffectiveDateTime (hist_effectiveThruDateTime),
KEY idx_rpt_weekEndCustomerProductWeekSequence (weekSequence),
KEY ix_product (productID),
KEY paymentProfileID (paymentProfileId, weekSequence)
);

INSERT rpt_main_02.rpt_weekEndCustomerProduct 
(
weekFriendly, startWeek, endWeek, weekSequence, paymentProfileId, ownerId, sourceUserID, accountType, paymentType, paymentFlags, parentPaymentProfileId,
	paymentStartDateTime, productId, paymentTerm, paymentTotal, userLimit, billToRecurringBillingID, modifyDateTime, hist_effectiveThruDateTime
)
SELECT
ref_weeks.weekFriendly,
ref_weeks.startWeek,
ref_weeks.endWeek,
ref_weeks.weekSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime


FROM rpt_main_02.hist_paymentProfile ProductNew
JOIN rpt_main_02.ref_weeks ON ProductNew.hist_effectiveThruDateTime > ref_weeks.endWeek
	AND ProductNew.modifyDateTime < ref_weeks.endWeek
	AND ref_weeks.endWeek <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID


WHERE ProductNew.parentPaymentProfileID IS NULL
AND ProductNew.planRate_USD > 0  /*Paid Accounts */
AND ProductNew.paymentType != 4  /*Not Promo Accounts */

ORDER BY weekSequence;




/*  Adds weeks after cancellation for paid accounts for use in comparisons and lookups   */

INSERT rpt_main_02.rpt_weekEndCustomerProduct
( weekFriendly, startWeek, endWeek, weekSequence, paymentProfileId, ownerID, sourceUserID, accountType, paymentType, paymentFlags, parentPaymentProfileId,
	paymentStartDateTime, productId, paymentTerm, paymentTotal, userLimit, billToRecurringBillingID, modifyDateTime, hist_effectiveThruDateTime)

SELECT  
ref_weeks.weekFriendly,
ref_weeks.startWeek,
ref_weeks.endWeek,
ref_weeks.weekSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime

FROM rpt_main_02.rpt_weekEndCustomerProduct

LEFT OUTER JOIN rpt_main_02.hist_paymentProfile ProductNew ON ProductNew.paymentProfileID  = rpt_weekEndCustomerProduct.paymentProfileID 
	AND ProductNew.productID < 3 	/* notPaid Accounts */
	AND ProductNew.planRate_USD <= 0  /* no money */
JOIN rpt_main_02.ref_weeks ON ProductNew.hist_effectiveThruDateTime > ref_weeks.endWeek
	AND ProductNew.modifyDateTime < ref_weeks.endWeek
	AND ref_weeks.endWeek <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID

WHERE ref_weeks.weekSequence = rpt_weekEndCustomerProduct.weekSequence + 1
-- and rpt_weekEndCustomerProduct.paymentProfileID = 1019848
ORDER BY weekSequence;




UPDATE rpt_main_02.rpt_weekEndCustomerProduct weekEnd 
LEFT OUTER JOIN rpt_main_02.rpt_weekEndCustomerProduct OldWeekEnd 
ON weekEnd.paymentProfileID = OldWeekEnd.paymentProfileID AND weekEnd.weekSequence = OldWeekEnd.weekSequence + 1 
SET weekEnd.isWin = TRUE 
	WHERE (OldWeekEnd.productID < 3 OR OldWeekEnd.productID IS NULL)
	AND weekEnd.productID >= 3
	AND weekEnd.paymentTotal > 0; 

UPDATE rpt_main_02.rpt_weekEndCustomerProduct weekEnd
JOIN rpt_main_02.rpt_weekEndCustomerProduct OldweekEnd FORCE INDEX (ix_product)
ON weekEnd.paymentProfileID = OldweekEnd.paymentProfileID AND weekEnd.weekSequence = OldweekEnd.weekSequence + 1 
SET weekEnd.isUpgrade = TRUE 
	WHERE OldweekEnd.productID >= 3
	AND rpt_main_02.SMARTSHEET_PRODUCTRANK (OldweekEnd.productID) < rpt_main_02.SMARTSHEET_PRODUCTRANK (weekEnd.productID)  
	AND weekEnd.paymentTotal > 0;
	
UPDATE rpt_main_02.rpt_weekEndCustomerProduct weekEnd
JOIN rpt_main_02.rpt_weekEndCustomerProduct OldweekEnd FORCE INDEX (ix_product)
ON weekEnd.paymentProfileID = OldweekEnd.paymentProfileID AND weekEnd.weekSequence = OldweekEnd.weekSequence + 1 
SET weekEnd.isUpgrade = TRUE 
	WHERE OldweekEnd.productID >= 3
	#AND rpt_main_02.SMARTSHEET_PRODUCTRANK (OldweekEnd.productID) < rpt_main_02.SMARTSHEET_PRODUCTRANK (weekEnd.productID)  
	#AND OldweekEnd.productID = weekEnd.productID
	AND (OldweekEnd.userLimit < weekEnd.userLimit OR OldweekEnd.paymentTotal < weekEnd.paymentTotal)
	AND weekEnd.paymentTotal > 0;
	
UPDATE rpt_main_02.rpt_weekEndCustomerProduct weekEnd
JOIN rpt_main_02.rpt_weekEndCustomerProduct OldweekEnd  
ON weekEnd.paymentProfileID = OldweekEnd.paymentProfileID AND weekEnd.weekSequence = OldweekEnd.weekSequence + 1 
SET weekEnd.isLoss = TRUE 
	WHERE weekEnd.productID < 3 AND OldweekEnd.productID >= 3;

UPDATE rpt_main_02.rpt_weekEndCustomerProduct weekEnd
JOIN rpt_main_02.rpt_weekEndCustomerProduct OldweekEnd  FORCE INDEX (ix_product)
ON weekEnd.paymentProfileID = OldweekEnd.paymentProfileID AND weekEnd.weekSequence = OldweekEnd.weekSequence + 1 
SET weekEnd.isDowngrade = TRUE 
	WHERE weekEnd.productID >= 3 
	AND rpt_main_02.SMARTSHEET_PRODUCTRANK (OldweekEnd.productID) > rpt_main_02.SMARTSHEET_PRODUCTRANK (weekEnd.productID);


	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_weekEndCustomerProduct");
