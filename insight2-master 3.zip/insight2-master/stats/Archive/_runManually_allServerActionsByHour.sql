
/* used to see how server performance/load varies over the course of a day */

SELECT 
        CONCAT(r.formAction, " - ", r.formName) AS 'Action',
        DATE(r.insertDateTime) 					AS 'Date',
        HOUR(r.insertDateTime)					AS 'Hour',
        COUNT(*)								AS 'Count',
        AVG(requestDuration) 					AS 'Average Request Duration'
        
FROM ss_log_02.requestLog r 
GROUP BY 1,2,3 
LIMIT 1234567890;

