/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryWeeklyNEWV2.csv insert");

/*CREATE TABLE IF NOT EXISTS 
rpt_main_02.output_RevenueSummary(
	weekFriendly VARCHAR(25),
	paymentProfileID BIGINT,
	PaymentStartDate DATE,
	productID INT,
	userLimit INT,	
	paymentTerm TINYINT,	
	OldMonthlyPayment DECIMAL(38,10),	
	NewMonthlyPayment DECIMAL(38,10),	
	MonthlyPaymentIncrease DECIMAL(38,10),	
	Bucket VARCHAR(50),
	SignupSourceFriendly VARCHAR(100),
	SignupSubSourceFriendly VARCHAR(100),
	SignupCampaign VARCHAR(50),
	SignupSegment VARCHAR(50),
	recordtype VARCHAR(25));*/
TRUNCATE rpt_main_02.output_RevenueSummaryNEW;
INSERT rpt_main_02.output_RevenueSummaryNEW SELECT * FROM rpt_main_02.output_RevenueSummary;
DELETE FROM rpt_main_02.output_RevenueSummaryNEW WHERE recordDate >= (SELECT startWeek FROM rpt_main_02.ref_weeks WHERE startWeek < NOW() AND endWeek > NOW());

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryNEWWins insert");

INSERT rpt_main_02.output_RevenueSummaryNEW(
	weekFriendly,
	paymentProfileID,
	PaymentStartDate,
	productID,
	userLimit,	
	paymentTerm,	
	OldMonthlyPayment,	
	NewMonthlyPayment,	
	MonthlyPaymentIncrease,	
	Bucket,
	SignupSourceFriendly,
	SignupSubSourceFriendly,
	SignupCampaign,
	SignupSegment,
	ipCountry,
	ipRegion,
	ipCity,
	recordtype,
	recordDate)
	
SELECT /*Generating RevenueSummaryWinsV2.csv*/
weeks.weekFriendly,
hist_paymentProfile.paymentProfileID,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

'0' AS OldMonthlyPayment,

hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS NewMonthlyPayment,

hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'WINS' AS recordtype,

DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.hist_paymentProfile
JOIN rpt_main_02.ref_weeks weeks ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND paymentStartDateTime BETWEEN weeks.startWeek AND weeks.endWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
	AND hist_paymentProfile.accountType !=2 
	AND hist_paymentProfile.planRate_USD > 0

-- ORDER BY 1,3
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryNEWWins insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryNEWUpgrades insert");


INSERT rpt_main_02.output_RevenueSummaryNEW(
	weekFriendly,
	paymentProfileID,
	PaymentStartDate,
	productID,
	userLimit,	
	paymentTerm,	
	OldMonthlyPayment,	
	NewMonthlyPayment,	
	MonthlyPaymentIncrease,	
	Bucket,
	SignupSourceFriendly,
	SignupSubSourceFriendly,
	SignupCampaign,
	SignupSegment,
	ipCountry,
	ipRegion,
	ipCity,
	recordtype,
	recordDate)
	
(SELECT /*Generating RevenueSummaryUpgradesV2.csv*/
weeks.weekFriendly,
hist_paymentProfile.paymentProfileID,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

oldHPP.planRate_USD/oldHPP.paymentTerm AS OldMonthlyPayment,

hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS NewMonthlyPayment,

(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm) - (oldHPP.planRate_USD/oldHPP.paymentTerm) AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'UPGRADES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
AND weeks.startWeek <= NOW()
AND weeks.endWeek >= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
AND oldHPP.modifyDateTime <= weeks.startWeek
AND weeks.startWeek <= NOW()
AND weeks.endWeek >= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.accountType !=2 
AND hist_paymentProfile.planRate_USD > 0
AND oldHPP.planRate_USD > 0
AND oldHPP.productID >= 3
AND oldHPP.planRate_USD/oldHPP.paymentTerm < hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm
and hist_paymentProfile.paymentProfileID Not IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/


-- ORDER BY 1,3
)

UNION

(SELECT 
weeks.weekFriendly,
orgHPP.paymentProfileID,
DATE_FORMAT(orgHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(orgHPP.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

oldHPP.planRate_USD/oldHPP.paymentTerm AS OldMonthlyPayment,

orgHPP.planRate_USD/orgHPP.paymentTerm AS NewMonthlyPayment,

(orgHPP.planRate_USD/orgHPP.paymentTerm) - (oldHPP.planRate_USD/oldHPP.paymentTerm) AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'UPGRADES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks 
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
	AND oldHPP.modifyDateTime <= weeks.startWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.hist_paymentProfile orgHPP ON orgHPP.paymentProfileID = hist_paymentProfile.parentPaymentProfileID
	AND hist_paymentProfile.modifyDateTime = orgHPP.modifyDateTime
	AND orgHPP.hist_effectiveThruDateTime > weeks.endWeek
	AND orgHPP.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
	AND oldHPP.productID >= 3
	AND oldHPP.planRate_USD > 0 
	AND oldHPP.accountType = 1 AND hist_paymentProfile.accountType = 2
	AND hist_paymentProfile.parentPaymentProfileID IS NOT NULL
	AND oldHPP.planRate_USD/oldHPP.paymentTerm < orgHPP.planRate_USD/orgHPP.paymentTerm
	and hist_paymentProfile.paymentProfileID Not IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/


-- ORDER BY 1,3
)
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryNEWUpgrades insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryNEWDowngrades insert");

INSERT rpt_main_02.output_RevenueSummaryNEW(
	weekFriendly,
	paymentProfileID,
	PaymentStartDate,
	productID,
	userLimit,	
	paymentTerm,	
	OldMonthlyPayment,	
	NewMonthlyPayment,	
	MonthlyPaymentIncrease,	
	Bucket,
	SignupSourceFriendly,
	SignupSubSourceFriendly,
	SignupCampaign,
	SignupSegment,
	ipCountry,
	ipRegion,
	ipCity,
	recordtype,
	recordDate)
	
SELECT /*Generating RevenueSummaryDowngradesV2.csv*/
weeks.weekFriendly,
hist_paymentProfile.paymentProfileID,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) as productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

CASE WHEN oldHPP.planRate_USD = 0 THEN orgHPP.planRate_USD/orgHPP.paymentTerm 
ELSE oldHPP.planRate_USD/oldHPP.paymentTerm END AS OldMonthlyPayment,

hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS NewMonthlyPayment,

CASE WHEN oldHPP.planRate_USD = 0 THEN - (orgHPP.planRate_USD/orgHPP.paymentTerm) + (hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm)
ELSE - (oldHPP.planRate_USD/oldHPP.paymentTerm) + (hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm) END AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'DOWNGRADES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
	AND oldHPP.modifyDateTime <= weeks.startWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile orgHPP ON oldHPP.parentPaymentProfileID = orgHPP.paymentProfileID 
	AND oldHPP.modifyDateTime = orgHPP.modifyDateTime
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
	AND hist_paymentProfile.productID >= 3
	AND hist_paymentProfile.planRate_USD > 0
	AND hist_paymentProfile.accountType != 2 
	and hist_paymentProfile.paymentProfileID Not IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/

HAVING OldMonthlyPayment > NewMonthlyPayment

-- ORDER BY 1,3
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryNEWDowngrades insert");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryNEWLosses insert");


INSERT rpt_main_02.output_RevenueSummaryNEW(
	weekFriendly,
	paymentProfileID,
	PaymentStartDate,
	productID,
	userLimit,	
	paymentTerm,	
	OldMonthlyPayment,	
	NewMonthlyPayment,	
	MonthlyPaymentIncrease,	
	Bucket,
	SignupSourceFriendly,
	SignupSubSourceFriendly,
	SignupCampaign,
	SignupSegment,
	ipCountry,
	ipRegion,
	ipCity,
	recordtype,
	recordDate)
	
SELECT /*Generating RevenueSummaryLossesV2.csv*/
weeks.weekFriendly,
hist_paymentProfile.paymentProfileID,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) as productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

oldHPP.planRate_USD/oldHPP.paymentTerm AS OldMonthlyPayment,

hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS NewMonthlyPayment,

-(oldHPP.planRate_USD/oldHPP.paymentTerm) AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'LOSSES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
	AND oldHPP.modifyDateTime <= weeks.startWeek
	AND weeks.startWeek <= NOW()
	AND weeks.endWeek >= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
	AND hist_paymentProfile.productID IN (0,2)
	AND hist_paymentProfile.accountType IN (1,3)
	AND hist_paymentProfile.planRate_USD = 0
	AND oldHPP.productID >= 3 
	AND oldHPP.planRate_USD > 0

-- ORDER BY 1,2
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryNEWLosses insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("output_RevenueSummaryNEW.csv");


SELECT ors.*, pp.mainContactDomain AS Domain, o.name AS orgName
FROM rpt_main_02.output_RevenueSummaryNEW ors
LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON ors.paymentProfileID=pp.paymentProfileID
LEFT JOIN rpt_main_02.organization o ON pp.paymentProfileID=o.paymentProfileID
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("output_RevenueSummaryNEW.csv");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryWeeklyNEWV2.csv insert");
