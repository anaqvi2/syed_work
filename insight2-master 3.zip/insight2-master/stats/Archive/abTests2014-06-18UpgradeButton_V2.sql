
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2014-06-18UpgradeButton_V2.sql");





/*Generating userPPC_detailed_V2.csv*/
SELECT
	userAccount.userID AS 'User ID', 
	userAccount.emailAddress AS 'E-mail Address', 
	ss1.valueNumeric AS "SS_ABTEST_UPGRADE_BUTTON",
	DATE_FORMAT(ss1.insertDateTime, '%Y-%m-%d') AS 'ABTestDate1',
	
	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 

	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Lifetime Log Count >= 400',
	
	CASE (userAccount.newsFlags & 1)  
		WHEN 1 THEN '1' ELSE '0' END AS 'Receive News',
	CASE (userAccount.newsFlags & 2)  
		WHEN 2 THEN '1' ELSE '0' END AS 'Receive Morning Mail',
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'	ELSE '0' END AS 'License Accepted',
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'	ELSE '0' END AS 'Password Set',
	
	fcflrbu.paymentFormViewCount AS 'Payment Form View Count',
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Viewed Payment Form At Least Once',
		
	userAccount.countryFriendly AS Country,
	CASE WHEN userAccount.countryFriendly = "United States" THEN "1" ELSE "0" END AS "is US",
	userAccount.languageFriendly AS "Language",
	CASE WHEN userAccount.languageFriendly  = "English" THEN "1" ELSE "0" END AS "is English",
	MAX(rpt_trials.trialDateTime),
	CASE WHEN MAX(rpt_trials.trialDateTime) IS NULL THEN 0 ELSE 1 END AS HadTrial,
	
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0 ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL ELSE 	
		CASE rpt_paymentProfile.countAsPaid = 0 WHEN 1 THEN NULL ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm END
	END AS 'Monthly Revenue',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0 ELSE 
		CASE rpt_paymentProfile.paymentTerm WHEN 12 THEN 1 ELSE 0 END	
	END AS 'Is Annual',
			
	rpt_paymentProfile.paymentTermFriendly AS 'Payment Term',
	rpt_paymentProfile.productName AS 'Product Name',
	rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm AS MonthlyPaymentUSD,

	CASE WHEN rpt_paymentProfile.productID > 2 THEN 1 ELSE 0 END AS CountAsPaidProduct,
	rpt_paymentProfile.hasPaid,
	rpt_paymentProfile.daysToBuy,

	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise?",
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS "Cancelled?",
	rpt_featureCountFromLogsRollupByUser.upgradeButtonPressCount
	
FROM rpt_main_02.userAccount 
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss1 ON userAccount.userID = ss1.userID AND ss1.siteSettingElementName = "SS_ABTEST_UPGRADE_BUTTON"
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON userAccount.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_trials ON userAccount.userID = rpt_trials.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON userAccount.userID = arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType != 2
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser ON rpt_featureCountFromLogsRollupByUser.userID = userAccount.userID

WHERE ss1.siteSettingElementName = "SS_ABTEST_UPGRADE_BUTTON" AND ss1.valueNumeric IS NOT NULL

GROUP BY 1,2,3,4
ORDER BY 4,1

LIMIT 12345678
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2014-06-18UpgradeButton_V2.sql");




