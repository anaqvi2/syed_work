
/***************************************************************************************************************************/
/* load the actual file created back into our system to double check it*/
/***************************************************************************************************************************/


CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_doubleCheckFile(
	signupDate 		DATE, 
	mkwid 			VARCHAR(50), 
	adversion 		VARCHAR(50), 
	keyword 		VARCHAR(50), 
	matchType 		VARCHAR(25), 
	signups 		INT, 
	strongLeads 	INT, 
	wellQualifieds 	INT, 
	wins 			INT, 	
	revenue 		NUMERIC(38,2),
	currency 		VARCHAR(25), 
	KEY(signupDate));


/* hard coded date needs to be changed manually */
LOAD DATA INFILE '/tmp/bulkRevenueadd_smartsheet_2013-06-08.txt' 
  INTO TABLE rpt_main_02.arc_marin_doubleCheckFile
  IGNORE 1 LINES; 
  
  
  