/*
 * Query for Brent to build a list of customers.
 */
SELECT rp.paymentProfileID as PaymentProfileID,
        rp.mainContactUserID as MainContactUserID,
        rp.mainContactEmailAddress as MainContactEmail,        
        rp.mainContactDomain as MainContactDomain,
        CONCAT('www.',rp.mainContactDomain) as MainContactUrl,
        IFNULL(rp.companyName,'') as CompanyName,
        cl.lifetimeLogCount as ActionCount,
        cl.last90DayLogCount as ActionCountLast90,
        DATE_FORMAT(rp.lastUserLoginDate,'%Y-%m-%d') as LastUserLoginDate,
        CASE rp.productID
		    WHEN 0 THEN rpt_main_02.SMARTSHEET_PRODUCTNAME(rp.lastPaidProductID)
			 ELSE rp.productName 
        END as ProductName,
        rp.paymentTermFriendly as PaymentTerm,
        rp.paymentTotal as PaymentTotal,
        rp.sheetCount as SheetCount,
        rp.activeProfileCount as ActiveCreatorCount,
        DATE_FORMAT(rp.paymentInsertDate,'%Y-%m-%d') as PaymentInsertDate,
        DATE_FORMAT(rp.paymentStartDateRaw,'%Y-%m-%d') as PaymentStartDate,
        DATE_FORMAT(rp.paymentStartDateRaw,'%Y-%m') as PaymentStartMonth,
        IFNULL(ss.sourceFriendly,'') as SignupSource,
        IFNULL(ss.subSourceFriendly,'') as SignupSubSource,
        IFNULL(ss.campaign,'') as SignupCampaign,
        IFNULL(ss.segment,'') as SignupSegment,
        dr.googleAppsDomain as GoogleAppInstalledDomain,
        IFNULL(ip.salesforceFlag,0) as Salesforce,
        IFNULL(ip.zimbraFlag,0) as Zimbra,
        CASE rp.productID
		    WHEN 0 THEN DATE_FORMAT(rp.cancelPaymentDate,'%Y-%m-%d')
			 ELSE ''
        END as CancelDate,
        CASE rp.productID
		    WHEN 0 THEN IFNULL(rp.cancelPaymentComment,'')
			 ELSE '' 
        END as CancelComment
FROM rpt_main_02.rpt_paymentProfile rp
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource ss ON rp.sourceUserID = ss.userID
  LEFT OUTER JOIN rpt_main_02.rpt_domainRollup dr ON rp.mainContactDomain = dr.domain
  LEFT OUTER JOIN rpt_main_02.rpt_integrationRollupByPaymentProfile ip ON rp.paymentProfileID = ip.paymentProfileID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByPaymentProfile cl ON rp.paymentProfileID = cl.paymentProfileID
WHERE hasPaid = 1  /* we want folks that were paid and cancelled */
  AND rp.paymentType NOT IN (4,5,6) /* Exclude anyone that is currently promo or a creator */
  /*AND ip.salesforceFlag = 1*/
  ;
  
  