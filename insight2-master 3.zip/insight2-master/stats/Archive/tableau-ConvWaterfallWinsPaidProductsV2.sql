/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ConvWaterfallPaidProductsV2.csv");



DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_paidproduct;

-- Grab detailed wins
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_waterfall_paidproduct
(
	SourceUserID int,
	`First Payment Month` datetime,
	paymentProfileID int,
	ownerID int,
	`Payment Account Type` varchar(20),
	`Payment Type` varchar(20),
	PaymentStartDate datetime,
	PaymentStartMonth datetime,
	productID varchar(50),
	userLimit int,
	paymentTerm int,
	MonthlyPayment decimal (42,14),
	`Insert Date Time` datetime,
	`Modify Date Time` datetime,
	hist_effectiveThruDateTime datetime,
	bucket varchar(50),
	trialStartMonth datetime,
	`Trial Bucket` varchar(50),
	`Trial Account Type` varchar(50),
	source varchar(50),
	subsource varchar(100),
	campaign varchar(100),
	segment varchar(100),
	workingSource varchar(50),
	workingSubsource varchar(100),
	workingBucket varchar(50),
	`IP Country` varchar(50),
	`IP Region` varchar(100),
	`IP City` varchar(100)
)
;

INSERT INTO rpt_main_02.stg_conv_waterfall_paidproduct
SELECT 
ppc.userID AS SourceUserID,
-- MIN(months.monthFriendly) AS 'First Payment Month',
MIN(months.startMonth) AS 'First Payment Month',
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS 'Payment Account Type',
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS 'Payment Type',
MIN(DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d")) AS PaymentStartDate,
MIN(DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m")) AS PaymentStartMonth,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,
planRate_USD/hist_paymentProfile.paymentTerm AS MonthlyPayment,
MIN(hist_paymentProfile.insertDateTime) AS 'Insert Date Time',
MIN(hist_paymentProfile.modifyDateTime) AS 'Modify Date Time',
MIN(hist_paymentProfile.hist_effectiveThruDateTime),
CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS Bucket,
trials.trialStartMonth,
trials.bucket AS 'Trial Bucket',
trials.accountType AS 'Trial Account Type',

trials.source,
trials.subsource,
trials.campaign,
trials.segment,

CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END
ELSE 
CASE rpt_signupSourceUser.sourceFriendly IS NULL /* if we already have source info, use it */
WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 
ELSE
CASE rpt_signupSourceUser.sourceFriendly != "PPC"	 /* if there is an ancestor source and a user source */
WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly /* use the anscestor source if the user source is sharing */
ELSE rpt_signupSourceUser.sourceFriendly	 /* otherwise use the user source */
END
END
END AS 'Working Source',

CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END
ELSE 
CASE rpt_signupSourceUser.subSourceFriendly IS NULL /* if we already have source info, use it */
WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 
ELSE 
CASE rpt_signupSourceUser.subSourceFriendly != "PPC"	 /* if there is an ancestor sub source and a user sub source */
WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly /* use the anscestor sub source if the user source is sharing */
ELSE rpt_signupSourceUser.subSourceFriendly	 /* otherwise use the user sub source */
END
END
END AS 'Working Sub Source',

CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.bucket IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END
ELSE rpt_signupSourceAncestor.bucket 
END AS 'Working Bucket',
ref.ipCountry AS "IP Country",
ref.ipRegion AS "IP Region",
ref.ipCity AS "IP City"



FROM rpt_main_02.hist_paymentProfile
JOIN rpt_main_02.ref_months months ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
AND hist_paymentProfile.modifyDateTime <= months.endMonth
AND hist_paymentProfile.paymentStartDateTime BETWEEN months.startMonth AND months.endMonth
AND months.startMonth <= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.userAccount ua	 ON ua.userID = ppc.userID
LEFT OUTER JOIN rpt_main_02.rpt_userAncestor ON ua.emailAddress = rpt_userAncestor.userEmailAddress
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceAncestor ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
LEFT OUTER JOIN rpt_main_02.stg_trialsByMonth trials ON trials.userID = ppc.userID 
-- LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref ON ref.ipAddress=rpt_signupSourceUser.ipAddress
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ref ON ref.ipNumber=rpt_signupSourceUser.ipAddress

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.paymentStartDateTime >= '2012-01-01 00:00:00'
AND trials.userID IS NOT NULL
GROUP BY 1
;

-- Aggregate wins and substitute ID values for names
-- This will make indexing and matching to trial combos easier
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_waterfall_pp
(
	bucketID INT,
	sourceID INT,
	subsourceID INT,
	campaignID INT,
	segmentID INT,
	-- trialStartMonth varchar(50),
	trialStartMonth datetime,
	accountType varchar(10),
	-- `First Payment Month` varchar(50),
	`First Payment Month` datetime,
	`IP Country` varchar(100),
	`IP Region` varchar(100),
	`IP City` varchar(200),
	paidProducts int,
	KEY ix_unique (bucketID, sourceID, subsourceID, campaignID, segmentID, trialStartMonth, accountType, `First Payment Month`, `IP Country`, `IP Region`, `IP City`)
)
;

TRUNCATE TABLE rpt_main_02.stg_conv_waterfall_pp;

INSERT INTO rpt_main_02.stg_conv_waterfall_pp
SELECT 
bucketID, 
sourceID, 
subsourceID, 
campaignID, 
segmentID, 
trialStartMonth, `Trial Account Type`, `First Payment Month`, 
`IP Country`, `IP Region`, `IP City`, count(*) AS paidProducts
FROM rpt_main_02.stg_conv_waterfall_paidproduct w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.source=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.subsource=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName
GROUP BY 1,2,3,4,5,6,7,8,9,10,11
;

UPDATE rpt_main_02.stg_conv_waterfall_pp SET campaignID = 0 WHERE campaignID IS NULL;
UPDATE rpt_main_02.stg_conv_waterfall_pp SET segmentID = 0 WHERE segmentID IS NULL;



-- Combine trial and win data into a single table for months where trials and wins exist for all key combo matches 
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_waterfall_tp
(
  `bucketID` int(11) DEFAULT NULL,
  `sourceID` int(11) DEFAULT NULL,
  `subsourceID` int(11) DEFAULT NULL,
  `campaignID` int(11) DEFAULT NULL,
  `segmentID` int(11) DEFAULT NULL,
  -- `trialStartMonth` varchar(50) DEFAULT NULL,
  `trialStartMonth` datetime DEFAULT NULL,
  `accountType` varchar(10) DEFAULT NULL,
  `IP Country` varchar(100) DEFAULT NULL,
  `IP Region` varchar(100) DEFAULT NULL,
  `IP City` varchar(200) DEFAULT NULL,
  -- `First Payment Month` varchar(50) DEFAULT NULL,
  `First Payment Month` datetime DEFAULT NULL, 
  `trials` decimal(32,0) DEFAULT NULL,
  `paidProducts` decimal(32,0) DEFAULT NULL,
  KEY `bucketID` (`bucketID`,`sourceID`,`subsourceID`,`campaignID`,`segmentID`,`trialStartMonth`,`accountType`,`First Payment Month`,`IP Country`,`IP Region`,`IP City`)
)
;

TRUNCATE TABLE rpt_main_02.stg_conv_waterfall_tp;

INSERT INTO rpt_main_02.stg_conv_waterfall_tp
SELECT 
t.bucketID, 
t.sourceID, 
t.subsourceID, 
t.campaignID, 
t.segmentID, 
t.trialStartMonth, 
t.accountType, 
t.`IP Country`, t.`IP Region`, t.`IP City`,
w.`First Payment Month`,
sum(trials) as trials,
sum(ifnull(paidProducts,0)) as paidProducts

FROM rpt_main_02.stg_conv_waterfall_trials t
JOIN rpt_main_02.stg_conv_waterfall_pp w 

ON t.bucketID=w.bucketID
AND t.sourceID=w.sourceID
AND t.subsourceID=w.subsourceID
AND t.campaignID=w.campaignID
AND t.segmentID=w.segmentID
AND t.trialStartMonth=w.trialStartMonth
AND t.`IP Country`=w.`IP Country`
AND t.`IP Region`=w.`IP Region`
AND t.`IP City`=w.`IP City`

GROUP BY 
t.bucketID, 
t.sourceID, 
t.subsourceID, 
t.campaignID, 
t.segmentID, 
t.trialStartMonth, 
t.accountType, 
t.`IP Country`, t.`IP Region`, t.`IP City`,
w.`First Payment Month` 
;


-- Identify and insert all wins into table where there are no trials for key combo match but there are wins
INSERT INTO rpt_main_02.stg_conv_waterfall_tp (bucketID, sourceID, subsourceID, campaignID, segmentID, 
trialStartMonth, accountType, `First Payment Month`, `IP Country`, `IP Region`, `IP City`, trials, paidProducts)

SELECT DISTINCT
w.bucketID, w.sourceID, w.subsourceID, w.campaignID, w.segmentID, 
w.trialStartMonth, 
w.accountType, w.`First Payment Month`, w.`IP Country`, w.`IP Region`, w.`IP City`, 0 as trials, paidProducts
FROM rpt_main_02.stg_conv_waterfall_pp w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_conv_waterfall_tp tw
	WHERE (w.bucketID)= (tw.bucketID)
	AND  (w.sourceID)= (tw.sourceID)
	AND  (w.subsourceID)= (tw.subsourceID)
	AND  (w.campaignID)= (tw.campaignID)
	AND  (w.segmentID)= (tw.segmentID)
	AND  (w.trialStartMonth)= (tw.trialStartMonth)
	AND  (w.`IP Country`)=  (tw.`IP Country`)
	AND  (w.`IP Region`)=  (tw.`IP Region`)
	AND  (w.`IP City`)=  (tw.`IP City`)
	AND  (w.`First Payment Month`)= (tw.`First Payment Month`)
)
;


-- Create table to stage trial data 

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_stg_trials 
(
	bucketID int,
	sourceID int,
	subsourceID int,
	campaignID int,
	segmentID int,
	trialStartMonth datetime,
	accountType varchar(50),
	`IP Country` varchar(50),
	`IP Region` varchar(100),
	`IP City` varchar(100),
	trials int,
	paidproducts int
);

INSERT INTO rpt_main_02.stg_conv_stg_trials
SELECT DISTINCT
w.bucketID, w.sourceID, w.subsourceID, w.campaignID, w.segmentID, 
w.trialStartMonth, 
w.accountType, w.`IP Country`, w.`IP Region`, w.`IP City`, trials, 0 as paidproducts
FROM rpt_main_02.stg_conv_waterfall_trials w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_conv_waterfall_tp tw
	WHERE (w.bucketID)= (tw.bucketID)
	AND  (w.sourceID)= (tw.sourceID)
	AND  (w.subsourceID)= (tw.subsourceID)
	AND  (w.campaignID)= (tw.campaignID)
	AND  (w.segmentID)= (tw.segmentID)
	AND  (w.trialStartMonth)= (tw.trialStartMonth)
	AND  (w.`IP Country`)=  (tw.`IP Country`)
	AND  (w.`IP Region`)=  (tw.`IP Region`)
	AND  (w.`IP City`)=  (tw.`IP City`)
)
;




-- Insert placeholder records for trials for every key combo and First Payment Month
-- This will allow conv rates to calculate correctly across months
-- Call stored proc to iterate through all months



INSERT INTO rpt_main_02.stg_conv_waterfall_tp (bucketID, sourceID, subsourceId, campaignID, segmentID, trialStartMonth, accountType, 
`IP Country`, `IP Region`, `IP City`,`First Payment Month`, trials, paidProducts)
SELECT bucketID, sourceID, subsourceID, campaignID, segmentId, trialStartMonth, accountType, 
`IP Country`, `IP Region`, `IP City`, trialStartMonth, trials, paidProducts
FROM rpt_main_02.stg_conv_stg_trials
;



-- Select data for report output
SELECT 	
bucketName as bucket, 
sourceName as source, 
subsourceName as subsource, 
campaignName as campaign, 
segmentName as segment,
trialStartMonth, accountType, `First Payment Month`, `IP Country`,`IP Region`,`IP City`, sum(trials) as trials, sum(paidProducts) as paidproducts
FROM rpt_main_02.stg_conv_waterfall_tp a
LEFT JOIN rpt_main_02.dim_bucket db on a.bucketID=db.bucketID
LEFT JOIN rpt_main_02.dim_source ds on a.sourceID=ds.sourceID
LEFT JOIN rpt_main_02.dim_subsource dss on a.subsourceID=dss.subsourceID
LEFT JOIN rpt_main_02.dim_campaign dc on a.campaignID=dc.campaignID
LEFT JOIN rpt_main_02.dim_segment dseg on a.segmentID=dseg.segmentID
group by 1,2,3,4,5,6,7,8,9,10,11
;


DROP TABLE rpt_main_02.stg_conv_waterfall_paidproduct;
DROP TABLE rpt_main_02.stg_conv_waterfall_tp;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ConvWaterfallPaidProductsV2.csv");
