/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_monthEndCustomerProductUser");

-- CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_monthEndCustomerProductByUser
-- (monthFriendly VARCHAR (15),
-- startMonth DATETIME,
-- endMonth DATETIME,
-- monthSequence TINYINT,
-- paymentProfileID BIGINT,
-- ownerID BIGINT,
-- sourceUserID BIGINT,
-- accountType TINYINT,
-- paymentType TINYINT,
-- paymentFlags INT,
-- parentPaymentProfileID BIGINT,
-- paymentStartDateTime DATETIME,
-- productID INT,
-- paymentTerm TINYINT,
-- paymentTotal NUMERIC(38,10),
-- userLimit INT,
-- billToRecurringBillingID VARCHAR(20),
-- modifyDateTime DATETIME,
-- hist_effectiveThruDateTime DATETIME
-- );


TRUNCATE TABLE rpt_main_02.rpt_monthEndCustomerProductByUser;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_monthEndCustomerProductByUser
(monthFriendly VARCHAR (15),
startMonth DATETIME,
endMonth DATETIME,
monthSequence TINYINT,
paymentProfileID BIGINT,
ownerID BIGINT,
sourceUserID BIGINT,
accountType TINYINT,
paymentType TINYINT,
paymentFlags INT,
parentPaymentProfileID BIGINT,
paymentStartDateTime DATETIME,
productID INT,
paymentTerm TINYINT,
paymentTotal NUMERIC(38,10),
userLimit INT,
billToRecurringBillingID VARCHAR(20),
modifyDateTime DATETIME,
hist_effectiveThruDateTime DATETIME
);

INSERT rpt_main_02.rpt_monthEndCustomerProductByUser
SELECT
ref_months.monthFriendly,
ref_months.startMonth,
ref_months.endMonth,
ref_months.monthSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime

FROM rpt_main_02.hist_paymentProfile ProductNew
JOIN rpt_main_02.ref_months ON ProductNew.hist_effectiveThruDateTime > ref_months.endMonth 
	AND ProductNew.modifyDateTime < ref_months.endMonth 
	AND ref_months.endMonth <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID


WHERE ProductNew.paymentType != 4  /*Not Promo Accounts */
AND ProductNew.accountType !=2 
AND productID > 2

ORDER BY MonthSequence;


/*  Create Indexes for these tables */
/*CREATE INDEX idx_sourceUser ON rpt_monthEndCustomerProductByUser(sourceUserID);
CREATE INDEX idx_rpt_monthEndCustomerProduct ON rpt_main_02.rpt_monthEndCustomerProductByUser (paymentProfileID);*/


	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_monthEndCustomerProductUser");
