/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("churnWaterfallV2.csv");


DROP TABLE IF EXISTS rpt_main_02.stg_churn_waterfall_losses;

CREATE TABLE rpt_main_02.stg_churn_waterfall_losses
(
	bucketID INT,
	sourceID INT,
	subsourceID INT,
	campaignID INT,
	segmentID INT,
	paymentStartMonth DATETIME,
	cancelMonth DATETIME,
	ipCountry VARCHAR(100),
	ipRegion VARCHAR(100),
	ipCity VARCHAR(100),
	languageFriendly VARCHAR(100),
	productID VARCHAR(50),
	paymentTerm INT,
	HadPaymentTermChange INT,
 	HadProductTypeChange INT,
	losses_plans INT,
	losses_ACV DECIMAL (32,0),
 	losses_plus_dg_plans INT,
 	losses_plus_dg_ACV DECIMAL (32,0),
	KEY ix_unique (bucketID, sourceID, subsourceID, campaignID, segmentID, paymentStartMonth, cancelMonth, ipCountry, ipRegion, ipCity, languageFriendly, productID, paymentTerm)
)
;

DROP TABLE IF EXISTS rpt_main_02.stg_churn_waterfall_wins;

CREATE TABLE rpt_main_02.stg_churn_waterfall_wins 
(
	bucketID INT,
	sourceID INT,
	subsourceID INT,
	campaignID INT,
	segmentID INT,
	paymentStartMonth DATETIME,
	winMonth DATETIME,
	ipCountry VARCHAR(100),
	ipRegion VARCHAR(100),
	ipCity VARCHAR(100),
	languageFriendly VARCHAR(100),
	productID VARCHAR(50),
	paymentTerm INT,
	HadPaymentTermChange INT,
 	HadProductTypeChange INT,
	wins_plans INT,
	wins_ACV DECIMAL(32,0),
	wins_plus_ug_plans INT,
	wins_plus_ug_ACV DECIMAL (32,0),
	KEY ix_unique (bucketID, sourceID, subsourceID, campaignID, segmentID, paymentStartMonth, winMonth, ipCountry, ipRegion, ipCity, languageFriendly, productID, paymentTerm)
)
;


INSERT INTO rpt_main_02.stg_churn_waterfall_losses 
(
	bucketID, 
	sourceID, 
	subsourceID, 
	campaignID, 
	segmentID, 
	paymentStartMonth, 
	productID, 
	paymentTerm, 
	HadPaymentTermChange,
 	HadProductTypeChange,
	cancelMonth, 
	ipCountry, 
	ipRegion, 
	ipCity, 
	languageFriendly,
	losses_plans, 
	losses_ACV,  
	losses_plus_dg_plans, 
	losses_plus_dg_ACV
)
SELECT 
	bucketID,
	sourceID,
	subsourceID,
	IFNULL(campaignID,0),
	IFNULL(segmentID,0),
	paymentStartMonth,
	productID,
	paymentTerm,
	HadPaymentTermChange,
 	HadProductTypeChange,
	effectiveMonth,
	ipCountry,
	ipRegion,
	ipCity,
	languageFriendly,
	plans,
	monthly_rev,
	plans,
	monthly_rev
FROM
(
	SELECT
	CASE ss.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE ss.bucket
	END AS 'Bucket',
	CASE ss.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.sourceFriendly
	END AS SignupSourceFriendly,
	CASE ss.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.subSourceFriendly
	END AS SignupSubSourceFriendly,
	campaign,
	segment,
	DATE_FORMAT(rsm.paymentStartDate,'%Y-%m-01') AS paymentStartMonth,
	OldProductName AS productID,
	OldPaymentTerm AS paymentTerm,
	DATE_FORMAT(rsm.modifyDateTime,'%Y-%m-01') AS EffectiveMonth,
	rsm.ipCountry,
	rsm.ipRegion,
	rsm.ipCity,
	ua.languageFriendly,
	CASE WHEN ptc.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadPaymentTermChange,
	CASE WHEN ig.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadProductTypeChange,
	COUNT(DISTINCT rsm.paymentProfileID) AS plans,
	SUM(MonthlyPaymentChange*-12) AS monthly_rev
	FROM rpt_main_02.output_RevenueSummaryMonthly rsm
	LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON rsm.paymentProfileID=pp.paymentProfileID
	LEFT JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
	LEFT JOIN rpt_main_02.rpt_signupSource ss ON ua.userID=ss.userID
	LEFT JOIN rpt_main_02.rpt_userPaymentTermChanges ptc ON rsm.paymentProfileID=ptc.paymentProfileID
	LEFT JOIN rpt_main_02.rpt_userProductTypeChanges ig ON rsm.paymentProfileID=ig.paymentProfileID
	WHERE recordType='LOSSES'
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
) w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.signupSourceFriendly=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.signupSubSourceFriendly=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName

UNION

SELECT 
	bucketID,
	sourceID,
	subsourceID,
	IFNULL(campaignID,0),
	IFNULL(segmentID,0),
	paymentStartMonth,
	productID,
	paymentTerm,
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth,
	ipCountry,
	ipRegion,
	ipCity,
	languageFriendly,
	0,
	0,
	0,
	monthly_rev
FROM
(
	SELECT
	CASE ss.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE ss.bucket
	END AS 'Bucket',
	CASE ss.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.sourceFriendly
	END AS SignupSourceFriendly,
	CASE ss.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.subSourceFriendly
	END AS SignupSubSourceFriendly,
	campaign,
	segment,
	DATE_FORMAT(rsm.paymentStartDate,'%Y-%m-01') AS paymentStartMonth,
	OldProductName AS productID,
	OldPaymentTerm AS paymentTerm,
	DATE_FORMAT(rsm.modifyDateTime,'%Y-%m-01') AS EffectiveMonth,
	rsm.ipCountry,
	rsm.ipRegion,
	rsm.ipCity,
	ua.languageFriendly,
	CASE WHEN ptc.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadPaymentTermChange,
	CASE WHEN ig.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadProductTypeChange,
	COUNT(DISTINCT rsm.paymentProfileID) AS plans,
	SUM(MonthlyPaymentChange*-12) AS monthly_rev
	FROM rpt_main_02.output_RevenueSummaryMonthly rsm
	LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON rsm.paymentProfileID=pp.paymentProfileID
	LEFT JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
	LEFT JOIN rpt_main_02.rpt_signupSource ss ON ua.userID=ss.userID
	LEFT JOIN rpt_main_02.rpt_userPaymentTermChanges ptc ON rsm.paymentProfileID=ptc.paymentProfileID
	LEFT JOIN rpt_main_02.rpt_userProductTypeChanges ig ON rsm.paymentProfileID=ig.paymentProfileID
	WHERE recordType='DOWNGRADES'
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
) w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.signupSourceFriendly=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.signupSubSourceFriendly=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName
;




INSERT INTO rpt_main_02.stg_churn_waterfall_wins 
(
	bucketID, 
	sourceID, 
	subsourceID, 
	campaignID, 
	segmentID, 
	paymentStartMonth, 
	productID, 
	paymentTerm, 
	HadPaymentTermChange,
	HadProductTypeChange,
	winMonth, 
	ipCountry, 
	ipRegion, 
	ipCity, 
	languageFriendly, 
	wins_plans, 
	wins_ACV, 
	wins_plus_ug_plans, 
	wins_plus_ug_ACV
)
	SELECT 
	bucketID,
	sourceID,
	subsourceID,
	IFNULL(campaignID,0),
	IFNULL(segmentID,0),
	paymentStartMonth,
	productID,
	paymentTerm,
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth,
	ipCountry,
	ipRegion,
	ipCity,
	languageFriendly,
	plans,
	monthly_rev,
	plans,
	monthly_rev
FROM
(
	SELECT
	CASE ss.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE ss.bucket
	END AS 'Bucket',
	CASE ss.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.sourceFriendly
	END AS SignupSourceFriendly,
	CASE ss.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.subSourceFriendly
	END AS SignupSubSourceFriendly,
	campaign,
	segment,
	DATE_FORMAT(rsm.paymentStartDate,'%Y-%m-01') AS paymentStartMonth,
	NewProductName AS productID,
	NewPaymentTerm AS paymentTerm,
	DATE_FORMAT(rsm.modifyDateTime,'%Y-%m-01') AS EffectiveMonth,
	rsm.ipCountry,
	rsm.ipRegion,
	rsm.ipCity,
	ua.languageFriendly,
	CASE WHEN ptc.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadPaymentTermChange,
	CASE WHEN ig.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadProductTypeChange,
	COUNT(DISTINCT rsm.paymentProfileID) AS plans,
	SUM(MonthlyPaymentChange*12) AS monthly_rev
	FROM rpt_main_02.output_RevenueSummaryMonthly rsm
	LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON rsm.paymentProfileID=pp.paymentProfileID
	LEFT JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
	LEFT JOIN rpt_main_02.rpt_signupSource ss ON ua.userID=ss.userID
	LEFT JOIN rpt_main_02.rpt_userPaymentTermChanges ptc ON rsm.paymentProfileID=ptc.paymentProfileID
	LEFT JOIN rpt_main_02.rpt_userProductTypeChanges ig ON rsm.paymentProfileID=ig.paymentProfileID
	WHERE recordType='WINS'
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
) w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.signupSourceFriendly=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.signupSubSourceFriendly=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName

UNION

SELECT 
	bucketID,
	sourceID,
	subsourceID,
	IFNULL(campaignID,0),
	IFNULL(segmentID,0),
	paymentStartMonth,
	productID,
	paymentTerm,
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth,
	ipCountry,
	ipRegion,
	ipCity,
	languageFriendly,
	0,
	0,
	0,
	monthly_rev
FROM
(
	SELECT
	CASE ss.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE ss.bucket
	END AS 'Bucket',
	CASE ss.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.sourceFriendly
	END AS SignupSourceFriendly,
	CASE ss.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE ss.subSourceFriendly
	END AS SignupSubSourceFriendly,
	campaign,
	segment,
	DATE_FORMAT(rsm.paymentStartDate,'%Y-%m-01') AS paymentStartMonth,
	OldProductName AS productID,
	OldPaymentTerm AS paymentTerm,
	DATE_FORMAT(rsm.modifyDateTime,'%Y-%m-01') AS EffectiveMonth,
	rsm.ipCountry,
	rsm.ipRegion,
	rsm.ipCity,
	ua.languageFriendly,
	CASE WHEN ptc.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadPaymentTermChange,
	CASE WHEN ig.paymentProfileID IS NULL THEN 0 ELSE 1 END AS HadProductTypeChange,
	COUNT(DISTINCT rsm.paymentProfileID) AS plans,
	SUM(MonthlyPaymentChange*12) AS monthly_rev
	FROM rpt_main_02.output_RevenueSummaryMonthly rsm
	LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON rsm.paymentProfileID=pp.paymentProfileID
	LEFT JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
	LEFT JOIN rpt_main_02.rpt_signupSource ss ON ua.userID=ss.userID
	LEFT JOIN rpt_main_02.rpt_userPaymentTermChanges ptc ON rsm.paymentProfileID=ptc.paymentProfileID
	LEFT JOIN rpt_main_02.rpt_userProductTypeChanges ig ON rsm.paymentProfileID=ig.paymentProfileID
	WHERE recordType='UPGRADES'
	GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
) w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.signupSourceFriendly=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.signupSubSourceFriendly=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName
;




-- Combine cancel and win data into a single table for months where cancels and wins exist for all key combo matches 
DROP TABLE IF EXISTS rpt_main_02.stg_churn_waterfall_cw;

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_churn_waterfall_cw 
(
  `bucketID` INT(11) DEFAULT NULL,
  `sourceID` INT(11) DEFAULT NULL,
  `subsourceID` INT(11) DEFAULT NULL,
  `campaignID` INT(11) DEFAULT NULL,
  `segmentID` INT(11) DEFAULT NULL,

  `PaymentStartMonth` DATETIME DEFAULT NULL,

  `ipCountry` VARCHAR(100) DEFAULT NULL,
  `ipRegion` VARCHAR(100) DEFAULT NULL,
  `ipCity` VARCHAR(200) DEFAULT NULL,
	languageFriendly VARCHAR(100),
  
  productID VARCHAR(50) DEFAULT NULL,
  paymentTerm INT,
  
  HadPaymentTermChange INT,
  HadProductTypeChange INT,

  `effectiveMonth` DATETIME DEFAULT NULL, 
  

  `wins_plans` DECIMAL(32,0) DEFAULT NULL,
  `wins_ACV` DECIMAL(32,0) DEFAULT NULL,

  `wins_plans2` DECIMAL(32,0) DEFAULT NULL,
  `wins_ACV2` DECIMAL(32,0) DEFAULT NULL,

  `cancelled_plans` DECIMAL(32,0) DEFAULT NULL,
  `cancelled_ACV` DECIMAL(32,0) DEFAULT NULL,  

  `cancelled_plans2` DECIMAL(32,0) DEFAULT NULL,
  `cancelled_ACV2` DECIMAL(32,0) DEFAULT NULL,  
  
  KEY `bucketID` (`bucketID`,`sourceID`,`subsourceID`,`campaignID`,`segmentID`,`PaymentStartMonth`,`effectiveMonth`,`ipCountry`,`ipRegion`,`ipCity`, languageFriendly, productID, paymentTerm,
  HadPaymentTermChange, HadProductTypeChange)
)
;


TRUNCATE TABLE rpt_main_02.stg_churn_waterfall_cw;

INSERT INTO rpt_main_02.stg_churn_waterfall_cw 
(
	bucketID, 
	sourceID, 
	subsourceID, 
	campaignID, 
	segmentID, 
	paymentStartMonth, 
	ipCountry, 
	ipRegion, 
	ipCity, 
	languageFriendly,
	productID, 
	paymentTerm, 
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth, 
	cancelled_plans, 
	cancelled_ACV, 
	cancelled_plans2, 
	cancelled_ACV2, 
	wins_plans, 
	wins_ACV,
	wins_plans2, 
	wins_ACV2
)

SELECT 
w.bucketID, 
w.sourceID, 
w.subsourceID, 
w.campaignID, 
w.segmentID, 
w.PaymentStartMonth, 
w.`ipCountry`, w.`ipRegion`, w.`ipCity`,
w.languageFriendly,
w.productID,
w.paymentTerm,
w.HadPaymentTermChange,
w.HadProductTypeChange,
l.CancelMonth,

SUM(losses_plans) AS cancelled_plans,
SUM(losses_ACV) AS cancelled_ACV,
 
SUM(losses_plus_dg_plans), 
SUM(losses_plus_dg_ACV),

SUM(IFNULL(wins_plans,0)) AS wins_plans,
SUM(IFNULL(wins_ACV,0)) AS wins_ACV,

SUM(IFNULL(wins_plus_ug_plans,0)),
SUM(IFNULL(wins_plus_ug_ACV,0))


FROM rpt_main_02.stg_churn_waterfall_losses l
JOIN rpt_main_02.stg_churn_waterfall_wins w 

ON l.bucketID=w.bucketID
AND l.sourceID=w.sourceID
AND l.subsourceID=w.subsourceID
AND l.campaignID=w.campaignID
AND l.segmentID=w.segmentID
AND l.PaymentStartMonth=w.PaymentStartMonth
AND l.`ipCountry`=w.`ipCountry`
AND l.`ipRegion`=w.`ipRegion`
AND l.`ipCity`=w.`ipCity`
AND l.languageFriendly=w.languageFriendly
AND l.productID=w.productID
AND l.paymentTerm=w.paymentTerm
AND l.HadPaymentTermChange=w.HadPaymentTermChange
AND l.HadProductTypeChange=w.HadProductTypeChange

GROUP BY 
w.bucketID, 
w.sourceID, 
w.subsourceID, 
w.campaignID, 
w.segmentID, 
w.PaymentStartMonth,
w.`ipCountry`, w.`ipRegion`, w.`ipCity`,
w.languageFriendly,
l.cancelMonth,
w.productID, 
w.paymentTerm,
w.HadPaymentTermChange,
w.HadProductTypeChange
;





-- Identify and insert all wins into table where there are no cancels for key combo match but there are wins
INSERT INTO rpt_main_02.stg_churn_waterfall_cw 
(
	bucketID, 
	sourceID, 
	subsourceID, 
	campaignID, 
	segmentID, 
	PaymentStartMonth, 
	`ipCountry`, 
	`ipRegion`, 
	`ipCity`, 
	languageFriendly,
	productID, 
	paymentTerm, 
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth, 
	wins_plans, 
	wins_ACV, 
	wins_plans2, 
	wins_ACV2, 
	cancelled_plans, 
	cancelled_ACV, 
	cancelled_plans2, 
	cancelled_ACV2
)

SELECT DISTINCT
	w.bucketID, 
	w.sourceID, 
	w.subsourceID, 
	w.campaignID, 
	w.segmentID, 
	w.PaymentStartMonth, 
	w.`ipCountry`, 
	w.`ipRegion`, 
	w.`ipCity`, 
	w.languageFriendly,
	w.productID, 
	w.paymentTerm, 
	w.HadPaymentTermChange,
	w.HadProductTypeChange,
	w.winMonth, 
	wins_plans, 
	wins_ACV, 
	IFNULL(wins_plus_ug_plans,0),
	IFNULL(wins_plus_ug_ACV,0),
	0,
	0,
	0,
	0
FROM rpt_main_02.stg_churn_waterfall_wins w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_churn_waterfall_cw cw
	WHERE (w.bucketID)= (cw.bucketID)
	AND  (w.sourceID)= (cw.sourceID)
	AND  (w.subsourceID)= (cw.subsourceID)
	AND  (w.campaignID)= (cw.campaignID)
	AND  (w.segmentID)= (cw.segmentID)
	AND  (w.PaymentStartMonth)= (cw.PaymentStartMonth)
	AND  (w.`ipCountry`)=  (cw.`ipCountry`)
	AND  (w.`ipRegion`)=  (cw.`ipRegion`)
	AND  (w.`ipCity`)=  (cw.`ipCity`)
	AND  (w.languageFriendly) = (cw.languageFriendly)
	AND  (w.productID)=(cw.productID)
	AND  (w.paymentTerm)=(cw.paymentTerm)
	AND  (w.HadPaymentTermChange)=(cw.HadPaymentTermChange)
 	AND  (w.HadProductTypeChange)=(cw.HadProductTypeChange)
)
;




-- Identify and insert all cancels into table where there are no wins for key combo match but there are cancels
INSERT INTO rpt_main_02.stg_churn_waterfall_cw 
(
	bucketID, 
	sourceID, 
	subsourceID, 
	campaignID, 
	segmentID, 
	PaymentStartMonth, 
	`ipCountry`, 
	`ipRegion`, 
	`ipCity`, 
	languageFriendly,
	productID, 
	paymentTerm, 
	HadPaymentTermChange,
	HadProductTypeChange,
	effectiveMonth, 
	wins_plans, 
	wins_ACV, 
	wins_plans2, 
	wins_ACV2, 
	cancelled_plans, 
	cancelled_ACV, 
	cancelled_plans2, 
	cancelled_ACV2
)

SELECT DISTINCT
w.bucketID, 
w.sourceID, 
w.subsourceID, 
w.campaignID, 
w.segmentID, 
w.PaymentStartMonth, 
w.`ipCountry`, 
w.`ipRegion`, 
w.`ipCity`, 
w.languageFriendly,
w.productID, 
w.paymentTerm, 
w.HadPaymentTermChange,
w.HadProductTypeChange,
w.CancelMonth, 
0,
0,
0,
0, 
losses_plans, 
losses_ACV, 
losses_plus_dg_plans, 
losses_plus_dg_ACV
FROM rpt_main_02.stg_churn_waterfall_losses w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_churn_waterfall_cw cw
	WHERE (w.bucketID)= (cw.bucketID)
	AND  (w.sourceID)= (cw.sourceID)
	AND  (w.subsourceID)= (cw.subsourceID)
	AND  (w.campaignID)= (cw.campaignID)
	AND  (w.segmentID)= (cw.segmentID)
	AND  (w.PaymentStartMonth)= (cw.PaymentStartMonth)
	AND  (w.`ipCountry`)=  (cw.`ipCountry`)
	AND  (w.`ipRegion`)=  (cw.`ipRegion`)
	AND  (w.`ipCity`)=  (cw.`ipCity`)
	AND (w.languageFriendly) = (cw.languageFriendly)
	AND  (w.`CancelMonth`)= (cw.`effectiveMonth`)
	AND  (w.productID)=(cw.productID)
	AND  (w.paymentTerm)=(cw.paymentTerm)
	AND  (w.HadPaymentTermChange)=(cw.HadPaymentTermChange)
 	AND  (w.HadProductTypeChange)=(cw.HadProductTypeChange)
)
;




-- Select data for report output
DROP TABLE IF EXISTS rpt_main_02.stg_churn_waterfall;

CREATE TABLE rpt_main_02.stg_churn_waterfall
SELECT 	DISTINCT
bucketName AS bucket, 
sourceName AS source, 
subsourceName AS subsource, 
campaignName AS campaign, 
segmentName AS segment,
PaymentStartMonth, 
`effectiveMonth`, 
`ipCountry`,
`ipRegion`,
`ipCity`, 
languageFriendly,
productID,
paymentTerm,
HadPaymentTermChange,
HadProductTypeChange,
SUM(wins_plans) wins_plans,
SUM(wins_ACV) AS wins_ACV,

SUM(wins_plans2) wins_plus_ug_plans,
SUM(wins_ACV2) wins_plus_ug_ACV,

SUM(cancelled_plans) cancelled_plans,
SUM(cancelled_ACV) cancelled_ACV,

SUM(cancelled_plans2) cancelled_plus_dg_plans,
SUM(cancelled_ACV2) cancelled_plus_dg_ACV

FROM rpt_main_02.stg_churn_waterfall_cw a
LEFT JOIN rpt_main_02.dim_bucket db ON a.bucketID=db.bucketID
LEFT JOIN rpt_main_02.dim_source ds ON a.sourceID=ds.sourceID
LEFT JOIN rpt_main_02.dim_subsource dss ON a.subsourceID=dss.subsourceID
LEFT JOIN rpt_main_02.dim_campaign dc ON a.campaignID=dc.campaignID
LEFT JOIN rpt_main_02.dim_segment dseg ON a.segmentID=dseg.segmentID
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
;



SELECT *
FROM rpt_main_02.stg_churn_waterfall
;



/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("churnWaterfallV2.csv");
