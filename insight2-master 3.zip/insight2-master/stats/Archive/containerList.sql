SELECT 
	r.containerName as ContainerName, 
	r.shareCount as ShareCount, 
	r.loadCount as LoadCount, 
	r.gridDataTimestamp as UpdateCount, 
	l.loginCount as OwnerLoginCount, 
	r.sourceContainerID as SourceContainerID, 
	r.sourceContainerName as SourceContainerName
FROM rpt_main_02.rpt_containerList r
JOIN rpt_main_02.rpt_loginCountTotal l ON r.ownerUserID = l.userID;