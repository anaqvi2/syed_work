

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryMonthlyNEWV2.csv insert");

DELETE FROM rpt_main_02.output_RevenueSummaryMonthlyNEW WHERE recordDateTime > (
	SELECT startMonth 
	FROM rpt_main_02.ref_months 
	WHERE startMonth < DATE_ADD(NOW(), INTERVAL -4 DAY) AND endMonth > DATE_ADD(NOW(), INTERVAL -4 DAY));



/*Insert Wins*/
INSERT rpt_main_02.output_RevenueSummaryMonthlyNEW (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime)

SELECT 
months.monthFriendly,
pp.mainContactUserID AS MainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
organization.name AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
NULL,
NULL,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(MIN(hist_paymentProfile.paymentStartDateTime), pp.paymentInsertDate) < 0
	WHEN 1 THEN NULL ELSE DATEDIFF(MIN(hist_paymentProfile.paymentStartDateTime), pp.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID),
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,
Case when hist_paymentProfile.paymentTerm = 12 then 1 else 0 END, 
NULL, 
NULL, 
NULL,
NULL,
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm,2) AS NewMonthlyPayment,
0 AS oldMonthlyPayment,
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm,2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime,
hist_paymentProfile.modifyDateTime,

CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,

rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'WINS' AS recordtype,

hist_paymentProfile.paymentStartDateTime

FROM rpt_main_02.hist_paymentProfile
JOIN rpt_main_02.ref_months months ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND paymentStartDateTime BETWEEN months.startMonth AND months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON pp.mainContactUserID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON pp.mainContactUserID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.planRate_USD > 0
AND hist_paymentProfile.paymentType != 4

GROUP BY 1,2
;

/*Insert Upgrades*/
INSERT rpt_main_02.output_RevenueSummaryMonthlyNEW (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime)

(SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
organization.name AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
Case when hist_paymentProfile.paymentTerm = 12 then 1 else 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
Case when oldHPP.paymentTerm = 12 then 1 else 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm), 2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,

rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime

FROM rpt_main_02.ref_months months
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.rpt_paymentProfile ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.mainContactUserID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.accountType !=2 
AND hist_paymentProfile.planRate_USD > 0
AND oldHPP.planRate_USD > 0
AND oldHPP.productID >= 3
AND oldHPP.planRate_USD/oldHPP.paymentTerm < hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4

GROUP BY 1,2)

UNION 

(SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
orgHPP.paymentProfileID,
orgHPP.ownerID,
organization.name AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(orgHPP.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(orgHPP.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
DATE_FORMAT(orgHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(orgHPP.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(orgHPP.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(orgHPP.productID) AS NewProductName,
orgHPP.userLimit AS NewUserLimit,
orgHPP.paymentTerm AS NewPaymentTerm,
Case when orgHPP.paymentTerm = 12 then 1 else 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
Case when oldHPP.paymentTerm = 12 then 1 else 0 END, 
ROUND(orgHPP.planRate_USD/orgHPP.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
ROUND((orgHPP.planRate_USD/orgHPP.paymentTerm), 2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

orgHPP.insertDateTime AS paymentProfileInsertDateTime,
orgHPP.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,

rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime

FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.hist_paymentProfile orgHPP ON orgHPP.paymentProfileID = hist_paymentProfile.parentPaymentProfileID
	AND hist_paymentProfile.modifyDateTime = orgHPP.modifyDateTime
	AND orgHPP.hist_effectiveThruDateTime > months.endMonth
	AND orgHPP.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.rpt_paymentProfile ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.mainContactUserID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
AND oldHPP.productID >= 3
AND oldHPP.planRate_USD > 0 
AND oldHPP.accountType = 1 AND hist_paymentProfile.accountType = 2
AND hist_paymentProfile.parentPaymentProfileID IS NOT NULL
AND oldHPP.planRate_USD/oldHPP.paymentTerm < orgHPP.planRate_USD/orgHPP.paymentTerm
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4

GROUP BY 1,2)

ORDER BY 1
;

/*Insert Downgrades*/
INSERT rpt_main_02.output_RevenueSummaryMonthlyNEW (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime)

SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
oldHPP.paymentProfileID,
hist_paymentProfile.ownerID,
organization.name, 
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
Case when hist_paymentProfile.paymentTerm = 12 then 1 else 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
Case when oldHPP.paymentTerm = 12 then 1 else 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
CASE WHEN oldHPP.planRate_USD = 0 THEN ROUND(orgHPP.planRate_USD/orgHPP.paymentTerm,2)
	ELSE ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm,2)  END AS OldMonthlyPayment,
CASE WHEN oldHPP.planRate_USD = 0 THEN ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm),2) - ROUND((orgHPP.planRate_USD/orgHPP.paymentTerm),2)
	ELSE ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm),2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm),2) END AS MonthlyPaymentChange,
hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,	
hist_paymentProfile.modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,

rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'DOWNGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime

FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile orgHPP ON oldHPP.parentPaymentProfileID = orgHPP.paymentProfileID 
	AND oldHPP.modifyDateTime = orgHPP.modifyDateTime
JOIN rpt_main_02.rpt_paymentProfile ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.mainContactUserID=rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
AND hist_paymentProfile.productID >= 3
AND hist_paymentProfile.planRate_USD > 0
AND hist_paymentProfile.accountType != 2 
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4

HAVING OldMonthlyPayment > NewMonthlyPayment

ORDER BY 1
;

/*Insert Losses*/
INSERT rpt_main_02.output_RevenueSummaryMonthlyNEW (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime)

SELECT 
months.monthFriendly,
ppc.mainContactUserID AS MainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
organization.name AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS NewAccountType,
DATE_FORMAT(oldHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID),
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,
Case when hist_paymentProfile.paymentTerm = 12 then 1 else 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID),
oldHPP.userLimit,
oldHPP.paymentTerm,
Case when oldHPP.paymentTerm = 12 then 1 else 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
0 - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,

rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'LOSSES' AS recordtype,

hist_paymentProfile.modifyDateTime

FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -4 DAY)
JOIN rpt_main_02.rpt_paymentProfile ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.mainContactUserID=rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.arc_paidAccountTransfers exclude on ppc.mainContactUserID = exclude.TransferFromUserID and exclude.transferStatus = "true"

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
AND hist_paymentProfile.productID IN (0,2)
AND hist_paymentProfile.accountType != 2 
AND hist_paymentProfile.planRate_USD = 0
AND oldHPP.productID >= 3 
AND oldHPP.planRate_USD > 0
AND exclude.TransferFromUserID IS NULL
AND hist_paymentProfile.paymentType != 4

ORDER BY 1
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryMonthlyNEWV2.csv insert");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryMonthlyNEWV2.csv select");

SELECT rsm.*, ua.languageFriendly 
FROM rpt_main_02.output_RevenueSummaryMonthlyNEW rsm
LEFT OUTER JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryMonthlyNEWV2.csv select");
