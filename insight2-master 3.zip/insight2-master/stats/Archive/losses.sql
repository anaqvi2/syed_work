
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("lossesV2.csv");


/*Generating lossesV2.csv*/
SELECT DISTINCT 
hppNEW.paymentProfileID AS 'Payment Profile ID', 
hppNEW.ownerID AS 'Owner ID', 
CASE hppNEW.accountType
 WHEN 1 THEN u.emailAddress
 WHEN 3 THEN opp.mainContactEmailAddress
 ELSE "ERROR" END AS 'Email Address',
c.sheetCount AS 'Current Sheet Count',

DATE_FORMAT(hppOLD.paymentStartDateTime, '%Y-%m-%d') AS 'Old Payment Start Date',
DATE_FORMAT(hppOLD.paymentStartDateTime, '%b%Y') AS 'Old Payment Start Month',

DATE_FORMAT(hppNEW.modifyDateTime, '%Y-%m-%d') AS 'Cancel Date',
DATE_FORMAT(hppNEW.modifyDateTime, '%Y-%U') AS 'Cancel Week',
DATE_FORMAT(hppNEW.modifyDateTime, '%b%Y') AS 'Cancel Month',

DATEDIFF(hppNEW.modifyDateTime, hppOLD.modifyDateTime) AS 'Days To Cancel',

hppOLD.productID AS 'Old ProductID', 
hppNEW.productID AS 'Canceled Product ID', 
pp.productID AS 'Current Product ID',

rpt_main_02.SMARTSHEET_PRODUCTNAME(hppOLD.productID) AS 'Old Product Name',
hppOLD.userLimit AS 'Old User Limit',
rpt_main_02.SMARTSHEET_PRODUCTNAME(hppNEW.productID) AS 'Canceled Product Name',
hppNEW.userLimit AS 'New User Limit',
rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) AS 'Current Product Name',
pp.userLimit AS 'Current User Limit',

hppOLD.planRate_USD AS 'Old Payment Total', 
hppNEW.planRate_USD AS 'Cancel Payment Total',

hppOLD.planRate_USD / hppOLD.paymentTerm AS 'Old Monthly Revenue',
0 - (hppOLD.planRate_USD / hppOLD.paymentTerm) AS 'Net Decrease Monthly Revenue',
	
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hppOLD.paymentType) AS 'Old Payment Type',
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hppNEW.paymentType) AS 'Canceled Payment Type',
rpt_main_02.SMARTSHEET_PAYMENTTYPE(pp.paymentType) AS 'Current Payment Type',

rpt_signupSourceUser.signupInsertDateTime 	AS SignupDateTime,
DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%b%Y') AS SignupMonth,

CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 		AS SignupCampaign,
rpt_signupSourceUser.segment 		AS SignupSegment,

/* quote to prevent odd characters causing problems in Excel and so Excel won't try to interpret keywords that start with + as a formula */
QUOTE(rpt_signupSourceUser.keyword) 		AS 'Signup Keyword',

rpt_signupSourceUser.referrer 		AS SignupReferrer,
rpt_signupSourceUser.queryValue		AS SignupQueryValue,
rpt_signupSourceUser.mySmartsheetReferralLink AS SignupMySmartsheetReferralLink,
rpt_signupSourceUser.mySmartsheetReferralLinkFriendly AS SignupMySmartsheetReferralLinkFriendly,
rpt_signupSourceUser.appLaunchType 		AS SignupShortcutType,
rpt_signupSourceUser.appLaunchParm1 	AS SignupShourcutParm1,
rpt_signupSourceUser.appLaunchParm1Friendly	AS SignupShourcutParm1Friendly


FROM rpt_main_02.hist_paymentProfile hppNEW
JOIN rpt_main_02.hist_paymentProfile hppOLD ON hppNEW.paymentProfileID = hppOLD.paymentProfileID 
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = hppNEW.paymentProfileID 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfileSheetCount c ON hppNEW.paymentProfileID = c.paymentProfileID
LEFT OUTER JOIN rpt_main_02.userAccount u ON hppNEW.ownerID = u.userID AND hppNEW.accountType = 1
LEFT OUTER JOIN rpt_main_02.organization o ON hppNEW.ownerID = o.organizationID AND hppNEW.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile opp ON o.paymentProfileID = opp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON hppNEW.ownerID = rpt_signupSourceUser.userID


WHERE hppNEW.modifyDateTime >= '2009-01-01'
AND (hppNEW.productID = 0 OR hppNEW.productID = 2)
AND hppOLD.productID >= 3
AND hppOLD.productID > hppNEW.productID
AND hppOLD.planRate_USD > 0
AND hppNEW.planRate_USD != hppOLD.planRate_USD
AND hppNEW.modifyDateTime = hppOLD.hist_effectiveThruDateTime + INTERVAL 1 SECOND
ORDER BY hppNEW.modifyDateTime;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("lossesV2.csv");

