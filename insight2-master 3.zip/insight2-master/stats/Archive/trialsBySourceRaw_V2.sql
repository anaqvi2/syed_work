
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("trialsBySourceRaw_V2.csv");


/*Generating trialsBySourceRaw_V2.csv*/
SELECT rpt_trials.paymentProfileID,
	rpt_paymentProfile.accountType,
	u.locale,
	DATE_FORMAT(trialDateTime, '%Y') AS 'TrialStartYear',
	DATE_FORMAT(trialDateTime, '%Y-%m-%d') AS 'Trial Start Date',
	DATE_FORMAT(trialDateTime, '%Y*%m(%b)') AS 'Trial Start Month',	
	rpt_main_02.SMARTSHEET_WEEK(trialDateTime) AS 'Trial Start Week',

	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket
	END AS 'Bucket',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',
	
	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END AS 'Signup SubSource Friendly',

	rpt_signupSource.segment,
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.hasPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.hasPaid
	END AS 'has Paid',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN 0  
		ELSE 1 END AS 'User Signed Up',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	COUNT(snapshotDate) AS daysWellQualified,
	
	CASE WHEN COUNT(snapshotDate) > 0 THEN 1 ELSE 0 END AS EverWellQual

FROM rpt_main_02.rpt_trials rpt_trials
JOIN rpt_main_02.userAccount u ON rpt_trials.userID = u.userID
JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON rpt_paymentProfile.paymentProfileID = rpt_trials.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON u.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON u.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON arc_wellQualifiedLeads.userID = rpt_trials.userID AND associatedWithPaidAccount = 0

WHERE rpt_trials.firstTrial = 1 AND rpt_trials.trialType = 1

GROUP BY 1,2
ORDER BY trialDateTime
LIMIT 123456789
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("trialsBySourceRaw_V2.csv");

