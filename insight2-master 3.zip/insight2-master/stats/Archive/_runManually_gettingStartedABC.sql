select "******** rpt_abTestInfo table - start ******** ", NOW();


/* this test is over.  keeping code for manual use if needed. */ 



/* from prepV2Data.sql */
DROP TABLE IF EXISTS rpt_abTestInfo;
CREATE TABLE IF NOT EXISTS 
rpt_abTestInfo(
	userID BIGINT, 
	gettingStartedAbcTest TINYINT, 
	openedOverviewVideo TINYINT, 
	openedColumnPropertiesForm TINYINT, 
	disabledHelpAutoShow TINYINT, 
	PRIMARY KEY(userID));
INSERT rpt_abTestInfo(userID, gettingStartedAbcTest, openedOverviewVideo, openedColumnPropertiesForm, disabledHelpAutoShow)
select u.userID, 
	(select min(parm3)   from rpt_main_02.rpt_clientGlobalLogRollup where parm1 = 12001 and insertByUserID = u.userID),
	(select count(*) from rpt_main_02.rpt_clientGlobalLogRollup  where parm1 = 8011 and insertByUserID = u.userID),
	(select count(*) from rpt_main_02.rpt_clientGlobalLogRollup  where (parm1 = 7043 or parm1 = 7015) and insertByUserID = u.userID),
	(select count(*) from rpt_main_02.rpt_clientGlobalLogRollup  where parm1 = 1804 and insertByUserID = u.userID)
from userAccount u;




/* outputting the data feed */


select 	userAccount.userID, 
	userAccount.emailAddress, 
	userAccount.insertDateTime,

	rpt_paymentProfile.productName as ProductName,
	rpt_paymentProfile.countAsPaid as "Count as Paid",

	rpt_paymentProfile.paymentStartMonth as PaymentStartMonth,
	rpt_paymentProfile.paymentStartWeek as PaymentStartWeek,
	rpt_paymentProfile.paymentStartDay as PaymentStartDay,

	rpt_paymentProfile.daysToBuy as DaysToBuy,

	rpt_paymentProfile.paymentInsertMonth as PaymentInsertMonth,
	rpt_paymentProfile.paymentInsertWeek as PaymentInsertWeek,
	rpt_paymentProfile.paymentInsertDay as PaymentInsertDay,

	/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%b%y') as SignupMonth,
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%U') as SignupWeek,
	DAYOFYEAR(rpt_signupSourceUser.signupInsertDateTime) as SignupDay,

	CASE rpt_signupSourceUser.sourceFriendly is null
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END as SignupSourceFriendly,

	CASE rpt_signupSourceUser.subSourceFriendly is null
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END as SignupSubSourceFriendly,

	rpt_signupSourceUser.campaign 		as SignupCampaign,
	rpt_signupSourceUser.segment 		as SignupSegment,
	rpt_signupSourceUser.keyword 		as SignupKeyword,

	rpt_loginCountTotal.loginCount,	
	rpt_loginCountTotal.firstLogin,	
	rpt_loginCountTotal.firstLoginMonth,	
	rpt_loginCountTotal.firstLoginWeek,	
	rpt_loginCountTotal.firstLoginDay,	

	rpt_loginCountTotal.daysSinceFirstLogin,	
	rpt_loginCountTotal.daysSinceLastLogin,	
	rpt_loginCountTotal.loginStrength,	
	rpt_loginCountTotal.lastLogin,	
	rpt_loginCountTotal.lastLoginWeek,	
	rpt_loginCountTotal.daysActive,

	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END as 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1
		ELSE 0
	END as 'User Logged In At Least Twice',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END as 'User Logged In At Least 4 Times',

	CASE rpt_featureCountRollupByUser.sharingCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END as 'User Shared Sheet',

	rpt_containerCountsByUser.sheetCount,
	rpt_featureCountRollupByUser.last7DaysLoginCount as 'Last 7 Days Login Count',
	rpt_featureCountRollupByUser.last30DaysLoginCount as 'Last 30 Days Login Count',
	rpt_featureCountRollupByUser.contactCount,
	rpt_featureCountRollupByUser.sharingCount,
	rpt_featureCountRollupByUser.attachmentCount,


	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END as 'Is Strong Lead',


	CASE rpt_paymentProfile.paymentStartDateRaw is not null and DATEDIFF(CURRENT_DATE(), rpt_paymentProfile.paymentStartDateRaw) <= 35
		WHEN 1 THEN 1
		ELSE 0
	END as 'Is In 35 Day Window',

	(rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) as 'Lead Strength',

	rpt_clientLogCountsByUserArchived.firstDayLogCount as firstDayLogCount,
	rpt_clientLogCountsByUserArchived.firstWeekLogCount as firstWeekLogCount,
	rpt_clientLogCountsByUserArchived.lastWeekLogCount,
	rpt_clientLogCountsByUserArchived.lifetimeLogCount as lifetimeLogCount,

	rpt_containerCountsByUser.sheetsSharedFromPaidAccount as 'Sheets Shared From Paid Account', 
	CASE rpt_containerCountsByUser.sheetsSharedFromPaidAccount > 0
		WHEN 1 THEN 1
		ELSE 0
	END as 'Is Associated With Paid Account',

	CASE rpt_clientLogCountsByUserArchived.firstWeekLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END as 'Is First Week Log Count >= 400',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END as 'Is Lifetime Log Count >= 400',

	rpt_abTestInfo.gettingStartedAbcTest,

	CASE rpt_abTestInfo.openedOverviewVideo > 0
		WHEN 1 THEN 1
		ELSE 0
	END as 'openedOverviewVideo',

	CASE rpt_abTestInfo.openedColumnPropertiesForm > 0
		WHEN 1 THEN 1
		ELSE 0
	END as 'openedColumnPropertiesForm',

	CASE rpt_abTestInfo.disabledHelpAutoShow > 0
		WHEN 1 THEN 1
		ELSE 0
	END as 'disabledHelpAutoShow'


from userAccount userAccount
  left outer join userAccount userAccount2		on userAccount.insertByUserID = userAccount2.userID
  left outer join rpt_main_02.rpt_paymentProfile  			on userAccount.userID = rpt_paymentProfile.ownerID
  left outer join rpt_main_02.rpt_signupSource as rpt_signupSourceUser on userAccount.userID = rpt_signupSourceUser.userID
  left outer join rpt_main_02.rpt_featureCountRollupByUser   	on userAccount.userID = rpt_featureCountRollupByUser.userID
  left outer join rpt_main_02.rpt_loginCountTotal 			on userAccount.userID = rpt_loginCountTotal.userID
  left outer join rpt_main_02.rpt_containerCountsByUser 		on userAccount.userID = rpt_containerCountsByUser.userID
  left outer join rpt_main_02.rpt_clientLogCountsByUserArchived	on userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  left outer join rpt_main_02.rpt_domainRollup 			on rpt_featureCountRollupByUser.domain 	= rpt_domainRollup.domain
  left outer join rpt_main_02.rpt_userAncestor 			on userAccount.emailAddress 	= rpt_userAncestor.userEmailAddress
  left outer join rpt_main_02.rpt_signupSource as rpt_signupSourceAncestor	on rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
  left outer join rpt_abTestInfo			on userAccount.userID = rpt_abTestInfo.userID
where userAccount.insertDateTime >= '2009/11/01'


