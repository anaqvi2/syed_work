SELECT 
	browser AS 'Browser',
	browserBucket AS 'Browser Bucket',
	operatingSystem AS 'Operating System',
	device	AS 'Device',
	userAgent AS 'User Agent',
	COUNT(*) AS 'User Agent Session Count' 
	FROM rpt_main_02.rpt_sessionLog
GROUP BY userAgent

