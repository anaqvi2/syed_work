select c.insertByUserID as UserID, 
       u.emailAddress as EmailAddress, 
       IFNULL(su.signupRequestID, 0) as signupID,
       DATE_FORMAT(su.signupInsertDateTime, '%y') as signupYear,
       DATE_FORMAT(su.signupInsertDateTime, '%m') as signupMonth,
       DATE_FORMAT(su.signupInsertDateTime, '%U') as signupWeek,
       DATE_FORMAT(su.signupInsertDateTime, '%d') as signupDay,
       su.classicCustomer as ClassicCustomer,
       su.source as SignupSource, 
       su.campaign as SignupCampaign, 
       su.segment as SignupSegment, 
       su.keyword as SignupKeyword, 
       su.referrer as SignupReferrer, 
       su.appLaunchType as SignupShortcutType, 
       su.appLaunchParm1 as SignupShourcutParm1, 
       CASE c.containerType
         WHEN 0 THEN "Workspace"
         WHEN 1 THEN "Folder"
         WHEN 2 THEN "Sheet"
         WHEN 3 THEN "Report"
         WHEN 4 THEN "Filter"
         WHEN 5 THEN "UIObject"
         WHEN 6 THEN "Shortcut-Sheet"
         WHEN 7 THEN "Shortcut-Report"
       END as ContainerType,
       count(*) as Count
from container c
  join userAccount u on c.insertByUserID = u.userID
  left outer join rpt_main_02.rpt_signupSource su on c.insertByUserID = su.userID
where deleteStatus = 0
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16;
