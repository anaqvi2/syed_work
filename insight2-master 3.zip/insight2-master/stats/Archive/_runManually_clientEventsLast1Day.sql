SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT  
	ce.sessionLogID,
	ce.clientEventID,
	ce.eventDateTime,
        sl.emailAddress AS email,
	clientEventLookup2.description AS ActionFriendly,
  	clientEventLookup1.description AS OjbectFriendly,
	REPLACE(ce.parm1String,',','') AS parm1String,
	ce.parm1Int AS parm1Int,
	rpt_loginCountTotal.loginCount 	AS LoginCount

FROM ss_log_02.clientEvent ce
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog sl 				ON ce.sessionLogID = sl.sessionLogID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal rpt_loginCountTotal 	ON sl.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN ss_log_02.clientEventLookup clientEventLookup1 	ON clientEventLookup1.clientEventLookupID = ce.objectID
LEFT OUTER JOIN ss_log_02.clientEventLookup clientEventLookup2 	ON clientEventLookup2.clientEventLookupID = ce.actionID
WHERE ce.eventDateTime > DATE_SUB(CURDATE(), INTERVAL 1 DAY) 
ORDER BY sessionLogID, clientEventID;
