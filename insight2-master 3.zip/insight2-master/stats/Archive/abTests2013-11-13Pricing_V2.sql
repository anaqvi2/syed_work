/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2013-11-16Pricing_V2.csv");




SELECT /*Generating abTests2013-11-16Pricing_V2.csv*/
	userAccount.userID AS 'User ID', 
	userAccount.emailAddress AS 'E-mail Address', 
	ss1.valueNumeric AS 'ENTERPRISE_PRICING',
	ss2.valueNumeric AS 'UPGRADE_PAYMENT_TERM',
	DATE_FORMAT(ss1.insertDateTime, '%Y-%m-%d') AS 'ABTestDate1',
	DATE_FORMAT(ss2.insertDateTime, '%Y-%m-%d') AS 'ABTestDate2',
	
	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 

	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Lifetime Log Count >= 400',
	
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'	ELSE '0' END AS 'License Accepted',
	
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'	ELSE '0' END AS 'Password Set',
	
	fcflrbu.paymentFormViewCount AS 'Payment Form View Count',
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Viewed Payment Form At Least Once',
		
	userAccount.countryFriendly AS Country,
	CASE WHEN userAccount.countryFriendly = "United States" THEN "1" ELSE "0" END AS "is US",
	userAccount.languageFriendly AS "Language",
	CASE WHEN userAccount.languageFriendly  = "English" THEN "1" ELSE "0" END AS "is English",
	MAX(rpt_trials.trialDateTime),
	CASE WHEN MAX(rpt_trials.trialDateTime) IS NULL THEN 0 ELSE 1 END AS HadTrial,
	
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
	
	rpt_signupRequestTrackingItem.itemValue AS ExperimentNumber,
	CASE WHEN INSTR(rpt_signupRequestTrackingItem.itemValue,'488072-88') THEN 
		CASE WHEN rpt_signupRequestTrackingItem.itemValue LIKE "%.1" THEN "B" WHEN rpt_signupRequestTrackingItem.itemValue LIKE "%.0" THEN "A" ELSE "Error" END
		ELSE 0 END AS "HomePageExperiment",
		
		
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0 ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL ELSE 	
		CASE rpt_paymentProfile.countAsPaid = 0 WHEN 1 THEN NULL ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm END
	END AS 'Monthly Revenue',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0 ELSE 
		CASE rpt_paymentProfile.paymentTerm WHEN 12 THEN 1 ELSE 0 END	
	END AS 'Is Annual',
			
	rpt_paymentProfile.paymentTermFriendly AS 'Payment Term',
	rpt_paymentProfile.productName AS 'Product Name',
	rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm AS MonthlyPaymentUSD,
	rpt_signupSource.appLaunchType,
	CASE WHEN ((rpt_signupSource.appLaunchType = 2 AND rpt_signupSource.appLaunchParm1Friendly) OR rpt_signupSource.appLaunchType IN (5,6,10,12,14)) THEN 1
		ELSE 0 END AS UsedDC,
		
	CASE WHEN ss1.valueNumeric IS NULL THEN NULL ELSE rpt_paymentProfile.sheetCount END AS SheetCount,
	CASE WHEN rpt_paymentProfile.productID > 2 THEN 1 ELSE 0 END AS CountAsPaidProduct,
	rpt_paymentProfile.hasPaid,
	rpt_paymentProfile.daysToBuy,
	SUM(logCount) AS EnterpriseContactFormLoads,
	CASE WHEN SUM(logCount) > 0 THEN 1 ELSE 0 END AS LoadedEnterpriseContactForm,
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise?",
	rpt_userIPLocation.ipCountry AS IPCountry,
	CASE rpt_userIPLocation.ipCountry 
		WHEN "United States" THEN 1
		WHEN "Australia" THEN 2
		WHEN "Canada" THEN 2
		WHEN "United Kingdom" THEN 2
		/*Euro with Language Support*/
		WHEN "Italy" THEN 2
		WHEN "Germany" THEN 2		
		WHEN "Ireland" THEN 2
		WHEN "France" THEN 2		
		WHEN "Austria" THEN 2		
		WHEN "Spain" THEN 2		
		WHEN "Portugal" THEN 2		
		/*Currency support without Language*/
		WHEN "Andorra" THEN 3
		WHEN "Belgium" THEN 3
		WHEN "Cyprus" THEN 3
		WHEN "Estonia" THEN 3
		WHEN "Finland" THEN 3
		WHEN "Greece" THEN 3
		WHEN "Kosovo" THEN 3
		WHEN "Luxembourg" THEN 3
		WHEN "Malta" THEN 3
		WHEN "Monaco" THEN 3
		WHEN "Montenegro" THEN 3
		WHEN "Netherlands" THEN 3
		WHEN "San Marino" THEN 3
		WHEN "Slovakia" THEN 3
		WHEN "Slovenia" THEN 3
		WHEN "Vatican City" THEN 3
		WHEN "Japan" THEN 3
		/*Language Support without Currency support*/
		WHEN "India" THEN 4
		WHEN "New Zealand" THEN 4
		WHEN "Mexico" THEN 4
		WHEN "Brazil" THEN 4
		WHEN "Colombia" THEN 4
		ELSE 0 END AS "CountryGroup",
	
	(SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2151 AND logDate < "2014-01-02"  /*Upgrade Step One */ 
	AND glr.insertByUserID = userAccount.userID) AS UpgradeStepOneBeforeLaunch,
	
	(SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2151   /*Upgrade Step One */ 
	AND glr.insertByUserID = userAccount.userID) AS UpgradeStepOneCount,
	
	CASE WHEN (SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2151
	AND glr.insertByUserID = userAccount.userID) > 0 THEN 1 ELSE 0 END AS ViewedUpgradeStepOne,
	
	
	(SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2152	/*Upgrade Step Two */
	AND glr.insertByUserID = userAccount.userID) AS UpgradeStepTwoCount,
	
	CASE WHEN (SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2152
	AND glr.insertByUserID = userAccount.userID) > 0 THEN 1 ELSE 0 END AS ViewedUpgradeStepTwo,
		
		
	(SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2153	/*Upgrade Step Three */
	AND glr.insertByUserID = userAccount.userID) AS UpgradeStepThreeCount,  
	
	CASE WHEN (SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2153
	AND glr.insertByUserID = userAccount.userID) > 0 THEN 1 ELSE 0 END AS ViewedUpgradeStepThree,
	
	
	(SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2155	/*Confirm Page*/
	AND glr.insertByUserID = userAccount.userID) AS ConfirmPageCount,  
	
	CASE WHEN (SELECT SUM(logCount) FROM rpt_main_02.arc_clientEventRollup glr WHERE objectID = 2155
	AND glr.insertByUserID = userAccount.userID) > 0 THEN 1 ELSE 0 END AS ViewedConfirmPage

FROM rpt_main_02.userAccount 
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss1 ON userAccount.userID = ss1.userID AND ss1.siteSettingElementName = 'SS_ABTEST_ENTERPRISE_PRICING'
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss2 ON userAccount.userID = ss2.userID AND ss2.siteSettingElementName = 'SS_ABTEST_UPGRADE_PAYMENT_TERM'
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON userAccount.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem  ON rpt_signupSource.signupRequestID = rpt_signupRequestTrackingItem.signupRequestID AND itemName = "utm_expid" 
LEFT OUTER JOIN rpt_main_02.rpt_trials ON userAccount.userID = rpt_trials.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON userAccount.userID = arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType != 2
LEFT OUTER JOIN rpt_main_02.arc_clientEventRollup ON userAccount.userID = arc_clientEventRollup.insertByUserID AND objectID = 2156
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON userAccount.userID = rpt_userIPLocation.userID

WHERE (ss1.siteSettingElementName = 'SS_ABTEST_ENTERPRISE_PRICING' OR ss2.siteSettingElementName ='SS_ABTEST_UPGRADE_PAYMENT_TERM') 
AND DATE_FORMAT(ss1.insertDateTime, '%Y-%m-%d') >"2014-01-01"
AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "xxxSunday"

GROUP BY 1,2,3,4
ORDER BY 4,1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2013-11-16Pricing_V2.csv");
