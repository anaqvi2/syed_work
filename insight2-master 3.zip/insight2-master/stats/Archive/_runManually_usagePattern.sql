
select "******************************************************************************************************************************", NOW();


/*

New Report Table: rpt_usagePattern

General Data Columns:
userID             = userID
isPayingCustomer   = Paying Custormer (boolean)
firstLoginDuration = Elapsed Time of First Login
loginsToPurchase   = Number of times logged in prior to purchase

Usage Data Columns - First instance of each:
sheetDateTime          = New Blank Sheet
templateDateTime       = New Sheet from Template
gettingStartedDateTime = View Getting Started Tab
sheetTipsDateTime      = View Sheet Tips & Hints

*/

select "******** rpt_usagePattern table - start ******** ", NOW();

/* create rpt_usagePattern table */
DROP TABLE IF EXISTS rpt_usagePattern;
CREATE TABLE rpt_usagePattern (
    userID                  BIGINT              NOT NULL,
    isPayingCustomer        BOOLEAN,
    firstLoginDuration      TIME,
    loginsToPurchase        INT,
    dateTime_sheet          DATETIME,
    dateTime_template       DATETIME,
    dateTime_gettingStarted DATETIME,
    dateTime_sheetTips      DATETIME,
    sequence_sheet          INT,
    sequence_template       INT,
    sequence_gettingStarted INT,
    sequence_sheetTips      INT,
    PRIMARY KEY(userID)
);


select "******** load all userID into rpt_usagePattern table - start ******** ", NOW();

/* load all userID into rpt_usagePattern */
INSERT INTO rpt_usagePattern (userID, isPayingCustomer)
SELECT userID, false from userAccount;


select "******** Paying Custormer (boolean) - start ******** ", NOW();
/* Paying Custormer (boolean) */
UPDATE rpt_usagePattern AS up
SET    up.isPayingCustomer = true
WHERE  up.userID IN (select distinct(pt.userID)
                     from   paymentTransaction AS pt
                     where  pt.paymentAmount is not null
                     and    pt.paymentAmount > 0
                     and    pt.userID = up.userID);

select "******** Elapsed Time of First Login - start ******** ", NOW();
/* Elapsed Time of First Login */
UPDATE rpt_usagePattern AS up
SET    up.firstLoginDuration = (SELECT sl1.sessionLength
                               from   rpt_main_02.rpt_sessionLog as sl1
                               where  sl1.loginAuthResult > 0
                               and    sl1.userID = up.userID
                               and    sl1.sessionLogID    = (select min(sl2.sessionLogID)
                                                             from   rpt_main_02.rpt_sessionLog as sl2
                                                             where  sl2.userID = up.userID));

select "******** Number of times logged in prior to purchase - start ******** ", NOW();
/* Number of times logged in prior to purchase */
UPDATE rpt_usagePattern AS up
SET    up.loginsToPurchase = 1 + (select count(sl.sessionLogID)
                              from   sessionLog as sl
                              where  sl.loginAuthResult = 1
                              and    sl.userID = up.userID
                              and    sl.insertDateTime <= (select min(pt.insertDateTime)
                                                           from   paymentTransaction as pt
                                                           where  pt.userID        = up.userID
                                                           and    pt.paymentAmount > 0))
where up.isPayingCustomer = true;

select "******** New Blank Sheet - start ******** ", NOW();
/* New Blank Sheet */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheet = (select min(c1.insertDateTime)
                            from   container as c1
                            where  c1.insertByUserID = up.userID
                            and    c1.containerType = 2
                            and    c1.templateStatus = 0
                            and    (c1.sourceID is null or c1.sourceID < 1000000));


 select "******** New Sheet from Template - start ******** ", NOW();                           
/* New Sheet from Template */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_template = (select min(c1.insertDateTime)
                               from   container as c1
                                     ,container as c2
                               where  c1.containerType = 2
                               and    c1.insertByUserID = up.userID
                               and    c1.sourceID = c2.containerID
                               and    c2.templateStatus != 0
                               and    c1.templateStatus = 0);


select "******** OPS DB: View Getting Started Tab - start ******** ", NOW(); 
/* OPS DB: View Getting Started Tab */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_gettingStarted = (select min(rl.insertDateTime)
                                     from   ss_log_02.requestLog as rl
                                     where  rl.formName   = "fn_eventLog"
                                     and    rl.insertByUserID = up.userID
                                     and    rl.formAction = "gl"
                                     and    rl.parm1      = 104);


select "******** OPS DB: View Sheet Tips & Hints - start ******** ", NOW(); 
/* OPS DB: View Sheet Tips & Hints */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheetTips = (select min(rl.insertDateTime)
                                from   ss_log_02.requestLog as rl
                                where  rl.formName   = "fn_eventLog"
                                and    rl.insertByUserID = up.userID
                                and    rl.formAction = "gl"
                                and    rl.parm1      = 8202);





select "******** initializing for PASS 1 - start ******** ", NOW(); 
UPDATE rpt_usagePattern AS up
SET    up.sequence_sheet          = 0,
       up.sequence_template       = 0,
       up.sequence_gettingStarted = 0,
       up.sequence_sheetTips      = 0;


UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheet = "9999-12-31 00:00:00"
WHERE  up.dateTime_sheet is null;

UPDATE rpt_usagePattern AS up
SET    up.dateTime_template = "9999-12-31 00:00:00"
WHERE  up.dateTime_template is null;

UPDATE rpt_usagePattern AS up
SET    up.dateTime_gettingStarted = "9999-12-31 00:00:00"
WHERE  up.dateTime_gettingStarted is null;

UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheetTips = "9999-12-31 00:00:00"
WHERE  up.dateTime_sheetTips is null;



select "******** PASS 1 - start ******** ", NOW(); 
/* PASS 1 */
update rpt_usagePattern
set sequence_sheet = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheet = "9999-12-31 00:00:00"
WHERE dateTime_sheet < "9999-12-31 00:00:00"
and   dateTime_sheet <= dateTime_template
and   dateTime_sheet <= dateTime_gettingStarted
and   dateTime_sheet <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_template = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_template = "9999-12-31 00:00:00"
WHERE dateTime_template < "9999-12-31 00:00:00"
and   dateTime_template <= dateTime_sheet
and   dateTime_template <= dateTime_gettingStarted
and   dateTime_template <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_gettingStarted = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_gettingStarted = "9999-12-31 00:00:00"
WHERE dateTime_gettingStarted < "9999-12-31 00:00:00"
and   dateTime_gettingStarted <= dateTime_sheet
and   dateTime_gettingStarted <= dateTime_template
and   dateTime_gettingStarted <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_sheetTips = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheetTips = "9999-12-31 00:00:00"
WHERE dateTime_sheetTips < "9999-12-31 00:00:00"
and   dateTime_sheetTips <= dateTime_sheet
and   dateTime_sheetTips <= dateTime_template
and   dateTime_sheetTips <= dateTime_gettingStarted;

select "******** PASS 2 - start ******** ", NOW(); 
/* PASS 2 */
update rpt_usagePattern
set sequence_sheet = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheet = "9999-12-31 00:00:00"
WHERE dateTime_sheet < "9999-12-31 00:00:00"
and   dateTime_sheet <= dateTime_template
and   dateTime_sheet <= dateTime_gettingStarted
and   dateTime_sheet <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_template = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_template = "9999-12-31 00:00:00"
WHERE dateTime_template < "9999-12-31 00:00:00"
and   dateTime_template <= dateTime_sheet
and   dateTime_template <= dateTime_gettingStarted
and   dateTime_template <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_gettingStarted = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_gettingStarted = "9999-12-31 00:00:00"
WHERE dateTime_gettingStarted < "9999-12-31 00:00:00"
and   dateTime_gettingStarted <= dateTime_sheet
and   dateTime_gettingStarted <= dateTime_template
and   dateTime_gettingStarted <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_sheetTips = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheetTips = "9999-12-31 00:00:00"
WHERE dateTime_sheetTips < "9999-12-31 00:00:00"
and   dateTime_sheetTips <= dateTime_sheet
and   dateTime_sheetTips <= dateTime_template
and   dateTime_sheetTips <= dateTime_gettingStarted;

select "******** PASS 3 - start ******** ", NOW(); 
/* PASS 3 */
update rpt_usagePattern
set sequence_sheet = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheet = "9999-12-31 00:00:00"
WHERE dateTime_sheet < "9999-12-31 00:00:00"
and   dateTime_sheet <= dateTime_template
and   dateTime_sheet <= dateTime_gettingStarted
and   dateTime_sheet <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_template = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_template = "9999-12-31 00:00:00"
WHERE dateTime_template < "9999-12-31 00:00:00"
and   dateTime_template <= dateTime_sheet
and   dateTime_template <= dateTime_gettingStarted
and   dateTime_template <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_gettingStarted = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_gettingStarted = "9999-12-31 00:00:00"
WHERE dateTime_gettingStarted < "9999-12-31 00:00:00"
and   dateTime_gettingStarted <= dateTime_sheet
and   dateTime_gettingStarted <= dateTime_template
and   dateTime_gettingStarted <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_sheetTips = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheetTips = "9999-12-31 00:00:00"
WHERE dateTime_sheetTips < "9999-12-31 00:00:00"
and   dateTime_sheetTips <= dateTime_sheet
and   dateTime_sheetTips <= dateTime_template
and   dateTime_sheetTips <= dateTime_gettingStarted;

select "******** PASS 4 - start ******** ", NOW(); 
/* PASS 4 */
update rpt_usagePattern
set sequence_sheet = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheet = "9999-12-31 00:00:00"
WHERE dateTime_sheet < "9999-12-31 00:00:00"
and   dateTime_sheet <= dateTime_template
and   dateTime_sheet <= dateTime_gettingStarted
and   dateTime_sheet <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_template = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_template = "9999-12-31 00:00:00"
WHERE dateTime_template < "9999-12-31 00:00:00"
and   dateTime_template <= dateTime_sheet
and   dateTime_template <= dateTime_gettingStarted
and   dateTime_template <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_gettingStarted = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_gettingStarted = "9999-12-31 00:00:00"
WHERE dateTime_gettingStarted < "9999-12-31 00:00:00"
and   dateTime_gettingStarted <= dateTime_sheet
and   dateTime_gettingStarted <= dateTime_template
and   dateTime_gettingStarted <= dateTime_sheetTips;


update rpt_usagePattern
set sequence_sheetTips = 1 + sequence_sheet + sequence_template + sequence_gettingStarted + sequence_sheetTips
   ,dateTime_sheetTips = "9999-12-31 00:00:00"
WHERE dateTime_sheetTips < "9999-12-31 00:00:00"
and   dateTime_sheetTips <= dateTime_sheet
and   dateTime_sheetTips <= dateTime_template
and   dateTime_sheetTips <= dateTime_gettingStarted;


select "******** Restore date columns - they were modified during sequencing... - start ******** ", NOW(); 
/* Restore date columns - they were modified during sequencing... */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheet          = null,
       up.dateTime_template       = null,
       up.dateTime_gettingStarted = null,
       up.dateTime_sheetTips      = null;

/* New Blank Sheet */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheet = (select min(c1.insertDateTime)
                            from   container as c1
                            where  c1.insertByUserID = up.userID
                            and    c1.containerType = 2
                            and    c1.templateStatus = 0
                            and    (c1.sourceID is null or c1.sourceID < 1000000));


/* New Sheet from Template */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_template = (select min(c1.insertDateTime)
                               from   container as c1
                                     ,container as c2
                               where  c1.containerType = 2
                               and    c1.insertByUserID = up.userID
                               and    c1.sourceID = c2.containerID
                               and    c2.templateStatus != 0
                               and    c1.templateStatus = 0);


/* OPS DB: View Getting Started Tab */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_gettingStarted = (select min(rl.insertDateTime)
                                     from   ss_log_02.requestLog as rl
                                     where  rl.formName   = "fn_eventLog"
                                     and    rl.insertByUserID = up.userID
                                     and    rl.formAction = "gl"
                                     and    rl.parm1      = 104);


/* OPS DB: View Sheet Tips & Hints */
UPDATE rpt_usagePattern AS up
SET    up.dateTime_sheetTips = (select min(rl.insertDateTime)
                                from   ss_log_02.requestLog as rl
                                where  rl.formName   = "fn_eventLog"
                                and    rl.insertByUserID = up.userID
                                and    rl.formAction = "gl"
                                and    rl.parm1      = 8202);


                                
select "******** rpt_usagePattern - final step - start ******** ", NOW(); 
update rpt_usagePattern
set    sequence_sheet = null
where  sequence_sheet = 0;
update rpt_usagePattern
set    sequence_sheet = 3
where  sequence_sheet = 4;
update rpt_usagePattern
set    sequence_sheet = 4
where  sequence_sheet = 8;

update rpt_usagePattern
set    sequence_template = null
where  sequence_template = 0;
update rpt_usagePattern
set    sequence_template = 3
where  sequence_template = 4;
update rpt_usagePattern
set    sequence_template = 4
where  sequence_template = 8;

update rpt_usagePattern
set    sequence_gettingStarted = null
where  sequence_gettingStarted = 0;
update rpt_usagePattern
set    sequence_gettingStarted = 3
where  sequence_gettingStarted = 4;
update rpt_usagePattern
set    sequence_gettingStarted = 4
where  sequence_gettingStarted = 8;

update rpt_usagePattern
set    sequence_sheetTips = null
where  sequence_sheetTips = 0;
update rpt_usagePattern
set    sequence_sheetTips = 3
where  sequence_sheetTips = 4;
update rpt_usagePattern
set    sequence_sheetTips = 4
where  sequence_sheetTips = 8;



SELECT * FROM rpt_usagePattern;