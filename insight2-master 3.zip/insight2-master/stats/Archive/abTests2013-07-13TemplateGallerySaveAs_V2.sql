/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2013-07-13TemplateGallerySaveAs_V2.csv");


/*Generating abTests2013-07-13TemplateGallerySaveAs_V2.csv*/
SELECT 
	userAccount.userID AS 'User ID', 
	userAccount.emailAddress AS 'E-mail Address', 
	ss.valueNumeric AS 'SS_ABTEST_TEMPLATE_GALLERY_SAVEAS_FORM',
	DATE_FORMAT(ss.insertDateTime, '%Y-%m-%d') AS 'ABTestDate',
	hist_paymentProfile.accountType,
	hist_paymentProfile.productID,
	hist_paymentProfile.modifyDateTime,
	hist_paymentProfile.hist_effectiveThruDateTime,

	/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	       
	CONCAT(DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTimePT, '%Y'), "*", 
	       LPAD(MONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0"), "*", 
	       LPAD(DAYOFMONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0")) AS 'Signup Day PT', 

	CASE rpt_signupSourceUser.bucket IS NULL
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSourceUser.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment',

	DATE_FORMAT(rpt_paymentProfile.paymentInsertDate, '%Y*%m(%b)') AS 'Payment Insert Month', 
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE rpt_paymentProfile.countAsPaid = 0
				WHEN 1 THEN NULL
				ELSE rpt_paymentProfile.paymentTotal / rpt_paymentProfile.paymentTerm
			END
	END AS 'Monthly Revenue',
		
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0
		ELSE 
			CASE rpt_paymentProfile.paymentTerm
			     WHEN 12 THEN 1
			     ELSE 0
			END	
	END AS 'Is Annual',
			
	rpt_paymentProfile.paymentTermFriendly AS 'Payment Term',
			
	/* quote to prevent odd characters causing problems in Excel and so Excel won't try to interpret keywords that start with + as a formula */
	QUOTE(rpt_signupSourceUser.keyword) 		AS 'Signup Keyword',

	rpt_signupSourceUser.adVersion AS 'Ad Version',

	CASE rpt_signupSourceUser.appLaunchParm1Friendly IS NULL 
		WHEN 1 THEN 0
		ELSE 1 END AS UsedDistributedContainer,
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Lifetime Log Count >= 400',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
	
	CASE rpt_paymentProfile.paymentStartDateRaw IS NOT NULL AND DATEDIFF(CURRENT_DATE(), rpt_paymentProfile.paymentStartDateRaw) <= 35
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is In 35 Day Window',
	
	CASE (userAccount.newsFlags & 1)  
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Receive News',
	CASE (userAccount.newsFlags & 2)  
		WHEN 2 THEN '1'
		ELSE '0'
	END AS 'Receive Morning Mail',
	
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'
		ELSE '0'
	END AS 'License Accepted',
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'
		ELSE '0'
	END AS 'Password Set',
	CASE (userAccount.statusFlags & 2) 
		WHEN 2 THEN '1'
		ELSE '0'
	END  AS 'Welcome Mail Sent',
	CASE (userAccount.statusFlags & 1) 
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Email Set',
	
	fcflrbu.paymentFormViewCount AS 'Payment Form View Count',
	
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Viewed Payment Form At Least Once',

	fcflrbu.overviewVideoViewCount AS 'Overview Video View Count',
	
	CASE fcflrbu.overviewVideoViewCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Viewed Overview Video At Least Once',
		
	rpt_paymentProfile.productName AS 'Product Name',
	
	CASE rpt_paymentProfile.countAsPaid
		WHEN 1 THEN
			CASE rpt_paymentProfile.productID
				WHEN 0 THEN "0" /* "Cancelled"  */
				WHEN 1 THEN "0" /* "Trial"      */
				WHEN 2 THEN "0" /* "Free"       */
				WHEN 3 THEN "0" /* "Basic"      */
				WHEN 4 THEN "0" /* "Advanced"   */
				WHEN 5 THEN "0" /* "Premium"    */
				WHEN 7 THEN "1" /* "Team"       */
				WHEN 8 THEN "1" /* "Team Plus"  */
				WHEN 6 THEN "1" /* "Enterprise" */
				ELSE "0"
			END
		ELSE 0
	END AS 'Team or Higher',
	
	userAccount.countryFriendly AS Country,
	CASE WHEN userAccount.countryFriendly = "United States" THEN "1" ELSE "0" END AS "is US",
	userAccount.languageFriendly AS "Language",
	CASE WHEN userAccount.languageFriendly  = "English" THEN "1" ELSE "0" END AS "is English",
	
	rpt_containerCountsByUser.sheetCount AS 'Sheet Count',
	CASE WHEN rpt_containerCountsByUser.sheetCount > 0 THEN "1" ELSE "0" END AS "created Sheet",
	rpt_featureCountRollupByUser.sharingCount AS 'Sharing Count',
	CASE WHEN rpt_featureCountRollupByUser.sharingCount > 0 THEN "1" ELSE "0" END AS "used Sharing Action",
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount > 25
	WHEN 1 THEN 1
	ELSE 0 END AS '25ClientEventsFirstDay',
	
	rpt_paymentProfile.daysToBuy,
	
	COUNT(arc_DailyWellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_DailyWellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1
	ELSE 0 END AS 'EverWellQual'

FROM rpt_main_02.userAccount 
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile ON rpt_main_02.hist_paymentProfile.ownerID = userAccount.userID AND rpt_main_02.hist_paymentProfile.accountType != 3
	AND rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime > "2013-07-13 23:00:00"  /*04:00:00 UTC is 8:00 PST when the release was made */
	AND rpt_main_02.hist_paymentProfile.modifyDateTime <= "2013-07-13 23:00:00" 
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss ON userAccount.userID = ss.userID AND ss.siteSettingElementName = "SS_ABTEST_TEMPLATE_GALLERY_SAVEAS_FORM"
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  			ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.countAsPaid = 1
LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedLeads ON userAccount.userID = arc_DailyWellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 			ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON userAccount.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   	ON userAccount.userID = rpt_featureCountRollupByUser.userID
	
WHERE ss.siteSettingElementName = "SS_ABTEST_TEMPLATE_GALLERY_SAVEAS_FORM"
	AND (rpt_main_02.hist_paymentProfile.productID NOT IN (3,4,5,6,7,8) OR rpt_main_02.hist_paymentProfile.productID IS NULL)
	AND (rpt_main_02.hist_paymentProfile.accountType != 3 OR rpt_main_02.hist_paymentProfile.accountType IS NULL)


GROUP BY 1,2,3,4
ORDER BY 4,1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2013-07-13TemplateGallerySaveAs_V2.csv");
