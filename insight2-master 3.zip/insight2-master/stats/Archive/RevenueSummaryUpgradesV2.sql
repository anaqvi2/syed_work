
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryUpgradesV2.csv insert");


INSERT rpt_main_02.output_RevenueSummary(
	weekFriendly,
	paymentProfileID,
	PaymentStartDate,
	productID,
	userLimit,	
	paymentTerm,	
	OldMonthlyPayment,	
	NewMonthlyPayment,	
	MonthlyPaymentIncrease,	
	Bucket,
	SignupSourceFriendly,
	SignupSubSourceFriendly,
	SignupCampaign,
	SignupSegment,
	ipCountry,
	ipRegion,
	ipCity,
	recordtype,
	recordDate)
	
(SELECT /*Generating RevenueSummaryUpgradesV2.csv*/
weeks.weekFriendly,
hist_paymentProfile.paymentProfileID,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

oldHPP.planRate/oldHPP.paymentTerm AS OldMonthlyPayment,

hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm AS NewMonthlyPayment,

(hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm) - (oldHPP.planRate/oldHPP.paymentTerm) AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'UPGRADES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
AND hist_paymentProfile.modifyDateTime <= weeks.endWeek

AND weeks.startWeek <= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
AND oldHPP.modifyDateTime <= weeks.startWeek
AND weeks.startWeek <= NOW()

JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.accountType !=2 
AND hist_paymentProfile.planRate > 0
AND oldHPP.planRate > 0
AND oldHPP.productID >= 3
AND oldHPP.planRate/oldHPP.paymentTerm < hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm
and hist_paymentProfile.paymentProfileID Not IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/


ORDER BY 1,3)

UNION

(SELECT 
weeks.weekFriendly,
orgHPP.paymentProfileID,
DATE_FORMAT(orgHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
SMARTSHEET_PRODUCTNAME(orgHPP.productID) AS productID,
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,

oldHPP.planRate/oldHPP.paymentTerm AS OldMonthlyPayment,

orgHPP.planRate/orgHPP.paymentTerm AS NewMonthlyPayment,

(orgHPP.planRate/orgHPP.paymentTerm) - (oldHPP.planRate/oldHPP.paymentTerm) AS MonthlyPaymentIncrease,

CASE rpt_signupSourceUser.bucket IS NULL 
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',

CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign AS SignupCampaign,
rpt_signupSourceUser.segment AS SignupSegment,

rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

'UPGRADES' AS recordtype,

DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m-%d") AS RecordDate

FROM rpt_main_02.ref_weeks weeks 
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > weeks.startWeek
	AND oldHPP.modifyDateTime <= weeks.startWeek
	AND weeks.startWeek <= NOW()
JOIN rpt_main_02.hist_paymentProfile orgHPP ON orgHPP.paymentProfileID = hist_paymentProfile.parentPaymentProfileID
	AND hist_paymentProfile.modifyDateTime = orgHPP.modifyDateTime
	AND orgHPP.hist_effectiveThruDateTime > weeks.endWeek
	AND orgHPP.modifyDateTime <= weeks.endWeek
	AND weeks.startWeek <= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON ppc.userID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
	AND oldHPP.productID >= 3
	AND oldHPP.planRate > 0 
	AND oldHPP.accountType = 1 AND hist_paymentProfile.accountType = 2
	AND hist_paymentProfile.parentPaymentProfileID IS NOT NULL
	AND oldHPP.planRate/oldHPP.paymentTerm < orgHPP.planRate/orgHPP.paymentTerm
	and hist_paymentProfile.paymentProfileID Not IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/


ORDER BY 1,3)
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryUpgradesV2.csv insert");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryUpgradesV2.csv select");

Select * from rpt_main_02.output_RevenueSummary where recordtype = 'UPGRADES';

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryUpgradesV2.csv select");
