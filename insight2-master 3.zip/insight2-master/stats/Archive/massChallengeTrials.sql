SELECT 
userAccount.userID, 
userAccount.emailAddress,
userAccount.firstName,
userAccount.lastName,
CONCAT('https://www.smartsheet.com/b/opscon?formName=fn_user&formAction=fa_detail&uid=',userAccount.userID)  AS 'Opscon Link',
signupRequestTrackingItem.insertDateTime,
signupRequestTrackingItem.itemname,
signupRequestTrackingItem.itemValue

FROM signupRequestTrackingItem
JOIN signupRequest ON signupRequestTrackingItem.signupRequestID = signupRequest.signupRequestID
LEFT OUTER JOIN userAccount ON signupRequest.userID = userAccount.userID

WHERE itemname = "u"
And itemValue = "QJ1511292"

GROUP BY userAccount.userID
ORDER BY signupRequestTrackingItem.insertDateTime;