/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2013-11-13HomePage_V2.csv");


SELECT /*Generating abTests2013-11-13HomePage_V2.csv*/
	userAccount.userID AS 'User ID', 
	userAccount.emailAddress AS 'E-mail Address', 
	userAccount.countryFriendly AS Country,
	CASE WHEN userAccount.countryFriendly = "United States" THEN "1" ELSE "0" END AS "is US",
	userAccount.languageFriendly AS "Language",
	CASE WHEN userAccount.languageFriendly  = "English" THEN "1" ELSE "0" END AS "is English",
	MAX(rpt_trials.trialDateTime),
	CASE WHEN MAX(rpt_trials.trialDateTime) IS NULL THEN 0 ELSE 1 END AS HadTrial,
	rpt_signupSource.signupInsertDateTime,
	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 

	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Lifetime Log Count >= 400',
	
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'	ELSE '0' END AS 'License Accepted',
	
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'	ELSE '0' END AS 'Password Set',
	
	fcflrbu.paymentFormViewCount AS 'Payment Form View Count',
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Viewed Payment Form At Least Once',
	
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
	
	rpt_signupRequestTrackingItem.itemValue AS ExperimentNumber,
	CASE WHEN INSTR(rpt_signupRequestTrackingItem.itemValue,'488072-88') THEN 
		CASE WHEN rpt_signupRequestTrackingItem.itemValue LIKE "%.1" THEN "B" WHEN rpt_signupRequestTrackingItem.itemValue LIKE "%.0" THEN "A" ELSE "Error" END
		ELSE 0 END AS "HomePageExperiment",
			
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0 ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL ELSE 	
		CASE rpt_paymentProfile.countAsPaid = 0 WHEN 1 THEN NULL ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm END
	END AS 'Monthly Revenue',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0 ELSE 
		CASE rpt_paymentProfile.paymentTerm WHEN 12 THEN 1 ELSE 0 END	
	END AS 'Is Annual',
			
	rpt_paymentProfile.paymentTermFriendly AS 'Payment Term',
	rpt_paymentProfile.productName AS 'Product Name',
	
	rpt_signupSource.appLaunchType,
	CASE WHEN ((rpt_signupSource.appLaunchType = 2 AND rpt_signupSource.appLaunchParm1Friendly) OR rpt_signupSource.appLaunchType IN (5,6,10,12,14)) THEN 1
		ELSE 0 END AS UsedDC,
		
	CASE WHEN rpt_paymentProfile.productID > 2 THEN 1 ELSE 0 END AS CountAsPaidProduct,
	rpt_paymentProfile.hasPaid,
	rpt_paymentProfile.daysToBuy,
	rpt_loginCountTotal.firstSessionLogID,
	rpt_sessionLog.loginType,
	rpt_browserSessionsByUser.mobileCount,
	CASE WHEN rpt_browserSessionsByUser.mobileCount > 0 THEN 1 ELSE 0 END AS usedMobile,
	CASE WHEN rpt_sessionLog.loginType = "OpenID" then 1 else 0 end AS OpenIDLogin

	

FROM rpt_main_02.userAccount 
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON userAccount.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem  ON rpt_signupSource.signupRequestID = rpt_signupRequestTrackingItem.signupRequestID AND itemName = "utm_expid" 
LEFT OUTER JOIN rpt_main_02.rpt_trials ON userAccount.userID = rpt_trials.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON userAccount.userID = arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType != 2
LEFT OUTER JOIN rpt_main_02.rpt_browserSessionsByUser ON userAccount.userID = rpt_browserSessionsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstSessionLogID = rpt_sessionLog.sessionLogID

WHERE rpt_signupRequestTrackingItem.itemValue LIKE '488072-88%'

GROUP BY 1,2
ORDER BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2013-11-13HomePage_V2.csv");
