
/***************************************************************************************************************************/
/* Marin Extract -  Last step, pull the rolled up data, file to be uploaded to Marin  */
/***************************************************************************************************************************/


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_extract.sql");



SET AUTOCOMMIT=0;


BEGIN;
SET @exportSQL = CONCAT(
"SELECT 
'Date', 'Keyword ID','Creative ID', 'Keyword',	'Match Type', 'sign_up Conv', 'strong_lead Conv', 'well_qual_lead Conv', 'paid_win Conv', 'paid_win Rev', 'Currency'
UNION ALL
SELECT 
    signupDate AS 'Date', 
    mkwid AS 'Keyword ID',
    adversion AS 'Creative ID', 
    keyword AS 'Keyword',						
    matchType AS 'Match Type',
    signups	AS 'sign_up Conv',
    strongLeads AS 'strong_lead Conv',
    wellQualifieds AS 'well_qual_lead Conv',
    wins AS 'paid_win Conv',
    revenue AS 'paid_win Rev',
    currency AS 'Currency'
INTO OUTFILE '/tmp/bulkRevenueadd_smartsheet_", CURRENT_DATE(), ".txt'
FROM rpt_main_02.arc_marin_uploadRollup
JOIN arc_marin_processStatus ON arc_marin_uploadRollup.runDate = arc_marin_processStatus.runDate AND arc_marin_processStatus.processStatus = 0
LIMIT 1234567890");

SELECT @exportSQL\G

PREPARE exportStatement FROM @exportSQL;

execute exportStatement;

/* insert record to track the process */
UPDATE rpt_main_02.arc_marin_processStatus
SET processStatus = 1, extractDateTime = NOW()
WHERE processStatus = 0;

COMMIT;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_extract.sql");

