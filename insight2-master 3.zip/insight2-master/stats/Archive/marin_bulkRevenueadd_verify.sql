
/***************************************************************************************************************************/
/* Marin Verify -  Mark today's process as being as the upload being completed successfully */
/***************************************************************************************************************************/


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_verify.sql");


/* insert record to track the process */
UPDATE rpt_main_02.arc_marin_processStatus
SET processStatus = 2, extractDateTime = NOW()
WHERE processStatus = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_verify.sql");
