/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_monthEndCustomerProduct");


DROP TABLE IF EXISTS rpt_main_02.rpt_monthEndCustomerProduct;

CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_monthEndCustomerProduct
(monthFriendly VARCHAR (15),
startMonth DATETIME,
endMonth DATETIME,
monthSequence TINYINT,
paymentProfileID BIGINT,
ownerID BIGINT,
sourceUserID BIGINT,
accountType TINYINT,
paymentType TINYINT,
paymentFlags INT,
parentPaymentProfileID BIGINT,
paymentStartDateTime DATETIME,
productID INT,
paymentTerm TINYINT,
paymentTotal NUMERIC(38,10),
userLimit INT,
bonusUsers INT,
billToRecurringBillingID VARCHAR(20),
modifyDateTime DATETIME,
hist_effectiveThruDateTime DATETIME,
PRIMARY KEY (paymentProfileID, startMonth)
);

INSERT rpt_main_02.rpt_monthEndCustomerProduct
SELECT
ref_months.monthFriendly,
ref_months.startMonth,
ref_months.endMonth,
ref_months.monthSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime


FROM rpt_main_02.hist_paymentProfile ProductNew
JOIN rpt_main_02.ref_months ON ProductNew.hist_effectiveThruDateTime > ref_months.endMonth 
	AND ProductNew.modifyDateTime < ref_months.endMonth 
	AND ref_months.endMonth <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID


WHERE ProductNew.parentPaymentProfileID IS NULL
AND ProductNew.planRate_USD > 0  /*Paid Accounts */
AND ProductNew.paymentType != 4  /*Not Promo Accounts */

ORDER BY MonthSequence;

/*  Adds months after cancellation for paid accounts for use in comparisons and lookups   */

INSERT rpt_main_02.rpt_monthEndCustomerProduct

SELECT 
ref_months.monthFriendly,
ref_months.startMonth,
ref_months.endMonth,
ref_months.monthSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime

FROM rpt_main_02.rpt_monthEndCustomerProduct

LEFT OUTER JOIN rpt_main_02.hist_paymentProfile ProductNew ON ProductNew.paymentProfileID  = rpt_monthEndCustomerProduct.paymentProfileID 
	AND ProductNew.productID < 3 	/* notPaid Accounts */
	AND ProductNew.planRate_USD <= 0  /* no money */
JOIN rpt_main_02.ref_months ON ProductNew.hist_effectiveThruDateTime > ref_months.endMonth 
	AND ProductNew.modifyDateTime < ref_months.endMonth
	AND ref_months.endMonth <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID

WHERE ref_months.MonthSequence = rpt_monthEndCustomerProduct.MonthSequence + 1

ORDER BY monthSequence;

/*  Create Indexes for these tables */
CREATE INDEX idx_rpt_monthEndCustomerProduct ON rpt_main_02.rpt_monthEndCustomerProduct (paymentProfileID);
CREATE INDEX idx_rpt_monthEndCustomerProductmodifyDateTime ON rpt_main_02.rpt_monthEndCustomerProduct (modifyDateTime);
CREATE INDEX idx_rpt_monthEndCustomerProductEffectiveDateTime ON rpt_main_02.rpt_monthEndCustomerProduct (hist_effectiveThruDateTime);

/*  Add columns for Boolean value indicating whether each monthly listing indicates a WIN, Upgrade, Downgrade or LOSS */

ALTER TABLE rpt_main_02.rpt_monthEndCustomerProduct ADD isWin BOOLEAN;
ALTER TABLE rpt_main_02.rpt_monthEndCustomerProduct ADD isUpgrade BOOLEAN;
ALTER TABLE rpt_main_02.rpt_monthEndCustomerProduct ADD isDowngrade BOOLEAN;
ALTER TABLE rpt_main_02.rpt_monthEndCustomerProduct ADD isLoss BOOLEAN;

UPDATE rpt_main_02.rpt_monthEndCustomerProduct monthEnd 
LEFT OUTER JOIN rpt_main_02.rpt_monthEndCustomerProduct OldMonthEnd 
ON monthEnd.paymentProfileID = OldMonthEnd.paymentProfileID AND monthEnd.MonthSequence = OldMonthEnd.MonthSequence + 1 
SET monthEnd.isWin = TRUE 
	WHERE (OldMonthEnd.productID < 3 OR OldMonthEnd.productID IS NULL)
	AND monthEnd.productID >= 3
	AND monthEnd.paymentTotal > 0; 
	
UPDATE rpt_main_02.rpt_monthEndCustomerProduct MonthEnd
JOIN rpt_main_02.rpt_monthEndCustomerProduct OldMonthEnd  
ON MonthEnd.paymentProfileID = OldMonthEnd.paymentProfileID AND MonthEnd.MonthSequence = OldMonthEnd.MonthSequence + 1 
SET MonthEnd.isUpgrade = TRUE 
	WHERE OldMonthEnd.productID >= 3
	AND rpt_main_02.SMARTSHEET_PRODUCTRANK (OldMonthEnd.productID) < rpt_main_02.SMARTSHEET_PRODUCTRANK (MonthEnd.productID)  
	AND MonthEnd.paymentTotal > 0;
	
UPDATE rpt_main_02.rpt_monthEndCustomerProduct MonthEnd
JOIN rpt_main_02.rpt_monthEndCustomerProduct OldMonthEnd  
ON MonthEnd.paymentProfileID = OldMonthEnd.paymentProfileID AND MonthEnd.MonthSequence = OldMonthEnd.MonthSequence + 1 
SET MonthEnd.isDowngrade = TRUE 
	WHERE MonthEnd.productID >= 3 
	AND rpt_main_02.SMARTSHEET_PRODUCTRANK (OldMonthEnd.productID) > rpt_main_02.SMARTSHEET_PRODUCTRANK (MonthEnd.productID);
	
UPDATE rpt_main_02.rpt_monthEndCustomerProduct MonthEnd
JOIN rpt_main_02.rpt_monthEndCustomerProduct OldMonthEnd  
ON MonthEnd.paymentProfileID = OldMonthEnd.paymentProfileID AND MonthEnd.MonthSequence = OldMonthEnd.MonthSequence + 1 
SET MonthEnd.isLoss = TRUE 
	WHERE MonthEnd.productID < 3 AND OldMonthEnd.productID >= 3;
	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_monthEndCustomerProduct");
