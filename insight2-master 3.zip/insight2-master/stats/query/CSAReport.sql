SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_csaReport");

DROP TABLE IF EXISTS rpt_main_02.rpt_csPlanReport;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_csPlanReport
(paymentProfileID BIGINT,
organizationID INT,
domain VARCHAR(100),
ISP INT,
accountName VARCHAR(100),
accountId VARCHAR(25),
csRep VARCHAR(100),
csRepEmailAddress VARCHAR(100),
csRepId VARCHAR(25),
territory VARCHAR(100),
segment VARCHAR(50),
productName VARCHAR(25),
productID INT,
userLimit INT,
licensesAssigned INT,
licensedUsers INT,
last30DayLoggedInUsers INT,
30DayActivityPerPlan INT,
licensedUsers90DaysAgo INT,
3MonthLicensedUserGrowth DECIMAL(10,2),
totalCollabs INT,
sightsUsersEnabled INT,
ACV DECIMAL(10,2),
ACV90DaysAgo DECIMAL(10,2),
ACVGrowthPast90Days DECIMAL(10,2),
lifetimeACVValue DECIMAL(10,2),
paymentStartDate DATETIME,
daysSincePurchase INT,
paymentType VARCHAR(25),
renewalDate DATE,
daysToRenewal INT,
salesRep VARCHAR(100),
salesEngagement INT,
openOpportunities INT,
closedLostOpportunities INT,
daysSinceLastInteraction INT,
engagedInDrip TINYINT,
toothbrushSuperUsers INT,
toothbrush0DayUsers INT,
totalNPS INT,
totalShares INT,
services DECIMAL(10,2),
country VARCHAR(100),
state VARCHAR(100),
city VARCHAR(100),
languageFriendly VARCHAR(100),
industry VARCHAR(100),
employeeCount INT,
zipCode VARCHAR(25),
Address VARCHAR(100),
accountTier VARCHAR(5),
accountHealth VARCHAR(25),
tierScore INT,
healthScore INT,
7DaysAgoAccountTier VARCHAR(5),
7DaysAgoAccountHealth VARCHAR(25),
7DaysAgoTierScore INT,
7DaysAgoHealthScore INT,
7DaysAgoOpenOpportunities INT,
7DaysAgoACV DECIMAL(10,2),
7DaysAgoLicensedUsers INT,
controlGroup TINYINT,
AccountType VARCHAR(50),
SightsPurchase TINYINT,
Reports DECIMAL(10,2),
Sharing DECIMAL(10,2),
Attachments DECIMAL(10,2),
Discussions DECIMAL(10,2),
UpdateRequests DECIMAL(10,2),
Mobile DECIMAL(10,2),
RowHierarchy DECIMAL(10,2),
ConditionalFormat DECIMAL(10,2),
Gantt DECIMAL(10,2),
ViewHistory DECIMAL(10,2),
Alerts DECIMAL(10,2),
LoggedIn DECIMAL(10,2),
Sheets DECIMAL(10,2),
Imports DECIMAL(10,2),
Last90DayActive DECIMAL(10,2),
lastContactDate DATE,
useCaseExists VARCHAR(50),
PRIMARY KEY (paymentProfileID),
INDEX (domain),
INDEX (accountId),
INDEX (accountName),
INDEX (csRepId));

INSERT IGNORE INTO rpt_main_02.rpt_csPlanReport (paymentProfileID, domain, productName, accountId, accountName, 
csRep, userLimit, licensesAssigned, licensedUsers, ACV, territory, csRepID, csRepEmailAddress)
SELECT ppi.paymentProfileID, ppi.domain, ppi.productName, acc.Id, acc.Name, CONCAT(us.firstName," ",us.lastName), ppi.userLimit, ppi.assignedUsers, 
ppi.licensedUsers, ppi.ACV, acc.Territory__c, acc.Customer_Success__c, us.Email
FROM rpt_main_02.rpt_paidPlanInfo ppi
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = ppi.domain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c 
LEFT OUTER JOIN ss_sfdc_02.user us ON us.Id = acc.Customer_Success__c;

UPDATE rpt_main_02.rpt_csPlanReport
SET domain='cree.com', accountName='Cree, Inc.', accountId='0014000000mw0SpAAI', csRep='Reid Kilwine', csRepEmailAddress='reid.kilwine@smartsheet.com', 
csRepID='00533000003uxWZAAY', territory='Major: East - Open (CDM)'
WHERE paymentProfileID=6892090;

UPDATE rpt_main_02.rpt_csPlanReport
SET domain='okq8.se', accountName='OK-Q8', accountId='0013300001cH1XWAA0', csRep='Liz Tanonis', csRepEmailAddress='liz.tanonis@smartsheet.com',
csRepID='00540000002n544AAA', territory='Unassigned (CDM)'
WHERE paymentProfileID=3975994; 

UPDATE rpt_main_02.rpt_csPlanReport
SET domain='ascension.org', accountName='Ascension Health', accountId='0014000000uWnXWAA0', csRep='Johannah Brown', csRepEmailAddress='johannah.brown@smartsheet.com',
csRepID='00533000003OTdUAAW', territory='Major: East3 - Jennifer Abramowitz (CDM)'
WHERE paymentProfileID=8494109; 

UPDATE rpt_main_02.rpt_csPlanReport
SET domain='cbre.com', accountName='CB Richard Ellis Group', accountId='0014000000mw0MvAAI', csRep='Dillon Brady', csRepEmailAddress='dillon.brady@smartsheet.com',
csRepID='00540000002nyJaAAI', territory='Los Angeles'
WHERE paymentProfileID=4047305;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.arc_ISPDomains B
ON A.domain=B.domain
SET ISP=1;

UPDATE rpt_main_02.rpt_csPlanReport
SET csRep='CustomerSuccess@'
WHERE (csRep IS NULL OR csRep='' OR csRep='Tasha Bishop');

UPDATE rpt_main_02.rpt_csPlanReport
SET segment=
CASE WHEN territory LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territory LIKE 'SMB%' THEN 'SMB' 
WHEN territory LIKE 'Major%' THEN 'Major'
WHEN territory LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territory LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territory LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territory LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN (territory LIKE 'Unassigned%'  OR territory='Not Enough Information (ISR3)' OR territory='') THEN 'No Territory'
ELSE 'Strategic'
END;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.use_case B
ON A.accountID=B.Account_Link__c
SET useCaseExists='Yes';

UPDATE rpt_main_02.rpt_csPlanReport
SET useCaseExists='N/A ISP'
WHERE ISP=1;

UPDATE rpt_main_02.rpt_csPlanReport
SET useCaseExists='No'
WHERE useCaseExists IS NULL;

DROP TABLE IF EXISTS rpt_main_02.stg_cs30DayActivity;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_cs30DayActivity
(planID BIGINT,
clientEvents INT,
PRIMARY KEY (planID));

INSERT INTO rpt_main_02.stg_cs30DayActivity
SELECT ppcu.planID, SUM(A.clientEvents)
FROM rpt_main_02.last30DayClientEventDate A
JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = A.userID
JOIN rpt_main_02.rpt_csPlanReport B ON ppcu.planID = B.paymentProfileID GROUP BY 1;

UPDATE rpt_main_02.rpt_csPlanReport A
LEFT OUTER JOIN rpt_main_02.stg_cs30DayActivity B ON B.planID = A.paymentProfileID
SET A.30DayActivityPerPlan = IFNULL(B.clientEvents,0);
UPDATE rpt_main_02.rpt_csPlanReport A
SET last30DayLoggedInUsers = 
	(SELECT COUNT(DISTINCT(ppcu.mainContactUserID))
		FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
		JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID AND lct.daysSinceLastLogin <= 30
		WHERE ppcu.planID = A.paymentProfileID);
		
UPDATE rpt_main_02.rpt_csPlanReport A
SET ACV90DaysAgo = (SELECT ((hpp.planRate_USD/hpp.paymentTerm)*12)
	FROM rpt_main_02.hist_paymentProfile hpp
	WHERE hpp.paymentProfileID = A.paymentProfileID
		AND DATE_SUB(NOW(), INTERVAL 90 DAY) BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime GROUP BY A.paymentProfileID);
		
UPDATE rpt_main_02.rpt_csPlanReport A
SET ACVGrowthPast90Days = (ACV/ACV90DaysAgo)-1 WHERE ACV90DaysAgo IS NOT NULL;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountID
SET employeeCount = acc.NumberOfEmployees;

UPDATE rpt_main_02.rpt_csPlanReport A
SET openOpportunities = (SELECT COUNT(*)
	FROM ss_sfdc_02.opportunity o
	WHERE o.AccountId = A.accountID AND o.StageName NOT IN('Closed Won', 'Closed Lost') AND o.Product__c != 'Services');
	
UPDATE rpt_main_02.rpt_csPlanReport A
SET totalCollabs = (SELECT COUNT(DISTINCT(userID))
	FROM rpt_main_02.rpt_paidPlanSheetAccess B
	WHERE A.paymentProfileID=B.sheetPlanID AND (B.sheetPlanID!=B.userPlanID OR B.userPlanID IS NULL));
    
UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.paymentProfileID
JOIN rpt_main_02.userAccount u ON u.userID = pp.mainContactUserID
SET A.languageFriendly = u.languageFriendly;

UPDATE rpt_main_02.rpt_csPlanReport A
SET services = (SELECT SUM(Services_ACV__c) 
	FROM ss_sfdc_02.opportunity o
	WHERE o.AccountID = A.accountID AND o.Product__c = 'Services' AND o.StageName = 'Closed Won');
	
UPDATE rpt_main_02.rpt_csPlanReport A
SET daysSincePurchase = (SELECT DATEDIFF(CURRENT_DATE,ppi.paymentStartDate)
	FROM rpt_main_02.rpt_paidPlanInfo ppi
	WHERE ppi.paymentProfileID = A.paymentProfileID);
	
UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.paymentProfileID
SET A.paymentType = pp.paymentTermFriendly;

UPDATE rpt_main_02.rpt_csPlanReport A
SET salesRep = (SELECT CONCAT(us.firstName," ",us.lastName)
	FROM ss_sfdc_02.user us
	JOIN ss_sfdc_02.account acc ON acc.OwnerId = us.Id
	WHERE acc.Id = A.accountID);
	
UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.paymentProfileID
SET A.productID = pp.productID;

DROP TABLE IF EXISTS rpt_main_02.stg_planTotalACV;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_planTotalACV
(paymentProfileID BIGINT,
ACV DECIMAL(10,2),
PRIMARY KEY (paymentProfileID));

INSERT IGNORE INTO rpt_main_02.stg_planTotalACV
SELECT hpp.paymentProfileID, MAX((hpp.planRate_USD/hpp.paymentTerm)*12)
FROM rpt_main_02.hist_paymentProfile hpp
WHERE hpp.productID > 2 AND hpp.planRate_USD > 0 AND hpp.accountType != 2 AND hpp.paymentType IN(1,2,3,6,8,10)
GROUP BY 1;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.stg_planTotalACV B ON A.paymentProfileID = B.paymentProfileID
SET A.lifetimeACVValue = B.ACV;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_workspace.cDunn_lead411Companies B ON A.domain = B.domain
SET A.industry = B.industry;
	
UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.paymentProfileID = A.paymentProfileID
SET A.paymentStartDate = ppi.paymentStartDate;

UPDATE rpt_main_02.rpt_csPlanReport A
SET licensedUsers90DaysAgo = (SELECT COUNT(DISTINCT(hpp.paymentProfileID))
	FROM rpt_main_02.hist_paymentProfile hpp 
	WHERE hpp.parentPaymentProfileID = A.paymentProfileID
	AND DATE_SUB(NOW(), INTERVAL 90 DAY) BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime);
	
UPDATE rpt_main_02.rpt_csPlanReport A
SET licensedUsers90DaysAgo = 1 WHERE A.productName IN('Basic', 'Advanced') AND paymentStartDate <= DATE_SUB(CURRENT_DATE, INTERVAL 90 DAY);
UPDATE rpt_main_02.rpt_csPlanReport A
SET 3MonthLicensedUserGrowth = (licensedUsers/licensedUsers90DaysAgo)-1;

UPDATE rpt_main_02.rpt_csPlanReport A
SET closedLostOpportunities = (SELECT COUNT(*)
	FROM ss_sfdc_02.opportunity o
	WHERE o.AccountId = A.accountID AND o.StageName = 'Closed Lost' AND o.Product__c != 'Services' AND CreatedDate >= DATE_SUB(CURRENT_DATE, INTERVAL 365 DAY));
	
UPDATE rpt_main_02.rpt_csPlanReport A
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile pp FORCE INDEX (PRIMARY)  ON A.paymentProfileID = pp.paymentProfileID
SET renewalDate = CASE WHEN pp.nextPaymentDate > NOW() THEN pp.nextPaymentDate 
	ELSE CASE WHEN pp.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(pp.actualLastPaymentDate), "-",DAY(pp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) + 1) YEAR) END
		WHEN pp.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN pp.paymentTerm = 1 
			THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +(pp.paymentTerm) MONTH) END
		ELSE "Other" END END;
        
UPDATE rpt_main_02.rpt_csPlanReport
SET daysToRenewal=DATEDIFF(renewalDate, CURRENT_DATE);
		
UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET A.country = acc.BillingCountry,
A.state = rpt_main_02.SMARTSHEET_STATEABBREV(acc.BillingState),
A.city = acc.BillingCity;

UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'United States' WHERE country IN('USA','US','U.S.A.', 'UNITED STATES', 'United STates', 'Untied States', 'U.S.', 'U]SA');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'Canada' WHERE country IN('CA','CANADA','CAN');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'United Kingdom' WHERE country IN('England','UK','GB','united Kingdom','United Kinddom', 'Great Britain', 'Great Britian');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'Australia' WHERE country IN('AU', 'AUS');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'New Zealand' WHERE country = 'NZ';
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'Mexico' WHERE country = 'MX';
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'Germany' WHERE country IN('DE');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'Netherlands' WHERE country IN('NL','Holland');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'United Arab Emirates' WHERE country IN('UAE');
UPDATE rpt_main_02.rpt_csPlanReport
SET country='Russia'
WHERE country='RU';

UPDATE rpt_main_02.rpt_csPlanReport
SET state='California'
WHERE state='california';

UPDATE rpt_main_02.rpt_csPlanReport
SET state='Texas'
WHERE state='Texas 77002';

DROP TABLE IF EXISTS rpt_workspace.js_lastContactDate;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_lastContactDate
(accountId VARCHAR(100),
lastContactDate DATETIME,
PRIMARY KEY (accountId));

INSERT INTO rpt_workspace.js_lastContactDate
SELECT accountId, MAX(A.ActivityDate) FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.user B
ON A.OwnerID=B.Id
WHERE A.AccountId != '' AND A.STATUS = 'Completed' AND B.Title IN ('Customer Success Manager', 'Customer Success Associate', 'Senior Customer Success Manager', 'Customer Success', 'Customer Success Intern', 'Customer Success Manager - Retail', 'Manager - CSA') AND A.type IN 
('Email Sent', 'Email Received', 'Call', 'Solution Help', 'Demo', 'Design Desk', 'Training', 'Admin Assistance', 'Demo/Screen Share', 'Onsite Meeting',
'Needs Analysis', 'Office Hours', 'Health Check', 'Engagement')
GROUP BY 1;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_workspace.js_lastContactDate B ON A.accountId = B.accountId
SET A.lastContactDate=B.lastContactDate;

UPDATE rpt_main_02.rpt_csPlanReport
SET daysSinceLastInteraction=DATEDIFF(CURRENT_DATE,lastContactDate);

UPDATE rpt_main_02.rpt_csPlanReport A
SET organizationID=
(SELECT organizationID FROM rpt_main_02.organization B
WHERE A.paymentProfileID=B.paymentProfileID);

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_account_02.orgConfigSetting B
ON A.organizationID=B.organizationID
SET A.sightsUsersEnabled=A.licensedUsers
WHERE B.configPropertyID=4024 AND B.valueBoolean=1;

DROP TABLE IF EXISTS rpt_workspace.js_csPlanReportSightsUsers;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csPlanReportSightsUsers
(userID INT,
planID INT,
PRIMARY KEY (userID),
INDEX (planID));

INSERT IGNORE INTO rpt_workspace.js_csPlanReportSightsUsers
SELECT A.userID, B.parentPaymentProfileID FROM ss_account_02.userConfigSetting A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.userID=B.mainContactUserID
WHERE A.configPropertyID=4024 AND A.valueBoolean=1 AND B.accountType=2;

INSERT IGNORE INTO rpt_workspace.js_csPlanReportSightsUsers
SELECT A.userID, B.paymentProfileID FROM ss_account_02.userConfigSetting A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.userID=B.mainContactUserID
WHERE A.configPropertyID=4024 AND A.valueBoolean=1 AND B.accountType=1;

UPDATE rpt_main_02.rpt_csPlanReport A
SET sightsUsersEnabled=
(SELECT COUNT(*) FROM rpt_workspace.js_csPlanReportSightsUsers B
WHERE A.paymentProfileID=B.planID)
WHERE sightsUsersEnabled IS NULL;

create table if not exists rpt_workspace.ts_TBusage
(userID int(15),
date date,
primary key (userID, date));

truncate table rpt_workspace.ts_TBusage;

insert ignore into rpt_workspace.ts_TBusage
select userID, date
from rpt_main_02.last30DayClientEventDate 
where date<>'0000-00-00'
group by 1,2;

insert ignore into rpt_workspace.ts_TBusage
SELECT userID, date
from rpt_main_02.last30DayMobileSessions
where date<>'0000-00-00'
group by 1,2;


DROP TABLE IF EXISTS rpt_workspace.ts_TBrollup;
CREATE TABLE rpt_workspace.ts_TBrollup AS
SELECT userID,COUNT('date') AS daysActiveOnEither
FROM rpt_workspace.ts_TBusage
GROUP BY 1;

ALTER TABLE rpt_workspace.ts_TBrollup 
ADD INDEX userID (userID ASC);

SELECT MIN(DATE) FROM rpt_main_02.last30DayClientEventDate WHERE DATE<>'0000-00-00' INTO @minTBdate;

DROP TABLE IF EXISTS rpt_workspace.ts_TBusers;
CREATE TABLE rpt_workspace.ts_TBusers
SELECT DISTINCT b.ownerID AS userID,c.planID
FROM rpt_main_02.hist_paymentProfile b
INNER JOIN rpt_main_02.rpt_paidPlanCurrentUsers c
ON b.ownerID=c.mainContactUserID
WHERE b.modifyDateTime < @minTBdate AND b.hist_effectiveThruDateTime >= @minTBdate AND b.productID>2 AND b.accountType<>3;

ALTER TABLE rpt_workspace.ts_TBusers 
ADD INDEX userID (userID ASC);

DROP TABLE IF EXISTS rpt_workspace.ts_toothbrushLast30Days;
CREATE TABLE rpt_workspace.ts_toothbrushLast30Days AS
SELECT a.*,IFNULL(b.daysActiveOnEither,0) AS daysActiveOnEither
FROM rpt_workspace.ts_TBusers a
LEFT JOIN rpt_workspace.ts_TBrollup b
ON a.userID=b.userID;

ALTER TABLE rpt_workspace.ts_toothbrushLast30Days
ADD INDEX userID (userID ASC),
ADD INDEX planID (planID ASC),
ADD INDEX daysActiveOnEither (daysActiveOnEither ASC);

UPDATE rpt_main_02.rpt_csPlanReport A
SET toothbrushSuperUsers = (SELECT COUNT(tl3.userID)
	FROM rpt_workspace.ts_toothbrushLast30Days tl3 
	WHERE tl3.planID = A.paymentProfileID
    AND tl3.daysActiveOnEither>=15);
UPDATE rpt_main_02.rpt_csPlanReport A
SET toothbrush0DayUsers = (SELECT COUNT(tl3.userID)
	FROM rpt_workspace.ts_toothbrushLast30Days tl3 
	WHERE tl3.planID = A.paymentProfileID
    AND tl3.daysActiveOnEither=0);
    
UPDATE rpt_main_02.rpt_csPlanReport A
SET totalNPS = (SELECT IFNULL(SUM(CASE WHEN nps.ReviewType='Promoter' THEN 1 WHEN nps.ReviewType='Detractor' THEN -1 ELSE 0 END),0)
	FROM rpt_main_02.stg_npsScore nps
    WHERE nps.PPID = A.paymentProfileID);
    
UPDATE rpt_main_02.rpt_csPlanReport A
SET totalShares = (SELECT IFNULL(SUM(fcr.sharingCount),0)
	FROM rpt_main_02.rpt_paidPlanSheetAccess ppsa 
	LEFT JOIN rpt_main_02.rpt_featureCountRollupByUser fcr
	ON ppsa.userID=fcr.userID
	WHERE A.paymentProfileID=ppsa.sheetPlanID);

DROP TABLE IF EXISTS rpt_main_02.rpt_csReport;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_csReport
SELECT accountId, accountName, COUNT(DISTINCT(paymentProfileID)) AS Plans, csRep, SUM(userLimit) AS userLimit, SUM(licensesAssigned) AS licensesAssigned, SUM(licensedUsers) AS licensedUsers,
(SUM(licensesAssigned)/SUM(userLimit)) AS utilization, SUM(ACV) AS ACV, SUM(last30DayLoggedInUsers) AS last30DayLoggedInUsers, 
 SUM(30DayActivityPerPlan)/SUM(licensedUsers) AS 30DayActivityPerUser, SUM(ACV90DaysAgo) AS ACV90DaysAgo, MAX(employeeCount) AS companySize,
SUM(openOpportunities) AS openOpportunities, SUM(lifetimeACVValue) AS lifetimeACVValue, SUM(totalCollabs) AS totalCollabs, 
CASE WHEN languageFriendly = 'English' THEN 'English' ELSE languageFriendly END AS languageFriendly, 
SUM(services) AS services, MIN(daysSincePurchase) AS daysSincePurchase, territory, industry, salesRep, 
MIN(paymentType) AS paymentTerm, SUM(licensedUsers90DaysAgo) AS licensedUsers90DaysAgo, 
MAX(paymentStartDate) AS paymentStartDate, (SUM(ACV)/SUM(ACV90DaysAgo))-1 AS 90DayACVGrowth, (SUM(licensedUsers)/SUM(licensedUsers90DaysAgo))-1 AS 90DayLicenseGrowth,
SUM(closedLostOpportunities) AS closedLostOpportunities, MIN(renewalDate) AS renewalDate, DATEDIFF(MIN(renewalDate), CURRENT_DATE) AS daysToRenewal,
country, state, city, MIN(daysSinceLastInteraction) AS daysSinceLastInteraction,
SUM(30DayActivityPerPlan) AS 30DayActivityTotal,
SUM(toothbrushSuperUsers) AS toothbrushSuperUsers,SUM(toothbrush0DayUsers) AS toothbrush0DayUsers,IFNULL(LEAST(1,ROUND(SUM(toothbrushSuperUsers)/SUM(licensedUsers),4)),0) AS toothbrushSuperPerc,IFNULL(LEAST(1,ROUND(SUM(toothbrush0DayUsers)/SUM(licensedUsers),4)),1) AS toothbrush0DayPerc,
GREATEST(-1,LEAST(1,SUM(totalNPS))) AS netPromoter,
SUM(totalShares) AS totalShares
FROM rpt_main_02.rpt_csPlanReport
WHERE ISP IS NULL
GROUP BY 1;

CREATE UNIQUE INDEX Id ON rpt_main_02.rpt_csReport (accountId);

ALTER TABLE rpt_main_02.rpt_csReport
ADD accountTier VARCHAR(5),
ADD accountHealth VARCHAR(25),
ADD tierScore INT,
ADD healthScore INT,
ADD 7DaysAgoAccountTier VARCHAR(5),
ADD 7DaysAgoAccountHealth VARCHAR(25),
ADD 7DaysAgoTierScore INT,
ADD 7DaysAgoHealthScore INT;

-- segment
ALTER TABLE rpt_main_02.rpt_csReport
ADD segment VARCHAR(50);

UPDATE rpt_main_02.rpt_csReport A
SET segment=
CASE WHEN territory LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territory LIKE 'SMB%' THEN 'SMB' 
WHEN territory LIKE 'Major%' THEN 'Major'
WHEN territory LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territory LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territory LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territory LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN (territory LIKE 'Unassigned%' OR territory LIKE 'Not Enough Information%' OR territory='') THEN 'No Territory'
ELSE 'Strategic'
END;

DROP TABLE IF EXISTS rpt_main_02.stg_csHealth;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_csHealth
(accountID VARCHAR(25),
last30DayActivity INT(25),
loggedInLast30 INT(25),
utilization INT(25),
licenseIncrease INT(25),
acvChange INT(25),
salesEngagement INT(25),
accountHealth VARCHAR(25),
PRIMARY KEY (accountID));

INSERT INTO rpt_main_02.stg_csHealth (accountID, last30DayActivity, loggedInLast30, utilization, licenseIncrease, acvChange, salesEngagement)
SELECT accountID,
CASE WHEN 30DayActivityPerUser >= 882 THEN 7
	WHEN 30DayActivityPerUser >= 46 THEN 4
	WHEN 30DayActivityPerUser < 46 THEN 1 END,
	
CASE WHEN (last30DayLoggedInUsers/licensedUsers) >= .75 THEN 6
	WHEN (last30DayLoggedInUsers/licensedUsers) >= .5 THEN 4
	WHEN (last30DayLoggedInUsers/licensedUsers) < .5 THEN 2 END,
	
CASE WHEN utilization >= .75 THEN 7
	WHEN utilization >= .5 THEN 4
	WHEN utilization < .5 THEN 1 END,
	
CASE WHEN licensedUsers90DaysAgo < licensedUsers THEN 7
	WHEN licensedUsers90DaysAgo = licensedUsers THEN 4
	WHEN licensedUsers90DaysAgo > licensedUsers THEN 1
	ELSE NULL END,
	
CASE WHEN ACV90DaysAgo < ACV THEN 7
	WHEN ACV90DaysAgo  = ACV THEN 4
	WHEN ACV90DaysAgo  > ACV THEN 1
	ELSE NULL END,
	
CASE WHEN daysSinceLastInteraction <= 30 THEN 6
	WHEN daysSinceLastInteraction <= 120 THEN 4
	WHEN daysSinceLastInteraction > 120 THEN 2
	WHEN daysSinceLastInteraction IS NULL THEN 2 END
	
FROM rpt_main_02.rpt_csReport;

ALTER TABLE rpt_main_02.rpt_csReport 
ADD engagedInDrip TINYINT,
ADD churnProb DECIMAL(6,4),
ADD expansionProb DECIMAL(6,4);

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountID
SET engagedInDrip = CASE WHEN acc.Account_To_Be_Assigned__c IN('Engaged','Existing') THEN 1 ELSE 0 END;

SET @c0=-2.944, @cUpForRenewal=1.073, @cLicenseChange=-0.228, @cEngagedInDrip=-0.478,@cTBsuperPerc=-1.433,@cTB0DayPerc=0.579,@cSharing=-2.027;
SET @e0=-6.970, @eUtilization=1.850, @eACVgrowth=0.530, @eLicenseGrowth=0.735, @eActivity=0.161, @eCollabs=0.062, @eTBsuperCount=0.255, @eTB0DayPerc=-0.815, @eNetPromoter=0.186;
UPDATE rpt_main_02.rpt_csReport
SET churnProb=1/(1+exp(-1*(
@c0+
(daysToRenewal<=30)*@cUpForRenewal+
(CASE WHEN licensedUsers90DaysAgo < licensedUsers THEN 1 WHEN licensedUsers90DaysAgo > licensedUsers THEN -1 ELSE 0 END)*@cLicenseChange+
engagedInDrip*@cEngagedInDrip+
toothbrushSuperPerc*@cTBsuperPerc+
toothbrush0DayPerc*@cTB0DayPerc+
(totalShares>=1)*@cSharing
))),
expansionProb=1/(1+exp(-1*(
@e0+
IFNULL(LEAST(utilization,1),0)*@eUtilization+
IFNULL(ACV>1.15*ACV90DaysAgo,0)*@eACVgrowth+
IFNULL(licensedUsers>licensedUsers90DaysAgo,0)*@eLicenseGrowth+
LN(1+LEAST(60000,30DayActivityTotal))*@eActivity+
LN(1+LEAST(250,totalCollabs))/LN(2)*@eCollabs+
LEAST(4,toothbrushSuperUsers)*@eTBsuperCount+
toothbrush0DayPerc*@eTB0DayPerc+
netPromoter*@eNetPromoter
))),
healthScore=GREATEST(1,LEAST(100,ROUND(((expansionProb-churnProb)*5+.5)*100,0))),
accountHealth=CASE WHEN healthScore<=35 THEN 'At Risk' WHEN healthScore>=75 THEN 'Good' ELSE 'Neutral' END
;

#OLD HEALTH CALC
#UPDATE rpt_main_02.stg_csHealth
#SET accountHealth = 
#	CASE WHEN (last30DayActivity+loggedInLast30+utilization+licenseIncrease+salesEngagement) >= 28 THEN "Good"
#	WHEN (last30DayActivity+loggedInLast30+utilization+licenseIncrease+salesEngagement) >= 23 AND acvChange = 7 THEN "Good"
#	WHEN (last30DayActivity+loggedInLast30+utilization+licenseIncrease+salesEngagement) >= 18 THEN "Neutral"
#	WHEN (last30DayActivity+loggedInLast30+utilization+licenseIncrease+salesEngagement) < 18 THEN "At Risk" END;

-- Old tier score code

/* DROP TABLE IF EXISTS rpt_main_02.stg_csTier;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_csTier
(accountID VARCHAR(25),
licensePotential INT,
acvValue INT,
companySize INT,
openOpportunitites INT,
lifetimeValue INT,
collabRatio INT,
LANGUAGE INT,
services INT,
tier VARCHAR(5),
PRIMARY KEY (accountID));

INSERT INTO rpt_main_02.stg_csTier
SELECT accountID,
CASE WHEN (userLimit/companySize) IS NULL THEN 2
	WHEN (userLimit/companySize)<=.25 THEN 6
	WHEN (userLimit/companySize)<=.5 THEN 4
	ELSE 2 END,
	
CASE WHEN ACV >= 1008 THEN 5
	WHEN ACV >= 471 THEN 4
	WHEN ACV < 471 THEN 3 END,
	
CASE WHEN companySize >= 180 THEN 7
	WHEN companySize >= 6 THEN 4 
	WHEN companySize < 6 THEN 1 END,
	
CASE WHEN openOpportunities > 0 THEN 7
	WHEN closedLostOpportunities > 0 THEN 1
	ELSE 4 END,
	
CASE WHEN lifetimeACVValue >= 1057 THEN 5
	WHEN lifetimeACVValue >= 499 THEN 4
	WHEN lifetimeACVValue < 499 THEN 3 END,
	
CASE WHEN (totalCollabs/licensedUsers) >= 2 THEN 5
	WHEN (totalCollabs/licensedUsers) >= 1 THEN 4
	WHEN (totalCollabs/licensedUsers) < 1 THEN 3 END,
	
CASE WHEN languageFriendly = 'English' THEN 7
	WHEN languageFriendly IN('Danish', 'Finnish', 'Dutch', 'Swedish', 'Norwegian') THEN 4
	ELSE 1 END,
	
CASE WHEN services IS NOT NULL THEN 6 ELSE 2 END,
NULL
FROM rpt_main_02.rpt_csReport;
UPDATE rpt_main_02.stg_csTier
SET tier = 
CASE WHEN (licensePotential+acvValue+companySize+openOpportunitites+lifetimeValue+collabRatio+LANGUAGE+services) >= 37 THEN "A"
WHEN (licensePotential+acvValue+companySize+openOpportunitites+lifetimeValue+collabRatio+LANGUAGE+services) >= 30 THEN "B"
WHEN (licensePotential+acvValue+companySize+openOpportunitites+lifetimeValue+collabRatio+LANGUAGE+services) < 30 THEN "C" END;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.stg_csTier C ON A.accountID = C.accountID
SET A.accountTier = C.tier,
A.tierScore = (C.licensePotential+C.acvValue+C.companySize+C.openOpportunitites+C.lifetimeValue+C.collabRatio+C.LANGUAGE+C.services); */

-- New Tier Scoring 7-31-17

DROP TABLE rpt_main_02.stg_csTieringOwned;
CREATE TABLE rpt_main_02.stg_csTieringOwned
(accountId VARCHAR(50),
accountName VARCHAR(100),
ARR DECIMAL(10,2),
ARRPct DECIMAL(10,6),
collaborators INT,
collaboratorsPct DECIMAL(10,6),
licensedUsers INT,
licensedUsersPct DECIMAL(10,6),
ARRScore INT,
collabScore INT,
userScore INT,
totalScore DECIMAL(10,2),
tier VARCHAR(5),
segment VARCHAR(100),
PRIMARY KEY (accountId));

INSERT INTO rpt_main_02.stg_csTieringOwned (accountId, accountName, ARR, collaborators, licensedUsers, segment)
SELECT accountId, accountName, ACV, totalCollabs, licensedUsers, segment
FROM rpt_main_02.rpt_csReport
WHERE csRep != 'CustomerSuccess@';

SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Mid-Market' INTO @mmARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Mid-Market' INTO @mmCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Mid-Market' INTO @mmUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'SMB' INTO @smbARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'SMB' INTO @smbCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'SMB' INTO @smbUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'EDU' INTO @eduARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'EDU' INTO @eduCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'EDU' INTO @eduUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Gov' INTO @govARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Gov' INTO @govCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Gov' INTO @govUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Healthcare' INTO @hcARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Healthcare' INTO @hcCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Healthcare' INTO @hcUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Major' INTO @majARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Major' INTO @majCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Major' INTO @majUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Retail' INTO @retARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Retail' INTO @retCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Retail' INTO @retUsers;
SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Strategic' INTO @strARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Strategic' INTO @strCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Strategic' INTO @strUsers;

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@mmARR, collaboratorsPct = collaborators/@mmCollab, licensedUsersPct = licensedUsers/@mmUsers
WHERE segment = 'Mid-Market';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@smbARR, collaboratorsPct = collaborators/@smbCollab, licensedUsersPct = licensedUsers/@smbUsers
WHERE segment = 'SMB';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@eduARR, collaboratorsPct = collaborators/@eduCollab, licensedUsersPct = licensedUsers/@eduUsers
WHERE segment = 'EDU';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@govARR, collaboratorsPct = collaborators/@govCollab, licensedUsersPct = licensedUsers/@govUsers
WHERE segment = 'Gov';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@hcARR, collaboratorsPct = collaborators/@hcCollab, licensedUsersPct = licensedUsers/@hcUsers
WHERE segment = 'Healthcare';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@majARR, collaboratorsPct = collaborators/@majCollab, licensedUsersPct = licensedUsers/@majUsers
WHERE segment = 'Major';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@retARR, collaboratorsPct = collaborators/@retCollab, licensedUsersPct = licensedUsers/@retUsers
WHERE segment = 'Retail';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRPct = ARR/@strARR, collaboratorsPct = collaborators/@strCollab, licensedUsersPct = licensedUsers/@strUsers
WHERE segment = 'Strategic';

UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .0030 THEN 3
			WHEN ARRPct >= .000765 THEN 2
				ELSE 1 END WHERE segment = 'Strategic';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .006833 THEN 3
			WHEN ARRPct >= .004592 THEN 2
				ELSE 1 END WHERE segment = 'EDU';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .001992 THEN 3
			WHEN ARRPct >= .000463 THEN 2
				ELSE 1 END WHERE segment = 'Gov';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .008769 THEN 3
			WHEN ARRPct >= .004796 THEN 2
				ELSE 1 END WHERE segment = 'Healthcare';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .006321 THEN 3
			WHEN ARRPct >= .003337 THEN 2
				ELSE 1 END WHERE segment = 'Retail';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .000932 THEN 3
			WHEN ARRPct >= .000553 THEN 2
				ELSE 1 END WHERE segment = 'Mid-Market';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .002502 THEN 3
			WHEN ARRPct >= .001144 THEN 2
				ELSE 1 END WHERE segment = 'Major';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET ARRScore = CASE WHEN ARRPct >= .001603 THEN 3
			WHEN ARRPct >= .001154 THEN 2
				ELSE 1 END WHERE segment = 'SMB';
				
/* Licensed User */

UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .003973 THEN 3
			WHEN licensedUsersPct >= .000710 THEN 2
				ELSE 1 END WHERE segment = 'Strategic';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .009474 THEN 3
			WHEN licensedUsersPct >= .003188 THEN 2
				ELSE 1 END WHERE segment = 'EDU';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .002799 THEN 3
			WHEN licensedUsersPct >= .000636 THEN 2
				ELSE 1 END WHERE segment = 'Gov';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .010156 THEN 3
			WHEN licensedUsersPct >= .003047 THEN 2
				ELSE 1 END WHERE segment = 'Healthcare';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .006626 THEN 3
			WHEN licensedUsersPct >= .002392 THEN 2
				ELSE 1 END WHERE segment = 'Retail';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .001275 THEN 3
			WHEN licensedUsersPct >= .000396 THEN 2
				ELSE 1 END WHERE segment = 'Mid-Market';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .003304 THEN 3
			WHEN licensedUsersPct >= .000951 THEN 2
				ELSE 1 END WHERE segment = 'Major';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET userScore = CASE WHEN licensedUsersPct >= .002040 THEN 3
			WHEN licensedUsersPct >= .000597 THEN 2
				ELSE 1 END WHERE segment = 'SMB';
				
/* Collabs */

UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .004307 THEN 3
			WHEN collaboratorsPct >= .000644 THEN 2
				ELSE 1 END WHERE segment = 'Strategic';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .006777 THEN 3
			WHEN collaboratorsPct >= .002937 THEN 2
				ELSE 1 END WHERE segment = 'EDU';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .001807 THEN 3
			WHEN collaboratorsPct >= .000657 THEN 2
				ELSE 1 END WHERE segment = 'Gov';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .010085 THEN 3
			WHEN collaboratorsPct >= .005155 THEN 2
				ELSE 1 END WHERE segment = 'Healthcare';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .005927 THEN 3
			WHEN collaboratorsPct >= .003153 THEN 2
				ELSE 1 END WHERE segment = 'Retail';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .001032 THEN 3
			WHEN collaboratorsPct >= .000451 THEN 2
				ELSE 1 END WHERE segment = 'Mid-Market';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .002509 THEN 3
			WHEN collaboratorsPct >= .001057 THEN 2
				ELSE 1 END WHERE segment = 'Major';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET collabScore = CASE WHEN collaboratorsPct >= .001702 THEN 3
			WHEN collaboratorsPct >= .000908 THEN 2
				ELSE 1 END WHERE segment = 'SMB';
				
UPDATE rpt_main_02.stg_csTieringOwned
SET totalScore = (ARRScore*.7+userScore*.2+collabScore*.1);

ALTER TABLE rpt_main_02.stg_csTieringOwned
ADD rank INT;

DROP TABLE IF EXISTS rpt_workspace.cDunn_accountRankings;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_accountRankings
SELECT A.accountId
     , A.segment
     , A.totalScore
     , COUNT(*) AS rank
  FROM rpt_main_02.stg_csTieringOwned A
  JOIN rpt_main_02.stg_csTieringOwned B
    ON (B.totalScore, B.accountId) >= (A.totalScore, A.accountId)
   AND A.segment = B.segment
 GROUP BY A.accountId
        , A.segment
        , A.totalScore
 ORDER BY segment
        , rank
;
CREATE UNIQUE INDEX accountId ON rpt_workspace.cDunn_accountRankings (accountId);

UPDATE rpt_main_02.stg_csTieringOwned A
JOIN rpt_workspace.cDunn_accountRankings B ON A.accountId = B.accountId
SET A.rank = B.rank;

SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Mid-Market' INTO @maxMM;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'SMB' INTO @maxSMB;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Healthcare' INTO @maxHC;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Gov' INTO @maxGov;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'EDU' INTO @maxEDU;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Major' INTO @maxMaj;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Retail' INTO @maxRetail;
SELECT MAX(rank) FROM rpt_main_02.stg_csTieringOwned WHERE segment = 'Strategic' INTO @maxStr;

UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxMM/3) THEN 'A'
		WHEN rank <= ((@maxMM/3)*2) THEN 'B'
		WHEN rank > ((@maxMM/3)*2) THEN 'C' END WHERE segment = 'Mid-Market';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxSMB/3) THEN 'A'
		WHEN rank <= ((@maxSMB/3)*2) THEN 'B'
		WHEN rank > ((@maxSMB/3)*2) THEN 'C' END WHERE segment = 'SMB';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxHC/3) THEN 'A'
		WHEN rank <= ((@maxHC/3)*2) THEN 'B'
		WHEN rank > ((@maxHC/3)*2) THEN 'C' END WHERE segment = 'Healthcare';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxGov/3) THEN 'A'
		WHEN rank <= ((@maxGov/3)*2) THEN 'B'
		WHEN rank > ((@maxGov/3)*2) THEN 'C' END WHERE segment = 'Gov';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxEDU/3) THEN 'A'
		WHEN rank <= ((@maxEDU/3)*2) THEN 'B'
		WHEN rank > ((@maxEDU/3)*2) THEN 'C' END WHERE segment = 'EDU';

UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxRetail/3) THEN 'A'
		WHEN rank <= ((@maxRetail/3)*2) THEN 'B'
		WHEN rank > ((@maxRetail/3)*2) THEN 'C' END WHERE segment = 'Retail';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxMaj/3) THEN 'A'
		WHEN rank <= ((@maxMaj/3)*2) THEN 'B'
		WHEN rank > ((@maxMaj/3)*2) THEN 'C' END WHERE segment = 'Major';
		
UPDATE rpt_main_02.stg_csTieringOwned
SET tier = CASE WHEN rank <= (@maxStr/3) THEN 'A'
		WHEN rank <= ((@maxStr/3)*2) THEN 'B'
		WHEN rank > ((@maxStr/3)*2) THEN 'C' END WHERE segment = 'Strategic';


DROP TABLE rpt_main_02.stg_csTieringNotOwned;
CREATE TABLE rpt_main_02.stg_csTieringNotOwned
(accountId VARCHAR(50),
accountName VARCHAR(100),
ARR DECIMAL(10,2),
ARRPct DECIMAL(10,6),
collaborators INT,
collaboratorsPct DECIMAL(10,6),
licensedUsers INT,
licensedUsersPct DECIMAL(10,6),
ARRScore INT,
collabScore INT,
userScore INT,
totalScore DECIMAL(10,2),
tier VARCHAR(5),
segment VARCHAR(100),
PRIMARY KEY (accountId));

INSERT INTO rpt_main_02.stg_csTieringNotOwned (accountId, accountName, ARR, collaborators, licensedUsers, segment)
SELECT accountId, accountName, ACV, totalCollabs, licensedUsers, segment
FROM rpt_main_02.rpt_csReport
WHERE csRep = 'CustomerSuccess@';

SELECT SUM(ARR) FROM rpt_main_02.stg_csTieringNotOwned INTO @unownedARR;
SELECT SUM(collaborators) FROM rpt_main_02.stg_csTieringNotOwned INTO @unownedCollab;
SELECT SUM(licensedUsers) FROM rpt_main_02.stg_csTieringNotOwned INTO @unownedUsers;

UPDATE rpt_main_02.stg_csTieringNotOwned
SET ARRPct = ARR/@unownedARR, collaboratorsPct = collaborators/@unownedCollab, licensedUsersPct = licensedUsers/@unownedUsers
;

UPDATE rpt_main_02.stg_csTieringNotOwned
SET ARRScore = CASE WHEN ARRPct >= .000136 THEN 3
			WHEN ARRPct >= .000098 THEN 2
				ELSE 1 END;
				
UPDATE rpt_main_02.stg_csTieringNotOwned
SET userScore = CASE WHEN licensedUsersPct >= .000330 THEN 3
			WHEN licensedUsersPct >= .000160 THEN 2
				ELSE 1 END;
				
UPDATE rpt_main_02.stg_csTieringNotOwned
SET collabScore = CASE WHEN collaboratorsPct >= .000170 THEN 3
			WHEN collaboratorsPct >= .000112 THEN 2
				ELSE 1 END;
				
ALTER TABLE rpt_main_02.stg_csTieringNotOwned
ADD territoryScore INT;

UPDATE rpt_main_02.stg_csTieringNotOwned
SET territoryScore = 
	CASE WHEN segment = 'Strategic' THEN 6
		WHEN segment = 'Major' THEN 5
		WHEN segment IN('EDU','Gov','Healthcare') THEN 4
		WHEN segment = 'Mid-Market' THEN 3
		WHEN segment = 'SMB' THEN 2
		ELSE 1 END;
		
UPDATE rpt_main_02.stg_csTieringNotOwned
SET totalScore = (territoryScore*.5+ARRScore*.3+collabScore*.2);


DROP TABLE rpt_main_02.stg_csTieringNotOwnedTiers;
CREATE TABLE rpt_main_02.stg_csTieringNotOwnedTiers
(accountId VARCHAR(50),
totalScore INT,
tier VARCHAR(5),
PRIMARY KEY (accountId));

INSERT INTO rpt_main_02.stg_csTieringNotOwnedTiers
SELECT accountId, totalScore, "A"
FROM rpt_main_02.stg_csTieringNotOwned
ORDER BY totalScore DESC
LIMIT 250;

INSERT IGNORE INTO rpt_main_02.stg_csTieringNotOwnedTiers
SELECT accountId, totalScore, "B"
FROM rpt_main_02.stg_csTieringNotOwned
ORDER BY totalScore DESC
LIMIT 1000;

INSERT IGNORE INTO rpt_main_02.stg_csTieringNotOwnedTiers
SELECT accountId, totalScore, "C"
FROM rpt_main_02.stg_csTieringNotOwned
ORDER BY totalScore DESC
;

UPDATE rpt_main_02.stg_csTieringNotOwned A
JOIN rpt_main_02.stg_csTieringNotOwnedTiers B ON A.accountId = B.accountId
SET A.tier = B.tier; 

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.stg_csTieringOwned B ON A.accountId = B.accountId
SET A.accountTier = B.tier, A.tierScore = B.totalScore;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.stg_csTieringNotOwned B ON A.accountId = B.accountId
SET A.accountTier = B.tier, A.tierScore = B.totalScore;

ALTER TABLE rpt_main_02.rpt_csReport
ADD last30DayActivity INT,
ADD loggedInLast30 INT,
ADD utilizationScore INT,
ADD licenseIncrease INT,
ADD acvChange INT,
ADD salesEngagement INT;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.stg_csHealth B ON A.accountID = B.accountID
SET	 A.last30DayActivity = B.last30DayActivity,
	A.loggedInLast30 = B.loggedInLast30,
	A.utilizationScore = B.utilization,
	A.licenseIncrease = B.licenseIncrease,
	A.acvChange = B.acvChange,
	A.salesEngagement = B.salesEngagement;
    
ALTER TABLE rpt_main_02.rpt_csReport
ADD 7DaysAgoOpenOpportunities INT,
ADD 7DaysAgoACV DECIMAL(10,2),
ADD 7DaysAgoLicensedUsers INT;
    
/*
drop table if exists rpt_workspace.js_hist_csReport;
create table if not exists rpt_workspace.js_hist_csReport
(accountID varchar(50),
accountName varchar(50),
accountTier varchar(50),
accountHealth varchar(50),
tierScore int,
healthScore int,
ACV dec(10,2),
licensedUsers int,
openOpportunities int,
historyDate date,
primary key (accountID, historyDate),
index (accountID),
index (accountName),
index (historyDate));
alter table rpt_workspace.js_hist_csReport
add csRep varchar(50),
add utilization dec(10,4);
alter table rpt_workspace.js_hist_csReport
add Plans int,
add userLimit int,
add licensesAssigned int,
add last30DayLoggedInUsers int,
add ACV90DaysAgo dec(10,2),
add companySize int,
add totalCollabs int,
add paymentTerm int,
add licensedUsers90DaysAgo int,
add 90DayACVGrowth dec(10,6),
add 90DayLicenseGrowth dec(10,4),
add closedLostOpportunities int,
add daysToRenewal int,
add daysSinceLastInteraction int,
add services dec(10,2),
add engagedInDrip int;
*/

INSERT IGNORE INTO rpt_workspace.js_hist_csReport
SELECT accountID,accountName,accountTier,accountHealth,tierScore,healthScore,ACV,licensedUsers,openOpportunities,CURRENT_DATE(),csRep,utilization,Plans,userLimit,licensesAssigned,last30DayLoggedInUsers,ACV90DaysAgo,companySize,totalCollabs,paymentTerm,licensedUsers90DaysAgo,90DayACVGrowth,90DayLicenseGrowth,closedLostOpportunities,daysToRenewal,daysSinceLastInteraction,services,engagedInDrip,toothbrushSuperUsers,toothbrush0DayUsers,netPromoter,totalShares
FROM rpt_main_02.rpt_csReport;

SELECT MAX(historyDate) FROM rpt_workspace.js_hist_csReport
WHERE historyDate <= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
INTO @7DaysAgoDate;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_workspace.js_hist_csReport B
ON A.accountID=B.accountID AND B.historyDate = @7DaysAgoDate
SET A.7DaysAgoAccountTier=B.accountTier, A.7DaysAgoAccountHealth=B.accountHealth, A.7DaysAgoTierScore=B.tierScore, A.7DaysAgoHealthScore=B.healthScore, 
A.7DaysAgoACV=B.ACV, A.7DaysAgoLicensedUsers=B.licensedUsers, A.7DaysAgoOpenOpportunities=B.openOpportunities;

DROP TABLE IF EXISTS rpt_workspace.js_csLastTierHealth;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csLastTierHealth
(accountId VARCHAR(25),
maxDate DATE,
tier VARCHAR(10),
health VARCHAR(25),
PRIMARY KEY (accountId),
KEY maxDate (maxDate));
INSERT INTO rpt_workspace.js_csLastTierHealth (accountId, maxDate)
SELECT accountId, MAX(historyDate)
FROM rpt_workspace.js_hist_csReport
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.js_csLastTierHealth (accountId, maxDate)
SELECT accountID, MAX(historyDate) FROM rpt_main_02.hist_csaReport
GROUP BY 1;

UPDATE rpt_workspace.js_csLastTierHealth A
JOIN rpt_workspace.js_hist_csReport B ON A.accountId = B.accountId AND A.maxDate = B.historyDate
SET A.tier = B.accountTier,
A.health = B.accountHealth;

UPDATE rpt_workspace.js_csLastTierHealth A
JOIN rpt_main_02.hist_csaReport B ON A.accountId = B.accountId AND A.maxDate = B.historyDate
SET A.tier = B.accountTier,
A.health = B.accountHealth;

/*UPDATE rpt_main_02.rpt_csReport A
LEFT OUTER JOIN rpt_workspace.cDunn_csRepDripAccounts B ON A.accountId = B.Id
SET A.engagedInDrip = CASE WHEN B.Id IS NOT NULL THEN 1 ELSE 0 END; */

ALTER TABLE rpt_main_02.rpt_csReport 
ADD zipCode VARCHAR(25),
ADD Address VARCHAR(100);

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET 	A.zipCode = acc.BillingPostalCode,
	A.address = NULL;
    
DROP TABLE IF EXISTS rpt_main_02.stg_csRepccountFeatures;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_csRepccountFeatures
SELECT A.accountName,
SUM(usedReports)/COUNT(DISTINCT(userID)) AS 'Reports',
SUM(usedSharing)/COUNT(DISTINCT(userID)) AS 'Sharing',
SUM(usedAttachments)/COUNT(DISTINCT(userID)) AS 'Attachments',
SUM(usedDiscussions)/COUNT(DISTINCT(userID)) AS 'Discussions',
SUM(usedUpdateRequests)/COUNT(DISTINCT(userID)) AS 'UpdateRequests',
SUM(usedMobile)/COUNT(DISTINCT(userID)) AS 'Mobile',
SUM(usedRowHierarchy)/COUNT(DISTINCT(userID)) AS 'RowHierarchy',
SUM(usedConditionalFormatting)/COUNT(DISTINCT(userID)) AS 'ConditionalFormat',
SUM(usedGanttView)/COUNT(DISTINCT(userID)) AS 'Gantt',
SUM(usedViewHistory)/COUNT(DISTINCT(userID)) AS 'ViewHistory',
SUM(usedAlerts)/COUNT(DISTINCT(userID)) AS 'Alerts',
SUM(loggedIn)/COUNT(DISTINCT(userID)) AS 'LoggedIn',
SUM(createdSheets)/COUNT(DISTINCT(userID)) AS 'Sheets',
SUM(usedImports)/COUNT(DISTINCT(userID)) AS 'Imports',
SUM(last30DayLogin)/COUNT(DISTINCT(userID)) AS 'Last30Day',
SUM(last90DayLogin)/COUNT(DISTINCT(userID)) AS 'Last90Day'
FROM rpt_workspace.cDunn_planFeatureUsage A
WHERE accountName IS NOT NULL
GROUP BY 1;

CREATE UNIQUE INDEX accountName ON rpt_main_02.stg_csRepccountFeatures (accountName);
ALTER TABLE rpt_main_02.rpt_csReport
ADD Reports DECIMAL(10,2),
ADD Sharing DECIMAL(10,2),
ADD Attachments DECIMAL(10,2),
ADD Discussions DECIMAL(10,2),
ADD UpdateRequests DECIMAL(10,2),
ADD Mobile DECIMAL(10,2),
ADD RowHierarchy DECIMAL(10,2),
ADD ConditionalFormat DECIMAL(10,2),
ADD Gantt DECIMAL(10,2),
ADD ViewHistory DECIMAL(10,2),
ADD Alerts DECIMAL(10,2),
ADD LoggedIn DECIMAL(10,2),
ADD Sheets DECIMAL(10,2),
ADD Imports DECIMAL(10,2),
ADD Last90DayActive DECIMAL(10,2);

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.stg_csRepccountFeatures B ON A.accountName = B.accountName
SET A.Reports = B.Reports,
	A.Sharing = B.Sharing,
	A.Attachments = B.Attachments,
	A.Discussions = B.Discussions,
	A.UpdateRequests = B.UpdateRequests,
	A.Mobile = B.Mobile,
	A.RowHierarchy = B.RowHierarchy,
	A.ConditionalFormat = B.ConditionalFormat,
	A.Gantt = B.Gantt,
	A.ViewHistory = B.ViewHistory,
	A.Alerts = B.Alerts,
	A.LoggedIn = B.LoggedIn,
	A.Sheets = B.Sheets,
	A.Imports = B.Imports,
	A.Last90DayActive = B.Last90Day;
	
ALTER TABLE rpt_main_02.rpt_csReport
ADD domain VARCHAR(100);

CREATE INDEX domain ON rpt_main_02.rpt_csReport (domain);

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.rpt_csPlanReport B ON B.accountId = A.accountId
SET A.domain = B.domain;

ALTER TABLE rpt_main_02.rpt_csReport 
ADD controlGroup TINYINT;

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET A.controlGroup = CASE WHEN acc.Account_To_Be_Assigned__c = 'Control' THEN 1 ELSE 0 END;

ALTER TABLE rpt_main_02.rpt_csReport
ADD AccountToBeAssigned VARCHAR(50),
ADD csRepEmail VARCHAR(100);

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET A.AccountToBeAssigned = acc.Account_To_Be_Assigned__c;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_main_02.rpt_csPlanReport B ON A.accountId = B.accountId
JOIN ss_sfdc_02.user u ON u.Id = B.csRepId
SET A.csRepEmail = u.Email;

ALTER TABLE rpt_main_02.rpt_csReport
ADD AccountType VARCHAR(50);

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET A.AccountType = acc.Account_Type__c;

ALTER TABLE rpt_main_02.rpt_csReport
ADD SightsPurchase TINYINT;

UPDATE rpt_main_02.rpt_csReport A
LEFT OUTER JOIN ss_sfdc_02.opportunity o ON o.accountID = A.accountID AND o.dashboards__c = 'true' AND o.StageName = 'Closed Won'
SET A.SightsPurchase = CASE WHEN o.Id IS NOT NULL THEN 1 ELSE 0 END;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_csReport B
ON A.accountID=B.accountID
SET A.salesEngagement=B.salesEngagement, A.engagedInDrip=B.engagedInDrip, A.zipCode=B.zipcode, A.Address=B.Address, A.accountTier=B.accountTier, 
A.accountHealth=B.accountHealth, A.tierScore=B.tierScore, A.healthScore=B.healthScore, A.7DaysAgoAccountTier=B.7DaysAgoAccountTier, 
A.7DaysAgoAccountHealth=B.7DaysAgoAccountHealth, A.7DaysAgoTierScore=B.7DaysAgoTierScore, A.7DaysAgoHealthScore=B.7DaysAgoHealthScore, 
A.7DaysAgoOpenOpportunities=B.7DaysAgoOpenOpportunities, A.7DaysAgoACV=B.7DaysAgoACV, A.7DaysAgoLicensedUsers=B.7DaysAgoLicensedUsers, 
A.controlGroup=B.controlGroup, A.AccountType=B.AccountType, A.SightsPurchase=B.SightsPurchase, A.Reports=B.Reports,
A.Sharing=B.Sharing, A.Attachments=B.Attachments, A.Discussions=B.Discussions, A.UpdateRequests=B.UpdateRequests, A.Mobile=B.Mobile, A.RowHierarchy=B.RowHierarchy,
A.ConditionalFormat=B.ConditionalFormat, A.Gantt=B.Gantt, A.ViewHistory=B.ViewHistory, A.Alerts=B.Alerts, A.LoggedIn=B.LoggedIn, A.Sheets=B.Sheets, A.Imports=B.Imports,
A.Last90DayActive=B.Last90DayActive;

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD updatedThroughDate DATE;

UPDATE rpt_main_02.rpt_csPlanReport
SET updatedThroughDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD customer VARCHAR(50);

UPDATE rpt_main_02.rpt_csPlanReport
SET customer=domain
WHERE ISP IS NULL;

UPDATE rpt_main_02.rpt_csPlanReport
SET customer=CONCAT(domain,'-',paymentProfileID)
WHERE ISP=1;

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD mainContactEmailAddress VARCHAR(50);

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.paymentProfileID=B.paymentProfileID
SET A.mainContactEmailAddress=B.mainContactEmailAddress
WHERE B.accountType!=2;

INSERT IGNORE INTO rpt_workspace.js_hist_csPlanReport
SELECT paymentProfileID,accountId,accountName,accountTier,accountHealth,domain,tierScore,healthScore,ACV,licensedUsers,openOpportunities,CURRENT_DATE(),salesRep,
productID,userLimit,licensesAssigned,last30DayLoggedInUsers,30DayActivityPerPlan,ACV90DaysAgo,employeeCount,totalCollabs,paymentType,licensedUsers90DaysAgo,
ACVGrowthPast90Days,closedLostOpportunities,daysToRenewal,daysSinceLastInteraction,services, engagedInDrip, segment,toothbrushSuperUsers,toothbrush0DayUsers,totalNPS,totalShares
FROM rpt_main_02.rpt_csPlanReport;

-- new updates for CS Portal V3
-- updated Through Date
ALTER TABLE rpt_main_02.rpt_csReport
ADD updatedThroughDate DATE;

UPDATE rpt_main_02.rpt_csReport
SET updatedThroughDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

-- country, state, city
UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountId
SET A.country = acc.BillingCountry,
A.state = rpt_main_02.SMARTSHEET_STATEABBREV(acc.BillingState),
A.city = acc.BillingCity;

UPDATE rpt_main_02.rpt_csReport
SET country = 'United States' WHERE country IN('USA','US','U.S.A.', 'UNITED STATES', 'United STates', 'Untied States', 'U.S.', 'U]SA');
UPDATE rpt_main_02.rpt_csReport
SET country = 'Canada' WHERE country IN('CA','CANADA','CAN');
UPDATE rpt_main_02.rpt_csReport
SET country = 'United Kingdom' WHERE country IN('England','UK','GB','united Kingdom','United Kinddom', 'Great Britain', 'Great Britian');
UPDATE rpt_main_02.rpt_csReport
SET country = 'Australia' WHERE country IN('AU', 'AUS');
UPDATE rpt_main_02.rpt_csPlanReport
SET country = 'New Zealand' WHERE country = 'NZ';
UPDATE rpt_main_02.rpt_csReport
SET country = 'Mexico' WHERE country = 'MX';
UPDATE rpt_main_02.rpt_csReport
SET country = 'Germany' WHERE country IN('DE');
UPDATE rpt_main_02.rpt_csReport
SET country = 'Netherlands' WHERE country IN('NL','Holland');
UPDATE rpt_main_02.rpt_csReport
SET country = 'United Arab Emirates' WHERE country IN('UAE');
UPDATE rpt_main_02.rpt_csReport
SET country='Russia'
WHERE country='RU';
UPDATE rpt_main_02.rpt_csReport
SET state='California'
WHERE state='california';
UPDATE rpt_main_02.rpt_csReport
SET state='Texas'
WHERE state='Texas 77002';


-- last contact date by CS Rep
ALTER TABLE rpt_main_02.rpt_csReport
ADD lastContactDateByCSRep DATE;

UPDATE rpt_main_02.rpt_csReport A
JOIN rpt_workspace.js_lastContactDate B ON A.accountId = B.accountId
SET A.lastContactDateByCSRep=B.lastContactDate;

UPDATE rpt_main_02.rpt_csReport
SET daysSinceLastInteraction=DATEDIFF(CURRENT_DATE,lastContactDateByCSRep);

-- contacted in quarter
ALTER TABLE rpt_main_02.rpt_csReport
ADD contactedWithinQuarter VARCHAR(10);

UPDATE rpt_main_02.rpt_csReport
SET contactedWithinQuarter=
CASE WHEN lastContactDateByCSRep >= '2017-08-01' THEN 'Yes' ELSE 'No' END;

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD contactedWithinQuarter VARCHAR(10);

UPDATE rpt_main_02.rpt_csPlanReport
SET contactedWithinQuarter=
CASE WHEN lastContactDate >= '2017-08-01' THEN 'Yes' ELSE 'No' END;

-- use case exists
ALTER TABLE rpt_main_02.rpt_csReport
ADD useCaseExists VARCHAR(15);

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.use_case B
ON A.accountID=B.Account_Link__c
SET useCaseExists='Yes';

UPDATE rpt_main_02.rpt_csReport
SET useCaseExists='No'
WHERE useCaseExists IS NULL;

-- employee count
ALTER TABLE rpt_main_02.rpt_csReport
ADD employeeCount INT;

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.account B ON A.accountID=B.Id
SET A.employeeCount = B.NumberOfEmployees;


-- links for usage dashboard
ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD usageDashboardLink VARCHAR(100);

UPDATE rpt_main_02.rpt_csPlanReport
SET usageDashboardLink=
CASE WHEN (Territory LIKE '%Major%' OR Territory NOT LIKE '%ISR3%') AND Territory IS NOT NULL THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Strategic_0/UsageDashboard'
WHEN Territory LIKE '%SMB%' THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-SMB_1/UsageDashboard'
WHEN (Territory LIKE '%Mid-Market%' OR Territory LIKE '%Vertical Market%') THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Mid-Market_0/UsageDashboard'
ELSE 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Unassigned/UsageDashboard'
END;


ALTER TABLE rpt_main_02.rpt_csReport
ADD usageDashboardLink VARCHAR(100);

UPDATE rpt_main_02.rpt_csReport
SET usageDashboardLink=
CASE WHEN (Territory LIKE '%Major%' OR Territory NOT LIKE '%ISR3%') AND Territory IS NOT NULL THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Strategic_0/UsageDashboard'
WHEN Territory LIKE '%SMB%' THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-SMB_1/UsageDashboard'
WHEN (Territory LIKE '%Mid-Market%' OR Territory LIKE '%Vertical Market%') THEN 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Mid-Market_0/UsageDashboard'
ELSE 'https://lalande.apollo.smartsheet.com/#/views/UsageDashboard-Unassigned/UsageDashboard'
END;

    
/*
-- new collab staging script
drop table if exists rpt_workspace.js_csDashboardCollabStaging;
create table if not exists rpt_workspace.js_csDashboardCollabStaging
(userID int,
userPlanID int,
userDomain varchar(50),
userAccountID varchar(100),
planSharedTo int,
domainSharedTo varchar(50),
domainSharedToISP int,
accountIDSharedTo varchar(100),
primary key (userId, planSharedTo),
index (userPlanID),
index (userDomain),
index (userAccountID),
index (domainSharedTo),
index (accountIDSharedTo));

insert into rpt_workspace.js_csDashboardCollabStaging(userID, userPlanID, userDomain, planSharedTo, domainSharedTo)
select userID, userPlanID, userDomain, sheetPlanID, sheetPlanDomain from rpt_main_02.rpt_paidPlanSheetAccess A
join rpt_main_02.rpt_csPlanReport B
on A.sheetPlanID=B.paymentProfileID
where (A.sheetPlanID!=A.userPlanID or A.userPlanID is null);

update rpt_workspace.js_csDashboardCollabStaging A
join rpt_main_02.arc_ISPDomains B
on A.domainSharedTo=B.domain 
set domainSharedToISP=1;

update rpt_workspace.js_csDashboardCollabStaging A
join ss_sfdc_02.domain B
on A.userDomain=B.Domain_Name_URL__c
set A.userAccountID=B.Account__c;

update rpt_workspace.js_csDashboardCollabStaging A
join ss_sfdc_02.domain B
on A.domainSharedTo=B.Domain_Name_URL__c
set A.accountIDSharedTo=B.Account__c;

update rpt_main_02.rpt_csReport A
set totalCollabs=
(select count(distinct userID) from rpt_workspace.js_csDashboardCollabStaging B
where A.accountID=B.accountIDSharedTo and (B.userAccountID!=B.accountIDSharedTo or B.userAccountID is null or B.userPlanID is null) and B.domainSharedToISP is null);
*/

-- maxPlan
ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD productIDRank INT;

UPDATE rpt_main_02.rpt_csPlanReport
SET productIDRank=rpt_main_02.SMARTSHEET_PRODUCTRANK(productID);

ALTER TABLE rpt_main_02.rpt_csReport
ADD maxProductID INT,
ADD maxProductName VARCHAR(50);

UPDATE rpt_main_02.rpt_csReport A
SET maxProductID=
(SELECT MAX(productIDRank) FROM rpt_main_02.rpt_csPlanReport B
WHERE A.accountId=B.accountID);

UPDATE rpt_main_02.rpt_csReport
SET maxProductID=rpt_main_02.SMARTSHEET_PRODUCTRANKCONVERT(maxProductID);

UPDATE rpt_main_02.rpt_csReport
SET maxProductName=rpt_main_02.SMARTSHEET_PRODUCTNAME(maxProductID);

ALTER TABLE rpt_main_02.rpt_csReport
ADD sightsUsersEnabled INT;

UPDATE rpt_main_02.rpt_csReport A
SET sightsUsersEnabled=
(SELECT SUM(sightsUsersEnabled) FROM rpt_main_02.rpt_csPlanReport B
WHERE A.accountID=B.accountID);

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD INDEX (organizationID),
ADD jiraEnabled INT,
ADD salesforceEnabled INT,
ADD securityPack INT,
ADD integrationPack INT,
ADD controlCenter INT;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_account_02.orgConfigSetting B
ON A.organizationID=B.organizationID
SET A.jiraEnabled=1
WHERE B.configPropertyID=4022 AND B.valueBoolean=1;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_account_02.orgConfigSetting B
ON A.organizationID=B.organizationID
SET A.jiraEnabled=1
WHERE B.configPropertyID=4021 AND B.valueBoolean=1;

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.Parent_Payment_Profile_ID__c
SET A.securityPack=1
WHERE B.Security_Pack__c='true' AND B.StageName='Closed Won';

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.Parent_Payment_Profile_ID__c
SET A.integrationPack=1
WHERE B.Integration_Pack__c='true' AND B.StageName='Closed Won';

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.Parent_Payment_Profile_ID__c
SET controlCenter=1
WHERE B.Project_Control_Center__c='true' AND B.StageName='Closed Won';

ALTER TABLE rpt_main_02.rpt_csPlanReport
ADD useCaseThisQuarter VARCHAR(50);

ALTER TABLE rpt_main_02.rpt_csReport
ADD useCaseThisQuarter VARCHAR(50);

UPDATE rpt_main_02.rpt_csPlanReport A
JOIN ss_sfdc_02.use_case B
ON A.accountID=B.Account_Link__c
SET useCaseThisQuarter='Yes'
WHERE B.CreatedDate >= '2017-08-01';

UPDATE rpt_main_02.rpt_csPlanReport
SET useCaseThisQuarter='No'
WHERE useCaseThisQuarter IS NULL;

UPDATE rpt_main_02.rpt_csReport A
JOIN ss_sfdc_02.use_case B
ON A.accountID=B.Account_Link__c
SET useCaseThisQuarter='Yes'
WHERE B.CreatedDate >= '2017-08-01';

UPDATE rpt_main_02.rpt_csReport
SET useCaseThisQuarter='No'
WHERE useCaseThisQuarter IS NULL;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_csaReport");