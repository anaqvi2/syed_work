SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("googleAppsDomainV2.csv");

/*Generating googleAppsDomainV2.csv*/
SELECT g.domain, 
adminEmail, 
CASE WHEN arc_datacomCompanyData.companyName IS NULL THEN 
	CASE WHEN arc_HooversCompanyData.companyName IS NULL THEN 
		rpt_paymentProfile.companyName ELSE  arc_HooversCompanyData.companyName END ELSE
	arc_datacomCompanyData.companyName END AS companyName,
CASE WHEN arc_datacomCompanyData.employeesTotal IS NULL THEN 
	arc_HooversCompanyData.employeesTotal ELSE 
	arc_datacomCompanyData.employeesTotal END AS employeesTotal,
CASE appListingID
	WHEN 303 then "303 - Google Crowdsourcing Solution Page"
	WHEN 505 then "505 - Sales Funnel"
	WHEN 509 then "509 - Google Marketplace Sales Pipeline Solution"
	ELSE appListingID END as appListingID, 
CASE state 
	WHEN 1 THEN "ACTIVE" 
	WHEN 2 THEN "UNLICENSED" 
	WHEN 3 THEN "PENDING"
	WHEN 4 THEN "EXPIRED"
	WHEN 5 THEN "DELINQUENT"
	WHEN 6 THEN "UNKNOWN"
	WHEN 7 THEN "SERVICE_ACCOUNT_ACTIVE"
	ELSE state END as State, 
insertDateTime, 
IFNULL(paidUserCount,0) AS PaidUsersInDomain

FROM rpt_main_02.googleAppsDomain g
LEFT OUTER JOIN rpt_main_02.rpt_domainRollup d ON g.domain = d.domain
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON g.domain = arc_HooversCompanyData.companyDomain
LEFT OUTER JOIN rpt_main_02.arc_datacomCompanyData ON g.domain = arc_datacomCompanyData.companyDomain
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON g.domain = rpt_paymentProfile.mainContactDomain

GROUP BY domain, applistingID, insertDateTime
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("googleAppsDomainV2.csv");

