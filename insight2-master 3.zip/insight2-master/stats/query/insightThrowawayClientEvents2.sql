select "******************************************************************************************************************************", NOW();
select "******** InsightThrowawayClientEventsPart2 - start ******** ", NOW();
/* Use this script to process to update client event fields after arc_clientEventRollup has been built

 Updates: 
- hierarchyCount, usedChangeView, columnPropertyFormCount in rpt_featureCountRollupByUser
- rpt_userPaymentFunnelProgress
- lifetimeLogCountStep in rpt_clientLogCountsByUserArchived
*/

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("InsightThrowawayClientEventsPart2");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_featureCountRollupByUser hierarchyCount usedChangeView columnPropertyFormCount");

select max(logDate) from rpt_main_02.arc_pj_marketoClientEventFeatures into @maxDate;
select max(logDate) from rpt_main_02.arc_clientEventRollup into @maxRollupDate;


insert ignore into rpt_main_02.arc_pj_marketoClientEventFeatures
select insertbyuserID, 
sum(case when objectID IN ('5006','5005','10200','10201') THEN logCount else 0 end),
sum(case when objectID IN ('5031','5032','5050') THEN logCount else 0 end),
sum(case when objectID IN ('10113','7158') THEN logCount else 0 end),
logDate
from rpt_main_02.arc_clientEventRollup 
where logDate between date_sub(@maxDate, interval 1 day) and date_add(@maxDate, interval 5 day) 
and logDate <= date_sub( @maxRollupDate, interval 1 day)
and objectID IN ('5006','5005','10200','10201','5031','5032','5050','10113','7158') 
and insertbyuserID > 100000 group by 1;

TRUNCATE TABLE rpt_main_02.stg_pj_marketoClientEventFeaturesRollup;
INSERT INTO rpt_main_02.stg_pj_marketoClientEventFeaturesRollup
SELECT insertbyuserID, sum(hierarchyCount) AS hierarchyCount, sum(usedChangeView) AS usedChangeView, sum(columnPropertyFormCount) AS columnPropertyFormCount
FROM rpt_main_02.arc_pj_marketoClientEventFeatures 
WHERE  @maxDate=date_sub( @maxRollupDate, interval 1 day)
GROUP BY 1;
        
update rpt_main_02.rpt_featureCountRollupByUser u
	JOIN rpt_main_02.stg_pj_marketoClientEventFeaturesRollup p on p.insertbyuserID = u.userID
SET u.hierarchyCount = p.hierarchyCount,
		u.usedChangeView = p.usedChangeView,
		u.columnPropertyFormCount =p.columnPropertyFormCount
WHERE  @maxDate=date_sub( @maxRollupDate, interval 1 day);

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_featureCountRollupByUser hierarchyCount usedChangeView columnPropertyFormCount");


CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_userPaymentFunnelProgress");

SELECT MAX(logDate) FROM rpt_main_02.rpt_payment_waterfall_actions INTO @maxLogDate;

INSERT INTO rpt_main_02.rpt_payment_waterfall_actions
SELECT 
	arc.insertByUserID, 
	arc.logDate,
	arc.objectID,
	arc.actionID,
	arc.parm1Int,
	arc.parm1String,
	arc.logCount
FROM rpt_main_02.arc_clientEventRollup arc
JOIN rpt_main_02.stg_user_trials m ON m.userID=arc.insertByUserID
LEFT OUTER JOIN rpt_main_02.rpt_payment_waterfall_actions p 
	ON arc.insertByUserID=p.insertByUserID
	AND arc.logDate=p.logDate
	AND arc.objectID=p.objectID
	AND arc.actionID=p.actionID
	AND arc.parm1Int=p.parm1Int
	AND arc.parm1String=p.parm1String
WHERE arc.objectID IN (2151,2152,2153,2155,2161)
/* the line below is being left out for now due to the non-capture of clicks for users that elect to purchase with PayPal */
 -- OR (objectID = 2001 AND actionID = 22 AND parm1Int = 7018 AND parm1String = "btn_save" )
AND p.insertByUserID IS NULL
AND arc.logDate >= @maxLogDate
AND arc.logDate < DATE_ADD(@maxLogDate, interval 5 day)
AND @maxLogDate != '2017-03-09'
;

INSERT IGNORE INTO rpt_main_02.rpt_paymentWaterfallPhasesNew
SELECT insertByUserID, SUM(logCount), 
	CASE WHEN objectID = 2151 THEN 'ViewedStep1'
	WHEN objectID = 2152 THEN 'ViewedStep2'
	WHEN objectID = 2153 THEN 'ViewedStep3'
	WHEN objectID = 2161 AND actionID = 52 THEN 'PayPal Start'
	WHEN objectID = 2161 AND actionID = 53 THEN 'PayPal Complete'
	WHEN objectID = 2155 THEN 'ViewedConfirmPage' ELSE NULL END
FROM rpt_main_02.rpt_payment_waterfall_actions 
WHERE objectID != 2001 AND logDate between @maxLogDate and DATE_ADD(@maxLogDate, interval 5 day)
GROUP BY 1,3;

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_userPaymentFunnelProgress");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_clientLogCountsByUserArchived table part 1 - start ******** ", NOW();


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep1");

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_dailyClientEvents LIKE rpt_main_02.arc_clientEvent;

SELECT MAX(clientEventID) INTO @maxClientEventID FROM rpt_main_02.stg_dailyClientEvents;
SELECT MAX(maxClientEvent) INTO @AlternateMaxClientEventID FROM rpt_main_02.arc_clientEventLookup;

SELECT IF(@maxClientEventID IS NULL, @AlternateMaxClientEventID, @maxClientEventID) INTO @maxClientEventID;

REPLACE INTO rpt_main_02.arc_clientEventLookup
SELECT CURRENT_DATE(), firstClientEventID, lastClientEventID, lastClientEventDateTime, (SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEvent)
FROM rpt_main_02.arc_clientEventLookup;

INSERT rpt_main_02.stg_dailyClientEvents
SELECT * FROM rpt_main_02.arc_clientEvent
WHERE clientEventID > @maxClientEventID
AND clientEventID <= @maxClientEventID+30000000;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep1");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep2");

DELETE FROM rpt_main_02.stg_dailyClientEvents WHERE clientEventID <= @maxClientEventID;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep2");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep3");

DROP TABLE if EXISTS rpt_main_02.stg_dailyClientEventRollup;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_dailyClientEventRollup (userID BIGINT, dailyClientEvents INT);

INSERT rpt_main_02.stg_dailyClientEventRollup SELECT arc_sessionLog.userID, COUNT(clientEventID) AS dailyClientEvents 
FROM rpt_main_02.stg_dailyClientEvents 
JOIN rpt_main_02.arc_sessionLog ON stg_dailyClientEvents.sessionlogID = arc_sessionLog.sessionLogID
GROUP BY arc_sessionLog.userID;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep3");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep4");

INSERT rpt_main_02.rpt_clientLogCountsByUserArchived (userID, lifetimeLogCount)
SELECT u.userID, 0 FROM rpt_main_02.userAccount u 
LEFT JOIN rpt_main_02.rpt_clientLogCountsByUserArchived r ON u.userID=r.userID
WHERE r.userID IS NULL;

UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
JOIN rpt_main_02.stg_dailyClientEventRollup ON clcua.userID = stg_dailyClientEventRollup.userID 
SET clcua.lifetimeLogCount = clcua.lifetimeLogCount + stg_dailyClientEventRollup.dailyClientEvents;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep4");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_trials gettingStartedOpen");

SELECT MAX(gettingStartedOpen) INTO @maxGettingStartedOpen FROM rpt_main_02.rpt_trials where gettingStartedOpen is not null;

UPDATE rpt_main_02.rpt_trials
	SET gettingStartedOpen = (SELECT MIN(arc_clientEvent.eventDateTime) FROM rpt_main_02.arc_clientEvent 
	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 1)
	WHERE gettingStartedOpen IS NULL AND trialDateTime between date_sub(@maxGettingStartedOpen, interval 1 day) and date_add(@maxGettingStartedOpen, interval 5 day) AND trialSessionID != 0;
    
/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_trials gettingStartedOpen");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_trials gettingStartedClose");

SELECT MAX(gettingStartedClose) INTO @maxGettingStartedClose FROM rpt_main_02.rpt_trials where gettingStartedClose is not null;

UPDATE rpt_main_02.rpt_trials
	SET gettingStartedClose = (SELECT MIN(arc_clientEvent.eventDateTime) FROM rpt_main_02.arc_clientEvent 
	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 2)
	WHERE gettingStartedClose IS NULL AND trialDateTime between date_sub(@maxGettingStartedClose, interval 1 day) and date_add(@maxGettingStartedClose, interval 5 day) AND trialSessionID != 0;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_trials gettingStartedClose");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_trials restartFirstDayLogCount");

SELECT MAX(trialDateTime) INTO @maxRestartFirstDayLogCount FROM rpt_main_02.rpt_trials where restartFirstDayLogCount is not null;

UPDATE rpt_main_02.rpt_trials
SET rpt_trials.restartFirstDayLogCount  =
	(SELECT SUM(r.logCount) FROM rpt_main_02.arc_clientEventRollup r
	WHERE r.insertByUserID = rpt_trials.userID 
	AND r.logDate BETWEEN DATE_FORMAT(rpt_trials.trialDateTime, '%Y-%m-%d') AND DATE_ADD(DATE_FORMAT(rpt_trials.trialDateTime, '%Y-%m-%d'), INTERVAL 12 HOUR)) 
WHERE rpt_trials.trialDateTime between date_sub(@maxRestartFirstDayLogCount, interval 1 day) and date_add(@maxRestartFirstDayLogCount, interval 5 day) AND firstTrial = 0;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_trials restartFirstDayLogCount");


CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_clientEventTemplateGallerySearch");

SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventTemplateGallerySearch INTO @maxClientEventID;

INSERT rpt_main_02.arc_clientEventTemplateGallerySearch
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID IN (552, 562)
AND actionID = 32 
AND clientEventID > @maxClientEventID
AND clientEventID <= (@maxClientEventID+30000000);

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_clientEventTemplateGallerySearch");

CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_clientEventSiteSearchTerms");

SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventSiteSearchTerms INTO @maxClientEventID;

INSERT rpt_main_02.arc_clientEventSiteSearchTerms 
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID = 7050 
AND actionID = 16 
AND clientEventID > @maxClientEventID
AND clientEventID <= (@maxClientEventID+30000000);

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_clientEventSiteSearchTerms");

CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_clientEventTemplateGalleryCategories");

SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventTemplateGalleryCategories INTO @maxClientEventID;

INSERT rpt_main_02.arc_clientEventTemplateGalleryCategories
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID IN (551,563) 
AND actionID = 22 
AND clientEventID > @maxClientEventID
AND clientEventID <= (@maxClientEventID+30000000);

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_clientEventTemplateGalleryCategories");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_workspace.cDunn_roleFormClick");

SELECT MAX(logDate) FROM rpt_workspace.cDunn_roleFormClicks INTO @maxRoleClick;

INSERT INTO rpt_workspace.cDunn_roleFormClicks
SELECT * FROM rpt_main_02.arc_clientEventRollup 
WHERE objectID = 7126 AND actionID = 1 AND 
logDate >= @maxRoleClick
and logDate <= date_add(@maxRoleClick, interval 5 day);

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_workspace.cDunn_roleFormClick");

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("InsightThrowawayClientEventsPart2");
