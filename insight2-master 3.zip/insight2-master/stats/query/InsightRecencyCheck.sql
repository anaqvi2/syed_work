-- SELECT TIMESTAMPADD(HOUR,-7,insertDateTime) INTO @LASTPAYMENTPROFILEINSERT FROM ss_core_02.paymentProfile ORDER BY paymentProfileID DESC LIMIT 1 ;
-- SELECT DATE_FORMAT(TIMESTAMPADD(HOUR,-7,paymentInsertDate),'%m/%d/%Y %r') INTO @LASTPAYMENTPROFILEINSERT FROM rpt_main_02.rpt_paymentProfile ORDER BY paymentProfileID DESC LIMIT 1;

-- SELECT TIMESTAMPADD(HOUR,-7,insertDateTime) INTO @LASTREQUESTLOGINSERT FROM ss_log_02.requestLog ORDER BY requestLogID DESC LIMIT 1 ;

-- SELECT TIMESTAMPADD(HOUR,-7,eventDateTime) INTO @LASTCLIENTEVENTDATE FROM ss_log_02.clientEvent ORDER BY clientEventID DESC LIMIT 1 ;


SELECT replicationDelaySeconds/3600 INTO @SlaveDelayFromMaster FROM rpt_main_02.arc_insightHealth ORDER BY replicationLastRecordDate DESC LIMIT 1; 

-- SELECT TIMESTAMPADD(HOUR,-7,NOW()) AS "Current Timestamp",
-- @LASTPAYMENTPROFILEINSERT AS "Most Recent Payment Profile Insert",
-- @LASTREQUESTLOGINSERT AS "Most Recent Request Log",
-- @LASTCLIENTEVENTDATE AS "Most Recent Client Event"

-- SELECT 'Sales Data in Tableau is up to date as of ' INTO @EmailBody;
SELECT 'Insight Replication Delay from Master in hours: ' INTO @EmailBody;
-- SELECT CONCAT(@EmailBody,@LASTPAYMENTPROFILEINSERT) AS ""
SELECT CONCAT(@EmailBody,@SlaveDelayFromMaster) AS ""
\G

