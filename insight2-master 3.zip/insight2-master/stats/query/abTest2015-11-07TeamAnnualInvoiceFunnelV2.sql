SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2015-11-07TeamAnnualInvoiceFunnel_V2.sql");

insert into rpt_main_02.stg_abtest_paymentActions(insertbyuserID)
(select userID from rpt_main_02.stg_teamAnnualInvoice);

select
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
siteSettingElementValue.insertDateTime,
rpt_trials.trialDateTime,
hist_paymentProfile.productID,
	ip.ipCountry,
	u.languageFriendly,
	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket
	END AS 'Bucket',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',
	
	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END AS 'Signup SubSource Friendly',

	rpt_signupSource.segment,
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.hasPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.hasPaid
	END AS 'has Paid',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN 0  
		ELSE 1 END AS 'User Signed Up',

CASE WHEN logCount > 0 THEN 1 ELSE 0 END as ReachedStep,
rpt_paymentProfile.paymentTypeFriendly,
CASE 
	WHEN pa.objectID is null THEN 'In Test'
    WHEN pa.objectID = 2151 THEN 'ViewedStep1'
	WHEN pa.objectID = 2152 THEN 'ViewedStep2'
	WHEN pa.objectID = 2153 THEN 'ViewedStep3'
	WHEN pa.objectID = 2161 AND pa.actionID = 52 THEN 'PayPal Start'
	WHEN pa.objectID = 2161 AND pa.actionID = 53 THEN 'PayPal Complete'
	WHEN pa.objectID = 2155 THEN 'ViewedConfirmPage' END AS PaymentFunnel

FROM rpt_main_02.siteSettingElementValue
JOIN rpt_main_02.userAccount u ON rpt_main_02.siteSettingElementValue.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_main_02.rpt_trials.userID = rpt_main_02.siteSettingElementValue.userID and rpt_main_02.rpt_trials.trialDateTime > "2015-11-07 00:00:00" and trialType = '1' and firstTrial = '1'
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON rpt_paymentProfile.sourceUserID = rpt_main_02.siteSettingElementValue.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_main_02.siteSettingElementValue.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON rpt_main_02.siteSettingElementValue.userID=ip.userID
LEFT OUTER JOIN rpt_main_02.stg_abtest_paymentActions pa ON u.userID=pa.insertbyuserID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3'
	and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
WHERE siteSettingElementName =  "SS_ABTEST_TEAM_ANNUAL_INVOICE"
group by 1,2,3, 18
limit 12312313123;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2015-11-07TeamAnnualInvoiceFunnel_V2.sql");