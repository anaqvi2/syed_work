SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2017-11-07UpgradeNowV2.sql");

-- drop table rpt_workspace.pj_abTest_FreeUserUpgrade;
create table if not exists rpt_workspace.pj_abTest_FreeUserUpgrade
(siteSettingElementValueID bigint,
siteSettingElementName varchar(50),
userID int,
valueNumeric int,
insertDateTime datetime,
organizationID int(15),
orgDomain varchar(50),
minCollabDate datetime,
sheetPlanDomain varchar(50),
primary key (siteSettingElementValueID),
unique key (siteSettingElementName, userID),
key (userID));

insert ignore into rpt_workspace.pj_abTest_FreeUserUpgrade(siteSettingElementValueID, siteSettingElementName, userID, valueNumeric, insertDateTime)
select siteSettingElementValueID, siteSettingElementName, userID, valueNumeric, insertDateTime
from ss_account_02.siteSettingElementValue 
where siteSettingElementValue.siteSettingElementName IN ("SS_ABTEST_UPG_NOW_VS_CREATE_OWN_FREE_COLLAB","SS_ABTEST_UPG_NOW_VS_CREATE_OWN_UNLIC_USER")
AND siteSettingElementValue.siteSettingElementValueID > 131673364;

update rpt_workspace.pj_abTest_FreeUserUpgrade pj
join organizationUserRole our on our.userID = pj.userID and our.role = 'Member' and our.insertDateTime < pj.insertDateTime
join organization o on o.organizationID = our.organizationID
set pj.organizationID = our.organizationID,
pj.orgDomain = o.domainName
where pj.organizationID is null and orgDomain is null;

update rpt_workspace.pj_abTest_FreeUserUpgrade pj
set pj.minCollabDate = 
(select min(minCollabDate)
from rpt_main_02.rpt_paidPlanSheetAccess sa
where sa.userID = pj.userID
and sa.minCollabDate <= pj.insertDateTime
and sa.userPlanID is null)
where pj.minCollabDate is null;

update rpt_workspace.pj_abTest_FreeUserUpgrade pj
join rpt_main_02.rpt_paidPlanSheetAccess sa on pj.userID= sa.userID and pj.minCollabDate = sa.minCollabDate and userPlanID is null
set pj.sheetPlanDomain = sa.sheetPlanDomain
where pj.sheetPlanDomain is null;

/* Client Events
8523 = Intro Tip - Upgrade Free Collab	, Open
8524 = Intro Tip - Upgrade Unlicensed Org User
14350 = Intro Tip - Upgrade Free Collab - Start Trial, Click
7221- Form - Collab Start Trial Confirmation, Open	
14351 = Intro Tip - Upgrade Free Collab - Upgrade, Click
14352 = Intro Tip - Upgrade Unlicensed Org User - Request License
208 = Desktop Links - Create Sheet Link	Click
2001 = Button	Click	btn_continue	7183

create table rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE like arc_clientEvent;
alter table rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE add insertbyuserID int(15);
alter table rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE add key(insertbyuserID); 
*/

select max(clientEventID) from rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE into @maxID;

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert ignore into rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE(clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID)
select clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID
from ss_log_02.clientEvent
where objectID IN (8523,8524,14350,14351,14352, 7221, 2151,2152,2153,2155,2161,208)
and eventDatetime >= '2017-11-07 20:00:00'
and clientEventid > 25257098447
and clientEventid > (@maxID-100000);

insert ignore into rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE(clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID)
select clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID
from ss_log_02.clientEvent
where objectID = 2001 and actionId = 22 and parm1String = 'btn_continue' and parm1Int = 7183
and eventDatetime >= '2017-11-07 20:00:00'
and clientEventid > 25257098447
and clientEventid > (@maxID-100000);

update rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE pj
	join ss_core_02.sessionLog sl on sl.sessionLogID= pj.sessionLogID and sl.sessionLogID > 550412936
set pj.insertbyuserID = sl.userID;

truncate table rpt_workspace.pj_collabUpgradeNowABTest;
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert into rpt_workspace.pj_collabUpgradeNowABTest
SELECT 
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
siteSettingElementValue.insertDateTime,
userAccount.insertDateTime as smartsheetInsertDate,
siteSettingElementValue.organizationID,
siteSettingElementValue.orgDomain,
siteSettingElementValue.minCollabDate,
siteSettingElementValue.sheetPlanDomain,
userAccount.domain,
(case when d.domain is not null then 0 else 1 end) IsOrgDomain,
(case when siteSettingElementName = "SS_ABTEST_UPG_NOW_VS_CREATE_OWN_FREE_COLLAB" and userAccount.domain = siteSettingElementValue.sheetPlanDomain then "In Domain"
	when siteSettingElementName = "SS_ABTEST_UPG_NOW_VS_CREATE_OWN_FREE_COLLAB" and userAccount.domain != siteSettingElementValue.sheetPlanDomain then "Out Domain"
	when siteSettingElementName = "SS_ABTEST_UPG_NOW_VS_CREATE_OWN_UNLIC_USER" and userAccount.domain = siteSettingElementValue.orgDomain then "In Domain"
    when siteSettingElementName = "SS_ABTEST_UPG_NOW_VS_CREATE_OWN_UNLIC_USER" and userAccount.domain != siteSettingElementValue.orgDomain then "Out Domain"
	END) as InternalvsExternal,

-- user data
CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,
userAccount.languageFriendly,

-- usage Data
rpt_loginCountTotal.firstLogin,
rpt_loginCountTotal.lastLogin,
sum(case when (ce.objectID IN (8523, 8524) and ce.actionID = 1)  or (objectID = 208 and actionID = 22) then 1 else 0 end) as IntroTipOpens,
sum(case when ce.objectID IN (14350,2001) then 1 else 0 end) as StartedTrialClicks,
sum(case when ce.objectID IN (14351) then 1 else 0 end) as  UpgradeClicks,
sum(case when ce.objectID IN (14352) then 1 else 0 end) as RequestLicenseClicks,
sum(case when ce.objectID IN (2151) then 1 else 0 end) as UpgradeStep1Views,
sum(case when ce.objectID IN (2152) then 1 else 0 end) as UpgradeStep2Views,
sum(case when ce.objectID IN (2153) then 1 else 0 end) as UpgradeStep3Views,
sum(case when ce.objectID IN (2155) then 1 else 0 end) as Confirmation,
sum(case when ce.objectID IN (2161) then 1 else 0 end) as Paypal,

-- user product
min(rpt_trials.trialDateTime) as trialDateTime,
rpt_trials.firstTrial,
rpt_trials.trialType,
rpt_paymentProfile.paymentStartDateClean,
CASE WHEN rpt_paymentProfile.planRate_USD > 0 then ((rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm)*12) else 0 end as ARR,
rpt_paymentProfile.userLimit,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_paymentProfile.productID) as 'Win Product',
-- rpt_paymentProfile.countAsPaid,
-- rpt_paymentProfile.hasPaid,
-- rpt_paymentProfile.daysToBuy,
rpt_paymentProfile.paymentTerm,
rpt_paymentProfile2.parentPaymentProfileID,
CASE WHEN rpt_paymentProfile2.productID IN (3,4,6,7,10,11) then rpt_paymentProfile2.paymentStartDateClean else null end as LicenseDateTime,
CASE WHEN rpt_paymentProfile2.productID IN (3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_paymentProfile2.productID) as 'Licensed Product',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS 'Basic?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS 'Advanced?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS 'Team?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise_Legacy?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 11 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 10 THEN 1 ELSE 0 
		END 
	END AS 'Business?',
CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS 'Cancelled?',
case when date_sub(rpt_paymentProfile2.paymentStartDateClean, interval 10 day) > siteSettingElementValue.insertDateTime 
		then date_sub(rpt_paymentProfile2.paymentStartDateClean, interval 10 day) 
			else siteSettingElementValue.insertDateTime end as pivotDate,
null as maxModifyDateTime,
0 as UpgradeARR
	
FROM rpt_workspace.pj_abTest_FreeUserUpgrade siteSettingElementValue
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_trials.userID = siteSettingElementValue.userID and siteSettingElementValue.insertDateTime <= rpt_trials.trialDateTime
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = siteSettingElementValue.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON siteSettingElementValue.userID = rpt_paymentProfile.sourceUserID
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean >= Date_sub(siteSettingElementValue.insertDateTime, interval 1 minute) 
    AND productID > 2 AND planRate_USD > 0
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > siteSettingElementValue.insertDateTime

LEFT OUTER JOIN rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE ce on ce.insertbyuserID = siteSettingElementValue.userID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains d on d.domain = userAccount.domain
GROUP BY 1,2,3,4;

select * from rpt_workspace.pj_collabUpgradeNowABTest;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2017-11-07UpgradeNowV2.sql");