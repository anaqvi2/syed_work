/* This stored procedure calls the following code that is commented out below*/
/* The code is stored here for reference only. The actual code that is executed is on the server and should match what is here*/

-- This should only run on Saturdays
-- CALL `rpt_main_02`.`arc_teamChurnScoring`();

-- Get weekly stats on current Team customers with user limit greater than 10 users
DROP TABLE IF EXISTS rpt_main_02.stg_team_churn_scoring;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_churn_scoring 
(
    weekFriendly varchar(15),
    startWeek datetime,
    endWeek datetime,
    paymentProfileID bigint,
    sourceUserID bigint,
    organizationID bigint,
    userID bigint,
    paymentType varchar(50),
    paymentStartDateTime datetime,
    weeksFromStart int DEFAULT 0,
    productName varchar(50),
    paymentTerm varchar(50),
    paymentTotal decimal(38,10),
    userLimit int,
    teamSize int,
	sumtrial int default 0,
	trial decimal(5,5) default 0,
    modifyDateTime datetime,
    hist_effectiveThruDateTime datetime,
    OrgOrISP varchar(3),
    sheetCount int default 0,
    sharingCount int default 0,
    TotalGridLoads1 int default 0,
    TotalGridLoads2 int default 0,
	TotalGridLoads int default 0,
    logCount int default 0,
    totalSharedUsers int default 0,
    KEY ix_ppid (paymentProfileID),
    KEY ix_sourceUser (sourceUserID),
	KEY teamSize (teamSize)
)
;

CREATE INDEX paymentProfileID ON rpt_main_02.stg_team_churn_scoring (paymentProfileID, weekFriendly);

INSERT INTO rpt_main_02.stg_team_churn_scoring
SELECT 
wecp.weekFriendly, 
wecp.startWeek, 
wecp.endWeek, 
wecp.paymentProfileID, 
wecp.sourceUserID, 
wecp.ownerID AS organizationID,
hpp.ownerID AS userID,
rpt_main_02.SMARTSHEET_PAYMENTTYPE (wecp.paymentType) AS paymentType,
wecp.paymentStartDateTime,
0 AS weeksFromStart,
rpt_main_02.SMARTSHEET_PRODUCTNAME(wecp.productID) AS productName,
SMARTSHEET_PAYMENTTERM(wecp.paymentTerm) AS paymentTerm,
wecp.paymentTotal,
wecp.userLimit,
case 
	when ba.userLimit BETWEEN 3 AND 5 THEN 3
	when ba.userLimit BETWEEN 6 AND 10 THEN 6
	when ba.userLimit > 10 THEN 11
END AS teamSize,
0 AS sumtrial,
0 AS trial, 
wecp.modifyDateTime,
wecp.hist_effectiveThruDateTime,
CASE WHEN d.domain IS NULL THEN 'Org' ELSE 'ISP' END AS OrgOrISP,
0 AS sheetCount,
0 AS sharingCount,
0 AS TotalGridLoads1,
0 AS TotalGridLoads2,
0 AS TotalGridLoads,
0 AS logCount,
0 AS totalSharedUsers
FROM rpt_main_02.rpt_weekEndCustomerProduct wecp 
JOIN rpt_main_02.rpt_paymentProfile ba ON wecp.paymentProfileID=ba.paymentProfileID AND ba.productName = 'Team' 
	AND ba.accountType = 3
LEFT JOIN rpt_main_02.hist_paymentProfile hpp on wecp.paymentProfileID=hpp.parentPaymentProfileID
	AND hpp.hist_effectiveThruDateTime > wecp.endWeek
	AND hpp.modifyDateTime < wecp.endWeek
	AND wecp.endWeek <= NOW()
LEFT JOIN rpt_main_02.userAccount ua ON wecp.sourceuserID=ua.userID
LEFT JOIN rpt_main_02.arc_ISPDomains d ON ua.domain=d.domain
GROUP BY weekFriendly, wecp.paymentProfileID, hpp.ownerID
;



/* Build Container Tables */
#DROP TABLE IF EXISTS rpt_main_02.stg_team_churn_scoring_containers1;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_churn_scoring_containers1
(
	containerID bigint,
	displayObjectID bigint,
	insertDate datetime,
	paymentProfileID bigint,
	userID bigint,
	KEY cID (containerID),
	KEY oID (displayObjectID),
	KEY ppID (paymentProfileID),
	KEY uID (userID)
)
;

INSERT INTO rpt_main_02.stg_team_churn_scoring_containers1 (containerID, displayObjectID, insertDate, paymentProfileID, userID)
SELECT c.containerID, c.displayObjectID, DATE_FORMAT(c.insertDateTime,'%Y-%m-%d') AS InsertDate , ba.paymentProfileID, ba.userID
FROM rpt_main_02.stg_team_churn_scoring ba
INNER JOIN rpt_main_02.container c
	ON c.insertByUserID = ba.userID AND c.ContainerType=2
LEFT OUTER JOIN rpt_main_02.stg_team_churn_scoring_containers1 INS ON c.containerID=INS.containerID
WHERE INS.containerID IS NULL
GROUP BY 1;




#DROP TABLE IF EXISTS rpt_main_02.stg_team_churn_scoring_containers2;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_churn_scoring_containers2
(
	containerID bigint,
	displayObjectID bigint,
	insertDate datetime,
	paymentProfileID bigint,
	userID bigint,
	KEY cID (containerID),
	KEY oID (displayObjectID),
	KEY ppID (paymentProfileID),
	KEY uID (userID)
)
;


INSERT INTO rpt_main_02.stg_team_churn_scoring_containers2 (containerID, displayObjectID, InsertDate , paymentProfileID, userID)
SELECT C.containerID, C.displayObjectID, DATE_FORMAT(GAM.insertDateTime,'%Y-%m-%d') AS InsertDate , ba.paymentProfileID, ba.userID
FROM rpt_main_02.stg_team_churn_scoring ba
INNER JOIN rpt_main_02.gridAccessMap GAM
	ON GAM.userID = ba.userID AND GAM.access<50
INNER JOIN rpt_main_02.container C
	 ON C.displayObjectID = GAM.GridID AND C.containerType =2 AND C.deleteStatus = 0
LEFT OUTER JOIN rpt_main_02.stg_team_churn_scoring_containers2 INS ON C.containerID=INS.containerID
WHERE INS.containerID IS NULL
GROUP BY 1;




/* User Went Through Trial*/
UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.sumtrial = 
(	SELECT 
	CASE WHEN count(distinct p.ownerID) > 0 THEN 1 ELSE 0 END
	FROM rpt_main_02.hist_paymentProfile p 
	WHERE p.productID = '1'
	AND p.ownerID = ba.userID
);




-- Set Weeks From Start
UPDATE  rpt_main_02.stg_team_churn_scoring
SET WeeksFromStart = CEILING(ABS(DATEDIFF(paymentStartDateTime, EndWeek))/7)
WHERE ProductName NOT IN ('Cancelled', 'Free', 'Trial');

UPDATE  rpt_main_02.stg_team_churn_scoring
SET WeeksFromStart = 1
WHERE ProductName NOT IN ('Cancelled', 'Free', 'Trial') AND WeeksFromStart = 0;



/* Opened By All Count - user level*/
DROP TABLE rpt_main_02.stg_team_openedSheets1;
CREATE TABLE rpt_main_02.stg_team_openedSheets1
SELECT c.*
FROM rpt_main_02.arc_gridLoadLogRollup c
JOIN rpt_main_02.stg_team_churn_scoring_containers1 cont
	ON c.gridID=cont.displayObjectID
	AND c.insertByUserID=cont.userID
;

CREATE INDEX ix_userID_insertDate ON rpt_main_02.stg_team_openedSheets1 (insertByUserID, insertDate);

UPDATE rpt_main_02.stg_team_churn_scoring ba #FORCE INDEX (teamSize)
SET ba.TotalGridLoads1 =
(
        SELECT
        SUM(c.gridLoadCount)
        FROM rpt_main_02.stg_team_openedSheets1 c
        WHERE ba.userID=c.insertByUserID AND c.insertDate BETWEEN ba.startWeek AND ba.endWeek
        GROUP BY weekFriendly, ba.userID
)
;

UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.TotalGridLoads1 = 0 WHERE TotalGridLoads1 IS NULL;


DROP TABLE rpt_main_02.stg_team_openedSheets2;
CREATE TABLE rpt_main_02.stg_team_openedSheets2
SELECT c.*
FROM rpt_main_02.arc_gridLoadLogRollup c
JOIN rpt_main_02.stg_team_churn_scoring_containers2 cont
	ON c.gridID=cont.displayObjectID
	AND c.insertByUserID=cont.userID
;

CREATE INDEX ix_userID_insertDate ON rpt_main_02.stg_team_openedSheets2 (insertByUserID, insertDate);


UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.TotalGridLoads2 =
(
        SELECT
        SUM(c.gridLoadCount)
        FROM rpt_main_02.stg_team_openedSheets2 c
        WHERE ba.userID=c.insertByUserID AND c.insertDate BETWEEN ba.startWeek AND ba.endWeek
        GROUP BY weekFriendly, ba.userID
);

UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.TotalGridLoads2 = 0 WHERE TotalGridLoads2 IS NULL;


UPDATE rpt_main_02.stg_team_churn_scoring ba 
	#INNER JOIN rpt_main_02.stg_team_churn_scoring AS ba1
	SET ba.TotalGridLoads = (ba.TotalGridLoads1+ba.TotalGridLoads2) 
	#	WHERE ba.paymentProfileID = ba1.paymentProfileID AND ba.weekFriendly=ba1.weekFriendly;
;

/* Sheets Created - User Level */
UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.sheetCount = 
(
	select 
	count(distinct containerID)
	FROM rpt_main_02.container c
	WHERE ba.userID = c.insertByUserID
	AND c.insertDateTime between ba.startWeek and ba.endWeek
	AND c.containerType = 2
	AND c.deletestatus = 0
	GROUP BY weekFriendly, ba.userID
)
;

UPDATE rpt_main_02.stg_team_churn_scoring SET sheetCount = 0 WHERE sheetCount IS NULL;

/* Sharing Count - User Level */

UPDATE rpt_main_02.stg_team_churn_scoring ba
SET ba.sharingCount =
(
        SELECT
        COUNT(gridID)
        FROM rpt_main_02.gridAccessMap gam
        WHERE ba.userID=gam.insertByUserID AND gam.insertDateTime BETWEEN ba.startWeek AND ba.endWeek
        AND ba.userID != gam.userID
        AND gam.deleteStatus = 0
        GROUP BY weekFriendly, ba.userID
)
;

UPDATE rpt_main_02.stg_team_churn_scoring SET sharingCount = 0 WHERE sharingCount IS NULL;



-- Create team level table
DROP TABLE IF EXISTS rpt_main_02.stg_team_level_churn_flagging;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_level_churn_flagging
SELECT DISTINCT 
weekFriendly,
startWeek,
endWeek,
paymentProfileID,
sourceUserID,
organizationID,
paymentType,
paymentStartDateTime,
weeksFromStart,
productName,
paymentTerm,
paymentTotal,
0 AS sumtrial,
trial,
userLimit,
0 AS licensesUsed,
teamSize,
modifyDateTime,
hist_effectiveThruDateTime,
OrgOrISP,
0 AS totalSharedUsers1,
0 AS totalSharedUsers2,
0 AS highProject1,
0 AS totalContainers1,
0 AS highProject2,
0 AS totalContainers2,
0 AS RunningLogCount,
0 AS totalSharedUsers,
0 AS RunningSheetsOpenedByAllCount,
0 AS RunningSheetCount,
0 AS RunningSharingCount,
0 As highProject
FROM rpt_main_02.stg_team_churn_scoring
;


ALTER TABLE rpt_main_02.stg_team_level_churn_flagging ADD PRIMARY KEY (paymentProfileID, weekFriendly);



UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.sumtrial=
(	SELECT COUNT(DISTINCT c.userID) 
	FROM rpt_main_02.stg_team_churn_scoring c
	WHERE c.paymentProfileID = ba.paymentProfileID
	AND ba.weekFriendly = c.weekFriendly
	AND c.sumtrial = '1'
	GROUP BY ba.weekFriendly, ba.paymentProfileID
)
;

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.licensesUsed=
(	SELECT p.activeProfileCount
	FROM rpt_main_02.rpt_paymentProfile p
	WHERE p.paymentProfileID = ba.paymentProfileID
	AND p.accountType = '3'
	GROUP BY ba.paymentProfileID
)
;

ALTER TABLE rpt_main_02.stg_team_level_churn_flagging modify trial DECIMAL(5,5);

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.trial = (ba.sumtrial/ba.licensesUsed);


UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.totalSharedUsers1 = 
(
	SELECT 
	COUNT(DISTINCT gam.userID)
	FROM rpt_main_02.gridAccessMap gam
	INNER JOIN rpt_main_02.stg_team_churn_scoring_containers1 cont
		ON cont.displayObjectID = gam.gridID
	WHERE ba.paymentProfileID=cont.paymentProfileID AND gam.insertDateTime < ba.endWeek
	AND cont.userID != gam.userID
	AND gam.deleteStatus = 0
	AND gam.access != 50
	GROUP BY weekFriendly, ba.paymentProfileID
);

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.totalSharedUsers2 = 
(
	SELECT 
	COUNT(DISTINCT gam.userID)
	FROM rpt_main_02.gridAccessMap gam
	INNER JOIN rpt_main_02.stg_team_churn_scoring_containers2 cont
		ON cont.displayObjectID = gam.gridID
	WHERE ba.paymentProfileID=cont.paymentProfileID AND gam.insertDateTime < ba.endWeek
	AND cont.userID != gam.userID
	AND gam.deleteStatus = 0
	AND gam.access != 50
	GROUP BY weekFriendly, ba.paymentProfileID
);


UPDATE rpt_main_02.stg_team_level_churn_flagging AS ba 
	SET ba.totalSharedUsers = (ba.totalSharedUsers1+ba.totalSharedUsers2);



/* Opened By All Count - Team Level Aggreagte */

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.RunningSheetsOpenedByAllCount =
(SELECT sum(A.TotalGridLoads) FROM rpt_main_02.stg_team_churn_scoring A
WHERE A.StartWeek < ba.EndWeek AND A.paymentProfileID = ba.paymentProfileID);


/* Sheet Count - Team Level Aggregate*/
UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.RunningSheetCount =
(SELECT sum(A.sheetCount) FROM rpt_main_02.stg_team_churn_scoring A
WHERE A.StartWeek < ba.EndWeek AND A.paymentProfileID = ba.paymentProfileID);


/* Sharing Count - Team Level Aggregate*/

update rpt_main_02.stg_team_level_churn_flagging ba
set ba.RunningSharingCount =
(SELECT sum(A.sharingCount) FROM rpt_main_02.stg_team_churn_scoring A
WHERE A.StartWeek < ba.EndWeek AND A.paymentProfileID = ba.paymentProfileID);


/* High Project */

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.highProject1 = 
(
	SELECT 
	SUM(CASE WHEN tcat.solutionCategory = 'Project Management' THEN 1 ELSE 0 END)
	FROM rpt_main_02.stg_team_churn_scoring_containers1 c
	LEFT OUTER JOIN rpt_main_02.rpt_containerSource CS
	ON c.containerID = CS.containerID
	LEFT OUTER JOIN rpt_main_02.ref_templateCategories tcat 
	ON tcat.containerID=CS.sourceID
	WHERE ba.paymentProfileID = c.paymentProfileID
	AND c.insertDate <= DATE_FORMAT(ba.endWeek, '%Y-%m-%d')
	GROUP BY ba.weekFriendly, ba.paymentProfileID
	
);

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.totalContainers1 = 
(
	SELECT count(distinct c.containerID)
	FROM rpt_main_02.stg_team_churn_scoring_containers1 c
	WHERE ba.paymentProfileID=c.paymentProfileID
	AND c.insertDate <= DATE_FORMAT(ba.endWeek,'%Y-%m-%d')
	GROUP BY ba.weekFriendly, ba.paymentProfileID
)
;


UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.highProject2 = 
(
	SELECT 
	SUM(CASE WHEN tcat.solutionCategory = 'Project Management' THEN 1 ELSE 0 END)
	FROM rpt_main_02.stg_team_churn_scoring_containers2 c
	LEFT OUTER JOIN rpt_main_02.rpt_containerSource CS
	ON c.containerID = CS.containerID
	LEFT OUTER JOIN rpt_main_02.ref_templateCategories tcat 
	ON tcat.containerID=CS.sourceID
	WHERE ba.paymentProfileID = c.paymentProfileID
	AND c.insertDate <= DATE_FORMAT(ba.endWeek, '%Y-%m-%d')
	GROUP BY ba.weekFriendly, ba.paymentProfileID
);

UPDATE rpt_main_02.stg_team_level_churn_flagging ba
SET ba.totalContainers2 = 
(
	SELECT count(distinct c.containerID)
	FROM rpt_main_02.stg_team_churn_scoring_containers2 c
	WHERE ba.paymentProfileID=c.paymentProfileID
	AND c.insertDate <= DATE_FORMAT(ba.endWeek,'%Y-%m-%d')
	GROUP BY ba.weekFriendly, ba.paymentProfileID
)
;


UPDATE rpt_main_02.stg_team_level_churn_flagging AS ba
SET ba.highProject = CASE WHEN (ba.highProject1+ba.highProject2)/(ba.totalContainers1+ba.totalContainers2) > 0.50 THEN 1 ELSE 0 END;

-- Determine most recent week to compare stats against

DROP TABLE IF EXISTS rpt_main_02.stg_team_churn_mostRecentWeek;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_churn_mostRecentWeek
SELECT paymentProfileID, max(startWeek) AS maxWeek
FROM rpt_main_02.stg_team_churn_scoring
GROUP BY paymentProfileID
;

ALTER TABLE rpt_main_02.stg_team_churn_mostRecentWeek ADD PRIMARY KEY (paymentProfileID, maxWeek);


DROP TABLE IF EXISTS rpt_main_02.stg_team_churn_maxWeek;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_team_churn_maxWeek
SELECT csw.*
	FROM rpt_main_02.stg_team_level_churn_flagging csw
	JOIN rpt_main_02.stg_team_churn_mostRecentWeek mrw ON csw.paymentProfileID=mrw.paymentProfileID
		AND csw.startWeek=mrw.maxWeek	
;

ALTER TABLE rpt_main_02.stg_team_churn_maxWeek ADD PRIMARY KEY (paymentProfileID);


CREATE TABLE IF NOT EXISTS rpt_main_02.arc_team_churn_scoring_NEW
(
	mainContactDomain VARCHAR(100),
	orgName VARCHAR(100),
	mainContactEmailAddress VARCHAR(200),
	paymentProfileID bigint,
	paymentStartDateTime datetime,
	weeksFromStart INT,
	maxWeek INT,
	productName VARCHAR(50),
	paymentTerm VARCHAR(50),
	paymentTotal DECIMAL(30,2),
	OrgOrISP VARCHAR(5),
	teamSize INT,
	trial DECIMAL(5,5) DEFAULT 0,
	licensesUsed INT,
	totalSharedUsers INT DEFAULT 0,
	RunningSheetCount INT DEFAULT 0,
	RunningSheetsOpenedByAllCount INT DEFAULT 0,
	RUnningSharingCount INT DEFAULT 0,
	highProject INT DEFAULT 0,
	RunningLogCount INT DEFAULT 0,
	teamSize_maxWeek INT DEFAULT 0,
	networkReach_maxWeek INT  DEFAULT 0,
	sheetcount_maxWeek INT DEFAULT 0,
	sharingcount_maxWeek INT DEFAULT 0,
	projectcount_maxWeek INT DEFAULT 0,
	logcount_maxWeek INT DEFAULT 0,
	opencount_maxWeek INT DEFAULT 0,
	willChurn INT,
	willChurn_maxWeek INT
)
;

#TRUNCATE TABLE rpt_main_02.arc_team_churn_scoring_NEW;

-- Monthly Team 10+ at Week 4
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk4,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 4, 11, a.totalSharedUsers,0,0) AS willChurn_wk4,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4, 11, b.totalSharedUsers,0,0) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit > 10
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 4
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE 
(a.willChurn_wk4 = 1
OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4,11, b.totalSharedUsers,0,0),
	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 4
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize > 10
#AND acs.maxWeek > 4
AND b.weeksFromStart > 4
;





-- Annual Team 10+ at Week 8
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk8,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 8, 11, a.totalSharedUsers,0,0) AS willChurn_wk8,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 8, 11, b.totalSharedUsers,0,0) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit > 10
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Annual'
	AND a.weeksFromStart = 8
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE 
(a.willChurn_wk8 = 1
OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 8,11, b.totalSharedUsers,0,0),
	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 8
AND acs.paymentTerm = 'Annual'
AND acs.teamSize > 10
#AND acs.maxWeek > 8
AND b.weeksFromStart > 8
;


-- Monthly Team 3-5 at Week 1
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk1,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 1, 3, 
	CASE WHEN a.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_wk1,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 1, 3, 
	CASE WHEN b.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit BETWEEN 3 AND 5
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 1
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE (a.willChurn_wk1 = 1 OR a.willChurn_maxWeek = 1)
AND DATEDIFF(NOW(),a.paymentStartDateTime) >= 7
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 

	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 1, 3, 
	CASE WHEN b.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END),

	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 1
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize BETWEEN 3 AND 5
#AND acs.maxWeek > 1
AND b.weeksFromStart > 1
;



-- Monthly Team 3-5 at Week 4
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk4,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 4, 3, 
	CASE WHEN a.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_wk4,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4, 3, 
	CASE WHEN b.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit BETWEEN 3 AND 5
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 4
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE (a.willChurn_wk4 = 1 OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 

	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4, 3, 
	CASE WHEN b.RunningSheetsOpenedByAllCount > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END),

	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 4
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize BETWEEN 3 AND 5
#AND acs.maxWeek > 4
AND b.weeksFromStart > 4
;



-- Monthly Team 3-5 at Week 20
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk20,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 20, 3, 
	CASE WHEN a.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.RunningSheetCount > 0 THEN 1 ELSE 0 END,
	a.RunningSheetCount) AS willChurn_wk20,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 20, 3, 
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END,
	b.RunningSheetCount) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit BETWEEN 3 AND 5
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 20
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE (a.willChurn_wk20 = 1 OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 

	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 20, 3, 
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END,
	b.RunningSheetCount),

	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 20
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize BETWEEN 3 AND 5
#AND acs.maxWeek > 20
AND b.weeksFromStart > 20
;


-- Monthly Team 6-10 at Week 4
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk4,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 4, 6, 
	a.RunningSheetsOpenedByAllCount,
	CASE WHEN a.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN a.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_wk4,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4, 6, 
	b.RunningSheetsOpenedByAllCount,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit BETWEEN 6 AND 10
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 4
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE (a.willChurn_wk4 = 1 OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 

	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 4, 6, 
	b.RunningSheetsOpenedByAllCount,
	CASE WHEN b.totalSharedUsers > 0 THEN 1 ELSE 0 END,
	CASE WHEN b.RunningSheetCount > 0 THEN 1 ELSE 0 END),

	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 4
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize BETWEEN 6 AND 10
#AND acs.maxWeek > 4
AND b.weeksFromStart > 4
;


-- Monthly Team 6-10 at Week 20
INSERT INTO rpt_main_02.arc_team_churn_scoring_NEW
SELECT 
pp.mainContactDomain, 
o.name AS OrgName, 
ua.emailAddress, 
a.paymentProfileID,
a.paymentStartDateTime,
a.weeksFromStart,
a.maxWeek,
a.productName,
a.paymentTerm,
a.paymentTotal,
a.OrgOrISP,
a.userLimit,
a.trial,
a.licensesUsed,
a.totalSharedUsers,
a.RunningSheetCount,
a.RunningSheetsOpenedByAllCount,
a.RunningSharingCount,
a.highProject,
a.RunningLogCount,
a.maxWeekTeamSize,
a.maxWeekNetworkReach,
a.maxWeekSheetCount,
a.maxWeekSharingCount,
a.maxWeekproject,
a.maxWeekLogCount,
a.maxWeekOpenCount,
a.willChurn_wk20,
a.willChurn_maxWeek
FROM
(
	SELECT a.*, 
	b.weeksFromStart AS maxWeek, b.totalSharedUsers AS maxWeekNetworkReach, b.userLimit AS maxWeekTeamSize, 
	b.RunningSheetCount AS maxWeekSheetCount, b.RunningSheetsOpenedByAllCount AS maxWeekOpenCount, b.highProject AS maxWeekproject, b.RunningLogCount AS maxWeekLogCount,
	b.RunningSharingCount AS maxWeekSharingCount,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(a.paymentTerm, a.productName, 20, 6, 
	CASE WHEN a.RunningSharingCount > 0 THEN 1 ELSE 0 END,
	a.RunningSheetsOpenedByAllCount,
	a.highProject) AS willChurn_wk20,
	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 20, 6, 
	CASE WHEN b.RunningSharingCount > 0 THEN 1 ELSE 0 END,
	b.RunningSheetsOpenedByAllCount,
	b.highProject) AS willChurn_maxWeek
	FROM rpt_main_02.stg_team_level_churn_flagging a
	LEFT JOIN rpt_main_02.stg_team_churn_maxWeek b ON a.paymentProfileID=b.paymentProfileID
	WHERE 
	a.productName = 'Team'
	#AND a.teamSize = 11
	AND a.userLimit BETWEEN 6 AND 10
	AND a.startWeek >= '2013-01-01'
	AND a.paymentTerm = 'Monthly'
	AND a.weeksFromStart = 20
	#AND b.weeksFromStart = 4 -- Have Not Gone Beyond Week 4
) a
LEFT JOIN rpt_paymentProfile pp ON a.paymentProfileID=pp.paymentProfileID
LEFT JOIN organization o ON a.organizationID=o.organizationID
LEFT JOIN userAccount ua ON o.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_team_churn_scoring_NEW ins ON a.paymentProfileID=ins.paymentProfileID AND a.weeksFromStart=ins.weeksFromStart
WHERE (a.willChurn_wk20 = 1 OR a.willChurn_maxWeek = 1)
AND ins.paymentProfileID IS NULL
;


UPDATE rpt_main_02.arc_team_churn_scoring_NEW acs
JOIN rpt_main_02.stg_team_churn_maxWeek b ON acs.paymentProfileID=b.paymentProfileID
SET acs.willChurn_maxWeek = 

	rpt_main_02.SMARTSHEET_CHURN_SCORE(b.paymentTerm, b.productName, 20, 6, 
	CASE WHEN b.RunningSharingCount > 0 THEN 1 ELSE 0 END,
	b.RunningSheetsOpenedByAllCount,
	b.highProject),

	acs.maxWeek=b.weeksFromStart
WHERE acs.weeksFromStart = 20
AND acs.paymentTerm = 'Monthly'
AND acs.teamSize BETWEEN 6 AND 10
#AND acs.maxWeek > 20
AND b.weeksFromStart > 20
;
