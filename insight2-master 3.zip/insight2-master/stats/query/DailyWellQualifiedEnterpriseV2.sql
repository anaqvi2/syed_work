SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyWellQualifiedEnterpriseV2.csv");


/*CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_sfdc_upload(
	uploadID BIGINT NOT NULL AUTO_INCREMENT,
	Company VARCHAR(100),
	OwnerID VARCHAR(25),
	STATUS VARCHAR(25),
	domain__c VARCHAR(100),
	FirstName VARCHAR(50),
	LastName VARCHAR(50), 	
	Email VARCHAR(100),
	Street VARCHAR(100),	
	City VARCHAR(50),
	State VARCHAR(25),
	PostalCode VARCHAR(25),
	Country VARCHAR(25),
	Phone VARCHAR (100),
	NumberOfEmployees INT,
	AnnualRevenue DECIMAL (32,10),	
	Title VARCHAR(50),
	Website VARCHAR(100),
	LeadSource VARCHAR(25),
	uploadDateTime DATETIME,
	PRIMARY KEY(uploadID)); */

/*Generate output of Daily Well Quals for \\SOL */
SELECT arc_HooversCompanyData.companyName,
	userAccount.domain,
	userAccount.firstName,
	CASE userAccount.lastName IS NULL 
	WHEN 1 THEN "No Last Name"
	ELSE userAccount.lastName END AS 'lastName',
	NULL AS "Title",
	userAccount.emailAddress,
	arc_HooversCompanyData.address AS "Street Address",
	arc_HooversCompanyData.primaryCity,
	arc_HooversCompanyData.primaryState,
	arc_HooversCompanyData.postalCode AS "PostalCode",
	userAccount.countryFriendly AS Country,
	arc_HooversCompanyData.employeesTotal,
	CASE arc_sfdc_stateRegions.SSAssignee 
		WHEN "Taryn" 	THEN "00540000001U30S"
		WHEN "Tim" 	THEN "00540000001U30X"
		When "Eric" THEN "00540000001UiO2"
		ELSE "Error" 
		END AS SSAssigneeID,	
	CASE arc_sfdc_stateRegions.SSAssignee IS NULL 
		WHEN 1 THEN "Error" ELSE arc_sfdc_stateRegions.SSAssignee
	END AS SSAssignee,
	
	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID IN(3,4,6,7,10,11)) AS "Current Paid Users From Domain",
	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 AND ProfileCount.productID = 6
	 	AND ProfileCount.productID IN(3,4,6,7,10,11)) AS "Current Enterprise Users From Domain",
		
	CASE WHEN arc_DailyWellQualifiedProsumer.SSOwner IS NULL THEN "Not Contacted" ELSE arc_DailyWellQualifiedProsumer.SSOwner END AS DailyReachoutContact,

	userAccount.languageFriendly AS "Language",
	arc_HooversCompanyData.primaryState,

	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead'

FROM rpt_main_02.arc_DailyWellQualifiedLeads
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedProsumer ON arc_DailyWellQualifiedProsumer.userID = arc_DailyWellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.userAccount AS userAccount ON userAccount.userID = arc_DailyWellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON arc_DailyWellQualifiedLeads.userID = rpt_paymentProfile.mainContactUserID AND rpt_paymentProfile.accountType != 3
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
LEFT OUTER JOIN rpt_main_02.arc_sfdc_stateRegions ON arc_HooversCompanyData.primaryState = arc_sfdc_stateRegions.state
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID =  rpt_clientLogCountsByUserArchived.userID

WHERE arc_DailyWellQualifiedLeads.snapshotDate = CURRENT_DATE()
AND userAccount.countryFriendly = "United States"
AND arc_HooversCompanyData.employeesTotal >= 1000
AND userAccount.domain NOT LIKE "%yahoo%"
AND userAccount.domain NOT LIKE "live.%"
AND userAccount.domain NOT LIKE "hotmail.%"
AND userAccount.domain NOT LIKE "%.rr.com"
AND userAccount.domain NOT IN ('Aol.com', 
'att.net',
'bellsouth.net',
'bigpond.com',
'bigpond.net.au',
'btinternet.com',
'comcast.net', 
'cox.net',
'charter.net',
'earthlink.net',
'gmail.com', 
'googlemail.com', 
'hotmail.com', 
'hotmail.co.uk', 
'hotmail.es', 
'hotmail.fr', 
'live.com', 
'mac.com',
'mail.com',
'me.com',
'msn.com', 
'mweb.co.za',
'optusnet.com.au',
'orange.fr',
'outlook.com',
'prodigy.net.mx',
'rogers.com',
'sbcglobal.net', 
'shaw.ca',
'telus.net',
'uol.com.br',
'verizon.net', 
'vodafone.co.nz',
'westnet.com.au',
'xtra.co.nz',
'ymail.com',
'live.co.uk',
'me.com',
'sympatico.ca',
'free.fr',
'163.com',
'naver.com',
'sky.com',
'rocketmail.com',
'mail.ru',
'ig.com.br',
'rediffmail.com',
'qq.com',
'terra.com.br',
'bol.com.br',
'ntlworld.com',
'talktalk.net',
'btconnect.com',
'eircom.net',
'laposte.net',
'libero.it',
'wanadoo.fr',
'videotron.ca',
'iinet.net.au',
'ibest.com.br',
'tiscali.co.uk',
'gmx.de',
'juno.com',
'blueyonder.co.uk',
'juno.com',
'aim.com',
'oi.com.br',
'126.com',
'sapo.pt',
'yandex.ru',
'optonline.net',
'web.de',
'globo.com',
'sfr.fr',
'embarqmail.com',
'roadrunner.com',
'hanmail.net')

GROUP BY userAccount.emailAddress

ORDER BY 19 DESC, 13;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyWellQualifiedEnterpriseV2.csv");
