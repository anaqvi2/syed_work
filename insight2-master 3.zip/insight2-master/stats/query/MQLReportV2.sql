SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("MQLReportV2.sql");

drop table if exists rpt_main_02.rpt_MQLEnrichment;
create table if not exists rpt_main_02.rpt_MQLEnrichment
(TASK_ID varchar(50),
OPPORTUNITY_ID varchar(50),
DIRECT_MAPPING int,
contactMapping int,
accountMapping int,
mappingType varchar(50),
TASK_TRAFFIC_SOURCE varchar(100),
TASK_SOURCE varchar(50),
TASK_SUB_SOURCE varchar(50),
taskCreatedDate datetime,
TASK_SUBJECT varchar(100),
taskOwnerID varchar(50),
taskOwner varchar(50),
taskOwnerRole varchar(50),
taskWhoID varchar(50),
TASK_TTTC dec(10,2),
TASK_STATUS varchar(50),
taskWhoType varchar(50),
taskWhoName varchar(50),
taskWhoEmailAddress varchar(50),
taskWhoTitle varchar(50),
taskWhoUserID int,
taskWhoDomain varchar(50),
taskWhoDomainISP int,
taskWhoAccountID varchar(50),
taskWhoAccountName varchar(50),
taskWhoDomainIsFortune1000 int,
taskWhoDomainIsExistingCustomer int,
taskWhoProductNameAtCreation varchar(50),
taskWhoFollowUpActivityCount int,
taskWhoStrongLead int,
taskWhoCompanySize varchar(50),
OPPORTUNITY_NAME varchar(100),
opportunityCreatedDate datetime,
OPPORTUNITY_STAGE varchar(50),
OPPORTUNITY_ARR dec(10,2),
OPPORTUNITY_COMMISH_ARR dec(10,2),
OPPORTUNITY_OWNERID varchar(50),
OPPORTUNITY_OWNER varchar(50),
opportunityCloseDate date,
opportunityDateDiff int,
opportunityClosedWonID varchar(50),
opportunityCycleTime int,
opportunitySecurityPack varchar(10),
opportunityIntegrationPack varchar(10),
opportunitySights varchar(10),
opportunitySalesforce varchar(10),
opportunitySCC varchar(10),
opportunityJira varchar(10),
taskCount int,
TASK_TTTCCalc dec(10,3),
taskWhoFollowUpActivityCountCalc dec(10,3),
opportunityCount int,
OPPORTUNITY_ARRCalc dec(10,3),
taskBucket varchar(50),
taskWhoDomainNewLogo int,
taskWhoCount int,
taskWhoIDProrated dec(10,3),
OPPORTUNITY_ID2 varchar(50),
OPPORTUNITY_STAGE2 varchar(50),
OPPORTUNITY_ARR2 dec(10,2),
opportunityDateDiff2 int,
opportunityCycleTime2 int,
opportunityCount2 int,
OPPORTUNITY_ARRCalc2 dec(10,3),
OPPORTUNITY_ID3 varchar(50),
OPPORTUNITY_STAGE3 varchar(50),
OPPORTUNITY_ARR3 dec(10,2),
opportunityDateDiff3 int,
opportunityCycleTime3 int,
opportunityCount3 int,
OPPORTUNITY_ARRCalc3 dec(10,3),
OPPORTUNITY_IDProrated dec(10,3),
OPPORTUNITY_IDProrated2 dec(10,3),
OPPORTUNITY_IDProrated3 dec(10,3),
primary key (TASK_ID, OPPORTUNITY_ID));

INSERT IGNORE INTO rpt_main_02.rpt_MQLEnrichment(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, taskCreatedDate, TASK_SUBJECT, taskOwnerID, taskWhoID, TASK_TTTC, TASK_STATUS, DIRECT_MAPPING,
OPPORTUNITY_ID, OPPORTUNITY_NAME, opportunityCreatedDate, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNERID, OPPORTUNITY_OWNER, opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhoID, A.Time_To_Task_Completion__c, A.Status, 1,
B.Id, B.Name, B.CreatedDate, B.StageName, (B.ARR_Variance__c/hce.exchangeRate), (B.Commissionable_ACV__c/hce.exchangeRate), 
B.OwnerID, CONCAT(C.FirstName,' ',C.LastName), B.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.opportunity B
ON A.WHAT_ID=B.Id
JOIN ss_sfdc_02.user C
ON B.OwnerId=C.Id
LEFT JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = B.CurrencyIsoCode 
	AND B.CloseDate BETWEEN hce.modifyDateTime AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND B.CreatedDate >= A.CreatedDate AND B.CloseDate >= '2016-01-01';


INSERT IGNORE INTO rpt_main_02.rpt_MQLEnrichment(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, taskCreatedDate, TASK_SUBJECT, taskOwnerID, taskWhoID, TASK_TTTC, TASK_STATUS, contactMapping,
OPPORTUNITY_ID, OPPORTUNITY_NAME, opportunityCreatedDate, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNERID, OPPORTUNITY_OWNER, opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhoID, A.Time_To_Task_Completion__c, A.Status, 1,
D.Id, D.Name, D.CreatedDate, D.StageName, (D.ARR_Variance__c/hce.exchangeRate), (D.Commissionable_ACV__c/hce.exchangeRate), 
D.OwnerID, CONCAT(E.FirstName,' ',E.LastName), D.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.contact B 
ON A.WhoID=B.Id
JOIN ss_sfdc_02.opportunity_contact_role C
ON B.Id=C.ContactId
JOIN ss_sfdc_02.opportunity D
ON C.OpportunityID=D.Id
JOIN ss_sfdc_02.user E
ON D.OwnerId=E.Id
LEFT JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = D.CurrencyIsoCode 
	AND D.CloseDate BETWEEN hce.modifyDateTime AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND D.CreatedDate >= A.CreatedDate AND D.CreatedDate < DATE_ADD(A.CreatedDate, INTERVAL 60 DAY) AND D.Amount > 0 AND D.CloseDate >= '2016-01-01';

INSERT IGNORE INTO rpt_main_02.rpt_MQLEnrichment(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, taskCreatedDate, TASK_SUBJECT, taskOwnerID, taskWhoID, TASK_TTTC, TASK_STATUS, accountMapping,
OPPORTUNITY_ID, OPPORTUNITY_NAME, opportunityCreatedDate, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNERID, OPPORTUNITY_OWNER, opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhoID, A.Time_To_Task_Completion__c, A.Status, 1,
C.Id, C.Name, C.CreatedDate, C.StageName, (C.ARR_Variance__c/hce.exchangeRate), (C.Commissionable_ACV__c/hce.exchangeRate), 
C.OwnerID, CONCAT(D.FirstName,' ',D.LastName), C.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.contact B 
ON A.WhoID=B.Id
JOIN ss_sfdc_02.opportunity C
ON B.AccountId=C.AccountId
JOIN ss_sfdc_02.user D
ON C.OwnerId=D.Id
LEFT JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = C.CurrencyIsoCode 
	AND C.CloseDate BETWEEN hce.modifyDateTime AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND C.CreatedDate >= A.CreatedDate AND C.CreatedDate < DATE_ADD(A.CreatedDate, INTERVAL 60 DAY) AND C.Amount > 0 AND C.CloseDate >= '2016-01-01';

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'\r','');

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'\n','');

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
join ss_sfdc_02.opportunity_contact_role C
on B.Id=C.ContactId
join ss_sfdc_02.opportunity D
on C.OpportunityID=D.Id
join ss_sfdc_02.user E
on D.OwnerId=E.Id
set A.contactMapping=1
where D.CreatedDate >= date(A.taskCreatedDate) and D.CreatedDate < date_add(A.taskCreatedDate, interval 60 day) and A.OPPORTUNITY_ID=D.Id and A.DIRECT_MAPPING=1;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
join ss_sfdc_02.opportunity C
on B.AccountId=C.AccountId
join ss_sfdc_02.user D
on C.OwnerId=D.Id
set A.accountMapping=1
where C.CreatedDate >= A.taskCreatedDate and C.CreatedDate < date_add(A.taskCreatedDate, interval 60 day) and A.OPPORTUNITY_ID=C.Id and (A.DIRECT_MAPPING=1 or A.contactMapping=1);

update rpt_main_02.rpt_MQLEnrichment
set mappingType=
case when DIRECT_MAPPING=1 and contactMapping is null and accountMapping is null then 'Direct Only'
when DIRECT_MAPPING=1 and contactMapping=1 and accountMapping is null then 'Direct and Contact'
when DIRECT_MAPPING=1 and contactMapping is null and accountMapping=1 then 'Direct and Account'
when DIRECT_MAPPING=1 and contactMapping=1 and accountMapping=1 then 'Direct and Contact and Account'
when DIRECT_MAPPING is null and contactMapping=1 and accountMapping is null then 'Contact Only'
when DIRECT_MAPPING is null and contactMapping=1 and accountMapping=1 then 'Contact and Account'
when DIRECT_MAPPING is null and contactMapping is null and accountMapping=1 then 'Account Only'
end;

-- section to get if taskWhoDomain is ISP and switch mapping type to 'No Mapping' when current mapping type is 'Account Only'
update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.lead B
on A.taskWhoID=B.Id
left join ss_sfdc_02.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join ss_sfdc_02.account D
on C.Account__c=D.Id
set A.taskWhoName=concat(B.FirstName,' ',B.LastName), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoDomain=B.Domain__c, A.taskWhoAccountID=D.Id, A.taskWhoAccountName=D.Name, A.taskWhoType='Lead'
where A.taskWhoName is null;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
left join ss_sfdc_02.account C
on B.AccountId=C.Id
set A.taskWhoName=concat(B.FirstName,' ',B.LastName), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name, A.taskWhoType='Contact'
where A.taskWhoName is null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.userAccount B
on A.taskWhoEmailAddress=B.emailAddress
set A.taskWhoUserID=B.userID;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set A.taskWhoDomain=B.domain
where taskWhoDomain is null;

update rpt_main_02.rpt_MQLEnrichment
set taskWhoDomain=(SUBSTR(taskWhoEmailAddress, INSTR(taskWhoEmailAddress, '@') + 1))
where taskWhoDomain is null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.arc_ISPDomains B
on A.taskWhoDomain=B.domain
set A.taskWhoDomainISP=1;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.domain B
on A.taskWhoDomain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id 
set A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name
where A.taskWhoAccountID is null;

delete from rpt_main_02.rpt_MQLEnrichment
where taskWhoDomainISP=1 and mappingType='Account Only';

delete from rpt_main_02.rpt_MQLEnrichment
where taskWhoAccountName like '%ISP Account%' and mappingType='Account Only';

delete from rpt_main_02.rpt_MQLEnrichment
where taskWhoAccountID='0014000000mw0ZMAAY';

-- insert for tasks that do not map to any opportunities
drop table if exists rpt_main_02.rpt_MQLEnrichmentStaging2;
create table if not exists rpt_main_02.rpt_MQLEnrichmentStaging2
(TASK_ID varchar(50),
primary key (TASK_ID));

insert ignore into rpt_main_02.rpt_MQLEnrichmentStaging2
select TASK_ID from rpt_main_02.rpt_MQLEnrichment;

INSERT IGNORE INTO rpt_main_02.rpt_MQLEnrichment(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, taskCreatedDate, TASK_SUBJECT, taskOwnerID, taskWhoID, TASK_TTTC, TASK_STATUS, mappingType)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhoID, A.Time_To_Task_Completion__c, A.Status, 'No Mapping'
FROM ss_sfdc_02.task A
LEFT JOIN rpt_main_02.rpt_MQLEnrichmentStaging2 B
on A.Id=B.TASK_ID
WHERE A.Traffic_Source__c != '' AND B.TASK_ID IS NULL;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.lead B
on A.taskWhoID=B.Id
left join ss_sfdc_02.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join ss_sfdc_02.account D
on C.Account__c=D.Id
set A.taskWhoName=concat(B.FirstName,' ',B.LastName), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoDomain=B.Domain__c, A.taskWhoAccountID=D.Id, A.taskWhoAccountName=D.Name, A.taskWhoType='Lead'
where A.taskWhoName is null;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
left join ss_sfdc_02.account C
on B.AccountId=C.Id
set A.taskWhoName=concat(B.FirstName,' ',B.LastName), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name, A.taskWhoType='Contact'
where A.taskWhoName is null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.userAccount B
on A.taskWhoEmailAddress=B.emailAddress
set A.taskWhoUserID=B.userID
where A.taskWhoUserID is null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set A.taskWhoDomain=B.domain
where taskWhoDomain is null;

update rpt_main_02.rpt_MQLEnrichment
set taskWhoDomain=(SUBSTR(taskWhoEmailAddress, INSTR(taskWhoEmailAddress, '@') + 1))
where taskWhoDomain is null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.arc_ISPDomains B
on A.taskWhoDomain=B.domain
set A.taskWhoDomainISP=1
where A.taskWhoDomainISP is null;

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.domain B
on A.taskWhoDomain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id 
set A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name
where A.taskWhoAccountID is null;

update rpt_main_02.rpt_MQLEnrichment 
set taskWhoAccountID=null, taskWhoAccountName=null
where taskWhoAccountID='' or taskWhoDomainISP=1;

update rpt_main_02.rpt_MQLEnrichment A
set A.TASK_SOURCE = 'None'
where A.TASK_SOURCE is null or A.TASK_SOURCE = '';

update rpt_main_02.rpt_MQLEnrichment A
set A.TASK_SUB_SOURCE = 'None'
where A.TASK_SUB_SOURCE is null or A.TASK_SUB_SOURCE = '';

update rpt_main_02.rpt_MQLEnrichment
set TASK_SOURCE=TASK_SUB_SOURCE, TASK_SUB_SOURCE='None'
where TASK_SOURCE='None';

update rpt_main_02.rpt_MQLEnrichment
set opportunityDateDiff=datediff(opportunityCreatedDate, taskCreatedDate);

update rpt_main_02.rpt_MQLEnrichment
set opportunityClosedWonID=OPPORTUNITY_ID
where OPPORTUNITY_STAGE='Closed Won';

update rpt_main_02.rpt_MQLEnrichment
set opportunityCycleTime=datediff(opportunityCloseDate, taskCreatedDate)
where opportunityClosedWonID is not null;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.ref_Oct2016fortune1000 B
on A.taskWhoDomain=B.domain
set taskWhoDomainIsFortune1000=1;

drop table if exists rpt_main_02.rpt_MQLEnrichmentStaging3;
create table if not exists rpt_main_02.rpt_MQLEnrichmentStaging3
select domain, min(winDate) as winDate from rpt_workspace.cDunn_allPlansPurchased 
group by 1;

alter table rpt_main_02.rpt_MQLEnrichmentStaging3
add ,
add ;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.rpt_MQLEnrichmentStaging3 B force 
on A.taskWhoDomain=B.domain and A.taskCreatedDate >= B.winDate
set A.taskWhoDomainIsExistingCustomer=1;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.hist_paymentProfile B
on A.taskWhoUserID=B.ownerID and B.accountType!=3 and B.modifyDateTime <= A.taskCreatedDate and B.HIST_EFFECTIVE_THRU_DATE_TIME > A.taskCreatedDate
set A.taskWhoProductNameAtCreation=rpt_main_02.SMARTSHEET_PRODUCTNAME(B.productID);

update rpt_main_02.rpt_MQLEnrichment
set taskWhoProductNameAtCreation='Free / Cancelled'
where taskWhoProductNameAtCreation in ('Free','Cancelled');

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set taskWhoProductNameAtCreation='Collab'
where A.taskCreatedDate > B.insertDateTime and A.taskWhoProductNameAtCreation is null;

UPDATE rpt_main_02.rpt_MQLEnrichment A
JOIN ss_sfdc_02.user B 
ON A.taskOwnerID=B.Id
JOIN ss_sfdc_02.user_role C 
ON B.userRoleID=C.Id
SET A.taskOwner = CONCAT(B.FirstName,' ',B.LastName), A.taskOwnerRole = C.Name;

update rpt_main_02.rpt_MQLEnrichment A
set taskWhoFollowUpActivityCount=
(select count(distinct B.Id) from ss_sfdc_02.task B
join ss_sfdc_02.lead C
on B.WhoId=C.Id 
where A.taskWhoEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.taskCreatedDate, interval 30 day) and B.LastModifiedDate > A.taskCreatedDate)
where taskWhoType='Lead';

update rpt_main_02.rpt_MQLEnrichment A
set taskWhoFollowUpActivityCount=
(select count(distinct B.Id) from ss_sfdc_02.task B
join ss_sfdc_02.contact C
on B.WhoId=C.Id 
where A.taskWhoEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.taskCreatedDate, interval 30 day) and B.LastModifiedDate > A.taskCreatedDate)
where taskWhoType='Contact';

update rpt_main_02.rpt_MQLEnrichment A
join ss_sfdc_02.opportunity B
on A.opportunityId=B.Id 
set A.opportunitySecurityPack=B.Security_Pack__c, A.opportunityIntegrationPack=B.Integration_Pack__c, A.opportunitySights=B.Dashboards__c, 
A.opportunitySalesforce=B.Salesforce_Integration__c, A.opportunitySCC=B.Project_Control_Center__c, A.opportunityJira=B.Jira_Integration__c;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.stg_tableauTrialReport B
on A.taskWhoUserID=B.userID
set A.taskWhoStrongLead=B.IsStrongLead;

update rpt_main_02.rpt_MQLEnrichment A
join rpt_workspace.pj_domainDataCoverage B
on A.taskWhoDomain=B.domain
set A.taskWhoCompanySize=B.companySize;

drop table if exists rpt_main_02.rpt_MQLEnrichmentCopy;
create table if not exists rpt_main_02.rpt_MQLEnrichmentCopy like rpt_main_02.rpt_MQLEnrichment;
insert into rpt_main_02.rpt_MQLEnrichmentCopy select * from rpt_main_02.rpt_MQLEnrichment;

alter table rpt_main_02.rpt_MQLEnrichmentCopy
add ,
add ,
add ;

update rpt_main_02.rpt_MQLEnrichment A
join (select TASK_ID, count(*) as taskCount from rpt_main_02.rpt_MQLEnrichmentCopy
group by 1) B
on A.TASK_ID=B.TASK_ID
set A.taskCount=B.taskCount;

update rpt_main_02.rpt_MQLEnrichment
set TASK_TTTCCalc=TASK_TTTC/taskCount;

update rpt_main_02.rpt_MQLEnrichment
set taskWhoFollowUpActivityCountCalc=taskWhoFollowUpActivityCount/taskCount;

update rpt_main_02.rpt_MQLEnrichment A
join (select OPPORTUNITY_ID, count(*) as oppCount from rpt_main_02.rpt_MQLEnrichmentCopy
where OPPORTUNITY_ID!=''
group by 1) B
on A.OPPORTUNITY_ID=B.OPPORTUNITY_ID
set A.opportunityCount=B.oppCount
where A.OPPORTUNITY_ID!='';

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_ARRCalc=OPPORTUNITY_ARR/opportunityCount;

update rpt_main_02.rpt_MQLEnrichment
set taskBucket=
case when TASK_TRAFFIC_SOURCE like 'Support Case%' then 'Support'
when TASK_TRAFFIC_SOURCE like 'Inbound Email%' then 'Email'
when TASK_TRAFFIC_SOURCE like 'G2 Crowd%' or TASK_TRAFFIC_SOURCE like 'Software Advice%' or TASK_TRAFFIC_SOURCE like 'IT Central Station%' or TASK_TRAFFIC_SOURCE like 'Technology Advice%' then 'Purchased Leads'
when TASK_TRAFFIC_SOURCE like 'Trial with%' or TASK_TRAFFIC_SOURCE like 'Post Trial Survey%' then 'Trial Flow'
when TASK_TRAFFIC_SOURCE like 'Trigger%' then 'Triggers'
when TASK_TRAFFIC_SOURCE like 'E-book%' or TASK_TRAFFIC_SOURCE like 'Forrester Wave Report%' then 'E-Books & Whitepapers'
when TASK_TRAFFIC_SOURCE like 'Webinar%' then 'Webinar'
when TASK_TRAFFIC_SOURCE like 'Chat%' then 'Chat'
when TASK_TRAFFIC_SOURCE like 'Direct Mail%' or TASK_TRAFFIC_SOURCE like 'Prospecting%' then 'Outbound Campaigns'
-- 'contains' matches after all the 'starts with' matches
when TASK_TRAFFIC_SOURCE like '%Contact Us%' or TASK_TRAFFIC_SOURCE like 'Enterprise Pricing%' or TASK_TRAFFIC_SOURCE like 'Enterprise Work Management Page%' or TASK_TRAFFIC_SOURCE like 'Sights Trial Request%' then 'Contact Us Forms'
when TASK_TRAFFIC_SOURCE like '%Partner%' or TASK_TRAFFIC_SOURCE like '%Reseller%' or TASK_TRAFFIC_SOURCE like '%Channel%' then 'Partner'
Else 'Unbucketed'
END;

UPDATE rpt_main_02.rpt_MQLEnrichment A
LEFT JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.taskWhoDomain = B.domain AND DATE_FORMAT(A.taskCreatedDate, '%Y-%m-01 00:00:00') = B.startMonth
SET A.taskWhoDomainNewLogo = CASE WHEN A.taskWhoDomainISP=1 THEN 0
WHEN B.domain IS NULL THEN 1 ELSE 0 END;

update rpt_main_02.rpt_MQLEnrichment A
join (select taskWhoID, count(*) as taskWhoCount from rpt_main_02.rpt_MQLEnrichmentCopy
where taskWhoID!=''
group by 1) B
on A.taskWhoID=B.taskWhoID
set A.taskWhoCount=B.taskWhoCount
where A.taskWhoID!='';

update rpt_main_02.rpt_MQLEnrichment
set taskWhoIdProrated=1/taskWhoCount;

update rpt_main_02.rpt_MQLEnrichment
set opportunitySecurityPack='false'
where OPPORTUNITY_ID!='' and opportunitySecurityPack is null;

update rpt_main_02.rpt_MQLEnrichment
set opportunityIntegrationPack='false'
where OPPORTUNITY_ID!='' and opportunityIntegrationPack is null;

update rpt_main_02.rpt_MQLEnrichment
set opportunitySights='false'
where OPPORTUNITY_ID!='' and opportunitySights is null;

update rpt_main_02.rpt_MQLEnrichment
set opportunitySalesforce='false'
where OPPORTUNITY_ID!='' and opportunitySalesforce is null;

update rpt_main_02.rpt_MQLEnrichment
set opportunitySCC='false'
where OPPORTUNITY_ID!='' and opportunitySCC is null;

update rpt_main_02.rpt_MQLEnrichment
set opportunityJira='false'
where OPPORTUNITY_ID!='' and opportunityJira is null;

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_ID2=OPPORTUNITY_ID, OPPORTUNITY_STAGE2=OPPORTUNITY_STAGE, OPPORTUNITY_ARR2=OPPORTUNITY_ARR, opportunityDateDiff2=opportunityDateDiff, 
opportunityCycleTime2=opportunityCycleTime
where DIRECT_MAPPING=1 or contactMapping=1;

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_ID3=OPPORTUNITY_ID, OPPORTUNITY_STAGE3=OPPORTUNITY_STAGE, OPPORTUNITY_ARR3=OPPORTUNITY_ARR, opportunityDateDiff3=opportunityDateDiff, 
opportunityCycleTime3=opportunityCycleTime
where DIRECT_MAPPING=1;

drop table if exists rpt_main_02.rpt_MQLEnrichmentCopy;
create table if not exists rpt_main_02.rpt_MQLEnrichmentCopy like rpt_main_02.rpt_MQLEnrichment;
insert into rpt_main_02.rpt_MQLEnrichmentCopy select * from rpt_main_02.rpt_MQLEnrichment;

alter table rpt_main_02.rpt_MQLEnrichmentCopy
add ,
add ;

update rpt_main_02.rpt_MQLEnrichment A
join (select OPPORTUNITY_ID2, count(*) as oppCount from rpt_main_02.rpt_MQLEnrichmentCopy
where OPPORTUNITY_ID2 is not null
group by 1) B
on A.OPPORTUNITY_ID2=B.OPPORTUNITY_ID2
set A.opportunityCount2=B.oppCount
where A.OPPORTUNITY_ID2 is not null;

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_ARRCalc2=OPPORTUNITY_ARR2/opportunityCount2;

update rpt_main_02.rpt_MQLEnrichment A
join (select OPPORTUNITY_ID3, count(*) as oppCount from rpt_main_02.rpt_MQLEnrichmentCopy
where OPPORTUNITY_ID3 is not null
group by 1) B
on A.OPPORTUNITY_ID3=B.OPPORTUNITY_ID3
set A.opportunityCount3=B.oppCount
where A.OPPORTUNITY_ID3 is not null;

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_ARRCalc3=OPPORTUNITY_ARR3/opportunityCount3;

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_IDProrated=1/opportunityCount, OPPORTUNITY_IDProrated2=1/opportunityCount2, OPPORTUNITY_IDProrated3=1/opportunityCount3;

update rpt_main_02.rpt_MQLEnrichment
set taskWhoName=replace(taskWhoName,'"','');

update rpt_main_02.rpt_MQLEnrichment
set TASK_SUBJECT=replace(TASK_SUBJECT,'"','');

update rpt_main_02.rpt_MQLEnrichment
set taskWhoTitle=replace(taskWhoTitle,'"','');

update rpt_main_02.rpt_MQLEnrichment
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'"','');

alter table rpt_main_02.rpt_MQLEnrichment
add taskWhoUserIDFirstIPCity varchar(50),
add taskWhoUserIDFirstIPRegion varchar(50),
add taskWhoUserIDFirstIPCountry varchar(50);

update rpt_main_02.rpt_MQLEnrichment A
join rpt_main_02.rpt_userIPLocation B
on A.taskWhoUserID=B.userID
set A.taskWhoUserIDFirstIPCity=B.ipCity, A.taskWhoUserIDFirstIPRegion=B.ipRegion, A.taskWhoUserIDFirstIPCountry=B.ipCountry;

select * from rpt_main_02.rpt_MQLEnrichment
where TASK_SOURCE!='Test';

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("MQLReportV2.sql");

