SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2015-08-15TestDriveOwnSheet_V2.csv");

SELECT 	ss1.siteSettingElementName,
	ss1.userID, 
	ss1.valueNumeric,
	DATE_FORMAT(ss1.insertDateTime, "%Y-%m-%d") AS insertDate,
	userAccount.emailAddress AS 'EmailAddress', 
	ip.ipCountry AS Country,
	CASE WHEN userAccount.countryFriendly = "United States" THEN "1" ELSE "0" END AS "isUS",
	userAccount.languageFriendly AS "Language",
	CASE WHEN userAccount.languageFriendly  = "English" THEN "1" ELSE "0" END AS "isEnglish",
	MAX(rpt_trials.trialDateTime) AS LatestTrial,
	CASE WHEN MAX(rpt_trials.trialDateTime) IS NULL THEN 0 ELSE 1 END AS HadTrial,
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1 ELSE 0
	END AS 'LoggedIn1x',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'LoggedIn4x',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'StrongLead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1 ELSE 0 END AS 'LifetimeLogCount400',
	
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'	ELSE '0' END AS 'LicenseAccepted',
	
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'	ELSE '0' END AS 'PasswordSet',
	
	fcflrbu.paymentFormViewCount AS 'PaymentFormViewCount',
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1 ELSE 0 END AS 'ViewedPaymentFormAtLeastOnce',
			
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0 ELSE rpt_paymentProfile.countAsPaid
	END AS 'CountasPaid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL ELSE 	
		CASE rpt_paymentProfile.countAsPaid = 0 WHEN 1 THEN NULL ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm END
	END AS 'MonthlyRevenue',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0 ELSE 
		CASE rpt_paymentProfile.paymentTerm WHEN 12 THEN 1 ELSE 0 END	
	END AS 'IsAnnual',
			
	rpt_paymentProfile2.paymentTermFriendly AS 'PaymentTerm',
	rpt_paymentProfile2.productName AS 'ProductName',
			
	CASE WHEN rpt_paymentProfile2.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
	rpt_paymentProfile2.hasPaid,
	rpt_paymentProfile.daysToBuy,
	rpt_loginCountTotal.firstSessionLogID,
	rpt_browserSessionsByUser.mobileCount,
	CASE WHEN rpt_browserSessionsByUser.mobileCount > 0 THEN 1 ELSE 0 END AS usedMobile,
	
			CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly'

FROM rpt_main_02.userAccount 
LEFT OUTER JOIN rpt_main_02.rpt_trials ON userAccount.userID = rpt_trials.userID
-- LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss1 ON userAccount.userID = ss1.userID AND ss1.siteSettingElementName = 'SS_ABTEST_TIPS_AND_TOUR_COLLABORATOR'
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ss1 ON userAccount.userID = ss1.userID AND ss1.siteSettingElementName = 'SS_ABTEST_TESTDRIVE_OWN_SHEET'
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType != 2
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.sourceUserID AND rpt_paymentProfile2.accountType != 3
LEFT OUTER JOIN rpt_main_02.rpt_browserSessionsByUser ON userAccount.userID = rpt_browserSessionsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip on ip.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource on userAccount.userID = rpt_signupSource.userID


WHERE ss1.siteSettingElementName = 'SS_ABTEST_TESTDRIVE_OWN_SHEET' AND siteSettingElementValueID > 48192097

GROUP BY 1,2,3
ORDER BY 1
LIMIT 123456789
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2015-08-15TestDriveOwnSheet_V2.csv");