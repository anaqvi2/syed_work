/* Script was use to remove duplicates and create primary key for rpt_main_02.arc_clientEventRollup*/
 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("GmailAddOnUsage.sql");

select accessToken.userID, 
accessToken.insertdatetime as AccessTokenInsertDateTime, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID) as accessTokenProductName,
accessTokenSession.restSessionLogID, 
accessTokenSession.insertDateTime,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp2.productID) as accessTokenSessionProductName,
ua.domain, 
case when ua.domain in ('mbfcorp.com','smartsheet.com') then 1 else 0 end as SmartsheetEmployee,
case when d.domain is null then 1 else 0 end as isOrgDomain
from ss_core_02.accessToken 
left outer join ss_core_02.accessTokenSession on accessToken.accessTokenID = accessTokenSession.accessTokenID 
join rpt_main_02.userAccount ua on ua.useriD = accessToken.userID
left outer join rpt_main_02.arc_ISPDomains d on d.domain = ua.domain
left outer join rpt_main_02.hist_paymentProfile hpp on hpp.ownerID = accessToken.userID and hpp.accountType != 3 and accessToken.insertDateTime between hpp.modifyDatetime and hpp.hist_effectiveThrudateTime
left outer join rpt_main_02.hist_paymentProfile hpp2 on hpp2.ownerID = accessToken.userID and hpp2.accountType != 3 and accessTokenSession.insertDateTime between hpp2.modifyDatetime and hpp2.hist_effectiveThrudateTime 
where apiClientID = 2001751;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("GmailAddOnUsage.sql");
