SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2016-04-13PricingMatrixMedallionFunnelV2.sql");

create temporary table rpt_workspace.pj_medallionUsers like rpt_workspace.pj_abtest_paymentActions;

insert into rpt_workspace.pj_medallionUsers
select * from rpt_workspace.pj_abtest_paymentActions;

insert into rpt_workspace.pj_medallionUsers(insertbyuserID)
(select distinct userID from rpt_main_02.siteSettingElementValue where siteSettingElementName = "SS_ABTEST_PRICING_MATRIX_BEST_VALUE_MEDALLION_2" and siteSettingElementValueID > 47012145);

select
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
siteSettingElementValue.insertDateTime,
rpt_trials.trialDateTime,
hist_paymentProfile.productID,
rpt_userIPLocation.ipCountry,
u.languageFriendly,
CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket
	END AS 'Bucket',	
CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',
CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END AS 'Signup SubSource Friendly',
rpt_signupSource.campaign,	
CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
CASE rpt_paymentProfile.hasPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.hasPaid
	END AS 'has Paid',
rpt_paymentProfile.paymentTypeFriendly,
CASE 
	WHEN pwa.objectID is null THEN 'In Test'
    WHEN pwa.objectID = 2151 THEN 'ViewedStep1'
	WHEN pwa.objectID = 2152 THEN 'ViewedStep2'
	WHEN pwa.objectID = 2153 THEN 'ViewedStep3'
	WHEN pwa.objectID = 2161 AND pwa.actionID = 52 THEN 'PayPal Start'
	WHEN pwa.objectID = 2161 AND pwa.actionID = 53 THEN 'PayPal Complete'
	WHEN pwa.objectID = 2155 THEN 'ViewedConfirmPage' END AS PaymentFunnel

FROM rpt_main_02.siteSettingElementValue
JOIN rpt_main_02.userAccount u ON rpt_main_02.siteSettingElementValue.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_main_02.rpt_trials.userID = rpt_main_02.siteSettingElementValue.userID and rpt_main_02.rpt_trials.trialDateTime > "2016-04-12 00:00:00" and trialType = '1' and firstTrial = '1'
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON rpt_paymentProfile.sourceUserID = rpt_main_02.siteSettingElementValue.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_main_02.siteSettingElementValue.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_main_02.siteSettingElementValue.userID=rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_workspace.pj_abtest_paymentActions pwa ON u.userID=pwa.insertbyuserID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3'
	and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
WHERE siteSettingElementName = "SS_ABTEST_PRICING_MATRIX_BEST_VALUE_MEDALLION_2"
AND siteSettingElementValueID > 47012145
group by 1,2,3, 16
limit 12312313123;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2016-04-13PricingMatrixMedallionFunnelV2.sql");