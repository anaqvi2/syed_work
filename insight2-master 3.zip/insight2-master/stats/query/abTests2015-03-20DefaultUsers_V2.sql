SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2015-03-20DefaultUsers_V2.sql");

DROP TABLE rpt_workspace.frank_TeamDefault;
CREATE TABLE rpt_workspace.frank_TeamDefault
SELECT siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
CASE WHEN siteSettingElementValue.valueNumeric = 4 THEN "Default5Users" ELSE "Default3Users" END AS ABGroup,
siteSettingElementValue.insertDateTime,
rpt_trials.trialDateTime, 
rpt_main_02.SMARTSHEET_WEEK(rpt_trials.trialDateTime) AS trialWeek,
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
COUNT(DISTINCT arc_clientEvent.clientEventID) AS first5MinClientEvents,
	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'SignupBucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'SignupSourceFriendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'SignupSubSourceFriendly',

rpt_clientLogCountsByUserArchived.firstDayLogCount,
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
rpt_featureCountFromLogsRollupByUser.importCount,
rpt_containerCountsByUser.importedSheetCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
	CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1 ELSE 0
	END AS 'UserLoggedInAtLeastTwice',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'UserLoggedInAtLeast4Times',
CASE WHEN userAccount.countryFriendly = "United States" THEN "US" ELSE "Other" END AS IsUS,
userAccount.countryFriendly,
rpt_paymentProfile.billToCountryFriendly,
rpt_userIPLocation.ipCountry,
	rpt_paymentProfile.productName AS 'ProductName',
	rpt_paymentProfile.hasPaid,
	rpt_paymentProfile.countasPaid,
	rpt_paymentProfile.planRate_USD/paymentTerm AS MRR,
	rpt_paymentProfile.daysToBuy,

	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise?",
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS "Cancelled?",
	rpt_paymentProfile.paymentStartDateClean,
	CASE WHEN countAsPaid = 1 THEN rpt_paymentProfile.userLimit ELSE NULL END AS userLimit

FROM rpt_main_02.siteSettingElementValue 
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = siteSettingElementValue.userID AND trialDateTime > DATE_ADD(siteSettingElementValue.insertDateTime,INTERVAL -30 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser ON siteSettingElementValue.userID = rpt_featureCountFromLogsRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.arc_clientEvent ON rpt_loginCountTotal.firstsessionLogID = arc_clientEvent.sessionLogID AND arc_clientEvent.eventDateTime < DATE_ADD(rpt_sessionLog.insertDateTime, INTERVAL 5 MINUTE)
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > "2015-03-20 22:00:00"
	
WHERE siteSettingElementName = "SS_ABTEST_PRICING_TEAM_DEFAULT_USERS" AND rpt_sessionLog.insertDateTime > "2015-03-20" AND siteSettingElementValueID > 48192097
GROUP BY 1,2,3,4
ORDER BY rpt_trials.trialDateTime
;

ALTER TABLE rpt_workspace.frank_TeamDefault ADD 7DAYStep1 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 7DAYStep2 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 7DAYStep3 INT;
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 7DAYConfirm INT;  
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 21DAYStep1 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 21DAYStep2 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 21DAYStep3 INT;
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 21DAYConfirm INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 30DAYStep1 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 30DAYStep2 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 30DAYStep3 INT;
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 30DAYConfirm INT;  
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 60DAYStep1 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 60DAYStep2 INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 60DAYStep3 INT;
ALTER TABLE rpt_workspace.frank_TeamDefault ADD 60DAYConfirm INT; 
ALTER TABLE rpt_workspace.frank_TeamDefault ADD firstWinProduct VARCHAR(25); 


UPDATE rpt_workspace.frank_TeamDefault 
SET 7DAYStep1 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2151 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +7 DAY)); 
UPDATE rpt_workspace.frank_TeamDefault 
SET 7DAYStep2 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2152 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +7 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 7DAYStep3 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2153 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +7 DAY)); 
UPDATE rpt_workspace.frank_TeamDefault 
SET 7DAYConfirm =(SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2155 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +7 DAY));   

UPDATE rpt_workspace.frank_TeamDefault 
SET 21DAYStep1 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2151 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +21 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 21DAYStep2 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2152 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +21 DAY));   
UPDATE rpt_workspace.frank_TeamDefault 
SET 21DAYStep3 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2153 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +21 DAY));   
UPDATE rpt_workspace.frank_TeamDefault 
SET 21DAYConfirm = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2155 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +21 DAY));   

UPDATE rpt_workspace.frank_TeamDefault 
SET 30DAYStep1 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2151 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +31 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 30DAYStep2 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2152 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +31 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 30DAYStep3 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2153 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +31 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 30DAYConfirm = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2155 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +31 DAY));   
 
UPDATE rpt_workspace.frank_TeamDefault 
SET 60DAYStep1 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2151 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +60 DAY));  
UPDATE rpt_workspace.frank_TeamDefault 
SET 60DAYStep2 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2152 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +60 DAY)); 
UPDATE rpt_workspace.frank_TeamDefault 
SET 60DAYStep3 = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2153 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +60 DAY)); 
UPDATE rpt_workspace.frank_TeamDefault 
SET 60DAYConfirm = (SELECT COUNT(*) FROM rpt_main_02.rpt_payment_waterfall_actions WHERE rpt_payment_waterfall_actions.insertByUserID = frank_TeamDefault.userID 
AND objectID=2155 AND logDate BETWEEN frank_TeamDefault.trialDateTime AND DATE_ADD(frank_TeamDefault.trialDateTime, INTERVAL +60 DAY));


UPDATE rpt_workspace.frank_TeamDefault A
SET firstWinProduct = (SELECT `rpt_main_02.SMARTSHEET_PRODUCTNAME`(fwp.productID) 
FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
WHERE fwp.sourceUserID = A.userID AND fwp.winDate >= A.sessionDateTime GROUP BY A.userID);

ALTER TABLE rpt_workspace.frank_TeamDefault
ADD firstWinDate DATETIME,
ADD firstWinUserLimit INT,
ADD isTeam3 TINYINT,
ADD isTeam4 TINYINT,
ADD isTeam5 TINYINT,
ADD isTeam3OrGreater TINYINT,
ADD isTeam4OrGreater TINYINT,
ADD isTeam5OrGreater TINYINT,
ADD isIndividualToTeamUpgrade TINYINT,
ADD isTeamtoTeamUpgrade TINYINT,
ADD diffUpgradeLicenses INT,
ADD firstWinMRR DECIMAL(10,2),
ADD daysToWin INT,
ADD isTeamToIndividualDowngrade TINYINT,
ADD isTeamToTeamDowngrade TINYINT,
ADD diffDowngradeLicenses INT,
ADD convertedToPlan TINYINT,
ADD first30DayWin TINYINT,
ADD retained TINYINT,
ADD basicWin TINYINT,
ADD advancedWin TINYINT,
ADD teamWin TINYINT,
ADD enterpriseWin TINYINT;

UPDATE rpt_workspace.frank_TeamDefault A
SET firstWinDate = (SELECT fwp.winDate
	FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
		WHERE fwp.sourceUserID = A.userID AND fwp.winDate >= A.sessionDateTime GROUP BY A.userID) WHERE A.firstWinProduct IS NOT NULL;

UPDATE rpt_workspace.frank_TeamDefault A
SET firstWinUserLimit = (SELECT fwp.userLimit
	FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
		WHERE fwp.sourceUserID = A.userID AND fwp.winDate = A.firstWinDate) WHERE A.firstWinDate IS NOT NULL;
		
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam3 = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit = 3 THEN 1 ELSE 0 END;
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam4 = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit = 4 THEN 1 ELSE 0 END;
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam5 = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit = 5 THEN 1 ELSE 0 END;
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam3OrGreater = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit >= 3 THEN 1 ELSE 0 END;
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam4OrGreater = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit >= 4 THEN 1 ELSE 0 END;
UPDATE rpt_workspace.frank_TeamDefault A
SET isTeam5OrGreater = CASE WHEN A.firstWinProduct = 'Team' AND A.firstWinUserLimit >= 5 THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET isIndividualToTeamUpgrade = CASE WHEN firstWinProduct IN('Basic', 'Advanced') AND productName IN('Team', 'Enterprise_Legacy', 'Enterprise') THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET isTeamToTeamUpgrade = CASE WHEN firstWinProduct IN('Team', 'Enterprise', 'Enterprise_Legacy') AND productName IN('Team', 'Enterprise_Legacy', 'Enterprise') AND firstWinUserLimit < userLimit THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET diffUpgradeLicenses = userLimit - firstWinUserLimit WHERE isIndividualToTeamUpgrade = 1 OR isTeamToTeamUpgrade = 1;


UPDATE rpt_workspace.frank_TeamDefault A
SET firstWinMRR = (SELECT (fwp.planRate_USD/fwp.paymentTerm)
	FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
		WHERE fwp.sourceUserID = A.userID AND fwp.winDate = A.firstWinDate) WHERE A.firstWinDate IS NOT NULL;
		
UPDATE rpt_workspace.frank_TeamDefault A
SET daysToWin = DATEDIFF(DATE_FORMAT(firstWinDate, '%Y-%m-%d'), DATE_FORMAT(trialDateTime, '%Y-%m-%d'));

UPDATE rpt_workspace.frank_TeamDefault A
SET isTeamToIndividualDowngrade = CASE WHEN firstWinProduct IN('Team', 'Enterprise_Legacy', 'Enterprise') 
	AND productName IN('Basic', 'Advanced') THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET isTeamToTeamDowngrade = CASE WHEN firstWinProduct IN('Team', 'Enterprise_Legacy', 'Enterprise') AND productName IN('Team', 'Enterprise_Legacy', 'Enterprise') 
	AND firstWinUserLimit > userLimit THEN 1 ELSE 0 END;
	
UPDATE rpt_workspace.frank_TeamDefault A
SET diffDowngradeLicenses = firstWinUserLimit - userLimit WHERE isTeamToIndividualDowngrade = 1 OR isTeamToTeamDowngrade = 1;

UPDATE rpt_workspace.frank_TeamDefault A
SET convertedToPlan = CASE WHEN firstWinDate IS NOT NULL THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET first30DayWin = CASE WHEN convertedToPlan = 1 AND daysToWin <= 30 THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET retained = CASE WHEN countAsPaid = 1 THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET basicWin = CASE WHEN firstWinProduct = 'Basic' THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET advancedWin = CASE WHEN firstWinProduct = 'Advanced' THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET teamWin = CASE WHEN firstWinProduct = 'Team' THEN 1 ELSE 0 END;

UPDATE rpt_workspace.frank_TeamDefault A
SET enterpriseWin = CASE WHEN firstWinProduct in('Enterprise_Legacy', 'Enterprise') THEN 1 ELSE 0 END;

ALTER TABLE rpt_workspace.frank_TeamDefault
ADD firstWinPaymentTerm VARCHAR(25),
ADD currentPaymentTerm VARCHAR(25);

UPDATE rpt_workspace.frank_TeamDefault A
SET firstWinPaymentTerm = (SELECT `SMARTSHEET_PAYMENTTERM`(fwp.paymentTerm)
FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID AND fwp.winDate = A.firstWinDate) WHERE A.firstWinDate IS NOT NULL;
	
UPDATE rpt_workspace.frank_TeamDefault A
SET currentPaymentTerm = (SELECT pp.paymentTermFriendly FROM rpt_main_02.rpt_paymentProfile pp 
	WHERE pp.sourceUserID = A.userID AND pp.accountType != 2 GROUP BY A.userID) WHERE A.countAsPaid = 1;


SELECT * FROM rpt_workspace.frank_TeamDefault;



/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2015-03-20DefaultUsers_V2.sql");




