SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging TEST*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2015-03-27CADAUDPricing_V2.sql");

SELECT siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
COUNT(DISTINCT arc_clientEvent.clientEventID) AS first5MinClientEvents,
	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

rpt_clientLogCountsByUserArchived.firstDayLogCount,
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
rpt_featureCountFromLogsRollupByUser.importCount,
rpt_containerCountsByUser.importedSheetCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
	CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Twice',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
CASE WHEN userAccount.countryFriendly = "United States" THEN "US" ELSE "Other" END AS IsUS,
userAccount.countryFriendly,
rpt_paymentProfile.billToCountryFriendly,
rpt_userIPLocation.ipCountry,
	rpt_paymentProfile.hasPaid,
	rpt_paymentProfile.countasPaid,
	rpt_paymentProfile.daysToBuy,

	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise?",
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS "Cancelled?",
	rpt_paymentProfile.paymentStartDateClean,
	CASE WHEN countAsPaid = 1 THEN rpt_paymentProfile.userLimit ELSE NULL END AS userLimit,
	CASE WHEN TeamDefault.valueNumeric = 4 THEN "Team5Default" ELSE "Team3Default" END AS TeamDefault 
FROM rpt_main_02.siteSettingElementValue 
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser ON siteSettingElementValue.userID = rpt_featureCountFromLogsRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.arc_clientEvent ON rpt_loginCountTotal.firstsessionLogID = arc_clientEvent.sessionLogID AND arc_clientEvent.eventDateTime < DATE_ADD(rpt_sessionLog.insertDateTime, INTERVAL 5 MINUTE)
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > "2015-03-20 22:00:00"
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue TeamDefault ON TeamDefault.userID = siteSettingElementValue.userID AND TeamDefault.siteSettingElementName = "SS_ABTEST_PRICING_TEAM_DEFAULT_USERS"

	
WHERE siteSettingElementValue.siteSettingElementName = "SS_ABTEST_PRICING_AUDCAD_ENTERPRISE" AND rpt_sessionLog.insertDateTime > "2015-03-27" AND siteSettingElementValue.siteSettingElementValueID > 48609844
GROUP BY 1,2,3,4
;



/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2015-03-27CADAUDPricing_V2.sql");




