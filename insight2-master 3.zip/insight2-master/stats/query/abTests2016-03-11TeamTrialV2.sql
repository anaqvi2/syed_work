SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2016-03-11TeamTrialV2.sql");

drop table if exists rpt_workspace.pj_stg_waterfallActions;
create table rpt_workspace.pj_stg_waterfallActions
select * from rpt_main_02.rpt_payment_waterfall_actions
where logDate >= '2016-03-11';

create index uID on rpt_workspace.pj_stg_waterfallActions(insertbyuserID);
create index oID on rpt_workspace.pj_stg_waterfallActions(objectID);

drop table if exists rpt_workspace.pj_teamMemberConversion;
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
create table rpt_workspace.pj_teamMemberConversion
select siteSettingElementValue.siteSettingElementName as testName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric as testGroup,
siteSettingElementValue.insertDateTime,
t.trialType, 
t.trialDateTime,
t.paymentProfileID,
hist_paymentProfile.ownerID as memberUserID, 
rpt_paidPlanCurrentUsers.productName, 
rpt_paidPlanInfo.MRR
FROM rpt_main_02.siteSettingElementValue 
JOIN rpt_main_02.rpt_trials on rpt_trials.userID = siteSettingElementValue.userID and rpt_trials.trialDateTime > "2016-03-11 00:00:00" and rpt_trials.firstTrial = '1' and rpt_trials.trialType = '1'
LEFT OUTER JOIN rpt_main_02.rpt_trials t on t.userID = siteSettingElementValue.userID and t.trialType = '3' and t.firstTrial = '1' AND t.trialDateTime > "2016-03-11 00:00:00"
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on hist_paymentProfile.parentpaymentProfileID = t.paymentProfileID and hist_paymentProfile.productID = 1 and hist_paymentProfile.accountType = 2 and hist_paymentProfile.ownerID != t.userID
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanCurrentUsers on rpt_paidPlanCurrentUsers.mainContactUserID = hist_paymentProfile.ownerID 
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanInfo  on rpt_paidPlanInfo.mainContactUserID = hist_paymentProfile.ownerID 

WHERE siteSettingElementName =  "SS_ABTEST_TEAM_TRIAL" 
AND siteSettingElementValueID > 47012145
group by 1,2,3,4,7,8;

create index uID on rpt_workspace.pj_teamMemberConversion(userID);
create index muID on rpt_workspace.pj_teamMemberConversion(memberUserID);

CREATE TABLE IF NOT EXISTS rpt_workspace.pj_stg_medallionTest
(userID int(15),
valueNumeric int,
primary key (userID));

INSERT IGNORE INTO rpt_workspace.pj_stg_medallionTest
SELECT userID, valueNumeric
FROM rpt_main_02.siteSettingElementValue 
WHERE siteSettingElementValue.siteSettingElementName =  "SS_ABTEST_PRICING_MATRIX_BEST_VALUE_MEDALLION_2"
AND siteSettingElementValue.siteSettingElementValueID > 47012145;

drop table if exists rpt_workspace.pj_stg_teamTrialTest;
create table rpt_workspace.pj_stg_teamTrialTest
(siteSettingElementName varchar(100),
userID int(15),
valueNumeric int,
insertDate date,
trialDateTime datetime,
trialDate date,
teamTrialDateTime datetime,
firstSessionLogID bigint,
sessionDateTime datetime,
signoutDateTime datetime,
sessionTime decimal(10,2),
firstDayLogCount int,
`Is Strong Lead` int,
WellQualCount int,
`EverWellQual` int,
`User Logged In At Least 3 Times` int,
sharingCount int,
lifetimeSheetCount int, 
sheetCount int, 
ViewedPricingScreen int,
lifetimeLogCount int,
`Signup Bucket` varchar(100),
`Signup Source Friendly` varchar(100),
`Signup Sub Source Friendly`varchar(100),
campaign varchar(100),
ipCountry varchar(100),    
languageFriendly varchar(100),
MedallionABTestGroup int,
hasPaid int,
daysToBuy int,
paymentTerm varchar(15),
userLimit int,
`Basic?` int,
`Advanced?` int,
`Team?` int,
`Enterprise?` int,
`Cancelled?` int,
paymentStartDateClean datetime, 
paymentStartDate date,
CountAsPaidProduct int,
MRR decimal(10,2),
salesAssisted int,
usersInvited int,
usersOnTeamTrial int,
teamTrialMemebers int,
memberMRR decimal(10,2),
licensedMembers int,
shareCount int,
index (userID),
index (insertDate));

insert into rpt_workspace.pj_stg_teamTrialTest(
siteSettingElementName,
userID,
valueNumeric,
insertDate,
trialDateTime,
trialDate,
firstSessionLogID,
sessionDateTime,
signoutDateTime,
sessionTime,
firstDayLogCount,
`Is Strong Lead`,
WellQualCount,
`EverWellQual`,
`User Logged In At Least 3 Times`,
sharingCount,
lifetimeSheetCount, 
sheetCount, 
ViewedPricingScreen,
lifetimeLogCount,
`Signup Bucket`,
`Signup Source Friendly`,
`Signup Sub Source Friendly`,
campaign,
ipCountry,    
languageFriendly)

select 
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_main_02.rpt_trials.trialDateTime,
DATE_FORMAT(rpt_main_02.rpt_trials.trialDateTime, "%Y-%m-%d") AS trialDate,
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150  WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0 WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
CASE rpt_loginCountTotal.loginCount >= 4 WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 3 Times',
rpt_featureCountRollupByUser.sharingCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
CASE WHEN pwa.objectID is not null THEN 1 ELSE 0 END AS ViewedPricingScreen,
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
CASE rpt_signupSource.bucket IS NULL WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
CASE rpt_signupSource.sourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly END AS 'Signup Source Friendly',
CASE rpt_signupSource.subSourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,    
userAccount.languageFriendly

FROM rpt_main_02.siteSettingElementValue 
JOIN rpt_main_02.rpt_trials on rpt_main_02.rpt_trials.userID = siteSettingElementValue.userID and rpt_main_02.rpt_trials.trialDateTime > "2016-03-11 00:00:00" and firstTrial = '1' and trialType = '1'
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser ON siteSettingElementValue.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_workspace.pj_stg_waterfallActions pwa on siteSettingElementValue.userID=pwa.insertbyuserID and pwa.logDate > rpt_main_02.rpt_trials.trialDateTime
WHERE siteSettingElementName =  "SS_ABTEST_TEAM_TRIAL" 
AND siteSettingElementValueID > 47012145
GROUP BY 1,2,3,4
LIMIT 123456789
;

update rpt_workspace.pj_stg_teamTrialTest 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON pj_stg_teamTrialTest.userID = rpt_paymentProfile.sourceUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > pj_stg_teamTrialTest.trialDateTime and rpt_paymentProfile.productID > 2
LEFT OUTER JOIN ss_sfdc_02.opportunity opp on opp.parent_payment_profile_ID__c = rpt_paymentProfile.paymentProfileID AND parent_payment_profile_ID__c IS NOT NULL AND opp.product__c != 'Services' AND opp.StageName = 'Closed Won' 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON pj_stg_teamTrialTest.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > pj_stg_teamTrialTest.trialDateTime and rpt_paymentProfile2.productID > 2
set 
pj_stg_teamTrialTest.hasPaid = rpt_paymentProfile.hasPaid,
pj_stg_teamTrialTest.daysToBuy = rpt_paymentProfile.daysToBuy,
pj_stg_teamTrialTest.paymentTerm = CASE WHEN rpt_paymentProfile.paymentTermFriendly IN ('Monthly','Annual','Semi-Annual') THEN rpt_paymentProfile.paymentTermFriendly else NULL END,
pj_stg_teamTrialTest.userLimit = CASE WHEN rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.productID != 9 THEN rpt_paymentProfile.userLimit ELSE 0 end,
`Basic?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END,
`Advanced?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
 CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END ,
`Team?` =  CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END,
`Enterprise?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END,
`Cancelled?` = CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END,
pj_stg_teamTrialTest.paymentStartDateClean = rpt_paymentProfile.paymentStartDateClean,
pj_stg_teamTrialTest.paymentStartDate = Date_format(rpt_paymentProfile.paymentStartDateClean, "%Y-%m-%d"),
pj_stg_teamTrialTest.CountAsPaidProduct = CASE WHEN rpt_paymentProfile2.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END,
pj_stg_teamTrialTest.MRR = CASE WHEN rpt_paymentProfile.planRate_USD > 0 then (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm) else 0 end,
pj_stg_teamTrialTest.salesAssisted = CASE WHEN opp.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END;

update rpt_workspace.pj_stg_teamTrialTest 
set teamTrialDateTime = 
(select pj_teamMemberConversion.trialDateTime
from rpt_workspace.pj_teamMemberConversion 
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID
and trialDateTime is not null
limit 1);

update rpt_workspace.pj_stg_teamTrialTest 
set usersInvited = 
(select count(distinct stg_teamTrialMembers.userID)
from rpt_workspace.pj_teamMemberConversion
	join rpt_main_02.stg_teamTrialMembers on stg_teamTrialMembers.orgPaymentProfileID = pj_teamMemberConversion.paymentProfileID
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID);

update rpt_workspace.pj_stg_teamTrialTest 
set usersOnTeamTrial = 
(select count(distinct stg_teamTrialMembers.userID)
from rpt_workspace.pj_teamMemberConversion
	join rpt_main_02.stg_teamTrialMembers on stg_teamTrialMembers.orgPaymentProfileID = pj_teamMemberConversion.paymentProfileID 
		and stg_teamTrialMembers.state = 1
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID);

update rpt_workspace.pj_stg_teamTrialTest 
set teamTrialMemebers = 
(select count(distinct pj_teamMemberConversion.memberUserID)
from rpt_workspace.pj_teamMemberConversion 
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID);

update rpt_workspace.pj_stg_teamTrialTest 
set licensedMembers = 
(select count(distinct(CASE WHEN pj_teamMemberConversion.productName is not null then pj_teamMemberConversion.memberUserID end))
from rpt_workspace.pj_teamMemberConversion 
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID);

update rpt_workspace.pj_stg_teamTrialTest 
set memberMRR = 
(select sum(case when pj_teamMemberConversion.MRR > 0 then pj_teamMemberConversion.MRR else 0 end)
from rpt_workspace.pj_teamMemberConversion 
where pj_stg_teamTrialTest.userID = pj_teamMemberConversion.userID);

update rpt_workspace.pj_stg_teamTrialTest 
set shareCount = 
(select count(distinct gam.userID)
from rpt_main_02.gridAccessMap gam
where gam.insertbyuserID = pj_stg_teamTrialTest.userID 
and gam.access < 50 
and gam.insertdatetime >= pj_stg_teamTrialTest.insertDate);

select * from rpt_workspace.pj_stg_teamTrialTest limit 1233453456;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2016-03-11TeamTrialV2.sql");