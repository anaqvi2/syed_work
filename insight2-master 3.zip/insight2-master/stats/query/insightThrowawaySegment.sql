select "******************************************************************************************************************************", NOW();
select "******** InsightThrowawaySegment - start ******** ", NOW();
/* Use this script to run portions of insight throwaway */
 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveBrowser0=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnWebBrowser=0)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveNativeApp0=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnNativeApp=0)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveEither0=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnEither=0)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveBrowser1=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnWebBrowser > 0 AND B.daysActiveOnWebBrowser < 15)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveNativeApp1=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnNativeApp > 0 AND B.daysActiveOnNativeApp < 15)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveEither1=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnEither > 0 AND B.daysActiveOnEither < 15)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveBrowser15=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnWebBrowser >= 15)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveNativeApp15=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnNativeApp >= 15)
WHERE A.monthYear='July 2017';

UPDATE rpt_workspace.js_toothbrushCustomerBreakout A
SET daysActiveEither15=
(SELECT COUNT(*) FROM rpt_workspace.js_toothbrushTotals B FORCE INDEX (customer)
WHERE A.customer=B.customer AND B.monthYear='July 2017' AND B.daysActiveOnEither >= 15)
WHERE A.monthYear='July 2017';

/*Start Logging*/


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** End of InsightThrowawaySegment ******** ", NOW();
set session transaction isolation level repeatable read;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("InsightThrowawaySegment");