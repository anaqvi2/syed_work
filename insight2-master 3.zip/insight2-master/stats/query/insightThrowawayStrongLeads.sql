select "******************************************************************************************************************************", NOW();
select "******** InsightThrowawayStrongLeads - start ******** ", NOW();
/* Use this script to process ss_log_02.clientEvent and update Strong Leads */
 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("InsightThrowawayStrongLeads");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_clientEvent");

SELECT 5 INTO @logLevel;  # DEBUG:5, INFO:4, WARN:3, ERROR:2, FATAL:1, OFF:0:  Determines the granularity of logging this process in the database.
SELECT 0 INTO @processId;  # 0 is the default processId, this will be overwritten with each utl_logStart call.

CALL rpt_main_02.etl_clientEvent_batches(@processId,@logLevel);

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_clientEvent");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_clientEvent_clean - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientEvent_clean delete");

TRUNCATE TABLE rpt_main_02.rpt_clientEvent_clean;

SELECT DATE_ADD(MAX(logDate), INTERVAL 1 DAY) INTO @startDate FROM rpt_main_02.arc_clientEventRollup;

-- DELETE FROM rpt_main_02.arc_clientEventRollup WHERE logDate >= @startDate;  

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean delete");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientEvent_clean insert");

SET AUTOCOMMIT = 0;

INSERT rpt_main_02.rpt_clientEvent_clean 
SELECT ce.*, sl.userID
FROM rpt_main_02.arc_clientEvent ce
LEFT JOIN rpt_main_02.arc_sessionLog sl ON ce.sessionLogID=sl.sessionLogID 
WHERE eventDateTime >= @startDate
;

COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean insert");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.rpt_clientEvent_clean update");


SELECT 1 	INTO @LOG_ID_OPEN; 
SELECT 20 	INTO @LOG_ID_MOUSE_DOWN;
SELECT 22	INTO @LOG_ID_CLICK;
SELECT 31 	INTO @LOG_ID_SHORTCUT_KEY;
SELECT 60 	INTO @LOG_ID_LAUNCH_UPGRADE;
SELECT 61 	INTO @LOG_ID_COMPLETE_UPGRADE;
SELECT 62 	INTO @LOG_ID_CANCEL_UPGRADE;
SELECT 99 	INTO @LOG_ID_DIAGNOSTIC;

SELECT 101 	INTO @LOG_ID_DESKTOP;
SELECT 200 	INTO @LOG_ID_MY_ACCOUNT_LINK;

SELECT 500 	INTO @LOG_ID_HOMEPAGE_TREE_NODE;

SELECT 564 	INTO @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE;

SELECT 1801 	INTO @LOG_ID_HELPOVERLAY_PAGE_CONTROL;
SELECT 1805 	INTO @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK;
SELECT 1806 	INTO @LOG_ID_HELPOVERLAY_VIDEO_LINK;
SELECT 2001 	INTO @LOG_ID_STANDARD_BUTTON_GENERIC;
SELECT 5001 	INTO @LOG_ID_TOOLBAR_BUTTON_SAVE;
SELECT 12001 	INTO @LOG_ID_GETTINGSTARTED_ABCTEST;

SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_clientEvent_clean cec 
SET cec.parm1String = NULL ,  cec.parm1Int = NULL
WHERE NOT	/* we are NOT blanking out the list below... i.e. below is a list of the items where we are keeing the parameters */
	(
	(cec.objectID >= @LOG_ID_MY_ACCOUNT_LINK AND cec.actionID = @LOG_ID_OPEN) OR  /* want to keep everything higher than the desktop and tabs */
	(cec.objectID = @LOG_ID_STANDARD_BUTTON_GENERIC) OR 
	(cec.actionID = @LOG_ID_LAUNCH_UPGRADE OR cec.actionID = @LOG_ID_COMPLETE_UPGRADE OR cec.actionID = @LOG_ID_CANCEL_UPGRADE) OR 
	(cec.objectID = @LOG_ID_HELPOVERLAY_PAGE_CONTROL OR cec.objectID = @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK OR cec.objectID = @LOG_ID_HELPOVERLAY_VIDEO_LINK) OR 
	(cec.actionID = @LOG_ID_SHORTCUT_KEY) OR 
	(cec.objectID = @LOG_ID_GETTINGSTARTED_ABCTEST) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TREE_NODE) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_CATEGORY) OR 
	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_SEARCH) OR 
	(cec.objectID = @LOG_ID_DESKTOP AND cec.actionID = @LOG_ID_DIAGNOSTIC) OR 
	(cec.objectID >= @LOG_ID_TOOLBAR_BUTTON_SAVE AND cec.actionID = @LOG_ID_MOUSE_DOWN) OR
	(cec.objectID = @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE AND @LOG_ID_CLICK)
	)
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean update");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_clientEventRollup - start ******** ", NOW();
	
/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_clientEventRollup");

SELECT MAX(DATE(eventDateTime)) INTO @maxEventDate FROM rpt_main_02.rpt_clientEvent_clean;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_clientEventRollup(insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
SELECT userID, 
	DATE(eventDateTime),
	objectID,
	actionID,
	parm1String,
	parm1Int,
	COUNT(*)
FROM rpt_main_02.rpt_clientEvent_clean cec
where date(cec.eventDateTime) < @maxEventDate
GROUP BY 1,2,3,4,5,6
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_clientEventRollup");


CALL rpt_main_02.SEGMENTED_START_LOG ("stg_clientLogCountsByUserArchived insert");

CREATE TABLE IF NOT EXISTS rpt_workspace.stg_clientLogCountsByUserArchived
(userID int(15),
trialDateTime datetime,
insertdatetime datetime,
firstDayTrialLogCount int,
firstDayLogCount int,
primary key (userID));

INSERT IGNORE INTO rpt_workspace.stg_clientLogCountsByUserArchived(userID, trialDateTime, insertDateTime)
SELECT t.userID, t.trialDateTime, ua.insertDateTime
FROM rpt_main_02.rpt_trials t
	JOIN userAccount ua on ua.userID = t.userID
WHERE firstTrial = 1 AND trialType = 1
AND trialDateTime > '2017-04-20 00:00:00';

INSERT IGNORE INTO rpt_workspace.stg_clientLogCountsByUserArchived(userID, insertDateTime)
SELECT userID, insertDateTime
FROM rpt_main_02.userAccount
WHERE insertDateTime > '2017-04-20 00:00:00';

SELECT MAX(trialDateTime) INTO @maxTrialDateTime 
FROM rpt_workspace.stg_clientLogCountsByUserArchived
WHERE firstDayTrialLogCount is not null;

SELECT MAX(insertdatetime) INTO @maxinsertdatetime
FROM rpt_workspace.stg_clientLogCountsByUserArchived
WHERE firstDayLogCount is not null;

SELECT MAX(logDate) INTO @maxRollupDate
FROM rpt_main_02.arc_clientEventRollup;

SET @maxTrialDateTime  = CASE WHEN @maxTrialDateTime is null then '2017-04-20 00:00:00' else @maxTrialDateTime end;
SET @maxinsertdatetime  = CASE WHEN @maxinsertdatetime is null then '2017-04-20 00:00:00' else @maxinsertdatetime end;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("stg_clientLogCountsByUserArchived insert");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("stg_clientLogCountsByUserArchived firstDayTrialLogCount");

UPDATE rpt_workspace.stg_clientLogCountsByUserArchived clcua
SET clcua.firstDayTrialLogCount =
(SELECT SUM(r.logCount) 
FROM rpt_main_02.arc_clientEventRollup r
WHERE r.insertByUserID = clcua.userID 
AND r.logDate <= DATE_ADD(clcua.trialDateTime, INTERVAL 12 HOUR)
)
WHERE clcua.trialDateTime is not null
AND clcua.trialDateTime >= DATE_SUB(@maxTrialDateTime, interval 1 DAY) 
and  DATE_ADD(clcua.trialDateTime, INTERVAL 12 HOUR) <= @maxRollupDate
;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("stg_clientLogCountsByUserArchived firstDayTrialLogCount");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("stg_clientLogCountsByUserArchived firstDayLogCount");

UPDATE rpt_workspace.stg_clientLogCountsByUserArchived clcua
SET clcua.firstDayLogCount =
(SELECT SUM(r.logCount) 
FROM rpt_main_02.arc_clientEventRollup r
WHERE r.insertByUserID = clcua.userID AND r.logDate <= DATE_ADD(clcua.insertDateTime, INTERVAL 12 HOUR))
WHERE clcua.insertDateTime  >= DATE_SUB(@maxinsertdatetime, interval 1 day)
AND DATE_ADD(clcua.insertDateTime, INTERVAL 12 HOUR) <= @maxRollupDate
;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("stg_clientLogCountsByUserArchived firstDayLogCount");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("update rpt_main_02.rpt_clientLogCountsByUserArchived firstDayTrialLogCount");

UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived cl 
	join rpt_workspace.stg_clientLogCountsByUserArchived stg on stg.userID = cl.userID and stg.trialDateTime >'2017-04-20 00:00:00' and stg.firstDayTrialLogCount is not null
set cl.firstDayTrialLogCount = stg.firstDayTrialLogCount;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("update rpt_main_02.rpt_clientLogCountsByUserArchived firstDayTrialLogCount");


/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("update rpt_main_02.rpt_clientLogCountsByUserArchived firstDayLogCount");

UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived cl
	join rpt_workspace.stg_clientLogCountsByUserArchived stg on stg.userID = cl.userID and stg.insertDateTime >'2017-04-20 00:00:00' and stg.firstDayLogCount is not null
set cl.firstDayLogCount = stg.firstDayLogCount;


/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("update rpt_main_02.rpt_clientLogCountsByUserArchived firstDayLogCount");


/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("InsightThrowawayStrongLeads");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** End of InsightThrowawayStrongLeads ******** ", NOW();
set session transaction isolation level repeatable read;
