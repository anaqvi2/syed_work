SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ErrorCheckV2.csv");

SELECT "******** Future Payment Start Dates ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE (paymentStartDateTime > NOW() AND hist_effectiveThruDateTime = "9999-12-31 08:00:00") 
or (paymentStartDateTime < "2008-01-01" AND hist_effectiveThruDateTime = "9999-12-31 08:00:00");

SELECT "******** Bill To Monthly Rate ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE paymentTerm = 1 AND paymentType = 2
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -7 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** Excessive Monthly Rate ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE (planRate_USD/paymentTerm)/userLimit > 40
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -7 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** Paid Multi-User Profiles ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE accountType = 2 AND planRate > 0 
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -7 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** No Payment Term ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE accountType != 2 AND (paymentTerm = 0 OR paymentTerm IS NULL) AND planRate > 0 
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -14 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** No Payment Type ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE accountType != 2 AND (paymentType = 0 OR paymentType IS NULL) AND planRate > 0 
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -14 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** No Payment Value ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE accountType != 2 AND planRate = 0 AND productID > 2 AND paymentType IN (1,2,6,8)
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -14 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** Promo Accounts with Payment ******** ";
SELECT paymentProfileID, SMARTSHEET_ACCOUNTTYPE(accountType), 
rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType), paymentStartDateTime, CONCAT(SMARTSHEET_PRODUCTNAME(productID), " ", userLimit) AS ProductName,
(planRate_USD/paymentTerm) AS monthlyPayment
FROM rpt_main_02.hist_paymentProfile WHERE paymentType = 4 AND planRate_USD > 0
AND modifyDateTime > DATE_ADD(NOW(), INTERVAL -7 DAY) AND hist_effectiveThruDateTime = "9999-12-31 08:00:00";

SELECT "******** Changed Payment Start Date without Flip ******** ";
SELECT 
hppNew.modifyDateTime,
hppNew.paymentProfileID AS 'PaymentProfileID', 
hppNew.paymentStartDateTime AS 'NewPaymentStartDate',
hppOld.paymentStartDateTime AS 'OldPaymentStartDate',
DATEDIFF(hppNew.paymentStartDateTime,hppOld.paymentStartDateTime) AS daysChanged,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hppOld.productID) AS 'OldProductName',
rpt_main_02.SMARTSHEET_PRODUCTNAME(hppNew.productID) AS 'NewProductName',
(hppNew.planRate_USD/hppNew.paymentTerm - hppOld.planRate_USD/hppOld.paymentTerm) AS 'NetPaymentChange'

FROM rpt_main_02.hist_paymentProfile hppNew
JOIN rpt_main_02.hist_paymentProfile hppOld ON hppNew.paymentProfileID = hppOld.paymentProfileID 

WHERE hppNew.modifyDateTime >= '2009-01-01'
AND hppNew.planRate_USD > 0 AND hppOld.planRate_USD > 0 
AND (DATEDIFF(hppNew.paymentStartDateTime,hppOld.paymentStartDateTime) > 0 OR DATEDIFF(hppNew.paymentStartDateTime,hppOld.paymentStartDateTime) < 0)
AND (hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND or hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime)
AND hppNew.modifyDateTime > DATE_ADD(NOW(), INTERVAL -7 DAY)
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ErrorCheckV2.csv");


