SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2014-04-11 utm_expid.sql");

SELECT
	userAccount.emailAddress AS 'E-mail Address', 
	rpt_signupSourceUser.signupInsertDateTime AS 'SignupDateTime', 
	CASE rpt_signupSourceUser.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSourceUser.bucket
	END AS 'Signup Bucket',
	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment',

	CASE MAX(rpt_paymentProfile.countAsPaid) IS NULL
		WHEN 1 THEN 0
		ELSE MAX(rpt_paymentProfile.countAsPaid) END as countAsPaid,
	rpt_paymentProfile.productName AS 'Product Name',
	rpt_paymentProfile.hasPaid,
	CASE MAX(rpt_paymentProfile.countAsPaid) IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE MAX(rpt_paymentProfile.countAsPaid) = 0
				WHEN 1 THEN NULL
				ELSE MAX(rpt_paymentProfile.planRate_USD) / MAX(rpt_paymentProfile.paymentTerm)
			END
	END AS 'Monthly Revenue',
	
	/* quote to prevent odd characters causing problems in Excel and so Excel won't try to interpret keywords that start with + as a formula */
	QUOTE(rpt_signupSourceUser.keyword) AS 'Signup Keyword',

	rpt_signupSourceUser.adVersion AS 'Ad Version',

	rpt_signupSourceUser.landingPageVersion AS landingPageVersion,
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Lifetime Log Count >= 400',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
	
	/* showed moderate use of area								+ showed heavy use of area  */
	 (ROUND(COALESCE(LEAST(rpt_loginCountTotal.loginCount, .5), 0) 				+ COALESCE(LEAST(rpt_loginCountTotal.loginCount / 8, .5), 0) +
	 COALESCE(LEAST(rpt_clientLogCountsByUserArchived.lifetimeLogCount / 200, .5), 0) 	+ COALESCE(LEAST(rpt_clientLogCountsByUserArchived.lifetimeLogCount / 2000, .5), 0) + 
	 COALESCE(LEAST(rpt_containerCountsByUser.sheetCount , .5), 0) 				+ COALESCE(LEAST(rpt_containerCountsByUser.sheetCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_containerCountsByUser.reportCount, .5), 0) 				+ COALESCE(LEAST(rpt_containerCountsByUser.reportCount / 10, .5), 0) + 
	 COALESCE(LEAST(rpt_containerCountsByUser.workspaceCount, .5), 0) 			+ COALESCE(LEAST(rpt_containerCountsByUser.workspaceCount / 10, .5), 0) + 
	 COALESCE(LEAST(rpt_featureCountRollupByUser.sharingCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.sharingCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.reminderCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.reminderCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.attachmentCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.attachmentCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.discussionCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.discussionCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountFromLogsRollupByUser.paymentFormViewCount, .5), 0)  	+ COALESCE(LEAST(rpt_featureCountFromLogsRollupByUser.paymentFormViewCount / 4, .5), 0), 1)) 
	AS 'Usage Rating',
	
	rpt_userIPLocation.ipCountry AS "IP Country",
	rpt_userIPLocation.ipRegion AS "IP Region",
	rpt_userIPLocation.ipCity AS "IP City",
	
	userAccount.languageFriendly,
	
	SUBSTRING_INDEX(rpt_signupRequestTrackingItem.itemValue,".",1) AS "ExperimentNumber",
	SUBSTRING_INDEX(rpt_signupRequestTrackingItem.itemValue,".",-1) AS "VariationNumber",
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN ref_weightedStrongLeadFactor.weightedStrongLeadFactor
		ELSE 0
	END AS 'WSL',
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise?",
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS "Cancelled?"

FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.userAccount userAccount2		ON userAccount.insertByUserID = userAccount2.userID
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  		ON userAccount.userID = rpt_paymentProfile.sourceUserID 
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   	ON userAccount.userID = rpt_featureCountRollupByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser   	ON userAccount.userID = rpt_featureCountFromLogsRollupByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 			ON userAccount.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON userAccount.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_domainRollup 			ON rpt_featureCountRollupByUser.domain 	= rpt_domainRollup.domain
  LEFT OUTER JOIN rpt_main_02.rpt_userAncestor 			ON userAccount.emailAddress 	= rpt_userAncestor.userEmailAddress
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceAncestor	ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
  LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem  ON rpt_signupSourceUser.signupRequestID = rpt_signupRequestTrackingItem.signupRequestID AND itemName = "utm_expid" 
  LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = userAccount.userID
  LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON rpt_userIPLocation.ipCountry = ref_weightedStrongLeadFactor.IPCountry


WHERE userAccount.insertDateTime  >= '2014-04-11' AND rpt_signupRequestTrackingItem.itemValue IS NOT NULL

GROUP BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2014-04-11 utm_expid.sql");




