CREATE TABLE IF NOT EXISTS rpt_main_02.`arc_InsightTableSizes` 
(
  `table_schema` varchar(100) DEFAULT NULL,
  `table_name` varchar(200) DEFAULT NULL,
  `rows_M` decimal(42,10) DEFAULT NULL,
  `data_GB` decimal(42,10) DEFAULT NULL,
  `indexes_GB` decimal(42,10) DEFAULT NULL,
  `total_size_GB` decimal(42,10) DEFAULT NULL,
  `snapshotDate` datetime DEFAULT NULL
) -- ENGINE=TokuDB DEFAULT CHARSET=utf8
;

INSERT INTO rpt_main_02.arc_InsightTableSizes
SELECT 
table_schema,
CONCAT(table_schema, '.', table_name) AS table_name,
ROUND(table_rows / 1000000, 6) AS rows_M,
ROUND(data_length / ( 1024 * 1024 * 1024 ), 6) AS DATA_GB,
ROUND(index_length / ( 1024 * 1024 * 1024 ), 6) AS idx_GB,
ROUND(( data_length + index_length ) / ( 1024 * 1024 * 1024 ), 6) AS total_size_GB,
NOW() AS SnapshotDate
FROM   information_schema.TABLES
WHERE table_schema IN ('rpt_main_02','ss_core_02','ss_log_02','ss_sfdc_02','rpt_workspace')
ORDER  BY data_length + index_length DESC
;
