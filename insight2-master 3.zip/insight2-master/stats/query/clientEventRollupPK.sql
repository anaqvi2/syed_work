/* Script was use to remove duplicates and create primary key for rpt_main_02.arc_clientEventRollup*/
 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("clientEventRollupPK");

create table if not exists rpt_main_02.arc_clientEventRollup_NEW
(id INT NOT NULL AUTO_INCREMENT,
insertByUserID int(11),
logDate date,
objectID smallint(6),
actionID smallint(6),
parm1String varchar(100),
parm1Int int(11),
logCount int(11),
primary key (id),
unique key (insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int),
index (insertbyuserID),
index (logDate));

SELECT DATE_ADD(MAX(logDate), INTERVAL 1 DAY) FROM rpt_main_02.arc_clientEventRollup_NEW INTO @maxDate;
SELECT CASE WHEN @maxDate IS NULL THEN '2011-11-03' ELSE @maxDate END INTO @maxDate;

-- SET @@sql_log_bin = 0;

INSERT IGNORE INTO rpt_main_02.arc_clientEventRollup_NEW(insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
SELECT * 
FROM rpt_main_02.arc_clientEventRollup
WHERE logDate = @maxDate
;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("clientEventRollupPK");
