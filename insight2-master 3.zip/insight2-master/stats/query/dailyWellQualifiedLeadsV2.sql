SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("dailyWellQualifiedLeadsV2.csv");


/*Generating dailyWellQualifiedLeadsV2.csv*/
SELECT arc_DailyWellQualifiedLeads.userID,
	CASE WHEN arc_DailyWellQualifiedProsumer.SSOwner IS NULL THEN "Not Contacted" ELSE arc_DailyWellQualifiedProsumer.SSOwner END AS DailyReachoutContact,
	userAccount.emailAddress,
	userAccount.countryFriendly AS Country,
	userAccount.languageFriendly AS "Language",
	
	rpt_loginCountTotal.loginCount,
	rpt_loginCountTotal.daysActive,
	rpt_containerCountsByUser.sheetCount AS 'Sheet Count',
	rpt_containerCountsByUser.sheetwithCellLinkCount AS 'Sheets with Cell Links',
	rpt_containerCountsByUser.reportCount AS 'Report Count',
	rpt_containerCountsByUser.workspaceCount AS 'Workspace Count',
	rpt_featureCountRollupByUser.sharingCount AS 'Sharing Count',
	rpt_featureCountRollupByUser.reminderCount AS 'Reminder Count',
	rpt_featureCountRollupByUser.cellLinkCount AS 'Cell Link Count',
	CASE rpt_signupSourceUser.bucket IS NULL
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSourceUser.bucket
	END AS 'Signup Bucket',

	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment'

FROM rpt_main_02.arc_DailyWellQualifiedLeads
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedProsumer ON arc_DailyWellQualifiedProsumer.userID = arc_DailyWellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.userAccount AS userAccount ON userAccount.userID = arc_DailyWellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON arc_DailyWellQualifiedLeads.userID = rpt_paymentProfile.mainContactUserID AND rpt_paymentProfile.accountType != 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON userAccount.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser ON userAccount.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID

WHERE arc_DailyWellQualifiedLeads.snapshotDate = CURRENT_DATE()

GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("dailyWellQualifiedLeadsV2.csv");
