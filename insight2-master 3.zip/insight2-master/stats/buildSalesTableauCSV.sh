
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/query

# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
#LOG_FILE=${STATS_HOME}/logs/buildCSV_${LOG_DATE}.log
#exec > $LOG_FILE 2>&1

DB_SERVER=127.0.0.1
DB_NAME_V2=ss_core_02

# die gracefully if it's Saturday or Sunday
# dow=`date +"%A"`
# if [ $dow = "Saturday" ] || [ $dow = "Sunday" ]
#then
#	echo "it's the weekend, exiting without working."
#	exit 0
#fi

# Remove any previous reports
rm -f ${STATS_OUTPUT}/*

. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_HOME}/reportFuncs.sh

for SQL_FILE in MQLReportV2.sql tableau-sales_carson_A_usageDashboardV2.sql tableau-sales_carson_A_usageDashboardMidMarketV2.sql tableau-sales_carson_A_usageDashboardSMBV2.sql tableau-sales_carson_A_usageDashboardStrategicV2.sql tableau-schmale-csDashboard1V2.sql tableau-schmale-csDashboard2V2.sql tableau-schmale-csDashboard3V2.sql tableau-schmale-csDashboard4V2.sql tableau-schmale-csDashboard5V2.sql tableau-schmale-csDashboard6V2.sql tableau-schmale-csDashboard7V2.sql tableau-schmale-csDashboard8V2.sql tableau-schmale-csDashboard9V2.sql tableau-schmale-csDashboard10V2.sql tableau-schmale-csDashboard11V2.sql tableau-schmale-csDashboard12V2.sql tableau-schmale-csDashboard13V2.sql tableau-schmale-csDashboard14V2.sql 

do
echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
 outputReport ${STATS_QUERY}/${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
 done


# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

zipReports *V2.csv insightSales-${LOG_DATE}-a.zip

# actually show the results in Jenkins console
#cat ${LOG_FILE}
