SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG ("Marketo Tableau Weekly", "marketo-ghostLeads.csv");

-- Select all leads in the Marketo lead latency list
SELECT
    mll.listID,
    mll.listName,
    mll.emailAddress AS email,
    mll.leadID AS id,
    mll.userID AS userID__c_contact,
    mll.leadStatus,
    mll.acceptedDateTime AS Accepted_Date_Time__c,
    mll.2StarDatetime AS X2_Star_Date_Time__c,
    mll.3StarDateTime AS X3_Star_Date_Time__c,
    mll.activityCount AS Activity_Count__c_lead,
    mu.trialStartDateTime AS trialStartDateTime__c,
    mu.trialEndDateDateTime AS trialEndDateDateTime__c,
    mu.isStrongLead AS isStrongLead__c,
    mu.isEverWellQualified AS isEverWellQualified__c,
    mu.productName AS productName__c,
    mu.monthlyPlanRate_USD AS monthlyPlanRate_USD__c,
    mu.paymentStartDateTime AS paymentStartDateTime__c,
    mu.salesforceOwnerAtImport,
    mu.salesforceOwnerRoleAtImport AS Owner_Role_at_Import__c,
    mu.isOrgDomain AS isOrgDomain__c,
    mu.fitRating AS Fit_Rating__c,
    mu.paymentTerm AS paymentTerm__c
FROM leadflow.arc_marketo_lead_lists AS mll
LEFT OUTER JOIN leadflow.arc_marketo_upload mu ON mll.emailAddress = mu.emailAddress
WHERE mll.listID IN (
    5316, 5317,    -- Marketo static list IDs for Ghost 5 Test - TEST HAS MATURED June 2016
    78636, 78635,  -- Marketo static list IDs for Ghost 6 Test
    25665, 78718   -- Marketo static list IDs for Fit Rating 1A Ghost Test
)
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG ("Marketo Tableau Weekly", "marketo-ghostLeads.csv");
