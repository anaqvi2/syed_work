SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "featureCountRollupByUser.csv");

-- Select all feature count usage status
SELECT mu.*
FROM rpt_main_02.rpt_featureCountRollupByUser fcru
    JOIN leadflow.arc_marketo_upload mu ON fcru.userID = mu.userID
WHERE mu.lastLogin >= DATE_SUB(NOW(), INTERVAL 365 DAY);

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "featureCountRollupByUser.csv");
