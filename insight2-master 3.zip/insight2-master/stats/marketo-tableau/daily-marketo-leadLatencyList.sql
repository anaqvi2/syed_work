SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-leadLatencyList.csv");

-- Select all leads in the Marketo lead latency list
SELECT
    listID,
    listName,
    emailAddress,
    userID,
    leadID,
    createdDateTime,
    newLeadTriggerDateTime
FROM leadflow.arc_marketo_lead_lists
WHERE listID IN (45694, 49667);

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-leadLatencyList.csv");
