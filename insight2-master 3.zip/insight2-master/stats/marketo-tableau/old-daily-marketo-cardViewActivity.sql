SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "cardViewActivity.csv");

-- Select all card view view count events
SELECT *
FROM rpt_workspace.pj_cardViewClientEvents
WHERE
    logDate >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    AND objectID = 5304
    AND actionID = 51
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "cardViewActivity.csv");
