SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

# Start Logging
CALL leadflow.SMARTSHEET_START_LOG ('Marketo Tableau Daily', 'marketo-leadEmailActivity.csv');

# Get the least of the max activity dates for each activity type.
# THis helps us be comprehensive about not missing any data.
SELECT LEAST(
           MAX(sendDateTime),
           MAX(deliverDateTime),
           MAX(openDateTime),
           MAX(clickDateTime),
           MAX(bounceDateTime),
           MAX(softBounceDateTime),
           MAX(unsubscribeDateTime)
       ) leastMaxActivityDateTime
INTO @leastMaxActivityDateTime
FROM leadflow.arc_marketo_email_activity
;

# Create temporary table for all leadId/primaryAttributeValueId combinations that have happened
# since the @leastMaxActivityDateTime
DROP TABLE IF EXISTS leadflow.tmp_lead_activity;
CREATE TEMPORARY TABLE IF NOT EXISTS leadflow.tmp_lead_activity
(INDEX (leadId, primaryAttributeValueId))
    SELECT DISTINCT
        leadId,
        primaryAttributeValueId
    FROM leadflow.arc_marketo_lead_activity
    WHERE activityDateTime >= @leastMaxActivityDateTime
    GROUP BY leadId, primaryAttributeValueId
;

# Delete potential duplicates. Anything deleted will be reinserted with any updated fields in next query.
# DELETE mea FROM leadflow.arc_marketo_email_activity mea
#     JOIN leadflow.tmp_lead_activity tla ON mea.leadId = tla.leadId AND mea.primaryAttributeValueId = tla.primaryAttributeValueId
# ;

DROP TABLE IF EXISTS leadflow.stg_arc_marketo_email_activity;
CREATE TABLE IF NOT EXISTS leadflow.stg_arc_marketo_email_activity LIKE leadflow.arc_marketo_email_activity;

# Insert new sends and their related activity data
INSERT INTO leadflow.stg_arc_marketo_email_activity
(sendActivityID, leadID, primaryAttributeValueID, primaryAttributeValue, sendDateTime, deliverDateTime, openDateTime, clickDateTime, bounceDateTime, softBounceDateTime, unsubscribeDateTime)
    SELECT
        sends.marketoGUID,
        sends.leadId,
        sends.primaryAttributeValueId,
        sends.primaryAttributeValue,
        sends.activityDateTime,
        delivers.activityDateTime,
        opens.activityDateTime,
        clicks.activityDateTime,
        bounces.activityDateTime,
        softbounces.activityDateTime,
        unsubscribes.activityDateTime
#         CURRENT_TIMESTAMP() insertDateTime,
#         CURRENT_TIMESTAMP() modifyDateTime
    FROM leadflow.arc_marketo_lead_activity sends
        LEFT JOIN leadflow.arc_marketo_lead_activity delivers
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = delivers.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        delivers.primaryAttributeValueId
                                                                                    AND delivers.activityTypeId = 7
        LEFT JOIN leadflow.arc_marketo_lead_activity opens
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = opens.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        opens.primaryAttributeValueId
                                                                                    AND opens.activityTypeId = 10
        LEFT JOIN leadflow.arc_marketo_lead_activity clicks
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = clicks.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        clicks.primaryAttributeValueId
                                                                                    AND clicks.activityTypeId = 11
        LEFT JOIN leadflow.arc_marketo_lead_activity bounces
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = bounces.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        bounces.primaryAttributeValueId
                                                                                    AND bounces.activityTypeId = 8
        LEFT JOIN leadflow.arc_marketo_lead_activity softbounces
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = softbounces.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        softbounces.primaryAttributeValueId
                                                                                    AND softbounces.activityTypeId = 27
        LEFT JOIN leadflow.arc_marketo_lead_activity unsubscribes
                  USE INDEX (leadId_primaryAttributeValueId_activityTypeId_idx) ON
                                                                                    sends.leadId = unsubscribes.leadId
                                                                                    AND sends.primaryAttributeValueId =
                                                                                        unsubscribes.primaryAttributeValueId
                                                                                    AND unsubscribes.activityTypeId = 9
        JOIN leadflow.tmp_lead_activity tla
            ON sends.leadId = tla.leadId AND sends.primaryAttributeValueId = tla.primaryAttributeValueId
    WHERE
        sends.activityTypeId = 6
;

INSERT INTO leadflow.arc_marketo_email_activity
    SELECT *
    FROM leadflow.stg_arc_marketo_email_activity stg
ON DUPLICATE KEY UPDATE
        leadflow.arc_marketo_email_activity.sendActivityID = stg.sendActivityID,
        leadflow.arc_marketo_email_activity.leadId = stg.leadID,
        leadflow.arc_marketo_email_activity.primaryAttributeValueID = stg.primaryAttributeValueID,
        leadflow.arc_marketo_email_activity.primaryAttributeValue = stg.primaryAttributeValue,
        leadflow.arc_marketo_email_activity.sendDateTime = stg.sendDateTime,
        leadflow.arc_marketo_email_activity.deliverDateTime = stg.deliverDateTime,
        leadflow.arc_marketo_email_activity.openDateTime = stg.openDateTime,
        leadflow.arc_marketo_email_activity.clickDateTime = stg.clickDateTime,
        leadflow.arc_marketo_email_activity.bounceDateTime = stg.bounceDateTime,
        leadflow.arc_marketo_email_activity.softBounceDateTime = stg.softBounceDateTime,
        leadflow.arc_marketo_email_activity.unsubscribeDateTime = stg.unsubscribeDateTime
;

SELECT *
FROM leadflow.arc_marketo_email_activity
WHERE sendDateTime >= DATE_SUB(NOW(), INTERVAL 2 MONTH)
;

# Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG ('Marketo Tableau Daily', 'marketo-leadEmailActivity.csv');
