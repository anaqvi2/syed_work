SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-bulletinRollup.csv");

-- Select all bulletins and rollup activities by type
SELECT
    b.bulletinID,
    b.description,
    b.startDateTime,
    b.endDateTime,
    COUNT(bu.userID)                             users,
    SUM(bu.closeCount)                           bulletinTotalCloses,
    IFNULL(SUM(bu.closeDateTime IS NOT NULL), 0) bulletinDistinctCloses,
    IFNULL(SUM(ce.opens > 0), 0)                 distinctOpens,
    IFNULL(SUM(ce.opens), 0)                     totalOpens,
    IFNULL(SUM(ce.closes > 0), 0)                distinctCloses,
    IFNULL(SUM(ce.closes), 0)                    totalCloses,
    IFNULL(SUM(ce.clicks > 0), 0)                distinctClicks,
    IFNULL(SUM(ce.clicks), 0)                    totalClicks,
    IFNULL(SUM(
               CASE
               WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1
                   THEN 0
               WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0
                   THEN 1
               WHEN ucs.valueBoolean = 1
                   THEN 0
               WHEN ucs.valueBoolean = 0
                   THEN 1
               WHEN ocs.valueBoolean = 0
                   THEN 1
               ELSE 0
               END), 0)                          unsubscribes
FROM ss_account_02.bulletin b
    JOIN ss_account_02.bulletinUser bu ON b.bulletinID = bu.bulletinID
    LEFT JOIN (
                  SELECT
                      ce.parm1Int,
                      ce.insertByUserID,
                      SUM(ce.actionID = 1 AND ce.objectID = 10717)  opens,
                      SUM(ce.actionID = 2 AND ce.objectID = 10717)  closes,
                      SUM(ce.actionID = 22 AND ce.objectID = 10718) clicks
                  FROM rpt_main_02.arc_clientEventBulletin ce
                  GROUP BY ce.parm1Int, ce.insertByUserID
              ) ce ON bu.userID = ce.insertByUserID AND bu.bulletinID = ce.parm1Int
    LEFT JOIN (
                  SELECT
                      ucs.userID,
                      our.organizationID
                  FROM ss_account_02.userConfigSetting ucs
                      LEFT JOIN ss_core_02.organizationUserRole our
                          ON ucs.userID = our.userID AND role = "MEMBER" AND state = 1
                  WHERE ucs.configPropertyID = 1300
                  UNION
                  SELECT
                      our.userID,
                      ocs.organizationID
                  FROM ss_account_02.orgConfigSetting ocs
                      JOIN ss_core_02.organizationUserRole our
                          ON ocs.organizationID = our.organizationID AND role = "MEMBER" AND state = 1
                  WHERE ocs.configPropertyID = 1300
              ) org ON bu.userID = org.userID
    LEFT JOIN ss_account_02.orgConfigSetting ocs ON org.organizationID = ocs.organizationID
                                                 AND ocs.configPropertyID = 1300
                                                 AND ocs.insertDateTime BETWEEN
                                                     b.startDateTime AND b.endDateTime
    LEFT JOIN ss_account_02.userConfigSetting ucs ON org.userID = ucs.userID
                                                  AND ucs.configPropertyID = 1300
                                                  AND ucs.insertDateTime BETWEEN
                                                      b.startDateTime AND b.endDateTime
WHERE bu.userID NOT IN (SELECT userID FROM leadflow.arc_marketo_lead_lists WHERE listID = 111557) -- Ignore Marketo seed list users
GROUP BY b.bulletinID
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-bulletinRollup.csv");
