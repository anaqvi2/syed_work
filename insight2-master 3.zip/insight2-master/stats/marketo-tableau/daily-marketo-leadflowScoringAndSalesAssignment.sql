SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-leadflowScoringAndSalesAssignment.csv");

-- Select all lead activities from the past three months
SELECT
    insertDateTime,
    userID,
    emailAddress,
    emailDomain,
    salesforceOwnerAtImport,
    salesforceLeadSource,
    smartscoreCode,
    salesforceStatus,
    salesforceOwnerRoleAtImport,
    fitRating,
    fitScore
FROM leadflow.arc_marketo_upload
WHERE insertDateTime >= '2015-01-01';

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-leadflowScoringAndSalesAssignment.csv");
