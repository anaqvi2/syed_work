DROP TABLE IF EXISTS rpt_workspace.jmarzinke_lead411Employees;
CREATE TABLE IF NOT EXISTS rpt_workspace.jmarzinke_lead411Employees LIKE rpt_main_02.arc_lead411Employees;
ALTER TABLE rpt_workspace.jmarzinke_lead411Employees   
  DROP COLUMN inferredEmail, 
  DROP COLUMN emailType, 
  DROP COLUMN userID, 
  DROP INDEX userID;


LOAD DATA LOCAL INFILE "C:/Users/jmarzinke/git/test-queries/employee_411_data/xae"
INTO TABLE rpt_workspace.jmarzinke_lead411Employees
FIELDS TERMINATED BY ',' ENCLOSED BY '"' ESCAPED BY '\\'
LINES TERMINATED BY '\n' STARTING BY ''
-- IGNORE 1 LINES
(
    personID,
    id,
    @emailAddress,
    @firstName,
    @lastName,
    @company,
    @domain,
    @jobTitle,
    @industry,
    @revenueRange,
    @employeeRange,
    @companyPhone,
    @employeePhone,
    @address,
    @city,
    @state,
    @zip,
    @country,
    @sic,
    @internalTech,
    @externalTech
)
SET
    emailAddress = CASE @emailAddress WHEN '' THEN NULL ELSE @emailAddress END,
    firstName = CASE @firstName WHEN '' THEN NULL ELSE @firstName END,
    lastName = CASE @lastName WHEN '' THEN NULL ELSE @lastName END,
    company = CASE @company WHEN '' THEN NULL ELSE @company END,
    domain = CASE @domain WHEN '' THEN NULL ELSE @domain END,
    jobTitle = CASE @jobTitle WHEN '' THEN NULL ELSE @jobTitle END,
    industry = CASE @industry WHEN '' THEN NULL ELSE @industry END,
    revenueRange = CASE @revenueRange WHEN '' THEN NULL ELSE @revenueRange END,
    employeeRange = CASE @employeeRange WHEN '' THEN NULL ELSE @employeeRange END,
    companyPhone = CASE @companyPhone WHEN '' THEN NULL ELSE @companyPhone END,
    employeePhone = CASE @employeePhone WHEN '' THEN NULL ELSE @employeePhone END,
    address = CASE @address WHEN '' THEN NULL ELSE @address END,
    city = CASE @city WHEN '' THEN NULL ELSE @city END,
    state = CASE @state WHEN '' THEN NULL ELSE @state END,
    zip = CASE @zip WHEN '' THEN NULL ELSE @zip END,
    country = CASE @country WHEN '' THEN NULL ELSE @country END,
    sic = CASE @sic WHEN '' THEN NULL ELSE @sic END,
    internalTech = CASE @internalTech WHEN '' THEN NULL ELSE @internalTech END,
    externalTech = CASE @externalTech WHEN '' THEN NULL ELSE @externalTech END
;


LOAD DATA LOCAL INFILE "C:/Users/jmarzinke/git/test-queries/employee_411_data/411_employees_with_tech_20160315_2000000.csv"
INTO TABLE rpt_workspace.jmarzinke_lead411Employees
FIELDS TERMINATED BY ',' ENCLOSED BY '"' ESCAPED BY '\\'
LINES TERMINATED BY '\n' STARTING BY ''
-- IGNORE 1 LINES
(
    personID,
    id,
    emailAddress,
    firstName,
    lastName,
    company,
    domain,
    jobTitle,
    industry,
    revenueRange,
    employeeRange,
    companyPhone,
    employeePhone,
    address,
    city,
    state,
    zip,
    country,
    sic,
    internalTech,
    externalTech
)
;
SELECT COUNT(*) FROM rpt_workspace.jmarzinke_lead411Employees;

