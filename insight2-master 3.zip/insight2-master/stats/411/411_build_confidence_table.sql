
USE rpt_workspace;


-- Created one table lWarr_emailFormat in domainformat2. Created a column confidence such that if there was only one email 
-- the highest confidence would be 5 and if there were less than 5 emails the highest confidence would be 7. If the email was in the 
-- original table the confidence is 10, otherwise the highest it can be is 9. I then created a new table lWarr_lead411EmployeeConfidence 
-- that added the personID with each domain/emailEnd that it matched with the corresponding confidence. 
-- EX: kcarney@ has two email endings with confidence 9 and 0. 



DROP TABLE jmarzinke_emailDomainCount;
CREATE TABLE jmarzinke_emailDomainCount (
domain VARCHAR(100), 
totalCount MEDIUMINT(9),
PRIMARY KEY (domain))
;

INSERT INTO jmarzinke_emailDomainCount
SELECT domain, COUNT(*) FROM jmarzinke_lead411EmployeesClean
GROUP BY domain
;

SELECT domain, COUNT(*) FROM jmarzinke_lead411EmployeesClean
GROUP BY domain
ORDER BY 2 DESC
;

SELECT * FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT LIKE "%.%"
;

SELECT * FROM jmarzinke_emailDomainCount
LIMIT 100000
;

UPDATE jmarzinke_emailFormat
SET confidence = NULL
;

SELECT ROUND(.4999999999, 1);
SELECT ROUND(.5000000001, 1);
SELECT ROUND(.5);
SELECT 1/18;
SELECT ROUND((1/20) * 9);
DROP TABLE jmarzinke_asdf;
CREATE TABLE jmarzinke_asdf (f FLOAT);
INSERT INTO jmarzinke_asdf
SELECT (1/18) * 9;

SELECT ROUND(f) FROM jmarzinke_asdf;

ALTER TABLE jmarzinke_emailFormat ADD confidence TINYINT(3);

UPDATE jmarzinke_emailFormat                        
SET confidence = 
    IF(
        (SELECT totalCount FROM jmarzinke_emailDomainCount WHERE jmarzinke_emailDomainCount.domain = jmarzinke_emailFormat.domain) = 1, 
        ROUND((jmarzinke_emailFormat.ct * 9) - 4), 
        IF(
            (SELECT totalCount FROM jmarzinke_emailDomainCount WHERE jmarzinke_emailDomainCount.domain = jmarzinke_emailFormat.domain) < 6,
            ROUND((
                (jmarzinke_emailFormat.ct / (SELECT totalCount FROM jmarzinke_emailDomainCount WHERE jmarzinke_emailDomainCount.domain = jmarzinke_emailFormat.domain)) * 9
            ) - 2),
            ROUND((jmarzinke_emailFormat.ct / (SELECT totalCount FROM jmarzinke_emailDomainCount WHERE jmarzinke_emailDomainCount.domain = jmarzinke_emailFormat.domain)) * 9)
        )
    )
;

UPDATE jmarzinke_emailFormat ef
JOIN jmarzinke_emailDomainCount edc ON ef.domain = edc.domain
SET ef.confidence = 
    IF(
        edc.totalCount = 1, 
        ROUND((ef.ct * 9) - 4), 
        IF(
            edc.totalCount < 6,
            ROUND(((ef.ct / edc.totalCount) * 9) - 2),
            ROUND((ef.ct / edc.totalCount) * 9)
        )
    )
;

LOAD DATA LOCAL INFILE 'C:/Users/jmarzinke/git/test-queries/employee_411_data/export.csv'
INTO TABLE jmarzinke_emailFormat
FIELDS TERMINATED BY ',' ENCLOSED BY ''
IGNORE 1 LINES  -- ignore header
(
    domain,
    emailEnd,
    form,
    ct,
    confidence
)
;

SELECT * FROM jmarzinke_emailFormat
WHERE confidence = 4
;

SELECT * FROM jmarzinke_emailFormat ef
JOIN jmarzinke_emailDomainCount edc ON ef.domain = edc.domain
WHERE ef.domain = "3plworldwide.com"
;

SELECT confidence, COUNT(*) FROM jmarzinke_emailFormat
GROUP BY confidence
;

SELECT form, domain, COUNT(*) FROM jmarzinke_emailFormat
GROUP BY form, domain
ORDER BY form DESC, 3 DESC
;

SELECT * FROM jmarzinke_emailFormat
WHERE domain = "usps.com"
;

SELECT * FROM rpt_workspace.jmarzinke_emailFormat  LIMIT 100;
SELECT * FROM rpt_workspace.lWarr_lead411EmployeeConfidence LIMIT 20;
SELECT * FROM rpt_workspace.cDunn_lead411Employees LIMIT 20;

DROP TABLE IF EXISTS jmarzinke_lead411EmployeeConfidence;
CREATE TABLE jmarzinke_lead411EmployeeConfidence (
    personID INT(11),
    hypothesizedEmail VARCHAR(100), 
    confidence TINYINT(3),
    PRIMARY KEY (personID, hypothesizedEmail, confidence)
);

SELECT COUNT(*) FROM jmarzinke_lead411EmployeesClean
WHERE domain = "usps.com" AND SUBSTR(emailAddress, INSTR(emailAddress, '@') + 1) != "usps.com"
;

SELECT COUNT(*) FROM jmarzinke_lead411Employees
WHERE emailAddress IS NOT NULL
;

SELECT COUNT(*) FROM jmarzinke_lead411EmployeesClean
WHERE firstName LIKE '%"%'
;

SELECT ed.personID, ed.firstName, ed.lastName FROM jmarzinke_emailFormat ef
JOIN jmarzinke_lead411EmployeesClean ed ON ef.domain = ed.domain AND ef.form = 'flast'
WHERE ed.emailAddress != '' AND LENGTH(ed.firstName) > 0 AND LENGTH(ed.lastName) > 1
ORDER BY 
;

-- inner joins lWarr_emailFormat with cDunn_lead411Employees to make email formats of all users on that domain
-- have to comment and uncomment each eamil format and run each one in the select and where clause
INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    a.personID,
    LOWER(CONCAT(SUBSTRING(a.firstName, 1, 1), a.lastName, '@', b.emailEnd)),
    b.confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND b.form = 'flast'
WHERE
    a.emailAddress != ''
    AND LENGTH(a.firstName) > 0 AND LENGTH(a.lastName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, lastName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'firstlast'
WHERE
    a.emailAddress != ''
    AND LENGTH(firstName) > 1 AND LENGTH(lastName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, '.', lastName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'first.last'
WHERE
    a.emailAddress != ''
    AND LENGTH(firstName) > 1 AND LENGTH(lastName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, SUBSTRING(firstName, 1, 1), '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'lastf'
WHERE
    a.emailAddress != ''
    AND LENGTH(firstName) > 0 AND LENGTH(lastName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, firstName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'lastfirst'
WHERE
    a.emailAddress != ''
    AND LENGTH(lastName) > 1 AND LENGTH(firstName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'last'
WHERE
    a.emailAddress != ''
    AND LENGTH(lastName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, SUBSTRING(lastName, 1, 1), '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'firstl'
WHERE
    a.emailAddress != ''
    AND LENGTH(firstName) > 1 AND LENGTH(lastName) > 0
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'first'
WHERE
    a.emailAddress != ''
    AND LENGTH(firstName) > 1
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, '.', firstName, '@', emailEnd)),
    confidence
FROM jmarzinke_emailFormat b
INNER JOIN jmarzinke_lead411EmployeesClean a ON a.domain = b.domain AND form = 'last.first'
WHERE
    a.emailAddress != ''
    AND LENGTH(lastName) > 1 AND LENGTH(firstName) > 1
;

SELECT COUNT(*) FROM jmarzinke_lead411EmployeeConfidence
;

SELECT confidence, COUNT(*) FROM jmarzinke_lead411EmployeeConfidence
GROUP BY confidence
;

SELECT hypothesizedEmail, COUNT(*) COUNT FROM jmarzinke_lead411EmployeeConfidence
GROUP BY hypothesizedEmail
ORDER BY COUNT DESC
;



-- Make all confidences of 0 = 1 so that domains with no known emails can have a confidence of 0.  
UPDATE jmarzinke_lead411EmployeeConfidence
SET confidence = 1
WHERE confidence = 0
;


-- Adds every email format to the confidence table for users on a domain that have no know email formats with a confidence level of 0. 
-- Have to comment and uncomment each format and run it for every one.
INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(SUBSTRING(firstName, 1, 1), lastName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, lastName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, '.', lastName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, SUBSTRING(firstName, 1, 1), '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, firstName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, SUBSTRING(lastName, 1, 1), '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(firstName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT
    personID,
    LOWER(CONCAT(lastName, '.', firstName, '@', domain)),
    0
FROM jmarzinke_lead411EmployeesClean
WHERE domain NOT IN (SELECT domain FROM jmarzinke_emailFormat) AND emailAddress = '' AND (lastName != '' AND firstName != '')
;


-- Adds emails given in cDunn_lead411Employees to lWarr_lead411EmployeeConfidence with a confidence of 10
INSERT INTO jmarzinke_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(emailAddress), 10 FROM jmarzinke_lead411EmployeesClean WHERE emailAddress != '';

SELECT * FROM lWarr_lead411Employees LIMIT 200;
SELECT * FROM cDunn_lead411Employees LIMIT 200;

SELECT COUNT(*) FROM jmarzinke_lead411EmployeeConfidence;

SELECT confidence, COUNT(*) FROM jmarzinke_lead411EmployeeConfidence
GROUP BY confidence
ORDER BY confidence ASC;


-- GREAT EXAMPLE
-- select * from lWarr_lead411Employees where domain='anixter.com';
-- select * from lWarr_lead411EmployeeConfidence where personID='128504';
-- expect terrance.faber@anixter.com with a high confidence
-- kkyriss@aquaamerica.com

-- ANOTHER GREAT EXAMPLE 
-- select * from lWarr_lead411Employees where domain='avaloncommunities.com';
-- select a.personID, a.id, a.emailAddress, b.hypothesizedEmail, b.confidence, a.firstName, a.lastName, a.company, a.domain, a.jobTitle, a.industry, a.revenueRange, a.employeeRange from lWarr_lead411Employees a inner join lWarr_lead411EmployeeConfidence b on a.personID=b.personID where domain='avaloncommunities.com';

-- EXAMPLE OF TWO FORMATS
-- select * from lWarr_lead411Employees where domain='bpoc.com';
-- select * from lWarr_lead411EmployeeConfidence where personID='26772828';



-- MATCH RATE AFTER ALL HAVE AT LEAST ONE EMAIL-----------------------------------


USE rpt_main_02;
-- english/US matches 
SELECT  COUNT(*) FROM 
	rpt_workspace.cDunn_lead411Employees a 
		INNER JOIN  
	rpt_main_02.userAccount USER ON a.personID=user.userID
		INNER JOIN 
	rpt_workspace.lWarr_lead411EmployeeConfidence b ON a.personID=b.personID
        INNER JOIN 
	rpt_main_02.rpt_trials tri ON a.personID=tri.userID
		INNER JOIN 
	rpt_main_02.rpt_paymentProfile pay ON tri.paymentProfileID=pay.paymentProfileID
		LEFT OUTER JOIN
	rpt_main_02.arc_ISPDomains isp ON isp.domain=a.domain
     WHERE 
     isp.domain IS NULL AND
    --  languageFriendly='English' and countryFriendly='United States' and
     confidence=10 AND 
      (productName!='Enterprise' AND productName!='Team' AND productName!='Advanced' AND productName!='Basic')
      AND trialDateTime >= '2015-06-01' AND trialDateTime < '2015-07-01' ;
 --    group by productName ;  
    

