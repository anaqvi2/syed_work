USE rpt_workspace;

DROP TABLE IF EXISTS rpt_workspace.jmarzinke_lead411EmployeesClean;
CREATE TABLE rpt_workspace.jmarzinke_lead411EmployeesClean LIKE rpt_workspace.jmarzinke_lead411Employees;
INSERT INTO rpt_workspace.jmarzinke_lead411EmployeesClean
SELECT
    ed.personID,
    ed.id,
    LOWER(ed.emailAddress),
    ed.firstName,
    ed.lastName,
    ed.company,
    LOWER(ed.domain),
    ed.jobTitle,
    ed.industry,
    ed.revenueRange,
    ed.employeeRange,
    ed.companyPhone,
    ed.employeePhone,
    ed.address,
    ed.city,
    ed.state,
    ed.zip,
    ed.country,
    ed.sic,
    ed.internalTech,
    ed.externalTech
FROM rpt_workspace.jmarzinke_lead411Employees ed
WHERE NOT ( 
    ((ed.firstName LIKE '?%' OR ed.lastName LIKE '?%') AND (ed.emailAddress LIKE '%?%' OR ed.emailAddress = ''))
    OR ((ed.firstName LIKE '&%' OR ed.lastName LIKE '&%') AND (ed.emailAddress LIKE '%&%' OR ed.emailAddress = ''))
    OR ((ed.firstName LIKE '-%' OR ed.lastName LIKE '-%') AND (ed.emailAddress LIKE '%-%' OR ed.emailAddress = ''))
    OR ((ed.firstName LIKE '.%' OR ed.lastName LIKE '.%') AND ed.emailAddress = '')
    OR ((ed.firstName LIKE '1%' OR ed.lastName LIKE '1%') AND ed.emailAddress = '')
    OR ((ed.firstName LIKE '2%' OR ed.lastName LIKE '2%') AND ed.emailAddress = '')
    OR ((ed.firstName LIKE '0%' OR ed.lastName LIKE '0%') AND ed.emailAddress = '')
    OR ((ed.firstName LIKE '4%' OR ed.lastName LIKE '4%') AND ed.emailAddress = '')
    OR ((ed.firstName LIKE '7%' OR ed.lastName LIKE '7%') AND ed.emailAddress = '')
)
;


-- creates a table of all domains in cDunn_lead411Employee with count, format of email, and email ending (sometimes different from domain) 
DROP TABLE IF EXISTS rpt_workspace.jmarzinke_emailFormat;
CREATE TABLE rpt_workspace.jmarzinke_emailFormat (
domain VARCHAR(100), 
ct MEDIUMINT(9),
form VARCHAR(100), 
emailEnd VARCHAR(100));


INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- first inital lastName @ domain
SELECT DISTINCT domain, COUNT(*) AS ct, 'flast', SUBSTR(emailAddress, INSTR(emailAddress, '@') + 1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(SUBSTRING(firstName, 1, 1), lastName, '@%')) AND LENGTH(firstName)>0 AND LENGTH(lastName)>1) AS b
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- firstLast 
SELECT DISTINCT domain, COUNT(*) AS ct,'firstlast', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(firstName,lastName, '@%')) AND LENGTH(firstName)> 1 AND LENGTH(lastName)>1) AS c
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- first.Last
SELECT DISTINCT domain, COUNT(*) AS ct, 'first.last', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(firstName,'.',lastName, '@%')) AND LENGTH(firstName)>1 AND LENGTH(lastName)>1) AS d
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- lastF
SELECT DISTINCT domain, COUNT(*) AS ct,  'lastf', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(lastName,SUBSTRING(firstName, 1,1), '@%'))AND LENGTH(firstName)>0  AND LENGTH(lastName)>1 )  AS e
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- lastFirst
SELECT DISTINCT domain, COUNT(*) AS ct, 'lastfirst', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(lastName,firstName, '@%')) AND LENGTH(firstName)>1 AND LENGTH(lastName)>1) AS f
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat(domain, ct, form, emailEnd)
-- last
SELECT DISTINCT domain, COUNT(*) AS ct, 'last', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(lastName, '@%')) AND LENGTH(lastName)>1) AS g
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat(domain, ct, form, emailEnd)
-- firstL
SELECT DISTINCT domain, COUNT(*) AS ct, 'firstl', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(firstName, SUBSTRING(lastName,1,1), '@%'))AND LENGTH(lastName)>0  AND LENGTH(firstName)>1) AS h
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- first 
SELECT DISTINCT domain, COUNT(*) AS ct,  'first', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(firstName, '@%')) AND LENGTH(firstName)>1) AS i
WHERE domain != '' GROUP BY domain, emailEnd;

INSERT INTO jmarzinke_emailFormat (domain, ct, form, emailEnd)
-- last.First
SELECT DISTINCT domain, COUNT(*) AS ct, 'last.first', SUBSTRING(emailAddress FROM LOCATE('@', emailAddress)+1) AS emailEnd FROM (
SELECT firstName, lastName, LOWER(domain) domain, LOWER(emailAddress) emailAddress FROM rpt_workspace.jmarzinke_lead411EmployeesClean WHERE LOWER(emailAddress) LIKE LOWER(CONCAT(lastName, '.', firstName, '@%')) AND LENGTH(lastName)>1 AND LENGTH(firstName)>1) AS j
WHERE domain != '' GROUP BY domain, emailEnd;

SELECT form, COUNT(*), SUM(ct) FROM rpt_workspace.jmarzinke_emailFormat
GROUP BY form
ORDER BY form ASC;

SELECT emailEnd, COUNT(*) FROM rpt_workspace.jmarzinke_emailFormat
GROUP BY emailEnd
ORDER BY 2 DESC
;
