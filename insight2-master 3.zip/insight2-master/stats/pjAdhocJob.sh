
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/query

# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
LOG_FILE=${STATS_HOME}/logs/PJAdhocJob_${LOG_DATE}.log
exec > $LOG_FILE 2>&1

DB_SERVER=127.0.0.1
DB_NAME_V2=ss_core_02

# Remove any previous reports
rm -f ${STATS_OUTPUT}/*

echo "Deleting log and report files older than 100 days..."
find ${STATS_HOME}/logs/PJAdhocJob* -mmin +1800 -type f -delete -print

. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_HOME}/reportFuncs.sh

SQL=$2

for SQL_FILE in ${STATS_QUERY}/${SQL}
do
  echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  mysql -h ${DB_SERVER} -D ${DB_NAME_V2} -u ${DB_USER} -p${DB_PWD} --force -v --unbuffered < ${SQL_FILE}
done



# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
cat ${LOG_FILE} >> ${LOG_FILE}.results
