-- Reports  Edited 
SELECT DATE_FORMAT(SV.insertDate,'%Y-%m') AS InsertMonth, SV.insertDate, 
	CASE 
		WHEN ST.SheetCategory LIKE '%project%' THEN ST.SheetCategory 
		WHEN ST.SheetCategory LIKE '%task%' THEN "Task List" 
		ELSE "Other" 
	END AS SheetCategory, 
	SUM(NumViews) AS Counts
FROM rpt_workspace.rArunk_OrgDB_SheetsViewed SV 
INNER JOIN rpt_workspace.rArunk_OrgDB_SheetsTable ST ON ST.containerID = SV.containerID 
WHERE ST.containerType=3 
AND SV.TransType != 'Views' 
AND SV.masterDomain = @domain
GROUP BY 1,2,3
ORDER BY 1, 2, 3
LIMIT 1234567
;