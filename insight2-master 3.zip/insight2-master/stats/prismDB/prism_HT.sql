/* ---- **** HOME TAB ***** ----- */

	-- Total Licensed Users
	SELECT "Total Licensed Users" AS Category, COUNT(DISTINCT UT.mainContactuserID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_UserTable UT 
	WHERE UT.masterDomain = @domain 
	AND UT.currentProductGroup NOT LIKE '%collab%'
	AND UT.currentProductGroup NOT LIKE '%trial%'

	UNION
	-- Total Users
	SELECT "Total Users" AS Category, COUNT(DISTINCT UT.mainContactuserID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_UserTable UT 
	WHERE UT.masterDomain = @domain 

	UNION
	-- Total Groups 
	SELECT "Total Groups" AS Category, COUNT(DISTINCT UG.orgGroupID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_UserGroupsTable UG
	WHERE UG.masterDomain = @domain 

	UNION
	-- Total Sheets
	SELECT "Total Sheets" AS Category, COUNT(DISTINCT ST.ContainerID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
	WHERE ST.masterDomain = @domain 
	AND ST.containerType=2 

	UNION
	-- Total Reports
	SELECT "Total Reports" AS Category, COUNT(DISTINCT ST.ContainerID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
	WHERE ST.masterDomain = @domain 
	AND ST.containerType=3 

	UNION 
	-- Total Sheet Views 
	SELECT "Total Sheet Views" AS Category, SUM(SV.NumSheetsViewed) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_SheetsViewedCategory SV 
	WHERE SV.masterDomain = @domain

	 UNION
	-- Total Shares - People 
	SELECT "Total People Shared to" AS Category, COUNT(DISTINCT GAM.userID) AS Counts
	FROM rpt_main_02.gridAccessMap GAM
	INNER JOIN rpt_workspace.rArunk_OrgDB_SheetsTable ST 
		ON ST.gridID = GAM.GridID 
		AND GAM.access<50
	WHERE ST.masterDomain = @domain

	UNION
	-- Total Discussions
	SELECT "Total Discussions" AS Category, (COUNT(DISTINCT DT.DiscussionID)) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_DiscussionsTable DT 
	WHERE DT.masterDomain = @domain 

	 UNION
	-- Total Shares - Volume
	SELECT "Total Share Count" AS Category, COUNT(GAM.userID) AS Counts
	FROM rpt_main_02.gridAccessMap GAM
	INNER JOIN rpt_workspace.rArunk_OrgDB_SheetsTable ST 
		ON ST.gridID = GAM.GridID 
		AND GAM.access<50
	WHERE ST.masterDomain = @domain

	UNION
	-- Total Reminders 
	SELECT "Total Reminders" AS Category, COUNT(DISTINCT(n.notificationID)) AS Counts  
	FROM rpt_workspace.cDunn_arc_notification n
	INNER JOIN rpt_workspace.rArunk_OrgDB_SheetsTable ST 
	 ON n.ownerKeyID = ST.GridID 
	WHERE ST.masterDomain = @domain 

	UNION
	-- Total Alerts 
	SELECT "Total Alerts" AS Category, COUNT(DISTINCT(r.reminderID)) AS Counts
	FROM rpt_main_02.reminder r
	INNER JOIN rpt_workspace.rArunk_OrgDB_SheetsTable ST 
		ON r.gridID = ST.GridID 
	WHERE ST.masterDomain = @domain 

	UNION
	-- Total Attachments
	SELECT "Total Attachments" AS Category, COUNT(DISTINCT OAT.originaldocAttachID) AS Counts
	FROM rpt_workspace.rArunk_OrgDB_AttachmentsTable OAT 
	WHERE OAT.masterDomain = @domain 

	UNION 
	-- Total Attachment Viewed
	
SELECT "Total Attachment Views" AS Category, SUM(AV.NumViews) AS Counts
		FROM rpt_workspace.rArunk_OrgDB_AttachmentViewed AV 
		WHERE AV.masterDomain = @domain
		AND AV.TransType = "Views"

	UNION
	-- Total Update Requests
	SELECT "Total Update Requests" AS Category, COUNT(DISTINCT SFT.FeatureID) AS Counts 
	FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT 
	WHERE SFT.masterDomain = @domain 
	AND SFT.FeatureType='Update Requests'

	UNION
	-- Total WebForms 
	SELECT "Total Web Forms Created" AS Category, COUNT(DISTINCT SFT.FeatureID) AS Counts 
	FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT 
	WHERE SFT.masterDomain = @domain 
	AND SFT.FeatureType='Web Forms'
;

/* ---- **** END HOME TAB **** ---- */