
ZIP=/usr/bin/zip

getFileNameWithExt () {
  FILE_NAME=${1##*/}
}

getFileNameWithoutExt () {
  FILE_NAME=${1##*/}
  FILE_NAME=${FILE_NAME%%.*}
}

zipFileAndRemoveSource () {
  echo "Zip $1 to $2"
  zip -j -9 $2 $1
  rm -rf $1
}

# Args are: outputReport [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
outputReport () {
  getFileNameWithoutExt $1
  OUTPUT_NAME=${FILE_NAME}.csv
  OUTPUT_FILE=${STATS_OUTPUT}/${OUTPUT_NAME}
  OUTPUT_ZIP_NAME=${OUTPUT_NAME}.zip
  OUTPUT_ZIP_FILE=${STATS_OUTPUT}/${OUTPUT_ZIP_NAME}
  mysql --default-character-set=utf8 -h $2 -u $4 -p$5 -D $3 -e "set @domain=${SQLDOMAIN}; source ${SQL_FILE};" -f < $1 | tr -d ',' | tr '\11' ',' > $OUTPUT_FILE
}

# Args are: zipReports [MatchingFiles] [OutputFileName]
zipReports () {
  echo "Zipping reports $1 to $2"
  pushd $STATS_OUTPUT
  ZIP_FILE=${2}
  REPORT_FILES=${1}
  echo "Zipping files ${REPORT_FILES} to ${ZIP_FILE}"
  ${ZIP} -g ${ZIP_FILE} ${REPORT_FILES}
  rm -f ${REPORT_FILES}

  # Removed 2016-01-08: Dropbox staging area not needed anymore because we are using
  #                     the artifact archiving feature in Jenkins.
  #echo "Copying file ${ZIP_FILE} to staging area"
  #cp ${ZIP_FILE} /var/lib/jenkins/dropbox/
  popd
}

