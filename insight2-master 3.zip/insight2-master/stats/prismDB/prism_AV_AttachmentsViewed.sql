-- Attachments Viewed 
SELECT DATE_FORMAT(AV.insertDate,'%Y-%m') AS InsertMonth, AV.insertDate, OAT.AttachmentGroup, SUM(AV.NumViews) AS Counts
FROM rpt_workspace.rArunk_OrgDB_AttachmentViewed AV 
INNER JOIN rpt_workspace.rArunk_OrgDB_AttachmentsTable OAT ON OAT.originalDocAttachID = AV.OriginalDocAttachID
WHERE AV.TransType = "Views" 
AND AV.masterDomain = @domain
GROUP BY 1,2,3
ORDER BY 1,2,3
LIMIT 123456789
;
