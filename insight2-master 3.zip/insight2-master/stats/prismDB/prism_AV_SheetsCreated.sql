-- Sheets Created 
SELECT DATE_FORMAT(insertDate, '%Y-%m') AS InsertMonth, insertDate, 
	CASE 
		WHEN ST.SheetCategory LIKE '%project%' THEN ST.SheetCategory 
		WHEN ST.SheetCategory LIKE '%task%' THEN "Task List" 
		ELSE "Other" 
	END AS SheetCategory, 
	COUNT(containerID) counts 
FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
WHERE ST.containerType=2 
AND ST.masterDomain = @domain
GROUP BY 1,2,3
ORDER BY 1
LIMIT 1234567;