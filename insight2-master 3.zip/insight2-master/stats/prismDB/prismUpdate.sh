#!/bin/bash

# set up our environment
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats

# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
LOG_FILE=${STATS_HOME}/logs/runDaily_${LOG_DATE}.log
exec > $LOG_FILE 2>&1

# grab secure configs
. ${SMARTUSER_HOME}/backupinfo.sh

# connect to our database
DB_SERVER=127.0.0.1
DB_NAME_V2=ss_core_02



echo "Executing Prism Update for $1"

# execute prism stored procedure
echo "**** $(date +%X) : Running CALL rpt_main_02.prismDBRun($1) ****"
mysql -h ${DB_SERVER} -D ${DB_NAME_V2} -u ${DB_USER} -p${DB_PWD} --force -v --unbuffered -e "CALL rpt_main_02.prismDBRun("$2");"


# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
cat ${LOG_FILE} >> ${LOG_FILE}.results