-- Alerts, Notifications and Update Requests
SELECT DATE_FORMAT(SFT.insertDate, '%Y-%m') AS InsertMonth, SFT.insertDate, FeatureType, COUNT(SFT.featureID) AS FeatureCount 
FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT
WHERE SFT.masterDomain = @domain
GROUP BY 1,2,3
LIMIT 1234567
;