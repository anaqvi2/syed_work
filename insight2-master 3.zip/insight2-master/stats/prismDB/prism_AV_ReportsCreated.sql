-- Reports Created
SELECT DATE_FORMAT(insertDate, '%Y-%m') AS InsertMonth, insertDate, COUNT(containerID) ReportsCreated
FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
WHERE ST.containerType=3 
AND ST.masterDomain = @domain
GROUP BY 1,2
LIMIT 123456789
;