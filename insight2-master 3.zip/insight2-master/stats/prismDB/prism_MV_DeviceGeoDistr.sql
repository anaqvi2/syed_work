-- Device Geo Distribution
SELECT UDT.device, 
CASE 
WHEN UT.currentProductGroup LIKE '%Collab%' THEN UT.currentProductGroup 
WHEN UT.currentProductGroup LIKE '%Trial%' THEN UT.currentProductGroup
ELSE "Licensed User" END AS currentProductGroup, 
	UDT.countryName, UDT.regionName, UDT.ipCity, COUNT(DISTINCT UT.mainContactUserID) NumUsers 
FROM rpt_workspace.rArunk_OrgDB_UserDevicesTable UDT 
INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
	ON UT.mainContactUserID = UDT.mainContactUserID
WHERE UDT.masterDomain = @domain 
AND UT.currentproductGroup NOT IN ('External Collaborator')
GROUP BY 1,2,3,4,5
LIMIT 123456789;