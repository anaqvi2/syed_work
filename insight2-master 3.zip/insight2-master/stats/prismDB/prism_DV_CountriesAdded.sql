-- Countries Added (Area Chart) Summary Page
SELECT UT.ipCountry, CASE WHEN MIN(UT.StartDate)<'2013-01-01' THEN '2012-12' ELSE DATE_FORMAT(MIN(UT.StartDate),'%Y-%m') END AS StartMonth, 
CASE WHEN MIN(UT.StartDate)<'2013-01-01' THEN '2012-12-31' ELSE MIN(UT.StartDate) END AS StartDate
FROM rpt_workspace.rArunk_OrgDB_UserTable UT
WHERE UT.masterDomain = @domain
GROUP BY 1
ORDER BY 3 ASC
LIMIT 123456
;