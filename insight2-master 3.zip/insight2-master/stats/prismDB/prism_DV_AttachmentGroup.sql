SELECT OAT.AttachmentGroup, COUNT(*) 
FROM rpt_workspace.rArunk_OrgDB_AttachmentsTable OAT 
WHERE OAT.masterDomain = @domain
GROUP BY 1;