-- Discussions Added 
SELECT DATE_FORMAT(insertDate,'%Y-%m') AS InsertMonth, insertDate, COUNT(discussionID) discussionscounts, SUM(DT.discussionThreads) DiscussionReplies 
FROM rpt_workspace.rArunk_OrgDB_DiscussionsTable DT 
WHERE DT.masterDomain = @domain
GROUP BY 1,2
ORDER BY 1
LIMIT 12345678
;