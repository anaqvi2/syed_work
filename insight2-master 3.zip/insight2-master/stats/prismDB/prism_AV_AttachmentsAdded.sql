-- Attachments Added 
SELECT DATE_FORMAT(insertDate,'%Y-%m') AS InsertMonth, insertDate, attachmentGroup, COUNT(OriginaldocAttachID) attachmentcounts 
FROM rpt_workspace.rArunk_OrgDB_AttachmentsTable OAT 
WHERE OAT.masterDomain = @domain
GROUP BY 2,3
ORDER BY 1
LIMIT 123456789
;