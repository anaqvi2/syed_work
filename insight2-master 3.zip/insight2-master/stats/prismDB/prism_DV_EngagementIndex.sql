-- Engagement Index - Top 50 
		-- +++++ ((**** THIS WILL NEED TO GET CHANGED TO POINT TO PAIVAND'S TABLE **** ))
SELECT UT.mainContactUserID, UT.userName, ROUND(SQRT(GUE.compositeEngagementScore),0) AS EngagementIndex 
FROM rpt_workspace.cDunn_OrgDBUserEngagement GUE
INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
	ON GUE.mainContactUserID = UT.mainContactUserID
WHERE UT.masterDomain = @domain 
AND UT.currentProductGroup in("Team","Enterprise")
ORDER BY 3 DESC
LIMIT 50
;