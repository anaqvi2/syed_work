
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/query

#LOG_DATE=$1
#LOG_FILE=${STATS_HOME}/logs/checkDataLatency_${LOG_DATE}.log
#exec > $LOG_FILE 
2>&1

DB_SERVER=127.0.0.1
DB_NAME_V2=rpt_main_02

# Remove any previous reports
#rm -f ${STATS_OUTPUT}/*

. ${STATS_HOME}/reportFuncs.sh
. ${SMARTUSER_HOME}/backupinfo.sh

echo 'Starting mysql call to check for data latency.'
mysql -h ${DB_SERVER} -u ${DB_USER} -p${DB_PWD} -D ${DB_NAME_V2} --force -v --unbuffered --execute='call utl_checkDataLatency(now(),NULL,@err);'
SQLSTATUS=$?

# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

# did it work?
if [ $SQLSTATUS == 1 ]
then
	echo "ERROR: Something failed during the call to the database. See SQL error above."
	exit 1
else
	echo "We didn't detect any SQL errors."
	exit 0
fi


