-- **************************************************************************************************************************
-- This is running every 5 minutes, so it has to run super fast...
-- **************************************************************************************************************************
# SET @@sql_mode = '';

USE rpt_workspace;
SELECT DATABASE();

-- debug
SHOW VARIABLES LIKE 'tx_isolation';
-- prevent us from locking any tables in core that might slow/stop replication
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- debug - test longer wait timeout
SET tokudb_lock_timeout = 300000;

-- debug
SHOW VARIABLES LIKE 'tx_isolation';

SELECT '************************************* start: ', ROW_COUNT(), NOW();

SELECT 10 INTO @insertPriority; -- highest priority, gets pushed to marketo first
SELECT 8 INTO @updatePriority; -- second highest priority

-- Added 2016-03-03
-- Use this variable for all date dependent lookbacks. Now when there are replication
-- issues, we only need to change the INTERVAL in one place.
SELECT DATE_SUB(NOW(), INTERVAL 24 HOUR) INTO @marketoLookbackDateTime;

SELECT '************************************* MAX(userAccountModifyDateTime), MAX(ppModifyDateTime), lastTrialDate rows: ', ROW_COUNT(), NOW();


/* REMOVE ABOVE WHEN WE GO TO PRODUCTION   */

-- Stage the leads
CREATE TABLE IF NOT EXISTS rpt_workspace.jmarzinke_marketo_lead_seed_temp LIKE rpt_workspace.jmarzinke_marketo_lead_seed;

-- truncate instead of drop and recreate to try to get more consistent query plans
TRUNCATE TABLE rpt_workspace.jmarzinke_marketo_lead_seed_temp;

ANALYZE TABLE rpt_workspace.jmarzinke_marketo_lead_seed_temp;

-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------
-- toddj - 3/4/2015 - code to catch updated payment profiles not just inserted ones


-- *********************************************************************************************************************
-- find and include the current leads in trial
-- *********************************************************************************************************************
REPLACE INTO rpt_workspace.jmarzinke_marketo_lead_seed_temp
(
    insertSource,
    userID,
    paymentProfileID,
    isTrialRestart,
    trialModifyDateTime
)
    SELECT
        'insight-trial' AS insertSource,
        hpp.ownerID     AS userID,
        hpp.paymentProfileID,
        CASE WHEN hppOld.productID IS NULL
            THEN 0
        ELSE 1 END      AS isTrialRestart,
        # First time is a trial in which the user did not previously have a payment Profile
        hpp.modifyDateTime
    FROM ss_core_02.hist_paymentProfile hpp
        # Compare to previous hist_paymentProfile entry
        LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppOld
            ON hpp.paymentProfileID = hppOld.paymentProfileID
               # This accounts for 1 second delays in the hist_effectiveThruDateTime
               AND (hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND
                    OR hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime)
               # This will ignore previous records that were trials
               AND (hppOld.productID != 1 OR hppOld.productID IS NULL)
        LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON mu.userID = hpp.ownerID
    WHERE hpp.productID = 1 # in trial
          AND (hpp.modifyDateTime != hpp.hist_effectiveThruDateTime OR hpp.modifyDateTime != hpp.hist_effectiveThruDateTime - INTERVAL 1 SECOND) # Ignore zero or negative second trials.
          AND hpp.modifyDateTime >= @marketoLookbackDateTime # replication may be behind so look back extra
          AND hpp.accountType != 3 # don't include org trials
          AND hpp.hist_effectiveThruDateTime >= '9999-12-31'
          AND mu.userID IS NULL # doesn't already exist in the upload table
    ORDER BY hpp.modifyDateTime DESC # newest first
;
SELECT '************************************* new tmp_marketo_leads - insight-trial rows: ', ROW_COUNT(), NOW();
SELECT COUNT(1) FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp;


-- *********************************************************************************************************************
-- find and include the current customers with a basic or higher plan (including student)
-- *********************************************************************************************************************
REPLACE INTO rpt_workspace.jmarzinke_marketo_lead_seed_temp
(
    insertSource,
	userID,
	paymentProfileID,
	isTrialRestart,
	trialModifyDateTime
)
SELECT  
    'insight-customer' AS insertSource,
	pp.ownerID AS userID,						  				
	pp.paymentProfileID AS paymentProfileID,						  				
	0 AS isTrialRestart, 
	NULL AS trialModifyDateTime
FROM ss_core_02.hist_paymentProfile pp 
LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON mu.paymentProfileID = pp.paymentProfileID
WHERE (pp.modifyDateTime >= @marketoLookbackDateTime) -- replication may be behind so look back extra
	AND pp.hist_effectiveThruDateTime >= '9999-12-31'
	AND pp.productID >= 3 		-- basic or higher (paid product plus student)
	AND pp.accountType != 3		-- not an org accountType
	AND pp.ownerID >= 1000000  	-- the starting range of the real records
	AND mu.paymentProfileID IS NULL  -- doesn't already exist in the upload table
;
SELECT '************************************* tmp_marketo_leads - paying customers from hist_paymentProfile rows: ', ROW_COUNT(), NOW();
SELECT COUNT(1) FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp;




-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------
-- twj - new processing of all users without payment profiles

-- *********************************************************************************************************************
-- Updated 2016-01-12
-- Inserting all other new users from userAccount
-- Includes a 24 hour pad in case replication is having issues
-- *********************************************************************************************************************
INSERT IGNORE INTO rpt_workspace.jmarzinke_marketo_lead_seed_temp
(
    insertSource,
    userID,
    paymentProfileID,
    isTrialRestart,
    trialModifyDateTime
)
SELECT
    'insight-user' AS insertSource,
    ua.userID,
    pp.paymentProfileID,
    0 AS isTrialRestart,
    NULL AS trialModifyDateTime
FROM ss_core_02.userAccount ua
LEFT OUTER JOIN ss_core_02.paymentProfile pp ON ua.userID = pp.ownerID AND pp.accountType != 3
LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON ua.userID = mu.userID
WHERE
    ua.insertDateTime >= @marketoLookbackDateTime AND
    mu.userID IS NULL
;
SELECT '************************************* tmp_marketo_leads - inserting insight-user rows: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- Added 2016-12-29
-- Prevent low-value leads from getting into Marketo. These are users who have:
--   1. Never logged in
--   2. Been inserted by a different user from a free plan (Cancelled, Trial, Free, Student)
-- This should also help with preventing phished users from clogging up the Marketo database
-- *********************************************************************************************************************
DELETE tml FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN ss_core_02.userAccount ua ON tml.userID = ua.userID AND ua.insertByUserID != 0
    LEFT JOIN ss_core_02.paymentProfile pp ON ua.insertByUserID = pp.ownerID AND pp.accountType != 3
    LEFT JOIN ss_core_02.sessionLog sl ON tml.userID = sl.userID AND sl.loginType NOT IN (11, 34) AND sl.loginAuthResult = 1
WHERE
    COALESCE(pp.productID, 0) IN (0, 1, 2, 9)    -- Free plans, including Student. Use coalesce to treat collab (no PP) as free plan.
    AND sl.sessionLogID IS NULL     -- Never logged in
;
SELECT '************************************* tmp_marketo_leads - deleting low-value user rows: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- Added 2015-12-30
-- Inserting users who have logged in recently but are not in the upload table already
-- This backfills active collaborators
-- *********************************************************************************************************************
SELECT MAX(sessionLogID)
FROM ss_core_02.sessionLog
INTO @max_sscore_slSessionLogID;

INSERT IGNORE INTO rpt_workspace.jmarzinke_marketo_lead_seed_temp
(
    insertSource,
    userID,
    paymentProfileID,
    isTrialRestart,
    trialModifyDateTime
)
SELECT DISTINCT
    'insight-active' AS insertSource,
    ua.userID,
    pp.paymentProfileID,
    0 AS isTrialRestart,
    NULL AS trialModifyDateTime
FROM ss_core_02.userAccount ua
LEFT OUTER JOIN ss_core_02.paymentProfile pp ON ua.userID = pp.ownerID AND pp.accountType != 3
LEFT OUTER JOIN ss_core_02.sessionLog sl ON ua.userID = sl.userID AND sl.loginAuthResult = 1 AND sl.loginType != 11 -- Include successful logins but exclude 'Update Request' logins.
LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON ua.userID = mu.userID
WHERE
    ua.userID >= 1000001 AND  -- first valid userID
    sl.sessionLogID >= (@max_sscore_slSessionLogID - 750000) AND  -- This looks back approximately 24 hours
    mu.userID IS NULL
;
SELECT '************************************* tmp_marketo_leads - inserting insight-active rows: ', ROW_COUNT(), NOW();


-- Inserting into rpt_workspace.jmarzinke_marketo_lead_seed_temp all users already in arc_marketo_upload w/o a paymentProfileID that now have one
INSERT IGNORE INTO rpt_workspace.jmarzinke_marketo_lead_seed_temp
SELECT mk_upload.* 
FROM rpt_workspace.jmarzinke_marketo_lead_seed mk_upload
JOIN ss_core_02.paymentProfile pp ON mk_upload.userID = pp.ownerID AND pp.accountType != 3 AND (pp.modifyDateTime >= @marketoLookbackDateTime) -- replication may be behind so look back extra
WHERE mk_upload.paymentProfileID IS NULL
;
SELECT '************************************* tmp_marketo_leads - inserting -newPP rows: ', ROW_COUNT(), NOW();


# *********************************************************************************************************************
# Added 2017-06-01
# Remove leads that come from temporary email address domains. We never want these in Marketo.
# However, if the user changes their email to a permanent one, they will come in with their next login.
# This is hardcoded for now, but will be developed properly in Yoda.
# See MKTO4285 for details.
# *********************************************************************************************************************
DELETE tml FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    INNER JOIN ss_core_02.userAccount ua ON tml.userID = ua.userID
WHERE
    rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) COLLATE utf8mb4_unicode_520_ci IN (
        'mvrht.com', 'mvrht.net', 'tipsb.com', 'sharklasers.com',
        'guerillamail.info', 'grr.la', 'guerrillamail.biz',
        'guerrillamail.com', 'guerrillamail.de',
        'guerrillamail.net', 'guerrillamail.org',
        'guerrillamailblock.com', 'pokemail.net', 'spam4.me',
        'yopmail.com', 'mailinator.com', 'airtable.com'
    )
;
SELECT '************************************* tmp_marketo_leads - deleting temporary email user rows: ', ROW_COUNT(), NOW();



-- debug OLD
-- SHOW VARIABLES LIKE 'tx_isolation'
-- ;
-- EXPLAIN UPDATE tmp_marketo_leads tml
-- JOIN ss_core_02.hist_paymentProfile pp ON tml.userID = pp.ownerID AND pp.accountType != 3 AND (pp.modifyDateTime >= @marketoLookbackDateTime) -- replication may be behind so look back extra
-- SET tml.paymentProfileID = pp.paymentProfileID,
-- 	tml.insertSource = CONCAT(tml.insertSource, '-newPP')
-- WHERE tml.paymentProfileID IS NULL
-- ;
-- SHOW FULL PROCESSLIST
-- ;

-- fill in new payment profile information
-- *********************************************************************************************************************
-- BEGIN hist_paymentProfile updates for leadflow.arc_marketo_upload (updated 2015-10-27)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to tmp_marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query #1: Retrieve changes made to hist_paymentProfile records
DROP TABLE IF EXISTS tmp_hist_paymentProfile_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_hist_paymentProfile_to_sync
(INDEX (ownerID))
	SELECT pp.ownerID, pp.paymentProfileID FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
	JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON tml.userID = mu.userID  -- 2015-11-12 FIX: Need to join mu in order for the WHERE clause to be effective
	JOIN ss_core_02.paymentProfile pp ON tml.userID = pp.ownerID AND pp.accountType != 3 AND (pp.modifyDateTime >= @marketoLookbackDateTime) -- replication may be behind so look back extra
	WHERE mu.paymentProfileID IS NULL
;
SELECT '************************************* tmp_marketo_leads - getting -newPP rows: ', ROW_COUNT(), NOW();

-- Query #2: Update tmp_marketo_leads with changes that will be added to arc_marketo_upload later
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN tmp_hist_paymentProfile_to_sync pp ON tml.userID = pp.ownerID
SET
	tml.paymentProfileID = pp.paymentProfileID,
	tml.insertSource = CONCAT(tml.insertSource, '-newPP')
;
SELECT '************************************* tmp_marketo_leads - updating -newPP rows: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- FINISH hist_paymentProfile updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************



-- Set Signup ID
-- 2016-12-21 - Moved up in the script as it is neede for amplified trial signup
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
SET signupRequestID =
(
    SELECT sr.signupRequestID
    FROM ss_account_02.signupRequest sr USE INDEX(signupRequest_idx1)
    WHERE sr.userID = tml.userID
    ORDER BY sr.resultStatus, sr.signupRequestID ASC  -- take the first valid signup if it exists
    LIMIT 1
)
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupRequestID rows: ', ROW_COUNT(), NOW();

-- 2016-12-21 - Create temporary table of all new lead signup request info
-- so we don't have to touch the core table multiple times
DROP TABLE IF EXISTS tmp_new_lead_signup_info;
CREATE TABLE IF NOT EXISTS tmp_new_lead_signup_info LIKE ss_account_02.signupRequestTrackingItem;
INSERT INTO tmp_new_lead_signup_info
    SELECT sr.*
    FROM ss_account_02.signupRequestTrackingItem sr
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON sr.signupRequestID = tml.signupRequestID
;

ANALYZE TABLE tmp_new_lead_signup_info;

-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------

-- *********************************************************************************************************************
-- BEGIN userAccount updates for leadflow.arc_marketo_upload (updated 2015-12-03)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to tmp_marketo_leads and execute updates
-- *********************************************************************************************************************
-- Query #1: Retrieve userAccount records
DROP TABLE IF EXISTS tmp_userAccount_info_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_userAccount_info_to_sync
(INDEX (userID))
    SELECT
        tml.userID,
        ua.modifyDateTime,
        ua.firstName,
        ua.lastName,
        ua.emailAddress,
        ua.newsFlags,
        ua.statusFlags,
        ua.locale,
        ua.timeZone,
        ua.insertByUserID
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
        LEFT OUTER JOIN ss_core_02.userAccount ua ON tml.userID = ua.userID
    WHERE tml.insertSource != 'leadSeed'
;
SELECT '************************************* temp tmp_marketo_leads - updating userAccount info: ', ROW_COUNT(), NOW();

-- Query #2: Update tmp_marketo_leads with changes that will be added to arc_marketo_upload later
-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_userAccount_info_to_sync ua ON tml.userID = ua.userID
    LEFT JOIN tmp_new_lead_signup_info srfn ON tml.signupRequestID = srfn.signupRequestID AND srfn.itemName = 'su_fname'
    LEFT JOIN tmp_new_lead_signup_info srln ON tml.signupRequestID = srln.signupRequestID AND srln.itemName = 'su_lname'
SET
    tml.userAccountModifyDateTime = ua.modifyDateTime,
    tml.firstName                 = COALESCE(ua.firstName, srfn.itemValue),
    tml.lastName                  = COALESCE(rpt_main_02.MARKETO_LAST_NAME(ua.lastName), rpt_main_02.MARKETO_LAST_NAME(srln.itemValue)),
    tml.emailAddress              = ua.emailAddress,
    tml.emailDomain               = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
    tml.website                   = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
    tml.newsFlags                 = ua.newsFlags,
    tml.statusFlags               = ua.statusFlags,
    tml.isUserAgreementAccepted   = CASE WHEN ua.statusFlags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in statusFlags bitmask, which is 1000 in binary (8 in decimal)
    tml.locale                    = ua.locale,
    tml.timeZone                  = ua.timeZone,
    tml.appOptOut                 = NOT (ua.newsFlags & 1),
    tml.userAccountInsertByUserID = ua.insertByUserID
;
-- ORIGINAL
-- UPDATE tmp_marketo_leads tml
--     JOIN tmp_userAccount_info_to_sync ua ON tml.userID = ua.userID
-- SET
--     tml.userAccountModifyDateTime = ua.modifyDateTime,
--     tml.firstName = ua.firstName,
--     tml.lastName = rpt_main_02.MARKETO_LAST_NAME(ua.lastName),
--     tml.emailAddress = ua.emailAddress,
--     tml.emailDomain = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
--     tml.website = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
--     tml.newsFlags = ua.newsFlags,
--     tml.statusFlags = ua.statusFlags,
--     tml.isUserAgreementAccepted = CASE WHEN ua.statusFlags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in statusFlags bitmask, which is 1000 in binary (8 in decimal)
--     tml.locale = ua.locale,
--     tml.timeZone = ua.timeZone,
--     tml.appOptOut = NOT(ua.newsFlags & 1),
--     tml.userAccountInsertByUserID = ua.insertByUserID
-- ;
SELECT '************************************* update tmp_marketo_leads - updating userAccount info: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- FINISH userAccount updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp_first_shared;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_first_shared
(INDEX (userID))
    SELECT
        gridAccessMap.userID,
        MIN(gridAccessMap.insertDateTime) AS firstSharedToDate
    FROM ss_core_02.gridAccessMap
        -- need to join back to tmp_marketo_leads table so we don't process the whole gridAccessMap table each time
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID = gridAccessMap.userID
    WHERE gridAccessMap.userID <> gridAccessMap.insertByUserID
    GROUP BY userID
;

-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT OUTER JOIN ss_core_02.paymentProfile pp ON tml.paymentProfileID = pp.paymentProfileID
    LEFT OUTER JOIN tmp_first_shared gam ON tml.userID = gam.userID
#     LEFT OUTER JOIN
#     (
#         SELECT
#             gridAccessMap.userID,
#             MIN(gridAccessMap.insertDateTime) AS firstSharedToDate
#         FROM ss_core_02.gridAccessMap
#             -- need to join back to tmp_marketo_leads table so we don't process the whole gridAccessMap table each time
#             JOIN tmp_marketo_leads ON tmp_marketo_leads.userID = gridAccessMap.userID
#         WHERE gridAccessMap.userID <> gridAccessMap.insertByUserID
#         GROUP BY userID
#     ) gam
#         ON gam.userId = tml.userId
    LEFT OUTER JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_phone'
SET
    tml.ppModifyDatetime        = pp.modifyDatetime,
    tml.parentPaymentProfileID  = pp.parentPaymentProfileID,
    tml.productName             = rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID),
    tml.userLimit               = pp.userLimit,
    tml.paymentStartDateTime    = pp.paymentStartDateTime,
    tml.nextPaymentDate         = pp.nextPaymentDate,
    tml.paymentType             = leadflow.SMARTSHEET_PAYMENTTYPE(pp.paymentType),
    tml.paymentTerm             = pp.paymentTerm,
    tml.currencyCode            = pp.currencyCode,
    tml.teamTrial               = CASE WHEN pp.accountType = 2 AND pp.productID = 1 THEN 1 ELSE 0 END,
    tml.trialStartDateTime      = CASE
                                      WHEN pp.productID = 1 THEN pp.paymentStartDateTime -- 1=in trial
                                      ELSE NULL
                                  END,
    tml.primaryContactPhone     = COALESCE(pp.primaryContactPhone, sr.itemValue), -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    tml.billToAddress           = rpt_main_02.MARKETO_BILLING_ADDRESS(pp.billToAddress1, pp.billToAddress2), -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    tml.billToCity              = pp.billToCity, -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    tml.billToRegionCode        = pp.billToRegionCode, -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    tml.billToPostCode          = pp.billToPostCode, -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    tml.billToCountryCode       = pp.billToCountryCode, -- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
    --  only set true if in trial now
    tml.wasSharedToPriorToTrial = CASE WHEN pp.productID = 1 AND pp.insertDateTime >= gam.firstSharedToDate THEN 1 ELSE 0 END
WHERE insertSource != 'leadSeed'
;
-- ORIGINAL
-- UPDATE tmp_marketo_leads tml
--     LEFT OUTER JOIN ss_core_02.paymentProfile pp ON tml.paymentProfileID = pp.paymentProfileID
--     LEFT OUTER JOIN
--     (
--         SELECT
--             gridAccessMap.userID,
--             MIN(gridAccessMap.insertDateTime) AS firstSharedToDate
--         FROM ss_core_02.gridAccessMap
--             -- need to join back to tmp_marketo_leads table so we don't process the whole gridAccessMap table each time
--             JOIN tmp_marketo_leads ON tmp_marketo_leads.userID = gridAccessMap.userID
--         WHERE gridAccessMap.userID <> gridAccessMap.insertByUserID
--         GROUP BY userID
--     ) gam
--         ON gam.userId = tml.userId
-- SET
--     tml.ppModifyDatetime = pp.modifyDatetime,
--     tml.parentPaymentProfileID = pp.parentPaymentProfileID,
--     tml.productName = rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID),
--     tml.userLimit = pp.userLimit,
--     tml.paymentStartDateTime = pp.paymentStartDateTime,
--     tml.nextPaymentDate = pp.nextPaymentDate,
--     tml.paymentTerm = pp.paymentTerm,
--     tml.currencyCode = pp.currencyCode,
--     tml.teamTrial = CASE WHEN pp.accountType = 2 AND pp.productID = 1 THEN 1 ELSE 0 END,
--     tml.trialStartDateTime =
--     CASE
--     WHEN pp.productID = 1  THEN pp.paymentStartDateTime  -- 1=in trial
--     ELSE NULL
--     END,
--     tml.primaryContactPhone = pp.primaryContactPhone,  	-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     tml.billToAddress = rpt_main_02.MARKETO_BILLING_ADDRESS(pp.billToAddress1, pp.billToAddress2), 	-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     tml.billToCity = pp.billToCity,		-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     tml.billToRegionCode = pp.billToRegionCode,		-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     tml.billToPostCode = pp.billToPostCode,		-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     tml.billToCountryCode = pp.billToCountryCode,	-- code handling paymentProfile updates below will pull from from parentPaymentProfiles for owners
--     --  only set true if in trial now 
--     tml.wasSharedToPriorToTrial = CASE WHEN pp.productID = 1 AND  pp.insertDateTime >= gam.firstSharedToDate THEN 1 ELSE 0 END
-- WHERE insertSource != 'leadSeed'
-- ;
SELECT '************************************* tmp_marketo_leads - updating paymentProfile info: ', ROW_COUNT(), NOW();


-- update fields from parent
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_core_02.paymentProfile pp ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN ss_core_02.paymentProfile parentPP ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.parentPaymentProfileID = parentPP.paymentProfileID
SET
    rpt_workspace.jmarzinke_marketo_lead_seed_temp.trialEndDateDateTime =
        CASE
            -- get the end date from the paymentProfile, but it will be null if it is a team trial, if so, get it from the parent
            WHEN pp.productID = 1  THEN COALESCE(pp.paymentEndDateTime, parentPP.paymentEndDateTime)  -- 1=in trial,
            ELSE trialEndDateDateTime 						-- don't over write, this will stay the end date time of last trial
        END,
    -- get the date from the parent, will be null if no parent
    rpt_workspace.jmarzinke_marketo_lead_seed_temp.parentPaymentStartDateTime = parentPP.paymentStartDateTime,
    rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentStartDateTime =
        CASE
            WHEN
                pp.accountType = 2 AND
                pp.productID = 7 AND
                pp.paymentStartDateTime < COALESCE(parentPP.paymentStartDateTime, '')
            THEN parentPP.paymentStartDateTime
            ELSE rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentStartDateTime
        END
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* trialEndDateDateTime rows: ', ROW_COUNT(), NOW();


UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
LEFT OUTER JOIN ss_core_02.paymentProfile parentPP ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.parentPaymentProfileID = parentPP.paymentProfileID
LEFT OUTER JOIN ss_core_02.organization ON parentPP.ownerID = organization.organizationID AND parentPP.accountType = 3
LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON parentPP.currencyCode = hce.currencyCode
			AND parentPP.paymentStartDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
SET organizationName = organization.name,
    rpt_workspace.jmarzinke_marketo_lead_seed_temp.organizationID = organization.organizationID,
	accountRole = 
		CASE
			WHEN rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentProfileID IS NOT NULL AND parentPP.paymentProfileID IS NULL THEN 'Individual'  -- this is the user not part of a multi-user plan
            WHEN rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentProfileID IS NULL AND parentPP.paymentProfileID IS NULL THEN NULL  -- this is for users with no payment profile
			WHEN organization.mainContactUserID = rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID THEN 'Owner'  -- this is the user who created the organization and team trial
			ELSE 'Member'																-- this is the user added to the team trial
		END,
	rpt_workspace.jmarzinke_marketo_lead_seed_temp.planRate =
		CASE 
			WHEN  parentPP.paymentProfileID IS NULL THEN rpt_workspace.jmarzinke_marketo_lead_seed_temp.planRate  -- no parent, so keep the existing value
			WHEN organization.mainContactUserID = rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID THEN parentPP.planRate  -- use the planRate from the org for the owner
			ELSE rpt_workspace.jmarzinke_marketo_lead_seed_temp.planRate 											-- members don't pay, keep existing value
		END,	
	monthlyPlanRate_USD =
		CASE 
			WHEN  parentPP.paymentProfileID IS NULL THEN monthlyPlanRate_USD  -- no parent, so keep the existing value
            WHEN organization.mainContactUserID = rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID AND parentPP.paymentTerm != 0 THEN  -- use the planRate from the org for the owner
				CASE 
					WHEN parentPP.currencyCode = 'USD' 
					THEN parentPP.planRate/parentPP.paymentTerm 
					ELSE (parentPP.planRate/hce.exchangeRate)/parentPP.paymentTerm
				END
			ELSE monthlyPlanRate_USD										-- members don't pay, keep existing value
		END
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* organizationName, accountRole, parent payment values rows: ', ROW_COUNT(), NOW();


UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN (
    SELECT
        mu.userID,
        -- Triple nested function: 1. Get max product by rank, 2. convert rank back to productID, 3. convert productID to product name.
        rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_main_02.SMARTSHEET_PRODUCTRANKCONVERT(MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(ppp.productID)))) maxOrgProduct
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp mu
    LEFT JOIN ss_core_02.organizationUserRole our ON mu.userID = our.userID AND our.state != 3              -- Ignore declined users
    LEFT JOIN ss_core_02.organization org ON our.organizationID = org.organizationID AND org.state = 1      -- Include only active orgs
    LEFT JOIN ss_core_02.paymentProfile ppp ON our.organizationID = ppp.ownerID AND ppp.accountType = 3     -- Just want org accounts
    GROUP BY mu.userID
) mp ON tml.userID = mp.userID
SET
    tml.orgProductName = mp.maxOrgProduct
WHERE tml.insertSource != 'leadSeed'
;
SELECT '************************************* orgProductName rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- Updated 2016-06-23
-- *********************************************************************************************************************
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN (
    SELECT
        tml.userID,
        IFNULL(ppp.userLimit, 0) paidLicenseLimit,
        IFNULL(ppp.bonusUserCount, 0) bonusLicenseLimit,
        IFNULL(SUM(our.state = 1), 0) assignedLicenseCount,
        IFNULL(SUM(our.state = 2), 0) pendingLicenseCount
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN (
        SELECT our1.userID, our1.organizationID
        FROM ss_core_02.organizationUserRole our1
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON our1.userID = tml.userID
        WHERE
            our1.role = 'USER_ADMIN'
            AND our1.state = 1
        UNION
        SELECT org.mainContactUserID, org.organizationID
        FROM ss_core_02.organization org
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON org.mainContactUserID = tml.userID
        WHERE org.state = 1
    ) uid ON tml.userID = uid.userID
    LEFT JOIN ss_core_02.paymentProfile ppp ON
        uid.organizationID = ppp.ownerID
        AND ppp.accountType = 3
    LEFT JOIN ss_core_02.organizationUserRole our ON
        uid.organizationID = our.organizationID
        AND our.role = 'LICENSE_USER'
        AND our.state IN (1, 2)
    GROUP BY uid.userID, uid.organizationID
) lic ON tml.userID = lic.userID
SET
    tml.userLimit = lic.paidLicenseLimit,
    tml.bonusLicenseLimit = lic.bonusLicenseLimit,
    tml.assignedLicenseCount = lic.assignedLicenseCount,
    tml.pendingLicenseCount = lic.pendingLicenseCount
WHERE tml.insertSource != 'leadSeed'
;
SELECT '************************************* licenseLimit rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update organization license tags
-- Updated 2016-07-05
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_tml_lic_tag_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_tml_lic_tag_updates
(INDEX (userID))
    SELECT
        lic.userID,
        leadflow.MARKETO_LICENSE_TAG(lic.assignedLicenseCount, lic.pendingLicenseCount, lic.paidLicenseLimit,
                                     tml.previousUserLimit, COUNT(our.organizationUserRoleID)) licenseTags
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
        JOIN (
                 SELECT
                     our1.userID,
                     our1.organizationID,
                     tml.assignedLicenseCount,
                     tml.pendingLicenseCount,
                     tml.userLimit paidLicenseLimit
                 FROM ss_core_02.organizationUserRole our1
                     JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON our1.userID = tml.userID
                 WHERE
                     our1.role = 'USER_ADMIN'
                     AND our1.state = 1
                 UNION
                 SELECT
                     org.mainContactUserID,
                     org.organizationID,
                     tml.assignedLicenseCount,
                     tml.pendingLicenseCount,
                     tml.userLimit
                 FROM ss_core_02.organization org
                     JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON org.mainContactUserID = tml.userID
                 WHERE org.state = 1
             ) lic ON tml.userID = lic.userID
        LEFT JOIN ss_core_02.organizationUserRole our
            ON lic.organizationID = our.organizationID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insertDateTime >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY lic.userID, lic.organizationID
;
SELECT '************************************* getting licenseTag rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_tml_lic_tag_updates tag ON tml.userID = tag.userID
SET tml.licenseTags = tag.licenseTags
WHERE tml.insertSource != 'leadSeed'
;
SELECT '************************************* updating licenseTag rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update organization roles
-- Added 2017-01-10
-- *********************************************************************************************************************
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN (
             SELECT
                 tml.userID,
                 COALESCE(our.organizationID, org.organizationID) organizationID,
                 CONCAT_WS(';',
                           GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                           CASE
                           WHEN org.mainContactUserID IS NOT NULL
                               THEN 'MAIN_CONTACT'
                           ELSE NULL
                           END) AS newOrgRoles
             FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
                 LEFT JOIN ss_core_02.organizationUserRole our ON tml.userID = our.userID
                 LEFT JOIN ss_core_02.organization org ON tml.userID = org.mainContactUserID AND org.state = 1
             WHERE COALESCE(our.organizationID, org.organizationID) IS NOT NULL
             GROUP BY tml.userID
         ) orgRole ON tml.userID = orgRole.userID
SET
    tml.organizationRoles = orgRole.newOrgRoles
WHERE
    COALESCE(orgRole.organizationID, 0) != 1030645 -- Exclude GE. Their org roles are updated below.
;
SELECT '************************************* organizationRoles rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN (
             SELECT
                 our.userID,
                 CONCAT_WS(';',
                           GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                           CASE WHEN org.mainContactUserID IS NOT NULL
                               THEN 'MAIN_CONTACT'
                           ELSE NULL END,
                           CONCAT('LICENSE_ADDED_BY:', COALESCE(our2.insertByUserID, 0))) AS newOrgRoles
             FROM ss_core_02.organizationUserRole our
                 JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON our.userID = tml.userID AND our.organizationID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
                 LEFT JOIN ss_core_02.organizationUserRole our2 ON our.userID = our2.userID AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insertByUserID to be specifically from the LICENSE_USER role
                 LEFT JOIN ss_core_02.organization org ON tml.userID = org.mainContactUserID AND org.state = 1
             GROUP BY our.userID
             ORDER BY our.userID ASC
         ) orgRole ON tml.userID = orgRole.userID
SET
    tml.organizationRoles = orgRole.newOrgRoles
;
SELECT '************************************* GE organizationRoles rows: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- BEGIN usedGoogleAuthentication updates for leadflow.arc_marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to tmp_marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query #1: Retrieve changes made to openIDIdentifier records
DROP TABLE IF EXISTS tmp_openIDIdentifiers_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_openIDIdentifiers_to_sync
(INDEX (userID))
	SELECT goog.userID FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
	LEFT OUTER JOIN ss_core_02.openIDIdentifier goog ON tml.userId = goog.userID
	WHERE insertSource != 'leadSeed' AND provider IN ('GoogleApps', 'GoogleOAuth2')
;
SELECT '************************************* tmp_marketo_leads - getting usedGoogleAuthentication info: ', ROW_COUNT(), NOW();

-- Query #2: Update tmp_marketo_leads with changes that will be added to arc_marketo_upload later
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN tmp_openIDIdentifiers_to_sync goog ON tml.userId = goog.userID
SET tml.usedGoogleAuthentication = CASE WHEN goog.userID IS NULL THEN 0 ELSE 1 END
;
SELECT '************************************* tmp_marketo_leads - updating usedGoogleAuthentication info: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- FINISH usedGoogleAuthentication updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************


-- Signup Tracking Info --------------------------------------------------------------------

# 2017-09-12 Add signupLandingPage data for new leads
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND itemName = 'slp' AND itemValue != ''
SET tml.signupLandingPage = sr.itemValue;
SELECT '************************************* signupLandingPage rows: ', ROW_COUNT(), NOW();

-- 2016-12-21 - Added to account for amplified trial signup
-- Capture Optimizely Experiment and Variation IDs
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND itemName = 'optimizelyBuckets'
SET tml.optimizelyBuckets = CASE WHEN sr.itemValue != '{}' THEN REPLACE(REPLACE(REPLACE(REPLACE(sr.itemValue,'"',''),',',';'),'{',''),'}','') END
;
SELECT '************************************* signupTracking_optimizely_code rows: ', ROW_COUNT(), NOW();

-- 2016-12-27 - Added to account for amplified trial signup
-- Capture Optimizely Experiment and Variation IDs in the ABTests field
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT JOIN (SELECT
                   ssev.userID,
                   GROUP_CONCAT(
                       DISTINCT siteSettingElementName, ':', FLOOR(valueNumeric) ORDER BY siteSettingElementValueID ASC
                       SEPARATOR ';') AS NewABTestValue
               FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
                   JOIN ss_account_02.siteSettingElementValue ssev ON tml.userID = ssev.userID
               WHERE ssev.siteSettingElementName LIKE 'SS_ABTEST%'
               GROUP BY ssev.userID
              ) ab ON tml.userID = ab.userID
SET tml.ABTests =
    CASE
        WHEN ab.NewABTestValue IS NULL AND tml.optimizelyBuckets IS NULL THEN NULL
        ELSE CONCAT_WS(';', ab.NewABTestValue, tml.optimizelyBuckets)
    END
;
SELECT '************************************* ABTests rows: ', ROW_COUNT(), NOW();

-- Assign source
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = 's'
SET signupTracking_s_code = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupTracking_s_code rows: ', ROW_COUNT(), NOW();

-- Assign campaign
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = 'c'
SET signupTracking_c_code = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupTracking_c_code rows: ', ROW_COUNT(), NOW();

-- Assign segment
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = 'm'
SET signupTracking_m_code = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupTracking_m_code rows: ', ROW_COUNT(), NOW();

-- Assign keyword
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = 'k'
SET signupTrackingKeyword = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupTrackingKeyword rows: ', ROW_COUNT(), NOW();

-- Assign Marketo Tracking Cookie
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = '_mkto_trk'
SET marketoTrackingCookie = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* marketoTrackingCookie rows: ', ROW_COUNT(), NOW();

-- Assign App Launch Type
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
JOIN ss_account_02.signupRequestTrackingItem srti ON tml.signupRequestID = srti.signupRequestID AND srti.itemName = 'Type' AND srti.itemType = 2
SET signupTrackingAppLaunchType = srti.itemValue
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* signupTrackingAppLaunchType rows: ', ROW_COUNT(), NOW();


-- Inferred Viral
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
SET signupBucket = 'Inferred Viral'
WHERE signupTrackingAppLaunchType IN (2,6) -- grid or workspace sharing
	OR userAccountInsertByUserID != 0
;
SELECT '************************************* Inferred Viral rows: ', ROW_COUNT(), NOW();

-- Inferred Title (updated 2015-10-27)
-- Need to use STRAIGHT_JOIN in order to force join execution order. Without it, the query does
-- a full table scan of arc_lead411EmployeeConfidence first.
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT JOIN rpt_main_02.arc_lead411EmployeeConfidence2017 lec
        ON tml.emailAddress = lec.hypothesizedEmail AND lec.confidence != -1
    LEFT JOIN rpt_main_02.arc_lead411Employees201703 le ON lec.personID = le.personID
    LEFT JOIN rpt_main_02.arc_lead411EmployeeConfidence lec2
        ON tml.emailAddress = lec2.hypothesizedEmail AND lec2.confidence != -1
    LEFT JOIN rpt_main_02.arc_lead411Employees le2 ON lec2.personID = le2.personID
SET tml.inferredTitle = COALESCE(le.jobTitle, le2.jobTitle)
;
SELECT '************************************* Inferred Title rows: ', ROW_COUNT(), NOW();

-- 2016-12-21 - Added to account for amplified trial signup
-- Overwrite inferredTitle with signup title if there's a value
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT OUTER JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_title'
SET tml.inferredTitle = COALESCE(sr.itemValue, tml.inferredTitle)
;
SELECT '************************************* Signup Title rows: ', ROW_COUNT(), NOW();


-- 2016-12-21 - Added inferred role to account for amplified trial signup
-- This is too complicated to do in the nightly query.
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT OUTER JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_role'
SET tml.inferredRole = COALESCE(
    CASE
        WHEN sr.itemValue IS NOT NULL THEN CONCAT('signupRole:', sr.itemValue)
        ELSE NULL
    END,
    tml.inferredRole) -- Just in case theres an existing value and there's no signup role, don't overwrite it.
;

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
SET containerCount =
(
    SELECT COUNT(*)
    FROM ss_core_02.container
    WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID = container.insertByUserID
          AND container.containerType = 2
          AND container.deleteStatus = 0
          AND container.paymentProfileID = rpt_workspace.jmarzinke_marketo_lead_seed_temp.paymentProfileID  -- paymentProfileID for its index
)
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* containerCount rows: ', ROW_COUNT(), NOW();


UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
SET
    tml.insertDateTime = CURRENT_TIMESTAMP(),
    tml.updateDateTime = CURRENT_TIMESTAMP(),
    tml.pushToMarketo  = @insertPriority
WHERE insertSource != 'leadSeed'
;
SELECT '************************************* tmp_marketo_leads - insertDateTime info: ', ROW_COUNT(), NOW();

-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------




-- Update misc. fields on the temp table before transferring to upload table

-- Set Org domain flag
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
    LEFT OUTER JOIN rpt_main_02.arc_ISPDomains d
        ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain = d.domain
SET isOrgDomain = CASE WHEN d.domain IS NULL THEN 1 ELSE 0 END
;
SELECT '************************************* isOrgDomain rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update userTags for all users.
-- Added 2016-08-11
-- 'insertedByOutDomain' = a user who was inserted by a non-ISP domain user with a different domain
-- 'insertedByInDomain'  = a user who was inserted by a non-ISP domain user with the same domain
-- 'insertedByISPDomain' = a user who was inserted by an ISP domain user
-- 'insertedBySelf'      = a user who created their own account
-- *********************************************************************************************************************
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN ss_core_02.userAccount ua ON tml.userID = ua.userID
    LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON tml.userID = mu.userID
    -- Join on userAccount to ensure we find a record. Lead might not be in our sync table.
    LEFT OUTER JOIN ss_core_02.userAccount uai ON ua.insertByUserID = uai.userID
    -- See if it's an ISP domain
    LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(uai.emailAddress) = isp.domain
    LEFT OUTER JOIN tmp_new_lead_signup_info src ON tml.signupRequestID = src.signupRequestID AND src.itemName = 'su_contactme'
    LEFT OUTER JOIN tmp_new_lead_signup_info sre ON tml.signupRequestID = sre.signupRequestID AND sre.itemName = 'signupEmail'
SET
    tml.userTags = leadflow.MARKETO_IMPORT_MS_PROJECT(
        leadflow.MARKETO_USER_TAG(
            CASE
            WHEN isp.domain IS NULL AND ua.insertByUserID != 0
                THEN 1
            WHEN isp.domain IS NOT NULL AND ua.insertByUserID != 0
                THEN 0
            ELSE -1
            END,
            tml.emailDomain,
            COALESCE(rpt_main_02.MARKETO_EXTRACT_DOMAIN(uai.emailAddress), ''),
            src.itemValue,
            sre.itemValue
        ), mu.clickedImportProjectCount);
SELECT '************************************* userTags rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- BEGIN googleAppsDomain updates for leadflow.arc_marketo_upload (updated 2015-12-11)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core/rpt_main tables and put it in a temporary table.
--     Query #2: Join temp table to tmp_marketo_leads and execute updates
-- *********************************************************************************************************************
-- Query #1: Retrieve changes made to rpt_domainRollup records
DROP TABLE IF EXISTS tmp_rpt_domainRollup_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_domainRollup_to_sync
(INDEX (userID))
    SELECT
        tml.userID,
        dr.googleAppsDomain
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
        LEFT OUTER JOIN rpt_main_02.rpt_domainRollup dr ON tml.emailDomain = dr.domain
    WHERE tml.isOrgDomain = 1
;
SELECT '************************************* temp isGoogleAppsInstalledDomain rows: ', ROW_COUNT(), NOW();

-- Query #2: Update tmp_marketo_leads with changes that will be added to arc_marketo_upload later
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_rpt_domainRollup_to_sync dr ON tml.userID = dr.userID
SET tml.isGoogleAppsInstalledDomain = dr.googleAppsDomain
;
SELECT '************************************* update isGoogleAppsInstalledDomain rows: ', ROW_COUNT(), NOW();
-- *********************************************************************************************************************
-- FINISH usedGoogleAuthentication updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************


-- update organization name and accountRole, and payment fields if owner
/* toddj - 2-2-2015 - commenting out, the fields set below are coming through LeadSeed.  The code below pulling
 * this data out of ss_core_02 is not necessary and won't work because the ss_core_02 is likely to be well behind when the lead comes through here.
 * 
UPDATE tmp_marketo_leads 
JOIN ss_core_02.paymentProfile pp on tmp_marketo_leads.paymentProfileId = pp.paymentProfileId
LEFT OUTER JOIN ss_core_02.paymentProfile parentPP ON tmp_marketo_leads.parentPaymentProfileID = parentPP.paymentProfileID
LEFT OUTER JOIN ss_core_02.organization ON parentPP.ownerID = organization.organizationID AND parentPP.accountType = 3
LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON parentPP.currencyCode = hce.currencyCode
			AND parentPP.paymentStartDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
SET organizationName = organization.name,
	accountRole = 
		CASE 
			WHEN  parentPP.paymentProfileID IS NULL THEN 'Individual'  -- this is the user who created the organization and team trial
			WHEN organization.mainContactUserID = tmp_marketo_leads.userID THEN 'Owner'  -- this is the user who created the organization and team trial
			ELSE 'Member'																-- this is the user added to the team trial
		END,
	tmp_marketo_leads.planRate =
		CASE 
			WHEN  parentPP.paymentProfileID IS NULL THEN tmp_marketo_leads.planRate  -- no parent, so keep the existing value
			WHEN organization.mainContactUserID = tmp_marketo_leads.userID THEN parentPP.planRate  -- use the planRate from the org for the owner
			ELSE tmp_marketo_leads.planRate 											-- members don't pay, keep existing value
		END,	
	monthlyPlanRate_USD =
		CASE 
			WHEN  parentPP.paymentProfileID IS NULL THEN monthlyPlanRate_USD  -- no parent, so keep the existing value
			WHEN organization.mainContactUserID = tmp_marketo_leads.userID THEN -- use the planRate from the org for the owner
				CASE 
					WHEN parentPP.currencyCode = 'USD' 
					THEN parentPP.planRate/parentPP.paymentTerm 
					ELSE (parentPP.planRate/hce.exchangeRate)/parentPP.paymentTerm
				END
			ELSE monthlyPlanRate_USD										-- members don't pay, keep existing value
		END
;  

SELECT '************************************* organizationName, accountRole, parent payment values rows: ', ROW_COUNT(), NOW();
*/


-- Set paid domain rollup info
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
    LEFT OUTER JOIN rpt_main_02.rpt_paidDomains ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain = rpt_paidDomains.mainContactDomain
SET domainsHighestPlan = rpt_paidDomains.MaxProduct
;
SELECT '************************************* domainsHighestPlan rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update domainOptOut for excluded domains and organizations
-- *********************************************************************************************************************
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT JOIN rpt_main_02.arc_domainEmailExclusion dee ON tml.emailDomain = dee.domain
    LEFT JOIN ss_core_02.organizationUserRole our ON tml.userID = our.userID AND our.role = 'MEMBER' AND our.state IN (1, 2)
    LEFT JOIN rpt_main_02.arc_organizationEmailExclusion oee ON our.organizationID = oee.organizationID
SET
    tml.domainOptOut = (COALESCE(dee.excludeFromMarketingEmail, 0) = 1 OR COALESCE(oee.excludeFromMarketingEmail, 0) = 1)
;
SELECT '************************************* domainOptOut rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update domainOptOut for collabs of excluded domains and organizations.
-- Added 2016-04-01
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_tml_collabs_opt_out;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_tml_collabs_opt_out
(INDEX (userID))
    SELECT tml2.userID, dee.excludeFromMarketingEmail FROM rpt_main_02.arc_domainEmailExclusion dee
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml USE INDEX (idx_emailDomain) ON dee.domain = tml.emailDomain
        JOIN ss_core_02.userAccount ua ON tml.userID = ua.insertByUserID  -- Get all collabs who were inserted by the excluded domain users
        LEFT JOIN rpt_main_02.arc_domainEmailExclusion dee2 ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = dee2.domain AND COALESCE(dee2.excludeFromMarketingEmail, 0) = 1  -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN rpt_main_02.arc_organizationEmailExclusion oee ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = tml.emailDomain AND COALESCE(oee.excludeFromMarketingEmail, 0) = 1
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml2 ON ua.userID = tml2.userID  -- Get all collabs in sync table to check if domainOptOut needs to be updated
    WHERE
        dee2.domain IS NULL  -- Only update collabs in domains that are NOT in the exclusion table
        AND oee.organizationID IS NULL
        AND dee.excludeFromMarketingEmail = 1
        AND dee.domain != 'smartsheet.com'
    UNION
    SELECT tml2.userID, oee.excludeFromMarketingEmail FROM ss_core_02.organizationUserRole our
        JOIN rpt_main_02.arc_organizationEmailExclusion oee ON our.organizationID = oee.organizationID AND oee.excludeFromMarketingEmail = 1 AND oee.organizationID != 1000008  -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml ON our.userID = tml.userID
        JOIN ss_core_02.userAccount ua ON tml.userID = ua.insertByUserID  -- Get all collabs who were inserted by the excluded users
        LEFT JOIN rpt_main_02.arc_organizationEmailExclusion oee2 ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = tml.emailDomain AND COALESCE(oee2.excludeFromMarketingEmail, 0) = 1  -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN rpt_main_02.arc_domainEmailExclusion dee ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = dee.domain AND COALESCE(dee.excludeFromMarketingEmail, 0) = 1
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed_temp tml2 ON ua.userID = tml2.userID  -- Get all collabs in sync table to check if domainOptOut needs to be updated
    WHERE
        oee2.organizationID IS NULL  -- Only update collabs in parent payment profile that are NOT in the exclusion table
        AND dee.domain IS NULL
        AND our.state IN (1, 2)
    GROUP BY tml2.userID
;
SELECT '************************************* collab domainOptOut rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN tmp_tml_collabs_opt_out coo ON tml.userID = coo.userID
SET
    tml.domainOptOut = coo.excludeFromMarketingEmail
;
SELECT '************************************* collab domainOptOut updates: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Set supplemental company data.
-- Updated 2016-06-01
-- *********************************************************************************************************************
-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT OUTER JOIN ss_sfdc_02.domain d ON tml.emailDomain = d.Domain_Name_URL__c
    LEFT OUTER JOIN ss_sfdc_02.account a ON d.Account__c = a.Id
    LEFT OUTER JOIN rpt_main_02.arc_lead411Companies201703 lc ON tml.emailDomain = lc.domain
    LEFT OUTER JOIN rpt_main_02.arc_lead411CompaniesV2 lc2 ON tml.emailDomain = lc2.domain
    LEFT OUTER JOIN rpt_main_02.arc_lead411Companies lc3 ON tml.emailDomain = lc3.domain
    LEFT OUTER JOIN tmp_new_lead_signup_info sr ON tml.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_company'
SET
    tml.company           = COALESCE(sr.itemValue, a.Name, lc.companyName, lc2.companyName, lc3.companyName, tml.emailDomain), -- use company name if found, otherwise just use the domain
    tml.numberOfEmployees = COALESCE(
        CASE
            WHEN lc.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '-', -1)), UNSIGNED)
            WHEN lc.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '<', -1)), UNSIGNED)
            WHEN lc.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '>', -1)), UNSIGNED)
            WHEN CONVERT(lc.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc.employeeRange, UNSIGNED)
            ELSE NULL
        END,
        CASE
            WHEN lc2.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '-', -1)), UNSIGNED)
            WHEN lc2.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '<', -1)), UNSIGNED)
            WHEN lc2.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '>', -1)), UNSIGNED)
            WHEN CONVERT(lc2.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc2.employeeRange, UNSIGNED)
            ELSE NULL
        END,
        CASE
            WHEN lc3.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '-', -1)), UNSIGNED)
            WHEN lc3.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '<', -1)), UNSIGNED)
            WHEN lc3.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '>', -1)), UNSIGNED)
            WHEN CONVERT(lc3.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc3.employeeRange, UNSIGNED)
            ELSE NULL
        END
    )
;
-- ORIGINAL
-- UPDATE tmp_marketo_leads tml
--     LEFT JOIN ss_sfdc_02.domain d ON tml.emailDomain = d.Domain_Name_URL__c
--     LEFT JOIN ss_sfdc_02.account a ON d.Account__c = a.Id
--     LEFT JOIN rpt_main_02.arc_lead411Companies lc ON tml.emailDomain = lc.domain
--     LEFT JOIN rpt_main_02.arc_lead411CompaniesV2 lc2 ON tml.emailDomain = lc2.domain
-- SET
--     tml.company           = COALESCE(a.Name, lc2.companyName, lc.companyName, tml.emailDomain), -- use company name if found, otherwise just use the domain
--     tml.numberOfEmployees = COALESCE(
--         CASE
--         WHEN lc2.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '-', -1)), UNSIGNED)
--         WHEN lc2.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '<', -1)), UNSIGNED)
--         WHEN lc2.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '>', -1)), UNSIGNED)
--         WHEN CONVERT(lc2.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc2.employeeRange, UNSIGNED)
--         ELSE NULL
--         END,
--         CASE
--         WHEN lc.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '-', -1)), UNSIGNED)
--         WHEN lc.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '<', -1)), UNSIGNED)
--         WHEN lc.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '>', -1)), UNSIGNED)
--         WHEN CONVERT(lc.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc.employeeRange, UNSIGNED)
--         ELSE NULL
--         END
--     )
-- ;
SELECT '************************************* supplemental data rows: ', ROW_COUNT(), NOW();

############################################################################################
# Set fitScore and fitRating for ONLY users who have had a trial
# Ignore zero second trials because these are from users who move directly to a paid plan
############################################################################################
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    JOIN ss_core_02.hist_paymentProfile hpp
         FORCE INDEX (hist_paymentProfile_idxPK)
        ON tml.paymentProfileID = hpp.paymentProfileID
           AND hpp.productID = 1
           AND hpp.modifyDateTime != hpp.hist_effectiveThruDateTime
    LEFT OUTER JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON tml.userID = mu.userID
SET tml.fitScore = COALESCE(mu.fitScore,
                            leadflow.getFitScoreV2(tml.isOrgDomain, tml.locale, tml.signupTracking_s_code, tml.signupTracking_c_code,
                                                   tml.signupTracking_m_code, tml.wasSharedToPriorToTrial,
                                                   IF(tml.userAccountInsertByUserID > 0, 1, 0), tml.signupTrackingAppLaunchType))
;

# UPDATE tmp_marketo_leads tml
# SET fitScore = getFitScoreV2(tml.isOrgDomain, tml.locale, tml.signupTracking_s_code, tml.signupTracking_c_code, tml.signupTracking_m_code,
#                              tml.wasSharedToPriorToTrial, IF(tml.userAccountInsertByUserID > 0, 1, 0), tml.signupTrackingAppLaunchType)
# ;

# Only set fitRating if fitScore is also set
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
SET fitRating = 
	CASE
		WHEN tml.fitScore >=50 THEN 'A' -- 5% likely to convert to paid plan
		WHEN tml.fitScore >=23 THEN 'B' -- 2.3% likely to convert to paid plan
		WHEN tml.fitScore >=10 THEN 'C' -- 1% likely to convert to paid plan
		ELSE 'D'
	END
WHERE tml.fitScore IS NOT NULL
;
SELECT '************************************* fitScore rows: ', ROW_COUNT(), NOW();


-- **************************************************************************************************************************
-- BEGIN Sales Rep Assignment
-- **************************************************************************************************************************
-- 2015-03-06 - toddj - this code below used to be in marketoLeadAssignment stored procedure
-- 2016-03-04 - jmarzinke - begin cleanup and documentation of sales assignment code


-- Pre-assign all leads with a payment profile to 'NeedsOwner' for later reassignment
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
SET salesforceOwnerAtImport = 'NeedsOwner'
WHERE paymentProfileID IS NOT NULL
;
SELECT '************************************* NeedsOwner rows: ', ROW_COUNT(), NOW();

-- Set lead source to 'Smartscored' for all Trial users with the following criteria
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
LEFT OUTER JOIN rpt_main_02.arc_doNotContactList ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailAddress = arc_doNotContactList.emailAddress
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain = isp.domain
SET salesforceLeadSource = 'Smartscored'
WHERE 
	rpt_workspace.jmarzinke_marketo_lead_seed_temp.productName = 'Trial'
	AND isp.domain IS NULL  -- Only smartscore non-ISP domains
	AND arc_doNotContactList.emailAddress IS NULL
	AND (rpt_workspace.jmarzinke_marketo_lead_seed_temp.locale LIKE 'en_%' OR SUBSTR(rpt_workspace.jmarzinke_marketo_lead_seed_temp.locale,4,6) IN ('SE', 'NO', 'NL', 'DK', 'FI'))  -- ('Sweden','Norway','Netherlands','Denmark','Finland')
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT IN ('smartsheet.com')  -- Don't smartscore Smartsheet employees
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE 'student.%'  -- Don't smartscore all students
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE 'students.%'
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE 'stud.%'
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE 'stu.%'
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE '%mail.%.edu'
	AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain NOT LIKE '%k12%'
	AND (rpt_workspace.jmarzinke_marketo_lead_seed_temp.wasSharedToPriorToTrial = 0 OR rpt_workspace.jmarzinke_marketo_lead_seed_temp.containerCount > 0) -- if they were shared to, make sure they created a sheet.
;
SELECT '************************************* Smartscored rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- BEGIN SFDC domain updates for leadflow.arc_sfdc_domains (updated 2016-05-19)
-- Use temp table to prevent locks on ss_sfdc_02.domain, which is slowing down the whole script
-- *********************************************************************************************************************
-- Query #1: Retrieve SFDC domain changes
DROP TABLE IF EXISTS tmp_sfdc_domains;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domains
(INDEX (Domain_Name_URL__c))
SELECT sfd.Domain_Name_URL__c, sfu.Owner_at_Import__c, sfd.Status__c FROM rpt_workspace.jmarzinke_arc_sfdc_domains lfd
JOIN ss_sfdc_02.domain sfd ON lfd.companyDomain = sfd.Domain_Name_URL__c
JOIN ss_sfdc_02.user sfu ON sfd.OwnerId = sfu.Id
;
SELECT '************************************* arc_sfdc_domains.sfdcOwner/Status__c ss_sfdc_02.domain temp: ', ROW_COUNT(), NOW();

-- Query #2: Update leadflow table to match SFDC where possible and delete matched records
UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains lfd
JOIN tmp_sfdc_domains sfd ON lfd.companyDomain = sfd.Domain_Name_URL__c
SET
    lfd.sfdcOwner = sfd.Owner_at_Import__c,
    lfd.Status__c = sfd.Status__c
;
SELECT '************************************* arc_sfdc_domains.sfdcOwner/Status__c ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();
-- *********************************************************************************************************************
-- FINISH SFDC domain updates for leadflow.arc_sfdc_domains
-- *********************************************************************************************************************


-- Update SSOwner to match SFDCOwner
UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains
SET
    SSOwner = sfdcOwner,
    valueCheck = 3
WHERE
    sfdcOwner != SSOwner
    AND sfdcOwner NOT IN ('Andrew Imhoff', 'Leads Uploader', 'Marketo Integration', 'Desk Integration')
;
SELECT '************************************* arc_sfdc_domains.SSOwner valueCheck rows: ', ROW_COUNT(), NOW();

-- Delete unassigned leads
DELETE FROM rpt_workspace.jmarzinke_arc_sfdc_domains
WHERE
    sfdcOwner = 'Andrew Imhoff'
    AND Status__c = 'Unassigned'
    AND dateAdded < @marketoLookbackDateTime
;
SELECT '************************************* arc_sfdc_domains.sfdcOwner delete rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains -- most specific to least specific matching
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_sfdc_02.domain ON domain.Domain_Name_URL__c = rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain
JOIN ss_sfdc_02.user sfu ON domain.OwnerId = sfu.Id
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = sfu.Owner_at_Import__c
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)')
AND domain.OwnerID IN (
	SELECT ID FROM ss_sfdc_02.user 
	WHERE userRoleID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to last 4 sections of a domain - aci.health.nsw.gov.au becomes health.nsw.gov.au
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_sfdc_02.domain ON domain.Domain_Name_URL__c = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -4)
JOIN ss_sfdc_02.user sfu ON domain.OwnerId = sfu.Id
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = sfu.Owner_at_Import__c
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)')
AND domain.OwnerID IN (	
	SELECT ID FROM ss_sfdc_02.user 
	WHERE userRoleID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to last 3 sections of a domain - 13lob.freeserve.co.uk becomes freeserve.co.uk 
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_sfdc_02.domain ON domain.Domain_Name_URL__c = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -3)
JOIN ss_sfdc_02.user sfu ON domain.OwnerId = sfu.Id
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = sfu.Owner_at_Import__c
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)')
AND domain.OwnerID IN (
	SELECT ID FROM ss_sfdc_02.user 
	WHERE userRoleID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to just last 2 sections of domain - 00518.mygbiz.com becomes mygbiz.com
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_sfdc_02.domain ON domain.Domain_Name_URL__c = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -2)
JOIN ss_sfdc_02.user sfu ON domain.OwnerId = sfu.Id
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = sfu.Owner_at_Import__c
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)')
AND domain.OwnerID IN (
	SELECT ID FROM ss_sfdc_02.user 
	WHERE userRoleID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- check for foreign versions of exisitng domains abb.com.nz - 09vantage.co.nz becomes 09vantage.co
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN ss_sfdc_02.domain ON domain.Domain_Name_URL__c = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', 2)
JOIN ss_sfdc_02.user sfu ON domain.OwnerId = sfu.Id
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = sfu.Owner_at_Import__c
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)')
AND domain.OwnerID IN (
	SELECT ID FROM ss_sfdc_02.user 
	WHERE userRoleID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains -- most specific to least specific matching
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner'
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to last 4 sections of a domain - aci.health.nsw.gov.au becomes health.nsw.gov.au
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -4)
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner'
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to last 3 sections of a domain - 13lob.freeserve.co.uk becomes freeserve.co.uk 
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -3)
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner'
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- Update salesforceOwnerAtImport for previously existing domains - handle matches to just last 2 sections of domain - 00518.mygbiz.com becomes mygbiz.com
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', -2)
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner'
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();

-- check for foreign versions of exisitng domains abb.com.nz - 09vantage.co.nz becomes 09vantage.co
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain, '.', 2)
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner'
;
SELECT '************************************* ss_sfdc_02.domain rows: ', ROW_COUNT(), NOW();


-- only allow edu domain from paid accounts through
-- UPDATE tmp_marketo_leads 
-- SET tmp_marketo_leads.salesforceLeadSource = NULL
-- WHERE tmp_marketo_leads.salesforceOwnerAtImport = 'NeedsOwner' AND emailDomain LIKE '%.edu%';
-- Update salesforceOwnerAtImport for all other leads
-- Insert new Prosumer domains to arc_sfdc_domains

/* INSERT arc_sfdc_domains (companyDomain, dateAdded)
SELECT emailDomain, NOW()
FROM tmp_marketo_leads
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON tmp_marketo_leads.emailDomain = arc_ISPDomains.domain
WHERE tmp_marketo_leads.salesforceOwnerAtImport = 'NeedsOwner' AND tmp_marketo_leads.emailDomain IS NOT NULL
AND arc_ISPDomains.userCount IS NULL -- Remove ISP domains
AND emailDomain NOT IN (SELECT companyDomain FROM arc_sfdc_domains)
GROUP BY 1
;
-- Assign owners for new domains
SELECT MAX(nullCount) INTO @nullCount FROM arc_sfdc_domains; -- find starting point for count for randomdistribution
UPDATE arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 
WHERE SSOwner IS NULL;
-- Assign owners based on 00-99 assignment table.  Generated via stored procedure LeadAssignment();
UPDATE arc_sfdc_domains
LEFT OUTER JOIN arc_leadAssignmentNBR ON RIGHT(nullCount,2) = arc_leadAssignmentNBR.AssignmentID
SET arc_sfdc_domains.SSOwner = arc_leadAssignmentNBR.SSOwner
WHERE arc_sfdc_domains.SSOwner IS NULL;
-- Update salesforceOwnerAtImport for these now assigned domains
UPDATE tmp_marketo_leads 
JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = tmp_marketo_leads.emailDomain
SET tmp_marketo_leads.salesforceOwnerAtImport = arc_sfdc_domains.SSOwner
WHERE tmp_marketo_leads.salesforceOwnerAtImport = 'NeedsOwner'; */

-- code included now to flag if the lead is coming in from a beachhead domain
INSERT rpt_workspace.jmarzinke_arc_sfdc_domains (companyDomain, dateAdded, beachheadDomain)
SELECT emailDomain, NOW(), CASE WHEN d.Domain_Name_URL__c IS NOT NULL THEN 1 ELSE 0 END
FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain = isp.domain
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain AND d.Beachhead_Domain__c = 'true'
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner' AND rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain IS NOT NULL
AND isp.userCount IS NULL -- Remove ISP domains
AND emailDomain NOT IN (SELECT companyDomain FROM rpt_workspace.jmarzinke_arc_sfdc_domains)
GROUP BY 1
;
SELECT '************************************* beachhead domain rows: ', ROW_COUNT(), NOW();

-- Assign owners for new domains
SELECT MAX(nullCount) INTO @nullCount FROM rpt_workspace.jmarzinke_arc_sfdc_domains; -- find starting point for count for randomdistribution including both ISR2 and ISR1 reps
SELECT MAX(beachheadDomainID) INTO @beachheadIDCount FROM rpt_workspace.jmarzinke_arc_sfdc_domains;  -- find starting point for beachhead assignment


UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains
SET beachheadDomainID = @beachheadIDCount:=@beachheadIDCount + 1 
WHERE SSOwner IS NULL AND beachheadDomain = 1;
SELECT '************************************* leadflow.arc_sfdc_domains rows: ', ROW_COUNT(), NOW();


UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1
WHERE SSOwner IS NULL AND (beachheadDomain IS NULL OR beachheadDomain = 0);
SELECT '************************************* leadflow.arc_sfdc_domains rows: ', ROW_COUNT(), NOW();

-- Assign beachhead owners based on 00-99 assignment table. This table only consists of ISR2 reps and is rebalanced twice a day.  Generated via stored procedure LeadAssignment();
UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains
LEFT OUTER JOIN leadflow.arc_leadAssignmentNBR ON RIGHT(beachheadDomainID,3) = arc_leadAssignmentNBR.AssignmentID
SET rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner = arc_leadAssignmentNBR.SSOwner
WHERE rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner IS NULL AND rpt_workspace.jmarzinke_arc_sfdc_domains.beachheadDomain = 1;
SELECT '************************************* leadflow.arc_sfdc_domains rows: ', ROW_COUNT(), NOW();

-- Assign owners for non-beachhead domains using 00-99 table that consists ISR1 reps.
UPDATE rpt_workspace.jmarzinke_arc_sfdc_domains
LEFT OUTER JOIN leadflow.arc_leadAssignmentNAS ON RIGHT(nullCount,3) = arc_leadAssignmentNAS.AssignmentID
SET rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner = arc_leadAssignmentNAS.SSOwner
WHERE rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner IS NULL AND (beachheadDomain IS NULL OR beachheadDomain = 0);
SELECT '************************************* leadflow.arc_sfdc_domains rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
JOIN rpt_workspace.jmarzinke_arc_sfdc_domains ON rpt_workspace.jmarzinke_arc_sfdc_domains.companyDomain = rpt_workspace.jmarzinke_marketo_lead_seed_temp.emailDomain
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = rpt_workspace.jmarzinke_arc_sfdc_domains.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner';
SELECT '************************************* arc_sfdc_domains rows: ', ROW_COUNT(), NOW();

-- this is for the leads that are not really smartscored, we're just pre-assigning owners so activity triggers
-- that happen later can cause the lead to be pushed to SFDC
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp
LEFT OUTER JOIN leadflow.arc_leadAssignmentNAS ON RIGHT(rpt_workspace.jmarzinke_marketo_lead_seed_temp.userID,3) = arc_leadAssignmentNAS.AssignmentID
SET rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = arc_leadAssignmentNAS.SSOwner
WHERE rpt_workspace.jmarzinke_marketo_lead_seed_temp.salesforceOwnerAtImport = 'NeedsOwner';
SELECT '************************************* arc_leadAssignmentNAS rows: ', ROW_COUNT(), NOW();

-- Assign salesforceOwnerRoleAtImport
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp A
JOIN ss_sfdc_02.user u ON u.Owner_at_Import__c = A.salesforceOwnerAtImport
JOIN ss_sfdc_02.user_role ur ON ur.Id = u.UserRoleID
SET salesforceOwnerRoleAtImport = ur.Name
;
SELECT '************************************* salesforceOwnerRoleAtImport rows: ', ROW_COUNT(), NOW();

-- Update remaining salesforce related fields (Updated 2016-08-03)
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT JOIN rpt_main_02.arc_domainEmailExclusion dee ON tml.emailDomain = dee.domain AND dee.excludeFromSalesEmail = 1
    LEFT JOIN ss_core_02.organizationUserRole our ON tml.userID = our.userID AND our.role = 'MEMBER' AND our.state IN (1, 2)
    LEFT JOIN rpt_main_02.arc_organizationEmailExclusion oee ON our.organizationID = oee.organizationID
    LEFT JOIN rpt_main_02.arc_doNotContactList dnc ON tml.emailAddress = dnc.emailAddress
SET
    tml.smartscoreCode   =
        CASE
            WHEN tml.isTrialRestart = 1 THEN 'Org+Restart'
            WHEN tml.wasSharedToPriorToTrial = 1 THEN 'Org+Shared'
            WHEN tml.signupRequestID IS NULL THEN 'Org+Viral'
            WHEN tml.usedGoogleAuthentication = 1 THEN 'Org+Google'
            WHEN tml.locale NOT LIKE ('en_%') THEN 'Org+OtherLanguage'
            ELSE 'Org+English'
        END,
    tml.salesforceStatus =
        CASE
            WHEN dee.domain IS NULL OR oee.organizationID IS NULL THEN 'Pending' -- pending leads get sales, webinar emails
            ELSE 'New' -- new just gets webinar emails
        END
WHERE tml.salesforceLeadSource IS NOT NULL
;
SELECT '************************************* SFDC fields() rows: ', ROW_COUNT(), NOW();


-- **************************************************************************************************************************
-- FINISH Sales Rep Assignment
-- **************************************************************************************************************************


-- **************************************************************************************************************************
-- BEGIN Add Success Rep Details, Account Tier, Account Health, and Account CSA Drip Bucket
-- **************************************************************************************************************************

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed_temp tml
    LEFT JOIN ss_sfdc_02.domain d ON tml.emailDomain = d.Domain_Name_URL__c
    LEFT JOIN ss_sfdc_02.account a ON d.Account__c = a.Id
    LEFT JOIN rpt_main_02.rpt_csReport cs ON a.Id = cs.accountId
    LEFT JOIN ss_sfdc_02.user csu ON a.Customer_Success__c = csu.Id
    LEFT JOIN ss_sfdc_02.user dou ON d.OwnerId = dou.Id AND dou.ID != '00540000002nu18AAA'  -- Exclude Andrew Imhoff. We don't want emails to come from him.
SET
    tml.accountHealth          = cs.accountHealth,
    tml.accountTier            = cs.accountTier,
    tml.accountCSADripBucket   = cs.AccountToBeAssigned,
    tml.accountTerritory       = cs.territory,
    tml.successRepEmail        = csu.Email,
    tml.successRepFirstName    = csu.FirstName,
    tml.successRepLastName     = csu.LastName,
    tml.successRepPhoneNumber  = csu.Phone,
    tml.domainOwnerEmail       = dou.Email,
    tml.domainOwnerFirstName   = dou.FirstName,
    tml.domainOwnerLastName    = dou.LastName,
    tml.domainOwnerTitle       = dou.Title,
    tml.domainOwnerPhoneNumber = dou.Phone
WHERE tml.isOrgDomain = 1  -- Ignore ISP domains.
;
SELECT '************************************* customer success account rows: ', ROW_COUNT(), NOW();

-- **************************************************************************************************************************
-- FINISH Add Success Rep Details, Account Tier, Account Health, and Account CSA Drip Bucket
-- **************************************************************************************************************************


-- **************************************************************************************************************************
-- BEGIN Copy All tmp_marketo_leads To arc_marketo_upload Table
-- **************************************************************************************************************************


-- Copy all fields into arc_marketo_upload, ignoring any with duplicate keys
INSERT IGNORE INTO rpt_workspace.jmarzinke_marketo_lead_seed
    SELECT *
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp
    WHERE insertSource NOT LIKE '%-newPP'
    ORDER BY userID ASC; -- Order by userID to minimize lock wait/deadlock collisions with Marketo importer updates
SELECT '************************************* arc_marketo_upload INSERT insertSource NOT LIKE %-newPP', ROW_COUNT(), NOW();

-- Replace all fields into arc_marketo_upload where a user has a payment profile where previously didn't
-- (e.g., A collaborator begins a trial)
REPLACE INTO rpt_workspace.jmarzinke_marketo_lead_seed
    SELECT *
    FROM rpt_workspace.jmarzinke_marketo_lead_seed_temp
    WHERE insertSource LIKE '%-newPP'
    ORDER BY userID ASC; -- Order by userID to minimize lock wait/deadlock collisions with Marketo importer updates
SELECT '************************************* arc_marketo_upload REPLACE insertSource LIKE %-newPP rows: ', ROW_COUNT(), NOW();

-- **************************************************************************************************************************
-- FINISH Copy All tmp_marketo_leads To arc_marketo_upload Table
-- **************************************************************************************************************************



-- **************************************************************************************************************************
-- BEGIN Update all fields that need to be current
-- **************************************************************************************************************************


-- create table for all userAccount records that have changed
DROP TABLE IF EXISTS tmp_userAcccount_marketoSync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_userAcccount_marketoSync LIKE ss_core_02.userAccount;

-- find all the records in ss_core_02.userAccount that have changed recently
INSERT IGNORE tmp_userAcccount_marketoSync
    SELECT ua.*
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mk_upload
        JOIN ss_core_02.userAccount ua ON mk_upload.userID = ua.userID
    WHERE ua.modifyDateTime >= @marketoLookbackDateTime
    ORDER BY mk_upload.userID ASC
;
SELECT '************************************* userAccount changes: ', ROW_COUNT(), NOW();

-- update the record if we can detect a change that we care about
-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mk_upload
    JOIN tmp_userAcccount_marketoSync ua ON mk_upload.userID = ua.userID
    LEFT JOIN ss_account_02.signupRequestTrackingItem srfn ON mk_upload.signupRequestID = srfn.signupRequestID AND srfn.itemName = 'su_fname'
    LEFT JOIN ss_account_02.signupRequestTrackingItem srln ON mk_upload.signupRequestID = srln.signupRequestID AND srln.itemName = 'su_lname'
SET
    mk_upload.pushToMarketo             = GREATEST(@updatePriority, mk_upload.pushToMarketo), -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mk_upload.updateDateTime            = CURRENT_TIMESTAMP(),
    mk_upload.userAccountModifyDateTime = ua.modifyDateTime, -- reset the flag to indicate when it last changed
    mk_upload.emailAddress              = ua.emailAddress,
    mk_upload.emailDomain               = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
    mk_upload.website                   = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress), -- uses same value as domain for now
    mk_upload.firstName                 = COALESCE(ua.firstName, srfn.itemValue),
    mk_upload.lastName                  = COALESCE(rpt_main_02.MARKETO_LAST_NAME(ua.lastName), rpt_main_02.MARKETO_LAST_NAME(srln.itemValue)),
    mk_upload.newsFlags                 = ua.newsFlags,
    mk_upload.appOptOut                 = NOT (ua.newsFlags & 1),
    mk_upload.statusFlags               = ua.statusFlags,
    mk_upload.isUserAgreementAccepted   = CASE WHEN ua.statusFlags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in statusFlags bitmask, which is 1000 in binary (8 in decimal)
    mk_upload.locale                    = ua.locale,
    mk_upload.timeZone                  = ua.timeZone
	--  the timestamp gets updated and use the current record from history
WHERE
    (mk_upload.emailAddress != ua.emailAddress COLLATE utf8mb4_unicode_520_ci OR			  -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
     -- mk_upload.emailDomain != ua.emailDomain OR 			 -- don't need emailDomain or website because emailAddress change will trigger these
     COALESCE(mk_upload.firstName, '') != COALESCE(ua.firstName, srfn.itemName, '') COLLATE utf8mb4_unicode_520_ci OR	-- could be null so use coalesce for null handling
     COALESCE(mk_upload.lastName, '') != COALESCE(rpt_main_02.MARKETO_LAST_NAME(ua.lastName), srln.itemName) COLLATE utf8mb4_unicode_520_ci OR
     COALESCE(mk_upload.newsFlags, '') != COALESCE(ua.newsFlags, '') OR
     COALESCE(mk_upload.statusFlags, '') != COALESCE(ua.statusFlags, '') OR
     COALESCE(mk_upload.locale, '') != COALESCE(ua.locale, '') COLLATE utf8mb4_unicode_520_ci OR
     COALESCE(mk_upload.timeZone, '') != COALESCE(ua.timeZone, '') COLLATE utf8mb4_unicode_520_ci OR
     COALESCE(mk_upload.userAccountModifyDateTime, '') != COALESCE(ua.modifyDateTime, '')
    )
    AND mk_upload.userAccountModifyDateTime <= ua.modifyDateTime  -- only if the modifyDateTime is changed in the right direction
    AND mk_upload.pushToMarketo != 10  -- Fix for MKTO1603. This prevents creating duplicate lead records (by userID) in Marketo if user changes email address immediately after creating account
;
-- ORIGINAL
-- UPDATE arc_marketo_upload mk_upload
--     JOIN tmp_userAcccount_marketoSync ua ON mk_upload.userID = ua.userID
-- SET
--     mk_upload.pushToMarketo             = GREATEST(@updatePriority, mk_upload.pushToMarketo), -- indicate record needs to be pushed, using GREATEST so we never lower the priority
--     mk_upload.updateDateTime            = CURRENT_TIMESTAMP(),
--     mk_upload.userAccountModifyDateTime = ua.modifyDateTime, -- reset the flag to indicate when it last changed
--     mk_upload.emailAddress              = ua.emailAddress,
--     mk_upload.emailDomain               = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
--     mk_upload.website                   = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress), -- uses same value as domain for now
--     mk_upload.firstName                 = ua.firstName,
--     mk_upload.lastName                  = rpt_main_02.MARKETO_LAST_NAME(ua.lastName),
--     mk_upload.newsFlags                 = ua.newsFlags,
--     mk_upload.appOptOut                 = NOT (ua.newsFlags & 1),
--     mk_upload.statusFlags               = ua.statusFlags,
--     mk_upload.isUserAgreementAccepted   = CASE WHEN ua.statusFlags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in statusFlags bitmask, which is 1000 in binary (8 in decimal)
--     mk_upload.locale                    = ua.locale,
--     mk_upload.timeZone                  = ua.timeZone
-- --  the timestamp gets updated and use the current record from history 
-- WHERE
--     (mk_upload.emailAddress != ua.emailAddress COLLATE utf8mb4_unicode_520_ci OR			  -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
--      -- mk_upload.emailDomain != ua.emailDomain OR 			 -- don't need emailDomain or website because emailAddress change will trigger these
--      COALESCE(mk_upload.firstName, '') != COALESCE(ua.firstName, '') COLLATE utf8mb4_unicode_520_ci OR	-- could be null so use coalesce for null handling
--      COALESCE(mk_upload.lastName, '') != rpt_main_02.MARKETO_LAST_NAME(ua.lastName) COLLATE utf8mb4_unicode_520_ci OR
--      COALESCE(mk_upload.newsFlags, '') != COALESCE(ua.newsFlags, '') OR
--      COALESCE(mk_upload.statusFlags, '') != COALESCE(ua.statusFlags, '') OR
--      COALESCE(mk_upload.locale, '') != COALESCE(ua.locale, '') COLLATE utf8mb4_unicode_520_ci OR
--      COALESCE(mk_upload.timeZone, '') != COALESCE(ua.timeZone, '') COLLATE utf8mb4_unicode_520_ci OR
--      COALESCE(mk_upload.userAccountModifyDateTime, '') != COALESCE(ua.modifyDateTime, '')
--     )
--     AND mk_upload.userAccountModifyDateTime <= ua.modifyDateTime  -- only if the modifyDateTime is changed in the right direction
--     AND mk_upload.pushToMarketo != 10  -- Fix for MKTO1603. This prevents creating duplicate lead records (by userID) in Marketo if user changes email address immediately after creating account
-- ;
SELECT '************************************* arc_marketo_upload rows updated from userAccount changes: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- BEGIN userAccount.isOrgDomain updates for leadflow.arc_marketo_upload (updated 2015-12-03)
-- This is done in two queries in order to eliminate locks on rpt_main_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to arc_marketo_upload and execute updates
-- *********************************************************************************************************************
-- Query #1: Retrieve changes made to userAccount.isOrgDomain records
-- Need to separate out isOrgDomain flag because the if the email address changes, the domain needs to be updated first before
-- we can check to see if that domain is an Org domain
DROP TABLE IF EXISTS tmp_userAccount_ISPDomains_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_userAccount_ISPDomains_to_sync
(INDEX (userID))
    SELECT
        mu.userID,
        ispd.domain
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN tmp_userAcccount_marketoSync ua ON mu.userID = ua.userID
        LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ispd ON mu.emailDomain = ispd.domain
    WHERE
        (
            (ispd.domain IS NOT NULL AND mu.isOrgDomain = 1)
            OR (ispd.domain IS NULL AND mu.isOrgDomain = 0)
        )
        AND mu.userAccountModifyDateTime <= ua.modifyDateTime
    ORDER BY mu.userID ASC
;
SELECT '************************************* temp arc_marketo_upload rows updated from userAccount.isOrgDomain changes: ', ROW_COUNT(), NOW();

-- Query #2: Update arc_marketo_upload with the userAccount.isOrgDomain changes
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_userAccount_ISPDomains_to_sync ispd ON mu.userID = ispd.userID
SET
    mu.isOrgDomain = CASE WHEN ispd.domain IS NULL THEN 1 ELSE 0 END,
    mu.pushToMarketo = GREATEST(@updatePriority, mu.pushToMarketo),  -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT '************************************* update arc_marketo_upload rows updated from userAccount.isOrgDomain changes: ', ROW_COUNT(), NOW();
-- *********************************************************************************************************************
-- FINISH userAccount.isOrgDomain updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************


DROP TABLE IF EXISTS tmp_paymentProfile_marketoSync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_paymentProfile_marketoSync LIKE ss_core_02.paymentProfile;

INSERT IGNORE tmp_paymentProfile_marketoSync
    SELECT pp.*
    FROM ss_core_02.paymentProfile pp
    WHERE pp.modifyDateTime >= @marketoLookbackDateTime
    ORDER BY pp.ownerID ASC
    -- SELECT pp.*
    -- FROM leadflow.arc_marketo_upload mk_upload
    --     JOIN ss_core_02.paymentProfile pp ON mk_upload.paymentProfileID = pp.paymentProfileID
    -- WHERE pp.modifyDateTime >= @marketoLookbackDateTime
    -- ORDER BY mk_upload.userID ASC
;
SELECT '************************************* paymentProfile changes: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- BEGIN Payment Profile updates for leadflow.arc_marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to arc_marketo_upload and execute updates
-- *********************************************************************************************************************

-- Query #1: Retrieve changes made to paymentProfile records
DROP TABLE IF EXISTS coreTableData_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS coreTableData_to_sync
(INDEX (userID))
    SELECT
        mu.userID,
        hce.exchangeRate                                        hceexchangeRate,
        org.mainContactUserID                                   orgmainContactUserID,
        org.name                                                orgname,
        org.organizationID                                      orgorganizationID,
        ppp.billToAddress1                                      pppbillToAddress1,
        ppp.billToAddress2                                      pppbillToAddress2,
        ppp.billToCity                                          pppbillToCity,
        ppp.billToCountryCode                                   pppbillToCountryCode,
        ppp.billToPostCode                                      pppbillToPostCode,
        ppp.billToRegionCode                                    pppbillToRegionCode,
        ppp.currencyCode                                        pppcurrencyCode,
        ppp.paymentEndDateTime                                  ppppaymentEndDateTime,
        ppp.paymentFlags                                        ppppaymentFlags,
        ppp.paymentProfileID                                    ppppaymentProfileID,
        ppp.paymentStartDateTime                                ppppaymentStartDateTime,
        ppp.paymentTerm                                         ppppaymentTerm,
        ppp.planRate                                            pppplanRate,
        ppp.primaryContactPhone                                 pppprimaryContactPhone,
        pp.accountType                                          ppaccountType,
        pp.billToAddress1                                       ppbillToAddress1,
        pp.billToAddress2                                       ppbillToAddress2,
        pp.billToCity                                           ppbillToCity,
        pp.billToCountryCode                                    ppbillToCountryCode,
        pp.billToPostCode                                       ppbillToPostCode,
        pp.billToRegionCode                                     ppbillToRegionCode,
        pp.currencyCode                                         ppcurrencyCode,
        pp.modifyDateTime                                       ppmodifyDateTime,
        leadflow.SMARTSHEET_NEXTPAYMENTDATE(
            CURRENT_TIMESTAMP(),
            pp.nextPaymentDate,
            ppp.nextPaymentDate,
            pp.paymentTerm,
            pp.actualLastPaymentDate,
            ppp.actualLastPaymentDate,
            pp.accountType,
            pp.paymentStartDateTime,
            ppp.paymentStartDateTime,
            COALESCE(pp.promoCode, ''),
            COALESCE(ppp.promoCode, ''),
            pp.insertDateTime,
            ppp.insertDateTime)                                 ppnextPaymentDate,
        pp.paymentProfileID                                     pppaymentProfileID,
        pp.parentPaymentProfileID                               ppparentPaymentProfileID,
        pp.paymentEndDateTime                                   pppaymentEndDateTime,
        pp.paymentFlags                                         pppaymentFlags,
        leadflow.SMARTSHEET_PAYMENTSTARTDATETIME(
            pp.accountType,
            pp.productID,
            pp.paymentStartDateTime,
            ppp.paymentStartDateTime)                           pppaymentStartDateTime,
        pp.paymentTerm                                          pppaymentTerm,
        pp.planRate                                             ppplanRate,
        pp.primaryContactPhone                                  ppprimaryContactPhone,
        IF(ppp.paymentProfileID IS NULL,
           COALESCE(pp.primaryContactPhone, sr.itemValue),
           IF(org.mainContactUserID = mu.userID,
              COALESCE(ppp.primaryContactPhone, sr.itemValue),
              COALESCE(pp.primaryContactPhone, sr.itemValue)))  primaryContactPhone,
        pp.productID                                            ppproductID,
        pp.userLimit                                            ppuserLimit,
        mu.userLimit                                            previousUserLimit,
        IF(ppp.paymentProfileID IS NULL,
           leadflow.SMARTSHEET_PAYMENTTYPE(pp.paymentType),
           IF(org.mainContactUserID = mu.userID,
              leadflow.SMARTSHEET_PAYMENTTYPE(ppp.paymentType),
              leadflow.SMARTSHEET_PAYMENTTYPE(pp.paymentType))) pppaymentType,
        pp.actualLastPaymentDate                                ppactualLastPaymentDate,
        pp.promoCode                                            pppromoCode,
        pp.insertDateTime                                       ppinsertDateTime
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN tmp_paymentProfile_marketoSync pp ON mu.paymentProfileID = pp.paymentProfileID
        LEFT OUTER JOIN ss_core_02.paymentProfile ppp ON pp.parentPaymentProfileID = ppp.paymentProfileID
        LEFT OUTER JOIN ss_core_02.organization org ON ppp.ownerID = org.organizationID AND ppp.accountType = 3  # mu.userID = org.mainContactUserIDs
        LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode AND
                                                                pp.paymentStartDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
        LEFT OUTER JOIN ss_account_02.signupRequestTrackingItem sr ON mu.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_phone'
    WHERE
        (
            COALESCE(mu.productName, '') != rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) COLLATE utf8mb4_unicode_520_ci OR   -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
            COALESCE(mu.userLimit, -1) != COALESCE(pp.userLimit, -1) OR
            COALESCE(mu.parentPaymentProfileID, 0) != COALESCE(pp.parentPaymentProfileID, 0) OR 	-- could be null so use coalesce for null handling
            COALESCE(mu.paymentStartDateTime, 0) != COALESCE(leadflow.SMARTSHEET_PAYMENTSTARTDATETIME(pp.accountType, pp.productID, pp.paymentStartDateTime, ppp.paymentStartDateTime), 0) OR
            (COALESCE(mu.trialEndDateDateTime, '') != COALESCE(pp.paymentEndDateTime, ppp.paymentEndDateTime) AND pp.productID = 1) OR
            COALESCE(mu.nextPaymentDate, 0) != COALESCE(leadflow.SMARTSHEET_NEXTPAYMENTDATE(CURRENT_TIMESTAMP(), pp.nextPaymentDate, ppp.nextPaymentDate, pp.paymentTerm, pp.actualLastPaymentDate, ppp.actualLastPaymentDate, pp.accountType, pp.paymentStartDateTime, ppp.paymentStartDateTime, COALESCE(pp.promoCode, ''), COALESCE(ppp.promoCode, ''), pp.insertDateTime, ppp.insertDateTime), 0) OR  -- could be null so use coalesce for null handling
            COALESCE(mu.paymentTerm, -1) != pp.paymentTerm OR
            (COALESCE(mu.planRate, -1) != pp.planRate AND ppp.paymentProfileID IS NULL) OR  -- the planRate is changed and there is no parent
            (COALESCE(mu.planRate, -1) != COALESCE(ppp.planRate, -1) AND org.mainContactUserID = mu.userID) OR  -- the planRate is changed from the parent value
            COALESCE(mu.currencyCode, '') != pp.currencyCode COLLATE utf8mb4_unicode_520_ci OR
            COALESCE(mu.recurringBillingCancelled, -1) !=  leadflow.MARKETO_RECURRING_BILLING_CANCELLED(ppp.paymentProfileID, org.mainContactUserID, mu.userID, pp.paymentFlags, ppp.paymentFlags) OR

            (COALESCE(mu.primaryContactPhone, '') != COALESCE(pp.primaryContactPhone, sr.itemValue, '') COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the primaryContactPhone is changed and there is no parent
            (COALESCE(mu.primaryContactPhone, '') != COALESCE(ppp.primaryContactPhone, sr.itemValue, '') COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID) OR  -- the primaryContactPhone is changed from the parent value

            (COALESCE(mu.billToAddress, '') != rpt_main_02.MARKETO_BILLING_ADDRESS(pp.billToAddress1, pp.billToAddress2) COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the billToAddress is changed and there is no parent
            (COALESCE(mu.billToAddress, '') != rpt_main_02.MARKETO_BILLING_ADDRESS(ppp.billToAddress1, ppp.billToAddress2) COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID ) OR  -- the billToAddress is changed from the parent value

            (COALESCE(mu.billToCity, '') != COALESCE(pp.billToCity, '') COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the billToCity is changed and there is no parent
            (COALESCE(mu.billToCity, '') != COALESCE(ppp.billToCity, '') COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID ) OR  -- the billToCity is changed from the parent value

            (COALESCE(mu.billToRegionCode, '') != COALESCE(pp.billToRegionCode, '') COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the billToRegionCode is changed and there is no parent
            (COALESCE(mu.billToRegionCode, '') != COALESCE(ppp.billToRegionCode, '') COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID ) OR  -- the billToRegionCode is changed from the parent value

            (COALESCE(mu.billToPostCode, '') != COALESCE(pp.billToPostCode, '') COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the billToPostCode is changed and there is no parent
            (COALESCE(mu.billToPostCode, '') != COALESCE(ppp.billToPostCode, '') COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID ) OR  -- the billToPostCode is changed from the parent value

            (COALESCE(mu.billToCountryCode, '') != COALESCE(pp.billToCountryCode, '') COLLATE utf8mb4_unicode_520_ci AND ppp.paymentProfileID IS NULL) OR  -- the billToCountryCode is changed and there is no parent
            (COALESCE(mu.billToCountryCode, '') != COALESCE(ppp.billToCountryCode, '') COLLATE utf8mb4_unicode_520_ci AND org.mainContactUserID = mu.userID ) OR  -- the billToCountryCode is changed from the parent value

            COALESCE(mu.paymentType, -1) != IF(ppp.paymentProfileID IS NULL, leadflow.SMARTSHEET_PAYMENTTYPE(pp.paymentType), IF(org.mainContactUserID = mu.userID, leadflow.SMARTSHEET_PAYMENTTYPE(ppp.paymentType), leadflow.SMARTSHEET_PAYMENTTYPE(pp.paymentType)))
        )
        AND COALESCE(mu.ppModifyDateTime, '') <= COALESCE(pp.modifyDateTime, '')
    ORDER BY mu.userID ASC
;
SELECT '************************************* temporary table rows grabbed from core database: ', ROW_COUNT(), NOW();

-- Query #2: Update arc_marketo_upload with the paymentProfile changes
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN coreTableData_to_sync tmp ON mu.userID = tmp.userID
SET
    mu.pushToMarketo              = GREATEST(@updatePriority, mu.pushToMarketo), -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mu.updateDateTime             = CURRENT_TIMESTAMP(),
    mu.ppModifyDateTime           = tmp.ppmodifyDateTime, -- reset the flag to indicate when it last changed
    mu.productName                = rpt_main_02.SMARTSHEET_PRODUCTNAME(tmp.ppproductID),
    mu.userLimit                  = tmp.ppuserLimit,
    mu.previousUserLimit          = tmp.previousUserLimit,
    mu.paymentStartDateTime       = tmp.pppaymentStartDateTime,
    -- get the date from the parent, will be null if no parent
    mu.parentPaymentStartDateTime = tmp.ppppaymentStartDateTime,
    mu.nextPaymentDate            = tmp.ppnextPaymentDate,
    mu.paymentType                = tmp.pppaymentType,
    mu.paymentTerm                = tmp.pppaymentTerm,
    mu.planRate                   =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppplanRate -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppplanRate -- owner, use the planRate from the org for the owner
            ELSE tmp.ppplanRate -- member, so use profile value
        END,
    mu.currencyCode               = tmp.ppcurrencyCode,
    mu.monthlyPlanRate_USD        = COALESCE(
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL
                THEN
                    CASE
                        WHEN tmp.ppcurrencyCode = 'USD' THEN tmp.ppplanRate / tmp.pppaymentTerm
                        ELSE (tmp.ppplanRate / tmp.hceexchangeRate) / tmp.pppaymentTerm
                    END -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID
                THEN --  owner, use the planRate from the org for the owner
                    CASE
                        WHEN tmp.pppcurrencyCode = 'USD' THEN tmp.pppplanRate / tmp.ppppaymentTerm
                        ELSE (tmp.pppplanRate / tmp.hceexchangeRate) / tmp.ppppaymentTerm
                    END
            ELSE
                CASE
                    WHEN tmp.ppcurrencyCode = 'USD' THEN tmp.ppplanRate / tmp.pppaymentTerm
                    ELSE (tmp.ppplanRate / tmp.hceexchangeRate) / tmp.pppaymentTerm
                END -- member, so use profile value
        END, 0
    ),
    mu.parentPaymentProfileID     = tmp.ppparentPaymentProfileID,
    -- Updated 2016-12-21 to account for amplified trial signup
    -- UPDATE
    mu.primaryContactPhone        = tmp.primaryContactPhone,
    -- ORIGINAL
    -- mu.primaryContactPhone =
    --     CASE
    --         WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppprimaryContactPhone  						-- no parent, so use profile value
    --         WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppprimaryContactPhone  -- owner, use the primaryContactPhone from the org for the owner
    --         ELSE tmp.ppprimaryContactPhone 																-- member, so use profile value
    --     END,
    -- combine to address fields into one billToAddress
    mu.billToAddress              =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.ppbillToAddress1, tmp.ppbillToAddress2) -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.pppbillToAddress1, tmp.pppbillToAddress2) -- owner, use the billToAddress from the org for the owner
            ELSE rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.ppbillToAddress1, tmp.ppbillToAddress2) -- member, so use profile value
        END,
    mu.billToCity                 =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppbillToCity -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppbillToCity -- owner, use the billToCity from the org for the owner
            ELSE tmp.ppbillToCity -- member, so use profile value
        END,
    mu.billToRegionCode           =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppbillToRegionCode -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppbillToRegionCode -- owner, use the billToRegionCode from the org for the owner
            ELSE tmp.ppbillToRegionCode -- member, so use profile value
        END,
    mu.billToPostCode             =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppbillToPostCode -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppbillToPostCode -- owner, use the billToPostCode from the org for the owner
            ELSE tmp.ppbillToPostCode -- member, so use profile value
        END,
    mu.billToCountryCode          =
        CASE
            WHEN tmp.ppppaymentProfileID IS NULL THEN tmp.ppbillToCountryCode -- no parent, so use profile value
            WHEN tmp.orgmainContactUserID = mu.userID THEN tmp.pppbillToCountryCode -- owner, use the billToCountryCode from the org for the owner
            ELSE tmp.ppbillToCountryCode -- member, so use profile value
        END,
    mu.trialStartDateTime         =
        CASE
            WHEN tmp.ppproductID = 1 THEN tmp.pppaymentStartDateTime -- 1=in trial
            ELSE mu.trialStartDateTime -- don't over write, this will stay the start date time of last trial
        END,
    -- get the end date from the paymentProfile, but it will be null if it is a team trial, if so, get it from the parent
    mu.trialEndDateDateTime       =
        CASE
            WHEN tmp.ppproductID = 1 THEN COALESCE(tmp.pppaymentEndDateTime, tmp.ppppaymentEndDateTime) -- 1=in trial,
            ELSE mu.trialEndDateDateTime -- don't over write, this will stay the end date time of last trial
        END,
    mu.organizationName           = tmp.orgname,
    mu.organizationID             = tmp.orgorganizationID,
    -- accountType changes should be triggered by parentPaymentProfileID changes
    mu.teamTrial                  =
        CASE
            WHEN tmp.ppaccountType = 2 AND tmp.ppproductID = 1 THEN 1
            ELSE 0
        END, -- teamTrial - set for member(accountType = 2) of trial(product = 1)
    mu.accountRole                = rpt_main_02.MARKETO_ACCOUNT_ROLE(mu.paymentProfileID, tmp.ppppaymentProfileID, tmp.orgmainContactUserID, mu.userID),
    mu.recurringBillingCancelled  = leadflow.MARKETO_RECURRING_BILLING_CANCELLED(tmp.ppppaymentProfileID, tmp.orgmainContactUserID,
                                                                                 mu.userID, tmp.pppaymentFlags, tmp.ppppaymentFlags)
;
SELECT '************************************* arc_marketo_upload rows updated from paymentProfile changes: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- FINISH Payment Profile updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************


-- When a change is made to paymentFlags for organizations --
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_paymentProfile_marketoSync ppp ON mu.parentPaymentProfileID = ppp.paymentProfileID AND ppp.accountType = 3
    JOIN ss_core_02.organization ON ppp.ownerID = organization.organizationID AND organization.mainContactUserID = mu.userID
SET
    mu.pushToMarketo             = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime            = CURRENT_TIMESTAMP(), -- since this is always an org, use the parent
    mu.recurringBillingCancelled = leadflow.MARKETO_RECURRING_BILLING_CANCELLED(ppp.paymentProfileID, organization.mainContactUserID, mu.userID,
                                                                       ppp.paymentFlags, ppp.paymentFlags)
WHERE
    COALESCE(mu.recurringBillingCancelled, -1) != leadflow.MARKETO_RECURRING_BILLING_CANCELLED(ppp.paymentProfileID, organization.mainContactUserID, mu.userID, ppp.paymentFlags, ppp.paymentFlags)
    AND COALESCE(mu.ppModifyDateTime, '') <= COALESCE(ppp.modifyDateTime, '')
;
SELECT '************************************* organization paymentFlags rows: ', ROW_COUNT(), NOW();

#######################################################################################################################
# Update isTrialRestart for all users with recent payment profile changes.
# (added 2017-08-10)
#######################################################################################################################

DROP TABLE IF EXISTS tmp_is_trial_restart;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_is_trial_restart
(PRIMARY KEY (paymentProfileID))
        SELECT
            pp.paymentProfileID,
            MAX(CASE WHEN hppPrev.productID IS NULL
                THEN 0
                ELSE 1 END) newIsTrialRestart
        FROM tmp_paymentProfile_marketoSync pp
            LEFT OUTER JOIN ss_core_02.hist_paymentProfile hpp
                ON pp.paymentProfileID = hpp.paymentProfileID
            LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppPrev
                ON hpp.paymentProfileID = hppPrev.paymentProfileID
                   # This accounts for 1 second delays in the hist_effectiveThruDateTime
                   AND (hpp.modifyDateTime = hppPrev.hist_effectiveThruDateTime + INTERVAL 1 SECOND
                        OR hpp.modifyDateTime = hppPrev.hist_effectiveThruDateTime)
                   # This will ignore previous records that were trials
                   AND (hppPrev.productID != 1 OR hppPrev.productID IS NULL)
        WHERE
            hpp.productID = 1
            AND (hppPrev.productID != 1 OR hppPrev.productID IS NULL)
            AND (hpp.modifyDateTime != hpp.hist_effectiveThruDateTime OR
                 hpp.modifyDateTime != hpp.hist_effectiveThruDateTime - INTERVAL 1 SECOND) # Ignore zero or negative second trials.
        GROUP BY pp.paymentProfileID;
SELECT '************************************* isTrialRestart rows: ', ROW_COUNT(), NOW();


UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_is_trial_restart tmp ON mu.paymentProfileID = tmp.paymentProfileID
SET
    mu.isTrialRestart = tmp.newIsTrialRestart,
    mu.pushToMarketo  = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    mu.isTrialRestart != tmp.newIsTrialRestart;
SELECT '************************************* isTrialRestart updates: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- Update orgProductName for all users who are members of organizations, whether licensed or not.
-- (added 2016-04-25)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp_org_pp_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_pp_updates
(PRIMARY KEY (userID))
    SELECT mu.userID
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN ss_core_02.organizationUserRole our ON mu.userID = our.userID
        JOIN ss_core_02.paymentProfile ppp ON our.organizationID = ppp.ownerID
    WHERE our.modifyDateTime >= @marketoLookbackDateTime
    UNION
    SELECT mu.userID
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN ss_core_02.organizationUserRole our ON mu.userID = our.userID
        JOIN ss_core_02.paymentProfile ppp ON our.organizationID = ppp.ownerID
    WHERE ppp.modifyDateTime >= @marketoLookbackDateTime
    ORDER BY userID
;
SELECT '************************************* organizationUserRole and paymentProfile updates: ', ROW_COUNT(), NOW();

DROP TABLE IF EXISTS tmp_max_org_product_name;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_max_org_product_name
(PRIMARY KEY (userID))
    SELECT
        mu.userID,
        -- Triple nested function: 1. Get max product by rank, 2. convert rank back to productID, 3. convert productID to product name.
        rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_main_02.SMARTSHEET_PRODUCTRANKCONVERT(MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(ppp.productID)))) maxOrgProduct
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN tmp_org_pp_updates uids ON mu.userID = uids.userID
        LEFT JOIN ss_core_02.organizationUserRole our ON mu.userID = our.userID AND our.state != 3              -- Ignore declined users
        LEFT JOIN ss_core_02.organization org ON our.organizationID = org.organizationID AND org.state = 1      -- Include only active orgs
        LEFT JOIN ss_core_02.paymentProfile ppp ON our.organizationID = ppp.ownerID AND ppp.accountType = 3     -- Just want org accounts
    GROUP BY mu.userID
;
SELECT '************************************* getting orgProductName rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_max_org_product_name mp ON mu.userID = mp.userID
SET
    mu.orgProductName = mp.maxOrgProduct,
    mu.pushToMarketo  = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.orgProductName, '') != COALESCE(mp.maxOrgProduct, '') -- COLLATE utf8mb4_unicode_520_ci
;
SELECT '************************************* updating orgProductName rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- (added 2016-06-23)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp_org_user_role_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_user_role_updates
(PRIMARY KEY (userID, organizationID))
    SELECT
        mu.userID,
        uid.organizationID,
        IFNULL(ppp.userLimit, 0)      paidLicenseLimit,
        IFNULL(ppp.bonusUserCount, 0) bonusLicenseLimit,
        IFNULL(SUM(our.state = 1), 0) assignedLicenseCount,
        IFNULL(SUM(our.state = 2), 0) pendingLicenseCount
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN (
                 (SELECT
                      our.userID,
                      our.organizationID
                  FROM ss_core_02.organizationUserRole our
                      JOIN (
                               SELECT organizationID
                               FROM ss_core_02.organizationUserRole
                               WHERE modifyDateTime >= @marketoLookbackDateTime
                               GROUP BY organizationID
                           ) updates ON our.organizationID = updates.organizationID
                  WHERE
                      our.role = 'USER_ADMIN'
                      AND our.state = 1)
                 UNION
                 (SELECT
                      mainContactUserID,
                      organizationID
                  FROM ss_core_02.organization
                  WHERE
                      modifyDateTime >= @marketoLookbackDateTime
                      AND state = 1)
                 ORDER BY 1 ASC
             ) uid ON mu.userID = uid.userID
        LEFT JOIN ss_core_02.paymentProfile ppp ON
                                                    uid.organizationID = ppp.ownerID
                                                    AND ppp.accountType = 3
        LEFT JOIN ss_core_02.organizationUserRole our ON
                                                          uid.organizationID = our.organizationID
                                                          AND our.role = 'LICENSE_USER'
                                                          AND our.state IN (1, 2)
    GROUP BY uid.userID, uid.organizationID
;
SELECT '************************************* getting org license limit rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_org_user_role_updates lic ON mu.userID = lic.userID
SET
    mu.userLimit            = lic.paidLicenseLimit,
    mu.bonusLicenseLimit    = lic.bonusLicenseLimit,
    mu.assignedLicenseCount = lic.assignedLicenseCount,
    mu.pendingLicenseCount  = lic.pendingLicenseCount,
    mu.pushToMarketo        = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime       = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.userLimit, '') != lic.paidLicenseLimit
    OR COALESCE(mu.bonusLicenseLimit, '') != lic.bonusLicenseLimit
    OR COALESCE(mu.assignedLicenseCount, '') != lic.assignedLicenseCount
    OR COALESCE(mu.pendingLicenseCount, '') != lic.pendingLicenseCount
;
SELECT '************************************* updating org license limit rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update organization license tags
-- (added 2016-07-05)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp_lic_tag_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_lic_tag_updates
(INDEX (userID))
    SELECT
        lic.userID,
        leadflow.MARKETO_LICENSE_TAG(lic.assignedLicenseCount, lic.pendingLicenseCount, lic.paidLicenseLimit,
                                     mu.previousUserLimit, COUNT(our.organizationUserRoleID)) licenseTags
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN tmp_org_user_role_updates lic ON mu.userID = lic.userID
        LEFT JOIN ss_core_02.organizationUserRole our
            ON lic.organizationID = our.organizationID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insertDateTime >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY lic.userID, lic.organizationID
;
SELECT '************************************* getting org license tag rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_lic_tag_updates tag ON mu.userID = tag.userID
SET
    mu.licenseTags    = tag.licenseTags,
    mu.pushToMarketo  = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.licenseTags, '') != COALESCE(tag.licenseTags, '') -- COLLATE utf8mb4_unicode_520_ci
;
SELECT '************************************* updating org license tag rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update last bulletin close date time
-- (added 2016-07-06)
-- *********************************************************************************************************************

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN (
             SELECT
                 ce.insertByUserID,
                 MAX(ce.eventDateTime) maxCloseDateTime
             FROM rpt_main_02.arc_clientEventBulletin ce
             WHERE
                 ce.eventDateTime >= @marketoLookbackDateTime
                 AND ce.objectID = 10717  -- 'Desktop - Bulletin Bar' object
                 AND ce.actionID = 2 -- 'Close' action
             GROUP BY ce.insertByUserID
             ORDER BY ce.insertByUserID
         ) maxClose ON mu.userID = maxClose.insertByUserID
SET
    mu.lastBulletinCloseDateTime = maxClose.maxCloseDateTime,
    mu.pushToMarketo             = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime            = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.lastBulletinCloseDateTime, '') != COALESCE(maxClose.maxCloseDateTime, '')
;
SELECT '************************************* updating last bulletin close date time rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update dashboardsEnabledStartDate for all userConfigSetting and orgConfigSetting changes in the last day.
-- configPropertyID = 4024 AND valueBoolean = 1 means the dashboards feature is enabled for a user or org
-- *********************************************************************************************************************

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
JOIN (
    -- Get all org setting users
    (SELECT our.userID FROM ss_account_02.orgConfigSetting ocs
    JOIN ss_core_02.organizationUserRole our ON ocs.organizationID = our.organizationID
    WHERE
        ocs.modifyDateTime >= @marketoLookbackDateTime
        AND ocs.configPropertyID = 4024
    GROUP BY our.userID)
    UNION
    -- Get all user setting users
    (SELECT ucs.userID FROM ss_account_02.userConfigSetting ucs
    WHERE
        ucs.modifyDateTime >= @marketoLookbackDateTime
        AND ucs.configPropertyID = 4024)
    UNION
    -- Get all current users to check if their enable date should be cleared
    (SELECT userID FROM rpt_workspace.jmarzinke_marketo_lead_seed
    WHERE dashboardsEnabledDateTime IS NOT NULL)
    ORDER BY userID
) uid ON mu.userID = uid.userID
LEFT OUTER JOIN ss_account_02.orgConfigSetting ocs ON mu.organizationID = ocs.organizationID AND ocs.configPropertyID = 4024
LEFT OUTER JOIN ss_account_02.userConfigSetting ucs ON mu.userID = ucs.userID AND ucs.configPropertyID = 4024
SET
    mu.dashboardsEnabledDateTime =
        CASE
            WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1 THEN ocs.modifyDateTime
            WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0 THEN NULL
            WHEN ucs.valueBoolean = 1 THEN ucs.modifyDateTime
            WHEN ucs.valueBoolean = 0 THEN NULL
            WHEN ocs.valueBoolean = 1 THEN ocs.modifyDateTime
            ELSE NULL
        END,
    mu.pushToMarketo = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.dashboardsEnabledDateTime, '') !=
        CASE
            WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1 THEN ocs.modifyDateTime
            WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0 THEN ''
            WHEN ucs.valueBoolean = 1 THEN ucs.modifyDateTime
            WHEN ucs.valueBoolean = 0 THEN ''
            WHEN ocs.valueBoolean = 1 THEN ocs.modifyDateTime
            ELSE ''
        END
;
SELECT '************************************* dashboardsEnabledDateTime rows: ', ROW_COUNT(), NOW();



-- *********************************************************************************************************************
-- BEGIN salesMarketingUserData updates for leadflow.arc_marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on ss_core_02 tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query #1: Grab the needed data from core tables and put it in a temporary table.
--     Query #2: Join temp table to tmp_marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query #1: Retrieve role information changes made to salesMarketingUserData records
DROP TABLE IF EXISTS tmp_salesMarketingUserData_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_salesMarketingUserData_to_sync
(INDEX (userID))
	SELECT smud.userID, smud.dataValue FROM rpt_workspace.jmarzinke_marketo_lead_seed mk_upload
	JOIN ss_core_02.salesMarketingUserData smud ON smud.userID = mk_upload.userID AND smud.dataKey = 'role'
	WHERE mk_upload.role IS NULL AND smud.dataValue IS NOT NULL  -- only update if need and have value
	ORDER BY mk_upload.userID ASC
;
SELECT '************************************* getting salesMarketingUserData rows: ', ROW_COUNT(), NOW();

-- Query #2: Update arc_marketo_upload with changes
UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mk_upload
JOIN tmp_salesMarketingUserData_to_sync tsmud ON mk_upload.userId = tsmud.userID
SET
	mk_upload.role = tsmud.dataValue,
	mk_upload.pushToMarketo = GREATEST(@updatePriority, mk_upload.pushToMarketo),	-- indicate record needs to be pushed, using GREATEST so we never lower the priority
	mk_upload.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT '************************************* updating salesMarketingUserData rows: ', ROW_COUNT(), NOW();

-- *********************************************************************************************************************
-- FINISH salesMarketingUserData updates for leadflow.arc_marketo_upload
-- *********************************************************************************************************************


-- *********************************************************************************************************************
-- Update organizationRoles for customers in the GE organization. We are adding an additional field to distinguish
-- whether a GE customer was added by a specific user in order to include them in specialized Marketo campaigns.
-- (added 2016-01-26 to account for special GE request; see MKTO1817 for details)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_ge_orgRoles;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_ge_orgRoles
(PRIMARY KEY (userID))
    SELECT
        our.userID,
        CONCAT_WS(';',
                  GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                  CASE WHEN org.mainContactUserID IS NOT NULL
                      THEN 'MAIN_CONTACT'
                  ELSE NULL END,
                  CONCAT('LICENSE_ADDED_BY:', COALESCE(our2.insertByUserID, 0))) newOrgRoles
    FROM ss_core_02.organizationUserRole our
        JOIN rpt_workspace.jmarzinke_marketo_lead_seed mu ON our.userID = mu.userID AND our.organizationID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
        LEFT JOIN ss_core_02.organizationUserRole our2 ON our.userID = our2.userID AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insertByUserID to be specifically from the LICENSE_USER role
        LEFT JOIN ss_core_02.organization org ON mu.userID = org.mainContactUserID AND org.state = 1
    GROUP BY our.userID
    ORDER BY our.userID ASC
;
SELECT '************************************* getting GE organizationRoles rows: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_ge_orgRoles orgRole ON mu.userID = orgRole.userID
SET
    mu.organizationRoles = orgRole.newOrgRoles,
    mu.pushToMarketo     = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime    = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.organizationRoles, '') != COALESCE(orgRole.newOrgRoles, '') COLLATE utf8mb4_unicode_520_ci
;
SELECT '************************************* updating GE organizationRoles rows: ', ROW_COUNT(), NOW();


-- *********************************************************************************************************************
-- Update customer success rep info for all leads where the CS info for the SFDC account has changed recently.
-- Need to create temp table of just recent data so the query is fast.
-- (added 2016-03-22)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_sfdc_domain_account_rep;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_rep
(INDEX (Domain_Name_URL__c))
    SELECT
        d.Domain_Name_URL__c,
        csu.Email     csEmail,
        csu.FirstName csFirstName,
        csu.LastName  csLastName,
        csu.Phone     csPhone,
        dou.Email     doEmail,
        dou.FirstName doFirstName,
        dou.LastName  doLastName,
        dou.Title     doTitle,
        dou.Phone     doPhone
    FROM ss_sfdc_02.domain d
        JOIN ss_sfdc_02.account a ON d.Account__c = a.Id
        LEFT JOIN ss_sfdc_02.user csu ON a.Customer_Success__c = csu.Id
        LEFT JOIN ss_sfdc_02.user dou ON d.OwnerId = dou.Id AND dou.ID != '00540000002nu18AAA' # Exclude Andrew Imhoff.
    WHERE
        (a.LastModifiedDate >= @marketoLookbackDateTime OR d.LastModifiedDate >= @marketoLookbackDateTime)
        # Ignore ISP domains. Use rpt_main_02.arc_ISPDomains instead of isOrgDomain field to avoid join on arc_marketo_upload.
        AND d.Domain_Name_URL__c NOT IN (SELECT domain
                                         FROM rpt_main_02.arc_ISPDomains)
;
SELECT '************************************* sfdc domain and account reps: ', ROW_COUNT(), NOW();

DROP TABLE IF EXISTS tmp_sfdc_domain_account_user;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_user
(INDEX (userID))
    SELECT
        mu.userID,
        d.*
    FROM rpt_workspace.jmarzinke_marketo_lead_seed mu
        JOIN tmp_sfdc_domain_account_rep d ON mu.emailDomain = d.Domain_Name_URL__c
        LEFT OUTER JOIN ss_core_02.organization org ON mu.userID = org.mainContactUserID AND org.state = 1
    WHERE
        (COALESCE(mu.successRepEmail, '') != COALESCE(d.csEmail, '')
         OR COALESCE(mu.successRepFirstName, '') != COALESCE(d.csFirstName, '')
         OR COALESCE(mu.successRepLastName, '') != COALESCE(d.csLastName, '')
         OR COALESCE(mu.successRepPhoneNumber, '') != COALESCE(d.csPhone, '')
         OR COALESCE(mu.domainOwnerEmail, '') != COALESCE(d.doEmail, '')
         OR COALESCE(mu.domainOwnerFirstName, '') != COALESCE(d.doFirstName, '')
         OR COALESCE(mu.domainOwnerLastName, '') != COALESCE(d.doLastName, '')
         OR COALESCE(mu.domainOwnerTitle, '') != COALESCE(d.doTitle, '')
         OR COALESCE(mu.domainOwnerPhoneNumber, '') != COALESCE(d.doPhone, ''))
        # Don't want to reintroduce leads who may have been purged.
        AND
        (org.mainContactUserID IS NOT NULL # MKTO3303 include all active org main contacts
         OR mu.productName IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR mu.orgProductName IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR COALESCE(mu.lastLogin, '2000-01-01') >= DATE_SUB(NOW(), INTERVAL 180 DAY))  # MKTO3290 include paid, trial, or active in last 180 days
    ORDER BY mu.userID ASC  # Need to order by userID to prevent deadlocks.
;
SELECT '************************************* sfdc account changes: ', ROW_COUNT(), NOW();

UPDATE rpt_workspace.jmarzinke_marketo_lead_seed mu
    JOIN tmp_sfdc_domain_account_user d ON mu.userID = d.userID
SET
    mu.successRepEmail        = d.csEmail,
    mu.successRepFirstName    = d.csFirstName,
    mu.successRepLastName     = d.csLastName,
    mu.successRepPhoneNumber  = d.csPhone,
    mu.domainOwnerEmail       = d.doEmail,
    mu.domainOwnerFirstName   = d.doFirstName,
    mu.domainOwnerLastName    = d.doLastName,
    mu.domainOwnerTitle       = d.doTitle,
    mu.domainOwnerPhoneNumber = d.doPhone,
    mu.pushToMarketo          = GREATEST(@updatePriority, mu.pushToMarketo),
    mu.updateDateTime         = CURRENT_TIMESTAMP()
;
SELECT '************************************* customer success rows: ', ROW_COUNT(), NOW();


-- **************************************************************************************************************************
-- FINISH Update all fields that need to be current
-- **************************************************************************************************************************

-- debug
SHOW VARIABLES LIKE 'tx_isolation';
