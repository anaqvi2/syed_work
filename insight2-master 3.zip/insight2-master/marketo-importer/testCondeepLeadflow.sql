use leadflow;
# Test sequence for comparing condeep to current leadflow in rpt_main)02
# Script assumes that 'syncLeadflow_and_rptMain' has been executed
# after the first leadseed has been created.

/* examine current latency between services */
select 'leadflow: amu' as datasource,max(ppModifyDateTime)
from leadflow.arc_marketo_upload
union
select 'rptMain: amu' as datasource,max(ppModifyDateTime)
from rpt_main_02.arc_marketo_upload
union
select 'leadflow: leadSeed' as datasource,max(ppModifyDateTime)
from leadflow.leadSeed
union
select 'ss_core' as datasource,modifyDateTime
from (select modifyDateTime from ss_core_02.paymentProfile order by paymentProfileId desc limit 1) x
union
select 'now' as datasource,now()
order by datasource;

# Identify the set of leads for fair comparison
drop table if exists AMUCompareLeads;
create table AMUCompareLeads as
select paymentProfileId
from rpt_main_02.arc_marketo_upload amu
where (amu.insertDateTime > (select insertDateTime from AMUCloneMax)
   )
  and greatest(amu.insertDateTime,updateDateTime) < date_sub(now(),interval 0 minute);

# Check counts of newly added rows.
# Expectation:  all columns of data should be identical for both tables
select 'leadflow: amu' as datasource,count(*), min(insertDateTime), max(insertDateTime)
       ,min(paymentProfileId)
       ,max(paymentProfileId)
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
union
select 'rptMain: amu' as datasource,count(*), min(insertDateTime), max(insertDateTime)
       ,min(paymentProfileId)
       ,max(paymentProfileId)
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads);

# Check for missing leads:  Expectation, no rows returned.
select *
from rpt_main_02.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
and paymentProfileId not in (select paymentProfileId 
                             from leadflow.arc_marketo_upload 
                             where insertDateTime > (select insertDateTime from AMUCloneMax));




/* Check for missing leadSeeds */
/* Assume ppIds are auto incremented */
#  Expectastion is that 'missingLeads = 0'
select count(*), min(ppModifyDateTime), max(ppModifyDateTime)
       ,min(paymentProfileId)
       ,max(paymentProfileId)
       ,max(paymentProfileId) - min(paymentProfileId) + 1 ppIdDiff
       ,(max(paymentProfileId) - min(paymentProfileId)) - count(*) + 1 missingLeads
from leadflow.leadSeed
where insertDateTime > (select insertDateTime from AMUCloneMax);


# Check for exact table diffs, if all 3 row counts match, then perfect
select 'leadflowRows' as db, count(*) as amuCount
from leadflow.arc_marketo_upload  
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
union
select 'rptMainRows' as db, count(*) as amuCount
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
union
select 'rowDiffs' as db, count(*) - (select count(*) from rpt_main_02.arc_marketo_upload
                                     where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
                                    ) as rowCount 
from (
select `arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    case when `arc_marketo_upload`.`monthlyPlanRate_USD` is null then 0.0 else monthlyPlanRate_USD end,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from leadflow.arc_marketo_upload 
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
union
select `arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    case when `arc_marketo_upload`.`monthlyPlanRate_USD` is null then 0.0 else monthlyPlanRate_USD end,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
) x;


# Identify row diffs for all new leads since AMU clone
drop table if exists leadflow.AMUdupsInsert;
create table AMUdupsInsert as 
select paymentProfileId, count(*)
from (
select `arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    case when `arc_marketo_upload`.`monthlyPlanRate_USD` is null then 0.0 else monthlyPlanRate_USD end,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from leadflow.arc_marketo_upload  
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
union
select 
`arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
   # `arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    case when `arc_marketo_upload`.`monthlyPlanRate_USD` is null then 0.0 else monthlyPlanRate_USD end,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from rpt_main_02.arc_marketo_upload  
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
) x
group by paymentProfileId
having count(*) > 1;


#  Examine contents of rows for all new leads since AMU clone
select 'leadflow' as db,
`arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    `arc_marketo_upload`.`billToAddress`,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdupsInsert)
union
select 'rptMain' as db, 
`arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    `arc_marketo_upload`.`billToAddress`,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress` 
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdupsInsert)
order by paymentProfileId, db;



/*
# Identify row differences for leads that were updated 
drop table if exists leadflow.AMUdupsUpdate;
create table AMUdupsUpdate as 
select paymentProfileId, count(*)
from (
select `arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    #`arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from leadflow.arc_marketo_upload  
where  (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
	and insertDateTime < (select insertDateTime from AMUCloneMax)
    #BMWand insertDateTime < (select date_sub(max(insertDateTime), interval 10 minute) from rpt_main_02.arc_marketo_upload) and updateDateTime < (select date_sub(max(insertDateTime), interval 10 minute) from rpt_main_02.arc_marketo_upload)
union
select 
`arc_marketo_upload`.`userID`,
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`updateDateTime`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
   # `arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    case when `arc_marketo_upload`.`billToAddress` is null then '' else `arc_marketo_upload`.`billToAddress` end as billToAddress,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from rpt_main_02.arc_marketo_upload
where (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
	and insertDateTime < (select insertDateTime from AMUCloneMax)
    #BMWand insertDateTime < (select date_sub(max(insertDateTime), interval 10 minute) from rpt_main_02.arc_marketo_upload) and updateDateTime < (select date_sub(max(insertDateTime), interval 10 minute) from rpt_main_02.arc_marketo_upload)
) x
group by paymentProfileId
having count(*) > 1;

# examine contents of rows for leads that were update.
select 'leadflow' as db,
`arc_marketo_upload`.`userID`,
    `arc_marketo_upload`.`pushToMarketo`,
    `arc_marketo_upload`.`insertDateTime`,
    `arc_marketo_upload`.`updateDateTime`,
    `arc_marketo_upload`.`uploadDateTime`,
    `arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    `arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    `arc_marketo_upload`.`billToAddress`,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress`
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdupsUpdate)
union
select 'rptMain' as db, 
`arc_marketo_upload`.`userID`,
    `arc_marketo_upload`.`pushToMarketo`,
    `arc_marketo_upload`.`insertDateTime`,
    `arc_marketo_upload`.`updateDateTime`,
    `arc_marketo_upload`.`uploadDateTime`,
    `arc_marketo_upload`.`uploadStatus`,
    `arc_marketo_upload`.`userAccountModifyDateTime`,
    `arc_marketo_upload`.`ppModifyDateTime`,
    `arc_marketo_upload`.`trialModifyDateTime`,
    `arc_marketo_upload`.`salesforceOwnerAtImport`,
    `arc_marketo_upload`.`salesforceStatus`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`salesforceLeadSource`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`isOrgDomain`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`newsFlags`,
    `arc_marketo_upload`.`statusFlags`,
    `arc_marketo_upload`.`locale`,
    `arc_marketo_upload`.`timeZone`,
    `arc_marketo_upload`.`ABTests`,
    `arc_marketo_upload`.`ipCountry`,
    `arc_marketo_upload`.`usedGoogleAuthentication`,
    `arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`domainUseInPastYear`,
    `arc_marketo_upload`.`currentDomainTrials`,
    `arc_marketo_upload`.`wasSharedToPriorToTrial`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`productName`,
    `arc_marketo_upload`.`accountRole`,
    `arc_marketo_upload`.`userLimit`,
    `arc_marketo_upload`.`paymentStartDateTime`,
    `arc_marketo_upload`.`nextPaymentDate`,
    `arc_marketo_upload`.`paymentTerm`,
    `arc_marketo_upload`.`planRate`,
    `arc_marketo_upload`.`monthlyPlanRate_USD`,
    `arc_marketo_upload`.`currencyCode`,
    `arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDateTime`,
    `arc_marketo_upload`.`trialEndDateDateTime`,
    `arc_marketo_upload`.`isTrialRestart`,
    `arc_marketo_upload`.`primaryContactPhone`,
    `arc_marketo_upload`.`billToAddress`,
    `arc_marketo_upload`.`billToCity`,
    `arc_marketo_upload`.`billToRegionCode`,
    `arc_marketo_upload`.`billToPostCode`,
    `arc_marketo_upload`.`billToCountryCode`,
    `arc_marketo_upload`.`organizationName`,
    `arc_marketo_upload`.`historyHighestPlan`,
    `arc_marketo_upload`.`signupTrackingKeyword`,
    `arc_marketo_upload`.`signupTracking_s_code`,
    `arc_marketo_upload`.`signupTracking_c_code`,
    `arc_marketo_upload`.`signupTracking_m_code`,
    `arc_marketo_upload`.`signupBucket`,
    `arc_marketo_upload`.`signupSource`,
    `arc_marketo_upload`.`signupSubSource`,
    `arc_marketo_upload`.`marketoTrackingCookie`,
    `arc_marketo_upload`.`lastLogin`,
    `arc_marketo_upload`.`lastMobileLogin`,
    `arc_marketo_upload`.`isEverWellQualified`,
    `arc_marketo_upload`.`isStrongLead`,
    `arc_marketo_upload`.`eventLogCount`,
    `arc_marketo_upload`.`loginCount`,
    `arc_marketo_upload`.`sheetCount`,
    `arc_marketo_upload`.`sharingCount`,
    `arc_marketo_upload`.`reportCount`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`churnRiskCategory`,
    `arc_marketo_upload`.`role`,
    `arc_marketo_upload`.`usedReminders`,
    `arc_marketo_upload`.`usedBrandedWorkspace`,
    `arc_marketo_upload`.`usedDriveAttachment`,
    `arc_marketo_upload`.`usedEvernoteAttachment`,
    `arc_marketo_upload`.`usedCellLinking`,
    `arc_marketo_upload`.`usedChangeView`,
    `arc_marketo_upload`.`discussionCount`,
    `arc_marketo_upload`.`importedSheetCount`,
    `arc_marketo_upload`.`templateCount`,
    `arc_marketo_upload`.`webFormCount`,
    `arc_marketo_upload`.`columnPropertyFormCount`,
    `arc_marketo_upload`.`hierarchyCount`,
    `arc_marketo_upload`.`attachmentCount`,
    `arc_marketo_upload`.`upgradeWizardProgress` 
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdupsUpdate)
order by paymentProfileId, db;


# Check salesforceowner distributions.
select * from
(
select 'leadflow' as datasource,salesforceOwnerAtImport, count(*) as leads
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
group by salesforceOwnerAtImport
) lf
left outer join
(select 'rpt_main' as datasource,salesforceOwnerAtImport, count(*) as leads
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
group by salesforceOwnerAtImport
) r
on lf.salesforceOwnerAtImport = r.salesforceOwnerAtImport
order by lf.leads desc;

#
select *
from
(
select paymentProfileId, salesforceOwnerAtImport, emailDomain
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
) lf
inner join
(select paymentProfileId, salesforceOwnerAtImport, emailDomain
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUCompareLeads)
) r
on lf.paymentProfileId = r.paymentProfileId
where lf.salesforceOwnerAtImport != r.salesforceOwnerAtImport
order by lf.paymentProfileId;
*/

####################  RESEARCH Queries below this line... disregard   ################################

# Check counts of newly added rows.
# Expectation:  all columns of data should be identical for both tables
/*
select 'leadflow: amu' as datasource,a.*
from leadflow.arc_marketo_upload a
where  (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
	and insertDateTime < (select insertDateTime from AMUCloneMax)
union
select 'rptMain: amu' as datasource,b.*
from rpt_main_02.arc_marketo_upload b
where (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
	and insertDateTime < (select insertDateTime from AMUCloneMax)
order by paymentProfileId, src;
*/



/*
# investigate a single column
select 'leadflow' as datasource,paymentProfileId, trialModifyDateTime
from leadflow.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdups)
union
select 'rpt_main' as datasource,paymentProfileId, trialModifyDateTime
from rpt_main_02.arc_marketo_upload
where paymentProfileId in (select paymentProfileId from AMUdups)
order by paymentProfileId, src;


select 'leadflow' as datasource,salesforceStatus, count(*) as leads
from leadflow.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
group by salesforceStatus
union
select 'rpt_main' as datasource,salesforceStatus, count(*) as leads
from rpt_main_02.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
group by salesforceStatus;

select * from
(
select 'leadflow' as datasource,salesforceOwnerAtImport, count(*) as leads
from leadflow.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
group by salesforceOwnerAtImport
) lf
left outer join
(select 'rpt_main' as datasource,salesforceOwnerAtImport, count(*) as leads
from rpt_main_02.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
group by salesforceOwnerAtImport
) r
on lf.salesforceOwnerAtImport = r.salesforceOwnerAtImport;



select 'leadflow' as datasource,paymentProfileId, firstName, lastName
from leadflow.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
union
select 'rpt_main' as datasource,paymentProfileId, firstName, lastName
from rpt_main_02.arc_marketo_upload
where insertDateTime > (select insertDateTime from AMUCloneMax)
order by paymentProfileId;


# Check counts of newly added rows.
# Expectation:  all columns of data should be identical for both tables
select 'leadflow: amu' as datasource,count(*), min(insertDateTime), max(insertDateTime)
       ,min(paymentProfileId)
       ,max(paymentProfileId)
from leadflow.arc_marketo_upload
where  (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
    and paymentProfileId <= (select max(paymentProfileId) from rpt_main_02.arc_marketo_upload)
union
select 'rptMain: amu' as datasource,count(*), min(insertDateTime), max(insertDateTime)
       ,min(paymentProfileId)
       ,max(paymentProfileId)
from rpt_main_02.arc_marketo_upload
where (userAccountModifyDateTime > (select insertDateTime from AMUCloneMax)
    or ppModifyDateTime > (select insertDateTime from AMUCloneMax))
;


*/






























