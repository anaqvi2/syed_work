# ***************************************************************************************************************************
#  These are queries to check the health status of Insight.
# ***************************************************************************************************************************
# SET @@sql_mode = '';
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
# show processlist;

# ***************************************************************************************************************************
#  Replication latency checks
# ***************************************************************************************************************************
SELECT MAX(sessionLogID) FROM ss_core_02.sessionLog INTO @MaxSessionLogID;
SELECT MAX(paymentProfileID) FROM ss_core_02.paymentProfile INTO @MaxPaymentProfileID;
SELECT MAX(userID) FROM ss_core_02.userAccount INTO @MaxUserID;
SELECT MAX(signupRequestTrackingItemID) FROM ss_account_02.signupRequestTrackingItem INTO @MaxSRTIID;
SELECT MAX(signupRequestID) FROM ss_account_02.signupRequest INTO @MaxSRID;
SELECT MAX(siteSettingElementValueID) FROM ss_account_02.siteSettingElementValue INTO @MaxSSEVID;
SELECT MAX(clientEventID) FROM ss_log_02.clientEvent INTO @MaxClientEventID;

SELECT 'ss_core_02.sessionLog', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_core_02.sessionLog WHERE sessionLogID = @MaxSessionLogID
UNION
SELECT 'ss_core_02.paymentProfile', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_core_02.paymentProfile WHERE paymentProfileID = @MaxPaymentProfileID
UNION
SELECT 'ss_core_02.userAccount', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_core_02.userAccount WHERE userID = @MaxUserID
UNION
SELECT 'ss_account_02.signupRequestTrackingItem', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_account_02.signupRequestTrackingItem WHERE signupRequestTrackingItemID = @MaxSRTIID
UNION
SELECT 'ss_account_02.signupRequest', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_account_02.signupRequest WHERE signupRequestID = @MaxSRID
UNION
SELECT 'ss_account_02.siteSettingElementValue', NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60/60, 2) HOURS
FROM ss_account_02.siteSettingElementValue WHERE siteSettingElementValueID = @MaxSSEVID
UNION
SELECT 'ss_log_02.clientEvent', NOW(), MAX(eventDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), eventDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), eventDateTime))/60, 2) MINS, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), eventDateTime))/60/60, 2) HOURS
FROM ss_log_02.clientEvent WHERE clientEventID = @MaxClientEventID
;

# SELECT MAX(paymentProfileID) FROM leadflow.leadSeed INTO @MaxPaymentProfileID;
# SELECT NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) DIFF, ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime))/60, 2) MIN FROM leadflow.leadSeed WHERE paymentProfileID = @MaxPaymentProfileID;
# SELECT
#     DATE_FORMAT(healthCheckDate, '%Y%m%d%H'),
#     max(replicationDelaySeconds)
# FROM rpt_main_02.arc_insightHealth
# GROUP BY DATE_FORMAT(healthCheckDate, '%Y%m%d%H')
# ORDER BY 1 DESC;

# SELECT *
# FROM rpt_main_02.arc_insightHealth
# ORDER BY healthCheckDate DESC;

# SELECT *, ROUND(replicationDelaySeconds/60) minutes, ROUND(replicationDelaySeconds/60/60, 1) hours FROM rpt_main_02.arc_insightHealth ORDER BY healthCheckDate DESC LIMIT 500;
#
# SELECT *, ROUND(replicationDelaySeconds/60) minutes, ROUND(replicationDelaySeconds/60/60, 1) hours FROM rpt_main_02.arc_insightHealthAccount ORDER BY healthCheckDate DESC LIMIT 500;
#
# SELECT *, ROUND(replicationDelaySeconds/60) minutes, ROUND(replicationDelaySeconds/60/60, 1) hours  FROM rpt_main_02.arc_insightHealthLog ORDER BY healthCheckDate DESC LIMIT 500;

# ***************************************************************************************************************************
#  Find all arc_marketo_upload records that still need to by synced
# ***************************************************************************************************************************
SELECT pushToMarketo, COUNT(*) FROM leadflow.arc_marketo_upload WHERE pushToMarketo != 0 GROUP BY 1 ORDER BY pushToMarketo DESC;
SELECT * FROM leadflow.arc_marketo_upload_sync_history WHERE recordCount > 0 ORDER BY insertDateTime DESC, syncFlag DESC LIMIT 1000;
# SELECT COUNT(1) FROM leadflow.arc_marketo_upload WHERE pushToMarketo IS NULL;
# SELECT * FROM leadflow.arc_marketo_upload_sync_history WHERE syncFlag = 10 ORDER BY insertDateTime DESC LIMIT 1000;
# select * from leadflow.arc_marketo_upload where pushToMarketo = 8;
#
# ***************************************************************************************************************************
# Marketo build times
# ***************************************************************************************************************************
SELECT
    qh.buildID ID,
    qh.buildSequence Sequence,
    qh.buildSource Source,
    qh.buildStep Step,
    qh.startTime,
    qh.endTime,
    CASE WHEN qh.timeElapsed IS NULL THEN TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) ELSE qh.timeElapsed END AS seconds,
    CASE WHEN qh.timeElapsed IS NULL THEN ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) / 60, 1) ELSE ROUND(qh.timeElapsed / 60, 1) END AS minutes,
    MAX(qh1.timeElapsed) AS "Prior 1",
    MAX(qh2.timeElapsed) AS "Prior 2",
    MAX(qh3.timeElapsed) AS "Prior 3",
    MAX(qh4.timeElapsed) AS "Prior 4",
    MAX(qh15.timeElapsed) AS "Prior 15"
FROM leadflow.arc_marketo_query_history qh
    LEFT JOIN leadflow.arc_marketo_query_history qh1 ON qh.buildStep = qh1.buildStep AND qh1.buildID = qh.buildID - 1
    LEFT JOIN leadflow.arc_marketo_query_history qh2 ON qh.buildStep = qh2.buildStep AND qh2.buildID = qh.buildID - 2
    LEFT JOIN leadflow.arc_marketo_query_history qh3 ON qh.buildStep = qh3.buildStep AND qh3.buildID = qh.buildID - 3
    LEFT JOIN leadflow.arc_marketo_query_history qh4 ON qh.buildStep = qh4.buildStep AND qh4.buildID = qh.buildID - 4
    LEFT JOIN leadflow.arc_marketo_query_history qh15 ON qh.buildStep = qh15.buildStep AND qh15.buildID = qh.buildID - 15
WHERE qh.buildSource IN ('Marketo Nightly', 'Marketo Tableau Daily', 'Marketo Tableau Weekly')
GROUP BY qh.buildID, qh.buildSequence
ORDER BY qh.buildID DESC, qh.buildSequence DESC
;

# SELECT
#     qh.buildID ID,
#     qh.buildSequence Sequence,
#     qh.buildSource Source,
#     qh.buildStep Step,
#     qh.startTime,
#     qh.endTime,
#     CASE WHEN qh.timeElapsed IS NULL THEN TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) ELSE qh.timeElapsed END AS seconds,
#     CASE WHEN qh.timeElapsed IS NULL THEN ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) / 60, 1) ELSE ROUND(qh.timeElapsed / 60, 1) END AS minutes
# FROM leadflow.arc_marketo_query_history qh
# WHERE qh.buildSource = 'Marketo Tableau Hourly'
# GROUP BY qh.buildID, qh.buildSequence
# ORDER BY qh.buildID DESC, qh.buildSequence DESC
# ;
#
# ***************************************************************************************************************************
#  InsightThrowaway build times
# ***************************************************************************************************************************
SELECT
    qh.buildNumber,
    qh.prepSequence,
    qh.tableName,
    qh.startTime,
    CASE WHEN qh.timeElapsed IS NULL THEN TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) + .01 ELSE qh.timeElapsed END AS seconds,
    CASE WHEN qh.timeElapsed IS NULL THEN ROUND(TIME_TO_SEC(TIMEDIFF(NOW(), qh.startTime)) / 60, 1) + .01 ELSE ROUND(qh.timeElapsed / 60, 1) END AS minutes,
    qh1.timeElapsed AS "Prior 1",
    qh2.timeElapsed AS "Prior 2",
#     qh3.timeElapsed AS "Prior 3",
#     qh4.timeElapsed AS "Prior 4"
    qh15.timeElapsed AS "Prior 15"
FROM rpt_main_02.arc_prepV2QueryHistory qh
    LEFT JOIN rpt_main_02.arc_prepV2QueryHistory qh1 ON qh.tableName = qh1.tableName AND qh1.buildNumber = qh.buildNumber - 1
    LEFT JOIN rpt_main_02.arc_prepV2QueryHistory qh2 ON qh.tableName = qh2.tableName AND qh2.buildNumber = qh.buildNumber - 2
#     LEFT JOIN rpt_main_02.arc_prepV2QueryHistory qh3 ON qh.tableName = qh3.tableName AND qh3.buildNumber = qh.buildNumber - 3
#     LEFT JOIN rpt_main_02.arc_prepV2QueryHistory qh4 ON qh.tableName = qh4.tableName AND qh4.buildNumber = qh.buildNumber - 4
    LEFT JOIN rpt_main_02.arc_prepV2QueryHistory qh15 ON qh.tableName = qh15.tableName AND qh15.buildNumber = qh.buildNumber - 15
WHERE qh.buildNumber >= (SELECT MAX(buildNumber) FROM rpt_main_02.arc_prepV2QueryHistory) - 1
ORDER BY qh.buildNumber DESC, qh.prepSequence DESC
;

# SELECT COUNT(1)
# FROM rpt_main_02.rpt_csReport
# ;
#
# SELECT accountHealth, accountTier, AccountToBeAssigned, territory
# FROM rpt_main_02.rpt_csReport
# LIMIT 100000
# ;

# ***************************************************************************************************************************
#  Marketo Lead Activity Cursor Dates
# ***************************************************************************************************************************
SELECT
    activityTypeId,
    max(activityDateTime) maxDateTime
FROM leadflow.arc_marketo_lead_activity
WHERE activityTypeId IN (2, 6, 7, 8, 9, 10, 11, 27)
GROUP BY activityTypeId
UNION ALL
SELECT
    activityTypeId,
    max(activityDateTime) maxDateTime
FROM leadflow.arc_marketo_activity_nurture
GROUP BY activityTypeId
UNION ALL
SELECT
    activityTypeId,
    max(activityDateTime) maxDateTime
FROM leadflow.arc_marketo_activity_program_status_progression
GROUP BY activityTypeId
;

# SELECT LEAST(
#            MAX(sendDateTime),
#            MAX(deliverDateTime),
#            MAX(openDateTime),
#            MAX(clickDateTime),
#            MAX(bounceDateTime),
#            MAX(softBounceDateTime),
#            MAX(unsubscribeDateTime)
#        ) leastMaxEmailActivityDateTime
# FROM leadflow.arc_marketo_email_activity
# ;

# ***************************************************************************************************************************
#  Marketo Lead Lists
# ***************************************************************************************************************************
# SELECT
#     listID,
#     listName,
#     count(leadID) numLeads
# FROM leadflow.arc_marketo_lead_lists
# GROUP BY listID, listName
# ;
#
#
# ***************************************************************************************************************************
#  Salesforce Importer Queues
# ***************************************************************************************************************************
SELECT 'Contacts', COUNT(*) FROM ss_sfdc_02.arc_sfdc_contact_upload
UNION ALL
SELECT 'Leads', COUNT(*) FROM ss_sfdc_02.arc_sfdc_lead_upload
UNION ALL
SELECT 'Domains', COUNT(*) FROM ss_sfdc_02.arc_sfdc_domainUpload
UNION ALL
SELECT 'Transactions', COUNT(*) FROM ss_sfdc_02.arc_sfdc_insight_data_integrators
;

# SELECT * FROM ss_sfdc_02.arc_sfdc_upload_cursor
# ORDER BY cursorID DESC
# LIMIT 100
# ;

# SELECT 'account', MAX(lastModifiedDate) FROM ss_sfdc_02.account UNION
# SELECT 'campaign', MAX(lastModifedDate) FROM ss_sfdc_02.campaign UNION
# SELECT 'campaign_member', MAX(lastModifiedDate) FROM ss_sfdc_02.campaign_member UNION
# SELECT 'case', MAX(lastModifiedDate) FROM ss_sfdc_02.case UNION
# SELECT 'contact', MAX(lastModifiedDate) FROM ss_sfdc_02.contact UNION
# SELECT 'domain', MAX(lastModifiedDate) FROM ss_sfdc_02.domain UNION
# SELECT 'lead', MAX(lastModifiedDate) FROM ss_sfdc_02.lead UNION
# SELECT 'opportunity', MAX(lastModifiedDate) FROM ss_sfdc_02.opportunity UNION
# SELECT 'opportunity_contact_role', MAX(lastModifiedDate) FROM ss_sfdc_02.opportunity_contact_role UNION
# SELECT 'opportunity_team_member', MAX(lastModifiedDate) FROM ss_sfdc_02.opportunity_team_member UNION
# SELECT 'record_type', MAX(lastModifiedDate) FROM ss_sfdc_02.record_type UNION
# SELECT 'services', MAX(lastModifiedDate) FROM ss_sfdc_02.services UNION
# SELECT 'task', MAX(lastModifiedDate) FROM ss_sfdc_02.task UNION
# SELECT 'use_case', MAX(lastModifiedDate) FROM ss_sfdc_02.use_case UNION
# SELECT 'user', MAX(lastModifiedDate) FROM ss_sfdc_02.user UNION
# SELECT 'user_role', MAX(lastModifiedDate) FROM ss_sfdc_02.user_role;

# ***************************************************************************************************************************
#  Update Marketo Sync Queue
# ***************************************************************************************************************************
# INSERT INTO leadflow.arc_marketo_upload_sync_history
# SELECT NOW(), 'marketoLeadsUploadCondeep.sql', muf.priority, COUNT(mu.userID)
# FROM leadflow.arc_marketo_upload_flags muf
# LEFT OUTER JOIN leadflow.arc_marketo_upload mu ON muf.priority = mu.pushToMarketo
# WHERE muf.priority != 0
# GROUP BY muf.priority
# ORDER BY muf.priority DESC
# ;
#
# ***************************************************************************************************************************
#  Miscellaneous queries
# ***************************************************************************************************************************
# SHOW FULL PROCESSLIST;
# select * from leadflow.arc_marketo_upload WHERE fitScore > 50 order by userID desc limit 500;
# select count(*) from leadflow.arc_marketo_upload;
# show variables where Variable_name like '%wait%';
# select * from leadflow.arc_marketo_upload where userID = 12095024;
#
# select max(userID) from leadflow.arc_marketo_upload;
# select * from rpt_main_02.arc_prepV2QueryHistory order by startTime desc;
#
# SET @disable_triggers = 1;
#
# UPDATE leadflow.arc_marketo_upload
# SET pushToMarketo = 0
# WHERE pushToMarketo = 1;
#
# SET @disable_triggers = NULL;
#
#
# ***************************************************************************************************************************
#  Insight Disk Space
# ***************************************************************************************************************************
# SELECT
#     table_schema,
#     table_name,
#     engine,
#     round(sum(data_length + index_length) / 1024 / 1024, 2) AS size_in_mb
# FROM information_schema.tables
# WHERE table_schema = 'leadflow' AND (table_name LIKE 'stg%' or table_name like 'tmp%') and table_name != 'tmp_company'
# GROUP BY table_schema, table_name
# ORDER BY size_in_mb
# DESC LIMIT 80;
