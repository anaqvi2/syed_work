-- ***************************************************************************************************************************
--  These are scripts to run manually as needed.  Checked into source control for safe keeping.
-- ***************************************************************************************************************************


-- ***************************************************************************************************************************
--  Find all arc_marketo_upload records that still need to by sync'd
-- ***************************************************************************************************************************
SELECT pushToMarketo, COUNT(*) FROM leadflow.arc_marketo_upload WHERE pushToMarketo != 0 GROUP BY 1;


-- ***************************************************************************************************************************
--  Find all users (trial or licensed seat holders) who should be in arc_marketo_upload but are not yet.
-- ***************************************************************************************************************************
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT pp.*
FROM ss_core_02.paymentProfile pp
LEFT OUTER JOIN leadflow.arc_marketo_upload mu ON mu.paymentProfileID = pp.paymentProfileID
WHERE (productID = 1 OR productID >= 3) -- in trial or paid, 1=trial, 2=free, 3=basic
	AND pp.accountType != 3			    -- not an org accountType
	AND mu.paymentProfileID IS NULL     -- doesn't already exist in the upload table
	AND pp.ownerID >= 1000000           -- the starting range of the real records
LIMIT 50000;


-- ***************************************************************************************************************************
--  Check and sync all leads to their current userAccount data.
--  This code is not going against history tables and is doing a table scan.  Using insert/select then update to avoid locking core.
-- ***************************************************************************************************************************
USE leadflow; 

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @updatePriority = 7;

DROP TABLE IF EXISTS stg_leads_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS stg_leads_to_sync LIKE ss_core_02.userAccount;

-- find all the records in ss_core_02.userAccount that don't match their respective records in leadflow.arc_marketo_upload
INSERT stg_leads_to_sync 
SELECT ua.* FROM leadflow.arc_marketo_upload mk_upload  -- to find the count, run without the insert in the above line
JOIN ss_core_02.userAccount ua ON mk_upload.userID = ua.userID  
WHERE 
	(mk_upload.emailAddress != ua.emailAddress OR			  -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
	-- mk_upload.emailDomain != ua.emailDomain OR 			 -- don't need emailDomain or website because emailAddress change will trigger these
	COALESCE(mk_upload.firstName, "") != COALESCE(ua.firstName, "") OR	-- could be null so use coalesce for null handling
	COALESCE(mk_upload.lastName, "") != rpt_main_02.MARKETO_LAST_NAME(ua.lastName) OR 
	COALESCE(mk_upload.newsFlags, "") != COALESCE(ua.newsFlags, "") OR
	COALESCE(mk_upload.statusFlags, "") != COALESCE(ua.statusFlags, "") OR
	COALESCE(mk_upload.locale, "") != COALESCE(ua.locale, "") OR
	COALESCE(mk_upload.timeZone, "") != COALESCE(ua.timeZone, "") OR
	COALESCE(mk_upload.userAccountModifyDateTime, "") != COALESCE(ua.modifyDateTime, "")
    )
	AND COALESCE(mk_upload.userAccountModifyDateTime, "") <= COALESCE(ua.modifyDateTime, "")  -- only if the modifyDateTime is changed in the right direction
	AND mk_upload.pushToMarketo != 10  -- Fix for MKTO1603. This prevents creating duplicate lead records (by userID) in Marketo if user changes email address immediately after creating account
LIMIT 123456
;

-- insert additional leads to sync for isOrgDomain flag,
-- needs to be done in separate step because emailDomain needs to be updated first before isOrgDomain can be set
INSERT IGNORE stg_leads_to_sync 
SELECT ua.* FROM leadflow.arc_marketo_upload mk_upload
JOIN ss_core_02.userAccount ua ON mk_upload.userID = ua.userID 
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON mk_upload.emailDomain = arc_ISPDomains.domain
WHERE
    ((arc_ISPDomains.domain IS NOT NULL AND mk_upload.isOrgDomain = 1)  OR (arc_ISPDomains.domain IS NULL AND mk_upload.isOrgDomain = 0))
    AND COALESCE(mk_upload.userAccountModifyDateTime, "") <= COALESCE(ua.modifyDateTime, "")
LIMIT 123456
;

UPDATE leadflow.arc_marketo_upload mk_upload
JOIN stg_leads_to_sync ua ON mk_upload.userID = ua.userID
SET 
	mk_upload.pushToMarketo = GREATEST(@updatePriority,mk_upload.pushToMarketo),	-- indicate record needs to be pushed, using GREATEST so we never lower the priority
	mk_upload.updateDateTime = CURRENT_TIMESTAMP(),								
	mk_upload.userAccountModifyDateTime = ua.modifyDateTime,	-- reset the flag to indicate when it last changed
	mk_upload.emailAddress = ua.emailAddress,		
	mk_upload.emailDomain = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),
	mk_upload.website = rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress),    			-- uses same value as domain for now 
	mk_upload.firstName = ua.firstName,
	mk_upload.lastName = rpt_main_02.MARKETO_LAST_NAME(ua.lastName),
	mk_upload.newsFlags = ua.newsFlags,
	mk_upload.appOptOut = NOT(ua.newsFlags & 1),
	mk_upload.statusFlags = ua.statusFlags,
	mk_upload.isUserAgreementAccepted = CASE WHEN ua.statusFlags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in statusFlags bitmask, which is 1000 in binary (8 in decimal)
	mk_upload.locale = ua.locale,
	mk_upload.timeZone = ua.timeZone
;

UPDATE leadflow.arc_marketo_upload mk_upload
JOIN stg_leads_to_sync ua ON mk_upload.userID = ua.userID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON mk_upload.emailDomain = arc_ISPDomains.domain
SET 
	mk_upload.pushToMarketo = GREATEST(@updatePriority,mk_upload.pushToMarketo),	-- indicate record needs to be pushed, using GREATEST so we never lower the priority
	mk_upload.updateDateTime = CURRENT_TIMESTAMP(),								
	mk_upload.isOrgDomain = CASE WHEN arc_ISPDomains.domain IS NULL THEN 1 ELSE 0 END
;



-- ***************************************************************************************************************************
--  NEW VERSION
--  Check and sync all leads to their current paymentProfile data.
--  This code is not going against history tables and is doing a table scan.  Using insert/select then update to avoid locking core.
-- ***************************************************************************************************************************

USE leadflow;

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @updatePriority = 7;

DROP TABLE IF EXISTS test_coreTableData_to_sync;
CREATE TABLE IF NOT EXISTS test_coreTableData_to_sync
AS (
    SELECT
        mk_upload.userID,
        hce.exchangeRate               hceexchangeRate,
        organization.mainContactUserID organizationmainContactUserID,
        organization.name              organizationname,
        organization.organizationID    organizationorganizationID,
        parentPP.billToAddress1        parentPPbillToAddress1,
        parentPP.billToAddress2        parentPPbillToAddress2,
        parentPP.billToCity            parentPPbillToCity,
        parentPP.billToCountryCode     parentPPbillToCountryCode,
        parentPP.billToPostCode        parentPPbillToPostCode,
        parentPP.billToRegionCode      parentPPbillToRegionCode,
        parentPP.currencyCode          parentPPcurrencyCode,
        parentPP.paymentEndDateTime    parentPPpaymentEndDateTime,
        parentPP.paymentFlags          parentPPpaymentFlags,
        parentPP.paymentProfileID      parentPPpaymentProfileID,
        parentPP.paymentStartDateTime  parentPPpaymentStartDateTime,
        parentPP.paymentTerm           parentPPpaymentTerm,
        parentPP.planRate              parentPPplanRate,
        parentPP.primaryContactPhone   parentPPprimaryContactPhone,
        pp.accountType                 ppaccountType,
        pp.billToAddress1              ppbillToAddress1,
        pp.billToAddress2              ppbillToAddress2,
        pp.billToCity                  ppbillToCity,
        pp.billToCountryCode           ppbillToCountryCode,
        pp.billToPostCode              ppbillToPostCode,
        pp.billToRegionCode            ppbillToRegionCode,
        pp.currencyCode                ppcurrencyCode,
        pp.modifyDateTime              ppmodifyDateTime,
        pp.nextPaymentDate             ppnextPaymentDate,
        pp.paymentProfileID            pppaymentProfileID,
        pp.parentPaymentProfileID      ppparentPaymentProfileID,
        pp.paymentEndDateTime          pppaymentEndDateTime,
        pp.paymentFlags                pppaymentFlags,
        pp.paymentStartDateTime        pppaymentStartDateTime,
        pp.paymentTerm                 pppaymentTerm,
        pp.planRate                    ppplanRate,
        pp.primaryContactPhone         ppprimaryContactPhone,
        pp.productID                   ppproductID,
        pp.userLimit                   ppuserLimit,
        mk_upload.userLimit            previousUserLimit
    FROM arc_marketo_upload mk_upload
	JOIN ss_core_02.paymentProfile pp ON mk_upload.paymentProfileID = pp.paymentProfileID
    LEFT OUTER JOIN ss_core_02.paymentProfile parentPP ON pp.parentPaymentProfileID = parentPP.paymentProfileID
    LEFT OUTER JOIN ss_core_02.organization ON parentPP.ownerID = organization.organizationID AND parentPP.accountType = 3
    LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode AND pp.paymentStartDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
    WHERE
        (COALESCE(mk_upload.productName, "") != rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) OR   -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
         COALESCE(mk_upload.userLimit, '') != COALESCE(pp.userLimit, '') OR
         COALESCE(mk_upload.parentPaymentProfileID, 0) != COALESCE(pp.parentPaymentProfileID,0) OR 	-- could be null so use coalesce for null handling
         mk_upload.paymentStartDateTime !=
            CASE
                WHEN
                    pp.accountType = 2 AND
                    pp.productID = 7 AND
                    pp.paymentStartDateTime < COALESCE(parentPP.paymentStartDateTime, "")
                THEN parentPP.paymentStartDateTime
                ELSE pp.paymentStartDateTime
            END OR
         (COALESCE(mk_upload.trialEndDateDateTime, "") != COALESCE(pp.paymentEndDateTime, parentPP.paymentEndDateTime) AND pp.productID = 1) OR
         COALESCE(mk_upload.nextPaymentDate, 0) != COALESCE(pp.nextPaymentDate, 0) OR  -- could be null so use coalesce for null handling
         mk_upload.paymentTerm != pp.paymentTerm OR
         (mk_upload.planRate != pp.planRate AND parentPP.paymentProfileID IS NULL) OR  -- the planRate is changed and there is no parent
         (mk_upload.planRate != parentPP.planRate AND organization.mainContactUserID = mk_upload.userID) OR  -- the planRate is changed from the parent value
         mk_upload.currencyCode != pp.currencyCode OR
         mk_upload.recurringBillingCancelled !=  leadflow.MARKETO_RECURRING_BILLING_CANCELLED(parentPP.paymentProfileID, organization.mainContactUserID, mk_upload.userID, pp.paymentFlags, parentPP.paymentFlags) OR
        -- don't need to trigger off of monthlyPlanRate_USD because two inputs planRate and paymentTerm already trigger
        -- mk_upload.monthlyPlanRate_USD != CASE WHEN pp.currencyCode = 'USD' THEN pp.planRate/pp.paymentTerm ELSE (pp.planRate/hce.exchangeRate)/pp.paymentTerm END,

         (COALESCE(mk_upload.primaryContactPhone, "") != COALESCE(pp.primaryContactPhone, "") AND parentPP.paymentProfileID IS NULL) OR  -- the primaryContactPhone is changed and there is no parent
         (COALESCE(mk_upload.primaryContactPhone, "") != COALESCE(parentPP.primaryContactPhone, "") AND organization.mainContactUserID = mk_upload.userID ) OR  -- the primaryContactPhone is changed from the parent value

         (COALESCE(mk_upload.billToAddress, "") != rpt_main_02.MARKETO_BILLING_ADDRESS(pp.billToAddress1, pp.billToAddress2) AND parentPP.paymentProfileID IS NULL) OR  -- the billToAddress is changed and there is no parent
         (COALESCE(mk_upload.billToAddress, "") != rpt_main_02.MARKETO_BILLING_ADDRESS(parentPP.billToAddress1, parentPP.billToAddress2) AND organization.mainContactUserID = mk_upload.userID ) OR  -- the billToAddress is changed from the parent value

         (COALESCE(mk_upload.billToCity, "") != COALESCE(pp.billToCity, "") AND parentPP.paymentProfileID IS NULL) OR  -- the billToCity is changed and there is no parent
         (COALESCE(mk_upload.billToCity, "") != COALESCE(parentPP.billToCity, "") AND organization.mainContactUserID = mk_upload.userID ) OR  -- the billToCity is changed from the parent value

         (COALESCE(mk_upload.billToRegionCode, "") != COALESCE(pp.billToRegionCode, "") AND parentPP.paymentProfileID IS NULL) OR  -- the billToRegionCode is changed and there is no parent
         (COALESCE(mk_upload.billToRegionCode, "") != COALESCE(parentPP.billToRegionCode, "") AND organization.mainContactUserID = mk_upload.userID ) OR  -- the billToRegionCode is changed from the parent value

         (COALESCE(mk_upload.billToPostCode, "") != COALESCE(pp.billToPostCode, "") AND parentPP.paymentProfileID IS NULL) OR  -- the billToPostCode is changed and there is no parent
         (COALESCE(mk_upload.billToPostCode, "") != COALESCE(parentPP.billToPostCode, "") AND organization.mainContactUserID = mk_upload.userID ) OR  -- the billToPostCode is changed from the parent value

         (COALESCE(mk_upload.billToCountryCode, "") != COALESCE(pp.billToCountryCode, "") AND parentPP.paymentProfileID IS NULL) OR  -- the billToCountryCode is changed and there is no parent
         (COALESCE(mk_upload.billToCountryCode, "") != COALESCE(parentPP.billToCountryCode, "") AND organization.mainContactUserID = mk_upload.userID )  -- the billToCountryCode is changed from the parent value
        )
        AND COALESCE(mk_upload.ppModifyDateTime, "") <= COALESCE(pp.modifyDateTime, "")
    ORDER BY mk_upload.userID ASC
);
SELECT "************************************* temporary table rows grabbed from core database: " ,ROW_COUNT(), NOW();

UPDATE arc_marketo_upload mk_upload
JOIN test_coreTableData_to_sync tmp ON mk_upload.userID = tmp.userID
SET
    mk_upload.pushToMarketo = GREATEST(@updatePriority,mk_upload.pushToMarketo),	-- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mk_upload.updateDateTime = CURRENT_TIMESTAMP(),
    mk_upload.ppModifyDateTime = tmp.ppmodifyDateTime,					-- reset the flag to indicate when it last changed
    mk_upload.productName = rpt_main_02.SMARTSHEET_PRODUCTNAME(tmp.ppproductID),
    mk_upload.userLimit = tmp.ppuserLimit,
    mk_upload.previousUserLimit = tmp.previousUserLimit,
    mk_upload.paymentStartDateTime =
        CASE
            WHEN
                tmp.ppaccountType = 2 AND
                tmp.ppproductID = 7 AND
                tmp.pppaymentStartDateTime < COALESCE(tmp.parentPPpaymentStartDateTime, "")
            THEN tmp.parentPPpaymentStartDateTime
            ELSE tmp.pppaymentStartDateTime
        END,
    -- get the date from the parent, will be null if no parent
    mk_upload.parentPaymentStartDateTime = tmp.parentPPpaymentStartDateTime,
    mk_upload.nextPaymentDate = tmp.ppnextPaymentDate,
    mk_upload.paymentTerm = tmp.pppaymentTerm,
    mk_upload.planRate =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppplanRate  -- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPplanRate  -- owner, use the planRate from the org for the owner
            ELSE tmp.ppplanRate 											-- member, so use profile value
        END,
    mk_upload.currencyCode = tmp.ppcurrencyCode,
    mk_upload.monthlyPlanRate_USD = COALESCE(
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN
                CASE
                    WHEN tmp.ppcurrencyCode = 'USD'
                    THEN tmp.ppplanRate/tmp.pppaymentTerm
                    ELSE (tmp.ppplanRate/tmp.hceexchangeRate)/tmp.pppaymentTerm
                END  -- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN --  owner, use the planRate from the org for the owner
                CASE
                    WHEN tmp.parentPPcurrencyCode = 'USD'
                    THEN tmp.parentPPplanRate/tmp.parentPPpaymentTerm
                    ELSE (tmp.parentPPplanRate/tmp.hceexchangeRate)/tmp.parentPPpaymentTerm
                END
            ELSE
                CASE
                    WHEN tmp.ppcurrencyCode = 'USD'
                    THEN tmp.ppplanRate/tmp.pppaymentTerm
                    ELSE (tmp.ppplanRate/tmp.hceexchangeRate)/tmp.pppaymentTerm
                END  -- member, so use profile value
        END, 0),
    mk_upload.parentPaymentProfileID = tmp.ppparentPaymentProfileID,
    mk_upload.primaryContactPhone =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppprimaryContactPhone  						-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPprimaryContactPhone  	-- owner, use the primaryContactPhone from the org for the owner
            ELSE tmp.ppprimaryContactPhone 																-- member, so use profile value
        END,
    mk_upload.billToAddress =  -- combine to address fields into one billToAddress
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.ppbillToAddress1, tmp.ppbillToAddress2) 	-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.parentPPbillToAddress1, tmp.parentPPbillToAddress2)  	-- owner, use the billToAddress from the org for the owner
            ELSE rpt_main_02.MARKETO_BILLING_ADDRESS(tmp.ppbillToAddress1, tmp.ppbillToAddress2)											-- member, so use profile value
        END,
    mk_upload.billToCity =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppbillToCity  						-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPbillToCity  	-- owner, use the billToCity from the org for the owner
            ELSE tmp.ppbillToCity 																	-- member, so use profile value
        END,
    mk_upload.billToRegionCode =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppbillToRegionCode  						-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPbillToRegionCode  	-- owner, use the billToRegionCode from the org for the owner
            ELSE tmp.ppbillToRegionCode 																-- member, so use profile value
        END,
    mk_upload.billToPostCode =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppbillToPostCode  						-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPbillToPostCode  	-- owner, use the billToPostCode from the org for the owner
            ELSE tmp.ppbillToPostCode 																-- member, so use profile value
        END,
    mk_upload.billToCountryCode =
        CASE
            WHEN tmp.parentPPpaymentProfileID IS NULL THEN tmp.ppbillToCountryCode  						-- no parent, so use profile value
            WHEN tmp.organizationmainContactUserID = mk_upload.userID THEN tmp.parentPPbillToCountryCode  	-- owner, use the billToCountryCode from the org for the owner
            ELSE tmp.ppbillToCountryCode 																-- member, so use profile value
        END,
    mk_upload.trialStartDateTime =
        CASE
            WHEN tmp.ppproductID = 1  THEN tmp.pppaymentStartDateTime  -- 1=in trial
            ELSE mk_upload.trialStartDateTime 					-- don't over write, this will stay the start date time of last trial
        END, -- trialStartDateTime,
    mk_upload.trialEndDateDateTime =
        CASE
            -- get the end date from the paymentProfile, but it will be null if it is a team trial, if so, get it from the parent
            WHEN tmp.ppproductID = 1  THEN COALESCE(tmp.pppaymentEndDateTime, tmp.parentPPpaymentEndDateTime)  -- 1=in trial,
            ELSE mk_upload.trialEndDateDateTime 						-- don't over write, this will stay the end date time of last trial
        END, -- trialEndDateDateTime,
    mk_upload.organizationName = tmp.organizationname,
    mk_upload.organizationID = tmp.organizationorganizationID,
    -- accountType changes should be triggered by parentPaymentProfileID changes
    mk_upload.teamTrial = CASE WHEN tmp.ppaccountType = 2 AND tmp.ppproductID = 1 THEN 1 ELSE 0 END, -- teamTrial - set for member(accountType = 2) of trial(product = 1)
    mk_upload.accountRole = rpt_main_02.MARKETO_ACCOUNT_ROLE(tmp.parentPPpaymentProfileID, tmp.organizationmainContactUserID, mk_upload.userID),
    mk_upload.recurringBillingCancelled = leadflow.MARKETO_RECURRING_BILLING_CANCELLED(tmp.parentPPpaymentProfileID, tmp.organizationmainContactUserID, mk_upload.userID, tmp.pppaymentFlags, tmp.parentPPpaymentFlags)
;
SELECT "************************************* arc_marketo_upload rows updated from paymentProfile changes: " ,ROW_COUNT(), NOW();


-- ***************************************************************************************************************************
--  Process for adding new fields to arc_marketo_upload table 
-- ***************************************************************************************************************************

-- manually pause marketo pull job so table is not modified anymore

-- check status of records to be synced
SELECT pushToMarketo, COUNT(*) FROM arc_marketo_upload WHERE pushToMarketo != 0 GROUP BY 1;

-- turn off records to be sync'd
UPDATE arc_marketo_upload
SET pushToMarketo = -2  -- adjust to fit remaining records
WHERE pushToMarketo = 2;

-- wait for importer job to finish

-- create a backup copy
CREATE TABLE arc_marketo_upload_backup LIKE arc_marketo_upload;
INSERT INTO arc_marketo_upload_backup SELECT * FROM arc_marketo_upload;

-- validate backup
SELECT COUNT(*) FROM arc_marketo_upload;
SELECT COUNT(*) FROM arc_marketo_upload_backup;

-- add new fields 
-- ALTER TABLE arc_marketo_upload ADD COLUMN fitScore TINYINT(3);  -- 11:18:683
-- ALTER TABLE arc_marketo_upload ADD COLUMN fitRating VARCHAR(10); -- 03:18:449
-- ALTER TABLE arc_marketo_upload ADD COLUMN appBehaviorScore INT(11);  -- 3:00:431
-- ALTER TABLE arc_marketo_upload ADD COLUMN appBehaviorScoreOld INT(11);  -- 2:10:636
-- ALTER TABLE arc_marketo_upload ADD COLUMN appBehaviorScoreNew INT(11);  -- 2:10:636
-- ALTER TABLE arc_marketo_upload ADD COLUMN recurringBillingCancelled TINYINT(1); -- 2:04:926
-- ALTER TABLE arc_marketo_upload ADD COLUMN domainOptOut TINYINT(1), ADD COLUMN appOptOut TINYINT(1); -- 3:01
-- ALTER TABLE arc_marketo_upload ADD COLUMN containerCount INT(11);  -- 04:46:808
ALTER TABLE arc_marketo_upload ADD COLUMN organizationRoles VARCHAR(200) NULL, ADD COLUMN inferredTitle VARCHAR(100) NULL; -- 00:00:383

-- turn on records to be sync'd
UPDATE arc_marketo_upload
SET pushToMarketo = 2
WHERE pushToMarketo = -2;

-- manually enable marketo pull job, validate working again



-- ***************************************************************************************************************************
--  Test table locking for queries
-- ***************************************************************************************************************************

-- Disable autocommit
SET autocommit = 0;

-- PUT QUERY TO TEST HERE

SELECT "************************************* Finished Updating Job Titles : ", ROW_COUNT(), NOW() ;

-- Check to see if the above query causes any table locks
SELECT * FROM information_schema.tokudb_lock_waits ;

SELECT COUNT(*), tkl.*, pl.* 
FROM information_schema.tokudb_locks tkl
  JOIN information_schema.PROCESSLIST pl 
    ON pl.ID = locks_mysql_thread_id 
WHERE (tkl.locks_table_schema = 'rpt_workspace' OR tkl.locks_table_schema = 'rpt_main_02' OR tkl.locks_table_schema = 'ss_core_02' OR tkl.locks_table_schema = 'leadflow') -- Just check the relevant databases
GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
;

SELECT "************************************* lock debugging : ", ROW_COUNT(), NOW() ;
  
-- Re-enable autocommit. MUST DO THIS TO PREVENT SYSTEM LOCKS.
SET autocommit = 1;


