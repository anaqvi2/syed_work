 

#populate the table with sfdc columns
use test;

delete from arc_marketo_upload;
insert into arc_marketo_upload (
    `arc_marketo_upload`.`userID`,
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`ownerID`,
    `arc_marketo_upload`.`status`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`street`,
    `arc_marketo_upload`.`city`,
    `arc_marketo_upload`.`state`,
    `arc_marketo_upload`.`postalCode`,
    `arc_marketo_upload`.`country`,
    `arc_marketo_upload`.`phone`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`annualRevenue`,
    `arc_marketo_upload`.`title`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`leadSource`,
    `arc_marketo_upload`.`existingEnterpriseDomain`,
    `arc_marketo_upload`.`existingPaidDomain`,
    `arc_marketo_upload`.`searchTerm`,
    `arc_marketo_upload`.`sourceBucket`,
    `arc_marketo_upload`.`sharedTo`,
    `arc_marketo_upload`.`containerCount`,
    `arc_marketo_upload`.`firstContainerFromTrialStart`,
    #`arc_marketo_upload`.`pushToMarketo`,
    `arc_marketo_upload`.`insertDateTime`,

    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`isOrgDomain`,
    #`arc_marketo_upload`.`newsFlags`,
    #`arc_marketo_upload`.`statusFlags`,
    #`arc_marketo_upload`.`localeLanguage`,
    #`arc_marketo_upload`.`localeCountry`,
    #`arc_marketo_upload`.`timeZone`,
    #`arc_marketo_upload`.`productName`,
    #`arc_marketo_upload`.`userLimit`,
    #`arc_marketo_upload`.`paymentStartDateTime`,
    #`arc_marketo_upload`.`nextPaymentDate`,
    #`arc_marketo_upload`.`paymentTerm`,
    #`arc_marketo_upload`.`planRate`,
    #`arc_marketo_upload`.`monthlyPlanRate_USD`,
    #`arc_marketo_upload`.`currencyCode`,
    #`arc_marketo_upload`.`teamTrial`,
    `arc_marketo_upload`.`trialStartDate`,
    #`arc_marketo_upload`.`trialEndDate`,
    #`arc_marketo_upload`.`isTrialRestart`,
    #`arc_marketo_upload`.`primaryContactPhone`,
    #`arc_marketo_upload`.`billToAddress`,
    #`arc_marketo_upload`.`billToCity`,
    #`arc_marketo_upload`.`billToRegionCode`,
    #`arc_marketo_upload`.`billToPostCode`,
    #`arc_marketo_upload`.`billToCountryCode`,
    #`arc_marketo_upload`.`marktetoTrackingCookie`,
    #`arc_marketo_upload`.`signupTrackingKeyword`,
    #`arc_marketo_upload`.`signupTracking_s_code`,
    #`arc_marketo_upload`.`signupTracking_c_code`,
    #`arc_marketo_upload`.`signupTracking_m_code`,
    #`arc_marketo_upload`.`SourceSource`,
    #`arc_marketo_upload`.`SourceSubSource`,
    #`arc_marketo_upload`.`salesforceOwnerID`,
    #`arc_marketo_upload`.`salesforceStatus`,
`arc_marketo_upload`.`smartscoreCode`,
    #`arc_marketo_upload`.`salesforceLeadSource`,
    #`arc_marketo_upload`.`numberOfEmployeesHvrs`,
    #`arc_marketo_upload`.`annualRevenueHvrs`,
    #`arc_marketo_upload`.`titleHvrs`,
    #`arc_marketo_upload`.`companyHvrs`,
    #`arc_marketo_upload`.`ipCountry`,
    #`arc_marketo_upload`.`organizationName`,
    #`arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    #`arc_marketo_upload`.`wasSharedToPriorToTrial`,
`arc_marketo_upload`.`domainsHighestPlan`,
    #`arc_marketo_upload`.`historyHighestPlan`,
`arc_marketo_upload`.`sheetCount`
    #`arc_marketo_upload`.`lastLogin`,
    #`arc_marketo_upload`.`lastMobileLogin`,
    #`arc_marketo_upload`.`isEverWellQualified`,
    #`arc_marketo_upload`.`isStrongLead`,
    #`arc_marketo_upload`.`eventLogCount`,
    #`arc_marketo_upload`.`loginCount`,
    #`arc_marketo_upload`.`sharingCount`,
    #`arc_marketo_upload`.`reportCount`
)
SELECT `userID__c`,
   `company`,
   `ownerID`,
   `status`,
   `paymentProfileID__c`,
   `parentPaymentProfileID__c`,
   `FirstName`,
   `LastName`,
   `Email`,
   `domain__c`,
   `Street`,
   `City`,
   `State`,
   `PostalCode`,
   `Country`,
   `Phone`,
   `NumberOfEmployees`,
   `AnnualRevenue`,
   `Title`,
   `Website`,
   `LeadSource`,
   `ExistingEnterpriseDomain`,
   `existing_Paid_Domain__c`,
   `Search_Term__c`,
   `Source_Bucket__c`,
   `Shared_To__c`,
   `containerCount`,
   `FirstContainerFromTrialStart`,
   `uploadDateTime`,
   `Trial_Start_Date__c`,
   `Smartscore_Code__c`,
   `Domain_s_Highest_Plan__c`,
   `Sheet_Count__c`
from rpt_main_02.arc_sfdc_upload
where userID__c not in 
   (
          select userId__c
          from rpt_main_02.arc_sfdc_upload
		  where userId__c is not null
		  group by userID__c
          having count(*) > 1
   )
   and userId__c is not null;



drop table if exists test.ref_country;

/*


drop table if exists test.ref_country;
drop table if exists test.ref_language;
drop table if exists test.arc_DailySmartscoreLeads;
drop table if exists test.arc_HooversCompanyData;
drop table if exists test.arc_ISPDomains;
drop table if exists test.arc_sfdc_enterpriseDomains;
drop table if exists test.rpt_paidDomains;
drop table if exists test.arc_sfdc_domains ;
drop table if exists test.arc_hubspotExcludeList;
drop table if exists test.arc_doNotContactList;


create table if not exists test.ref_country like rpt_main_02.ref_country;
create table if not exists test.ref_language like rpt_main_02.ref_language;
create table if not exists test.arc_DailySmartscoreLeads like rpt_main_02.arc_DailySmartscoreLeads;
create table if not exists test.arc_HooversCompanyData like rpt_main_02.arc_HooversCompanyData;
create table if not exists test.arc_ISPDomains like rpt_main_02.arc_ISPDomains;
create table if not exists test.arc_sfdc_enterpriseDomains like rpt_main_02.arc_sfdc_enterpriseDomains;
create table if not exists test.rpt_paidDomains like rpt_main_02.rpt_paidDomains;
create table if not exists test.arc_sfdc_domains like rpt_main_02.arc_sfdc_domains;
create table if not exists test.arc_hubspotExcludeList like rpt_main_02.arc_hubspotExcludeList;
create table if not exists test.arc_doNotContactList like rpt_main_02.arc_doNotContactList;

insert into test.ref_country SELECT * from rpt_main_02.ref_country;
insert into test.ref_language SELECT * from rpt_main_02.ref_language;
insert into test.arc_DailySmartscoreLeads SELECT * from rpt_main_02.arc_DailySmartscoreLeads;
insert into test.arc_HooversCompanyData SELECT * from rpt_main_02.arc_HooversCompanyData;
insert into test.arc_ISPDomains SELECT * from rpt_main_02.arc_ISPDomains;
insert into test.arc_sfdc_enterpriseDomains SELECT * from rpt_main_02.arc_sfdc_enterpriseDomains;
insert into test.rpt_paidDomains SELECT * from rpt_main_02.rpt_paidDomains;
insert into test.arc_sfdc_domains SELECT * from rpt_main_02.arc_sfdc_domains;
insert into test.arc_hubspotExcludeList SELECT * from rpt_main_02.arc_hubspotExcludeList;
insert into test.arc_doNotContactList SELECT * from rpt_main_02.arc_doNotContactList;

*/