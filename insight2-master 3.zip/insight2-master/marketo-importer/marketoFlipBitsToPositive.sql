-- ******************************************************************
-- Flip bits to POSITIVE equivalents. This is used after jenkins job
-- MarketoNightlyCondeep is disabled and no longer running.
-- https://jenkins.hq.smartsheet.com/view/Insight/job/MarketoImporterCondeep/
-- ******************************************************************
USE leadflow;

SELECT pushToMarketo, COUNT(*) FROM arc_marketo_upload WHERE pushToMarketo != 0 GROUP BY 1;

-- Disable triggers so that these changes are now written into the journal table
SET @disable_triggers = 1;

UPDATE arc_marketo_upload
SET pushToMarketo = 1
WHERE pushToMarketo = -1;

UPDATE arc_marketo_upload
SET pushToMarketo = 2
WHERE pushToMarketo = -2;

UPDATE arc_marketo_upload
SET pushToMarketo = 3
WHERE pushToMarketo = -3;

UPDATE arc_marketo_upload
SET pushToMarketo = 4
WHERE pushToMarketo = -4;

UPDATE arc_marketo_upload
SET pushToMarketo = 5
WHERE pushToMarketo = -5;

UPDATE arc_marketo_upload
SET pushToMarketo = 6
WHERE pushToMarketo = -6;

UPDATE arc_marketo_upload
SET pushToMarketo = 7
WHERE pushToMarketo = -7;

UPDATE arc_marketo_upload
SET pushToMarketo = 8
WHERE pushToMarketo = -8;

UPDATE arc_marketo_upload
SET pushToMarketo = 9
WHERE pushToMarketo = -9;

UPDATE arc_marketo_upload
SET pushToMarketo = 10
WHERE pushToMarketo = -10;

-- Re-enable triggers
SET @disable_triggers = NULL;

SELECT pushToMarketo, COUNT(*) FROM arc_marketo_upload WHERE pushToMarketo != 0 GROUP BY 1;