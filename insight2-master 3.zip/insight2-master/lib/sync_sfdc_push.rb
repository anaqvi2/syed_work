 # trac_pushData.rb
 # @description:  Pulling Data from MySQL tables to update Salesforce
 # @note: include .env file in folder with login credentials
 # @author Rauza Zhenissova
 # @date 2014-August-13


require 'dotenv'
require 'salesforce_bulk'
require 'yaml'
require 'cabin'
require 'active_record'
require 'mysql2'

class SyncSFDCPush

	Dotenv.load
	BULK_SIZE = 5000

	def self.init
		@columns = YAML.load_file(ENV['PUSHCONFIG'])
		ENV['UPSERT_DEBUG'] = 'false'
		@logger = Cabin::Channel.new
		@logger.subscribe(STDOUT)
		@logger.level = @columns["LogLevel"]
		@priorityLevel = @columns["priorityLevel"]
		env_variables = ["SF_LOGIN", "SF_PASSWORD", "SECURITY_TOKEN", "LOGIN_HOST", "DB_HOST", "DB_NAME", "DB_USERNAME", "DB_PASSWORD"]

		#Write an error message if enviromental variable is missing
		env_variables.each do |var|
			if ENV[var].nil?
				@logger.error("Environment variable " + var + " is missing")
			end
		end
		#create Bulk Client instance
		@client = SalesforceBulk::Client.new(username:  ENV['SF_LOGIN'], password: ENV['SF_PASSWORD']+ENV['SECURITY_TOKEN'], login_host: ENV['LOGIN_HOST'])
		@client.authenticate
		@logger.info("Connected to SalesforceBulk")
		recordBase = ActiveRecord::Base.establish_connection(:adapter => "mysql2", :host => ENV['DB_HOST'], :database => ENV['DB_NAME'], :username => ENV['DB_USERNAME'], :password => ENV['DB_PASSWORD'])
	end

	#create ActiveRecord instance
	def self.fetch_table(tableName)
		ActiveRecord::Base.connection.reconnect!
	  	table = Class.new(ActiveRecord::Base){self.table_name = tableName}
	  	return table
	end

	# Bulk can process up to 10,000 records/batch. Maximum 5,000 batches/24 hours period
	# atrributes is an array of hashes to be inserted
	def self.addBulk(tableName, attributes)
		job = @client.add_job(:insert, tableName)
		@logger.info("Initiated a new insert job for " + tableName)
		if (attributes.size() > 0)
			timer = @logger.time("Time needed to create records")

			#remove records with greater priority
			if(attributes[0].has_key?("priority"))
				attributes = attributes.partition{|k| k["priority"] <= @priorityLevel}[0]
			end

			#process in a batches of specified size
			attributes.each_slice(BULK_SIZE).to_a.each do |records|
				requests = generateHash(tableName, records)
				# add multiple batches to a job
				batch = @client.add_batch(job.id, requests)
			end

			@client.close_job(job.id)
			@logger.info("Closed the insert job")
			showLog(job, tableName)
			timer.stop
		end
	end

	# Remove processed records from MySQL table
	def self.deleteFromMySQL(extId, tableName, updatedIds)
		new_table = fetch_table(tableName)
		timer = @logger.time("Time needed delete MySQL records")
		new_table.primary_key = extId
		updatedIds.each do |tmpId|
			if new_table.exists?(extId => tmpId)
				new_table.where(extId => tmpId).first.destroy
			end
		end
		@logger.debug(updatedIds.size().to_s + " records have been synced. Synced records have been deleted from MySQL")
		timer.stop
	end

	# Upsert records form MySQL table to SFDC
	def self.upsertBulk(tableName, fields, metavalues)
		extId = metavalues["ExternalId"]
		upsert_records = Hash.new

		if  !extId.nil?
			# Initiate ActiveRecord  object
			new_table = fetch_table(tableName)

			querySize = BULK_SIZE
			success = true
			while querySize == BULK_SIZE && success
				successfullRecords = Array.new
				#retrieve records from MySQL and generate an array of hashes
				@logger.debug("pulling records from " + tableName)
				upsert_records = generateSQLHash(new_table, fields, metavalues)
				querySize = upsert_records.size()
				if upsert_records.size() != 0
					# upsert_records.each do |record|
					# 	updatedIds << record[extId]
					# end

					timer = @logger.time("Time needed to upsert records into SFDC")
					job = @client.add_job(:upsert, metavalues["SFDCTable"], :external_id_field_name => extId)
					@logger.info("Initiated a new upsert job for " + metavalues["SFDCTable"].to_s)
					batch = @client.add_batch(job.id, upsert_records)
					@client.close_job(job.id)
					timer.stop
					updatedRecords = showLog(job, metavalues["SFDCTable"])
					successfullRecords = getSuccessfulExternalId(updatedRecords, metavalues["SFDCTable"], extId)
					#wipe the table once records copied
					if successfullRecords.size()>0
						deleteFromMySQL(fields.invert[extId], tableName, successfullRecords)
					else
						@logger.error("Couldn't upsert this batch")
					end
					timer.stop
				end
			end
		else
			@logger.debug("ERROR: External Id is not specified in config file")
		end
	end

	def self.getSuccessfulExternalId(recordSize, sfdcTable, extId)
		succesfullIds = Array.new
		job = @client.add_job(:query, sfdcTable)
		@logger.info("Initiated a new query job for " +  sfdcTable)

		query = "select " + extId + " from " + sfdcTable + " ORDER BY LastModifiedDate DESC LIMIT " + recordSize.to_s
		#retrieve records that were modified after the last synced time
		batch = @client.add_batch(job.id, query)
		job = @client.close_job(job.id)

		batches = @client.batch_info_list(job.id)
		@logger.debug query
		@logger.warn("Waiting for a job " + job.id.to_s + " to complete on " + sfdcTable)
		batches.each do |batch|
			if !batch.failed?
				#Loop to wait for a batch to complete
				while !batch.completed?  do
					batch = @client.batch_info(job.id, batch.id)
				end
				results = batch_result(job.id, batch.id)

				if results.any?
					results.each do |result|
						result.each do |key, value|
							succesfullIds << value
						end
					end
				end
			end
		end
		return succesfullIds
	end

	def self.batch_result(jobId, batchId)
      response = @client.http_get("job/#{jobId}/batch/#{batchId}/result")
      if response.body =~ /<.*?>/m
        result = XmlSimple.xml_in(response.body)
        
        if result['result'].present?
          results = query_result(jobId, batchId, result['result'].first)
          
          collection = SalesforceBulk::QueryResultCollection.new(self, jobId, batchId, result['result'].first, result['result'])
          collection.replace(results)
        end
      else
        result = SalesforceBulk::BatchResultCollection.new(jobId, batchId)
        
        CSV.parse(response.body, :headers => true) do |row|
          result << SalesforceBulk::BatchResult.new(row[0], row[1].to_b, row[2].to_b, row[3])
        end
        
        result
      end
    end
    
    def self.query_result(job_id, batch_id, result_id)
      headers = {"Content-Type" => "text/csv; charset=UTF-8"}
      response = @client.http_get("job/#{job_id}/batch/#{batch_id}/result/#{result_id}", headers)
      
      lines = response.body.lines.to_a
      headers = CSV.parse_line(lines.shift).collect { |header| header.to_sym }
      
      result = []
      
      #CSV.parse(lines.join, :headers => headers, :converters => [:all, lambda{|s| s.to_b if s.kind_of? String }]) do |row|
      CSV.parse(lines.join.gsub("\r\n", " "), :headers => headers) do |row|
        result << Hash[row.headers.zip(row.fields)]
      end
      
      result
    end

	def self.generateSQLHash(new_table, fields, metavalues)
		priority = metavalues["priority"]
		requests = Array.new
		timer = @logger.time("Time needed to query MySQL records")
		new_table.first(BULK_SIZE).each do |record|
			hashes = Hash.new
			if record.attributes[priority].nil? || record.attributes[priority]<=@priorityLevel
				fields.keys.each do |key|

					if key != priority && record.attributes.include?(key)
						# change column name for salesforce table
						if record.attributes[key].class == Time
							begin
							   formattedTime = record.attributes[key].strftime "%Y-%m-%dT%H:%M:%S.000Z"
							   hashes.merge!({fields[key] => formattedTime})
							rescue ArgumentError
							   hashes.merge!({fields[key] => record.attributes[key]})
							end
						else
							hashes.merge!({fields[key] => record.attributes[key]})
						end
						
					end
				end
				requests << hashes
			end
		end
		if  !(fields.keys -  new_table.column_names).empty?
			@logger.warn("The following fields do not exist in MySQL table, please modify them in the config file")
			@logger.warn(fields.keys - new_table.column_names)
			@logger.debug("Available " +  " fields")
			@logger.debug(new_table.column_names)
		end
		timer.stop
		return requests
	end

	#delete_tasks, array of hashes with ids and priority levels
	def self.deleteBulk(tableName, delete_tasks)
		job = @client.add_job(:delete,  @columns["Tables"][tableName]["Metadata"]["SFDCTable"])
		@logger.info("Initiated a new delete job for " + tableName)

		if (delete_tasks.size() > 0)
			timer = @logger.time("Time needed to delete records")
			if(delete_tasks[0].has_key?("priority"))
				delete_tasks = delete_tasks.partition{|k| k["priority"] <= @priorityLevel}[0]
			end

			delete_tasks.each_slice(BULK_SIZE).to_a.each do |records|
				batch = @client.add_batch(job.id, records)
			end
			@client.close_job(job.id)
			@logger.info("Closed the delete job")
			showLog(job, tableName)
			timer.stop
		end
	end

	def self.generateHash(tableName, records)
		columns = @columns["Tables"][tableName]["Fields"]
		metavalues = @columns["Tables"][tableName]["Metadata"]
		requests = Array.new

		records.each do |record|
			hashes = Hash.new
			record.each do |key,value|
				if key != "priority"
					if columns[key] == metavalues["ExternalId"]
						hashes.merge!({key => value})
					else 
						# change column name for salesforce table
						hashes.merge!({columns[key] => value})
					end
				end
			end
			requests << hashes
		end
		return requests
	end

	def self.showLog(job, tableName)
		batches = @client.batch_info_list(job.id) # returns an Array of Batch objects
		batchNo = 1
		@logger.warn("Waiting for a job " + job.id.to_s + " to complete")
		updatedRecords = false
		successfullRecords = 0
		batches.each do |batch|
			if batch.failed?
				@logger.error("Batch #{batch.id} couldn't be completed. Please check your input")
				updatedRecords = false
			else
				# Wait till batch is completed
				while !batch.completed?  do
					batch = @client.batch_info(job.id, batch.id)
					@logger.warn("Waiting for a batch " + batchNo.to_s + "/#{batches.size()} to complete. Batch ID #{batch.id}")
					sleep(30)
				end
				@logger.info("The Batch #" + batch.id.to_s + " completed on " + tableName)
				#show batch results
				results = @client.batch_result(job.id, batch.id)
				@logger.debug('Number of records processed in this batch: ' + results.size().to_s)
				
				results.each do |result|
					if !result.error?
						updatedRecords = true
						successfullRecords += 1
					else
						@logger.debug("Item #{result.id} had an error of: #{result.error}") 
					end
				end
			end
			batchNo += 1
		end
		@logger.info("The Job #" + job.id.to_s + " completed on " + tableName)
		@logger.debug("Total number of DML requests: " + batches.size().to_s)
		return successfullRecords
	end
	# Runs the program
	def self.go
		subject = @columns["Tables"]
		subject.each do |s|
	  		upsertBulk(s.first, s.last["Fields"], s.last["Metadata"])
		end
	end
end


