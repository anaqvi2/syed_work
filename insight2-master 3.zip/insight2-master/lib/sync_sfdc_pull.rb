 # @description:  Pulling timestampFile from Salesforce to update MySQL tables
 # @note: include .env file in folder with login credentials
 # @author Rauza Zhenissova
 # @date 2014-August-13
require 'dotenv'
require 'salesforce_bulk'
require 'yaml'
require 'cabin'
require 'mysql2'
require 'simplecov'
require 'upsert'
require 'active_record'

class SyncSFDCPull
	Dotenv.load
	BULK_SIZE = 5000

	def self.init
		class << self; attr_accessor :client end
		@columns = YAML.load_file(ENV['PULLCONFIG'])
		ENV['UPSERT_DEBUG'] = 'false'
		env_variables = ["SF_LOGIN", "SF_PASSWORD", "SECURITY_TOKEN", "LOGIN_HOST", "DB_HOST", "DB_NAME", "DB_USERNAME", "DB_PASSWORD"]

		#Write an error message if enviromental variable is missing
		env_variables.each do |var|
			if ENV[var].nil?
				@logger.warn("Environment variable " + var + " is missing")
			end
		end
		#create Bulk Client instance
		@client = SalesforceBulk::Client.new(username:  ENV['SF_LOGIN'], password: ENV['SF_PASSWORD']+ENV['SECURITY_TOKEN'], login_host: ENV['LOGIN_HOST'])
		@client.authenticate
		@logger = Cabin::Channel.new
		@logger.subscribe(STDOUT)
		@logger.level = @columns["LogLevel"]
		@fileName =  @columns["TimestampFile"]
		recordBase = ActiveRecord::Base.establish_connection(:adapter => "mysql2", :host => ENV['DB_HOST'], :database => ENV['DB_NAME'], :username => ENV['DB_USERNAME'], :password => ENV['DB_PASSWORD'], :encoding => 'utf8')
	end

	#create ActiveRecord instance
	def self.fetch_table(tableName)
		ActiveRecord::Base.connection.reconnect!
		table = Class.new(ActiveRecord::Base){self.table_name = tableName}
	  	return table
	end
	# pull records that are marked needSync
	# def self.pullUnsyncedRecords(tableName, fields, metaValues)
	# 	timer = @logger.time("Time needed to pull unsynced records")
	# 	job = @client.add_job(:query, tableName)
	# 	@logger.info("Added a new query job")
	# 	needSync = metaValues["SyncTag"]
	# 	idName = @columns["Tables"][tableName]["Fields"]["Id"]
	# 	# query for records that need to be synced
	# 	batch = @client.add_batch(job.id, "select " + fields.keys.join(",") + ", " + needSync + " from " + tableName + " where " + needSync + " = true")
	# 	job = @client.close_job(job.id)
		
	# 	#create hash to update retrieved records, need to push to DB
	# 	result = ResultToHash(job, tableName, needSync)
	#   @connection = Mysql2::Client.new(:host => ENV['DB_HOST'], :database => ENV['DB_NAME'], :username => ENV['DB_USERNAME'], :password => ENV['DB_PASSWORD'])
	# 	if(result.size() > 0)
	# 		updateTable = Array.new
	# 		Upsert.batch(@connection,metaValues["TableName"]) do |upsert|
	# 			result.each do |r|
	# 				updateTable << {idName => r[idName], needSync => false}
	# 				r.delete needSync
	# 				upsert.row({idName => r[idName]}, r.except("idName"))
	# 			end
	# 		end
	# 		# mark the records as synced
	# 		updateBulk(tableName, updateTable)	
	# 	end
	# 	timer.stop
	# 	showLog(job)
	# end

	# pull records that haven't been synced since certain time
	def self.pullOutdatedRecords(tableName, fields, metaValues)
		success = true
		errorFields = Array.new
		modifiedInclude = false
		@connection = Mysql2::Client.new(:host => ENV['DB_HOST'], :database => ENV['DB_NAME'], :username => ENV['DB_USERNAME'], :password => ENV['DB_PASSWORD'])
		
		timestampFile = Hash.new
		# new_table = fetch_table(metaValues["TableName"])
		# if !(fields.keys - new_table.column_names).empty?
		# 	fields.keys.each do |f|
		# 		if !new_table.column_names.include?(f) 
		# 			fields.delete(f)
		# 			errorFields << f
		# 		end
		# 	end
		# 	@logger.debug("The following fields do not exist in SFDC, please modify them in the config file")
		# 	@logger.debug(errorFields)

		# 	@logger.debug("Available " + tableName + " fields")
		# 	@logger.debug(new_table.column_names)
		# end
		#needSync = metaValues["SyncTag"]
		synced_time = Time.at(0).strftime "%Y-%m-%dT%H:%M:%S.000Z"
				
		if File.file? (@fileName) then
			timestampFile = YAML.load_file(@fileName)
			if !timestampFile[tableName].nil?
				synced_time = timestampFile[tableName]
			end
		else
			timestampFile = {tableName => synced_time}
			File.open(@fileName, 'w') { |f| YAML.dump(timestampFile, f) }
		end

		queryFields = fields.keys.join(",")
		if !queryFields.include? "LastModifiedDate"
			modifiedInclude = true
			queryFields += ", LastModifiedDate"
		end
		querySize = BULK_SIZE
		while querySize == BULK_SIZE && success
			query = "SELECT " + queryFields + " FROM " + tableName + " WHERE LastModifiedDate >= #{synced_time}" + " ORDER BY LastModifiedDate LIMIT " + BULK_SIZE.to_s
			@logger.info(query)
			result = queryRecords(query, tableName, fields, metaValues)
			querySize = result[0]
			timestampFile = YAML.load_file(@fileName)
			synced_time = timestampFile[tableName]
			success = result[1]
		end

		@connection.close

		#syncResult = pullUnsyncedRecords(tableName, fields, metaValues)
	end


	def self.queryRecords(query, tableName, fields, metaValues)

		job = @client.add_job(:query, tableName)
		@logger.info("Initiated a new query job for " + tableName)

		timer = @logger.time("Time needed to pull outdated records")
		#retrieve records that were modified after the last synced time
		batch = @client.add_batch(job.id, query)
		job = @client.close_job(job.id)

		# place records in a hash (DB)
		result = ResultToHash(job, tableName, metaValues)
		@logger.debug("Pulled " + result.size().to_s + " records from SFDC's " + tableName + " table")
		timer.stop
		if(result.size() > 0)
			success = upsertToMySQL(result, tableName, fields, metaValues)
		end
		showLog(job)
		resultArray = [result.size(), success]
		return resultArray
	end

	def self.upsertToMySQL(result, tableName, fields, metaValues)
		idName = fields["Id"]
		modifiedInclude = false
		if fields.keys.include? "LastModifiedDate"
			modifiedInclude = true
		end
		success = false
		updateTable = Array.new
		modifiedTime = 0
		timer = @logger.time("Time needed push to MySQL table")
		result.each_slice(BULK_SIZE).to_a.each do |records|
			@logger.debug("Upserting " + records.size().to_s + " records to MySQL Database")
			begin
				@connection = Mysql2::Client.new(:host => ENV['DB_HOST'], :database => ENV['DB_NAME'], :username => ENV['DB_USERNAME'], :password => ENV['DB_PASSWORD'], :reconnect =>true)
				Upsert.batch(@connection, metaValues["TableName"]) do |upsert|
					records.each do |r|
						# if (r[needSync]=="true")
						# 	updateTable << {idName => r[idName], needSync => false}
						# end
						#r.delete needSync
						modifiedTime = r["LastModifiedDate"]
						if !modifiedInclude
							r.delete "LastModifiedDate"
						end
						upsert.row({idName => r[idName]}, r)
					end
				end
				success = true
				#Update timestamp for the next call
			rescue Exception => e
  				@logger.warn(e.message + " MYSQL EXCEPTION!")
  				success = false
			end

			if(success)
				timestampFile = YAML.load_file(@fileName)
				timestampFile[tableName] = modifiedTime
				File.open(@fileName, 'w') { |f| YAML.dump(timestampFile, f) }
			end
		end
		timer.stop

		# mark the records as synced
		# if (updateTable.size()>0)
		# 	updateBulk(tableName, updateTable)	
		# end

		return success
	end

	# convert Bulk output to an array of hashes
	def self.ResultToHash(job, tableName, metaValues)
		batches = @client.batch_info_list(job.id)
		columns = @columns["Tables"][tableName]["Fields"]
		finalResult = Array.new
		@logger.warn("Waiting for a job " + job.id.to_s + " to complete on " + tableName)
		batchNo = 1
		batches.each do |batch|

			if !batch.failed?
				#Loop to wait for a batch to complete
				while !batch.completed?  do
					batch = @client.batch_info(job.id, batch.id)
					@logger.warn("Waiting for a batch " + batchNo.to_s + "/" + batches.size().to_s + " to complete on " + tableName + ". Batch id " + batch.id.to_s)
					sleep(60)
				end
				@logger.info("The Batch #" + batch.id.to_s + " completed on " + tableName)
				results = batch_result(job.id, batch.id)
				@logger.debug("Received the result from Batch")

				new_table = fetch_table(metaValues["TableName"])
				#Put all results in an array of hashes
				errorMessage = ""
				while results.any?
					@logger.debug("Converting " + results.size().to_s + " records to hash")
					results.each do |result|
						errorMessage = ""
						hashes = Hash.new
						result.each do |key,value|
							# if key.to_s == syncField.to_s
							# 	hashes.merge!({key.to_s => value})
							if key.to_s == "LastModifiedDate" && columns[key.to_s].nil?
								hashes.merge!({"LastModifiedDate" => value})
							elsif !new_table.column_names.include?(columns[key.to_s]) 
								errorMessage += columns[key.to_s].to_s + " "
							else
								hashes.merge!({columns[key.to_s] => value.force_encoding('utf-8')})
							end
						end
							finalResult << hashes
					end
					@logger.debug("Another set is available.") if results.next?
					
					results.next? ? results.next : break
				end

				if errorMessage != ""
					@logger.debug("Field/s " + errorMessage + " do not exist in MySQL table")
				end
			else
				@logger.error("Batch failed to process. Please check your Query")
			end	

			batchNo+=1
		end
		@logger.info("The Job #" + job.id.to_s + " completed on " + tableName)
		return finalResult
	end

	# update_tasks is an array of hashes to be updated
	def self.updateBulk(tableName, update_tasks)
		job = @client.add_job(:update, tableName)
		if update_tasks.size() > 0
			timer = @logger.time("Time needed to update records")

			update_tasks.each_slice(BULK_SIZE).to_a.each do |records|
				batch = @client.add_batch(job.id, update_tasks)
			end
			@client.close_job(job.id)
		end
		showLog(job)
		timer.stop
	end

	def self.batch_result(jobId, batchId)
      response = @client.http_get("job/#{jobId}/batch/#{batchId}/result")
      
      if response.body =~ /<.*?>/m
        result = XmlSimple.xml_in(response.body)
        
        if result['result'].present?
          results = query_result(jobId, batchId, result['result'].first)
          
          collection = SalesforceBulk::QueryResultCollection.new(self, jobId, batchId, result['result'].first, result['result'])
          collection.replace(results)
        end
      else
        result = SalesforceBulk::BatchResultCollection.new(jobId, batchId)
        
        CSV.parse(response.body, :headers => true) do |row|
          result << SalesforceBulk::BatchResult.new(row[0], row[1].to_b, row[2].to_b, row[3])
        end
        
        result
      end
    end
    
    def self.query_result(job_id, batch_id, result_id)
      headers = {"Content-Type" => "text/csv; charset=UTF-8"}
      response = @client.http_get("job/#{job_id}/batch/#{batch_id}/result/#{result_id}", headers)
      
      lines = response.body.lines.to_a
      headers = CSV.parse_line(lines.shift).collect { |header| header.to_sym }
      
      result = []
      
      #CSV.parse(lines.join, :headers => headers, :converters => [:all, lambda{|s| s.to_b if s.kind_of? String }]) do |row|
      CSV.parse(lines.join.gsub("\r\n", " "), :headers => headers) do |row|
        result << Hash[row.headers.zip(row.fields)]
      end
      
      result
    end

	def self.showLog(job)
		batches = @client.batch_info_list(job.id) # returns an Array of Batch objects
		
		batches.each do |batch|
			if batch.failed?
				@logger.error("Batch couldn't be completed. Please check your Query")
			else
				# Wait till batch is completed
				while !batch.completed?  do
					batch = @client.batch_info(job.id, batch.id)
					@logger.warn("Waiting for a job " + job.id.to_s + " to complete")
					sleep(60)
				end
				@logger.debug("Batch #{batch.id} completed.") 
				#show batch results
				results = batch_result(job.id, batch.id) # returns an Array of BatchResult objects
				@logger.debug('Number of records processed in this batch: ' + results.size().to_s)
			end
		end
		@logger.debug("Total number of SOQL requests: " + batches.size().to_s)
	end

	def self.go
		subject = @columns["Tables"]
		subject.each do |s|
	  		pullOutdatedRecords(s.first, s.last["Fields"], s.last["Metadata"])
		end
	end
end

