
-- Set at the session level to prevent locking of ss_core_02 tables


-- Pull last transaction inserted into upload table
-- We'll use this as the starting point for each run
SELECT MAX(paymentProfileLastModifiedDateTime) FROM MAIN.ARC.sfdc_opportunityUpload  WHERE paymentProfileLastModifiedDateTime < CURRENT_TIMESTAMP() INTO @maxRecordDate;
SET @maxRecordDate = CASE WHEN @maxRecordDate IS NULL THEN '1901-01-01' ELSE @maxRecordDate END;
#SET @maxRecordDate = '2014-11-01';

-- Drop and create table to hold new transactions
DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_upload_transactions;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sfdc_upload_transactions
(
  `parentPaymentProfileID` BIGINT(20) NOT NULL DEFAULT '0',
  `mainContactUserID` BIGINT(20) DEFAULT NULL,
  `mainContactName` VARCHAR(100) DEFAULT NULL,
  `FIRST_NAME` VARCHAR(100) DEFAULT NULL,
  `LAST_NAME` VARCHAR(100) DEFAULT NULL,
  `orgAdminEmail` VARCHAR(100) DEFAULT NULL,
  `OWNER_ID` BIGINT(20) DEFAULT NULL,
  `organizationName` VARCHAR(100) DEFAULT NULL,
  `organizationDomain` VARCHAR(100) DEFAULT NULL,
  `newPaymentType` VARCHAR(20) DEFAULT NULL,
  `bonusSheetCount` INT(11) DEFAULT NULL,
  `bonusUserCount` INT(11) DEFAULT NULL,
  `billToCCName` VARCHAR(100) DEFAULT NULL,
  `billToAddress` VARCHAR(300) DEFAULT NULL,
  `billToCity` VARCHAR(50) DEFAULT NULL,
  `billToRegionCode` VARCHAR(50) DEFAULT NULL,
  `billToPostCode` VARCHAR(50) DEFAULT NULL,
  `billToCountryCode` VARCHAR(50) DEFAULT NULL,
  `oldPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `newPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `oldProductName` VARCHAR(20) DEFAULT NULL,
  `newProductName` VARCHAR(20) DEFAULT NULL,
  `oldUserLimit` INT(11) DEFAULT NULL,
  `newUserLimit` INT(11) DEFAULT NULL,
  `userLimitChange` INT(11) DEFAULT NULL,
  `oldMonthlyPayment` DECIMAL(40,8) DEFAULT NULL,
  `newMonthlyPayment` DECIMAL(40,8) DEFAULT NULL,
  `monthlyPaymentChange` DECIMAL(40,8) DEFAULT NULL,
  `bucket` VARCHAR(20) DEFAULT NULL,
  `recordType` VARCHAR(20) DEFAULT NULL,
  `paymentStartDateTime` DATETIME DEFAULT NULL,
  `actualLastPaymentDate` DATETIME DEFAULT NULL,
  `calculatedNextPaymentDate` DATETIME DEFAULT NULL,
  `paymentProfileInsertDateTime` DATETIME DEFAULT NULL,
  `paymentProfileLastModifiedDateTime` DATETIME DEFAULT NULL,
  `HIST_EFFECTIVE_THRU_DATE_TIME` DATETIME DEFAULT NULL,
  `recordDateTime` DATETIME DEFAULT NULL
) DEFAULT CHARSET=utf8
;

SELECT MAX(recordDateTime) FROM MAIN.ARC.sfdc_opportunityUpload WHERE recordType = "WINS" AND recordDateTime < CURRENT_TIMESTAMP() INTO @maxWINRecordDate;
SET @maxWINRecordDate = CASE WHEN @maxWINRecordDate IS NULL THEN '1901-01-01' ELSE @maxWINRecordDate END;

-- Get new WINS since last run
INSERT INTO rpt_main_02.stg_sfdc_upload_transactions
SELECT 
hist_paymentProfile.paymentProfileID AS parentPaymentProfileID,
organization.mainContactUserID,
CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
userAccount.FIRST_NAME,
userAccount.LAST_NAME,
userAccount.emailAddress,
hist_paymentProfile.OWNER_ID,
organization.name AS OrgName,
SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
IFNULL(hist_paymentProfile.bonusSheetCount,0) AS bonusSheetCount,
IFNULL(hist_paymentProfile.bonusUserCount,0) AS bonusUserCount,
hist_paymentProfile.billToCCName,
CONCAT(hist_paymentProfile.billToAddress1,' ',hist_paymentProfile.billtoAddress2) AS billToAddress,
hist_paymentProfile.billToCity,
hist_paymentProfile.billToRegionCode,
hist_paymentProfile.billToPostCode,
hist_paymentProfile.billToCountryCode,
NULL AS OldPaymentTerm,
rpt_main_02.SMARTSHEET_PAYMENTTERM(hist_paymentProfile.paymentTerm) AS NewPaymentTerm,
NULL AS OldProductName,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
0 AS OldUserLimit,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.userLimit-0 AS userLimitChange,
0 AS OldMonthlyPayment,
(CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm 
	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)/hist_paymentProfile.paymentTerm END) AS NewMonthlyPayment,

(CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm
	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)/hist_paymentProfile.paymentTerm END) AS MonthlyPaymentChange,
NULL AS bucket,
'WINS' AS recordType,
hist_paymentProfile.paymentStartDateTime AS paymentStartDateTime,
hist_paymentProfile.actualLastPaymentDate,
hist_paymentProfile.nextPaymentDate AS calculatedNextPaymentDate,
hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.MODIFY_DATE_TIME AS lastModifiedDateTime,
hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME,
hist_paymentProfile.paymentStartDateTime AS recordDateTime

FROM ss_core_02.hist_paymentProfile
JOIN MAIN.REF.months months FORCE INDEX (ref_months_end) ON hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME > months.endMonth
	AND hist_paymentProfile.MODIFY_DATE_TIME <= months.endMonth
	AND hist_paymentProfile.paymentStartDateTime BETWEEN months.startMonth AND months.endMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
/* Need exchange rates to convert plan rates into USD equivalents*/	
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN ss_core_02.organization ON hist_paymentProfile.paymentProfileID=organization.paymentProfileID
LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID
WHERE hist_paymentProfile.productID >= 6 /* Team and Enterprise Only*/
AND CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END > 0 /* converts planRate into USD equivalent*/
AND hist_paymentProfile.paymentType !=4
AND (hist_paymentProfile.MODIFY_DATE_TIME >= @maxWINRecordDate OR hist_paymentProfile.paymentProfileID = 10951031)  /* Grabs new Wins*/
;



-- Get UPGRADES since last run
INSERT INTO rpt_main_02.stg_sfdc_upload_transactions
SELECT
hist_paymentProfile.paymentProfileID AS parentPaymentProfileID,
organization.mainContactUserID,
CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
userAccount.FIRST_NAME,
userAccount.LAST_NAME,
userAccount.emailAddress,
hist_paymentProfile.OWNER_ID,
organization.name AS OrgName,
SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
IFNULL(hist_paymentProfile.bonusSheetCount,0) AS bonusSheetCount,
IFNULL(hist_paymentProfile.bonusUserCount,0) AS bonusUserCount,
hist_paymentProfile.billToCCName,
CONCAT(hist_paymentProfile.billToAddress1,' ',hist_paymentProfile.billtoAddress2) AS billToAddress,
hist_paymentProfile.billToCity,
hist_paymentProfile.billToRegionCode,
hist_paymentProfile.billToPostCode,
hist_paymentProfile.billToCountryCode,
rpt_main_02.SMARTSHEET_PAYMENTTERM(oldHPP.paymentTerm) AS OldPaymentTerm,
rpt_main_02.SMARTSHEET_PAYMENTTERM(hist_paymentProfile.paymentTerm) AS NewPaymentTerm,
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
oldHPP.userLimit AS OldUserLimit,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.userLimit-oldHPP.userLimit AS userLimitChange,
((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm) AS OldMonthlyPayment,
((CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' 
	THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END)/hist_paymentProfile.paymentTerm) AS NewMonthlyPayment,

((CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' 
	THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END)/hist_paymentProfile.paymentTerm)-
((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm) AS MonthlyPaymentChange,
NULL AS bucket,
'UPGRADES' AS recordType,
hist_paymentProfile.paymentStartDateTime,
hist_paymentProfile.actualLastPaymentDate,
hist_paymentProfile.nextPaymentDate AS calculatedNextPaymentDate,
hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.MODIFY_DATE_TIME AS lastModifiedDateTime,
hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME,
hist_paymentProfile.MODIFY_DATE_TIME AS recordDateTime


FROM ss_core_02.hist_paymentProfile
JOIN ss_core_02.hist_paymentProfile oldHPP ON hist_paymentProfile.paymentProfileID=oldHPP.paymentProfileID
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/	
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce2 ON oldHPP.CURRENCY_CODE=hce2.CURRENCY_CODE
	AND oldHPP.MODIFY_DATE_TIME BETWEEN hce2.MODIFY_DATE_TIME AND hce2.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN ss_core_02.organization ON hist_paymentProfile.paymentProfileID=organization.paymentProfileID
LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID


WHERE hist_paymentProfile.productID >= 6 /* Upgrades to Team or Enterprise Only*/
AND hist_paymentProfile.accountType != 2
/* Upgrades determined by change in Monthly payments*/
AND CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END > 0
AND CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END > 0
AND oldHPP.productID >= 3

#AND (CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm <
#	(CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' 
#		THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END)/hist_paymentProfile.paymentTerm

AND oldHPP.planRate/oldHPP.paymentTerm < hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm
		
		
		
AND hist_paymentProfile.paymentProfileID NOT IN (1274492) /* Exclude Team Smartsheet */
AND hist_paymentProfile.paymentType != 4
AND hist_paymentProfile.MODIFY_DATE_TIME = oldHPP.HIST_EFFECTIVE_THRU_DATE_TIME 
AND (hist_paymentProfile.MODIFY_DATE_TIME >= @maxWINRecordDate OR hist_paymentProfile.paymentProfileID IN(10040801,
7948110)) /* Grabs new upgrades*/

UNION

SELECT 
orgHPP.paymentProfileID AS parentPaymentProfileID,
organization.mainContactUserID,
CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
userAccount.FIRST_NAME,
userAccount.LAST_NAME,
userAccount.emailAddress,
orgHPP.OWNER_ID,
organization.name AS OrgName,
SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(orgHPP.paymentType) AS NewPaymentType,
IFNULL(orgHPP.bonusSheetCount,0) AS bonusSheetCount,
IFNULL(orgHPP.bonusUserCount,0) AS bonusUserCount,
orgHPP.billToCCName,
CONCAT(orgHPP.billToAddress1,' ',orgHPP.billtoAddress2) AS billToAddress,
orgHPP.billToCity,
orgHPP.billToRegionCode,
orgHPP.billToPostCode,
orgHPP.billToCountryCode,
rpt_main_02.SMARTSHEET_PAYMENTTERM(oldHPP.paymentTerm) AS OldPaymentTerm,
rpt_main_02.SMARTSHEET_PAYMENTTERM(orgHPP.paymentTerm) AS NewPaymentTerm,
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
rpt_main_02.SMARTSHEET_PRODUCTNAME(orgHPP.productID) AS NewProductName,
oldHPP.userLimit AS OldUserLimit,
orgHPP.userLimit AS NewUserLimit,
orgHPP.userLimit-oldHPP.userLimit AS userLimitChange,
((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm) AS OldMonthlyPayment,
((CASE WHEN orgHPP.CURRENCY_CODE = 'USD' THEN orgHPP.planRate ELSE (orgHPP.planRate/hce3.EXCHANGE_RATE) END)/orgHPP.paymentTerm) AS NewMonthlyPayment,
((CASE WHEN orgHPP.CURRENCY_CODE = 'USD' THEN orgHPP.planRate ELSE (orgHPP.planRate/hce3.EXCHANGE_RATE) END)/orgHPP.paymentTerm) - 
	((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm) AS MonthlyPaymentChange,
NULL AS bucket,
'UPGRADES' AS recordType,
orgHPP.paymentStartDateTime,
orgHPP.actualLastPaymentDate,
orgHPP.nextPaymentDate AS calculatedNextPaymentDate,
orgHPP.insertDateTime AS paymentProfileInsertDateTime,
orgHPP.MODIFY_DATE_TIME AS lastModifiedDateTime,
orgHPP.HIST_EFFECTIVE_THRU_DATE_TIME,
orgHPP.MODIFY_DATE_TIME AS recordDateTime

FROM MAIN.REF.months months
JOIN ss_core_02.hist_paymentProfile ON hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME > months.endMonth
	AND hist_paymentProfile.MODIFY_DATE_TIME <= months.endMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
JOIN ss_core_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID=hist_paymentProfile.paymentProfileID
	AND oldHPP.HIST_EFFECTIVE_THRU_DATE_TIME > months.startMonth
	AND oldHPP.MODIFY_DATE_TIME <= months.startMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
/* This is for capturing Upgrades from Individual Plans to Team, Enterprise Plans*/
JOIN ss_core_02.hist_paymentProfile orgHPP ON orgHPP.paymentProfileID=hist_paymentProfile.parentPaymentProfileID
	AND DATE_FORMAT(hist_paymentProfile.MODIFY_DATE_TIME,'%Y-%m')=DATE_FORMAT(orgHPP.MODIFY_DATE_TIME,'%Y-%m')
	AND orgHPP.HIST_EFFECTIVE_THRU_DATE_TIME > months.endMonth
	AND orgHPP.MODIFY_DATE_TIME <= months.endMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce2 ON oldHPP.CURRENCY_CODE=hce2.CURRENCY_CODE
	AND oldHPP.MODIFY_DATE_TIME BETWEEN hce2.MODIFY_DATE_TIME AND hce2.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce3 ON orgHPP.CURRENCY_CODE=hce3.CURRENCY_CODE
	AND orgHPP.MODIFY_DATE_TIME BETWEEN hce3.MODIFY_DATE_TIME AND hce3.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN ss_core_02.organization ON orgHPP.paymentProfileID=organization.paymentProfileID 
LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID

WHERE hist_paymentProfile.MODIFY_DATE_TIME >= '2009-01-01'
AND oldHPP.productID >= 3
AND CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END > 0
AND oldHPP.accountType = 1 AND hist_paymentProfile.accountType = 2
AND hist_paymentProfile.parentPaymentProfileID IS NOT NULL
/* Upgrades determined by change in Monthly payments*/

#AND ((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm)
# < ((CASE WHEN orgHPP.CURRENCY_CODE = 'USD' THEN orgHPP.planRate ELSE (orgHPP.planRate/hce3.EXCHANGE_RATE) END)/orgHPP.paymentTerm)

AND oldHPP.planRate/oldHPP.paymentTerm < orgHPP.planRate/orgHPP.paymentTerm
 
AND hist_paymentProfile.paymentProfileID NOT IN (1274492) /* Exclude Team Smartsheet*/
AND hist_paymentProfile.paymentType != 4
AND organization.insertByUserID=hist_paymentProfile.OWNER_ID

AND (hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.MODIFY_DATE_TIME, INTERVAL -30 SECOND) 
OR hist_paymentProfile.paymentStartDateTime = hist_paymentProfile.MODIFY_DATE_TIME 
OR hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.MODIFY_DATE_TIME, INTERVAL +10 SECOND))

AND orgHPP.paymentStartDateTime < months.startMonth
AND (hist_paymentProfile.MODIFY_DATE_TIME >= @maxWINRecordDate OR hist_paymentProfile.paymentProfileID IN(10040801,
7948110))  /* Grabs new upgrades*/
;


-- Get DOWNGRADES since last run
INSERT IGNORE INTO rpt_main_02.stg_sfdc_upload_transactions
SELECT
hist_paymentProfile.paymentProfileID AS parentPaymentProfileID,
organization.mainContactUserID,
CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
userAccount.FIRST_NAME,
userAccount.LAST_NAME,
userAccount.emailAddress,
hist_paymentProfile.OWNER_ID,
organization.name AS OrgName,
SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
IFNULL(hist_paymentProfile.bonusSheetCount,0) AS bonusSheetCount,
IFNULL(hist_paymentProfile.bonusUserCount,0) AS bonusUserCount,
oldHPP.billToCCName,
CONCAT(oldHPP.billToAddress1,' ',oldHPP.billtoAddress2) AS billToAddress,
oldHPP.billToCity,
oldHPP.billToRegionCode,
oldHPP.billToPostCode,
oldHPP.billToCountryCode,

rpt_main_02.SMARTSHEET_PAYMENTTERM(oldHPP.paymentTerm) AS OldPaymentTerm,
rpt_main_02.SMARTSHEET_PAYMENTTERM(hist_paymentProfile.paymentTerm) AS NewPaymentTerm,
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
oldHPP.userLimit AS OldUserLimit,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.userLimit-oldHPP.userLimit AS userLimitChange,
(CASE WHEN (CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END) = 0
	THEN ((CASE WHEN orgHPP.CURRENCY_CODE = 'USD' THEN orgHPP.planRate ELSE (orgHPP.planRate/hce3.EXCHANGE_RATE) END)/orgHPP.paymentTerm)
ELSE ((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm)
END) AS OldMonthlyPayment,

((CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate 
	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)END)/hist_paymentProfile.paymentTerm) AS NewMonthlyPayment,

((CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate 
	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)END)/hist_paymentProfile.paymentTerm)-
(CASE WHEN (CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END) = 0
	THEN ((CASE WHEN orgHPP.CURRENCY_CODE = 'USD' THEN orgHPP.planRate ELSE (orgHPP.planRate/hce3.EXCHANGE_RATE) END)/orgHPP.paymentTerm)
ELSE ((CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm)
END) AS MonthlyPaymentChange,
NULL AS bucket,
'DOWNGRADES' AS recordType,
hist_paymentProfile.paymentStartDateTime,
hist_paymentProfile.actualLastPaymentDate,
hist_paymentProfile.nextPaymentDate AS calculatedNextPaymentDate,
hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.MODIFY_DATE_TIME AS lastModifiedDateTime,
hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME,
hist_paymentProfile.MODIFY_DATE_TIME AS recordDateTime

FROM ss_core_02.hist_paymentProfile
JOIN ss_core_02.hist_paymentProfile oldHPP ON hist_paymentProfile.paymentProfileId=oldHPP.paymentProfileID
LEFT JOIN ss_core_02.hist_paymentProfile orgHPP ON oldHPP.parentPaymentProfileID=orgHPP.paymentProfileID
	AND oldHPP.MODIFY_DATE_TIME = orgHPP.MODIFY_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/	
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce2 ON oldHPP.CURRENCY_CODE=hce2.CURRENCY_CODE
	AND oldHPP.MODIFY_DATE_TIME BETWEEN hce2.MODIFY_DATE_TIME AND hce2.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce3 ON orgHPP.CURRENCY_CODE=hce3.CURRENCY_CODE
	AND orgHPP.MODIFY_DATE_TIME BETWEEN hce3.MODIFY_DATE_TIME AND hce3.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN ss_core_02.organization ON hist_paymentProfile.paymentProfileID=organization.paymentProfileID
LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID

WHERE hist_paymentProfile.MODIFY_DATE_TIME >= '2009-01-01'
AND hist_paymentProfile.productID >= 3
AND CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END > 0
AND hist_paymentProfile.accountType != 2
AND hist_paymentProfile.paymentProfileID NOT IN (1274492) /* Exclude Team Smartsheet*/
AND hist_paymentProfile.paymentType != 4
AND oldHPP.productID NOT IN (3,4) /* Exclude Downgrades from Advanced or Basic products*/
AND hist_paymentProfile.MODIFY_DATE_TIME = oldHPP.HIST_EFFECTIVE_THRU_DATE_TIME
AND hist_paymentProfile.MODIFY_DATE_TIME >= @maxRecordDate /* Grabs new Downgrades*/
#HAVING OldMonthlyPayment > NewMonthlyPayment /* Downgrades based on decrease in monthly payment value*/
AND 
(CASE WHEN oldHPP.planRate = 0 THEN orgHPP.planRate/orgHPP.paymentTerm ELSE oldHPP.planRate/oldHPP.paymentTerm END)
	> hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm
;

-- Get new LOSSES since last run
INSERT IGNORE INTO rpt_main_02.stg_sfdc_upload_transactions
SELECT
hist_paymentProfile.paymentProfileID AS parentPaymentProfileID,
organization.mainContactUserID,
CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
userAccount.FIRST_NAME,
userAccount.LAST_NAME,
userAccount.emailAddress,
hist_paymentProfile.OWNER_ID,
organization.name AS OrgName,
SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
IFNULL(hist_paymentProfile.bonusSheetCount,0) AS bonusSheetCount,
IFNULL(hist_paymentProfile.bonususerCount,0) AS bonusUserCount,
oldHPP.billToCCName,
CONCAT(oldHPP.billToAddress1,' ',oldHPP.billtoAddress2) AS billToAddress,
oldHPP.billToCity,
oldHPP.billToRegionCode,
oldHPP.billToPostCode,
oldHPP.billToCountryCode,
rpt_main_02.SMARTSHEET_PAYMENTTERM(oldHPP.paymentTerm) AS OldPaymentTerm,
rpt_main_02.SMARTSHEET_PAYMENTTERM(hist_paymentProfile.paymentTerm) AS NewPaymentTerm,
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
oldHPP.userLimit AS OldUserLimit,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.userLimit-oldHPP.userLimit AS userLimitChange,
(CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm AS OldMonthlyPayment,
0 AS NewMonthlyPayment,
0 - (CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END)/oldHPP.paymentTerm AS MonthlyPaymentChange,
NULL AS bucket,
'LOSSES' AS recordType,
oldHPP.paymentStartDateTime,
oldHPP.actualLastPaymentDate,
oldHPP.nextPaymentDate AS calculatedNextPaymentDate,
oldHPP.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.MODIFY_DATE_TIME AS lastModifiedDateTime,
hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME,
hist_paymentProfile.MODIFY_DATE_TIME AS recordDateTime

FROM MAIN.REF.months months
JOIN ss_core_02.hist_paymentProfile ON hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME > months.endMonth
	AND hist_paymentProfile.MODIFY_DATE_TIME <= months.endMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
JOIN ss_core_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID=hist_paymentProfile.paymentProfileID
	AND oldHPP.HIST_EFFECTIVE_THRU_DATE_TIME > months.startMonth
	AND oldHPP.MODIFY_DATE_TIME <= months.startMonth
	AND months.startMonth <= CURRENT_TIMESTAMP()
/* Need exchange rates to convert plan rates into USD equivalents*/	
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
/* Need exchange rates to convert plan rates into USD equivalents*/
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce2 ON oldHPP.CURRENCY_CODE=hce2.CURRENCY_CODE
	AND oldHPP.MODIFY_DATE_TIME BETWEEN hce2.MODIFY_DATE_TIME AND hce2.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN ss_core_02.organization ON oldHPP.paymentProfileID=organization.paymentProfileID
LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID

WHERE hist_paymentProfile.MODIFY_DATE_TIME >= '2009-01-01'
AND hist_paymentProfile.productID IN (0,2) /* Current product should be Cancelled or Free*/
AND hist_paymentProfile.accountType != 2
AND CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END = 0
AND oldHPP.productID >= 6 /* Used to Be a Team or Enterprise Account*/
AND CASE WHEN oldHPP.CURRENCY_CODE = 'USD' THEN oldHPP.planRate ELSE (oldHPP.planRate/hce2.EXCHANGE_RATE) END > 0
AND hist_paymentProfile.paymentType != 4
AND hist_paymentProfile.MODIFY_DATE_TIME >= @maxRecordDate /*Grabs new Losses*/
;

/*If you need to add a skipped record run once with this section, replacing the ppid as appropriate*/
-- INSERT INTO rpt_main_02.stg_sfdc_upload_transactions
-- SELECT 
-- hist_paymentProfile.paymentProfileID AS parentPaymentProfileID,
-- organization.mainContactUserID,
-- CONCAT(userAccount.FIRST_NAME,' ',userAccount.LAST_NAME) AS mainContactName,
-- userAccount.FIRST_NAME,
-- userAccount.LAST_NAME,
-- userAccount.emailAddress,
-- hist_paymentProfile.OWNER_ID,
-- organization.name AS OrgName,
-- SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS OrgDomain,
-- rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
-- IFNULL(hist_paymentProfile.bonusSheetCount,0) AS bonusSheetCount,
-- IFNULL(hist_paymentProfile.bonusUserCount,0) AS bonusUserCount,
-- hist_paymentProfile.billToCCName,
-- CONCAT(hist_paymentProfile.billToAddress1,' ',hist_paymentProfile.billtoAddress2) AS billToAddress,
-- hist_paymentProfile.billToCity,
-- hist_paymentProfile.billToRegionCode,
-- hist_paymentProfile.billToPostCode,
-- hist_paymentProfile.billToCountryCode,
-- NULL AS OldPaymentTerm,
-- SMARTSHEET_PAYMENTTERM(hist_paymentProfile.paymentTerm) AS NewPaymentTerm,
-- NULL AS OldProductName,
-- SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
-- 0 AS OldUserLimit,
-- hist_paymentProfile.userLimit AS NewUserLimit,
-- hist_paymentProfile.userLimit-0 AS userLimitChange,
-- 0 AS OldMonthlyPayment,
-- (CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm 
--	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)/hist_paymentProfile.paymentTerm END) AS NewMonthlyPayment,
--
-- (CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm
--	ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE)/hist_paymentProfile.paymentTerm END) AS MonthlyPaymentChange,
-- NULL AS bucket,
-- 'WINS' AS recordType,
-- hist_paymentProfile.paymentStartDateTime AS paymentStartDateTime,
-- hist_paymentProfile.actualLastPaymentDate,
-- hist_paymentProfile.nextPaymentDate AS calculatedNextPaymentDate,
-- hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
-- hist_paymentProfile.MODIFY_DATE_TIME AS lastModifiedDateTime,
-- hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME,
-- hist_paymentProfile.paymentStartDateTime AS recordDateTime
--
-- FROM ss_core_02.hist_paymentProfile
-- JOIN MAIN.REF.months months FORCE INDEX (ref_months_end) ON hist_paymentProfile.HIST_EFFECTIVE_THRU_DATE_TIME > months.endMonth
--	AND hist_paymentProfile.MODIFY_DATE_TIME <= months.endMonth
--	AND hist_paymentProfile.paymentStartDateTime BETWEEN months.startMonth AND months.endMonth
--	AND months.startMonth <= CURRENT_TIMESTAMP()
-- /* Need exchange rates to convert plan rates into USD equivalents*/	
-- LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hist_paymentProfile.CURRENCY_CODE = hce.CURRENCY_CODE
--	AND hist_paymentProfile.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
-- LEFT JOIN ss_core_02.organization ON hist_paymentProfile.paymentProfileID=organization.paymentProfileID
-- LEFT JOIN ss_core_02.userAccount ON organization.mainContactUserID=userAccount.userID
-- WHERE hist_paymentProfile.productID >= 6 /* Team and Enterprise Only*/
-- AND CASE WHEN hist_paymentProfile.CURRENCY_CODE = 'USD' THEN planRate ELSE (hist_paymentProfile.planRate/hce.EXCHANGE_RATE) END > 0 /* converts planRate into USD equivalent*/
-- AND hist_paymentProfile.paymentType !=4
-- AND hist_paymentProfile.paymentProfileID = 5918478
-- ;

-- Create Upload table
CREATE TABLE IF NOT EXISTS rpt_main_02.`arc_sfdc_opportunityUpload` 
(
  `Id` INT(11) NOT NULL AUTO_INCREMENT,
  `parentPaymentProfileID` BIGINT(20) NOT NULL DEFAULT '0',
  `mainContactUserID` BIGINT(20) DEFAULT NULL,
  `mainContactName` VARCHAR(100) DEFAULT NULL,
  `FIRST_NAME` VARCHAR(100) DEFAULT NULL,
  `LAST_NAME` VARCHAR(100) DEFAULT NULL,
  `orgAdminEmail` VARCHAR(100) DEFAULT NULL,
  `OWNER_ID` BIGINT(20) DEFAULT NULL,
  `organizationName` VARCHAR(100) DEFAULT NULL,
  `organizationDomain` VARCHAR(100) DEFAULT NULL,
  `newPaymentType` VARCHAR(20) DEFAULT NULL,
  `bonusSheetCount` INT(11) DEFAULT NULL,
  `bonusUserCount` INT(11) DEFAULT NULL,
  `billToCCName` VARCHAR(100) DEFAULT NULL,
  `billToAddress` VARCHAR(300) DEFAULT NULL,
  `billToCity` VARCHAR(50) DEFAULT NULL,
  `billToRegionCode` VARCHAR(50) DEFAULT NULL,
  `billToPostCode` VARCHAR(50) DEFAULT NULL,
  `billToCountryCode` VARCHAR(50) DEFAULT NULL,
  `oldPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `newPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `oldProductName` VARCHAR(20) DEFAULT NULL,
  `newProductName` VARCHAR(20) DEFAULT NULL,
  `oldUserLimit` INT(11) DEFAULT NULL,
  `newUserLimit` INT(11) DEFAULT NULL,
  `userLimitChange` INT(11) DEFAULT NULL,
  `oldPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `newPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `paymentTotalChange` DECIMAL(40,8) DEFAULT NULL,
  `bucket` VARCHAR(20) DEFAULT NULL,
  `recordType` VARCHAR(20) DEFAULT NULL,
  `paymentStartDateTime` DATETIME DEFAULT NULL,
  `actualLastPaymentDate` DATETIME DEFAULT NULL,
  `calculatedNextPaymentDate` DATETIME DEFAULT NULL,
  `paymentProfileInsertDateTime` DATETIME DEFAULT NULL,
  `paymentProfileLastModifiedDateTime` DATETIME DEFAULT NULL,
  `HIST_EFFECTIVE_THRU_DATE_TIME` DATETIME DEFAULT NULL,
  `recordDateTime` DATETIME DEFAULT NULL,
  `lastTransactionDateTime` DATETIME DEFAULT NULL,
  `daysSinceLastTransaction` INT(11) DEFAULT NULL,
  `uploadDateTime` DATETIME DEFAULT NULL,
  `pushToSalesforce` INT(11) DEFAULT NULL,
  `transactionNumber` INT(11) DEFAULT NULL,
  `insertDateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  KEY `ix_sfdc_update` (`parentPaymentProfileID`)
) DEFAULT CHARSET=utf8
;


CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.`arc_sfdc_insight_data_integrators` 
(
  `Id` INT(11) NOT NULL,
  `parentPaymentProfileID` BIGINT(20) NOT NULL DEFAULT '0',
  `mainContactUserID` BIGINT(20) DEFAULT NULL,
  `mainContactName` VARCHAR(100) DEFAULT NULL,
  `FIRST_NAME` VARCHAR(100) DEFAULT NULL,
  `LAST_NAME` VARCHAR(100) DEFAULT NULL,
  `orgAdminEmail` VARCHAR(100) DEFAULT NULL,
  `OWNER_ID` BIGINT(20) DEFAULT NULL,
  `organizationName` VARCHAR(100) DEFAULT NULL,
  `organizationDomain` VARCHAR(100) DEFAULT NULL,
  `newPaymentType` VARCHAR(20) DEFAULT NULL,
  `bonusSheetCount` INT(11) DEFAULT NULL,
  `bonusUserCount` INT(11) DEFAULT NULL,
  `billToCCName` VARCHAR(100) DEFAULT NULL,
  `billToAddress` VARCHAR(300) DEFAULT NULL,
  `billToCity` VARCHAR(50) DEFAULT NULL,
  `billToRegionCode` VARCHAR(50) DEFAULT NULL,
  `billToPostCode` VARCHAR(50) DEFAULT NULL,
  `billToCountryCode` VARCHAR(50) DEFAULT NULL,
  `oldPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `newPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `oldProductName` VARCHAR(20) DEFAULT NULL,
  `newProductName` VARCHAR(20) DEFAULT NULL,
  `oldUserLimit` INT(11) DEFAULT NULL,
  `newUserLimit` INT(11) DEFAULT NULL,
  `userLimitChange` INT(11) DEFAULT NULL,
  `oldPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `newPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `paymentTotalChange` DECIMAL(40,8) DEFAULT NULL,
  `bucket` VARCHAR(20) DEFAULT NULL,
  `recordType` VARCHAR(20) DEFAULT NULL,
  `paymentStartDateTime` DATETIME DEFAULT NULL,
  `actualLastPaymentDate` DATETIME DEFAULT NULL,
  `calculatedNextPaymentDate` DATETIME DEFAULT NULL,
  `paymentProfileInsertDateTime` DATETIME DEFAULT NULL,
  `paymentProfileLastModifiedDateTime` DATETIME DEFAULT NULL,
  `HIST_EFFECTIVE_THRU_DATE_TIME` DATETIME DEFAULT NULL,
  `recordDateTime` DATETIME DEFAULT NULL,
  `lastTransactionDateTime` DATETIME DEFAULT NULL,
  `daysSinceLastTransaction` INT(11) DEFAULT NULL,
  `uploadDateTime` DATETIME DEFAULT NULL,
  `pushToSalesforce` INT(11) DEFAULT NULL,
  `transactionNumber` INT(11) DEFAULT NULL,
  `insertDateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
    domainID VARCHAR(50),
  repOWNER_ID VARCHAR(50),
  PRIMARY KEY (`Id`),
  KEY `ix_sfdc_update` (`parentPaymentProfileID`),
  KEY domainID (domainID)
) DEFAULT CHARSET=utf8
;

-- Clear out upload table
#TRUNCATE TABLE MAIN.ARC.sfdc_insight_data_integrators;

-- Move delayed records from last run into upload table
INSERT INTO SFDC.PUBLIC.arc_sfdc_insight_data_integrators
(
Id, 
parentPaymentProfileID, 
mainContactUserID, 
mainContactName, 
FIRST_NAME, 
LAST_NAME, 
orgAdminEmail,
OWNER_ID, 
organizationName, 
organizationDomain,
newPaymentType, 
bonusSheetCount, 
bonusUserCount, 
billToCCName, 
billToAddress, 
billToCity, 
billToRegionCode, 
billToPostCode, 
billToCountryCode,
oldPaymentTerm, 
newPaymentTerm, 
oldProductName, 
newProductName, 
oldUserLimit, 
newUserLimit, 
userLimitChange, 
oldPaymentTotal, 
newPaymentTotal,
paymentTotalChange, 
bucket, 
recordType, 
paymentStartDateTime, 
actualLastPaymentDate, 
calculatedNextPaymentDate, 
paymentProfileInsertDateTime,
paymentProfileLastModifiedDateTime, 
HIST_EFFECTIVE_THRU_DATE_TIME, 
recordDateTime, 
lastTransactionDateTime, 
daysSinceLastTransaction, 
uploadDateTime,
pushToSalesforce, 
transactionNumber, 
insertDateTime)
SELECT 
Id, 
parentPaymentProfileID, 
mainContactUserID, 
mainContactName, 
FIRST_NAME, 
LAST_NAME, 
orgAdminEmail,
OWNER_ID, 
organizationName, 
organizationDomain,
newPaymentType, 
bonusSheetCount, 
bonusUserCount, 
billToCCName, 
billToAddress, 
billToCity, 
billToRegionCode, 
billToPostCode, 
billToCountryCode,
oldPaymentTerm, 
newPaymentTerm, 
oldProductName, 
newProductName, 
oldUserLimit, 
newUserLimit, 
userLimitChange, 
oldPaymentTotal, 
newPaymentTotal,
paymentTotalChange, 
bucket, 
recordType, 
paymentStartDateTime, 
actualLastPaymentDate, 
calculatedNextPaymentDate, 
paymentProfileInsertDateTime,
paymentProfileLastModifiedDateTime, 
HIST_EFFECTIVE_THRU_DATE_TIME, 
recordDateTime, 
lastTransactionDateTime, 
daysSinceLastTransaction, 
uploadDateTime,
pushToSalesforce, 
transactionNumber, 
insertDateTime
FROM MAIN.ARC.sfdc_insight_data_integrators_next
;


-- Insert new records into archive table
INSERT INTO MAIN.ARC.sfdc_opportunityUpload 
(
	parentPaymentProfileID,
	mainContactUserID,
	mainContactName,
	FIRST_NAME,
	LAST_NAME,
	orgAdminEmail,
	OWNER_ID,
	organizationName,
	organizationDomain,
	newPaymentType,
	bonusSheetCount,
	bonusUserCount,
	billToCCName,
	billToAddress,
	billToCity,
	billToRegionCode,
	billToPostCode,
	billToCountryCode,
	oldPaymentTerm,
	newPaymentTerm,
	oldProductName,
	newProductName,
	oldUserLimit,
	newUserLimit,
	userLimitChange,
	oldPaymentTotal,
	newPaymentTotal,
	paymentTotalChange,
	bucket,
	recordType,
	paymentStartDateTime,
	actualLastPaymentDate,
	calculatedNextPaymentDate,
	paymentProfileInsertDateTime,
	paymentProfileLastModifiedDateTime,
	HIST_EFFECTIVE_THRU_DATE_TIME,
	recordDateTime,
	pushToSalesforce
)
SELECT 
	a.parentPaymentProfileID,
	a.mainContactUserID,
	a.mainContactName,
	a.FIRST_NAME,
	a.LAST_NAME,
	a.orgAdminEmail,
	a.OWNER_ID,
	a.organizationName,
	a.organizationDomain,
	a.newPaymentType,
	a.bonusSheetCount,
	a.bonusUserCount,
	a.billToCCName,
	a.billToAddress,
	a.billToCity,
	a.billToRegionCode,
	a.billToPostCode,
	a.billToCountryCode,
	a.oldPaymentTerm,
	a.newPaymentTerm,
	a.oldProductName,
	a.newProductName,
	a.oldUserLimit,
	a.newUserLimit,
	a.userLimitChange,
	a.oldMonthlyPayment*12,
	a.newMonthlyPayment*12,
	a.MonthlyPaymentChange*12,
	a.bucket,
	a.recordType,
	a.paymentStartDateTime,
	a.actualLastPaymentDate,
	a.calculatedNextPaymentDate,
	a.paymentProfileInsertDateTime,
	a.paymentProfileLastModifiedDateTime,
	a.HIST_EFFECTIVE_THRU_DATE_TIME,
	a.recordDateTime,
	1 /* Flag for SFDC Upload: Only records with a value of 1 should be uploaded */ 
FROM rpt_main_02.stg_sfdc_upload_transactions a
LEFT JOIN MAIN.ARC.sfdc_opportunityUpload exclude ON a.parentPaymentProfileID=exclude.parentPaymentProfileID
	AND a.recordDateTime=exclude.recordDateTime
WHERE exclude.parentPaymentProfileID IS NULL
ORDER BY a.parentPaymentProfileID, a.recordDateTime
;




-- Set Transaction Number for each transaction
-- These should start over for each unique parentPaymnentProfileID
-- Used to determine the lastTransactionDateTime and daysSinceLastTransaction
SET @row_number:=0;
SET @pppid := '';

UPDATE MAIN.ARC.sfdc_opportunityUpload a
JOIN
	(
		SELECT *, @row_number:= CASE WHEN @pppid=parentPaymentProfileID THEN @row_number+1 ELSE 1 END AS row_number, @pppid:=parentpaymentProfileID AS pppid 
		FROM MAIN.ARC.sfdc_opportunityUpload
		ORDER BY parentPaymentProfileID
	) b ON a.parentPaymentProfileID=b.pppid AND a.recordDateTime=b.recordDateTime
SET a.transactionNumber=b.row_number
;


-- Set lastTransactionDateTime and daysSinceLastTransaction
UPDATE MAIN.ARC.sfdc_opportunityUpload a
JOIN MAIN.ARC.sfdc_opportunityUpload b FORCE INDEX (ix_sfdc_update) ON a.parentPaymentProfileID=b.parentPaymentProfileID
	AND a.transactionNumber=b.transactionNumber+1
SET a.lastTransactionDateTime = b.recordDateTime,
	a.daysSinceLastTransaction = DATEDIFF(a.recordDateTime, b.recordDateTime)
;


-- Load only new transactions into upload table since last run
INSERT INTO SFDC.PUBLIC.arc_sfdc_insight_data_integrators 
(
	Id,
	parentPaymentProfileID,
	mainContactUserID,
	mainContactName,
	FIRST_NAME,
	LAST_NAME,
	orgAdminEmail,
	OWNER_ID,
	organizationName,
	organizationDomain,
	newPaymentType,
	bonusSheetCount,
	bonusUserCount,
	billToCCName,
	billToAddress,
	billToCity,
	billToRegionCode,
	billToPostCode,
	billToCountryCode,
	oldPaymentTerm,
	newPaymentTerm,
	oldProductName,
	newProductName,
	oldUserLimit,
	newUserLimit,
	userLimitChange,
	oldPaymentTotal,
	newPaymentTotal,
	paymentTotalChange,
	bucket,
	recordType,
	paymentStartDateTime,
	actualLastPaymentDate,
	calculatedNextPaymentDate,
	paymentProfileInsertDateTime,
	paymentProfileLastModifiedDateTime,
	HIST_EFFECTIVE_THRU_DATE_TIME,
	recordDateTime,
	lastTransactionDateTime,
	daysSinceLastTransaction,
	uploadDateTime,
	pushToSalesforce,
	transactionNumber,
	insertDateTime
)
SELECT 
	Id,
	parentPaymentProfileID,
	mainContactUserID,
	mainContactName,
	FIRST_NAME,
	LAST_NAME,
	orgAdminEmail,
	OWNER_ID,
	organizationName,
	organizationDomain,
	newPaymentType,
	bonusSheetCount,
	bonusUserCount,
	billToCCName,
	billToAddress,
	billToCity,
	billToRegionCode,
	billToPostCode,
	billToCountryCode,
	oldPaymentTerm,
	newPaymentTerm,
	oldProductName,
	newProductName,
	oldUserLimit,
	newUserLimit,
	userLimitChange,
	oldPaymentTotal,
	newPaymentTotal,
	paymentTotalChange,
	bucket,
	recordType,
	paymentStartDateTime,
	actualLastPaymentDate,
	calculatedNextPaymentDate,
	paymentProfileInsertDateTime,
	paymentProfileLastModifiedDateTime,
	HIST_EFFECTIVE_THRU_DATE_TIME,
	recordDateTime,
	lastTransactionDateTime,
	daysSinceLastTransaction,
	uploadDateTime,
	pushToSalesforce,
	transactionNumber,
	insertDateTime
FROM MAIN.ARC.sfdc_opportunityUpload
WHERE pushToSalesforce = 1
;

UPDATE SFDC.PUBLIC.arc_sfdc_insight_data_integrators A
JOIN SFDC.PUBLIC.domain d ON d.Domain_Name_URL__c = A.organizationDomain
SET 	A.domainID = d.Id,
	A.repOWNER_ID = d.OWNER_ID;



CREATE TABLE IF NOT EXISTS rpt_main_02.`arc_sfdc_insight_data_integrators_next` 
(
  `Id` INT(11) NOT NULL,
  `parentPaymentProfileID` BIGINT(20) NOT NULL DEFAULT '0',
  `mainContactUserID` BIGINT(20) DEFAULT NULL,
  `mainContactName` VARCHAR(100) DEFAULT NULL,
  `FIRST_NAME` VARCHAR(100) DEFAULT NULL,
  `LAST_NAME` VARCHAR(100) DEFAULT NULL,
  `orgAdminEmail` VARCHAR(100) DEFAULT NULL,
  `OWNER_ID` BIGINT(20) DEFAULT NULL,
  `organizationName` VARCHAR(100) DEFAULT NULL,
  `organizationDomain` VARCHAR(100) DEFAULT NULL,
  `newPaymentType` VARCHAR(20) DEFAULT NULL,
  `bonusSheetCount` INT(11) DEFAULT NULL,
  `bonusUserCount` INT(11) DEFAULT NULL,
  `billToCCName` VARCHAR(100) DEFAULT NULL,
  `billToAddress` VARCHAR(300) DEFAULT NULL,
  `billToCity` VARCHAR(50) DEFAULT NULL,
  `billToRegionCode` VARCHAR(50) DEFAULT NULL,
  `billToPostCode` VARCHAR(50) DEFAULT NULL,
  `billToCountryCode` VARCHAR(50) DEFAULT NULL,
  `oldPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `newPaymentTerm` VARCHAR(20) DEFAULT NULL,
  `oldProductName` VARCHAR(20) DEFAULT NULL,
  `newProductName` VARCHAR(20) DEFAULT NULL,
  `oldUserLimit` INT(11) DEFAULT NULL,
  `newUserLimit` INT(11) DEFAULT NULL,
  `userLimitChange` INT(11) DEFAULT NULL,
  `oldPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `newPaymentTotal` DECIMAL(40,8) DEFAULT NULL,
  `paymentTotalChange` DECIMAL(40,8) DEFAULT NULL,
  `bucket` VARCHAR(20) DEFAULT NULL,
  `recordType` VARCHAR(20) DEFAULT NULL,
  `paymentStartDateTime` DATETIME DEFAULT NULL,
  `actualLastPaymentDate` DATETIME DEFAULT NULL,
  `calculatedNextPaymentDate` DATETIME DEFAULT NULL,
  `paymentProfileInsertDateTime` DATETIME DEFAULT NULL,
  `paymentProfileLastModifiedDateTime` DATETIME DEFAULT NULL,
  `HIST_EFFECTIVE_THRU_DATE_TIME` DATETIME DEFAULT NULL,
  `recordDateTime` DATETIME DEFAULT NULL,
  `lastTransactionDateTime` DATETIME DEFAULT NULL,
  `daysSinceLastTransaction` INT(11) DEFAULT NULL,
  `uploadDateTime` DATETIME DEFAULT NULL,
  `pushToSalesforce` INT(11) DEFAULT NULL,
  `transactionNumber` INT(11) DEFAULT NULL,
  `insertDateTime` DATETIME DEFAULT CURRENT_TIMESTAMP,
    domainID VARCHAR(50),
  repOWNER_ID VARCHAR(50),
  `row_number` INT(11) DEFAULT NULL,
  `pppid` BIGINT(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ix_sfdc_update` (`parentPaymentProfileID`),
  KEY domainID (domainID)
) DEFAULT CHARSET=utf8
;

-- Empty table that holds records that need to be delayed for next run
TRUNCATE TABLE MAIN.ARC.sfdc_insight_data_integrators_next;

-- Add records to delayed run set
SET @row_number:=0;
SET @pppid := '';

INSERT INTO MAIN.ARC.sfdc_insight_data_integrators_next
SELECT idi.*, 
@row_number:= CASE WHEN @pppid=idi.parentPaymentProfileID THEN @row_number+1 ELSE 1 END AS row_number, @pppid:=idi.parentpaymentProfileID AS pppid
FROM SFDC.PUBLIC.arc_sfdc_insight_data_integrators idi
JOIN
	(
	SELECT parentPaymentProfileID, COUNT(*)
	FROM SFDC.PUBLIC.arc_sfdc_insight_data_integrators
	GROUP BY parentPaymentProfileID
	HAVING COUNT(*) > 1
	) idid
ON idi.parentPaymentProfileID=idid.parentPaymentProfileID
ORDER BY idi.parentPaymentProfileID, idi.recordDateTime
;


-- Remove the single instances so we only have transactions in this table that would cause a PPPID issue
DELETE FROM MAIN.ARC.sfdc_insight_data_integrators_next WHERE row_number = 1;


-- Remove the dupe pppid transactions from the upload table so we have one transaction per pppid
DELETE SFDC.PUBLIC.arc_sfdc_insight_data_integrators
FROM SFDC.PUBLIC.arc_sfdc_insight_data_integrators
LEFT JOIN MAIN.ARC.sfdc_insight_data_integrators_next ON 
	arc_sfdc_insight_data_integrators.parentPaymentProfileID=arc_sfdc_insight_data_integrators_next.parentPaymentProfileID
	WHERE arc_sfdc_insight_data_integrators_next.recordDateTime = arc_sfdc_insight_data_integrators.recordDateTime
	AND arc_sfdc_insight_data_integrators_next.Id = arc_sfdc_insight_data_integrators.Id
;

-- Update pushToSalesforce flag on records added this run
UPDATE MAIN.ARC.sfdc_opportunityUpload SET pushToSalesforce = 0 WHERE pushToSalesforce = 1;


