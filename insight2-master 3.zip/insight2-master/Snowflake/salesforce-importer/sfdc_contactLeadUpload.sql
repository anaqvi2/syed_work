USE ss_sfdc_02;
SELECT CURRENT_DATABASE();


SET tokudb_lock_timeout = 300000;


SELECT '********** START: ', ROW_COUNT(), CURRENT_TIMESTAMP();

SELECT CURRENT_TIMESTAMP()
INTO @currentRunDateTime;

# Contact/lead update delay currently three days, 72 hours.
# This runs every 24 hours, so we look back one less day for @lastRunDelay.
SET defaultDelay = 72;
SELECT @defaultDelay - 24 INTO @lastRunDelay;

# This is the marker to prevent leads and contacts from getting pushed to Salesforce too often.
# The LEAST calculation is to ensure we don't flood the sync queue if this doesn't run for several days.
SELECT LEAST(DATE_SUB(MAX(lastRunDateTime), INTERVAL @lastRunDelay HOUR), DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL @defaultDelay HOUR))
INTO @lastPushDateTimeMarker
FROM SFDC.PUBLIC.arc_sfdc_upload_cursor
;
SELECT @defaultDelay, @lastRunDelay, @lastPushDateTimeMarker;

CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.arc_sfdc_upload_cursor (
    cursorID          BIGINT      NOT NULL AUTO_INCREMENT,
    uploadType        VARCHAR(32) NOT NULL,
    lastRunDateTime   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    maxUpdateDateTime DATETIME             DEFAULT NULL,
    PRIMARY KEY (cursorID),
    KEY (uploadType)
)
;

# Get max cursor datetime from the last successful run. If there is no max datetime, set to 1 day prior.
# SELECT CASE
#        WHEN MAX(maxUpdateDateTime) IS NULL
#            THEN DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
#        ELSE MAX(maxUpdateDateTime)
#        END
# INTO @lastMaxUpdateDateTime
# FROM SFDC.PUBLIC.arc_sfdc_upload_cursor
# WHERE uploadType = 'contact_lead'
# ;
# SELECT @lastMaxUpdateDateTime;

# Create new record and get the row ID
INSERT INTO SFDC.PUBLIC.arc_sfdc_upload_cursor (uploadType, lastRunDateTime) VALUES ('contact_lead', @currentRunDateTime);
SET @lastID = LAST_INSERT_ID();
SELECT @lastID;

# Recreate the contact upload table
CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.arc_sfdc_contact_upload (
    ID                      VARCHAR(25)                  NOT NULL DEFAULT '',
    updateDateTime          DATETIME                     NOT NULL,
    emailAddress            VARCHAR(100)                 NOT NULL,
    LAST_NAME                VARCHAR(80)                           DEFAULT NULL,
    lastLogin               DATETIME                              DEFAULT NULL,
    lastMobileLogin         DATETIME                              DEFAULT NULL,
    isEverWellQualified     TINYINT(1) DEFAULT 0         NULL,
    isStrongLead            TINYINT(1) DEFAULT 0         NULL,
    attachmentCount         INT(11) DEFAULT 0            NULL,
    columnPropertyFormCount INT(11) DEFAULT 0            NULL,
    dashboardCount          INT(11) DEFAULT 0            NULL,
    discussionCount         INT(11) DEFAULT 0            NULL,
    eventLogCount           INT(11) DEFAULT 0            NULL,
    hierarchyCount          INT(11) DEFAULT 0            NULL,
    imagesInGridCount       INT(11) DEFAULT 0            NULL,
    importedSheetCount      INT(11) DEFAULT 0            NULL,
    loginCount              INT(11) DEFAULT 0            NULL,
    reportCount             INT(11) DEFAULT 0            NULL,
    sharingCount            INT(11) DEFAULT 0            NULL,
    sheetCount              INT(11) DEFAULT 0            NULL,
    templateCount           INT(11) DEFAULT 0            NULL,
    webFormCount            INT(11) DEFAULT 0            NULL,
    usedBrandedWorkspace    TINYINT(1) DEFAULT 0         NULL,
    usedCellLinking         TINYINT(1) DEFAULT 0         NULL,
    usedChangeView          TINYINT(1) DEFAULT 0         NULL,
    usedDriveAttachment     TINYINT(1) DEFAULT 0         NULL,
    usedEvernoteAttachment  TINYINT(1) DEFAULT 0         NULL,
    usedReminders           TINYINT(1) DEFAULT 0         NULL,
    solutionsUsed           VARCHAR(1000) DEFAULT '#N/A' NULL,
    cardViewViewCount       INT(11) DEFAULT 0            NULL,
    PRIMARY KEY (ID)
)
;

# Recreate the lead upload table
# DROP TABLE IF EXISTS SFDC.PUBLIC.arc_sfdc_lead_upload;
CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.arc_sfdc_lead_upload (
    ID                      VARCHAR(25)                  NOT NULL DEFAULT '',
    updateDateTime          DATETIME                     NOT NULL,
    emailAddress            VARCHAR(100)                 NOT NULL,
    LAST_NAME                VARCHAR(80)                           DEFAULT NULL,
    company                 VARCHAR(255)                          DEFAULT NULL,
    lastLogin               DATETIME                              DEFAULT NULL,
    lastMobileLogin         DATETIME                              DEFAULT NULL,
    isEverWellQualified     TINYINT(1) DEFAULT 0         NULL,
    isStrongLead            TINYINT(1) DEFAULT 0         NULL,
    attachmentCount         INT(11) DEFAULT 0            NULL,
    columnPropertyFormCount INT(11) DEFAULT 0            NULL,
    dashboardCount          INT(11) DEFAULT 0            NULL,
    discussionCount         INT(11) DEFAULT 0            NULL,
    eventLogCount           INT(11) DEFAULT 0            NULL,
    hierarchyCount          INT(11) DEFAULT 0            NULL,
    imagesInGridCount       INT(11) DEFAULT 0            NULL,
    importedSheetCount      INT(11) DEFAULT 0            NULL,
    loginCount              INT(11) DEFAULT 0            NULL,
    reportCount             INT(11) DEFAULT 0            NULL,
    sharingCount            INT(11) DEFAULT 0            NULL,
    sheetCount              INT(11) DEFAULT 0            NULL,
    templateCount           INT(11) DEFAULT 0            NULL,
    webFormCount            INT(11) DEFAULT 0            NULL,
    usedBrandedWorkspace    TINYINT(1) DEFAULT 0         NULL,
    usedCellLinking         TINYINT(1) DEFAULT 0         NULL,
    usedChangeView          TINYINT(1) DEFAULT 0         NULL,
    usedDriveAttachment     TINYINT(1) DEFAULT 0         NULL,
    usedEvernoteAttachment  TINYINT(1) DEFAULT 0         NULL,
    usedReminders           TINYINT(1) DEFAULT 0         NULL,
    upgradeWizardProgress   VARCHAR(100) DEFAULT '#N/A'  NULL,
    solutionsUsed           VARCHAR(1000) DEFAULT '#N/A' NULL,
    cardViewViewCount       INT(11) DEFAULT 0            NULL,
    PRIMARY KEY (ID)
)
;


# Get a list of all users whose app activity data may have changed since last run.
# Use this list to narrow down the number of leads/contacts to push to SFDC.
DROP TABLE IF EXISTS SFDC.PUBLIC.tmp_sfdc_lead_contact_users;
CREATE TEMPORARY TABLE IF NOT EXISTS SFDC.PUBLIC.tmp_sfdc_lead_contact_users
(PRIMARY KEY (userID))
    SELECT userID
    FROM leadflow.arc_marketo_upload_journal
    WHERE
        journalDateTime >= @lastPushDateTimeMarker
        AND pushToMarketo >= 4 # priority for app activity changes
    GROUP BY userID
;
SELECT '********** tmp_sfdc_lead_contact_users rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();

# Insert all contacts updated since the cursor date into staging table
CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.stg_arc_sfdc_contact_upload LIKE SFDC.PUBLIC.arc_sfdc_contact_upload;
TRUNCATE TABLE SFDC.PUBLIC.stg_arc_sfdc_contact_upload;
INSERT IGNORE INTO SFDC.PUBLIC.stg_arc_sfdc_contact_upload
    SELECT
        c.Id,
        mu.updateDateTime,
        mu.emailAddress,
        c.LAST_NAME,
        mu.lastLogin,
        mu.lastMobileLogin,
        IFNULL(mu.isEverWellQualified, 0)     AS isEverWellQualified,
        IFNULL(mu.isStrongLead, 0)            AS isStrongLead,
        IFNULL(mu.attachmentCount, 0)         AS attachmentCount,
        IFNULL(mu.columnPropertyFormCount, 0) AS columnPropertyFormCount,
        IFNULL(mu.dashboardCount, 0)          AS dashboardCount,
        IFNULL(mu.discussionCount, 0)         AS discussionCount,
        IFNULL(mu.eventLogCount, 0)           AS eventLogCount,
        IFNULL(mu.hierarchyCount, 0)          AS hierarchyCount,
        IFNULL(mu.imagesInGridCount, 0)       AS imagesInGridCount,
        IFNULL(mu.importedSheetCount, 0)      AS importedSheetCount,
        IFNULL(mu.loginCount, 0)              AS loginCount,
        IFNULL(mu.reportCount, 0)             AS reportCount,
        IFNULL(mu.sharingCount, 0)            AS sharingCount,
        IFNULL(mu.sheetCount, 0)              AS sheetCount,
        IFNULL(mu.templateCount, 0)           AS templateCount,
        IFNULL(mu.webFormCount, 0)            AS webFormCount,
        IFNULL(mu.usedBrandedWorkspace, 0)    AS usedBrandedWorkspace,
        IFNULL(mu.usedCellLinking, 0)         AS usedCellLinking,
        IFNULL(mu.usedChangeView, 0)          AS usedChangeView,
        IFNULL(mu.usedDriveAttachment, 0)     AS usedDriveAttachment,
        IFNULL(mu.usedEvernoteAttachment, 0)  AS usedEvernoteAttachment,
        IFNULL(mu.usedReminders, 0)           AS usedReminders,
        IFNULL(mu.solutionsUsed, '#N/A')      AS solutionsUsed,
        IFNULL(mu.cardViewViewCount, 0)       AS cardViewViewCount
    FROM leadflow.arc_marketo_upload mu
        JOIN SFDC.PUBLIC.tmp_sfdc_lead_contact_users tu ON mu.userID = tu.userID
        JOIN SFDC.PUBLIC.contact c ON mu.emailAddress = c.Email
    WHERE
        mu.updateDateTime >= @lastPushDateTimeMarker
        AND COALESCE(c.lastPushQueueDateTime, '') < @lastPushDateTimeMarker
;
ANALYZE TABLE SFDC.PUBLIC.stg_arc_sfdc_contact_upload;

# Copy from staging to upload table. If it's already there, replace it with latest data.
INSERT INTO SFDC.PUBLIC.arc_sfdc_contact_upload
    SELECT *
    FROM SFDC.PUBLIC.stg_arc_sfdc_contact_upload stg
ON DUPLICATE KEY UPDATE
    SFDC.PUBLIC.arc_sfdc_contact_upload.updateDateTime          = stg.updateDateTime,
    SFDC.PUBLIC.arc_sfdc_contact_upload.emailAddress            = stg.emailAddress,
    SFDC.PUBLIC.arc_sfdc_contact_upload.LAST_NAME                = stg.LAST_NAME,
    SFDC.PUBLIC.arc_sfdc_contact_upload.lastLogin               = stg.lastLogin,
    SFDC.PUBLIC.arc_sfdc_contact_upload.lastMobileLogin         = stg.lastMobileLogin,
    SFDC.PUBLIC.arc_sfdc_contact_upload.isEverWellQualified     = stg.isEverWellQualified,
    SFDC.PUBLIC.arc_sfdc_contact_upload.isStrongLead            = stg.isStrongLead,
    SFDC.PUBLIC.arc_sfdc_contact_upload.attachmentCount         = stg.attachmentCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.columnPropertyFormCount = stg.columnPropertyFormCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.dashboardCount          = stg.dashboardCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.discussionCount         = stg.discussionCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.eventLogCount           = stg.eventLogCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.hierarchyCount          = stg.hierarchyCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.imagesInGridCount       = stg.imagesInGridCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.importedSheetCount      = stg.importedSheetCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.loginCount              = stg.loginCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.reportCount             = stg.reportCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.sharingCount            = stg.sharingCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.sheetCount              = stg.sheetCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.templateCount           = stg.templateCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.webFormCount            = stg.webFormCount,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedBrandedWorkspace    = stg.usedBrandedWorkspace,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedCellLinking         = stg.usedCellLinking,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedChangeView          = stg.usedChangeView,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedDriveAttachment     = stg.usedDriveAttachment,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedEvernoteAttachment  = stg.usedEvernoteAttachment,
    SFDC.PUBLIC.arc_sfdc_contact_upload.usedReminders           = stg.usedReminders,
    SFDC.PUBLIC.arc_sfdc_contact_upload.solutionsUsed           = stg.solutionsUsed,
    SFDC.PUBLIC.arc_sfdc_contact_upload.cardViewViewCount       = stg.cardViewViewCount
;
SELECT '********** INSERT INTO SFDC.PUBLIC.arc_sfdc_contact_upload rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();

# Update contact lastPushQueueDateTime value so we know when the contact was last pushed to SFDC
UPDATE SFDC.PUBLIC.contact c
    JOIN SFDC.PUBLIC.stg_arc_sfdc_contact_upload stg ON c.Id = stg.ID
SET c.lastPushQueueDateTime = @currentRunDateTime
;
SELECT '********** UPDATE SFDC.PUBLIC.contact lastPushQueueDateTime rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();


# Insert all leads updated since the cursor date
# Insert all contacts updated since the cursor date into staging table
CREATE TABLE IF NOT EXISTS SFDC.PUBLIC.stg_arc_sfdc_lead_upload LIKE SFDC.PUBLIC.arc_sfdc_lead_upload;
TRUNCATE TABLE SFDC.PUBLIC.stg_arc_sfdc_lead_upload;
INSERT IGNORE INTO SFDC.PUBLIC.stg_arc_sfdc_lead_upload
    SELECT
        l.Id,
        mu.updateDateTime,
        mu.emailAddress,
        l.LAST_NAME,
        l.Company,
        mu.lastLogin,
        mu.lastMobileLogin,
        IFNULL(mu.isEverWellQualified, 0)        AS isEverWellQualified,
        IFNULL(mu.isStrongLead, 0)               AS isStrongLead,
        IFNULL(mu.attachmentCount, 0)            AS attachmentCount,
        IFNULL(mu.columnPropertyFormCount, 0)    AS columnPropertyFormCount,
        IFNULL(mu.dashboardCount, 0)             AS dashboardCount,
        IFNULL(mu.discussionCount, 0)            AS discussionCount,
        IFNULL(mu.eventLogCount, 0)              AS eventLogCount,
        IFNULL(mu.hierarchyCount, 0)             AS hierarchyCount,
        IFNULL(mu.imagesInGridCount, 0)          AS imagesInGridCount,
        IFNULL(mu.importedSheetCount, 0)         AS importedSheetCount,
        IFNULL(mu.loginCount, 0)                 AS loginCount,
        IFNULL(mu.reportCount, 0)                AS reportCount,
        IFNULL(mu.sharingCount, 0)               AS sharingCount,
        IFNULL(mu.sheetCount, 0)                 AS sheetCount,
        IFNULL(mu.templateCount, 0)              AS templateCount,
        IFNULL(mu.webFormCount, 0)               AS webFormCount,
        IFNULL(mu.usedBrandedWorkspace, 0)       AS usedBrandedWorkspace,
        IFNULL(mu.usedCellLinking, 0)            AS usedCellLinking,
        IFNULL(mu.usedChangeView, 0)             AS usedChangeView,
        IFNULL(mu.usedDriveAttachment, 0)        AS usedDriveAttachment,
        IFNULL(mu.usedEvernoteAttachment, 0)     AS usedEvernoteAttachment,
        IFNULL(mu.usedReminders, 0)              AS usedReminders,
        IFNULL(mu.upgradeWizardProgress, '#N/A') AS upgradeWizardProgress,
        IFNULL(mu.solutionsUsed, '#N/A')         AS solutionsUsed,
        IFNULL(mu.cardViewViewCount, 0)          AS cardViewViewCount
    FROM leadflow.arc_marketo_upload mu
        JOIN SFDC.PUBLIC.tmp_sfdc_lead_contact_users tu ON mu.userID = tu.userID
        JOIN SFDC.PUBLIC.lead l ON mu.emailAddress = l.Email
        LEFT JOIN SFDC.PUBLIC.contact c ON mu.emailAddress = c.Email
    WHERE
        mu.updateDateTime >= @lastPushDateTimeMarker
        AND COALESCE(l.lastPushQueueDateTime, '') < @lastPushDateTimeMarker
        AND c.Email IS NULL          # If the user is also in the contact table, ignore.
        AND l.ConvertedDate IS NULL  # If the lead has a converted (to contact) date, ignore.
;
ANALYZE TABLE SFDC.PUBLIC.stg_arc_sfdc_lead_upload;

# Copy from staging to upload table. If it's already there, replace it with latest data.
INSERT INTO SFDC.PUBLIC.arc_sfdc_lead_upload
    SELECT *
    FROM SFDC.PUBLIC.stg_arc_sfdc_lead_upload stg
ON DUPLICATE KEY UPDATE
    SFDC.PUBLIC.arc_sfdc_lead_upload.updateDateTime          = stg.updateDateTime,
    SFDC.PUBLIC.arc_sfdc_lead_upload.emailAddress            = stg.emailAddress,
    SFDC.PUBLIC.arc_sfdc_lead_upload.LAST_NAME                = stg.LAST_NAME,
    SFDC.PUBLIC.arc_sfdc_lead_upload.lastLogin               = stg.lastLogin,
    SFDC.PUBLIC.arc_sfdc_lead_upload.lastMobileLogin         = stg.lastMobileLogin,
    SFDC.PUBLIC.arc_sfdc_lead_upload.isEverWellQualified     = stg.isEverWellQualified,
    SFDC.PUBLIC.arc_sfdc_lead_upload.isStrongLead            = stg.isStrongLead,
    SFDC.PUBLIC.arc_sfdc_lead_upload.attachmentCount         = stg.attachmentCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.columnPropertyFormCount = stg.columnPropertyFormCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.dashboardCount          = stg.dashboardCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.discussionCount         = stg.discussionCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.eventLogCount           = stg.eventLogCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.hierarchyCount          = stg.hierarchyCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.imagesInGridCount       = stg.imagesInGridCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.importedSheetCount      = stg.importedSheetCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.loginCount              = stg.loginCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.reportCount             = stg.reportCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.sharingCount            = stg.sharingCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.sheetCount              = stg.sheetCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.templateCount           = stg.templateCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.webFormCount            = stg.webFormCount,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedBrandedWorkspace    = stg.usedBrandedWorkspace,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedCellLinking         = stg.usedCellLinking,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedChangeView          = stg.usedChangeView,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedDriveAttachment     = stg.usedDriveAttachment,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedEvernoteAttachment  = stg.usedEvernoteAttachment,
    SFDC.PUBLIC.arc_sfdc_lead_upload.usedReminders           = stg.usedReminders,
    SFDC.PUBLIC.arc_sfdc_lead_upload.upgradeWizardProgress   = stg.upgradeWizardProgress,
    SFDC.PUBLIC.arc_sfdc_lead_upload.solutionsUsed           = stg.solutionsUsed,
    SFDC.PUBLIC.arc_sfdc_lead_upload.cardViewViewCount       = stg.cardViewViewCount
;
SELECT '********** INSERT INTO SFDC.PUBLIC.arc_sfdc_lead_upload rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();

# Update lead lastPushQueueDateTime value so we know when the lead was last pushed to SFDC
UPDATE SFDC.PUBLIC.lead l
    JOIN SFDC.PUBLIC.stg_arc_sfdc_lead_upload stg ON l.Id = stg.ID
SET l.lastPushQueueDateTime = @currentRunDateTime
;
SELECT '********** UPDATE SFDC.PUBLIC.lead lastPushQueueDateTime rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();


# Retrieve the max update datetime from the contact and lead tables
SELECT MAX(mx.updateDateTime)
INTO @maxUpdateDateTime
FROM (
         SELECT updateDateTime
         FROM SFDC.PUBLIC.arc_sfdc_contact_upload
         UNION ALL
         SELECT updateDateTime
         FROM SFDC.PUBLIC.arc_sfdc_lead_upload
     ) mx
;
SELECT @maxUpdateDateTime;

# Update the max cursor datetime
UPDATE SFDC.PUBLIC.arc_sfdc_upload_cursor
SET maxUpdateDateTime = @maxUpdateDateTime
WHERE cursorID = @lastID
;
SELECT '********** UPDATE SFDC.PUBLIC.arc_sfdc_upload_cursor rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();

SELECT '********** END: ', ROW_COUNT(), CURRENT_TIMESTAMP();
