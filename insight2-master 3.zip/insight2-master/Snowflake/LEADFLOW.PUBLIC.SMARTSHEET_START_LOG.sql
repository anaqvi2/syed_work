CREATE OR REPLACE FUNCTION LEADFLOW.PUBLIC.SMARTSHEET_START_LOG (
    BUILD_SOURCE  VARCHAR
   ,BUILD_STEP    VARCHAR
  )
  RETURNS TABLE (
    BUILD_ID        INTEGER
   ,BUILD_SEQUENCE  INTEGER
   ,BUILD_SOURCE    VARCHAR
   ,BUILD_STEP      VARCHAR
   ,START_TIME      TIMESTAMP_NTZ
   ,END_TIME        TIMESTAMP_NTZ
   ,TIME_ELAPSED    INTEGER
  )
AS '
  WITH CTE_TIME AS (
    SELECT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ AS START_TIME
  )
 ,CTE_PREV AS (
    SELECT X.START_TIME
          ,X.BUILD_ID
          ,X.BUILD_SEQUENCE
          ,X.BUILD_SOURCE    -- Not currently used
          ,X.BUILD_STEP      -- Not currently used
      FROM LEADFLOW.ARC.MARKETO_QUERY_HISTORY X
     ORDER BY X.START_TIME DESC
       LIMIT 1
  )
 ,CTE_CURR AS (
    SELECT (TO_DATE(P.START_TIME) = TO_DATE(T.START_TIME)) AS REUSE_BUILD_ID
          ,IFNULL(P.BUILD_ID, 0) + CASE WHEN REUSE_BUILD_ID THEN 0 ELSE 1 END AS BUILD_ID
          ,1 + CASE WHEN REUSE_BUILD_ID THEN P.BUILD_SEQUENCE ELSE 0 END AS BUILD_SEQUENCE
          ,T.START_TIME
      FROM CTE_TIME T
           LEFT JOIN CTE_PREV P
             ON TRUE
  )
  SELECT C.BUILD_ID
        ,C.BUILD_SEQUENCE 
        ,BUILD_SOURCE
        ,BUILD_STEP
        ,C.START_TIME
        ,NULL::TIMESTAMP_NTZ AS END_TIME
        ,NULL::INTEGER AS TIME_ELAPSED
    FROM CTE_CURR C
'
;

SELECT * FROM TABLE(LEADFLOW.PUBLIC.SMARTSHEET_START_LOG('ABC','DEF'))
;
INSERT INTO LEADFLOW.ARC.MARKETO_QUERY_HISTORY SELECT * FROM TABLE(LEADFLOW.PUBLIC.SMARTSHEET_START_LOG('ABC','DEF'))
;
SELECT * FROM LEADFLOW.ARC.MARKETO_QUERY_HISTORY ORDER BY START_TIME DESC
;

CREATE OR REPLACE FUNCTION LEADFLOW.PUBLIC.SMARTSHEET_STOP_LOG (
    BUILD_SOURCE  VARCHAR
   ,BUILD_STEP    VARCHAR
  )
  RETURNS TABLE (
    BUILD_SOURCE    VARCHAR
   ,BUILD_STEP      VARCHAR
   ,BUILD_SEQUENCE  INTEGER
   ,END_TIME        TIMESTAMP_NTZ
   ,TIME_ELAPSED    INTEGER
  )
AS '
  WITH CTE_TIME AS (
    SELECT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ AS CURRENT_TIME
  )
 ,CTE_OPEN AS (
    SELECT X.START_TIME
          ,X.BUILD_ID
          ,X.BUILD_SEQUENCE
          ,X.BUILD_SOURCE  -- Not currently used
          ,X.BUILD_STEP    -- Not currently used
          ,X.END_TIME
      FROM LEADFLOW.ARC.MARKETO_QUERY_HISTORY X
     ORDER BY START_TIME DESC
       LIMIT 1
  )
  SELECT BUILD_SOURCE
        ,BUILD_STEP
        ,T.CURRENT_TIME AS END_TIME
        ,DATEDIFF(SECOND, O.START_TIME, T.CURRENT_TIME) AS TIME_ELAPSED
    FROM CTE_TIME T
         JOIN CTE_OPEN O
           ON O.END_TIME IS NULL
          AND TO_DATE(O.START_TIME) = TO_DATE(T.CURRENT_TIME)  -- Sanity check
'
;



"SMARTSHEET_START_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_START_LOG`( in buildSource varchar(100), IN buildStep VARCHAR(250) )
BEGIN
DECLARE bID INT;
DECLARE bS INT;
DECLARE startTime DATETIME;
SELECT MAX(buildSequence) INTO bS FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE();
IF bS IS NULL 
THEN SET bS = 0;
ELSE SET bS = (SELECT MAX(buildSequence) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;
SELECT MAX(buildID) INTO bID FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE();
IF bID IS NULL
THEN SET bID = (SELECT MAX(buildID)+1 FROM leadflow.arc_marketo_query_history);
ELSE SET bID = (SELECT MAX(buildID) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;
SET bS = bS+1;
SET startTime = NOW();
INSERT INTO leadflow.arc_marketo_query_history (buildID, buildSequence, buildSource, buildStep, startTime)
SELECT bID, bS, buildSource, buildStep, startTime;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"



"SMARTSHEET_STOP_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_STOP_LOG`( IN buildSource VARCHAR(100), IN buildStep VARCHAR(250) )
BEGIN
DECLARE endTime DATETIME;
DECLARE buildSequence INT;
SET endTime = NOW();
SET buildSequence = (SELECT MAX(mqh.buildSequence) FROM leadflow.arc_marketo_query_history mqh 
WHERE mqh.buildStep = buildStep and mqh.buildSource = buildSource AND DATE_FORMAT(mqh.startTime, ""%Y-%m-%d"") = CURRENT_DATE());
UPDATE leadflow.arc_marketo_query_history arc
SET
    arc.timeElapsed = TIME_TO_SEC(TIMEDIFF(endTime, startTime)),
    arc.endTime = endTime
WHERE
    arc.buildStep = buildStep
    and arc.buildSource = buildSource
    and arc.buildSequence = buildSequence
    AND DATE_FORMAT(arc.startTime, ""%Y-%m-%d"") = CURRENT_DATE()
;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
