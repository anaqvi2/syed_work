SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;


-- Users with Personas

SELECT b.AccountId, b.AccountName, b.paymentProfileId, persona.userID, b.userType,
CASE WHEN persona.Persona IN('Tom', 'Sally') THEN persona.Persona ELSE 'Other' END AS Persona,
ua.emailAddress,
ua.FIRST_NAME,
ua.LAST_NAME,
CONCAT(ua.FIRST_NAME,' ',ua.LAST_NAME) AS UserName,
ua.languageFriendly,
lct.lastLogin,
CASE WHEN our.userID IS NOT NULL THEN 1 ELSE 0 END AS SysAdmin,

CASE WHEN l.Id IS NOT NULL OR c.Id IS NOT NULL THEN 1 ELSE 0 END InSFDC,
l.Id AS LeadID,
c.Id AS ContactID,

CASE 
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Id
END AS SalesforceLinkId,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.LastActivityDate
END AS SalesforceLastActivityDate,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Phone
END AS SalesforcePhone


FROM rpt_main_02.stg_PersonaUpdates persona
LEFT JOIN MAIN.RPT.paymentProfile pp ON persona.paymentProfileID=pp.paymentProfileID
LEFT JOIN MAIN.RPT.paymentProfile parent ON pp.parentPaymentProfileID=parent.paymentProfileID
JOIN
(
SELECT m.AccountId, m.AccountName, pp.paymentProfileID, 'Tom & Sally' AS UserType
FROM rpt_workspace.markj_ISR3_dashboard m
JOIN MAIN.RPT.paymentProfile pp ON m.Domain_Name_URL__c=pp.mainContactDomain
WHERE pp.countAsPaid = 1
) b ON parent.paymentProfileID=b.paymentProfileID
LEFT JOIN rpt_main_02.userAccount ua ON persona.userID=ua.userID
LEFT JOIN MAIN.RPT.loginCountTotal lct ON persona.userID=lct.userID
LEFT JOIN rpt_main_02.organizationUserRole our ON persona.userID=our.userID AND our.role='DATA_ADMIN' AND our.state=1

LEFT JOIN SFDC.PUBLIC.lead l ON ua.emailAddress=l.Email
LEFT JOIN SFDC.PUBLIC.contact c ON ua.emailAddress=c.Email
WHERE persona.Persona IN ('Tom', 'Sally')
-- AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday"


UNION ALL


SELECT b.AccountId, b.AccountName, b.paymentProfileId, pp.OWNER_ID, b.userType,
NULL AS Persona,
ua.emailAddress,
ua.FIRST_NAME,
ua.LAST_NAME,
CONCAT(ua.FIRST_NAME,' ',ua.LAST_NAME) AS UserName,
ua.languageFriendly,
lct.lastLogin,
CASE WHEN our.userID IS NOT NULL THEN 1 ELSE 0 END AS SysAdmin,

CASE WHEN l.Id IS NOT NULL OR c.Id IS NOT NULL THEN 1 ELSE 0 END InSFDC,
l.Id AS LeadID,
c.Id AS ContactID,

CASE 
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Id
END AS SalesforceLinkId,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.LastActivityDate
END AS SalesforceLastActivityDate,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Phone
END AS SalesforcePhone


FROM 
(
SELECT m.AccountId, m.AccountName, ppB.paymentProfileID, 'Active Trials' AS UserType
FROM rpt_workspace.markj_ISR3_dashboard m
JOIN MAIN.RPT.paymentProfile ppB ON m.Domain_Name_URL__c=ppB.mainContactDomain
WHERE ppB.productID = 1
) b 
LEFT JOIN MAIN.RPT.paymentProfile pp ON b.paymentProfileID=pp.paymentProfileID
LEFT JOIN rpt_main_02.userAccount ua ON pp.OWNER_ID=ua.userID
LEFT JOIN MAIN.RPT.loginCountTotal lct ON pp.OWNER_ID=lct.userID
LEFT JOIN rpt_main_02.organizationUserRole our ON pp.OWNER_ID=our.userID AND our.role='DATA_ADMIN' AND our.state=1

LEFT JOIN SFDC.PUBLIC.lead l ON ua.emailAddress=l.Email
LEFT JOIN SFDC.PUBLIC.contact c ON ua.emailAddress=c.Email
-- WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday"

UNION ALL

SELECT b.AccountId, b.AccountName, b.paymentProfileId, persona.userID, b.userType,
CASE WHEN persona.Persona IN('Tom', 'Sally') THEN persona.Persona ELSE 'Sys Admin (No Persona)' END AS Persona,
ua.emailAddress,
ua.FIRST_NAME,
ua.LAST_NAME,
CONCAT(ua.FIRST_NAME,' ',ua.LAST_NAME) AS UserName,
ua.languageFriendly,
lct.lastLogin,
CASE WHEN our.userID IS NOT NULL THEN 1 ELSE 0 END AS SysAdmin,

CASE WHEN l.Id IS NOT NULL OR c.Id IS NOT NULL THEN 1 ELSE 0 END InSFDC,
l.Id AS LeadID,
c.Id AS ContactID,

CASE 
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Id
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Id
END AS SalesforceLinkId,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.LastActivityDate
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.LastActivityDate
END AS SalesforceLastActivityDate,

CASE
	WHEN c.Id IS NULL AND l.Id IS NULL THEN NULL
	WHEN c.Id IS NULL AND l.Id IS NOT NULL THEN l.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NULL THEN c.Phone
	WHEN c.Id IS NOT NULL AND l.Id IS NOT NULL THEN c.Phone
END AS SalesforcePhone


FROM rpt_main_02.organizationUserRole our 
LEFT JOIN MAIN.RPT.paymentProfile pp ON our.userID = pp.mainContactUserID AND pp.accountType != 3
LEFT JOIN MAIN.RPT.paymentProfile parent ON pp.parentPaymentProfileID=parent.paymentProfileID
LEFT JOIN rpt_main_02.stg_PersonaUpdates persona ON persona.userID = our.userID
JOIN
(
SELECT m.AccountId, m.AccountName, pp.paymentProfileID, 'Sys Admin (No Persona)' AS UserType
FROM rpt_workspace.markj_ISR3_dashboard m
JOIN MAIN.RPT.paymentProfile pp ON m.Domain_Name_URL__c=pp.mainContactDomain
WHERE pp.countAsPaid = 1
) b ON parent.paymentProfileID=b.paymentProfileID
LEFT JOIN rpt_main_02.userAccount ua ON persona.userID=ua.userID
LEFT JOIN MAIN.RPT.loginCountTotal lct ON persona.userID=lct.userID

LEFT JOIN SFDC.PUBLIC.lead l ON ua.emailAddress=l.Email
LEFT JOIN SFDC.PUBLIC.contact c ON ua.emailAddress=c.Email
WHERE our.role= 'DATA_ADMIN' AND our.state=1 
AND (persona.Persona NOT IN ('Tom', 'Sally') OR persona.Persona IS NULL)
-- AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
;


