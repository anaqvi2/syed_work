


SELECT 
t.Subject,
t.ActivityDate AS 'Activity Date',
t.Status,
t.Priority,
t.Description,
t.Type,
t.CallType AS 'Call Type',
t.Id,
t.WHO_ID AS 'Who Id',
t.WhatId AS 'What Id',
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'Owner Name',
t.AccountId AS 'Account Id',
a.Name AS 'Account Name',
CONCAT(ao.FIRST_NAME,' ',ao.LAST_NAME) AS 'Account Owner Name',
t.CREATED_DATE AS 'Created Date',
CONCAT(cb.FIRST_NAME,' ',cb.LAST_NAME) AS 'Created By Name',
t.LastModifiedDate AS 'Last Modified Date',
CONCAT(lm.FIRST_NAME,' ',lm.LAST_NAME) AS 'Last Modified By Name',
Activity_Completion_Date_Time__c as "Activity Completion Date/Time",
t.Inbound_Submission_Date_Time__c as 'Inbound Submission Date Time',
la.Name AS 'Lead Account Name',
la.id AS 'Lead Account Id',
CONCAT(u2.FIRST_NAME,' ',u2.LAST_NAME) AS 'Lead Account Owner Name'

FROM SFDC.PUBLIC.task t
LEFT JOIN SFDC.PUBLIC.account a ON t.AccountId=a.Id
LEFT JOIN SFDC.PUBLIC.user u ON t.OWNER_ID=u.Id
LEFT JOIN SFDC.PUBLIC.user cb ON t.CreatedById=cb.Id
LEFT JOIN SFDC.PUBLIC.user lm ON t.LastModifiedById=lm.Id
LEFT JOIN SFDC.PUBLIC.lead l ON l.Id = t.WHO_ID
LEFT JOIN SFDC.PUBLIC.domain d ON d.domain_name_url__c = l.domain__c
LEFT JOIN SFDC.PUBLIC.account la ON la.id = d.account__c
LEFT JOIN SFDC.PUBLIC.user ao ON a.OWNER_ID=ao.Id
LEFT JOIN SFDC.PUBLIC.user u2 ON la.OWNER_ID=u2.Id;