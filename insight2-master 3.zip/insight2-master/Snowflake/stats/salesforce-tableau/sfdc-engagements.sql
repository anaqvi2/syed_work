



SELECT t.OWNER_ID, 
CONCAT(rep.FIRST_NAME," ",rep.LAST_NAME) AS SalesRep, 
t.ActivityDate, 
t.Subject, 
t.Type, 
t.AccountId, 
acc.Name, 
acc.Territory__c
FROM SFDC.PUBLIC.task t
LEFT JOIN SFDC.PUBLIC.account acc ON acc.Id = t.AccountId
LEFT JOIN SFDC.PUBLIC.user rep ON rep.Id = t.OWNER_ID
WHERE t.Type = 'Engagement' 
AND t.Status = 'Completed' 
AND rep.Title = 'Client Development Manager'
;