


SELECT DATE_SUB(MAX(insertDateTime), INTERVAL 7 HOUR) FROM ss_core_02.paymentProfile INTO @maxppInsertPst;

SELECT cp.paymentProfileID, rpt_main_02.`SMARTSHEET_PRODUCTNAME`(cp.productID) AS ProductName,
CASE WHEN cp.accountType = 3 THEN cp.OWNER_ID ELSE NULL END AS OrgID,
rpt_main_02.`SMARTSHEET_PAYMENTTYPE`(cp.paymentType) AS PaymentType, rpt_main_02.`SMARTSHEET_PAYMENTTERM`(cp.paymentTerm) AS PaymentTerm, cp.productPriceID, cp.promoCode, cp.planRate,
cp.CURRENCY_CODE, cp.planTaxRate, cp.taxCalculatedRate, cp.taxLastCalcDateTime, 
CASE WHEN cp.paymentProfileID = 8610170 THEN NULL ELSE REPLACE(cp.billToCompany,'"','') END AS billToCompany, cp.billToAddress1, cp.billToAddress2, cp.billToCity, cp.billToRegionCode,
cp.billToCountryCode, cp.billToRecurringBillingID, cp.paymentStartDateTime, cp.paymentEndDateTime, cp.estimatedLastPaymentDate, cp.actualLastPaymentDate, cp.nextPaymentDate,
cp.userLimit, CASE WHEN (cp.paymentFlags & 32 = 32) THEN 1 ELSE 0 END AS taxExempt, pp.mainContactEmailAddress AS accountOwnerEmail, cp.billToEmailAddress, cp.billToPostCode,
((cp.planRate/cp.paymentTerm)*12) AS LocalARR, cp.primaryContactPhone,

CASE WHEN pp.nextPaymentDate > CURRENT_TIMESTAMP() THEN pp.nextPaymentDate 
	ELSE CASE WHEN pp.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(pp.actualLastPaymentDate), "-",DAY(pp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(CURRENT_TIMESTAMP()) - YEAR(pp.paymentStartDateClean)) YEAR) > CURRENT_TIMESTAMP() 
				THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(CURRENT_TIMESTAMP()) - YEAR(pp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +((YEAR(CURRENT_TIMESTAMP()) - YEAR(pp.paymentStartDateClean)) + 1) YEAR) END
		WHEN pp.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(CURRENT_TIMESTAMP()) - rpt_main_02.SMARTSHEET_MONTH(pp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN pp.paymentTerm = 1 
			THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(CURRENT_TIMESTAMP()) - rpt_main_02.SMARTSHEET_MONTH(pp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +(pp.paymentTerm) MONTH) END
		ELSE " " END END AS 'CalculatedNextPaymentDateNew',
		
REPLACE(cp.referralEmailAddress,'"',' ') AS referralEmailAddress, @maxppInsertPst AS updatedThrough, cp.billToFIRST_NAME, cp.billToLAST_NAME,
	CASE WHEN cp.CURRENCY_CODE = 'USD' THEN ((cp.planRate/cp.paymentTerm)*12)
		ELSE (((cp.planRate/hce.EXCHANGE_RATE)/cp.paymentTerm)*12) 
		END AS 'ARR-USD',
	REPLACE(pp.companyName,'"','') AS organization, cp.bonusUserCount
, cp.billToCCExpMonth, cp.billToCCExpYear, cp.actualLastPaymentDate,
CASE WHEN isp.domain IS NOT NULL THEN 'ISP' ELSE 'Org' END AS orgVsISP
FROM ss_core_02.paymentProfile cp
JOIN MAIN.RPT.paymentProfile pp ON pp.paymentProfileID = cp.paymentProfileID
LEFT JOIN ss_core_02.hist_CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = cp.CURRENCY_CODE 
	AND cp.MODIFY_DATE_TIME BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
LEFT JOIN MAIN.ARC.ISPDomains isp on isp.domain = pp.mainContactDomain
WHERE cp.accountType IN(1,3) AND ((cp.productID > 2 AND cp.planRate > 0 AND cp.paymentType IN(1,2,3,6,8,10)) 
		OR (cp.productID = 0 AND pp.maxPaidDate IS NOT NULL))
;