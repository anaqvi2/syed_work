


drop table if exists rpt_workspace.pj_powerHourList;
create table if not exists rpt_workspace.pj_powerHourList
(userID int(15),
emailAddress varchar(100),
domain varchar(50),
planID int(15),
planDomain varchar(50),
jobTitle varchar(200),
HVT varchar(200),
PMOOps int,
sheetsAccessible int,
sightsAccessible int,
last30DaysActive int,
usersSharedTo int,
shareDateTimes int,
planUserLimit int,
isLicensed int,
productName varchar(25),
daysSinceFirstLogin int,
recentExpansion int,
salesRep varchar(100),
RepRole varchar(25),
contactID varchar(100),
contactOWNER_ID varchar(100),
leadId varchar(100),
leadOWNER_ID varchar(100),
domainID varchar(100),
domainOWNER_ID varchaR(100),
accountName varchar(100),
TrafficSource varchar(100),
isConverted varchar(50),
Score int,
RankbyDomain int,
Rank int,
primary key (userID));

insert into rpt_workspace.pj_powerHourList (userID, emailAddress, domain, daysSinceFirstLogin, HVT, jobTitle)
select ua.userID, ua.emailAddress, ua.domain, datediff(curdate(), firstlogin), HVT, title
from rpt_main_02.userAccount ua 
	join MAIN.RPT.loginCountTotal lct on lct.userID = ua.userID and lct.lastLogin >= date_sub(curdate(), interval 90 day)
    join rpt_workspace.pj_userDataCoverage pj on pj.userID = ua.userID
    left outer join MAIN.ARC.ISPDomains d on d.domain = ua.domain
where d.domain is null
and ua.languageFriendly not in ('Spanish', 'Portuguese', 'French', 'German', 'Italian', 'Russian','Japanese')
and ua.domain not in ('smartsheet.com','mbfcorp.com','airtable.com','netsuite.com')
and (HVT = 1 or pj.title like '%PMO%' or pj.title like '%Ops%' or pj.title like '%operations%')  
and pj.title not like '%desktop%' ;

update rpt_workspace.pj_powerHourList pj
join SFDC.PUBLIC.lead l on l.userID__c = pj.userID
set pj.leadID = l.Id,
pj.isConverted = l.IsConverted,
pj.leadOWNER_ID = l.OWNER_ID;

update rpt_workspace.pj_powerHourList pj
join SFDC.PUBLIC.contact c FORCE INDEX (PRIMARY) on c.userID__c = pj.userID
set pj.ContactId = c.Id,
pj.contactOWNER_ID= c.OWNER_ID;

update rpt_workspace.pj_powerHourList pj
join SFDC.PUBLIC.contact c on c.email = pj.emailAddress
set pj.ContactId = c.Id,
pj.contactOWNER_ID= c.OWNER_ID
where ContactId is null;

update rpt_workspace.pj_powerHourList pj
	join SFDC.PUBLIC.task t on t.WHO_ID = pj.contactID and Traffic_Source__c like '%power hour%'
set TrafficSource = t.Traffic_Source__c;

update rpt_workspace.pj_powerHourList pj
	join SFDC.PUBLIC.task t on t.WHO_ID = pj.leadID and Traffic_Source__c like '%power hour%'
set TrafficSource = t.Traffic_Source__c
where TrafficSource is null;

delete from rpt_workspace.pj_powerHourList where trafficSource is not null;
delete from rpt_workspace.pj_powerHourList where IsConverted = 'true' and repRole in ('NBR','WW Sales');

update rpt_workspace.pj_powerHourList pj
set sheetsAccessible =
(select count(distinct gridID)
from rpt_main_02.gridAccessMap gam
where gam.userID = pj.userID
and deleteStatus = 0);

update rpt_workspace.pj_powerHourList pj
set sightsAccessible =
(select count(distinct dashboardID)
from rpt_main_02.dashboardAccessMap gam
where gam.userID = pj.userID
and deleteStatus = 0);

create table if not exists rpt_workspace.pj_last30UserDatesActive
(userID int(15),
date date,
primary key (userID, date));

truncate table rpt_workspace.pj_last30UserDatesActive;
insert ignore into rpt_workspace.pj_last30UserDatesActive
select userID, date
from rpt_main_02.last30DayClientEventDate
where userID > 1000
group by 1,2

union 

select userID, date
from rpt_main_02.last30DayMobileSessions
where userID > 1000
group by 1,2;

create table if not exists rpt_workspace.pj_last30DaysActive
(userID int(15),
dayCount int,
primary key (userID));

truncate rpt_workspace.pj_last30DaysActive;
insert into rpt_workspace.pj_last30DaysActive
select userID, count(distinct date)
from rpt_workspace.pj_last30UserDatesActive
group by 1;

update rpt_workspace.pj_powerHourList pj
left outer join rpt_workspace.pj_last30DaysActive da on da.userID = pj.userID
left outer join rpt_main_02.stg_sharingCounts stg on stg.userID = pj.userID
set pj.last30DaysActive = case when da.dayCount is null then 0 else da.dayCount end ,
pj.usersSharedTo = case when stg.usersSharedTo is null then 0 else stg.usersSharedTo end;



update rpt_workspace.pj_powerHourList pj
set shareDateTimes =
(select count(distinct insertDateTime)
from rpt_main_02.gridAccessMap gam FORCE INDEX (grid_insertByUserID)
where gam.insertbyuserID = pj.userID
and deleteStatus = 0
and access != 50)

update rpt_workspace.pj_powerHourList pj
	left outer join MAIN.RPT.paidPlanCurrentUsers ppcu on ppcu.mainContactUserID = pj.userID
    left outer join MAIN.RPT.paidPlanSheetAccess sa on sa.userID = pj.userID and sa.userPlanID is null
set pj.planID = case when ppcu.planID is not null then ppcu.planID else sheetPlanID end,
pj.productName = case when ppcu.productName is not null then ppcu.productName else null end;

update rpt_workspace.pj_powerHourList pj
	join MAIN.RPT.paymentProfile  pp on pp.mainContactUserID = pj.userID and pp.accountType != 3
set pj.productName = pp.productName
where pj.productName is null;

update rpt_workspace.pj_powerHourList pj
	join MAIN.RPT.paidPlanInfo ppi on ppi.paymentProfileID= pj.planID 
set pj.planDomain = pj.domain,
pj.planUserLimit = ppi.userLimit;

update rpt_workspace.pj_powerHourList set planDomain = case when planDomain is null then domain else planDomain end;

UPDATE rpt_workspace.pj_powerHourList A
JOIN SFDC.PUBLIC.domain d ON d.Domain_Name_URL__c = A.planDomain
JOIN SFDC.PUBLIC.user u ON u.Id = d.OWNER_ID
LEFT OUTER JOIN SFDC.PUBLIC.user_role ur ON u.userRoleID = ur.id
LEFT OUTER JOIN SFDC.PUBLIC.account acc ON acc.Id = d.Account__c
SET A.SalesRep = CONCAT(u.FIRST_NAME," ",u.LAST_NAME),
A.RepRole = ur.Name,
A.domainID = d.ID,
A.domainOWNER_ID = d.OWNER_ID,
A.accountName = acc.Name;

update rpt_workspace.pj_powerHourList A set accountName = planDomain where accountName is null;

update rpt_workspace.pj_powerHourList set isLicensed = case when productName  in ('Collab', 'Trial') then 0 else 1 end,
planUserLimit = case when planUserLimit is null then 0 else planUserLimit end;

update rpt_workspace.pj_powerHourList pj
	join rpt_main_02.output_RevenueSummaryMonthly rsm on rsm.paymentProfileID = pj.planID and recordType = 'UPGRADES' and date_format(recordDateTime, '%Y-%m') >= date_format(date_sub(curdate(), interval 9 month), '%Y-%m')
set recentExpansion = 1;

update rpt_workspace.pj_powerHourList pj set recentExpansion = 0 where recentExpansion is null;

update rpt_workspace.pj_powerHourList pj set pj.SalesRep = 'Andrew Imhoff' where repRole = 'WW Sales';

update rpt_workspace.pj_powerHourList set Score = 
case when last30DaysActive = 0 then 0 else
(sheetsAccessible*.25)+sightsAccessible+(case when last30DaysActive >= 15 then 150 else last30DaysActive end) +(usersSharedTo*.5)+ (shareDateTimes*.25)+(isLicensed*10)+(recentExpansion*100)+(case when planUserLimit > 1000 then 150 else planUserLimit*.25 end) end;

drop table if exists rpt_workspace.pj_powerHourAccountsRanked;
create table if not exists rpt_workspace.pj_powerHourAccountsRanked
select userID, emailAddress, domain, planID, planDomain, salesRep, RepRole, ContactID, contactOWNER_ID, leadID, leadOWNER_ID, domainID, domainOWNER_ID, accountName, Score, HVT, PMOOps, sheetsAccessible, last30DaysActive, usersSharedTo, shareDateTimes, isLicensed, recentExpansion,
      (@num:=if(@accountName = accountName, @num +1, if(@accountName := accountName, 1, 1))) account_rank
  from rpt_workspace.pj_powerHourList
  CROSS JOIN (select @num:=0, @accountName:=null) c
  order by accountName, Score desc;
  
drop table if exists rpt_workspace.pj_powerHourRepLeadsRanked;
create table if not exists rpt_workspace.pj_powerHourRepLeadsRanked
select userID, emailAddress, domain, planID, planDomain, salesRep, RepRole, ContactID, leadID, domainID,contactOWNER_ID, leadOWNER_ID, domainOWNER_ID,  accountName, Score, account_rank, HVT, PMOOps, sheetsAccessible, last30DaysActive, usersSharedTo, shareDateTimes, isLicensed, recentExpansion,
      (@num:=if(@salesRep = salesRep, @num +1, if(@salesRep := salesRep, 1, 1))) rep_rank
  from rpt_workspace.pj_powerHourAccountsRanked
  CROSS JOIN (select @num:=0, @salesRep:=null) c
  where account_rank <= 3
  order by salesRep, Score desc;
  
select count(distinct salesRep) from rpt_workspace.pj_powerHourRepLeadsRanked where repRole = 'NBR' INTO @NBRs;

select count(*) from rpt_workspace.pj_powerHourRepLeadsRanked where repRole = 'NBR' and rep_rank <= 25 INTO @NBRLeads;

select (@NBRs*25) - @NBRLeads INTO @additionalLeads;

select * 
from rpt_workspace.pj_powerHourRepLeadsRanked 
where RepRole in ('CDM','WW Sales', 'NBR')
and (case when RepRole = 'WW Sales' then rep_rank <= (@additionalLeads+20) else rep_rank <= 25 end);