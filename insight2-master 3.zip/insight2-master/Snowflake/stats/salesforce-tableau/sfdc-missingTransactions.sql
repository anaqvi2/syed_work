


DELETE FROM MAIN.RPT.taxableTransactions WHERE DATE_FORMAT(paymentDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY), '%Y-%m');

/*Insert records  */
INSERT MAIN.RPT.taxableTransactions
       (paymentHistoryID        ,
        paymentProfileID        ,
        transactionType         ,        
        transactionID		,
        processorTransactionID	,
        paymentType             ,
        paymentTerm             ,
        productName		,
        transactionAmount       ,
        taxAmount               ,
        totalAmount             ,
        paymentDateTime         ,
        CURRENCY_CODE            ,
        paymentMessage          )
SELECT  h.paymentHistoryID      ,
        h.paymentProfileID      ,
        h.transactionType       ,
        h.transactionID		,
        h.processorTransactionID,
        h.paymentType           ,
        0                       ,
        0			,
        h.paymentAmount-h.taxAmount,
        h.taxAmount             ,
        h.paymentAmount         ,
        h.paymentDateTime       ,
        h.CURRENCY_CODE          ,
        h.paymentMessage
FROM    ss_core_02.paymentHistory h
  LEFT OUTER JOIN MAIN.RPT.taxableTransactions t ON h.paymentHistoryID = t.paymentHistoryID
WHERE   t.paymentHistoryID IS NULL   AND   result = 0
AND DATE_FORMAT(h.paymentDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY), '%Y-%m');

/* Update*/
UPDATE MAIN.RPT.taxableTransactions t
  JOIN ss_core_02.hist_paymentProfile hp
      ON t.paymentProfileID = hp.paymentProfileID
     AND hp.MODIFY_DATE_TIME <= t.paymentDateTime
     AND hp.HIST_EFFECTIVE_THRU_DATE_TIME > t.paymentDateTime
SET     t.paymentTerm           = hp.paymentTerm        ,
	t.productName		= rpt_main_02.SMARTSHEET_PRODUCTNAME(hp.productID),
        t.billToAddress1        = hp.billToAddress1     ,
        t.billToCity            = hp.billToCity         ,
        t.billToRegionCode      = hp.billToRegionCode   ,
        t.billToPostCode        = hp.billToPostCode     ,
        t.billToCountryCode     = hp.billToCountryCode  ,
        t.taxExemptStatus 	= CASE WHEN hp.paymentFlags & 32 = 32 THEN 1 ELSE 0 END,
        t.paymentStartDate	= hp.paymentStartDateTime
WHERE DATE_FORMAT(paymentDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY), '%Y-%m');

UPDATE MAIN.RPT.taxableTransactions t
	JOIN ss_core_02.hist_paymentProfile hp ON t.paymentProfileID = hp.paymentProfileID
		AND hp.MODIFY_DATE_TIME <= t.paymentDateTime
		AND hp.HIST_EFFECTIVE_THRU_DATE_TIME > t.paymentDateTime	
	JOIN ss_core_02.hist_paymentProfile hpp ON hp.parentPaymentProfileID = hpp.paymentProfileID AND hpp.productID > 2
		AND hpp.MODIFY_DATE_TIME <= t.paymentDateTime
		AND hpp.HIST_EFFECTIVE_THRU_DATE_TIME > t.paymentDateTime
SET     t.billToAddress1        = hpp.billToAddress1     ,
        t.billToCity            = hpp.billToCity         ,
        t.billToRegionCode      = hpp.billToRegionCode   ,
        t.billToPostCode        = hpp.billToPostCode     ,
        t.billToCountryCode     = hpp.billToCountryCode  ,
        t.paymentProfileID 	= hpp.paymentProfileID	 ,
        t.paymentTerm 		= hpp.paymentTerm	 ,
        t.taxExemptStatus 	= CASE WHEN hpp.paymentFlags & 32 = 32 THEN 1 ELSE 0 END,
        t.paymentStartDate	= hp.paymentStartDateTime
WHERE DATE_FORMAT(paymentDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY), '%Y-%m')   
	AND t.billToAddress1 IS NULL AND t.billToCity IS NULL AND t.billToRegionCode IS NULL AND t.billToCountryCode IS NULL AND t.billToPostCode IS NULL;
	

/*Transactions*/ 
/* SELECT 
t.paymentHistoryID, 
t.paymentProfileID, 
t.transactionType, 
rpt_main_02.SMARTSHEET_TRANTYPE(t.transactionType) AS TransactionTypeDesc,
t.transactionID, 
t.processorTransactionID, 
t.paymentType, 
t.paymentTerm,
t.productName,
t.transactionAmount, 
t.taxAmount, 
t.totalAmount, 
DATE_FORMAT(t.paymentDateTime, '%Y-%m-%d') AS paymentDateTime, 
t.CURRENCY_CODE, 
t.paymentMessage,
t.billToAddress1, 
t.billToCity, 
t.billToRegionCode, 
t.billToPostCode, 
t.billToCountryCode,
COALESCE(st.settlementAmount,'') AS SettlementAmount, 
COALESCE(st.netAmountUSD,'') AS NetAmountUSD, 
COALESCE(st.grossAmount,'') AS GrossAmount, 
COALESCE(st.EXCHANGE_RATE,'') AS EXCHANGE_RATE, 
COALESCE(DATE_FORMAT(st.transactionDateTime,'%Y-%m-%d'),'') AS TransactionDateTime, 
COALESCE(st.missingCurrencyExchange,'') AS MissingCurrencyExchange,
t.taxExemptStatus,
DATE_FORMAT(t.paymentStartDate,'%Y-%m-%d') AS PaymentStartDate


FROM MAIN.RPT.taxableTransactions t 
LEFT OUTER JOIN MAIN.ARC.settlementTransactions st ON t.processorTransactionID = st.processorTransactionID
WHERE '2016-11-01 00:00:00' <= t.paymentDateTime
ORDER BY t.paymentDateTime

LIMIT 123456789; */


  
  
/*Missing Transactions*/

SELECT 
arc_settlementTransactions.transactionDateTime AS TransactionDateTime,
arc_settlementTransactions.processorTransactionID,  
arc_settlementTransactions.CURRENCY_CODE, 
COALESCE(arc_settlementTransactions.grossAmount,'') AS totalAmount, 
COALESCE(arc_settlementTransactions.settlementAmount,'') AS SettlementAmount, 
COALESCE(arc_settlementTransactions.netAmountUSD,'') AS NetAmountUSD, 
COALESCE(arc_settlementTransactions.grossAmount,'') AS GrossAmount, 
COALESCE(arc_settlementTransactions.EXCHANGE_RATE,'')  AS EXCHANGE_RATE

FROM MAIN.ARC.settlementTransactions 
LEFT OUTER JOIN MAIN.RPT.taxableTransactions 
	ON arc_settlementTransactions.processorTransactionID = rpt_taxableTransactions.processorTransactionID 
WHERE '2016-12-01 00:00:00' <= arc_settlementTransactions.transactionDateTime 
AND paymentHistoryID IS NULL 
ORDER BY transactionDateTime
;