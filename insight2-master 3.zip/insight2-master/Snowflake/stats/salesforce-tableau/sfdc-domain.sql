



/*Run update to SFDC.PUBLIC.domain table where Territory__c is replaced by Territory__c in account*/
UPDATE SFDC.PUBLIC.domain
LEFT OUTER JOIN SFDC.PUBLIC.account ON account.ID = domain.Account__c
SET domain.Territory__c = account.Territory__c
WHERE domain.Territory__c != account.Territory__c
;

SELECT 
d.Account__c AS 'Account',
d.Assigned_Licensed_Users__c AS 'Assigned Licensed Users',
d.Bonus_Users__c AS 'Bonus Users',
d.Cancels_ACV_All_Time__c AS 'Cancels ACV All Time',
d.Cancels_ACV_Trailing_12_Months__c AS 'Cancels ACV Trailing 12 Months',
d.Days_Since_Last_Transaction__c AS 'Days Since Last Transaction',
d.Domain_s_Highest_Plan__c AS "Domain's Highest Plan",
d.Domain_Name_URL__c AS 'Domain Name URL',
d.Downgrades_ACV_All_Time__C AS 'Downgrades ACV All Time',
d.Downgrades_ACV_Trailing_12_Months__c AS 'Downgrades ACV Trailing 12 Months',
d.Hist_Effective_Thru_Date_Time__c AS 'Hist Effective Thru Date Time',
d.Insert_Date_Time__c AS 'Insert Date Time',
d.ISP__c AS 'ISP',
d.Customer_Success__c AS 'Customer Success',
d.Last_Activity_Date__c AS 'Last Activity Date',
d.Last_Transaction_Date_Time__c AS 'Last Transaction Date Time',
d.Net_Bookings_ACV_All_Time__c AS 'Net Bookings ACV All Time',
d.Net_Bookings_ACV_Trailing_12_Months__c AS 'Net Bookings ACV Trailing 12 Month',
d.Paid_Licensed_Users__c AS 'Paid Licensed Users',
d.Parent__c AS 'Parent',
d.Pending_Licensed_Users__c AS 'Pending Licensed Users',
d.Status__c AS 'Status',
d.Territory__c AS 'Territory',
d.Transaction_Number__c AS 'Transaction Number',
d.Upgrades_ACV_All_Time__c AS 'Ugprades ACV All Time',
d.Upgrades_ACV_Trailing_12_Months__c AS 'Ugprades ACV Trailing 12 Months',
d.Upload_Date__c AS 'Upload Date',
d.Wins_ACV_All_Time__c AS 'Wins ACV All Time',
d.Wins_ACV_Trailing_12_Months__c AS 'Wins ACV Trailing 12 Months',
d.Id, 
d.Name,
d.OWNER_ID AS 'Owner Id',
d.LastModifiedDate AS 'Last Modified Date',
d.InsightInsertDateTime AS 'Insight Insert Date Time',
d.InsightModifiedDateTime AS 'Insight Modified Date Time',
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'Owner Name',
a.Name AS 'Account Name',
a.BillingCity AS 'Billing City',
a.BillingCountry AS 'Billing Country',
a.BillingPostalCode AS 'Billing Postal Code',
a.BillingStreet AS 'Billing Street',
a.BillingState AS 'Billing State',
a.Buying_Phase__c AS 'Buying Phase',
a.Fortune_1000__c AS 'Fortune1000',
a.Fortune_1000_Rank__c AS 'Fortune 1000 Rank',
a.Territory__c AS 'Territory',
a.AnnualRevenue AS 'Annual Revenue',
a.NumberOfEmployees AS 'Number of Employees'
FROM SFDC.PUBLIC.domain d
LEFT JOIN SFDC.PUBLIC.user u ON d.OWNER_ID=u.Id
LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c=a.Id
;