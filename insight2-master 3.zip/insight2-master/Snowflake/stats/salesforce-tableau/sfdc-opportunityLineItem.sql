



SELECT A.Billing_Frequency__c, 
A.Category__c, 
A.Changing_Subscription_Plan_Checkbox__c, 
A.Discount_Reason__c, 
A.Expiration_Date__c, 
A.Is_CoE__c, 
A.Is_Design_Desk__c,
A.Is_JIRA_Connector__c, 
A.Is_Recurring_Checkbox__c, 
A.Is_SCC__c, 
A.Is_SFDC_Connector__c, 
A.Opportunity_Closed_Won__c, 
A.Opportunity_Product_Compilation__c, 
A.Primary_Subscription__c, 
A.Product_Is_Recurring__c, 
/* REPLACE(REPLACE(A.Product_Notes_for_Future__c,'"',''),",",'') AS Product_Notes_for_Future__c, */
A.Product_Plan_Type__c,
A.Prorated_Price_to_Plan_Renewal_Date__c, 
A.Related_SKU__c,
A.Sales_Price_Formatted__c, 
A.SOW_Product__c, 
A.Total_Formatted__c, 
A.Training_Handover_Or_Consulting_Pipeline__c, 
/* REPLACE(REPLACE(A.Description,'"',''),",",'') AS Description, */
A.ListPrice, 
A.OpportunityId, 
A.Quantity,
A.UnitPrice, 
A.TotalPrice, 
A.LastModifiedDate, 
A.Product_Name__c, 
A.Id
FROM SFDC.PUBLIC.OpportunityLineItem A
;