



SELECT c.Id, c.CaseNumber, c.ContactId, c.AccountId, acc.Name, c.ParentId, c.SuppliedName, c.SuppliedEmail, c.Status, c.Reason, c.Origin, c.Subject,
c.priority, c.Description, c.IsEscalated, c.OWNER_ID, CONCAT(u.FIRST_NAME," ",u.LAST_NAME) AS rep, c.CREATED_DATE, c.CreatedById, c.LastModifiedDate, c.LastModifiedById,
c.Case_Age_In_Business_Hours__c, c.Last_Status_Change__c, c.Time_With_Customer__c, c.Time_With_Support__c, c.Account_Is_Vendor__c, c.Age_of_Case_in_Hours__c, 
c.Age_of_Case_in_Minutes__c, c.Case_Age__c, c.Case_Language__c, c.Category__c, c.Contact_Form_Dropdown__c, c.Email_to_Case_Address__c, c.Feature__c, c.First_Response__c, 
c.Group__c, c.Inactive_Owner_Case_Received_Email__c, c.Lead__c, c.Owner_is_Trainee__c, c.Owner_on_PTO__c, c.Plan_Type__c, c.SLA_Current_Result__c, c.SLA_Response_Target__c,
c.SLA_Warn_Time__c, c.Severity__c, c.TimeToFirstResponseInMinutes__c, c.TimeToFirstResponse__c, c.Time_to_SLA_Target__c, c.Case_ID__c, c.InsightInsertDateTime, 
c.InsightModifiedDateTime, c.CURRENCY_ISO_CODE, c.Of_Times_Case_Closed__c, c.Account_Type__c, c.Case_Owner_Role__c, c.Case_Transferred_To__c, c.Feature_Category__c,
c.Feature_Sub_Category__c, c.First_Date_Time_Closed__c, c.First_Response_Hour__c, c.Insert_Hour__c, c.Labels__c, c.New_Case_Comment__c, c.New_Case_Email__c,
c.Phone_Call_Length__c, c.Resolution_Code__c, c.Smartsheet_Labs_Case__c, c.Time_Escalated_to_Close__c, c.Time_Zone__c, c.Time_Zone_Group__c, c.User_Lookup__c,
c.ClosedDate
FROM SFDC.PUBLIC.case c
LEFT JOIN SFDC.PUBLIC.account acc ON acc.Id = c.AccountId
LEFT JOIN SFDC.PUBLIC.user u ON u.Id = c.OWNER_ID
;