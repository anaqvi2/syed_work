



SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;

-- Needed for Pie Chart
	select 
	AccountName, productGroup2,
	count(distinct mainContactUserID) as users
	from rpt_workspace.markj_ISR3_dashboard m
	left join rpt_main_02.stg_sfdc_LicensedUserGroupings lug on m.Domain_Name_URL__c=lug.masterDomain
	group by 1,2

	union all

select AccountName, 
'Open Licensed Seats',
Paid_Licensed_Users__c-Assigned_Licensed_Users__c as OpenSeats
from rpt_workspace.markj_ISR3_dashboard
;

