set session transaction isolation level read uncommitted;


drop table if exists SFDC.PUBLIC.open_opportunities;
create table if not exists SFDC.PUBLIC.open_opportunities
select *
from SFDC.PUBLIC.opportunity
where STAGE_NAME not in ('Closed Won','Closed Lost')
;

create index AccountId on SFDC.PUBLIC.open_opportunities (AccountId);


drop table if exists SFDC.PUBLIC.renewal_opportunities;
create table if not exists SFDC.PUBLIC.renewal_opportunities
select *
from SFDC.PUBLIC.opportunity
where RecordTypeID = '01240000000M8rkAAC'
;

create index AccountId on SFDC.PUBLIC.renewal_opportunities (AccountId);



DROP TABLE IF EXISTS rpt_workspace.markj_ISR3_dashboard;
CREATE TABLE IF NOT EXISTS rpt_workspace.markj_ISR3_dashboard
(
  `AccountId` VARCHAR(25) DEFAULT NULL,
  `AccountName` VARCHAR(255) DEFAULT NULL,
  `Industry` VARCHAR(40) DEFAULT NULL,
  `AnnualRevenue` DECIMAL(18,2) DEFAULT NULL,
  `NumberOfEmployees` INT(11) DEFAULT NULL,
  `Domain__c` VARCHAR(100) DEFAULT NULL,
  `Domain_Name_URL__c` VARCHAR(100) DEFAULT NULL,
  `Territory__c` VARCHAR(100) DEFAULT NULL,
  `OWNER_ID` VARCHAR(25) DEFAULT NULL,
  `AccountOwner` VARCHAR(121) DEFAULT NULL,
  `UserRole` VARCHAR(80) DEFAULT NULL,
  `Fortune_1000__c` INT(11) DEFAULT NULL,
  `Fortune_1000_Rank__c` INT(11) DEFAULT NULL,
  `Assigned_Licensed_Users__c` INT(11) DEFAULT 0,
  `Bonus_Users__c` INT(11) DEFAULT 0,
  `Cancels_ACV_All_Time__c` DECIMAL(16,2) DEFAULT 0,
  `Cancels_ACV_Trailing_12_Months__c` DECIMAL(16,2) DEFAULT 0,
  `Domain_s_Highest_Plan__c` VARCHAR(50) DEFAULT NULL,
  `Downgrades_ACV_All_Time__c` DECIMAL(16,2) DEFAULT 0,
  `Downgrades_ACV_Trailing_12_Months__c` DECIMAL(16,2) DEFAULT 0,
  `Last_Activity_Date__c` DATETIME DEFAULT NULL,
  `RenewalDate` DATETIME DEFAULT NULL,
  `Net_Bookings_ACV_All_Time__c` DECIMAL(16,2) DEFAULT 0,
  `Net_Bookings_ACV_Trailing_12_Months__c` DECIMAL(16,2) DEFAULT 0,
  `Paid_Licensed_Users__c` INT(11) DEFAULT 0,
  `Pending_Licensed_Users__c` INT(11) DEFAULT 0,
  `Upgrades_ACV_All_Time__c` DECIMAL(16,2) DEFAULT 0,
  `Upgrades_ACV_Trailing_12_Months__c` DECIMAL(16,2) DEFAULT 0,
  `Wins_ACV_All_Time__c` DECIMAL(16,2) DEFAULT 0,
  `Wins_ACV_Trailing_12_Months__c` DECIMAL(16,2) DEFAULT 0,
  `BasicPlans` INT DEFAULT 0,
  `AdvPlans` INT DEFAULT 0,
  `TeamPlans` INT DEFAULT 0,
  `EntPlans` INT DEFAULT 0,
  `OpenOppsACV` DECIMAL(16,2) DEFAULT 0,
  `ActiveTrials` INT DEFAULT 0,
  `Users_Individual` INT(11) DEFAULT 0,
  `Users_Team` INT(11) DEFAULT 0,
  `Users_Ent` INT(11) DEFAULT 0,
  `Users_Collab` INT(11) DEFAULT 0,
  LoggedIn10Day INT,
  LoggedIn30Day INT,
  LoggedIn90Day INT,
  Last_Upgrade_Date DATETIME,
  Last_Upgrade_MRR DECIMAL(10,2),
  KEY ix_domain (Domain_Name_URL__c)
)
;

INSERT INTO rpt_workspace.markj_ISR3_dashboard
SELECT 
a.Id,
a.Name AS AccountName,
a.Industry,
a.AnnualRevenue,
a.NumberOfEmployees,
a.Domain__c,
d.Domain_Name_URL__c,
a.Territory__c,
a.OWNER_ID,
CONCAT(aO.FIRST_NAME,' ',aO.LAST_NAME) AS AccountOwner,
ur.Name AS UserRole,
a.Fortune_1000__c,
a.Fortune_1000_Rank__c,
d.Assigned_Licensed_Users__c,
d.Bonus_Users__c,
d.Cancels_ACV_All_Time__c,
d.Cancels_ACV_Trailing_12_Months__c,
d.Domain_s_Highest_Plan__c,
d.Downgrades_ACV_All_Time__c,
d.Downgrades_ACV_Trailing_12_Months__c,
d.Last_Activity_Date__c,
NULL AS RenewalDate,
d.Net_Bookings_ACV_All_Time__c,
d.Net_Bookings_ACV_Trailing_12_Months__c,
d.Paid_Licensed_Users__c,
d.Pending_Licensed_Users__c,
d.Upgrades_ACV_All_Time__c,
d.Upgrades_ACV_Trailing_12_Months__c,
d.Wins_ACV_All_Time__c,
d.Wins_ACV_Trailing_12_Months__c,
0 AS BasicPlans,
0 AS AdvPlans,
0 AS TeamPlans,
0 AS EntPlans,
0 AS OpenOppsACV,
0 AS ActiveTrials,
0 AS Users_Individual,
0 AS Users_Team,
0 AS Users_Ent,
0 AS Users_Collab,
0 AS LoggedIn10Day,
0 AS LoggedIn30Day,
0 AS LoggedIn90Day,
NULL AS Last_Upgrade_Date,
NULL AS Last_Upgrade_MRR
FROM SFDC.PUBLIC.account a
LEFT JOIN SFDC.PUBLIC.domain d ON d.account__c=a.Id
#join (select distinct mainContactDomain from MAIN.RPT.paymentProfile where countAsPaid = 1) pp on pp.mainContactDomain=d.Domain_Name_URL__c 
JOIN MAIN.RPT.paidDomains pp ON pp.mainContactDomain=d.domain_Name_URL__c
LEFT JOIN SFDC.PUBLIC.user aO ON a.OWNER_ID=aO.Id
LEFT JOIN SFDC.PUBLIC.user_role ur ON aO.UserRoleId=ur.Id
WHERE 
#a.name in ( 'Compass Group Usa, Inc.','Twilio') and
#a.name = 'Twilio'
#and 
account__c IS NOT NULL
#and ur.Name = 'ISR3'
GROUP BY a.Id, d.Id
;

UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.BasicPlans = 
(
	SELECT 
	COUNT(DISTINCT(ppi.paymentProfileID))
	FROM MAIN.RPT.paidPlanInfo ppi
	WHERE m.Domain_Name_URL__c= ppi.domain
	AND ppi.productName = 'Basic'
	GROUP BY m.Domain_Name_URL__c
)
;

UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.AdvPlans = 
(
	SELECT 
	COUNT(DISTINCT(ppi.paymentProfileID))
	FROM MAIN.RPT.paidPlanInfo ppi
	WHERE m.Domain_Name_URL__c= ppi.domain
	AND ppi.productName = 'Advanced'
	GROUP BY m.Domain_Name_URL__c
)
;

UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.TeamPlans = 
(
	SELECT 
	COUNT(DISTINCT(ppi.paymentProfileID))
	FROM MAIN.RPT.paidPlanInfo ppi
	WHERE m.Domain_Name_URL__c= ppi.domain
	AND ppi.productName = 'Team'
	GROUP BY m.Domain_Name_URL__c
)
;

UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.EntPlans = 
(
	SELECT 
	COUNT(DISTINCT(ppi.paymentProfileID))
	FROM MAIN.RPT.paidPlanInfo ppi
	WHERE m.Domain_Name_URL__c= ppi.domain
	AND ppi.productName = 'Enterprise'
	GROUP BY m.Domain_Name_URL__c
)
;


-- Update Open Opps ACV
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.OpenOppsACV = 
(
	SELECT SUM(o.Amount)
	FROM SFDC.PUBLIC.open_opportunities o
	WHERE m.AccountId=o.AccountId
	GROUP BY m.Domain_Name_URL__c
	
)
;

UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.ActiveTrials = (SELECT dt.trials
	FROM MAIN.RPT.domainTrials dt
		WHERE dt.domain = m.Domain_Name_URL__c);



UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.LoggedIn10Day = (SELECT COUNT(DISTINCT(lct.userID))
				FROM MAIN.RPT.loginCountTotal lct
					JOIN rpt_main_02.userAccount u ON u.userID = lct.userID
					WHERE u.domain = m.Domain_Name_URL__c
					AND lct.daysSinceLastLogin <= 10);
					
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.LoggedIn30Day = (SELECT COUNT(DISTINCT(lct.userID))
				FROM MAIN.RPT.loginCountTotal lct
					JOIN rpt_main_02.userAccount u ON u.userID = lct.userID
					WHERE u.domain = m.Domain_Name_URL__c
					AND lct.daysSinceLastLogin <= 30);
				
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.LoggedIn90Day = (SELECT COUNT(DISTINCT(lct.userID))
				FROM MAIN.RPT.loginCountTotal lct
					JOIN rpt_main_02.userAccount u ON u.userID = lct.userID
					WHERE u.domain = m.Domain_Name_URL__c
					AND lct.daysSinceLastLogin <= 90);


DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_LicensedUserGroupings;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sfdc_LicensedUserGroupings
(masterDomain VARCHAR(100),
productGroup2 VARCHAR(25),
mainContactUserID BIGINT,
PRIMARY KEY (mainContactUserID),
KEY masterDomain (masterDomain));

INSERT INTO rpt_main_02.stg_sfdc_LicensedUserGroupings
	
	SELECT masterDomain, productGroup2, mainContactUserID
	FROM rpt_main_02.`arc_cDunn_templateUsersNew` u 
	JOIN rpt_workspace.markj_ISR3_dashboard m ON u.masterDomain=m.Domain_Name_URL__c
	WHERE (accountType != 3 OR accountType IS NULL)
	AND productGroup2 IN('Basic', 'Advanced', 'Team', 'Enterprise', 'Trial', 'Internal Collaborator', 'External Collaborator')
	AND paidCollab IS NULL
	GROUP BY mainContactUserID
;




-- Update Individual Users
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.Users_Individual = 
(
	SELECT 
	COUNT(DISTINCT mainContactUserID)
	FROM rpt_main_02.stg_sfdc_LicensedUserGroupings lug
	WHERE m.Domain_Name_URL__c=lug.masterDomain
	AND lug.productGroup2 IN ('Basic','Advanced')
	GROUP BY lug.masterDomain
)
;

-- Update Team Users
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.Users_Team = 
(
	SELECT 
	COUNT(DISTINCT mainContactUserID)
	FROM rpt_main_02.stg_sfdc_LicensedUserGroupings lug
	WHERE m.Domain_Name_URL__c=lug.masterDomain
	AND lug.productGroup2 = 'Team'
	GROUP BY lug.masterDomain
)
;


-- Update Ent Users
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.Users_Ent = 
(
	SELECT 
	COUNT(DISTINCT mainContactUserID)
	FROM rpt_main_02.stg_sfdc_LicensedUserGroupings lug
	WHERE m.Domain_Name_URL__c=lug.masterDomain
	AND lug.productGroup2 = 'Enterprise'
	GROUP BY lug.masterDomain
)
;


-- Update Collab Users
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.Users_Collab = 
(
	SELECT 
	COUNT(DISTINCT mainContactUserID)
	FROM rpt_main_02.stg_sfdc_LicensedUserGroupings lug
	WHERE m.Domain_Name_URL__c=lug.masterDomain
	AND lug.productGroup2 IN ('Internal Collaborator','External Collaborator')
	GROUP BY lug.masterDomain
)
;


UPDATE rpt_workspace.markj_ISR3_dashboard m
SET m.RenewalDate = 
(
	SELECT MIN(CLOSE_DATE)
	FROM SFDC.PUBLIC.renewal_opportunities ro
	WHERE m.AccountId=ro.AccountId
	GROUP BY ro.AccountId

)
;

DROP TABLE IF EXISTS rpt_workspace.cDunn_domainLastUpgrade;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_domainLastUpgrade
(accountID VARCHAR(25),
domain VARCHAR(100),
lastUpgradeDate DATETIME,
lastUpgradeMRR DECIMAL(10,2),
PRIMARY KEY (domain),
KEY accountID (accountID),
KEY ix_lastUpgrade (lastUpgradeDate));

INSERT INTO rpt_workspace.cDunn_domainLastUpgrade (accountID, domain, lastUpgradeDate)

SELECT m.accountID, m.Domain_Name_URL__c, MAX(rsm.recordDateTime)
FROM rpt_workspace.markj_ISR3_dashboard m
JOIN MAIN.RPT.paidPlanInfo ppi ON m.Domain_Name_URL__c = ppi.domain
JOIN rpt_main_02.output_RevenueSummaryMonthly rsm ON rsm.paymentProfileID = ppi.paymentProfileID
WHERE rsm.recordType = 'UPGRADES' AND rsm.currencyChange = 0
GROUP BY m.Domain_Name_URL__c;


UPDATE rpt_workspace.cDunn_domainLastUpgrade A
SET lastUpgradeMRR = (SELECT rsm.MonthlyPaymentChange
FROM rpt_main_02.output_RevenueSummaryMonthly rsm
JOIN MAIN.RPT.paidPlanInfo ppi ON rsm.paymentProfileID = ppi.paymentProfileID
WHERE ppi.domain = A.domain AND rsm.recordDateTime = A.lastUpgradeDate GROUP BY A.domain);

DROP TABLE IF EXISTS rpt_workspace.cDunn_accountLastUpgrade;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_accountLastUpgrade
(accountID VARCHAR(25),
lastUpgradeDate DATETIME,
lastUpgradeMRR DECIMAL(10,2),
PRIMARY KEY (accountID),
KEY ix_lastUpgrade (lastUpgradeDate));

INSERT INTO rpt_workspace.cDunn_accountLastUpgrade (accountID, lastUpgradeDate)
SELECT accountID, MAX(lastUpgradeDate)
FROM rpt_workspace.cDunn_domainLastUpgrade
GROUP BY accountID;

UPDATE rpt_workspace.cDunn_accountLastUpgrade A
SET lastUpgradeMRR = (SELECT du.lastUpgradeMRR
			FROM rpt_workspace.cDunn_domainLastUpgrade du
			WHERE du.accountID = A.accountID AND du.lastUpgradeDate = A.lastUpgradeDate);


UPDATE rpt_workspace.markj_ISR3_dashboard m
SET Last_Upgrade_Date = (SELECT au.lastUpgradeDate
				FROM rpt_workspace.cDunn_accountLastUpgrade au
					WHERE au.accountID = m.accountID);
					
UPDATE rpt_workspace.markj_ISR3_dashboard m
SET Last_Upgrade_MRR = (SELECT au.lastUpgradeMRR
				FROM rpt_workspace.cDunn_accountLastUpgrade au
					WHERE au.accountID = m.accountID);
					
SELECT AccountId, AccountName, Industry, AnnualRevenue, NumberOfEmployees, Domain__c, Territory__c, OWNER_ID, AccountOwner, UserRole,
Fortune_1000__c, Fortune_1000_Rank__c, 
SUM(IFNULL(Assigned_Licensed_Users__c,0)) AS Assigned_Licensed_Users__c,
SUM(IFNULL(Bonus_Users__c,0)) AS Bonus_Users__c,
SUM(IFNULL(Cancels_ACV_All_Time__c,0)) AS Cancels_ACV_All_Time__c,
SUM(IFNULL(Cancels_ACV_Trailing_12_Months__c,0)) AS Cancels_ACV_Trailing_12_Months__c,
Domain_s_Highest_Plan__c, 
SUM(IFNULL(Downgrades_ACV_All_Time__c,0)) AS Downgrades_ACV_All_Time__c,
SUM(IFNULL(Downgrades_ACV_Trailing_12_Months__c,0)) AS Downgrades_ACV_Trailing_12_Months__c,
Last_Activity_Date__c, 
RenewalDate, 
SUM(IFNULL(Net_Bookings_ACV_All_Time__c,0)) AS Net_Bookings_ACV_All_Time__c,
SUM(IFNULL(Net_Bookings_ACV_Trailing_12_Months__c,0)) AS Net_Bookings_ACV_Trailing_12_Months__c,
SUM(IFNULL(Paid_Licensed_Users__c,0)) AS Paid_Licensed_Users__c,
SUM(IFNULL(Pending_Licensed_Users__c,0)) AS Pending_Licenesed_Users__c,
SUM(IFNULL(Upgrades_ACV_All_Time__c,0)) AS Upgrades_ACV_All_Time__c,
SUM(IFNULL(Upgrades_ACV_Trailing_12_Months__c,0)) AS Upgrades_ACV_Trailing_12_Months__c,
SUM(IFNULL(Wins_ACV_All_Time__c,0)) AS Wins_ACV_All_Time__c,
SUM(IFNULL(Wins_ACV_Trailing_12_Months__c,0)) AS Wins_ACV_Trailing_12_Months__c,
SUM(IFNULL(BasicPlans,0)) AS BasicPlans,
SUM(IFNULL(AdvPlans,0)) AS AdvPlans,
SUM(IFNULL(TeamPlans,0)) AS TeamPlans,
SUM(IFNULL(EntPlans,0)) AS EntPlans,
SUM(IFNULL(OpenOppsACV,0)) AS OpenOppsACV,
SUM(IFNULL(ActiveTrials,0)) AS ActiveTrials,
SUM(IFNULL(Users_Individual,0)) AS Users_Individual,
SUM(IFNULL(Users_Team,0)) AS Users_Team,
SUM(IFNULL(Users_Ent,0)) AS Users_Ent,
SUM(IFNULL(Users_Collab,0)) AS Users_Collab,
SUM(IFNULL(LoggedIn10Day,0)) AS LoggedIn10Day,
SUM(IFNULL(LoggedIn30Day,0)) AS LoggedIn30Day,
SUM(IFNULL(LoggedIn90Day,0)) AS LoggedIn90Day,
Last_Upgrade_Date,
Last_Upgrade_MRR
FROM rpt_workspace.markj_ISR3_dashboard
GROUP BY AccountId
;


set session transaction isolation level repeatable read;
