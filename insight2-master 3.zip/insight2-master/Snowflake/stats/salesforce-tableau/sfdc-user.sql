


SELECT
    u.UserName           AS 'User Name',
    u.FIRST_NAME          AS 'First Name',
    u.LAST_NAME           AS 'Last Name',
    u.Title,
    u.Email,
    u.Phone,
    u.MobilePhone        AS 'Mobile Phone',
    u.Alias,
    u.IsActive           AS 'Is Active',
    u.StartDay           AS 'Start Day',
    u.EndDay             AS 'End Day',
    u.Extension,
    u.Id,
    ur.Name              AS 'User Role',
    u.ProfileId          AS 'Profile Id',
    u.ManagerId          AS 'Manager Id',
    u.LastLoginDate      AS 'Last Login Date',
    u.Employee_Name__c   AS 'Employee Name',
    u.Owner_at_Import__c AS 'Owner at Import',
    u.CREATED_DATE        AS 'Created Date',
    u.Division
FROM SFDC.PUBLIC.user u
    LEFT JOIN SFDC.PUBLIC.user_role ur ON u.UserRoleId = ur.Id
;