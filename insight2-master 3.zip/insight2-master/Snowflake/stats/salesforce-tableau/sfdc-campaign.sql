




SELECT 
c.Name,
c.Type,
c.Status,
c.StartDate AS 'Start Date',
c.EndDate AS 'End Date',
REPLACE(c.Description,'"'," ") AS 'Description',
c.NumberOfLeads AS 'Number of Leads',
c.NumberOfConvertedLeads AS 'Number of Converted Leads',
c.NumberOfContacts AS 'Number of Contacts',
c.NumberOfResponses AS 'Number of Responses',
c.NumberOfOpportunities AS 'Number of Opportunities',
c.NumberOfWonOpportunities AS 'Number of Won Opportunities',
c.AmountAllOpportunities AS 'Amount All Opportunities',
c.AmountWonOpportunities AS 'Amount Won Opportunities',
c.Id,
c.ParentId AS 'Parent Id',
rt.Name AS 'Record Type'
FROM SFDC.PUBLIC.campaign c
LEFT JOIN SFDC.PUBLIC.record_type rt ON c.RecordTypeId=rt.Id
;