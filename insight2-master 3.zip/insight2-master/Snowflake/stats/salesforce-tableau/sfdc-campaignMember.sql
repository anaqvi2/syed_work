



SELECT 
cm.Status,
cm.HasResponded AS 'Has Responded',
cm.CREATED_DATE AS 'Created Date',
cm.LastModifiedDate AS 'Last Modified Date',
cm.FirstRespondedDate AS 'First Responded Date',
cm.Id,
c.Name AS 'Campaign Name',
cm.LeadId AS 'Lead Id',
cm.ContactId AS 'Contact Id',
CONCAT(cb.FIRST_NAME,' ',cb.LAST_NAME) AS 'Created By Name',
CONCAT(lm.FIRST_NAME,' ',lm.LAST_NAME) AS 'Last Modified By Name'
FROM SFDC.PUBLIC.campaign_member cm
LEFT JOIN SFDC.PUBLIC.campaign c ON cm.CampaignId=c.Id
LEFT JOIN SFDC.PUBLIC.user cb ON cm.CreatedById=cb.Id
LEFT JOIN SFDC.PUBLIC.user lm ON cm.LastModifiedById=lm.Id
;