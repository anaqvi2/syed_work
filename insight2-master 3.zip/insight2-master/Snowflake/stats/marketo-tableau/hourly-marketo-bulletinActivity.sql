

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-bulletinActivity.csv");

-- Get last eventDateTime processed
SELECT MAX(firstEventDateTime)
INTO @maxEventDateTime
FROM MAIN.ARC.clientEventBulletinFirstAction;

-- process all bulletin client events since last eventDateTime
INSERT IGNORE INTO MAIN.ARC.clientEventBulletinFirstAction
    SELECT
        ce.parm1Int,
        sl.userID,
        ce.objectID,
        ce.actionID,
        MIN(ce.eventDateTime) eventDateTime -- Get first time user did the action
    FROM MAIN.ARC.clientEventBulletin ce
        JOIN ss_core_02.sessionLog sl ON ce.sessionLogID = sl.sessionLogID
    WHERE ce.eventDateTime >= @maxEventDateTime
    GROUP BY ce.parm1Int, sl.userID, ce.objectID, ce.actionID;

-- Select all bulletin activity
SELECT
    bu.bulletinID,
    bu.userID,
    ua.emailAddress,
    bu.closeCount                                                             bulletinTotalCloses,
    bu.CLOSE_DATETime                                                          bulletinCLOSE_DATETime,
    ce.firstEventDateTime                                                     eventDateTime,
    ce.clientEventObjectID                                                    eventObject,
    ce.clientEventActionID                                                    eventAction,
    IFNULL(ce.clientEventActionID = 1 AND ce.clientEventObjectID = 10717, 0)  isOpen,
    IFNULL(ce.clientEventActionID = 2 AND ce.clientEventObjectID = 10717, 0)  isClose,
    IFNULL(ce.clientEventActionID = 22 AND ce.clientEventObjectID = 10718, 0) isClick,
    CASE
    WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1
        THEN 0
    WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0
        THEN 1
    WHEN ucs.valueBoolean = 1
        THEN 0
    WHEN ucs.valueBoolean = 0
        THEN 1
    WHEN ocs.valueBoolean = 0
        THEN 1
    ELSE 0
    END                                                                       isUnsubscribe
FROM ss_account_02.bulletinUser bu
    JOIN ss_account_02.bulletin b ON bu.bulletinID = b.bulletinID
    LEFT JOIN ss_core_02.userAccount ua ON bu.userID = ua.userID
    LEFT JOIN MAIN.ARC.clientEventBulletinFirstAction ce ON bu.userID = ce.userID AND bu.bulletinID = ce.bulletinID
    LEFT JOIN rpt_main_02.stg_bulletinUnsubscribeUsers buu ON bu.userID = buu.userID
    LEFT JOIN ss_account_02.orgConfigSetting ocs ON buu.organizationID = ocs.organizationID
                                                    AND ocs.configPropertyID = 1300
                                                    AND ocs.insertDateTime BETWEEN b.startDateTime AND b.endDateTime
    LEFT JOIN ss_account_02.userConfigSetting ucs ON buu.userID = ucs.userID
                                                     AND ucs.configPropertyID = 1300
                                                     AND ucs.insertDateTime BETWEEN b.startDateTime AND b.endDateTime
WHERE
    bu.userID NOT IN (SELECT userID
                      FROM leadflow.arc_marketo_lead_lists
                      WHERE listID = 111557) -- Ignore Marketo seed list users
    AND b.startDateTime >= date_sub(current_timestamp(), INTERVAL 3 MONTH)
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-bulletinActivity.csv");
