

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-replicationDelayLog.csv");

-- Select all lead activities from the past three months
SELECT *
FROM MAIN.ARC.insightHealthLog;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-replicationDelayLog.csv");
