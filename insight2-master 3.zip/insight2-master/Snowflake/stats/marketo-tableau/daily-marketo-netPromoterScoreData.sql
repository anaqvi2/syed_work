

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-netPromoterScoreData.csv");

-- Select all net promoter score data
SELECT *
FROM leadflow.arc_marketo_lead_nps
WHERE emailAddress NOT LIKE '%smartsheet.com'  -- Ignore @smartsheet.com users. Probably from testing.
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-netPromoterScoreData.csv");
