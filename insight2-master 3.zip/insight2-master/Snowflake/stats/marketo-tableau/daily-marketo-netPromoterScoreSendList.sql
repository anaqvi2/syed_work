

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-netPromoterScoreSendList.csv");

-- Select all users send the NPS survey
SELECT
    userID,
    listID,
    listName
FROM leadflow.arc_marketo_lead_lists
WHERE listID IN
      (33268, 76512, 128696, 153267, 153268, 160629, 164362, 164780, 164781, 164782, 164783,
       164784, 164785, 164786, 164789, 164790, 164791, 164792, 164793, 164794);

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-netPromoterScoreSendList.csv");
