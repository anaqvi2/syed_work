SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-unlicensedOrgMembersV2.csv");


SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT MAX(insertDateTime) FROM rpt_main_02.jlatta_unlicensedorgmembers INTO  @maxinsertdatetime;

INSERT INTO rpt_main_02.jlatta_unlicensedorgmembers

(userID,
firstName,
lastName,
emailAddress,
languageFriendly,
countryFriendly,
userType,
autoProvisioned,
UnlicensedOrgMember,
insertDateTime,
LicensedOrgMember,
organizationID,
state,
insertByUserID) 


SELECT
u.userID,
u.firstName,
u.lastName,
u.emailAddress,
u.languageFriendly,
u.countryFriendly,
CASE h.productID
	WHEN 0 THEN "Cancelled"
	WHEN 1 THEN "Trial"
	WHEN 2 THEN "Free"
	WHEN 3 THEN "Basic"
	WHEN 4 THEN "Advanced"
	WHEN 5 THEN "Premium"
	WHEN 6 THEN "Enterprise"
	WHEN 7 THEN "Team"
    WHEN 8 THEN "Team Plus"
	ELSE "Collaborator" END AS userType,
IF(c.organizationID IS NOT NULL, 1,0) AS autoProvisioned,
1 AS UnlicensedOrgMember,     
o.insertDateTime,
0 AS LicensedOrgMember,
o.organizationID,
o.state,
o.insertByUserID
FROM rpt_main_02.userAccount u
JOIN rpt_main_02.organizationUserRole o 
ON o.userID=u.userID
LEFT JOIN ss_account_02.orgConfigSetting c
ON c.organizationID=o.organizationID
AND c.configPropertyID=1168
AND c.valueLong >0
LEFT JOIN rpt_main_02.hist_paymentProfile h
ON h.ownerID=o.organizationID
AND h.accountType=3
AND o.insertDateTime>=h.modifyDateTime
AND o.insertDateTime<=h.hist_effectiveThruDateTime
JOIN rpt_main_02.rpt_organizationUser r
ON r.userID=o.userID
WHERE r.licenseUserCount=0
AND (o.state=1 OR o.state=2)
AND o.role='MEMBER'
AND o.insertDateTime >@maxinsertdatetime
GROUP BY 1;

INSERT INTO rpt_main_02.jlatta_unlicensedorgmembers

(userID,
firstName,
lastName,
emailAddress,
languageFriendly,
countryFriendly,
userType,
autoProvisioned,
UnlicensedOrgMember,
insertDateTime,
LicensedOrgMember,
organizationID,
state,
insertByUserID)


SELECT
u.userID,
u.firstName,
u.lastName,
u.emailAddress,
u.languageFriendly,
u.countryFriendly,
CASE h.productID
	WHEN 0 THEN "Cancelled"
	WHEN 1 THEN "Trial"
	WHEN 2 THEN "Free"
	WHEN 3 THEN "Basic"
	WHEN 4 THEN "Advanced"
	WHEN 5 THEN "Premium"
	WHEN 6 THEN "Enterprise"
	WHEN 7 THEN "Team"
    WHEN 8 THEN "Team Plus"
	ELSE "Collaborator" END AS userType,
IF(c.organizationID IS NOT NULL, 1,0) AS autoProvisioned,
0 AS UnlicensedOrgMember,   
o.insertDateTime,   
1 AS LicensedOrgMember,
o.organizationID,
o.state,
o.insertByUserID
FROM rpt_main_02.userAccount u
JOIN rpt_main_02.organizationUserRole o 
ON o.userID=u.userID
LEFT JOIN ss_account_02.orgConfigSetting c
ON c.organizationID=o.organizationID
AND c.configPropertyID=1168
AND c.valueLong >0
LEFT JOIN rpt_main_02.hist_paymentProfile h
ON h.ownerID=o.organizationID
AND h.accountType=3
AND o.insertDateTime>=h.modifyDateTime
AND o.insertDateTime<=h.hist_effectiveThruDateTime
WHERE (o.state=1 OR o.state=2)
AND o.role='LICENSE_USER'
AND o.insertDateTime> @maxinsertdatetime-- Daily Data 
GROUP BY 1;


SELECT * FROM rpt_main_02.jlatta_unlicensedorgmembers WHERE insertDateTime <CONCAT(CURDATE()," ","00:00:00");

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-unlicensedOrgMembersV2.csv");
