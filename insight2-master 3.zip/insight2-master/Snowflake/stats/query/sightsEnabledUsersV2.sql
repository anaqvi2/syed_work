SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("sightsEnabledUsersV2.sql");

SELECT ucs.userID, u.emailAddress, ppcu.planID AS ppID, ppcu.planDomain, ppcu.productName
FROM ss_account_02.userConfigSetting ucs
JOIN rpt_main_02.userAccount u ON u.userID = ucs.userID
JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = ucs.userID
WHERE configPropertyId = 4024 AND valueBoolean = 1
;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("sightsEnabledUsersV2.sql");
