SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("UseCaseReportV2.sql");

drop table if exists rpt_workspace.js_useCaseEnrichment;
create table if not exists rpt_workspace.js_useCaseEnrichment
select * from ss_sfdc_02.use_case;

delete from rpt_workspace.js_useCaseEnrichment
where CreatedDate < '2016-07-01';

alter table rpt_workspace.js_useCaseEnrichment
add createdByName varchar(50),
add accountName varchar(50),
add contactName varchar(50),
add contactEmailAddress varchar(50),
add industry varchar(50),
add subIndustry varchar(50),
add industryCombinedField varchar(50),
add maxProductName varchar(50),
add ACV dec(10,2),
add ISP int,
add paymentProfileID int,
add toothbrushLastMonthLicensedUsers int,
add toothbrushLastMonthSuperUsers int,
add toothbrushLastMonthZeroDayUsers int,
add createdByTeam varchar(50),
add index (ISP),
add index (paymentProfileID),
drop InsightModifiedDateTime,
drop InsightInsertDateTime,
drop ACV_Potential_img__c;

update rpt_workspace.js_useCaseEnrichment A
left join ss_sfdc_02.user B
on A.CreatedById=B.Id
left join ss_sfdc_02.account C
on A.Account_Link__c=C.Id
left join ss_sfdc_02.contact D FORCE INDEX (PRIMARY)
on A.Contact_Link__c=D.Id
set createdByName=concat(B.FirstName,' ',B.LastName), A.accountName=C.Name, A.contactName=concat(D.FirstName,' ',D.LastName), A.contactEmailAddress=D.Email;

update rpt_workspace.js_useCaseEnrichment
set Contact_OpsCon_Link__c=substring_index(substring_index(Contact_OpsCon_Link__c, '"',2), '"',-1);

update rpt_workspace.js_useCaseEnrichment
set paymentProfileID=substring_index(Contact_OpsCon_Link__c,'/',-1);

update rpt_workspace.js_useCaseEnrichment A
join ss_sfdc_02.account B
on A.Account_Link__c=B.Id 
join rpt_main_02.arc_ISPDomains C
on B.Domain__c=C.domain
set A.ISP=1;

update rpt_workspace.js_useCaseEnrichment
set ISP=1
where accountName like '%ISP Account%';

update rpt_workspace.js_useCaseEnrichment A
join ss_sfdc_02.account B 
on A.Account_Link__c=B.Id
join rpt_workspace.pj_domainDataCoverage C
on B.Domain__c=C.domain
set A.industry=C.Industry, A.subIndustry=C.subIndustry
where C.industry!='Not Available' and A.ISP is null;

update rpt_workspace.js_useCaseEnrichment
set industry='NULL'
where industry is null;

update rpt_workspace.js_useCaseEnrichment
set subIndustry='NULL'
where subIndustry is null;

update rpt_workspace.js_useCaseEnrichment
set industryCombinedField=concat(industry,' / ',subIndustry);

update rpt_workspace.js_useCaseEnrichment A
set ACV=
(select sum(ACV) from rpt_main_02.rpt_paidPlanInfo B
where A.Account_Link__c=B.accountId)
where A.ISP is null;

update rpt_workspace.js_useCaseEnrichment A
join rpt_main_02.rpt_csReport B
on A.account_Link__c=B.accountID
set A.maxProductName=B.maxProductName
where A.ISP is null;

update rpt_workspace.js_useCaseEnrichment A
join rpt_main_02.rpt_paidPlanInfo B
on A.paymentProfileID=B.paymentProfileID
set A.ACV=B.ACV, A.maxProductName=B.productName
where A.ISP=1;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthLicensedUsers=
(select sum(licensedUsers) from rpt_workspace.js_toothbrushCustomerBreakout B force index (accountID)
where A.Account_Link__c=B.accountID and B.monthYear='December 2017')
where A.ISP is null;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthLicensedUsers=
(select sum(licensedUsers) from rpt_workspace.js_toothbrushCustomerBreakout B force index (ISP_PPID)
where A.paymentProfileID=B.ISP_PPID and B.monthYear='December 2017')
where A.ISP=1;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthSuperUsers=
(select sum(daysActiveEither15) from rpt_workspace.js_toothbrushCustomerBreakout B force index (accountID)
where A.Account_Link__c=B.accountID and B.monthYear='December 2017')
where A.ISP is null;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthSuperUsers=
(select sum(daysActiveEither15) from rpt_workspace.js_toothbrushCustomerBreakout B force index (ISP_PPID)
where A.paymentProfileID=B.ISP_PPID and B.monthYear='December 2017')
where A.ISP=1;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthZeroDayUsers=
(select sum(daysActiveEither0) from rpt_workspace.js_toothbrushCustomerBreakout B force index (accountID)
where A.Account_Link__c=B.accountID and B.monthYear='December 2017')
where A.ISP is null;

update rpt_workspace.js_useCaseEnrichment A
set toothbrushLastMonthZeroDayUsers=
(select sum(daysActiveEither0) from rpt_workspace.js_toothbrushCustomerBreakout B force index (ISP_PPID)
where A.paymentProfileID=B.ISP_PPID and B.monthYear='December 2017')
where A.ISP=1;

update rpt_workspace.js_useCaseEnrichment A
join ss_sfdc_02.user B
on A.createdById=B.Id 
join ss_sfdc_02.user_role C
on B.UserRoleID=C.Id 
set A.createdByTeam=C.Name;

alter table rpt_workspace.js_useCaseEnrichment
add country varchar(50);

UPDATE rpt_workspace.js_useCaseEnrichment A
JOIN ss_sfdc_02.account B
ON A.Account_Link__c=B.Id 
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.accountId = B.Id
JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = ppi.mainContactUserID
SET A.country = ip.ipCountry;

ALTER TABLE rpt_workspace.js_useCaseEnrichment
ADD A13Region VARCHAR(100);

UPDATE rpt_workspace.js_useCaseEnrichment A
JOIN rpt_main_02.ref_geoClassification B ON A.country = B.country
SET A.A13Region = B.geoRegion;

select * from rpt_workspace.js_useCaseEnrichment;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("UseCaseReportV2.sql");

