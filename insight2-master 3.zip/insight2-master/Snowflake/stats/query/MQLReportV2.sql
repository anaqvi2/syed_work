




/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MQLReportV2.sql'));

drop table if exists MAIN.RPT.MQLENRICHMENT;
create table if not exists MAIN.RPT.MQLENRICHMENT
(TASK_ID varchar(50),
OPPORTUNITY_ID varchar(50),
DIRECT_MAPPING int,
contactMapping int,
accountMapping int,
mappingType varchar(50),
TASK_TRAFFIC_SOURCE varchar(100),
TASK_SOURCE varchar(50),
TASK_SUB_SOURCE varchar(50),
TASK_CREATED_DATE datetime,
TASK_SUBJECT varchar(100),
TASK_OWNER_ID varchar(50),
taskOwner varchar(50),
taskOwnerRole varchar(50),
TASK_WHO_ID varchar(50),
TASK_TTTC dec(10,2),
TASK_STATUS varchar(50),
taskWhoType varchar(50),
taskWhoName varchar(50),
taskWhoEmailAddress varchar(50),
taskWhoTitle varchar(50),
taskWhoUserID int,
taskWhoDomain varchar(50),
taskWhoDomainISP int,
taskWhoAccountID varchar(50),
taskWhoAccountName varchar(50),
taskWhoDomainIsFortune1000 int,
taskWhoDomainIsExistingCustomer int,
taskWhoProductNameAtCreation varchar(50),
taskWhoFollowUpActivityCount int,
taskWhoStrongLead int,
taskWhoCompanySize varchar(50),
OPPORTUNITY_NAME varchar(100),
OPPORTUNITY_CREATED_DATE datetime,
OPPORTUNITY_STAGE varchar(50),
OPPORTUNITY_ARR dec(10,2),
OPPORTUNITY_COMMISH_ARR dec(10,2),
OPPORTUNITY_OWNER_ID varchar(50),
OPPORTUNITY_OWNER varchar(50),
OPPORTUNITY_CLOSE_DATE date,
opportunityDateDiff int,
opportunityClosedWonID varchar(50),
opportunityCycleTime int,
opportunitySecurityPack varchar(10),
opportunityIntegrationPack varchar(10),
opportunitySights varchar(10),
opportunitySalesforce varchar(10),
opportunitySCC varchar(10),
opportunityJira varchar(10),
taskCount int,
TASK_TTTCCalc dec(10,3),
taskWhoFollowUpActivityCountCalc dec(10,3),
opportunityCount int,
OPPORTUNITY_ARRCalc dec(10,3),
taskBucket varchar(50),
taskWhoDomainNewLogo int,
taskWhoCount int,
TASK_WHO_IDProrated dec(10,3),
OPPORTUNITY_ID2 varchar(50),
OPPORTUNITY_STAGE2 varchar(50),
OPPORTUNITY_ARR2 dec(10,2),
opportunityDateDiff2 int,
opportunityCycleTime2 int,
opportunityCount2 int,
OPPORTUNITY_ARRCalc2 dec(10,3),
OPPORTUNITY_ID3 varchar(50),
OPPORTUNITY_STAGE3 varchar(50),
OPPORTUNITY_ARR3 dec(10,2),
opportunityDateDiff3 int,
opportunityCycleTime3 int,
opportunityCount3 int,
OPPORTUNITY_ARRCalc3 dec(10,3),
OPPORTUNITY_IDProrated dec(10,3),
OPPORTUNITY_IDProrated2 dec(10,3),
OPPORTUNITY_IDProrated3 dec(10,3),
primary key (TASK_ID, OPPORTUNITY_ID));


INSERT INTO MAIN.RPT.MQLENRICHMENT(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, DIRECT_MAPPING,
OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 1,
B.Id, B.Name, B.CREATED_DATE, B.STAGE_NAME, (B.ARR_Variance__c/hce.EXCHANGE_RATE), (B.Commissionable_ACV__c/hce.EXCHANGE_RATE), 
B.OWNER_ID, C.FIRST_NAME||' '||C.LAST_NAME, B.CLOSE_DATE
FROM SFDC.PUBLIC.task A
JOIN SFDC.PUBLIC.opportunity B
ON A.WHAT_ID=B.Id
JOIN SFDC.PUBLIC.user C
ON B.OWNER_ID=C.Id
LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = B.CURRENCY_ISO_CODE 
	AND B.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND B.CREATED_DATE >= A.CREATED_DATE AND B.CLOSE_DATE >= '2016-01-01';
  AND NOT EXISTS (SELECT 1 FROM MAIN.RPT.MQLENRICHMENT X WHERE X.TASK_ID = A.Id AND X.OPPORTUNITY_ID = B.Id)
;


--MERGE INTO MAIN.RPT.MQLENRICHMENT T
--  USING (
--    SELECT A.Id
--          ,A.Traffic_Source__c
--          ,TRIM(LEFT(A.Traffic_Source__c,(POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
--           TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
--           A.CREATED_DATE
--          ,A.SUBJECT
--          ,A.OWNER_ID
--          ,A.WHO_ID
--          ,A.Time_To_Task_Completion__c
--          ,A.Status
--          ,1
--          ,B.Id
--          ,B.Name
--          ,B.CREATED_DATE
--          ,B.STAGE_NAME
--          ,(B.ARR_Variance__c/hce.EXCHANGE_RATE)
--          ,(B.Commissionable_ACV__c/hce.EXCHANGE_RATE)
--          ,B.OWNER_ID
--          ,C.FIRST_NAME || ' ' || C.LAST_NAME
--          ,B.CLOSE_DATE
--    FROM SFDC.PUBLIC.task A
--    JOIN SFDC.PUBLIC.opportunity B
--    ON A.WHAT_ID=B.Id
--    JOIN SFDC.PUBLIC.user C
--    ON B.OWNER_ID=C.Id
--    LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = B.CURRENCY_ISO_CODE 
--    	AND B.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
--    WHERE A.Traffic_Source__c != '' AND B.CREATED_DATE >= A.CREATED_DATE AND B.CLOSE_DATE >= '2016-01-01';
--  ) S
--  ON S.TASK_ID = T.TASK_ID
-- AND S.OPPORTUNITY_ID = T.OPPORTUNITY_ID
--  WHEN NOT MATCHED THEN
--    INSERT (TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, DIRECT_MAPPING, OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
--    VALUES (S.TASK_ID, S.TASK_TRAFFIC_SOURCE, S.TASK_SOURCE, S.TASK_SUB_SOURCE, S.TASK_CREATED_DATE, S.TASK_SUBJECT, S.TASK_OWNER_ID, S.TASK_WHO_ID, S.TASK_TTTC, S.TASK_STATUS, S.DIRECT_MAPPING, S.OPPORTUNITY_ID, S.OPPORTUNITY_NAME, S.OPPORTUNITY_CREATED_DATE, S.OPPORTUNITY_STAGE, S.OPPORTUNITY_ARR, S.OPPORTUNITY_COMMISH_ARR, S.OPPORTUNITY_OWNER_ID, S.OPPORTUNITY_OWNER, S.OPPORTUNITY_CLOSE_DATE)
--;


--MERGE INTO MAIN.RPT.MQLENRICHMENT T
--  USING (
--    SELECT A.Id, A.Traffic_Source__c,
--    TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
--    TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
--    A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 1,
--    B.Id, B.Name, B.CREATED_DATE, B.STAGE_NAME, (B.ARR_Variance__c/hce.EXCHANGE_RATE), (B.Commissionable_ACV__c/hce.EXCHANGE_RATE), 
--    B.OWNER_ID, C.FIRST_NAME || ' ' || C.LAST_NAME, B.CLOSE_DATE
--    FROM SFDC.PUBLIC.task A
--    JOIN SFDC.PUBLIC.opportunity B
--    ON A.WHAT_ID=B.Id
--    JOIN SFDC.PUBLIC.user C
--    ON B.OWNER_ID=C.Id
--    LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = B.CURRENCY_ISO_CODE 
--    	AND B.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
--    WHERE A.Traffic_Source__c != '' AND B.CREATED_DATE >= A.CREATED_DATE AND B.CLOSE_DATE >= '2016-01-01';
--  ) S
--  ON S.TASK_ID  T.TASK_ID
-- AND S.OPPORTUNITY_ID = T.OPPORTUNITY_ID
--  WHEN NOT MATCHED THEN
--    INSERT (TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, DIRECT_MAPPING, OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
--    VALUES (S.TASK_ID, S.TASK_TRAFFIC_SOURCE, S.TASK_SOURCE, S.TASK_SUB_SOURCE, S.TASK_CREATED_DATE, S.TASK_SUBJECT, S.TASK_OWNER_ID, S.TASK_WHO_ID, S.TASK_TTTC, S.TASK_STATUS, S.DIRECT_MAPPING, S.OPPORTUNITY_ID, S.OPPORTUNITY_NAME, S.OPPORTUNITY_CREATED_DATE, S.OPPORTUNITY_STAGE, S.OPPORTUNITY_ARR, S.OPPORTUNITY_COMMISH_ARR, S.OPPORTUNITY_OWNER_ID, S.OPPORTUNITY_OWNER, S.OPPORTUNITY_CLOSE_DATE)
--;

--INSERT IGNORE INTO MAIN.RPT.MQLENRICHMENT(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, DIRECT_MAPPING,
--OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
--SELECT A.Id, A.Traffic_Source__c,
--TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
--TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
--A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 1,
--B.Id, B.Name, B.CREATED_DATE, B.STAGE_NAME, (B.ARR_Variance__c/hce.EXCHANGE_RATE), (B.Commissionable_ACV__c/hce.EXCHANGE_RATE), 
--B.OWNER_ID, CONCAT(C.FIRST_NAME,' ',C.LAST_NAME), B.CLOSE_DATE
--FROM SFDC.PUBLIC.task A
--JOIN SFDC.PUBLIC.opportunity B
--ON A.WHAT_ID=B.Id
--JOIN SFDC.PUBLIC.user C
--ON B.OWNER_ID=C.Id
--LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = B.CURRENCY_ISO_CODE 
--	AND B.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
--WHERE A.Traffic_Source__c != '' AND B.CREATED_DATE >= A.CREATED_DATE AND B.CLOSE_DATE >= '2016-01-01';


INSERT IGNORE INTO MAIN.RPT.MQLENRICHMENT(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, contactMapping,
OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 1,
D.Id, D.Name, D.CREATED_DATE, D.STAGE_NAME, (D.ARR_Variance__c/hce.EXCHANGE_RATE), (D.Commissionable_ACV__c/hce.EXCHANGE_RATE), 
D.OWNER_ID, CONCAT(E.FIRST_NAME,' ',E.LAST_NAME), D.CLOSE_DATE
FROM SFDC.PUBLIC.task A
JOIN SFDC.PUBLIC.contact B 
ON A.WHO_ID=B.Id
JOIN SFDC.PUBLIC.opportunity_contact_role C
ON B.Id=C.ContactId
JOIN SFDC.PUBLIC.opportunity D
ON C.OpportunityID=D.Id
JOIN SFDC.PUBLIC.user E
ON D.OWNER_ID=E.Id
LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = D.CURRENCY_ISO_CODE 
	AND D.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND D.CREATED_DATE >= A.CREATED_DATE AND D.CREATED_DATE < DATE_ADD(A.CREATED_DATE, INTERVAL 60 DAY) AND D.Amount > 0 AND D.CLOSE_DATE >= '2016-01-01';

INSERT IGNORE INTO MAIN.RPT.MQLENRICHMENT(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, accountMapping,
OPPORTUNITY_ID, OPPORTUNITY_NAME, OPPORTUNITY_CREATED_DATE, OPPORTUNITY_STAGE, OPPORTUNITY_ARR, OPPORTUNITY_COMMISH_ARR, OPPORTUNITY_OWNER_ID, OPPORTUNITY_OWNER, OPPORTUNITY_CLOSE_DATE)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 1,
C.Id, C.Name, C.CREATED_DATE, C.STAGE_NAME, (C.ARR_Variance__c/hce.EXCHANGE_RATE), (C.Commissionable_ACV__c/hce.EXCHANGE_RATE), 
C.OWNER_ID, CONCAT(D.FIRST_NAME,' ',D.LAST_NAME), C.CLOSE_DATE
FROM SFDC.PUBLIC.task A
JOIN SFDC.PUBLIC.contact B 
ON A.WHO_ID=B.Id
JOIN SFDC.PUBLIC.opportunity C
ON B.AccountId=C.AccountId
JOIN SFDC.PUBLIC.user D
ON C.OWNER_ID=D.Id
LEFT JOIN MAIN.HIST.CURRENCY_EXCHANGE hce ON hce.CURRENCY_CODE = C.CURRENCY_ISO_CODE 
	AND C.CLOSE_DATE BETWEEN hce.MODIFY_DATE_TIME AND hce.HIST_EFFECTIVE_THRU_DATE_TIME
WHERE A.Traffic_Source__c != '' AND C.CREATED_DATE >= A.CREATED_DATE AND C.CREATED_DATE < DATE_ADD(A.CREATED_DATE, INTERVAL 60 DAY) AND C.Amount > 0 AND C.CLOSE_DATE >= '2016-01-01';

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'\r','');

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'\n','');

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.contact B
on A.TASK_WHO_ID=B.Id
join SFDC.PUBLIC.opportunity_contact_role C
on B.Id=C.ContactId
join SFDC.PUBLIC.opportunity D
on C.OpportunityID=D.Id
join SFDC.PUBLIC.user E
on D.OWNER_ID=E.Id
set A.contactMapping=1
where D.CREATED_DATE >= date(A.TASK_CREATED_DATE) and D.CREATED_DATE < date_add(A.TASK_CREATED_DATE, interval 60 day) and A.OPPORTUNITY_ID=D.Id and A.DIRECT_MAPPING=1;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.contact B
on A.TASK_WHO_ID=B.Id
join SFDC.PUBLIC.opportunity C
on B.AccountId=C.AccountId
join SFDC.PUBLIC.user D
on C.OWNER_ID=D.Id
set A.accountMapping=1
where C.CREATED_DATE >= A.TASK_CREATED_DATE and C.CREATED_DATE < date_add(A.TASK_CREATED_DATE, interval 60 day) and A.OPPORTUNITY_ID=C.Id and (A.DIRECT_MAPPING=1 or A.contactMapping=1);

update MAIN.RPT.MQLENRICHMENT
set mappingType=
case when DIRECT_MAPPING=1 and contactMapping is null and accountMapping is null then 'Direct Only'
when DIRECT_MAPPING=1 and contactMapping=1 and accountMapping is null then 'Direct and Contact'
when DIRECT_MAPPING=1 and contactMapping is null and accountMapping=1 then 'Direct and Account'
when DIRECT_MAPPING=1 and contactMapping=1 and accountMapping=1 then 'Direct and Contact and Account'
when DIRECT_MAPPING is null and contactMapping=1 and accountMapping is null then 'Contact Only'
when DIRECT_MAPPING is null and contactMapping=1 and accountMapping=1 then 'Contact and Account'
when DIRECT_MAPPING is null and contactMapping is null and accountMapping=1 then 'Account Only'
end;

-- section to get if taskWhoDomain is ISP and switch mapping type to 'No Mapping' when current mapping type is 'Account Only'
update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.lead B
on A.TASK_WHO_ID=B.Id
left join SFDC.PUBLIC.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join SFDC.PUBLIC.account D
on C.Account__c=D.Id
set A.taskWhoName=concat(B.FIRST_NAME,' ',B.LAST_NAME), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoDomain=B.Domain__c, A.taskWhoAccountID=D.Id, A.taskWhoAccountName=D.Name, A.taskWhoType='Lead'
where A.taskWhoName is null;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.contact B
on A.TASK_WHO_ID=B.Id
left join SFDC.PUBLIC.account C
on B.AccountId=C.Id
set A.taskWhoName=concat(B.FIRST_NAME,' ',B.LAST_NAME), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name, A.taskWhoType='Contact'
where A.taskWhoName is null;

update MAIN.RPT.MQLENRICHMENT A
join rpt_main_02.userAccount B
on A.taskWhoEmailAddress=B.emailAddress
set A.taskWhoUserID=B.userID;

update MAIN.RPT.MQLENRICHMENT A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set A.taskWhoDomain=B.domain
where taskWhoDomain is null;

update MAIN.RPT.MQLENRICHMENT
set taskWhoDomain=(SUBSTR(taskWhoEmailAddress, POSITION(taskWhoEmailAddress, '@') + 1))
where taskWhoDomain is null;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.ARC.ISPDomains B
on A.taskWhoDomain=B.domain
set A.taskWhoDomainISP=1;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.domain B
on A.taskWhoDomain=B.Domain_Name_URL__c
join SFDC.PUBLIC.account C
on B.Account__c=C.Id 
set A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name
where A.taskWhoAccountID is null;

delete from MAIN.RPT.MQLENRICHMENT
where taskWhoDomainISP=1 and mappingType='Account Only';

delete from MAIN.RPT.MQLENRICHMENT
where taskWhoAccountName like '%ISP Account%' and mappingType='Account Only';

delete from MAIN.RPT.MQLENRICHMENT
where taskWhoAccountID='0014000000mw0ZMAAY';

-- insert for tasks that do not map to any opportunities
drop table if exists MAIN.RPT.MQLENRICHMENTStaging2;
create table if not exists MAIN.RPT.MQLENRICHMENTStaging2
(TASK_ID varchar(50),
primary key (TASK_ID));

insert ignore into MAIN.RPT.MQLENRICHMENTStaging2
select TASK_ID from MAIN.RPT.MQLENRICHMENT;

INSERT IGNORE INTO MAIN.RPT.MQLENRICHMENT(TASK_ID, TASK_TRAFFIC_SOURCE, TASK_SOURCE, TASK_SUB_SOURCE, TASK_CREATED_DATE, TASK_SUBJECT, TASK_OWNER_ID, TASK_WHO_ID, TASK_TTTC, TASK_STATUS, mappingType)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (POSITION(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CREATED_DATE, A.SUBJECT, A.OWNER_ID, A.WHO_ID, A.Time_To_Task_Completion__c, A.Status, 'No Mapping'
FROM SFDC.PUBLIC.task A
LEFT JOIN MAIN.RPT.MQLENRICHMENTStaging2 B
on A.Id=B.TASK_ID
WHERE A.Traffic_Source__c != '' AND B.TASK_ID IS NULL;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.lead B
on A.TASK_WHO_ID=B.Id
left join SFDC.PUBLIC.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join SFDC.PUBLIC.account D
on C.Account__c=D.Id
set A.taskWhoName=concat(B.FIRST_NAME,' ',B.LAST_NAME), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoDomain=B.Domain__c, A.taskWhoAccountID=D.Id, A.taskWhoAccountName=D.Name, A.taskWhoType='Lead'
where A.taskWhoName is null;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.contact B
on A.TASK_WHO_ID=B.Id
left join SFDC.PUBLIC.account C
on B.AccountId=C.Id
set A.taskWhoName=concat(B.FIRST_NAME,' ',B.LAST_NAME), A.taskWhoEmailAddress=B.Email, A.taskWhoTitle=B.Title, A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name, A.taskWhoType='Contact'
where A.taskWhoName is null;

update MAIN.RPT.MQLENRICHMENT A
join rpt_main_02.userAccount B
on A.taskWhoEmailAddress=B.emailAddress
set A.taskWhoUserID=B.userID
where A.taskWhoUserID is null;

update MAIN.RPT.MQLENRICHMENT A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set A.taskWhoDomain=B.domain
where taskWhoDomain is null;

update MAIN.RPT.MQLENRICHMENT
set taskWhoDomain=(SUBSTR(taskWhoEmailAddress, POSITION(taskWhoEmailAddress, '@') + 1))
where taskWhoDomain is null;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.ARC.ISPDomains B
on A.taskWhoDomain=B.domain
set A.taskWhoDomainISP=1
where A.taskWhoDomainISP is null;

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.domain B
on A.taskWhoDomain=B.Domain_Name_URL__c
join SFDC.PUBLIC.account C
on B.Account__c=C.Id 
set A.taskWhoAccountID=C.Id, A.taskWhoAccountName=C.Name
where A.taskWhoAccountID is null;

update MAIN.RPT.MQLENRICHMENT 
set taskWhoAccountID=null, taskWhoAccountName=null
where taskWhoAccountID='' or taskWhoDomainISP=1;

update MAIN.RPT.MQLENRICHMENT A
set A.TASK_SOURCE = 'None'
where A.TASK_SOURCE is null or A.TASK_SOURCE = '';

update MAIN.RPT.MQLENRICHMENT A
set A.TASK_SUB_SOURCE = 'None'
where A.TASK_SUB_SOURCE is null or A.TASK_SUB_SOURCE = '';

update MAIN.RPT.MQLENRICHMENT
set TASK_SOURCE=TASK_SUB_SOURCE, TASK_SUB_SOURCE='None'
where TASK_SOURCE='None';

update MAIN.RPT.MQLENRICHMENT
set opportunityDateDiff=datediff(OPPORTUNITY_CREATED_DATE, TASK_CREATED_DATE);

update MAIN.RPT.MQLENRICHMENT
set opportunityClosedWonID=OPPORTUNITY_ID
where OPPORTUNITY_STAGE='Closed Won';

update MAIN.RPT.MQLENRICHMENT
set opportunityCycleTime=datediff(OPPORTUNITY_CLOSE_DATE, TASK_CREATED_DATE)
where opportunityClosedWonID is not null;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.REF.Oct2016fortune1000 B
on A.taskWhoDomain=B.domain
set taskWhoDomainIsFortune1000=1;

drop table if exists MAIN.RPT.MQLENRICHMENTStaging3;
create table if not exists MAIN.RPT.MQLENRICHMENTStaging3
select domain, min(winDate) as winDate from rpt_workspace.cDunn_allPlansPurchased 
group by 1;

alter table MAIN.RPT.MQLENRICHMENTStaging3
add ,
add ;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.RPT.MQLENRICHMENTStaging3 B force 
on A.taskWhoDomain=B.domain and A.TASK_CREATED_DATE >= B.winDate
set A.taskWhoDomainIsExistingCustomer=1;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.HIST.paymentProfile B
on A.taskWhoUserID=B.OWNER_ID and B.accountType!=3 and B.MODIFY_DATE_TIME <= A.TASK_CREATED_DATE and B.HIST_EFFECTIVE_THRU_DATE_TIME > A.TASK_CREATED_DATE
set A.taskWhoProductNameAtCreation=rpt_main_02.SMARTSHEET_PRODUCTNAME(B.productID);

update MAIN.RPT.MQLENRICHMENT
set taskWhoProductNameAtCreation='Free / Cancelled'
where taskWhoProductNameAtCreation in ('Free','Cancelled');

update MAIN.RPT.MQLENRICHMENT A
join rpt_main_02.userAccount B
on A.taskWhoUserID=B.userID
set taskWhoProductNameAtCreation='Collab'
where A.TASK_CREATED_DATE > B.insertDateTime and A.taskWhoProductNameAtCreation is null;

UPDATE MAIN.RPT.MQLENRICHMENT A
JOIN SFDC.PUBLIC.user B 
ON A.TASK_OWNER_ID=B.Id
JOIN SFDC.PUBLIC.user_role C 
ON B.userRoleID=C.Id
SET A.taskOwner = CONCAT(B.FIRST_NAME,' ',B.LAST_NAME), A.taskOwnerRole = C.Name;

update MAIN.RPT.MQLENRICHMENT A
set taskWhoFollowUpActivityCount=
(select count(distinct B.Id) from SFDC.PUBLIC.task B
join SFDC.PUBLIC.lead C
on B.WHO_ID=C.Id 
where A.taskWhoEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.TASK_CREATED_DATE, interval 30 day) and B.LastModifiedDate > A.TASK_CREATED_DATE)
where taskWhoType='Lead';

update MAIN.RPT.MQLENRICHMENT A
set taskWhoFollowUpActivityCount=
(select count(distinct B.Id) from SFDC.PUBLIC.task B
join SFDC.PUBLIC.contact C
on B.WHO_ID=C.Id 
where A.taskWhoEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.TASK_CREATED_DATE, interval 30 day) and B.LastModifiedDate > A.TASK_CREATED_DATE)
where taskWhoType='Contact';

update MAIN.RPT.MQLENRICHMENT A
join SFDC.PUBLIC.opportunity B
on A.opportunityId=B.Id 
set A.opportunitySecurityPack=B.Security_Pack__c, A.opportunityIntegrationPack=B.Integration_Pack__c, A.opportunitySights=B.Dashboards__c, 
A.opportunitySalesforce=B.Salesforce_Integration__c, A.opportunitySCC=B.Project_Control_Center__c, A.opportunityJira=B.Jira_Integration__c;

update MAIN.RPT.MQLENRICHMENT A
join MAIN.STG.tableauTrialReport B
on A.taskWhoUserID=B.userID
set A.taskWhoStrongLead=B.IsStrongLead;

update MAIN.RPT.MQLENRICHMENT A
join rpt_workspace.pj_domainDataCoverage B
on A.taskWhoDomain=B.domain
set A.taskWhoCompanySize=B.companySize;

drop table if exists MAIN.RPT.MQLENRICHMENTCopy;
create table if not exists MAIN.RPT.MQLENRICHMENTCopy like MAIN.RPT.MQLENRICHMENT;
insert into MAIN.RPT.MQLENRICHMENTCopy select * from MAIN.RPT.MQLENRICHMENT;

alter table MAIN.RPT.MQLENRICHMENTCopy
add ,
add ,
add ;

update MAIN.RPT.MQLENRICHMENT A
join (select TASK_ID, count(*) as taskCount from MAIN.RPT.MQLENRICHMENTCopy
group by 1) B
on A.TASK_ID=B.TASK_ID
set A.taskCount=B.taskCount;

update MAIN.RPT.MQLENRICHMENT
set TASK_TTTCCalc=TASK_TTTC/taskCount;

update MAIN.RPT.MQLENRICHMENT
set taskWhoFollowUpActivityCountCalc=taskWhoFollowUpActivityCount/taskCount;

update MAIN.RPT.MQLENRICHMENT A
join (select OPPORTUNITY_ID, count(*) as oppCount from MAIN.RPT.MQLENRICHMENTCopy
where OPPORTUNITY_ID!=''
group by 1) B
on A.OPPORTUNITY_ID=B.OPPORTUNITY_ID
set A.opportunityCount=B.oppCount
where A.OPPORTUNITY_ID!='';

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_ARRCalc=OPPORTUNITY_ARR/opportunityCount;

update MAIN.RPT.MQLENRICHMENT
set taskBucket=
case when TASK_TRAFFIC_SOURCE like 'Support Case%' then 'Support'
when TASK_TRAFFIC_SOURCE like 'Inbound Email%' then 'Email'
when TASK_TRAFFIC_SOURCE like 'G2 Crowd%' or TASK_TRAFFIC_SOURCE like 'Software Advice%' or TASK_TRAFFIC_SOURCE like 'IT Central Station%' or TASK_TRAFFIC_SOURCE like 'Technology Advice%' then 'Purchased Leads'
when TASK_TRAFFIC_SOURCE like 'Trial with%' or TASK_TRAFFIC_SOURCE like 'Post Trial Survey%' then 'Trial Flow'
when TASK_TRAFFIC_SOURCE like 'Trigger%' then 'Triggers'
when TASK_TRAFFIC_SOURCE like 'E-book%' or TASK_TRAFFIC_SOURCE like 'Forrester Wave Report%' then 'E-Books & Whitepapers'
when TASK_TRAFFIC_SOURCE like 'Webinar%' then 'Webinar'
when TASK_TRAFFIC_SOURCE like 'Chat%' then 'Chat'
when TASK_TRAFFIC_SOURCE like 'Direct Mail%' or TASK_TRAFFIC_SOURCE like 'Prospecting%' then 'Outbound Campaigns'
-- 'contains' matches after all the 'starts with' matches
when TASK_TRAFFIC_SOURCE like '%Contact Us%' or TASK_TRAFFIC_SOURCE like 'Enterprise Pricing%' or TASK_TRAFFIC_SOURCE like 'Enterprise Work Management Page%' or TASK_TRAFFIC_SOURCE like 'Sights Trial Request%' then 'Contact Us Forms'
when TASK_TRAFFIC_SOURCE like '%Partner%' or TASK_TRAFFIC_SOURCE like '%Reseller%' or TASK_TRAFFIC_SOURCE like '%Channel%' then 'Partner'
Else 'Unbucketed'
END;

UPDATE MAIN.RPT.MQLENRICHMENT A
LEFT JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.taskWhoDomain = B.domain AND DATE_FORMAT(A.TASK_CREATED_DATE, '%Y-%m-01 00:00:00') = B.startMonth
SET A.taskWhoDomainNewLogo = CASE WHEN A.taskWhoDomainISP=1 THEN 0
WHEN B.domain IS NULL THEN 1 ELSE 0 END;

update MAIN.RPT.MQLENRICHMENT A
join (select TASK_WHO_ID, count(*) as taskWhoCount from MAIN.RPT.MQLENRICHMENTCopy
where TASK_WHO_ID!=''
group by 1) B
on A.TASK_WHO_ID=B.TASK_WHO_ID
set A.taskWhoCount=B.taskWhoCount
where A.TASK_WHO_ID!='';

update MAIN.RPT.MQLENRICHMENT
set TASK_WHO_IDProrated=1/taskWhoCount;

update MAIN.RPT.MQLENRICHMENT
set opportunitySecurityPack='false'
where OPPORTUNITY_ID!='' and opportunitySecurityPack is null;

update MAIN.RPT.MQLENRICHMENT
set opportunityIntegrationPack='false'
where OPPORTUNITY_ID!='' and opportunityIntegrationPack is null;

update MAIN.RPT.MQLENRICHMENT
set opportunitySights='false'
where OPPORTUNITY_ID!='' and opportunitySights is null;

update MAIN.RPT.MQLENRICHMENT
set opportunitySalesforce='false'
where OPPORTUNITY_ID!='' and opportunitySalesforce is null;

update MAIN.RPT.MQLENRICHMENT
set opportunitySCC='false'
where OPPORTUNITY_ID!='' and opportunitySCC is null;

update MAIN.RPT.MQLENRICHMENT
set opportunityJira='false'
where OPPORTUNITY_ID!='' and opportunityJira is null;

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_ID2=OPPORTUNITY_ID, OPPORTUNITY_STAGE2=OPPORTUNITY_STAGE, OPPORTUNITY_ARR2=OPPORTUNITY_ARR, opportunityDateDiff2=opportunityDateDiff, 
opportunityCycleTime2=opportunityCycleTime
where DIRECT_MAPPING=1 or contactMapping=1;

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_ID3=OPPORTUNITY_ID, OPPORTUNITY_STAGE3=OPPORTUNITY_STAGE, OPPORTUNITY_ARR3=OPPORTUNITY_ARR, opportunityDateDiff3=opportunityDateDiff, 
opportunityCycleTime3=opportunityCycleTime
where DIRECT_MAPPING=1;

drop table if exists MAIN.RPT.MQLENRICHMENTCopy;
create table if not exists MAIN.RPT.MQLENRICHMENTCopy like MAIN.RPT.MQLENRICHMENT;
insert into MAIN.RPT.MQLENRICHMENTCopy select * from MAIN.RPT.MQLENRICHMENT;

alter table MAIN.RPT.MQLENRICHMENTCopy
add ,
add ;

update MAIN.RPT.MQLENRICHMENT A
join (select OPPORTUNITY_ID2, count(*) as oppCount from MAIN.RPT.MQLENRICHMENTCopy
where OPPORTUNITY_ID2 is not null
group by 1) B
on A.OPPORTUNITY_ID2=B.OPPORTUNITY_ID2
set A.opportunityCount2=B.oppCount
where A.OPPORTUNITY_ID2 is not null;

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_ARRCalc2=OPPORTUNITY_ARR2/opportunityCount2;

update MAIN.RPT.MQLENRICHMENT A
join (select OPPORTUNITY_ID3, count(*) as oppCount from MAIN.RPT.MQLENRICHMENTCopy
where OPPORTUNITY_ID3 is not null
group by 1) B
on A.OPPORTUNITY_ID3=B.OPPORTUNITY_ID3
set A.opportunityCount3=B.oppCount
where A.OPPORTUNITY_ID3 is not null;

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_ARRCalc3=OPPORTUNITY_ARR3/opportunityCount3;

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_IDProrated=1/opportunityCount, OPPORTUNITY_IDProrated2=1/opportunityCount2, OPPORTUNITY_IDProrated3=1/opportunityCount3;

update MAIN.RPT.MQLENRICHMENT
set taskWhoName=replace(taskWhoName,'"','');

update MAIN.RPT.MQLENRICHMENT
set TASK_SUBJECT=replace(TASK_SUBJECT,'"','');

update MAIN.RPT.MQLENRICHMENT
set taskWhoTitle=replace(taskWhoTitle,'"','');

update MAIN.RPT.MQLENRICHMENT
set OPPORTUNITY_NAME=replace(OPPORTUNITY_NAME,'"','');

alter table MAIN.RPT.MQLENRICHMENT
add taskWhoUserIDFirstIPCity varchar(50),
add taskWhoUserIDFirstIPRegion varchar(50),
add taskWhoUserIDFirstIPCountry varchar(50);

update MAIN.RPT.MQLENRICHMENT A
join MAIN.RPT.userIPLocation B
on A.taskWhoUserID=B.userID
set A.taskWhoUserIDFirstIPCity=B.ipCity, A.taskWhoUserIDFirstIPRegion=B.ipRegion, A.taskWhoUserIDFirstIPCountry=B.ipCountry;

select * from MAIN.RPT.MQLENRICHMENT
where TASK_SOURCE!='Test';

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY T SET T.TIME_ELAPSED = S.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MQLReportV2.sql')) S WHERE S.BUILD_NUMBER = T.BUILD_NUMBER AND S.PREP_SEQUENCE = T.PREP_SEQUENCE;

