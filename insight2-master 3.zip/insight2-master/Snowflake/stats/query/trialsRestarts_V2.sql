set session transaction isolation level read uncommitted;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("trialsRestarts_V2.csv");


/*Generating trialsRestarts_V2.csv*/
SELECT rpt_trials.paymentProfileID,
	rpt_paymentProfile.accountType,
	u.locale,
	DATE_FORMAT(rpt_trials.trialDateTime, '%Y') AS 'TrialStartYear',
	DATE_FORMAT(rpt_trials.trialDateTime, '%Y-%m-%d') AS 'Trial Start Date',
	DATE_FORMAT(rpt_trials.trialDateTime, '%Y*%m(%b)') AS 'Trial Start Month',	
	rpt_main_02.SMARTSHEET_WEEK(rpt_trials.trialDateTime) AS 'Trial Start Week',

	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket
	END AS 'Bucket',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',
	
	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END AS 'Signup SubSource Friendly',

	rpt_signupSource.segment,
	
	MAX(rpt_paymentProfile.countAsPaid) AS 'Count as Paid',
	
	MAX(rpt_paymentProfile.hasPaid) AS 'hasPaid',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN 0  
		ELSE 1 END AS 'User Signed Up',
	
	CASE rpt_trials.restartFirstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Restart Strong Lead',
	
rpt_userIPLocation.ipCountry AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

CASE WHEN rpt_trials.trialDateTime < '2014-06-01 00:00:00' THEN ref_weightedStrongLeadFactor.weightedStrongLeadFactor
ELSE wslf.weightedStrongLeadFactor END AS "Weighted Strong Lead Factor",

u.languageFriendly,
CASE 
	WHEN rpt_signupSource.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSource.slp = '' THEN NULL ELSE rpt_signupSource.slp END)
	ELSE rpt_signupSource.campaign
END AS campaign,
CASE WHEN rpt_signupSource.appLaunchType IN (2,12,5) THEN rpt_signupSource.appLaunchParm1Friendly ELSE NULL END AS DistributedContainer,
rpt_trials.userID,
lct.loginCount,
rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID) AS "firstWinProduct",
(fwp.planRate_USD/fwp.paymentTerm) AS "MRR",
MAX(rpt_paymentProfile.daysToBuy) AS 'daysToBuy',
rpt_trials.trialType,
fwp.winDate,
fwp.paymentTerm,
CASE WHEN team.userID IS NOT NULL THEN 1 ELSE 0 END AS "hadTeamTrial",
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialDateTime) <= 30 THEN 1 ELSE 0 END AS "isFirst30DayWin",
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialDateTime) <= 60 THEN 1 ELSE 0 END AS "isFirst60DayWin",
rpt_paymentProfile.productName AS 'currentProduct',
rpt_trials.trialEndDateTime,
u.domain,
CASE WHEN isp.domain IS NULL THEN 'Org Domain' ELSE 'ISP Domain' END AS 'Org vs ISP',
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialEndDateTime) <= 10 THEN 1 ELSE 0 END AS "paidWithin10Days",
rpt_signupSource.signupInsertDateTime AS "SignupDate",
rpt_trials.trialDateTime,
CASE WHEN fwp.winDate >= rpt_trials.trialDateTime THEN 1 ELSE 0 END AS 'adjustedHasPaid'


FROM rpt_main_02.rpt_trials rpt_trials
JOIN rpt_main_02.userAccount u ON rpt_trials.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON rpt_paymentProfile.sourceUserID = rpt_trials.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource  ON u.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = u.userID
LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON rpt_userIPLocation.ipCountry = ref_weightedStrongLeadFactor.IPCountry
LEFT OUTER JOIN rpt_main_02.arc_cDunn_wslfOverTimeUpdate wslf 	ON wslf.IPCountry = rpt_userIPLocation.ipCountry
	AND rpt_trials.trialDateTime BETWEEN wslf.trialMonthStartDate AND wslf.trialMonthEndDate
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = u.userID
LEFT OUTER JOIN rpt_main_02.arc_paymentProfile_firstWinProduct fwp ON fwp.sourceUserID = u.userID
	AND fwp.winDate >= rpt_trials.trialDateTime
LEFT OUTER JOIN rpt_main_02.rpt_trials team ON team.userID = u.userID 
	AND team.trialType = 3 AND team.firstTrial = 1
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = u.domain

WHERE rpt_trials.firstTrial = 0 AND rpt_trials.trialType = 1

GROUP BY rpt_trials.userID, rpt_trials.trialDateTime
ORDER BY rpt_trials.trialDateTime DESC
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("trialsRestarts_V2.csv");

