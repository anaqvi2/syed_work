SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard14V2.sql");

select accountName, accountID, csRep, maxProductName, Plans as numberOfPlans, lastContactDateByCSRep, contactedWithinQuarter, useCaseExists, accountHealth, ACV as ARR, 
userLimit as purchasedLicenses, licensesAssigned as assignedLicenses, licensedUsers as acceptedLicenses, employeeCount, openOpportunities, totalCollabs, sightsUsersEnabled, segment, territory, country, state, city, 
usageDashboardLink, salesRep, controlGroup, engagedInDrip, Reports, Sharing, Attachments, Discussions, UpdateRequests, Mobile, RowHierarchy, ConditionalFormat, Gantt, ViewHistory, Alerts, LoggedIn, Sheets, Imports, 
Last90DayActive, updatedThroughDate, healthScore, useCaseThisQuarter
from rpt_main_02.rpt_csReport;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard14V2.sql");

