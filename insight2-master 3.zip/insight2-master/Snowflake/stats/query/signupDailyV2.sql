
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("signupDailyV2.csv");

SET @@sql_mode = '';



SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
/*Generating signupDailyV2.sql*/
SELECT
	userAccount.emailAddress AS 'E-mail Address', 

	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	rpt_main_02.SMARTSHEET_WEEK(rpt_signupSource.signupInsertDateTime) AS 'Signup Week',
	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%Y*%m*%d') AS 'SignupDay', 

	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"					
		ELSE rpt_signupSource.bucket
	END AS 'Bucket',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSource.segment 			  AS 'Signup Segment',
	rpt_signupSource.mySmartsheetReferralLinkFriendly AS 'Signup My Smartsheet Referral Link Friendly',

	CASE rpt_loginCountTotal.loginCount > 0 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In',
	
	rpt_signupSource.referrer 		AS 'Signup Referrer',
	rpt_signupSource.queryValue		AS 'Signup QueryItem',

	SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS Domain,
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',

	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',
	
	userAccount.locale,
	
	userAccount.languageFriendly,
	
	ip.ipCountry,
	
	userAccount.userID,
	
	rpt_signupSource.signupInsertDateTime,
	
	rpt_signupSource.campaign,
	
	rpt_signupSource.slp,
	
	rpt_signupSource.lang


FROM rpt_main_02.rpt_signupSource
JOIN rpt_main_02.userAccount userAccount 										ON rpt_signupSource.userID 	= userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal rpt_loginCountTotal 			ON rpt_signupSource.userID 	= rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser rpt_featureCountFromLogsRollupByUser 	ON rpt_signupSource.userID 	= rpt_featureCountFromLogsRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile FORCE INDEX (idx_rpt_paymentProfileSourceUserID)  ON rpt_paymentProfile.sourceUserID =userAccount.userID AND rpt_paymentProfile.countAsPaid = 1 /* there might be more than one, so only join to the paid one */
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY) ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = userAccount.userID
WHERE rpt_signupSource.signupInsertDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -180 DAY)
AND userAccount.domain != 'smartsheet.com'
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("signupDailyV2.csv");

