set session transaction isolation level read uncommitted;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("userPPC_detailed_English_Search_V2.csv");

/*Generating userPPC_detailed_V2.csv*/
SELECT
	userAccount.emailAddress AS 'E-mail Address', 

	/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	       
	CONCAT(DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTimePT, '%Y'), "*", 
	       LPAD(MONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0"), "*", 
	       LPAD(DAYOFMONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0")) AS 'Signup Day PT', 

	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment',
	rpt_signupSourceUser.dev					AS 'Signup Device',
	rpt_signupSourceUser.devm					AS 'Singup Device Model',
	
	DATE_FORMAT(MIN(rpt_paymentProfile.paymentInsertDate), '%Y*%m(%b)') AS 'Payment Insert Month', 
	
	CASE MAX(rpt_paymentProfile.countAsPaid) IS NULL
		WHEN 1 THEN 0
		ELSE MAX(rpt_paymentProfile.countAsPaid)
	END AS 'Count as Paid',
	
	CASE MAX(rpt_paymentProfile.countAsPaid) IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE MAX(rpt_paymentProfile.countAsPaid) = 0
				WHEN 1 THEN NULL
				ELSE MAX(rpt_paymentProfile.planRate_USD) / MAX(rpt_paymentProfile.paymentTerm)
			END
	END AS 'Monthly Revenue',
	
	/* quote to prevent odd characters causing problems in Excel and so Excel won't try to interpret keywords that start with + as a formula */
	QUOTE(rpt_signupSourceUser.keyword) 		AS 'Signup Keyword',

	rpt_signupSourceUser.adVersion AS 'Ad Version',

	rpt_signupSourceUser.landingPageVersion AS landingPageVersion,
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Lifetime Log Count >= 400',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
	
	CASE MIN(rpt_paymentProfile.paymentStartDateRaw) IS NOT NULL AND DATEDIFF(CURRENT_DATE(), MIN(rpt_paymentProfile.paymentStartDateRaw)) <= 35
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is In 35 Day Window',
	
	/* showed moderate use of area								+ showed heavy use of area  */
	 (ROUND(COALESCE(LEAST(rpt_loginCountTotal.loginCount, .5), 0) 				+ COALESCE(LEAST(rpt_loginCountTotal.loginCount / 8, .5), 0) +
	 COALESCE(LEAST(rpt_clientLogCountsByUserArchived.lifetimeLogCount / 200, .5), 0) 	+ COALESCE(LEAST(rpt_clientLogCountsByUserArchived.lifetimeLogCount / 2000, .5), 0) + 
	 COALESCE(LEAST(rpt_containerCountsByUser.sheetCount , .5), 0) 				+ COALESCE(LEAST(rpt_containerCountsByUser.sheetCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_containerCountsByUser.reportCount, .5), 0) 				+ COALESCE(LEAST(rpt_containerCountsByUser.reportCount / 10, .5), 0) + 
	 COALESCE(LEAST(rpt_containerCountsByUser.workspaceCount, .5), 0) 			+ COALESCE(LEAST(rpt_containerCountsByUser.workspaceCount / 10, .5), 0) + 
	 COALESCE(LEAST(rpt_featureCountRollupByUser.sharingCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.sharingCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.reminderCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.reminderCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.attachmentCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.attachmentCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountRollupByUser.discussionCount, .5), 0) 			+ COALESCE(LEAST(rpt_featureCountRollupByUser.discussionCount / 20, .5), 0) +
	 COALESCE(LEAST(rpt_featureCountFromLogsRollupByUser.paymentFormViewCount, .5), 0)  	+ COALESCE(LEAST(rpt_featureCountFromLogsRollupByUser.paymentFormViewCount / 4, .5), 0), 1)) 
	AS 'Usage Rating',
	
	rpt_main_02.SMARTSHEET_WEEK(rpt_signupSourceUser.signupInsertDateTime) AS 'Signup Week',
	
	rpt_userIPLocation.ipCountry AS "IP Country",
	rpt_userIPLocation.ipRegion AS "IP Region",
	rpt_userIPLocation.ipCity AS "IP City",
	
	userAccount.languageFriendly,
	rpt_signupSourceUser.matchtype,
	
	rpt_signupRequestTrackingItem.itemValue AS "Experiment Number",
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN ref_weightedStrongLeadFactor.weightedStrongLeadFactor
		ELSE 0
	END AS 'WSL',
	
	rpt_signupSourceUser.webSite,
	rpt_signupSourceUser.webPage,
	rpt_signupSourceUser.placement,
	rpt_signupSourceUser.network,
	rpt_signupSourceUser.slk,
	rpt_signupSourceUser.slp,
	CASE MAX(rpt_paymentProfile.countAsPaid) IS NULL
		WHEN 1 THEN NULL
		ELSE rpt_paymentProfile.productName
	END AS 'ProductName',
	rpt_signupSourceUser.referrer,
	rpt_signupSourceUser.exp

FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.userAccount userAccount2		ON userAccount.insertByUserID = userAccount2.userID
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  		ON userAccount.userID = rpt_paymentProfile.sourceUserID 
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser FORCE INDEX (PRIMARY) ON userAccount.userID = rpt_featureCountRollupByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser   	ON userAccount.userID = rpt_featureCountFromLogsRollupByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 			ON userAccount.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser FORCE INDEX (PRIMARY) 		ON userAccount.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	FORCE INDEX (PRIMARY) ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_domainRollup 			ON rpt_featureCountRollupByUser.domain 	= rpt_domainRollup.domain
  LEFT OUTER JOIN rpt_main_02.rpt_userAncestor 			ON userAccount.emailAddress 	= rpt_userAncestor.userEmailAddress
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceAncestor	ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
  LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem  ON rpt_signupSourceUser.signupRequestID = rpt_signupRequestTrackingItem.signupRequestID AND itemName = "utm_expid" 
  LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = userAccount.userID
  LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON rpt_userIPLocation.ipCountry = ref_weightedStrongLeadFactor.IPCountry


WHERE userAccount.insertDateTime  >= DATE_ADD(CURRENT_DATE(), INTERVAL -400 DAY)
	AND rpt_signupSourceUser.bucket IN ("Paid") AND rpt_signupSourceUser.sourceFriendly NOT IN ("PPC - Foreign Language")
	AND rpt_signupSourceUser.subSourceFriendly IN 
				("_Google Search", 
				"_Bing Search",
				"_Google Search (iPad only)",									
				"Google Adwords Sitelinks",
				"Google Mobile Search (iphone)", 
				"Google Mobile Search (non-iphone)",
 				"Seattle GEO Target (Google Search)",
				"Seattle GEO Target (Bing Search)",
				"Bing Sitelinks",
				"_Google Search - International - Tier 1", 
				"_Google Search - International - Tier 2",
				"Bing Search - International - Tier 1")
GROUP BY 1
LIMIT 1234567890
;







/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("userPPC_detailed_English_Search_V2.csv");




