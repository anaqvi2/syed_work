SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard6V2.sql");

DROP TABLE IF EXISTS rpt_workspace.js_csRetentionCalcRepQTD;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csRetentionCalcRepQTD
(paymentProfileID INT,
accountType VARCHAR(50),
domain VARCHAR(50),
ISP INT,
customer VARCHAR(50),
csRep VARCHAR(50),
csRepID VARCHAR(50),
accountName VARCHAR(50),
accountID VARCHAR(50),
territory VARCHAR(50),
segment VARCHAR(50),
currentACV DEC(10,2),
quarterServicesACVbyRep DEC(10,2),
quarterNewACVbyRep DEC(10,2),
quarterExpansionACVbyRep DEC(10,2),
quarterCancelACVbyRep DEC(10,2),
quarterReductionACVbyRep DEC(10,2),
quarterNewACVbyOther DEC(10,2),
quarterExpansionACVbyOther DEC(10,2),
quarterCancelACVbyOther DEC(10,2),
quarterReductionACVbyOther DEC(10,2),
csRepAtClose VARCHAR(100),
byOtherCSM VARCHAR(100),
beginningOfQuarterOwner VARCHAR(100),
30DaysInOwner VARCHAR(100),
60DaysInOwner VARCHAR(100),
otherCSMInsert TINYINT,
currentACVRetention DECIMAL(10,2),
ownerType INT,
companySize VARCHAR(50),
PRIMARY KEY (paymentProfileID, csRep),
INDEX (domain),
INDEX (ISP),
INDEX (customer),
INDEX (csRepID),
INDEX (accountName),
INDEX (accountID));

INSERT INTO rpt_workspace.js_csRetentionCalcRepQTD(paymentProfileID, accountType, domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV, csRepAtClose, ownerType)
SELECT paymentProfileID, 'Currently Owned', domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV, csRepAtClose, 1 
FROM rpt_workspace.js_csRetentionCalcSegmentQTD;

/* INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcRepQTD(paymentProfileID, accountType, domain, ISP, csRep, territory, segment)
SELECT paymentProfileID, 'Previously Owned', domain, ispDomain, customerSuccess, territory, segment FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE recordDateTime >= '2017-11-01' AND recordDateTime < '2018-02-01' AND currencyChange=0 AND futureLoss IS NULL AND segment IS NOT NULL; */

INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcRepQTD(paymentProfileID, accountType, csRep, territory, segment, ownerType)
SELECT paymentProfileId, 'Previously Owned', csRepAtClose, territoryAtClose, segmentAtClose, 1 FROM rpt_workspace.js_servicesAtClose
WHERE closeWonDate >= '2017-11-01' AND closeWonDate < '2018-02-01';

/* DELETE FROM rpt_workspace.js_csRetentionCalcRepQTD
WHERE csRep='' OR csRep IS NULL; */

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.paymentProfileID=B.paymentProfileID
SET A.domain=B.mainContactDomain
WHERE A.domain IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN rpt_main_02.arc_ISPDomains B
ON A.domain=B.domain
SET ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET ISP=0
WHERE ISP IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN ss_sfdc_02.domain B
ON A.domain=B.Domain_Name_URL__c
JOIN ss_sfdc_02.account C
ON B.Account__c=C.Id
SET A.accountName=B.Name
WHERE A.accountName IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET domain = 'incitecpivot.com.au',
customer = 'Incitec Pivot Limited',
accountId = '0013300001f6HPxAAM',
csRep = 'Andrew Rustemeyer',
territory = 'Unassigned (CDM)',
segment = 'No Territory'
WHERE paymentProfileID = 7598286;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET customer=domain
WHERE ISP=0;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET customer=CONCAT(domain,'-',paymentProfileID)
WHERE ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN ss_sfdc_02.account B
ON A.AccountName=B.Name
SET A.accountID=B.Id;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterNewACVbyRep=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.csRep=B.customerSuccess AND B.domainLevelRecordTypeNew='New' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterExpansionACVbyRep=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.csRep=B.customerSuccess AND B.domainLevelRecordTypeNew='Expansion' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterCancelACVbyRep=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.csRep=B.customerSuccess AND B.domainLevelRecordTypeNew='Cancel' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterReductionACVbyRep=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.csRep=B.customerSuccess AND B.domainLevelRecordTypeNew='Reduction' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterServicesACVbyRep=
(SELECT SUM(ARR) FROM rpt_workspace.js_servicesAtClose B
WHERE A.paymentProfileID=B.paymentProfileID AND A.csRep=B.csRepAtClose AND B.closeWonDate >= '2017-11-01'  AND B.closeWonDate < '2018-02-01');

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterNewACVbyRep=ROUND(quarterNewACVbyRep, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterExpansionACVbyRep=ROUND(quarterExpansionACVbyRep, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterCancelACVbyRep=ROUND(quarterCancelACVbyRep, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterReductionACVbyRep=ROUND(quarterReductionACVbyRep, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterServicesACVbyRep=ROUND(quarterServicesACVbyRep, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterNewACVbyRep=0
WHERE quarterNewACVbyRep IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterExpansionACVbyRep=0
WHERE quarterExpansionACVbyRep IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterCancelACVbyRep=0
WHERE quarterCancelACVbyRep IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterReductionACVbyRep=0
WHERE quarterReductionACVbyRep IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterServicesACVbyRep=0
WHERE quarterServicesACVbyRep IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterNewACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.csRep!=B.customerSuccess OR B.customerSuccess=' ' OR B.customerSuccess IS NULL) AND B.domainLevelRecordTypeNew='New' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterExpansionACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.csRep!=B.customerSuccess OR B.customerSuccess=' ' OR B.customerSuccess IS NULL) AND B.domainLevelRecordTypeNew='Expansion' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterCancelACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.csRep!=B.customerSuccess OR B.customerSuccess=' ' OR B.customerSuccess IS NULL) AND B.domainLevelRecordTypeNew='Cancel' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET quarterReductionACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.csRep!=B.customerSuccess OR B.customerSuccess=' ' OR B.customerSuccess IS NULL) AND B.domainLevelRecordTypeNew='Reduction' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);


UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterNewACVbyOther=ROUND(quarterNewACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterExpansionACVbyOther=ROUND(quarterExpansionACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterCancelACVbyOther=ROUND(quarterCancelACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterReductionACVbyOther=ROUND(quarterReductionACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterNewACVbyOther=0
WHERE quarterNewACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterExpansionACVbyOther=0
WHERE quarterExpansionACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterCancelACVbyOther=0
WHERE quarterCancelACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET quarterReductionACVbyOther=0
WHERE quarterReductionACVbyOther IS NULL;


UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET segment=
CASE WHEN territory LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territory LIKE 'SMB%' THEN 'SMB' 
WHEN territory LIKE 'Major%' THEN 'Major'
WHEN territory LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territory LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territory LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territory LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN (territory LIKE 'Unassigned%' OR territory='Not Enough Information (ISR3)' OR territory='') THEN 'No Territory'
ELSE 'Strategic'
END
WHERE territory IS NOT NULL;


DROP TABLE IF EXISTS rpt_workspace.js_csRetentionCalcRepQTDStaging;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csRetentionCalcRepQTDStaging
(paymentProfileID INT,
currentACV DEC(10,2),
PRIMARY KEY (paymentProfileID));

INSERT INTO rpt_workspace.js_csRetentionCalcRepQTDStaging
SELECT paymentProfileID, currentACV FROM rpt_workspace.js_csRetentionCalcRepQTD
WHERE accountType='Currently Owned';

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN rpt_workspace.js_csRetentionCalcRepQTDStaging B
ON A.paymentProfileID=B.paymentProfileID
SET A.currentACV=B.currentACV
WHERE A.accountType='Previously Owned';

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.paymentProfileID=B.paymentProfileID
SET A.currentACV=(B.planRate_USD/B.paymentTerm)*12
WHERE A.currentACV IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET currentACV=ROUND(currentACV, 0);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET currentACV=0
WHERE currentACV IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET currentACV=0
WHERE accountType='Previously Owned' AND 
quarterServicesACVbyRep!=0 AND quarterNewACVbyRep=0 AND quarterExpansionACVbyRep=0 AND quarterCancelACVbyRep=0 AND quarterReductionACVbyRep=0;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET segment = 'No Territory' WHERE segment IS NULL OR segment = '';

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
LEFT JOIN ss_sfdc_02.opportunity o ON A.paymentProfileID = o.parent_payment_profile_ID__c 
AND o.CloseDate >= '2017-11-01' AND o.CloseDate < '2018-02-01' AND o.StageName IN('Closed Won', 'Closed Lost')
AND ARR_Variance__c != 0
SET A.csRepAtClose = o.Customer_Success_at_Close__c;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
SET byOtherCSM =
(SELECT B.customerSuccess FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.csRep!=B.customerSuccess OR B.customerSuccess=' ' OR B.customerSuccess IS NULL) AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL GROUP BY A.paymentProfileID);

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET byOtherCSM = 'CustomerSuccess@' WHERE byOtherCSM = '';

INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcRepQTD
SELECT paymentProfileID, accountType, domain, ISP, customer, 
byOtherCSM, '', accountName, accountID, territory, segment, 
(currentACV-quarterExpansionACVByRep-quarterNewACVByRep-quarterReductionACVbyRep-quarterCancelACVbyRep), 0, quarterNewACVByOther, quarterExpansionACVbyOther,
quarterCancelACVbyOther, quarterReductionACVByOther, 0,0,0,0,'','',NULL,NULL,NULL,1, NULL, 2, NULL
FROM rpt_workspace.js_csRetentionCalcRepQTD A
WHERE byOtherCSM IS NOT NULL
;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
 JOIN rpt_workspace.cDunn_begQ4 B ON A.paymentProfileID = B.paymentProfileID
 SET A.beginningOfQuarterOwner = B.csRep;
 
  UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
 JOIN rpt_workspace.cDunn_30DaysInQ4 B ON A.paymentProfileID = B.paymentProfileID
 SET A.30DaysInOwner = B.csRep;
 
  UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
 LEFT JOIN rpt_workspace.cDunn_60DaysInQ4 B ON A.paymentProfileID = B.paymentProfileID
 SET A.60DaysInOwner = CASE WHEN DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d') < '2018-01-01' THEN A.csRep ELSE B.csRep END;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET beginningOfQuarterOwner = '' WHERE beginningOfQuarterOwner IS NULL;
UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET 30DaysInOwner = '' WHERE 30DaysInOwner IS NULL;
UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET 60DaysInOwner = '' WHERE 60DaysInOwner IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET beginningOfQuarterOwner = REPLACE(beginningOfQuarterOwner, '\r',''),
30DaysInOwner = REPLACE(30DaysInOwner, '\r',''),
60DaysInOwner = REPLACE(60DaysInOwner, '\r','');

UPDATE rpt_workspace.js_csRetentionCalcRepQTD
SET currentACVRetention = 
CASE WHEN csRep = beginningOfQuarterOwner AND csRep = 30DaysInOwner AND csRep = 60DaysInOwner AND otherCSMInsert IS NULL THEN currentACV
	WHEN csRep = beginningOfQuarterOwner AND otherCSMInsert IS NULL AND (quarterNewACVByRep > 0 OR quarterExpansionACVByRep > 0 OR quarterReductionACVByRep < 0 OR quarterCancelACVByRep < 0) THEN currentACV
	WHEN csRep = beginningOfQuarterOwner  AND otherCSMInsert IS NULL AND quarterExpansionACVByRep = 0 AND quarterReductionACVByRep = 0 AND quarterCancelACVByRep = 0 THEN 0
	WHEN csRep = beginningOfQuarterOwner AND otherCSMInsert = 1 AND 60DaysInOwner = beginningOfQuarterOwner THEN currentACV
	WHEN csRep = beginningOfQuarterOwner AND otherCSMInsert = 1 AND 60DaysInOwner != beginningOfQuarterOwner AND (quarterNewACVByRep > 0 OR quarterExpansionACVByRep > 0 OR quarterReductionACVByRep < 0 OR quarterCancelACVByRep < 0) THEN currentACV
	WHEN csRep = beginningOfQuarterOwner AND otherCSMInsert = 1 AND 60DaysInOwner != beginningOfQuarterOwner AND quarterNewACVByRep = 0 AND quarterExpansionACVByRep = 0 AND quarterReductionACVByRep = 0 AND quarterCancelACVByRep = 0 THEN 0
	WHEN csRep != beginningOfQuarterOwner AND csRep = 30DaysInOwner AND otherCSMInsert IS NULL THEN currentACV
	WHEN csRep != beginningOfQuarterOwner AND csRep != 30DaysInOwner AND (quarterNewACVByRep > 0 OR quarterExpansionACVByRep > 0 OR quarterReductionACVByRep < 0 OR quarterCancelACVByRep < 0) THEN currentACV
	WHEN csRep != beginningOfQuarterOwner AND csRep != 30DaysInOwner AND quarterNewACVByRep = 0 AND quarterExpansionACVByRep = 0 AND quarterReductionACVByRep = 0 AND quarterCancelACVByRep = 0 THEN 0
	END;
	
INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcRepQTD
SELECT paymentProfileID, accountType, domain, ISP, customer, 
CASE WHEN beginningOfQuarterOwner = '' THEN 'CustomerSuccess@' ELSE beginningOfQuarterOwner END, '', accountName, accountId, territory, segment, currentACV, quarterServicesACVbyRep,
quarterNewACVbyRep, quarterExpansionACVbyRep, quarterCancelACVbyRep, quarterReductionACVbyRep, quarterNewACVbyOther , quarterExpansionACVbyOther, 
quarterCancelACVbyOther, quarterReductionACVbyOther, csRepAtClose, byOtherCSM, beginningOfQuarterOwner, 30DaysInOwner, 60DaysInOwner, NULL, 
CASE WHEN beginningOfQuarterOwner = 60DaysInOwner THEN currentACV ELSE 0 END,
3,
NULL
FROM rpt_workspace.js_csRetentionCalcRepQTD
WHERE csRep != beginningOfQuarterOwner AND otherCSMInsert IS NULL AND quarterNewACVbyRep = 0 AND quarterExpansionACVbyRep = 0 AND quarterCancelACVbyRep = 0
	AND quarterReductionACVbyRep = 0 AND quarterNewACVbyOther = 0 AND quarterExpansionACVbyOther = 0 AND quarterCancelACVbyOther = 0 AND quarterReductionACVbyOther = 0;
	
UPDATE rpt_workspace.js_csRetentionCalcRepQTD A
JOIN rpt_workspace.pj_domainDataCoverage ddc ON ddc.domain = A.domain
SET A.companySize = ddc.companySize;

DELETE FROM rpt_workspace.js_csRetentionCalcRepQTD WHERE paymentProfileID = 9781684 AND quarterCancelACVByRep = '-16800.00';

DELETE FROM rpt_workspace.js_csRetentionCalcRepQTD WHERE paymentProfileID = 9694798 AND quarterReductionACVByRep = '-3000.00';
	
DELETE FROM rpt_workspace.js_csRetentionCalcRepQTD
WHERE paymentProfileID = 9810533 AND quarterReductionACVByRep = '-6900.00';

SELECT * FROM rpt_workspace.js_csRetentionCalcRepQTD
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard6V2.sql");



