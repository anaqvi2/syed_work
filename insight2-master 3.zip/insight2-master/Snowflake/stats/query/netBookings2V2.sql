SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("netBookings2V2.sql");

select dayDate, monthYear, recordType, 
netBookingsActualToDate, netBookingsPlanTotal, 
grossBookingsActualToDate, grossBookingsPlanTotal, 
commercialActualToDate, commercialPlanTotal, 
strategicActualToDate, strategicPlanTotal, 
partnerSalesActualToDate, partnerSalesPlanTotal, 
customerSuccessActualToDate, customerSuccessPlanTotal
from rpt_workspace.js_monthlyPerformance2
where dayDate <= DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 0 MONTH)), '%Y-%m-%d');

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("netBookings2V2.sql");

