SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("netBookings1V2.sql");

update rpt_workspace.js_monthlyPerformance2 A
set strategicActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Strategic' and B.recordDate >= DATE_FORMAT(A.dayDate, '%Y-%m-01') and B.recordDate <= A.dayDate)
where dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set strategicActualToDate=0
where strategicActualToDate is null and dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set strategicActualPerBuyingDay=strategicActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set strategicActualTotal=strategicActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_monthlyPerformance2 A
set customerSuccessActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Customer Success' and B.recordDate >= DATE_FORMAT(A.dayDate, '%Y-%m-01') and B.recordDate <= A.dayDate)
where dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set customerSuccessActualToDate=0
where customerSuccessActualToDate is null and dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set customerSuccessActualPerBuyingDay=customerSuccessActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set customerSuccessActualTotal=customerSuccessActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_monthlyPerformance2 A
set partnerSalesActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Partner' and B.recordDate >= DATE_FORMAT(A.dayDate, '%Y-%m-01') and B.recordDate <= A.dayDate)
where dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set partnerSalesActualToDate=0
where partnerSalesActualToDate is null and dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set partnerSalesActualPerBuyingDay=partnerSalesActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set partnerSalesActualTotal=partnerSalesActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_monthlyPerformance2 A
join rpt_workspace.js_monthlyPerformance B
set A.commercialActualToDate=B.commercialActualToDate
where A.dayDate=B.dayDate and A.recordType=B.recordType;

update rpt_workspace.js_monthlyPerformance2
set commercialActualToDate=0
where commercialActualToDate is null and dayDate < current_date;

update rpt_workspace.js_monthlyPerformance2
set commercialActualPerBuyingDay=commercialActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set commercialActualTotal=commercialActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_monthlyPerformance2
set netBookingsActualToDate=commercialActualToDate+strategicActualToDate+customerSuccessActualToDate+partnerSalesActualToDate;

update rpt_workspace.js_monthlyPerformance2
set netBookingsActualPerBuyingDay=netBookingsActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set netBookingsActualTotal=netBookingsActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_monthlyPerformance2
set grossBookingsActualToDate=commercialActualToDate+strategicActualToDate+partnerSalesActualToDate;

update rpt_workspace.js_monthlyPerformance2
set grossBookingsActualPerBuyingDay=grossBookingsActualToDate/buyingDaysToDate;

update rpt_workspace.js_monthlyPerformance2
set grossBookingsActualTotal=grossBookingsActualPerBuyingDay*buyingDaysTotal;


(select * from rpt_workspace.js_monthlyPerformance2
where dayDate in (date_sub(CURRENT_DATE, INTERVAL 1 DAY), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 4 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 5 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 8 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 9 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 10 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 11 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 13 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 14 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 15 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 16 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 17 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'))
and current_date!=date_format(current_date, '%Y-%m-01')
order by recordType, dayDate)

union

(select * from rpt_workspace.js_monthlyPerformance2
where dayDate in (CURRENT_DATE,
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 4 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 5 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 8 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 9 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 10 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 11 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 13 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 14 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 15 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 16 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 17 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'))
and current_date=date_format(current_date, '%Y-%m-01')
order by recordType, dayDate);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("netBookings1V2.sql");

