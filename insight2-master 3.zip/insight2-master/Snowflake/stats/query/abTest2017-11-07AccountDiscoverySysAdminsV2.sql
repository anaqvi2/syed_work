SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2017-11-07AccountDiscoverySysAdminsV2.sql");

select case when config.valueBoolean = 0 then "Disabled" when config.valueBoolean = 1 then "Enabled" End as ConfigValue,
o.organizationID,  
name, 
domainName,
config.insertbyuserID,
config.modifyByUserID,
config.insertDateTime,
config.sessionLogID,
rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productid) as productName,
pp.userLimit,
case when cc.totalCollaborators is not null then cc.totalCollaborators else 0 end as totalCollaborators,
-- ppi.ACV as ARR,
case when d.domain is null then 1 else 0 end as isOrgDomain,
case when domainName like '%.edu%' or domainName like '%.org%' or domainName like '%.ml%' or d.domain is not null or config.sessionLogID = 0 then 1 else 0 end as AutomaticOptOut
from ss_account_02.orgConfigSetting config
join ss_core_02.organization o on o.organizationID = config.organizationID 
left outer join rpt_main_02.arc_ISPDomains d on d.domain COLLATE utf8mb4_unicode_520_ci = o.domainName
left outer join ss_core_02.paymentProfile pp on pp.paymentProfileID = o.paymentProfileID and pp.accountType = 3
left outer join rpt_main_02.rpt_paidPlanCollabCount cc on cc.paymentProfileID = o.paymentProfileID
where configPropertyID = 1332
limit 23123123;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2017-11-07AccountDiscoverySysAdminsV2.sql");