/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ToothbrushCSscatterDailyVersionV2.csv");

select *,date(now()) as runDate From rpt_main_02.rpt_csDomainReport;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ToothbrushCSscatterDailyVersionV2.csv");