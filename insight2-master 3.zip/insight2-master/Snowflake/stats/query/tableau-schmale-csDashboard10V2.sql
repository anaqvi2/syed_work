SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard10V2.sql");

/*
drop table if exists rpt_workspace.js_last30DayAnyActivity;
create table if not exists rpt_workspace.js_last30DayAnyActivity
(userID int,
date date,
primary key (userID, date));

insert ignore into rpt_workspace.js_last30DayAnyActivity
select userID, date from last30DayClientEventDate
where date >= '2017-02-01';

insert ignore into rpt_workspace.js_last30DayAnyActivity
select userID, date from last30DayMobileSessions
where date >= '2017-02-01';
*/

delete from rpt_workspace.js_last30DayAnyActivity
where date < date_sub(current_date, interval 30 day);

delete from rpt_workspace.js_last30DayAnyActivity
where date >= date_sub(current_date, interval 3 day);

select max(date) from rpt_workspace.js_last30DayAnyActivity into @maxDate;

insert ignore into rpt_workspace.js_last30DayAnyActivity
select userID, date from rpt_main_02.last30DayClientEventDate
where date > @maxDate;

insert ignore into rpt_workspace.js_last30DayAnyActivity
select userID, date from rpt_main_02.last30DayMobileSessions
where date > @maxDate;

/*
drop table if exists rpt_workspace.js_toothbrushFirst30Days;
create table if not exists rpt_workspace.js_toothbrushFirst30Days
(userID int,
emailAddress varchar(50),
fullName varchar(50),
title varchar(50),
productID int,
planID int,
mainContactDomain varchar(50),
ISP int,
customer varchar(50),
accountID varchar(100),
accountName varchar(100),
paymentStartDate date,
daysLicensed int,
browserDaysActive int,
nativeAppDaysActive int,
totalDaysActive int,
initialCSRepID varchar(50),
initialCSRep varchar(50),
currentCSRepID varchar(50),
currentCSRep varchar(50),
lastLoginDate date,
contactedPostLicenseDate int,
primary key (userID),
index (emailAddress),
index (planID),
index (productID),
index (mainContactDomain),
index (accountID),
index (paymentStartDate));

alter table rpt_workspace.js_toothbrushFirst30Days
add sfdcContactID varchar(50);

alter table rpt_workspace.js_toothbrushFirst30Days
add productName varchar(50);

update rpt_workspace.js_toothbrushFirst30Days
set initialCSRepID=currentCSRepID;

update rpt_workspace.js_toothbrushFirst30Days
set initialCSRep=currentCSRep;
*/


select max(paymentStartDate) from rpt_workspace.js_toothbrushFirst30Days into @maxDate;

insert ignore into rpt_workspace.js_toothbrushFirst30Days(userID, paymentStartDate)
select ownerID, min(modifyDateTime) as minModifyDateTime from rpt_main_02.hist_paymentProfile
where accountType != 3 and productID > 2
group by 1
having minModifyDateTime >= @maxDate;

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.rpt_paymentProfile B
on A.userID=B.mainContactUserID 
set A.productID=B.productID, A.mainContactDomain=B.mainContactDomain
where B.accountType != 3;

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.rpt_paymentProfile B
on A.userID=B.mainContactUserID 
set A.planID=B.paymentProfileID
where A.productID in (3,4,9) and B.accountType != 3;

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.rpt_paymentProfile B
on A.userID=B.mainContactUserID 
set A.planID=B.parentPaymentProfileID
where A.productID in (6,7,10,11) and B.accountType != 3;

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.userAccount B
on A.userID=B.userID
set A.emailAddress=B.emailAddress, A.fullName=concat(B.firstName,' ',B.lastName);

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_workspace.pj_userDataCoverage B
on A.userID=B.userID
set A.title=B.Title;

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.arc_ISPDomains B
on A.mainContactDomain=B.domain
set A.ISP=1;

update rpt_workspace.js_toothbrushFirst30Days
set customer=mainContactDomain
where ISP is null;

update rpt_workspace.js_toothbrushFirst30Days
set customer=concat(mainContactDomain,'-',planID)
where ISP=1;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.domain B
on A.mainContactDomain=B.Domain_Name_URL__c 
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountID=C.Id, A.accountName=C.Name, A.currentCSRepID=C.Customer_Success__c;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.user B
on A.currentCSRepID=B.Id
set A.currentCSRep=concat(B.firstName,' ',B.lastName);

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.account B
on A.accountID=B.Id
set A.currentCSRep='CustomerSuccess@'
where A.currentCSRep is null and B.Account_to_be_Assigned__c in ('Disqualified', 'Engaged', 'Existing');

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.domain B
on A.mainContactDomain=B.Domain_Name_URL__c 
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.initialCSRepID=C.Customer_Success__c
where A.daysLicensed <= 5;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.user B
on A.initialCSRepID=B.Id
set A.initialCSRep=concat(B.firstName,' ',B.lastName)
where A.initialCSRep is null;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.account B
on A.accountID=B.Id
set A.initialCSRep='CustomerSuccess@'
where A.initialCSRep is null and A.daysLicensed <= 5 and B.Account_to_be_Assigned__c in ('Disqualified', 'Engaged', 'Existing');

update rpt_workspace.js_toothbrushFirst30Days
set daysLicensed=
case when datediff(current_date,paymentStartDate) <= 30 then datediff(current_date,paymentStartDate)
when datediff(current_date,paymentStartDate) > 30 then 30
end;

update rpt_workspace.js_toothbrushFirst30Days A
set browserDaysActive=
(select count(*) from rpt_main_02.last30DayClientEventDate B
where A.userID=B.userID and A.paymentStartDate <= B.date and B.date < date_add(A.paymentStartDate, interval 30 day));

update rpt_workspace.js_toothbrushFirst30Days A
set nativeAppDaysActive=
(select count(*) from rpt_main_02.last30DayMobileSessions B
where A.userID=B.userID and A.paymentStartDate <= B.date and B.date < date_add(A.paymentStartDate, interval 30 day));

update rpt_workspace.js_toothbrushFirst30Days A
set totalDaysActive=
(select count(*) from rpt_workspace.js_last30DayAnyActivity B
where A.userID=B.userID and A.paymentStartDate <= B.date and B.date < date_add(A.paymentStartDate, interval 30 day));

update rpt_workspace.js_toothbrushFirst30Days A
join rpt_main_02.rpt_loginCountTotal B
on A.userID=B.userID
set A.lastLoginDate=B.lastLogin;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.contact B
on A.emailAddress=B.Email 
join ss_sfdc_02.task C
on B.Id=C.WhoId
set contactedPostLicenseDate=1
where C.Status='Completed' and C.CreatedDate >= A.paymentStartDate;

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.contact B
on A.emailAddress=B.email
set A.sfdcContactID=B.Id;

update rpt_workspace.js_toothbrushFirst30Days
set productName=rpt_main_02.SMARTSHEET_PRODUCTNAME(productID);

/*
alter table rpt_workspace.js_toothbrushFirst30Days
add territory varchar(50),
add segment varchar(50);

alter table rpt_workspace.js_toothbrush30DaySnapshot
add territory varchar(50),
add segment varchar(50);
*/

update rpt_workspace.js_toothbrushFirst30Days A
join ss_sfdc_02.account B
on A.accountID=B.ID
set A.territory=B.Territory__c;

update rpt_workspace.js_toothbrushFirst30Days
set segment=
case when territory like 'Mid-Market%' then 'Mid-Market' 
when territory like 'SMB%' then 'SMB' 
when territory like 'Major%' then 'Major'
when territory like 'Vertical Market: Retail%' then 'Retail'
when territory like 'Vertical Market: EDU%' then 'EDU'
when territory like 'Vertical Market: Healthcare%' then 'Healthcare'
when territory like 'Vertical Market: Gov%' then 'Gov'
when (territory like 'Unassigned%' or territory='Not Enough Information (ISR3)' or territory='') then 'No Territory'
else 'Strategic'
end
where territory is not null;

/*
drop table if exists rpt_workspace.js_toothbrush30DaySnapshot;
create table if not exists rpt_workspace.js_toothbrush30DaySnapshot
select * from rpt_workspace.js_toothbrushFirst30Days
where daysLicensed = 30;

alter table rpt_workspace.js_toothbrush30DaySnapshot
add primary key (userID);
*/

insert ignore into rpt_workspace.js_toothbrush30DaySnapshot
select * from rpt_workspace.js_toothbrushFirst30Days
where daysLicensed = 30;

delete from rpt_workspace.js_toothbrushFirst30Days
where daysLicensed = 30;

select userID, emailAddress, fullName, title, planID, accountID, accountName, paymentStartDate, daysLicensed, browserDaysActive, nativeAppDaysActive, 
totalDaysActive, currentCSRep as csRep, lastLoginDate, contactedPostLicenseDate, sfdcContactID, productName, initialCSRep, territory, segment from rpt_workspace.js_toothbrushFirst30Days
where planID is not null and currentCSRep is not null;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard10V2.sql");

