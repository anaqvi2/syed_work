SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("usageDashboardResellerV2.sql");

DROP TABLE IF EXISTS rpt_workspace.js_usageDBReseller;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_usageDBReseller
SELECT mainContactUserID, productName, paymentProfileID, mainContactDomain, parentPaymentProfileID, mainContactEmailAddress, sheetCount, sheetsCreated, sheetsShared, usersSharedTo, 
trialDate, persona, paymentStartDate, StartDate, daysSinceLastLogin, Last30DayLogins, Last90DayLogins, totalLogins, userLimit, bonusUserCount, seatCount, activeProfileCount, accountType, 
ACV, sharedToByUserID, ppID, masterDomain, everPaid, productGroup2, ipCountry, ipRegion, ipCity, role, REPLACE(fullName,",","") AS 'fullName', Territory, 
REPLACE(accountName,",","") AS accountName, paidCollab, totalCollabs, internalCollabs, accountID, CSM, last30DayLoginPlan, userAccountID,userAccountName, SysAdmin, dashboardCount,
REPLACE(jobTitle,",","") AS jobTitle, REPLACE(industry,",","") AS industry, edu, netPromoterScore, reportCount, sightsEnabled FROM rpt_workspace.js_usageDBUnassigned
WHERE closedByReseller=1;

CREATE UNIQUE INDEX userPlan ON rpt_workspace.js_usageDBReseller (mainContactUserID, ppID);

INSERT IGNORE INTO rpt_workspace.js_usageDBReseller
SELECT mainContactUserID, productName, paymentProfileID, mainContactDomain, parentPaymentProfileID, mainContactEmailAddress, sheetCount, sheetsCreated, sheetsShared, usersSharedTo, 
trialDate, persona, paymentStartDate, StartDate, daysSinceLastLogin, Last30DayLogins, Last90DayLogins, totalLogins, userLimit, bonusUserCount, seatCount, activeProfileCount, accountType, 
ACV, sharedToByUserID, ppID, masterDomain, everPaid, productGroup2, ipCountry, ipRegion, ipCity, role, REPLACE(fullName,",","") AS 'fullName', Territory, 
REPLACE(accountName,",","") AS accountName, paidCollab, totalCollabs, internalCollabs, accountID, CSM, last30DayLoginPlan, userAccountID,userAccountName, SysAdmin, dashboardCount,
REPLACE(jobTitle,",","") AS jobTitle, REPLACE(industry,",","") AS industry, edu, netPromoterScore, reportCount, sightsEnabled FROM rpt_main_02.arc_cDunn_templateUsersNew
WHERE closedByReseller=1;

SELECT * FROM rpt_workspace.js_usageDBReseller
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("usageDashboardResellerV2.sql");

