
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-deadAccountsV2.csv");

SET @@sql_mode = '';


DROP TABLE IF EXISTS rpt_main_02.stg_licensedUser30Day;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_licensedUser30Day
(userID BIGINT,
planID BIGINT,
planDomain VARCHAR(100),
daysSinceLastLogin INT,
PRIMARY KEY (userID),
KEY planID (planID),
KEY planDomain (planDomain));

INSERT INTO rpt_main_02.stg_licensedUser30Day
SELECT ppcu.mainContactUserID, ppcu.planID, ppcu.planDomain, 
lct.daysSinceLastLogin
FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID
;

DROP TABLE IF EXISTS rpt_main_02.rpt_deadAccounts;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_deadAccounts
(paymentProfileID BIGINT,
domain VARCHAR(100),
accountName VARCHAR(100),
daysSinceLastLogin INT,
CSM VARCHAR(100),
paymentStartDateTime datetime,
licensesPurchased INT,
licensedUsers INT,
ARR DECIMAL(10,2),
productName VARCHAR(25),
paymentTerm VARCHAR(25),
renewalDate DATETIME,
employeeCount INT,
otherPlansOnDomain TINYINT,
territory VARCHAR(100),
salesRep VARCHAR(100),
totalARR DECIMAL(10,2),
totalProductARR DECIMAL(10,2));

INSERT INTO rpt_main_02.rpt_deadAccounts
SELECT ppi.paymentProfileID, ppi.domain, acc.Name, MIN(B.daysSinceLastLogin), CONCAT(uu.FirstName," ",uu.LastName), ppi.paymentStartDate, ppi.userLimit, ppi.licensedUsers,
ppi.ACV, ppi.productName, rp.paymentTermFriendly, 
CASE WHEN rp.nextPaymentDate > NOW() THEN rp.nextPaymentDate 
	ELSE CASE WHEN rp.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_ADD(rp.nextPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN rp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN rp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(rp.actualLastPaymentDate), "-",DAY(rp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(rp.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) + 1) YEAR) END
		WHEN rp.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.nextPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN rp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN rp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN rp.paymentTerm = 1 
			THEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(rp.paymentStartDateClean, INTERVAL +(rp.paymentTerm) MONTH) END
		ELSE "Other" END END AS 'Renewal Date',
acc.NumberOfEmployees, 
NULL,
acc.Territory__c,
CONCAT(u.FirstName," ",u.LastName),
NULL,
NULL

FROM rpt_main_02.rpt_paidPlanInfo ppi
JOIN rpt_main_02.rpt_paymentProfile rp ON rp.paymentProfileID = ppi.paymentProfileID
JOIN rpt_main_02.stg_licensedUser30Day B ON B.planID = ppi.paymentProfileID
LEFT JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = ppi.domain
LEFT JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
LEFT JOIN ss_sfdc_02.user u ON u.Id = acc.OwnerId
LEFT JOIN ss_sfdc_02.user uu ON uu.Id = acc.Customer_Success__c
GROUP BY 1
HAVING MIN(daysSinceLastLogin) > 30
;

DROP TABLE IF EXISTS rpt_main_02.stg_domainPlanCounts;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_domainPlanCounts
(domain VARCHAR(100),
plans INT,
PRIMARY KEY (domain));

INSERT INTO rpt_main_02.stg_domainPlanCounts
SELECT domain, COUNT(DISTINCT(paymentProfileID)) 
FROM rpt_main_02.rpt_paidPlanInfo
GROUP BY 1;

UPDATE rpt_main_02.rpt_deadAccounts A
JOIN rpt_main_02.stg_domainPlanCounts B ON A.domain = B.domain
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
SET A.otherPlansOnDomain = CASE WHEN isp.domain IS NOT NULL THEN 0
		ELSE CASE WHEN B.plans >= 2 THEN 1 ELSE 0 END END;

DROP TABLE IF EXISTS rpt_main_02.stg_planTypeARR;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_planTypeARR
(productName VARCHAR(25),
ARR DECIMAL(10,2),
PRIMARY KEY (productName));

INSERT INTO rpt_main_02.stg_planTypeARR
SELECT productName, SUM(ACV)
FROM rpt_main_02.rpt_paidPlanInfo
GROUP BY 1;

UPDATE rpt_main_02.rpt_deadAccounts A
JOIN rpt_main_02.stg_planTypeARR B ON A.productName = B.productName
SET A.totalARR = B.ARR;

SELECT SUM(ACV) FROM rpt_main_02.rpt_paidPlanInfo INTO @totalARR;

UPDATE rpt_main_02.rpt_deadAccounts A
SET totalProductARR = @totalARR;
		
/* drop table if exists rpt_main_02.stg_domainPlanCounts;
DROP TABLE IF EXISTS rpt_main_02.stg_licensedUser30Day; */


SELECT * FROM rpt_main_02.rpt_deadAccounts
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-deadAccountsV2.csv");