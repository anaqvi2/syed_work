SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("referralRewardsV2.csv");


/*Generating referralRewardsV2.csv*/
SELECT
	userAccount.emailAddress 	AS 'Customer',
	
	DATE(paymentStartDateClean) AS 'Payment Start Date',
	rpt_paymentProfile.planRate_USD 		AS 'Initial Payment',
	
	/* DATE_FORMAT(paymentStartDateClean, '%Y*%m(%b)') as 'Payment Start Month', */

	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS "Signup Source",
	
	CASE rpt_signupSourceUser.mySmartsheetReferralLinkFriendly IS NULL  
		WHEN 1 THEN rpt_paymentProfile.referralEmailAddress 	/* there is no link specified */
		ELSE 
			CASE rpt_paymentProfile.referralEmailAddress IS NULL
				WHEN 1 THEN CONCAT(rpt_signupSourceUser.mySmartsheetReferralLinkFriendly, " (from link)")
				ELSE 
					CASE rpt_paymentProfile.referralEmailAddress = rpt_signupSourceUser.mySmartsheetReferralLinkFriendly
						WHEN 1 THEN CONCAT(rpt_signupSourceUser.mySmartsheetReferralLinkFriendly, " (from link)")  /* if they are the same, just pick one */ 
						ELSE 
							CASE rpt_paymentProfile.referralEmailAddress = userAccount.emailAddress
								WHEN 1 THEN rpt_signupSourceUser.mySmartsheetReferralLinkFriendly /* two different ones, but  the first is a self referral - ingore */
								ELSE CONCAT(rpt_paymentProfile.referralEmailAddress, " / ", rpt_signupSourceUser.mySmartsheetReferralLinkFriendly, " (from link)") /* they are different concatenate them */ 
							END
						
					END
			END		
	END AS "Referrer's E-mail",
	
	CASE userAccountReferrer.emailAddress IS NULL AND rpt_signupSourceUser.mySmartsheetReferralLinkFriendly IS NULL  
		WHEN 1 THEN 0
		ELSE 1
	END AS "Referrer's email exists",	
	
	CASE rpt_signupSourceUser.mySmartsheetReferralLinkFriendly  IS NOT NULL   
		WHEN 1 THEN (SELECT loginCount FROM rpt_main_02.userAccount ua 
					JOIN rpt_main_02.rpt_loginCountTotal lct ON ua.userID = lct.userID
					WHERE rpt_signupSourceUser.mySmartsheetReferralLinkFriendly  = ua.emailAddress)
		ELSE CASE userAccountReferrer.emailAddress IS NOT NULL 
					WHEN 1 THEN (SELECT loginCount FROM rpt_main_02.userAccount ua 
						JOIN rpt_main_02.rpt_loginCountTotal lct ON ua.userID = lct.userID
						WHERE userAccountReferrer.emailAddress  = ua.emailAddress)
					ELSE 0
				END
	END	AS 'Referrer Login Count',
	
	CASE rpt_signupSourceUser.mySmartsheetReferralLinkFriendly  IS NOT NULL   
		WHEN 1 THEN (SELECT COUNT(*) FROM rpt_main_02.rpt_userSourceIP sl 
					JOIN rpt_main_02.rpt_userSourceIP sl2 ON sl.sourceIP = sl2.sourceIP 
					WHERE sl.emailAddress = userAccount.emailAddress AND rpt_signupSourceUser.mySmartsheetReferralLinkFriendly = sl2.emailAddress)
		ELSE CASE userAccountReferrer.emailAddress IS NOT NULL 
					WHEN 1 THEN (SELECT COUNT(*) FROM rpt_main_02.rpt_userSourceIP sl 
							JOIN rpt_main_02.rpt_userSourceIP sl2 ON sl.sourceIP = sl2.sourceIP 
							WHERE sl.emailAddress = userAccount.emailAddress AND userAccountReferrer.emailAddress  = sl2.emailAddress)
					ELSE 0
				END
	END	AS 'Shared IP Addresses',	
		

	CASE rpt_signupSourceUser.mySmartsheetReferralLinkFriendly IS NULL  
		WHEN 1 THEN TIMESTAMPDIFF(MINUTE,userAccountReferrer.insertDatetime,userAccount.insertDateTime)	/* there is no link specified */
		ELSE TIMESTAMPDIFF(MINUTE,userAccountMySmartsheetReferral.insertDatetime,userAccount.insertDateTime)
	
	END AS 'Minutes Between Insert of Users',	
	

	userAccountInsertBy.emailAddress AS 'User Inserted By',

	CONCAT("https://www.smartsheet.com/b/opscon?formName=fn_user&formAction=fa_detail&uid=", userAccount.userID) AS "OpsCon Link",
	
	GREATEST(
	    DATE_ADD(IFNULL(rpt_paymentProfile.actualLastPaymentDate,rpt_paymentProfile.paymentStartDateClean), INTERVAL rpt_paymentProfile.paymentTerm MONTH),
	    IFNULL(rpt_paymentProfile.nextPaymentDate, rpt_paymentProfile.paymentStartDateClean)
	  ) AS OldCalculatedNextPaymentDate,
CASE WHEN rpt_paymentProfile.nextPaymentDate > NOW() THEN rpt_paymentProfile.nextPaymentDate 
	ELSE CASE WHEN rpt_paymentProfile.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(rpt_paymentProfile.actualLastPaymentDate), "-",DAY(rpt_paymentProfile.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) + 1) YEAR) END
		WHEN rpt_paymentProfile.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN rpt_paymentProfile.paymentTerm = 1 
			THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(rpt_paymentProfile.paymentTerm) MONTH) END
		ELSE "Other" END
	END
AS NewCalcNextPaymentDate,
rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID) AS planTypeAtPurchase,
rpt_paymentProfile.paymentProfileID

FROM rpt_main_02.rpt_paymentProfile rpt_paymentProfile
JOIN rpt_main_02.userAccount userAccount 									ON rpt_paymentProfile.sourceUserID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.userAccount userAccountInsertBy					ON userAccount.insertByUserID = userAccountInsertBy.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser 			ON rpt_paymentProfile.sourceUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.userAccount userAccountReferrer					ON rpt_paymentProfile.referralEmailAddress = userAccountReferrer.emailAddress
LEFT OUTER JOIN rpt_main_02.userAccount userAccountMySmartsheetReferral		ON rpt_signupSourceUser.mySmartsheetReferralLinkFriendly = userAccountMySmartsheetReferral.emailAddress
LEFT OUTER JOIN rpt_main_02.arc_sourceUser_firstWinProduct fwp 				ON fwp.sourceUserID = rpt_paymentProfile.sourceUserID
/* LEFT OUTER JOIN rpt_main_02.organization organization				ON rpt_paymentProfile.paymentProfileID = organization.paymentProfileID	
	LEFT OUTER JOIN rpt_main_02.organizationUserRole organizationUserRole ON organization.organizationID = organizationUserRole.organizationID AND organizationUserRole.userID */
WHERE countAsPaid = 1 AND (rpt_signupSourceUser.mySmartsheetReferralLinkFriendly IS NOT NULL OR (rpt_paymentProfile.referralEmailAddress IS NOT NULL AND rpt_paymentProfile.referralEmailAddress != userAccount.emailAddress))
ORDER BY paymentStartDateClean
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("referralRewardsV2.csv");






	
