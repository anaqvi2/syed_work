SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryMonthlyV2.csv insert");

UPDATE rpt_main_02.arc_paidAccountTransfers pat
JOIN rpt_main_02.arc_requestLog rl ON rl.requestLogID = pat.requestLogID
SET pat.transferToUserID = rl.parm2
WHERE pat.transferToUserID IS NULL;

UPDATE rpt_main_02.arc_paidAccountTransfers pat
JOIN rpt_main_02.arc_requestLog rl ON rl.requestLogID = pat.requestLogID
SET pat.transferFromUserID = rl.parm1
WHERE pat.transferFromUserID IS NULL;

DROP TABLE IF EXISTS rpt_main_02.stg_customerSuccessRSM;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_customerSuccessRSM
(mainContactUserID BIGINT,
paymentProfileID BIGINT,
recordDateTime DATETIME,
customerSuccess VARCHAR(100),
territory VARCHAR(100),
KEY paymentProfileID (paymentProfileID),
KEY recordDateTime (recordDateTime));

INSERT INTO rpt_main_02.stg_customerSuccessRSM
SELECT mainContactUserID, paymentProfileID, recordDateTime, customerSuccess, territory
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE recordDateTime >= (
	SELECT startMonth 
	FROM rpt_main_02.ref_months WHERE startMonth < DATE_ADD(NOW(), INTERVAL -5 DAY) AND endMonth > DATE_ADD(NOW(), INTERVAL -5 DAY))
	AND (NewProductName != 'ConsolidationUpdate' OR NewProductName IS NULL);
	
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE futureLoss = 1;

/*Insert Wins*/

INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
currencyChange,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)

SELECT 
months.monthFriendly,
pp.mainContactUserID AS MainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
NULL,
NULL,
hist_paymentProfile.paymentStartDateTime AS PaymentStartDate,

CASE DATEDIFF(MIN(hist_paymentProfile.paymentStartDateTime), pp.paymentInsertDate) < 0
	WHEN 1 THEN NULL ELSE DATEDIFF(MIN(hist_paymentProfile.paymentStartDateTime), pp.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID),
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
NULL, 
NULL, 
NULL,
NULL,
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm,2) AS NewMonthlyPayment,
0 AS oldMonthlyPayment,
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm,2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime,
hist_paymentProfile.modifyDateTime,

CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'WINS' AS recordtype,

hist_paymentProfile.paymentStartDateTime,
0,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
0,
hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm,
hist_paymentProfile.currencyCode

FROM rpt_main_02.hist_paymentProfile
JOIN rpt_main_02.ref_months months ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND paymentStartDateTime BETWEEN months.startMonth AND months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile pp FORCE INDEX (PRIMARY) ON pp.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON pp.mainContactUserID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON pp.mainContactUserID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.planRate_USD > 0
AND hist_paymentProfile.paymentType != 4
AND hist_paymentProfile.paymentStartDateTime >= '2016-12-01'

GROUP BY 1,2,3
;



/*Insert Upgrades*/
INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
currencyChange,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)

(SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
hist_paymentProfile.paymentStartDateTime AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm), 2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN oldHPP.planRate = hist_paymentProfile.planRate THEN 1 ELSE 0 END AS CurrencyChange,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
oldHPP.planRate/oldHPP.paymentTerm,
hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm,
hist_paymentProfile.currencyCode

FROM rpt_main_02.ref_months months
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID = rpt_userIPLocation.userID

WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.accountType !=2 
AND hist_paymentProfile.planRate_USD > 0
AND oldHPP.planRate_USD > 0
AND oldHPP.productID >= 3
AND oldHPP.planRate_USD/oldHPP.paymentTerm < hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4
AND (hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.modifyDateTime, INTERVAL -30 SECOND) 
OR hist_paymentProfile.paymentStartDateTime = hist_paymentProfile.modifyDateTime 
OR hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.modifyDateTime, INTERVAL +10 SECOND))
AND hist_paymentProfile.paymentStartDateTime < months.startMonth
AND hist_paymentProfile.modifyDateTime >= '2016-12-01'

GROUP BY 1,2,3)

UNION 

(SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
orgHPP.paymentProfileID,
orgHPP.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(orgHPP.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(orgHPP.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
orgHPP.paymentStartDateTime AS PaymentStartDate,

CASE DATEDIFF(orgHPP.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(orgHPP.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(orgHPP.productID) AS NewProductName,
orgHPP.userLimit AS NewUserLimit,
orgHPP.paymentTerm AS NewPaymentTerm,
CASE WHEN orgHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
ROUND(orgHPP.planRate_USD/orgHPP.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
ROUND((orgHPP.planRate_USD/orgHPP.paymentTerm), 2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

orgHPP.insertDateTime AS paymentProfileInsertDateTime,
orgHPP.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN oldHPP.planRate = hist_paymentProfile.planRate THEN 1 ELSE 0 END AS CurrencyChange,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
oldHPP.planRate/oldHPP.paymentTerm,
orgHPP.planRate/orgHPP.paymentTerm,
orgHPP.currencyCode


FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.hist_paymentProfile orgHPP ON orgHPP.paymentProfileID = hist_paymentProfile.parentPaymentProfileID
	AND DATE_FORMAT(hist_paymentProfile.modifyDateTime, "%Y-%m") = DATE_FORMAT(orgHPP.modifyDateTime, "%Y-%m")
	AND orgHPP.hist_effectiveThruDateTime > months.endMonth
	AND orgHPP.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfileContact OrgPPC ON OrgPPC.paymentProfileID = orgHPP.paymentProfileID

WHERE hist_paymentProfile.modifyDateTime >= '2016-12-01' AND orgHPP.modifyDateTime >= '2016-08-01'
AND oldHPP.productID >= 3
AND oldHPP.planRate_USD > 0 
AND oldHPP.accountType = 1 AND hist_paymentProfile.accountType = 2
AND hist_paymentProfile.parentPaymentProfileID IS NOT NULL
AND oldHPP.planRate_USD/oldHPP.paymentTerm < orgHPP.planRate_USD/orgHPP.paymentTerm
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4
AND ppc.mainContactUserID = OrgPPC.userID /*Excludes instance of user joining a different org at a higher plan rate*/
AND (hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.modifyDateTime, INTERVAL -30 SECOND) 
OR hist_paymentProfile.paymentStartDateTime = hist_paymentProfile.modifyDateTime 
OR hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.modifyDateTime, INTERVAL +10 SECOND))
AND orgHPP.paymentStartDateTime < months.startMonth

GROUP BY 1,2,3)

ORDER BY 1
LIMIT 4444444
;

/*Insert Alternate Upgrades*/

INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
currencyChange,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)
SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
hist_paymentProfile.paymentStartDateTime AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm), 2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN oldHPP.planRate = hist_paymentProfile.planRate THEN 1 ELSE 0 END AS CurrencyChange,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
oldHPP.planRate/oldHPP.paymentTerm,
hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm,
hist_paymentProfile.currencyCode


FROM rpt_main_02.ref_months months
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly RSM ON hist_paymentProfile.paymentProfileID = RSM.paymentProfileID 
	AND months.monthFriendly = RSM.monthFriendly AND RSM.recordType = "Upgrades"

WHERE hist_paymentProfile.productID IN (6,7,8,10,11)
AND hist_paymentProfile.accountType = 3
AND hist_paymentProfile.planRate_USD > 0
AND (oldHPP.planRate_USD IS NULL OR oldHPP.planRate_USD = 0)
AND hist_paymentProfile.paymentType != 4
AND hist_paymentProfile.paymentStartDateTime < months.startMonth
AND RSM.paymentProfileID IS NULL
AND hist_paymentProfile.modifyDateTime >= '2016-12-01'

GROUP BY 1,2,3
;

/****Payment Profile Transfer Upgrades****/
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE oldMonthlyPayment IS NULL AND recordDateTime >= (
	SELECT startMonth 
	FROM rpt_main_02.ref_months WHERE startMonth < DATE_ADD(NOW(), INTERVAL -5 DAY) AND endMonth > DATE_ADD(NOW(), INTERVAL -5 DAY));

INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
currencyChange,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)

SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(CASE WHEN paidTransferHPP.accountType IS NULL THEN sourceHPP.accountType END) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(CASE WHEN paidTransferHPP.paymentType IS NULL THEN sourceHPP.paymentType END) AS OldPaymentType,
hist_paymentProfile.paymentStartDateTime AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(paidTransferHPP.productID) AS OldProductName,
CASE WHEN paidTransferHPP.userLimit IS NULL THEN sourceHPP.userLimit END AS OldUserLimit,
CASE WHEN paidTransferHPP.paymentTerm IS NULL THEN sourceHPP.paymentTerm END AS OldPaymentTerm,
CASE WHEN (CASE WHEN paidTransferHPP.paymentTerm IS NULL THEN sourceHPP.paymentTerm END) = 12 THEN 1 ELSE 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
IFNULL(CASE WHEN paidTransferHPP.planRate_USD IS NULL THEN ROUND(sourceHPP.planRate_USD/sourceHPP.paymentTerm, 2)
	ELSE ROUND(paidTransferHPP.planRate_USD/paidTransferHPP.paymentTerm, 2) END,0) AS OldMonthlyPayment,
ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm), 2) - 
IFNULL(CASE WHEN paidTransferHPP.planRate_USD IS NULL THEN ROUND(sourceHPP.planRate_USD/sourceHPP.paymentTerm, 2)
	ELSE ROUND(paidTransferHPP.planRate_USD/paidTransferHPP.paymentTerm, 2) END,0) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime AS modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'UPGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN paidTransferHPP.planRate = hist_paymentProfile.planRate THEN 1 ELSE 0 END AS CurrencyChange,
IFNULL(CASE WHEN paidTransferHPP.planRate IS NULL THEN ROUND(sourceHPP.planRate/sourceHPP.paymentTerm, 2)
	ELSE ROUND(paidTransferHPP.planRate/paidTransferHPP.paymentTerm, 2) END,0),
ROUND(hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm, 2),
hist_paymentProfile.currencyCode

FROM rpt_main_02.ref_months months
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly RSM ON hist_paymentProfile.paymentProfileID = RSM.paymentProfileID 
	AND months.monthFriendly = RSM.monthFriendly AND RSM.recordType = "Upgrades"
LEFT OUTER JOIN rpt_main_02.arc_paidAccountTransfers ON ppc.sourceUserID = arc_paidAccountTransfers.TransferToUserID AND arc_paidAccountTransfers.transferStatus = "true"
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile sourceHPP ON sourceHPP.ownerID = ppc.sourceUserID AND sourceHPP.accountType != 3
	AND sourceHPP.hist_effectiveThruDateTime > months.startMonth
	AND sourceHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile paidTransferHPP ON paidTransferHPP.ownerID = arc_paidAccountTransfers.TransferFromUserID  AND paidTransferHPP.accountType != 3
	AND paidTransferHPP.hist_effectiveThruDateTime > months.startMonth
	AND paidTransferHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)

WHERE hist_paymentProfile.productID IN (6,7,8,10,11)
AND hist_paymentProfile.accountType = 3
AND hist_paymentProfile.planRate_USD > 0
AND (oldHPP.planRate_USD IS NULL OR oldHPP.planRate_USD = 0)
AND hist_paymentProfile.paymentType != 4
AND hist_paymentProfile.paymentStartDateTime < months.startMonth
AND RSM.paymentProfileID IS NULL
AND hist_paymentProfile.modifyDateTime >= '2016-12-01'
GROUP BY 1,2,3
;

/*Insert Downgrades*/
INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
currencyChange,
oldPaymentProfileID,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)


SELECT 
months.monthFriendly,
ppc.mainContactUserID AS mainContactUserID,
oldHPP.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","") AS organizationName, 
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS OldPaymentType,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS NewProductName,
hist_paymentProfile.userLimit AS NewUserLimit,
hist_paymentProfile.paymentTerm AS NewPaymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID) AS OldProductName,
oldHPP.userLimit AS OldUserLimit,
oldHPP.paymentTerm AS OldPaymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
CASE WHEN oldHPP.planRate_USD = 0 THEN ROUND(orgHPP.planRate_USD/orgHPP.paymentTerm,2)
	ELSE ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm,2)  END AS OldMonthlyPayment,
CASE WHEN oldHPP.planRate_USD = 0 THEN ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm),2) - ROUND((orgHPP.planRate_USD/orgHPP.paymentTerm),2)
	ELSE ROUND((hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm),2) - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm),2) END AS MonthlyPaymentChange,
hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,	
hist_paymentProfile.modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'DOWNGRADES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN oldHPP.planRate = hist_paymentProfile.planRate THEN 1 ELSE 0 END AS CurrencyChange,

CASE WHEN oldHPP.accountType = 2 THEN orgHPP.paymentProfileID ELSE oldHPP.paymentProfileID END AS oldPaymentProfileID,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
CASE WHEN oldHPP.planRate_USD = 0 THEN ROUND(orgHPP.planRate/orgHPP.paymentTerm,2)
	ELSE ROUND(oldHPP.planRate/oldHPP.paymentTerm,2)  END,
hist_paymentProfile.planRate/hist_paymentProfile.paymentTerm,
hist_paymentProfile.currencyCode



FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile orgHPP FORCE INDEX (hist_paymentProfile_idxPK) ON oldHPP.parentPaymentProfileID = orgHPP.paymentProfileID 
	AND oldHPP.modifyDateTime = orgHPP.modifyDateTime
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID=rpt_userIPLocation.userID

WHERE hist_paymentProfile.modifyDateTime >= '2016-12-01'
AND hist_paymentProfile.productID >= 3
AND hist_paymentProfile.planRate_USD > 0
AND hist_paymentProfile.accountType != 2 
AND hist_paymentProfile.paymentProfileID NOT IN (1274492)  /*Excluded PPs based on typos or other incorrect data*/
AND hist_paymentProfile.paymentType != 4
AND (hist_paymentProfile.paymentStartDateTime < DATE_ADD(hist_paymentProfile.modifyDateTime, INTERVAL -30 SECOND) OR hist_paymentProfile.paymentStartDateTime = hist_paymentProfile.modifyDateTime)
AND hist_paymentProfile.paymentStartDateTime < months.startMonth


HAVING OldMonthlyPayment > NewMonthlyPayment

ORDER BY 1
;

/*Insert Losses*/
INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
excludeLoss,
currencyChange,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)

SELECT 
months.monthFriendly,
ppc.mainContactUserID AS MainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","")  AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS NewAccountType,
DATE_FORMAT(oldHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID),
hist_paymentProfile.userLimit,
hist_paymentProfile.paymentTerm,
CASE WHEN hist_paymentProfile.paymentTerm = 12 THEN 1 ELSE 0 END, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID),
oldHPP.userLimit,
oldHPP.paymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
ROUND(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm, 2) AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
0 - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.modifyDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment 	AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",

'LOSSES' AS recordtype,

hist_paymentProfile.modifyDateTime,

CASE WHEN sourceHPP.accountType = 2 THEN 1 ELSE 0 END AS excludeLoss,
0,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
oldHPP.planRate/oldHPP.paymentTerm,
0,
oldHPP.currencyCode


FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
	AND months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID=rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.arc_paidAccountTransfers exclude ON ppc.mainContactUserID = exclude.TransferFromUserID AND exclude.transferStatus = "true"
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile sourceHPP ON sourceHPP.ownerID = ppc.mainContactUserID AND sourceHPP.accountType = 2
	AND sourceHPP.hist_effectiveThruDateTime > months.endMonth
	AND sourceHPP.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly RSM ON hist_paymentProfile.paymentProfileID = RSM.oldPaymentProfileID 
	AND months.monthFriendly = RSM.monthFriendly AND RSM.recordType = "Downgrades"
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly RSM2 ON hist_paymentProfile.ownerID = RSM2.mainContactUserID 
	AND months.monthFriendly = RSM2.monthFriendly AND RSM2.recordType = "UPGRADES"
	
WHERE hist_paymentProfile.modifyDateTime >= '2016-12-01'
/* AND hist_paymentProfile.productID IN (0,2)
AND hist_paymentProfile.accountType != 2 */
AND hist_paymentProfile.planRate_USD = 0
AND oldHPP.productID >= 3 
AND oldHPP.planRate_USD > 0
AND exclude.TransferFromUserID IS NULL
AND hist_paymentProfile.paymentType != 4
AND RSM.oldPaymentProfileID IS NULL
AND RSM2.mainContactUserID IS NULL
ORDER BY 1
;

/*Insert Future Losses*/
INSERT rpt_main_02.output_RevenueSummaryMonthly (monthFriendly,
mainContactUserID,
paymentProfileID,
ownerID,
organization,
NewAccountType,
NewPaymentType,
OldAccountType,
OldPaymetType,
PaymentStartDate,

DaysToBuy,
NewProductName,
NewUserLimit,
NewPaymentTerm,
NewPaymentTermAnnual,
OldProductName,
OldUserLimit,
OldPaymentTerm,
OldPaymentTermAnnual,
NewMonthlyPayment,
OldMonthlyPayment,
MonthlyPaymentChange,

paymentProfileInsertDateTime,
modifyDateTime,
Bucket,
SignupSourceFriendly,
SignupSubSourceFriendly,
SignupCampaign,
SignupSegment,
ipCountry,
ipRegion,
ipCity,
recordtype,
recordDateTime,
excludeLoss,
currencyChange,
futureLoss,
reseller,
OldMonthlyPaymentLocal,
NewMonthlyPaymentLocal,
currencyCode)
SELECT 
months.monthFriendly,
ppc.mainContactUserID AS MainContactUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
REPLACE(REPLACE(organization.name,'"',""),"'","")  AS organizationName,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS NewAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS NewPaymentType,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(oldHPP.accountType) AS OldAccountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(oldHPP.paymentType) AS NewPaymentType,
DATE_FORMAT(oldHPP.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,

CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentInsertDate) END AS DaysToBuy,
"Cancelled",
1,
0,
0, 
rpt_main_02.SMARTSHEET_PRODUCTNAME(oldHPP.productID),
oldHPP.userLimit,
oldHPP.paymentTerm,
CASE WHEN oldHPP.paymentTerm = 12 THEN 1 ELSE 0 END, 
0 AS NewMonthlyPayment,
ROUND(oldHPP.planRate_USD/oldHPP.paymentTerm, 2) AS OldMonthlyPayment,
0 - ROUND((oldHPP.planRate_USD/oldHPP.paymentTerm), 2) AS MonthlyPaymentChange,

hist_paymentProfile.insertDateTime AS paymentProfileInsertDateTime,
hist_paymentProfile.paymentEndDateTime,
CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

CASE 
	WHEN rpt_signupSourceUser.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSourceUser.slp = '' THEN "Homepage" ELSE rpt_signupSourceUser.slp END)
	ELSE rpt_signupSourceUser.campaign
END AS SignupCampaign,

rpt_signupSourceUser.segment AS SignupSegment,

CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) 
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",
'LOSSES' AS recordtype,
hist_paymentProfile.modifyDateTime,

CASE WHEN sourceHPP.accountType = 2 THEN 1 ELSE 0 END AS excludeLoss,
0,
1,
CASE WHEN hist_paymentProfile.referralEmailAddress LIKE "Reseller%" THEN 1 ELSE 0 END AS Reseller,
oldHPP.planRate_USD/oldHPP.paymentTerm,
0,
oldHPP.currencyCode


FROM rpt_main_02.ref_months months  
JOIN rpt_main_02.hist_paymentProfile ON hist_paymentProfile.hist_effectiveThruDateTime > months.endMonth
	AND hist_paymentProfile.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
JOIN rpt_main_02.hist_paymentProfile oldHPP ON oldHPP.paymentProfileID = hist_paymentProfile.paymentProfileID
	AND oldHPP.hist_effectiveThruDateTime > months.startMonth
	AND oldHPP.modifyDateTime <= months.startMonth
	AND months.startMonth <= NOW()
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ppc FORCE INDEX (PRIMARY) ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.mainContactUserID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY) ON ppc.mainContactUserID=rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.arc_paidAccountTransfers exclude ON ppc.mainContactUserID = exclude.TransferFromUserID AND exclude.transferStatus = "true"
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile sourceHPP ON sourceHPP.ownerID = ppc.mainContactUserID AND sourceHPP.accountType = 2
	AND sourceHPP.hist_effectiveThruDateTime > months.endMonth
	AND sourceHPP.modifyDateTime <= months.endMonth
	AND months.startMonth <= NOW()
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly RSM ON hist_paymentProfile.paymentProfileID = RSM.oldPaymentProfileID 
	AND months.monthFriendly = RSM.monthFriendly AND RSM.recordType = "Downgrades"
	
WHERE hist_paymentProfile.modifyDateTime >= '2009-01-01'
AND hist_paymentProfile.productID >=3
AND hist_paymentProfile.accountType != 2 
AND (hist_paymentProfile.paymentFlags & 16) = 16
AND oldHPP.productID >= 3 
AND oldHPP.planRate_USD > 0
AND exclude.TransferFromUserID IS NULL
AND hist_paymentProfile.paymentType != 4
AND RSM.oldPaymentProfileID IS NULL

ORDER BY 1
;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.paymentProfileID
SET A.domain = pp.mainContactDomain
WHERE DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly rsm
LEFT JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = rsm.domain
LEFT JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
SET rsm.accountName = acc.Name, rsm.accountID=acc.Id,
rsm.fortune1000 = CASE WHEN acc.Fortune_1000_Rank__c > 0 THEN 1 ELSE 0 END, rsm.territory=acc.Territory__c, rsm.CustomerSuccess=d.Customer_Success__c
WHERE DATE_FORMAT(rsm.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.stg_customerSuccessRSM cs ON cs.paymentProfileID = A.paymentProfileID 
	AND DATE_FORMAT(cs.recordDateTime, '%Y-%m') = DATE_FORMAT(A.recordDateTime, '%Y-%m')
SET A.customerSuccess = cs.customerSuccess, A.territory=cs.territory
WHERE DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET segment=
CASE WHEN territory LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territory LIKE 'SMB%' THEN 'SMB' 
WHEN territory LIKE 'Major%' THEN 'Major'
WHEN territory LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territory LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territory LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territory LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN (territory LIKE 'Unassigned%' OR territory='Not Enough Information (ISR3)' OR territory='') THEN 'No Territory'
ELSE 'Strategic'
END
WHERE recordDateTime >= '2017-05-01' AND territory IS NOT NULL;

UPDATE rpt_main_02.output_RevenueSummaryMonthly rsm
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ss ON ss.userID = rsm.mainContactUserID
LEFT OUTER JOIN rpt_main_02.ref_trpValues trp ON trp.trpValue = ss.trpvalue
SET rsm.trpValue = CONCAT(ss.trpValue, " ", IF(trp.trpName IS NULL, "UNKNOWN TRP VALUE",trp.trpName)),
rsm.trpCategory = trp.trpCategory,
rsm.lpv = ss.landingPageVersion,
rsm.lpa = ss.lpa,
rsm.lang = ss.lang
WHERE rsm.trpValue IS NULL;

-- Manually remomving a win/loss combo that Mader/Stephen have deemed to be an accident and shouldn't show

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6432987 AND recordType = 'WINS' AND monthFriendly = '2015-09(Sep)';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 1753369 AND recordType = 'LOSSES' AND monthFriendly = '2015-09(Sep)';

-- Manually removing/fixing transactions that Mader/Stephen have deemed to be accidents and shouldn't show

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5015121 AND recordType = 'LOSSES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2015-09';
UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = 350.00000000000000,
MonthlyPaymentChange = 1150.00000000000000
WHERE paymentProfileID = 6471882 AND recordType = 'UPGRADES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2015-09';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2014-12-20 00:00:00' WHERE paymentProfileID = 3790372 AND recordType = "LOSSES";
UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2014-11-01 00:00:00' WHERE paymentProfileID = 3624321 AND recordType = "LOSSES";

-- Manually fixing to get 12/1 transactions in November

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2015-11-30 21:06:15' WHERE paymentProfileID = 5240367 AND recordType = "UPGRADES" AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2015-12';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET monthFriendly = '2015-11(Nov)',
OldMonthlyPayment = 0,
MonthlyPaymentChange = '5287.50000000000000',
recordtype = 'WINS',
recordDateTime = '2015-11-30 23:50:00'
WHERE paymentProfileID = 6745056 AND monthFriendly = '2015-12(Dec)';

-- Manual fix from Feb 2016 for loss then immediate re-buy

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5241013 AND recordType = 'LOSSES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-02';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = 583.33333333333333,
MonthlyPaymentChange = -233.33333333333333,
recordType = 'DOWNGRADES'
WHERE paymentProfileID = 7087558 AND recordType = 'WINS' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-02';


-- February 2016 additions

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-02-29 23:00:00' WHERE paymentProfileID = 7115314 AND recordDateTime >= '2016-03-01 00:00:00' AND monthFriendly = '2016-03(Mar)';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 3520474 AND monthFriendly = '2016-03(Mar)';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = 880.00, MonthlyPaymentChange = 250.00 WHERE paymentProfileID = 3520474 AND recordDateTime = '2016-02-29 23:59:36';


-- Manual fix for incorrect december win/loss combo

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
	WHERE paymentProfileID = 6759967 AND monthFriendly IN('2015-12(Dec)','2016-01(Jan)');
	
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE monthFriendly = '2016-03(Mar)' AND paymentProfileID = 2418105;

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET MonthlyPaymentChange = '175.41'
WHERE paymentProfileID = 1326421
AND monthFriendly = '2016-03(Mar)';

-- After 5 PM plan booked to March

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-03-31 15:00:00'
WHERE paymentProfileID = 7038586
AND recordDateTime = '2016-04-01 15:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET MonthlyPaymentChange = '10233.59'
WHERE paymentProfileID = 3888977 AND monthFriendly = '2016-04(Apr)';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 5955508 AND monthFriendly = '2016-04(Apr)';

-- Manual Fixes for May 2016

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.stg_manualBookingDateChanges B ON A.paymentProfileID = B.paymentProfileID AND DATE_FORMAT(A.recordDateTime, '%Y-%m') = '2016-05'
SET A.recordDateTime = B.recordDateTime
WHERE A.recordType = 'LOSSES';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-05-31 23:00:00',
domainLevelRecordType = 'UPGRADES'
WHERE paymentProfileID = 5945188 AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-06';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5359911 AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = 2020.42,
	MonthlyPaymentChange = 1616.67
WHERE paymentProfileID = 5359911 AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-05';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE domain = 'sodexo.com' AND recordType = 'LOSSES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-05';

-- Manual Fixes for June 2016

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5945188 AND monthFriendly LIKE '%2016-06%' AND domainStartingMRR IS NULL;

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET domainLevelRecordType = NULL,
domainStartingMRR = NULL,
domainLevelRecordTypeNew = NULL
WHERE paymentProfileID IN (4064415, 5304818, 6064356, 6119036, 6852496, 7259083) AND monthFriendly LIKE '%2016-06%' AND recordTypeNew = 'EXPANSION';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET domainLevelRecordType = NULL,
domainStartingMRR = NULL,
domainLevelRecordTypeNew = NULL
WHERE paymentProfileID IN ('1812245', '1891915', '3235968', '3631408', '3960831', '3983205', '4239177', '4357953', '4671247', '4871083', '4902904', 
'5595058', '5637861', '5640858', '5762147', '5766215', '5896876', '5923532', '5983131', '6038047', '6054691', '6062666', '6091855', '6097733', '6116093', 
'6126296', '6195320','6231444','6257160', '6280189', '6345063', '6486375', '6499056', '6581192', '6632880', '6664827', '6741221', '6767435', '6801572', '6813034', 
'6847496', '6980190', '7030746') AND monthFriendly LIKE '%2016-06%' AND recordType = 'LOSSES';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE domain = 'snclavalin.com' 
AND monthFriendly = '2016-08(Aug)';

-- August 2016 manual fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDatetime = '2016-08-31 16:00:00' 
WHERE recordType = 'UPGRADES' AND paymentProfileID = 7614098 
AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-09';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDatetime = '2016-08-31 16:00:00' 
WHERE recordType = 'UPGRADES' AND paymentProfileID = 7583135 
AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-09';

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID IN(7583135,7614098) AND domainLevelRecordType IS NULL; */

-- September manual fixes

/* UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-09-30 00:00:00'
WHERE paymentProfileID = 8138262 AND recordType = 'WINS' AND recordDateTime >= '2016-10-01 00:00:00'; */

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 8138262 AND recordType = 'WINS' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-10';

/* UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '757.33',
MonthlyPaymentChange = '633.25'
WHERE paymentProfileID = 1506106 AND recordDateTime = '2016-09-01 05:48:36'; */

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 1506106 AND recordType = 'UPGRADES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-10';

/* UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '1600.00',
MonthlyPaymentChange = '1093.00'
WHERE paymentProfileID = 6089813 AND recordDateTime = '2016-09-12 21:41:39'; */

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 6089813 AND recordType = 'UPGRADES' AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2016-10';

-- October fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '8.25',
MonthlyPaymentChange = '19.99',
OldProductName = 'Basic'
WHERE paymentProfileID = 8272517 AND monthFriendly = '2016-10(Oct)';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '1954.17000000000000',
MonthlyPaymentChange = '366.67000000000000'
WHERE paymentProfileID = 2997021
AND recordDateTime = '2016-10-10 16:49:13'
AND '2016-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2997021 AND recordDateTime = '2016-11-01 00:03:05';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-10-31 16:00:00'
WHERE paymentProfileID = 8322058 AND recordDateTime >= '2016-11-01'
AND '2016-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8322058 AND recordDateTime >= '2016-11-01'; */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-10-31 16:00:00'
WHERE paymentProfileID = 5117822 AND recordDateTime >= '2016-11-01'
AND '2016-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5117822 AND recordDateTime >= '2016-11-01'; */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-10-31 16:00:00'
WHERE paymentProfileID = 7325274 AND recordDateTime >= '2016-11-01'
AND '2016-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7325274 AND recordDateTime >= '2016-11-01'; */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-10-31 16:00:00'
WHERE paymentProfileID = 8326994 AND recordDateTime >= '2016-11-01'
AND '2016-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8326994 AND recordDateTime >= '2016-11-01'; */

-- November 2016 Manual Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '1243.75',
	MonthlyPaymentChange = '863.75'
WHERE paymentProfileID = 7800676
AND recordDateTime = '2016-11-28 17:00:15'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7800676 AND recordDateTime = '2016-12-01 00:50:03';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-11-30 16:00:00'
WHERE paymentProfileID = 4941990
AND recordDateTime = '2016-12-01 16:55:36'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4941990 AND recordDateTime = '2016-12-01 16:55:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '315.00',
	MonthlyPaymentChange = '1035.00',
    PaymentStartDate = '2015-11-23 09:54:41'
WHERE paymentProfileID = 6656771
AND recordDateTime = '2016-11-21 08:00:00'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '13.00',
	MonthlyPaymentChange = '44.00'
WHERE paymentProfileID = 8369083
AND recordDateTime = '2016-11-24 17:00:03'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '13.00',
	MonthlyPaymentChange = '44.00'
WHERE paymentProfileID = 8435615
AND recordDateTime = '2016-11-24 17:00:03'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '10.00',
	MonthlyPaymentChange = '47.00'
WHERE paymentProfileID = 8456929
AND recordDateTime = '2016-11-23 09:17:14'
AND '2016-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

-- December after 4 PM deals

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-12-30 00:00:00'
WHERE paymentProfileID = 8224694
AND recordDateTime = '2017-01-03 08:00:00'
AND '2016-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* Cancelled and Purchased under different PPID, changing the new one now
UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-12-30 00:00:00'
WHERE paymentProfileID = 8638214
AND recordDateTime = '2017-01-03 08:00:00'
AND '2016-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8638214
AND recordDateTime = '2017-01-03 08:00:00';*/

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8224694
AND recordDateTime = '2017-01-03 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2016-12-30 00:00:00',
salesAssisted = 1
WHERE paymentProfileID = 8128578
AND recordDateTime = '2017-01-06 08:00:00'
AND monthFriendly = '2017-01(Jan)'
AND '2016-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8128578
AND recordDateTime = '2017-01-06 08:00:00';

/*
update rpt_main_02.output_RevenueSummaryMonthly
set paymentProfileID = 8492439,
ownerID = 1167676, 
organization = 'B&E Resources',
NewAccountType = 'Multi-user',
NewPaymentType = 'Annual',
NewProductName = 'Business',
NewUserLimit = 3,
NewPaymentTerm = 12,
NewMonthlyPayment = '75.00',
MonthlyPaymentChange = '45.00',
recordType = 'UPGRADES',
recordTypeNew='EXPANSION',
domainLevelRecordType = 'UPGRADES',
domainLevelRecordTypeNew = 'EXPANSION'
where paymentProfileID = 4083463 and date_format(recordDateTime, '%Y-%m')='2016-11';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '91.62',
MonthlyPaymentChange = '783.38',
recordType = 'UPGRADES',
domainLevelRecordType = 'UPGRADES',
recordTypeNew = 'EXPANSION',
domainLevelrecordTypeNew = 'EXPANSION'
WHERE paymentProfileID = 7404409 AND recordDateTime = '2016-11-30 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '1954.17000000000000',
MonthlyPaymentChange = '233.33'
WHERE paymentProfileID = 2997021 AND recordDateTime = '2016-11-18 23:37:53';
*/

-- January Fixes

-- DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8638214 and monthFriendly = '2017-01(Jan)';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldProductName = 'Basic',
OldPaymentTerm = 12,
OldPaymentTermAnnual = 1,
OldMonthlyPayment = '14.00000',
MonthlyPaymentChange = '31.00000'
WHERE paymentProfileID = 8770805 AND monthFriendly = '2017-01(Jan)';

-- January 2017 After 4 PM Deals

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordDateTime = '2017-01-31 00:00:00'
WHERE paymentProfileID = 8813942
AND recordDateTime = '2017-02-01 08:00:00'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8813942 AND recordDateTime = '2017-02-01 08:00:00';


UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '500.00',
	MonthlyPaymentChange = '290.00'
WHERE paymentProfileID = 7171415
AND recordDateTime = '2017-01-26 16:19:33'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7171415 AND recordDateTime = '2017-02-01 15:45:01';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordDateTime = '2017-01-31 00:00:00'
WHERE paymentProfileID = 8806210
AND recordDateTime = '2017-02-01 00:16:54'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8806210 AND recordDateTime = '2017-02-01 00:16:54';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordDateTime = '2017-01-31 00:00:00'
WHERE paymentProfileID = 6252408
AND recordDateTime = '2017-02-02 20:24:59'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6252408 AND recordDateTime = '2017-02-02 20:24:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordDateTime = '2017-01-31 00:00:00'
WHERE paymentProfileID = 7720063
AND recordDateTime = '2017-02-01 00:01:00'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7720063 AND recordDateTime = '2017-02-01 00:01:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordDateTime = '2017-01-31 00:00:00'
WHERE paymentProfileID = 8806232
AND recordDateTime = '2017-02-01 00:20:22'
AND '2017-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8806232 AND recordDateTime = '2017-02-01 00:20:22';

-- February 2017 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET 	NewMonthlyPayment = '52187.50000000000000',
	MonthlyPaymentChange = '4227.81',
	recordType = 'UPGRADES',
	recordTypeNew = 'EXPANSION',
	domainLevelRecordType = 'UPGRADES',
	domainLevelRecordTypeNew = 'EXPANSION',
	NewUserLimit = 6352
WHERE paymentProfileID = 3888977 AND recordDateTime = '2017-02-28 23:41:33'
AND '2017-02' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 3888977 AND recordDateTime = '2017-03-01 00:12:58';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-02-28 00:00:00'
WHERE paymentProfileID = 8950692
AND recordDateTime = '2017-03-01 08:00:00'
AND '2017-02' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8950692 AND recordDateTime = '2017-03-01 08:00:00';

-- March 2017 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 6378740 
AND recordDateTime = '2017-04-01 00:14:56' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 6378740 AND recordDateTime = '2017-04-01 00:14:56';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 8976625 AND recordDateTime = '2017-03-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 6790359
AND recordDateTime = '2017-04-03 17:24:26' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6378740 AND recordDateTime = '2017-04-03 17:24:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 7393150 
AND recordDateTime = '2017-04-03 16:32:05' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7393150 AND recordDateTime = '2017-04-03 16:32:05';


UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 7277306
AND recordDateTime = '2017-04-03 15:33:09' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7277306 AND recordDateTime = '2017-04-03 15:33:09';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 7603634
AND recordDateTime = '2017-04-03 14:45:53' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7603634 AND recordDateTime = '2017-04-03 14:45:53';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 9008383
AND recordDateTime = '2017-04-04 07:00:00' 
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9008383 AND recordDateTime = '2017-04-04 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 2773728
AND recordDateTime = '2017-04-04 14:51:44' 
AND recordType = 'UPGRADES'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2773728 AND recordDateTime = '2017-04-04 14:51:44';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-03-31 00:00:00'
WHERE paymentProfileID = 8327141
AND recordDateTime = '2017-04-04 23:03:35'
AND '2017-03' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8327141 AND recordDateTime = '2017-04-04 07:00:00';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9129821 AND recordDateTime = '2017-04-04 23:04:31';

-- April 2017 fixes

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 9181928 
AND recordType = 'LOSSES' 
AND recordDateTime = '2017-04-07 21:35:14';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 7367173 
AND recordType = 'UPGRADES' 
AND recordDateTime = '2017-04-07 17:34:41'; 

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '2094.67000000000000',
	MonthlyPaymentChange = '131.66'
WHERE paymentProfileID = 2773728
	AND recordDateTime = '2017-04-05 17:41:37'
	AND '2017-04' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
	
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 5593965 AND recordType = 'LOSSES' AND recordDateTime = '2017-04-28 19:15:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-04-30 00:00:00'
WHERE paymentProfileID = 9366137 AND recordDateTime = '2017-05-03 16:41:07'
AND '2017-04' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9366137 AND recordDateTime = '2017-05-03 16:41:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-04-30 00:00:00'
WHERE paymentProfileID = 9374269 AND recordDateTime = '2017-05-04 07:00:00'
AND '2017-04' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET recordType = 'UPGRADES',
domainLevelRecordType = 'EXPANSION',
recordTypeNew = 'UPGRADES',
domainLevelRecordType = 'EXPANSION',
OldMonthlyPayment = '1050.00000000000000',
MonthlyPaymentChange = '700.00'
WHERE paymentProfileID = 9374269 AND recordDateTime = '2017-05-04 07:00:00';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8958624 AND recordDateTime = '2017-04-13 14:25:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordType = 'DOWNGRADES', domainLevelRecordType = 'DOWNGRADES', recordTypeNew = 'REDUCTION', domainLevelRecordTypeNew = 'REDUCTION',
MonthlyPaymentChange = '-75.00',
OldMonthlyPayment = '1325.00',
NewMonthlyPayment = '1250.00'
WHERE paymentProfileID = 8667587 AND recordDateTime = '2017-04-13 16:54:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '18357.50000000000000',
MonthlyPaymentChange = '2470.83'
WHERE paymentProfileID = 2080166
AND recordDateTime = '2017-04-30 21:43:32'
AND '2017-04' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

-- May 2017 Fixes

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9342446 AND recordDateTime = '2017-04-28 07:00:00';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9342446 AND recordDateTime = '2017-05-08 22:14:39';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9334475 AND recordType = 'LOSSES' AND recordDateTime = '2017-05-03 16:33:50';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9366137 AND recordDateTime = '2017-05-03 16:41:07';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5594228 AND recordType = 'LOSSES' AND recordDateTime = '2017-05-16 14:53:00';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5594228 AND recordType = 'LOSSES' AND recordDateTime = '2017-05-16 14:53:00';


DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2080166 AND recordDateTime = '2017-05-04 20:57:20';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET MonthlyPaymentChange = 190.00,
	recordType = 'DOWNGRADES',
	recordTypeNew = 'REDUCTION',
	domainLevelRecordType = 'DOWNGRADES',
	domainLevelRecordTypeNew = 'REDUCTION'
WHERE paymentProfileID = 4764486 AND recordDateTime = '2017-05-03 17:03:59'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8261476 AND recordDateTime = '2017-05-01 17:08:26';

/* UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9535767
AND recordDateTime = '2017-06-01 07:00:00'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m'); */

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9535767 AND recordDateTime = '2017-06-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9536709
AND recordDateTime = '2017-06-01 07:00:00'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9536709 AND recordDateTime = '2017-06-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9358478
AND recordDateTime = '2017-06-01 07:00:00'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9358478 AND recordDateTime = '2017-06-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET NewMonthlyPayment = '351.67',
	MonthlyPaymentChange = '308.24'
WHERE paymentProfileID = 8362791
AND recordDateTime = '2017-05-12 04:08:16'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8362791 AND recordDateTime = '2017-06-01 16:58:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9535710
AND recordDateTime = '2017-06-01 07:00:00'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9535710 AND recordDateTime = '2017-06-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9532721
AND recordDateTime = '2017-06-01 00:13:48'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9532721 AND recordDateTime = '2017-06-01 00:13:48';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 1401533
AND recordDateTime = '2017-06-01 19:43:29'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 1401533 AND recordDateTime = '2017-06-01 19:43:29';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9536881
AND recordDateTime = '2017-06-01 07:00:00'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9536881 AND recordDateTime = '2017-06-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 9236637
AND recordDateTime = '2017-06-01 01:23:17'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9236637 AND recordDateTime = '2017-06-01 01:23:17';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-05-31 00:00:00'
WHERE paymentProfileID = 6358599
AND recordDateTime = '2017-06-01 02:02:49'
AND '2017-05' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6358599 AND recordDateTime = '2017-06-01 02:02:49';

-- June 2017 Fixes

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2357704 AND recordDateTime = '2017-06-07 16:15:12';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8572156 AND recordDateTime = '2017-06-15 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2017-06-30 00:00:00'
WHERE paymentProfileID = 7520384
AND recordDateTime = '2017-07-01 00:08:46'
AND '2017-06' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7520384 AND recordDateTime = '2017-07-01 00:08:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2017-06-30 00:00:00'
WHERE paymentProfileID = 2785215
AND recordDateTime = '2017-07-12 18:14:23'
AND '2017-06' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2785215 AND recordDateTime = '2017-07-01 00:17:55';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2017-06-30 00:00:00'
WHERE paymentProfileID = 2932113
AND recordDateTime = '2017-07-06 21:07:35'
AND '2017-06' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2932113 AND recordDateTime = '2017-07-06 21:07:35';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2017-06-30 00:00:00'
WHERE paymentProfileID = 3812596
AND recordDateTime = '2017-07-06 18:19:16'
AND '2017-06' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 3812596 AND recordDateTime = '2017-07-06 18:19:16';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2017-06-30 00:00:00'
WHERE paymentProfileID = 6358369
AND recordDateTime = '2017-07-06 22:12:36'
AND '2017-06' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6358369 AND recordDateTime = '2017-07-06 22:12:36';

-- July 2017 Manual Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846754
AND recordDateTime = '2017-08-01 00:52:48'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846754 AND recordDateTime = '2017-08-01 00:52:48';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9165970
AND recordDateTime = '2017-08-01 00:47:52'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9165970 AND recordDateTime = '2017-08-01 00:47:52';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9175529
AND recordDateTime = '2017-08-01 00:49:43'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9175529 AND recordDateTime = '2017-08-01 00:49:43';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 4186928
AND recordDateTime = '2017-08-01 18:20:07'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 4186928 AND recordDateTime = '2017-08-01 18:20:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 6415592
AND recordDateTime = '2017-08-01 17:57:59'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6415592 AND recordDateTime = '2017-08-01 17:57:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9849288
AND recordDateTime = '2017-08-01 04:00:00'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9849288 AND recordDateTime = '2017-08-01 04:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 6001018
AND recordDateTime = '2017-08-01 20:50:31'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6001018 AND recordDateTime = '2017-08-01 20:50:31';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9851121
AND recordDateTime = '2017-08-01 07:00:00'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9851121 AND recordDateTime = '2017-08-01 07:00:00'; */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846685
AND recordDateTime = '2017-08-01 00:31:56'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846685 AND recordDateTime = '2017-08-01 00:31:56';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846656
AND recordDateTime = '2017-08-01 00:20:14'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846656 AND recordDateTime = '2017-08-01 00:20:14'; */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846629
AND recordDateTime = '2017-08-01 00:13:10'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846629 AND recordDateTime = '2017-08-01 00:13:10';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 6202135
AND recordDateTime = '2017-08-01 00:45:01'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6202135 AND recordDateTime = '2017-08-01 00:45:01';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 7690272
AND recordDateTime = '2017-08-01 00:21:26'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7690272 AND recordDateTime = '2017-08-01 00:21:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 8700326
AND recordDateTime = '2017-08-01 22:59:06'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8700326 AND recordDateTime = '2017-08-01 22:59:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 8603668
AND recordDateTime = '2017-08-01 00:08:25'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8603668 AND recordDateTime = '2017-08-01 00:08:25';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 8603668
AND recordDateTime = '2017-08-01 00:08:25'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8603668 AND recordDateTime = '2017-08-01 00:08:25';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846662
AND recordDateTime = '2017-08-01 00:20:33'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846662 AND recordDateTime = '2017-08-01 00:20:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 7892250
AND recordDateTime = '2017-08-01 00:24:49'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7892250 AND recordDateTime = '2017-08-01 00:24:49';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9297843
AND recordDateTime = '2017-08-01 00:07:02'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9297843 AND recordDateTime = '2017-08-01 00:07:02';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846599
AND recordDateTime = '2017-08-01 00:03:42'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846599 AND recordDateTime = '2017-08-01 00:03:42';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9311202
AND recordDateTime = '2017-08-01 20:48:24'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9311202 AND recordDateTime = '2017-08-01 20:48:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846679
AND recordDateTime = '2017-08-01 00:28:50'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846679 AND recordDateTime = '2017-08-01 00:28:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 3570810
AND recordDateTime = '2017-08-01 00:01:22'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 3570810 AND recordDateTime = '2017-08-01 00:01:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9846935
AND recordDateTime = '2017-08-01 01:53:44'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9846935 AND recordDateTime = '2017-08-01 01:53:44';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9364842
AND recordDateTime = '2017-08-01 00:16:44'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9364842 AND recordDateTime = '2017-08-01 00:16:44';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 8933478
AND recordDateTime = '2017-08-01 00:44:20'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8933478 AND recordDateTime = '2017-08-01 00:44:20';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9852020
AND recordDateTime = '2017-08-01 04:00:00'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9852020 AND recordDateTime = '2017-08-01 04:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET 	NewMonthlyPayment = '300.00',
	MonthlyPaymentChange = '75.00'
WHERE paymentProfileID = 7393160
AND recordDateTime = '2017-07-18 19:01:11'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7393160 AND recordDateTime = '2017-08-01 22:01:48';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 2759740
AND recordDateTime = '2017-08-02 15:21:58'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 2759740 AND recordDateTime = '2017-08-02 15:21:58';


DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9851625 AND recordDateTime = '2017-08-02 15:21:58';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9757590 AND recordDateTime = '2017-08-01 17:40:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 6663372
AND recordDateTime = '2017-08-02 18:53:13'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 6663372 AND recordDateTime = '2017-08-02 18:53:13';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 7959982
AND recordDateTime = '2017-08-02 15:29:07'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7959982 AND recordDateTime = '2017-08-02 15:29:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 8434422
AND recordDateTime = '2017-08-02 18:34:14'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8434422 AND recordDateTime = '2017-08-02 18:34:14';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 7152204
AND recordDateTime = '2017-08-02 17:28:36'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7152204 AND recordDateTime = '2017-08-02 17:28:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-07-31 00:00:00'
WHERE paymentProfileID = 9706705
AND recordDateTime = '2017-08-02 16:43:09'
AND '2017-07' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9706705 AND recordDateTime = '2017-08-02 16:43:09';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9477951 AND recordDateTime = '2017-07-11 07:00:00';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 9477951 AND recordDateTime = '2017-08-01 17:36:56';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7477184 AND recordDateTime = '2017-07-18 20:31:24';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 7477184 AND recordDateTime = '2017-08-01 18:57:31';


-- August 2017 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 6114449
AND recordDateTime = '2017-09-01 16:52:05'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6114449 AND recordDateTime = '2017-09-01 16:52:05';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 1282951
AND recordDateTime = '2017-09-01 17:40:03'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 1282951 AND recordDateTime = '2017-09-01 17:40:03';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 8159037
AND recordDateTime = '2017-09-01 16:03:35'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8159037 AND recordDateTime = '2017-09-01 16:03:35';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 5521433
AND recordDateTime = '2017-09-01 00:10:02'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5521433 AND recordDateTime = '2017-09-11 16:32:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 6330189
AND recordDateTime = '2017-09-01 00:17:33'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6330189 AND recordDateTime = '2017-09-01 00:17:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET OldMonthlyPayment = 14972.92000000000000,
	MonthlyPaymentChange = '414.16'
WHERE paymentProfileID = 6330189 AND recordDateTime = '2017-09-19 16:32:37';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 2163193
AND recordDateTime = '2017-09-01 15:24:54'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2163193 AND recordDateTime = '2017-09-01 15:24:54';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 9260895
AND recordDateTime = '2017-09-01 20:15:56'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9260895 AND recordDateTime = '2017-09-06 18:04:15';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-08-31 00:00:00'
WHERE paymentProfileID = 10012468
AND recordDateTime = '2017-09-01 07:00:00'
AND '2017-08' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10012468 AND recordDateTime = '2017-09-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = 333.00,
MonthlyPaymentChange = 83.25
WHERE paymentProfileID = 7152204
AND recordDateTime = '2017-08-29 22:08:30';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = 975.00000000000000,
MonthlyPaymentChange = 585.00
WHERE paymentProfileID = 9851121
AND recordDateTime = '2017-08-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = 1424.00,
MonthlyPaymentChange = 416.67
WHERE paymentProfileID = 8700326
AND recordDateTime = '2017-08-21 15:15:30';

delete from rpt_main_02.output_RevenueSummaryMonthly where paymentProfileID = 10012447 and recordDateTime = '2017-09-01 07:00:00';

-- September 2017 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesAssisted = 1,
salesRep = "Gene Um",
salesRepRole = "CDM"
WHERE paymentProfileID = 10010041 and recordDateTime = '2017-09-01 05:42:37';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-09-30 00:00:00'
WHERE paymentProfileID = 10180944
AND recordDateTime = '2017-10-01 00:49:47'
AND '2017-09' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10180944 AND recordDateTime = '2017-10-01 00:49:47';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-09-30 00:00:00'
WHERE paymentProfileID = 4097567
AND recordDateTime = '2017-10-02 21:31:22'
AND '2017-09' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4097567 AND recordDateTime = '2017-10-02 21:31:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-09-30 00:00:00'
WHERE paymentProfileID = 6966902
AND recordDateTime = '2017-10-02 23:54:38'
AND '2017-09' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6966902 AND recordDateTime = '2017-10-02 23:54:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-09-30 00:00:00'
WHERE paymentProfileID = 7880496
AND recordDateTime = '2017-10-02 20:07:04'
AND '2017-09' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7880496 AND recordDateTime = '2017-10-02 20:07:04';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-09-30 00:00:00'
WHERE paymentProfileID = 8181380
AND recordDateTime = '2017-10-03 17:56:19'
AND '2017-09' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8181380 AND recordDateTime = '2017-10-03 17:56:19';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
set salesRepRole = 'NAS' 
where date_format(recordDateTime,'%Y-%m') = '2017-09' and salesRep IN ('Kelsey Witt','Nick Carey','David Sparks','Rachel Klausner');

-- October 2017 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 7597992
AND recordDateTime = '2017-11-01 01:38:45'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 7597992 and recordDateTime = '2017-11-01 01:38:45';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 10386696
AND recordDateTime = '2017-11-01 07:00:00'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 10386696 and recordDateTime = '2017-11-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 10386860
AND recordDateTime = '2017-11-01 07:00:00'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 10386860 and recordDateTime = '2017-11-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 8181380
AND recordDateTime = '2017-11-01 14:58:33'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 8181380 and recordDateTime = '2017-11-01 14:58:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 10245419
AND recordDateTime = '2017-11-01 07:00:00'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 10245419 and recordDateTime = '2017-11-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 8623222
AND recordDateTime = '2017-11-01 15:12:06'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 8623222 and recordDateTime = '2017-11-01 15:12:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 8826957
AND recordDateTime = '2017-11-01 15:09:58'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 8826957 and recordDateTime = '2017-11-01 15:09:58';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 10395041
AND recordDateTime = '2017-11-02 07:00:00'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 10395041 and recordDateTime = '2017-11-02 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-10-31 00:00:00'
WHERE paymentProfileID = 5101743
AND recordDateTime = '2017-11-01 23:57:37'
AND '2017-10' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 7597992 and recordDateTime = '2017-11-01 01:38:45';

delete from rpt_main_02.output_RevenueSummaryMonthly 
where paymentPRofileID = 5101743 and recordDateTime = '2017-11-01 23:57:37';

-- UPDATE rpt_main_02.output_RevenueSummaryMonthly 
-- set salesRepRole = 'NBR' 
-- where date_format(recordDateTime,'%Y-%m') = '2017-10' and salesRep IN ('Nick Nordal', 'Chad Johnson', 'Ryan Comerford','Kyle Backstrom');

-- November 2017 Fixes

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8826957 AND recordDateTime = '2017-11-27 19:17:58';
DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 10170700 AND recordDateTime = '2017-11-01 07:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571992
AND recordDateTime = '2017-12-01 03:39:01'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571992 AND recordDateTime = '2017-12-01 03:39:01';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 8494095
AND recordDateTime = '2017-12-01 01:10:22'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 8494095 AND recordDateTime = '2017-12-01 01:10:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 6591681
AND recordDateTime = '2017-12-01 18:09:17'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 6591681 AND recordDateTime = '2017-12-01 18:09:17';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 8905473
AND recordDateTime = '2017-12-01 17:52:50'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 8905473 AND recordDateTime = '2017-12-01 17:52:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10178396
AND recordDateTime = '2017-12-01 00:47:45'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10178396 AND recordDateTime = '2017-12-01 00:47:45';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 9257489
AND recordDateTime = '2017-12-01 17:54:15'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 9257489 AND recordDateTime = '2017-12-01 17:54:15';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 4607612
AND recordDateTime = '2017-12-01 01:20:26'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 4607612 AND recordDateTime = '2017-12-01 01:20:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10416299
AND recordDateTime = '2017-12-01 00:56:38'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10416299 AND recordDateTime = '2017-12-01 00:56:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10574886
AND recordDateTime = '2017-12-01 08:00:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10574886 AND recordDateTime = '2017-12-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 7284875
AND recordDateTime = '2017-12-01 00:53:20'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 7284875 AND recordDateTime = '2017-12-01 00:53:20';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10474435
AND recordDateTime = '2017-12-01 00:26:14'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10474435 AND recordDateTime = '2017-12-01 00:26:14';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571226
AND recordDateTime = '2017-12-01 00:09:33'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571226 AND recordDateTime = '2017-12-01 00:09:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571401
AND recordDateTime = '2017-12-01 00:49:07'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571401 AND recordDateTime = '2017-12-01 00:49:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10507226
AND recordDateTime = '2017-12-01 00:24:34'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10507226 AND recordDateTime = '2017-12-01 00:24:34';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10069802
AND recordDateTime = '2017-12-01 00:41:59'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10069802 AND recordDateTime = '2017-12-01 00:41:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 8366670
AND recordDateTime = '2017-12-01 00:01:06'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 8366670 AND recordDateTime = '2017-12-01 00:01:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571472
AND recordDateTime = '2017-12-01 01:05:16'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571472 AND recordDateTime = '2017-12-01 01:05:16';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10572014
AND recordDateTime = '2017-12-01 03:48:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10572014 AND recordDateTime = '2017-12-01 03:48:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571161
AND recordDateTime = '2017-12-01 01:15:59'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571161 AND recordDateTime = '2017-12-01 01:15:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571161
AND recordDateTime = '2017-12-01 01:15:59'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571161 AND recordDateTime = '2017-12-01 01:15:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571345
AND recordDateTime = '2017-12-01 00:38:36'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571345 AND recordDateTime = '2017-12-01 00:38:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571482
AND recordDateTime = '2017-12-01 01:11:31'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571482 AND recordDateTime = '2017-12-01 01:11:31';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 6973325
AND recordDateTime = '2017-12-01 00:20:06'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 6973325 AND recordDateTime = '2017-12-01 00:20:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571318
AND recordDateTime = '2017-12-01 00:32:28'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10571318 AND recordDateTime = '2017-12-01 00:32:28';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10572041
AND recordDateTime = '2017-12-01 03:55:59'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10572041 AND recordDateTime = '2017-12-01 03:55:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 2410026
AND recordDateTime = '2017-12-01 17:13:59'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 2410026 AND recordDateTime = '2017-12-01 17:13:59';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 4342597
AND recordDateTime = '2017-12-01 00:58:46'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 4342597 AND recordDateTime = '2017-12-01 00:58:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 4528183
AND recordDateTime = '2017-12-01 19:33:17'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 4528183 AND recordDateTime = '2017-12-01 19:33:17';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 8605182
AND recordDateTime = '2017-12-01 03:26:05'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 8605182 AND recordDateTime = '2017-12-01 03:26:05';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 9610316
AND recordDateTime = '2017-12-01 22:13:06'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 9610316 AND recordDateTime = '2017-12-01 22:13:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10465908
AND recordDateTime = '2017-12-01 00:27:31'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10465908 AND recordDateTime = '2017-12-01 00:27:31';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 4086059
AND recordDateTime = '2017-12-01 16:49:31'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 4086059 AND recordDateTime = '2017-12-01 16:49:31';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 5359175
AND recordDateTime = '2017-12-01 00:44:16'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 5359175 AND recordDateTime = '2017-12-01 00:44:16';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10577173
AND recordDateTime = '2017-12-01 08:00:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10577173 AND recordDateTime = '2017-12-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10577293
AND recordDateTime = '2017-12-01 08:00:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10577293 AND recordDateTime = '2017-12-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10577320
AND recordDateTime = '2017-12-01 08:00:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10577320 AND recordDateTime = '2017-12-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 6830597
AND recordDateTime = '2017-12-01 23:17:00'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 6830597 AND recordDateTime = '2017-12-07 18:51:37';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-11-30 00:00:00'
WHERE paymentProfileID = 10571342
AND recordDateTime = '2017-12-01 00:37:34'
AND '2017-11' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 6830597 AND recordDateTime = '2017-12-01 00:37:34';

-- December 2017 fixes

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 5359175 AND recordDateTime = '2017-12-19 18:27:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '537.00',
	MonthlyPaymentChange = '87.00',
	monthFriendly = '2017-09(Sep)'
WHERE paymentProfileID = 10416299 AND recordDateTime = '2017-12-12 21:16:09';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '258.83000000000000',
	MonthlyPaymentChange = '41.84',
	monthFriendly = '2017-09(Sep)'
WHERE paymentProfileID = 7284875 AND recordDateTime = '2017-12-19 23:46:08';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 9342341
AND recordDateTime = '2018-01-02 16:59:21'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 9342341 AND recordDateTime = '2018-01-02 16:59:21';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '6080.00',
	MonthlyPaymentChange = '670.00',
	monthFriendly = '2017-11(Nov)'
WHERE paymentProfileID = 9342341 AND recordDateTime = '2018-01-18 16:19:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 7937425
AND recordDateTime = '2018-01-02 16:49:58'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 7937425 AND recordDateTime = '2018-01-02 16:49:58';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 3760270
AND recordDateTime = '2018-01-02 17:05:42'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 3760270 AND recordDateTime = '2018-01-02 17:05:42';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '6080.00',
	MonthlyPaymentChange = '670.00',
	monthFriendly = '2017-11(Nov)'
WHERE paymentProfileID = 9342341 AND recordDateTime = '2018-01-18 16:19:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 4582166
AND recordDateTime = '2018-01-02 21:36:14'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 4582166 AND recordDateTime = '2018-01-02 21:36:14';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 5607747
AND recordDateTime = '2018-01-02 20:50:57'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 5607747 AND recordDateTime = '2018-01-02 20:50:57';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 9511569
AND recordDateTime = '2018-01-02 18:01:05'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 9511569 AND recordDateTime = '2018-01-02 18:01:05';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET NewMonthlyPayment = '10162.50',
MonthlyPaymentChange = '1027.50',
recordType = 'UPGRADES',
domainLevelRecordType = 'UPGRADES',
recordTypeNew = 'EXPANSION',
domainLevelRecordTypeNew = 'EXPANSION'
WHERE paymentProfileID = 2932113 AND recordDateTime = '2017-12-29 20:43:49';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 2932113 AND recordDateTime = '2018-01-02 18:20:04';

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET NewMonthlyPayment = '600.00',
MonthlyPaymentChange = '450.00'
WHERE paymentProfileID = 10433165 AND recordDateTime = '2017-12-28 19:26:12';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 10433165 AND recordDateTime = '2018-01-02 20:38:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 10757018
AND recordDateTime = '2018-01-02 08:00:00'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 10757018 AND recordDateTime = '2018-01-02 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 10757202
AND recordDateTime = '2018-01-02 08:00:00'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 10757202 AND recordDateTime = '2018-01-02 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 5546814
AND recordDateTime = '2018-01-02 21:59:00'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 5546814 AND recordDateTime = '2018-01-02 21:59:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordDateTime = '2017-12-31 00:00:00'
WHERE paymentProfileID = 6074334
AND recordDateTime = '2018-01-02 16:53:58'
AND '2017-12' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 6074334 AND recordDateTime = '2018-01-02 16:53:58';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET OldMonthlyPayment = '110.83000000000000',
	MonthlyPaymentChange = '187.50',
	monthFriendly = '2017-11(Nov)'
WHERE paymentProfileID = 6074334 AND recordDateTime = '2018-01-26 20:47:26';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 8088288 and recordDateTime = '2017-12-07 17:00:04';

-- Jan 2018 Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET 	OldMonthlyPayment = '2250.00000000000000',
	MonthlyPaymentChange = '22.50'
WHERE paymentProfileID = 7937425 AND recordDateTime = '2018-01-18 17:56:11';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentPRofileID = 10759494 AND recordDateTime = '2018-01-02 08:00:00';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE paymentProfileID = 2810035 AND recordDateTime = '2018-01-30 00:44:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8366083
AND recordDateTime = '2018-02-01 18:25:54'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8366083 AND recordDateTime = '2018-02-01 18:25:54';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8673826
AND recordDateTime = '2018-02-01 00:09:28'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8673826 AND recordDateTime = '2018-02-01 00:09:28';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10950980
AND recordDateTime = '2018-02-01 17:12:50'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10950980 AND recordDateTime = '2018-02-01 17:12:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10950978
AND recordDateTime = '2018-02-01 00:01:15'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10950978 AND recordDateTime = '2018-02-01 00:01:15';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2517673
AND recordDateTime = '2018-02-01 00:04:53'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2517673 AND recordDateTime = '2018-02-01 00:04:53';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2477293
AND recordDateTime = '2018-02-01 00:18:41'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2477293 AND recordDateTime = '2018-02-01 00:18:41';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET NewMonthlyPayment = '473.67000000000000',
	MonthlyPaymentChange = '423.67'
WHERE paymentProfileID = 6306500
AND recordDateTime = '2018-01-21 17:00:06'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6306500 AND recordDateTime = '2018-02-01 00:09:29';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951054
AND recordDateTime = '2018-02-01 00:16:10'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951054 AND recordDateTime = '2018-02-01 00:16:10';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951031
AND recordDateTime = '2018-02-01 00:12:31'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951031 AND recordDateTime = '2018-02-01 00:12:31';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9385988
AND recordDateTime = '2018-02-01 17:03:03'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9385988 AND recordDateTime = '2018-02-01 17:03:03';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951048
AND recordDateTime = '2018-02-01 00:18:08'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951048 AND recordDateTime = '2018-02-01 00:18:08';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951091
AND recordDateTime = '2018-02-01 00:24:01'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951091 AND recordDateTime = '2018-02-01 00:24:01';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2144732
AND recordDateTime = '2018-02-01 00:23:49'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2144732 AND recordDateTime = '2018-02-01 00:23:49';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '95.29',
NewMonthlyPayment = '455.88'
WHERE paymentProfileID = 3759670
AND recordDateTime = '2018-01-29 18:34:59'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 3759670 AND recordDateTime = '2018-02-01 00:24:39';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6669363
AND recordDateTime = '2018-02-01 00:29:22'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6669363 AND recordDateTime = '2018-02-01 00:29:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10799526
AND recordDateTime = '2018-02-01 00:31:23'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10799526 AND recordDateTime = '2018-02-01 00:31:23';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951134
AND recordDateTime = '2018-02-01 00:44:58'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951134 AND recordDateTime = '2018-02-01 00:39:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 4081396
AND recordDateTime = '2018-02-01 00:39:38'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4081396 AND recordDateTime = '2018-02-01 00:39:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 3923713
AND recordDateTime = '2018-02-01 00:44:38'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 3923713 AND recordDateTime = '2018-02-01 00:44:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10629440
AND recordDateTime = '2018-02-01 00:46:21'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10629440 AND recordDateTime = '2018-02-01 00:46:21';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951175
AND recordDateTime = '2018-02-01 00:46:46'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951175 AND recordDateTime = '2018-02-01 00:46:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10076916
AND recordDateTime = '2018-02-01 00:45:57'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10076916 AND recordDateTime = '2018-02-01 00:45:57';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9917040
AND recordDateTime = '2018-02-01 00:48:07'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9917040 AND recordDateTime = '2018-02-01 00:48:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2080166
AND recordDateTime = '2018-02-01 00:52:06'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2080166 AND recordDateTime = '2018-02-01 00:52:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951201
AND recordDateTime = '2018-02-01 00:54:50'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951201 AND recordDateTime = '2018-02-01 00:54:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9634312
AND recordDateTime = '2018-02-01 00:57:27'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9634312 AND recordDateTime = '2018-02-01 00:57:27';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6804701
AND recordDateTime = '2018-02-01 01:32:29'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6804701 AND recordDateTime = '2018-02-01 01:32:29';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951232
AND recordDateTime = '2018-02-01 01:01:55'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951232 AND recordDateTime = '2018-02-01 01:01:55';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9793810
AND recordDateTime = '2018-02-01 02:08:39'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9793810 AND recordDateTime = '2018-02-01 02:08:39';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951386
AND recordDateTime = '2018-02-01 01:51:09'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951386 AND recordDateTime = '2018-02-01 01:51:09';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '3375.00',
NewMonthlyPayment = '3375.00'
WHERE paymentProfileID = 10480343
AND recordDateTime = '2018-01-22 08:00:00'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10480343 AND recordDateTime = '2018-02-01 01:52:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951408
AND recordDateTime = '2018-02-01 01:56:18'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951408 AND recordDateTime = '2018-02-01 01:56:18';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951408
AND recordDateTime = '2018-02-01 01:56:18'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951408 AND recordDateTime = '2018-02-01 01:56:18';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951387
AND recordDateTime = '2018-02-01 01:51:53'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951387 AND recordDateTime = '2018-02-01 01:51:53';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 3451808
AND recordDateTime = '2018-02-01 01:43:15'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 3451808 AND recordDateTime = '2018-02-01 01:43:15';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '113.33',
NewMonthlyPayment = '197.33'
WHERE paymentProfileID = 5761203
AND recordDateTime = '2018-01-31 23:10:46'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5761203 AND recordDateTime = '2018-02-01 01:39:25';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2210175
AND recordDateTime = '2018-02-01 01:38:50'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2210175 AND recordDateTime = '2018-02-01 01:38:50';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8033086
AND recordDateTime = '2018-02-01 01:40:12'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8033086 AND recordDateTime = '2018-02-01 01:40:12';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8033086
AND recordDateTime = '2018-02-01 01:37:08'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8033086 AND recordDateTime = '2018-02-01 01:37:08';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951344
AND recordDateTime = '2018-02-01 01:37:08'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951344 AND recordDateTime = '2018-02-01 01:37:08';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8114892
AND recordDateTime = '2018-02-01 01:34:33'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8114892 AND recordDateTime = '2018-02-01 01:34:33';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951325
AND recordDateTime = '2018-02-01 01:31:19'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951325 AND recordDateTime = '2018-02-01 01:31:19';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6804701
AND recordDateTime = '2018-02-01 01:31:19'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6804701 AND recordDateTime = '2018-02-01 01:31:19';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951330
AND recordDateTime = '2018-02-01 01:31:47'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951330 AND recordDateTime = '2018-02-01 01:31:47';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9507487
AND recordDateTime = '2018-02-01 01:24:03'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9507487 AND recordDateTime = '2018-02-01 01:24:03';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951300
AND recordDateTime = '2018-02-01 01:25:34'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951300 AND recordDateTime = '2018-02-01 01:25:34';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7903800
AND recordDateTime = '2018-02-01 01:25:42'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7903800 AND recordDateTime = '2018-02-01 01:25:42';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951303
AND recordDateTime = '2018-02-01 01:26:12'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951303 AND recordDateTime = '2018-02-01 01:26:12';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '133.00',
NewMonthlyPayment = '199.33000000000000'
WHERE paymentProfileID = 2502411
AND recordDateTime = '2018-01-31 05:24:40'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2502411 AND recordDateTime = '2018-02-01 05:50:38';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951281
AND recordDateTime = '2018-02-01 01:21:41'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951281 AND recordDateTime = '2018-02-01 01:21:41';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5668054
AND recordDateTime = '2018-02-01 01:19:02'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5668054 AND recordDateTime = '2018-02-01 01:19:02';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951227
AND recordDateTime = '2018-02-01 01:02:29'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951227 AND recordDateTime = '2018-02-01 01:02:29';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5686632
AND recordDateTime = '2018-02-01 01:15:55'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5686632 AND recordDateTime = '2018-02-01 01:15:55';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10791356
AND recordDateTime = '2018-02-01 01:07:55'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10791356 AND recordDateTime = '2018-02-01 01:07:55';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10314423
AND recordDateTime = '2018-02-01 01:08:06'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10314423 AND recordDateTime = '2018-02-01 01:08:06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 1695184
AND recordDateTime = '2018-02-02 19:57:22'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 1695184 AND recordDateTime = '2018-02-02 19:57:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5612682
AND recordDateTime = '2018-02-01 21:12:46'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5612682 AND recordDateTime = '2018-02-01 21:12:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5612682
AND recordDateTime = '2018-02-01 21:12:46'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5612682 AND recordDateTime = '2018-02-01 21:12:46';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951617
AND recordDateTime = '2018-02-01 03:00:26'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951617 AND recordDateTime = '2018-02-01 03:00:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 4926986
AND recordDateTime = '2018-02-01 02:40:37'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4926986 AND recordDateTime = '2018-02-01 02:40:37';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6001018
AND recordDateTime = '2018-02-01 02:25:26'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6001018 AND recordDateTime = '2018-02-01 02:25:26';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '150.00',
NewMonthlyPayment = '297.00'
WHERE paymentProfileID = 6243611
AND recordDateTime = '2018-01-18 23:54:41'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6243611 AND recordDateTime = '2018-02-01 19:49:28';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7800676
AND recordDateTime = '2018-02-01 16:57:14'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7800676 AND recordDateTime = '2018-02-01 16:57:14';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6897417
AND recordDateTime = '2018-02-01 16:35:49'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6897417 AND recordDateTime = '2018-02-01 16:35:49';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET monthlyPaymentChange = '326.41',
NewMonthlyPayment = '2766.67000000000000'
WHERE paymentProfileID = 8605136
AND recordDateTime = '2018-01-31 21:45:55'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8605136 AND recordDateTime = '2018-02-01 23:06:08';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5487636
AND recordDateTime = '2018-02-01 19:30:42'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5487636 AND recordDateTime = '2018-02-01 19:30:42';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9915321
AND recordDateTime = '2018-02-01 20:51:35'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9915321 AND recordDateTime = '2018-02-01 20:51:35';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7801463
AND recordDateTime = '2018-02-01 19:54:52'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7801463 AND recordDateTime = '2018-02-01 19:54:52';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8065322
AND recordDateTime = '2018-02-01 19:40:51'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8065322 AND recordDateTime = '2018-02-01 19:40:51';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 9728254
AND recordDateTime = '2018-02-01 21:27:51'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 9728254 AND recordDateTime = '2018-02-01 21:27:51';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10957990
AND recordDateTime = '2018-02-01 08:00:00'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10957990 AND recordDateTime = '2018-02-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2911900
AND recordDateTime = '2018-02-01 23:19:24'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2911900 AND recordDateTime = '2018-02-01 23:19:24';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 2427730
AND recordDateTime = '2018-02-01 21:48:40'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2427730 AND recordDateTime = '2018-02-01 21:48:40';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 4291641
AND recordDateTime = '2018-02-01 22:48:22'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4291641 AND recordDateTime = '2018-02-01 22:48:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 4291641
AND recordDateTime = '2018-02-01 22:48:22'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4291641 AND recordDateTime = '2018-02-01 22:48:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10709501
AND recordDateTime = '2018-02-01 16:52:10'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10709501 AND recordDateTime = '2018-02-01 16:52:10';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 4291641
AND recordDateTime = '2018-02-01 22:48:22'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 4291641 AND recordDateTime = '2018-02-01 22:48:22';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 5702295
AND recordDateTime = '2018-02-02 00:49:48'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5702295 AND recordDateTime = '2018-02-02 00:49:48';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10704644
AND recordDateTime = '2018-02-02 00:59:25'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10704644 AND recordDateTime = '2018-02-02 00:59:25';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET MonthlyPaymentChange = '74.00',
	NewMonthlyPayment = '10013.92',
	recordType = 'UPGRADES',
	domainLevelRecordType = 'UPGRADES',
	recordTypeNew = 'EXPANSION',
	domainLevelRecordTypeNew = 'EXPANSION'
WHERE paymentProfileID = 2415094 AND recordDateTime = '2018-01-05 21:53:54';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 2415094 AND recordDateTime = '2018-02-01 22:46:20';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7520384
AND recordDateTime = '2018-02-01 18:22:17'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7520384 AND recordDateTime = '2018-02-01 18:22:17';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET MonthlyPaymentChange = '3718.25',
	NewMonthlyPayment = '10763.50'
WHERE paymentProfileID = 5731902 AND recordDateTime = '2018-01-26 22:28:02'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET MonthlyPaymentChange = '1932',
	NewMonthlyPayment = '10105.67000000000000'
WHERE paymentProfileID = 6409707 AND recordDateTime = '2018-01-30 17:43:17'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6409707 AND recordDateTime = '2018-02-01 00:00:07';

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 5731902 AND recordDateTime = '2018-02-02 23:36:48';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10963431
AND recordDateTime = '2018-02-02 18:38:36'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10963431 AND recordDateTime = '2018-02-02 18:38:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8627421
AND recordDateTime = '2018-02-03 01:16:17'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8627421 AND recordDateTime = '2018-02-03 01:16:17';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7800919
AND recordDateTime = '2018-02-01 21:46:36'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7800919 AND recordDateTime = '2018-02-01 21:46:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8550605
AND recordDateTime = '2018-02-02 18:38:36'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8550605 AND recordDateTime = '2018-02-02 18:38:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951011
AND recordDateTime = '2018-02-01 00:08:20'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951011 AND recordDateTime = '2018-02-01 00:08:20';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 6089813
AND recordDateTime = '2018-02-01 17:51:49'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 6089813 AND recordDateTime = '2018-02-01 17:51:49';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951668
AND recordDateTime = '2018-02-01 03:19:52'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951668 AND recordDateTime = '2018-02-01 03:19:52';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10955924
AND recordDateTime = '2018-02-01 08:00:00'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10955924 AND recordDateTime = '2018-02-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10955409
AND recordDateTime = '2018-02-01 08:00:00'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10955409 AND recordDateTime = '2018-02-01 08:00:00';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8849515
AND recordDateTime = '2018-02-02 16:37:25'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8849515 AND recordDateTime = '2018-02-02 16:37:25';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10951154
AND recordDateTime = '2018-02-01 00:41:13'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10951154 AND recordDateTime = '2018-02-01 00:41:13';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8742660
AND recordDateTime = '2018-02-01 22:36:07'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8742660 AND recordDateTime = '2018-02-01 22:36:07';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 7159066
AND recordDateTime = '2018-02-01 23:29:47'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 7159066 AND recordDateTime = '2018-02-01 23:29:47';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 8627421
AND recordDateTime = '2018-02-02 18:38:36'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 8627421 AND recordDateTime = '2018-02-02 18:38:36';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET recordDateTime = '2018-01-31 00:00:00'
WHERE paymentProfileID = 10962741
AND recordDateTime = '2018-02-02 08:00:00'
AND '2018-01' >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE paymentProfileID = 10962741 AND recordDateTime = '2018-02-02 08:00:00';


-- End of all manual fixes


UPDATE rpt_main_02.output_RevenueSummaryMonthly rsm
JOIN ss_sfdc_02.opportunity opp ON opp.Parent_Payment_Profile_ID__c = rsm.paymentProfileID
	AND opp.StageName = "Closed Won" AND (opp.ARR_Variance__c > 0 OR (opp.ARR_Variance__c < 0 AND opp.Consolidation_ACV__c > 0))
	AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,rsm.recordDateTime),'%Y-%m-01')=DATE_FORMAT(opp.CloseDate,'%Y-%m-01')
SET rsm.ConsolidationACV = opp.Consolidation_ACV__c
WHERE DATE_FORMAT(rsm.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET ConsolidationMonthlyPaymentChange = (ConsolidationACV/12)
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
SET A.ispDomain = CASE WHEN isp.domain IS NOT NULL THEN 1 ELSE 0 END;

-- Code to catch finance PSD errors on the last day of the month

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET OldMonthlyPayment = 0,
MonthlyPaymentChange = NewMonthlyPayment,
recordType = 'WINS'
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m')
AND recordType = 'UPGRADES' AND MonthlyPaymentChange IS NULL AND DAYOFMONTH(NOW()) <= 7;

-- Code to remove win-loss combos that should be cancelled out

DROP TABLE IF EXISTS rpt_workspace.cDunn_winLossCancelOut;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_winLossCancelOut
(domain VARCHAR(100),
records INT,
paymentChange DECIMAL(10,2),
recordDateMonth VARCHAR(25),
maxPayment DECIMAL(10,2),
PRIMARY KEY (domain));

INSERT INTO rpt_workspace.cDunn_winLossCancelOut
SELECT domain, COUNT(DISTINCT(paymentProfileID)) AS 'Records', SUM(MonthlyPaymentChange) AS PaymentChange, DATE_FORMAT(recordDateTime, '%Y-%m'),
MAX(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m')
AND futureLoss IS NULL
GROUP BY 1,4
HAVING Records >= 2 AND PaymentChange = 0;

INSERT IGNORE INTO rpt_workspace.cDunn_winLossCancelOutHistory
SELECT A.*, CURRENT_DATE()
FROM rpt_workspace.cDunn_winLossCancelOut A
WHERE DAYOFMONTH(CURRENT_DATE()) = 2;

DELETE A FROM rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_workspace.cDunn_winLossCancelOut B ON A.domain = B.domain AND DATE_FORMAT(A.recordDateTime, '%Y-%m') = B.recordDateMonth
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* Consolidation Code */

DELETE FROM rpt_main_02.stg_consolidationARR 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

INSERT IGNORE INTO rpt_main_02.stg_consolidationARR
SELECT A.accountName, A.domain, A.paymentProfileID, A.MonthlyPaymentChange,
consolidationMonthlyPaymentChange, recordDateTime
FROM rpt_main_02.output_RevenueSummaryMonthly A
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
WHERE ConsolidationACV > 0 AND accountName NOT LIKE '%ISP' AND isp.domain IS NULL
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.stg_consolidationARR B ON A.paymentProfileID = B.paymentProfileID AND A.recordDateTime = B.recordDateTime
SET A.MonthlyPaymentChange = (A.MonthlyPaymentChange - A.ConsolidationMonthlyPaymentChange)
WHERE DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_workspace.cDunn_consolidationTransactions
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

INSERT IGNORE INTO rpt_workspace.cDunn_consolidationTransactions 
SELECT A.accountName, A.recordDateTime, A.MonthlyPaymentChange AS MRR, B.recordDateTime
FROM rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.stg_consolidationARR B ON A.accountName = B.accountName
WHERE A.recordType = 'LOSSES' AND A.recordDateTime >= B.recordDateTime AND A.recordDateTime <= DATE_ADD(B.recordDateTime, INTERVAL 60 DAY)
AND DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

DROP TABLE IF EXISTS rpt_workspace.cDunn_planReconciliation;
CREATE TABLE rpt_workspace.cDunn_planReconciliation
(accountName VARCHAR(100),
paymentProfileID BIGINT,
recordDateTime DATETIME,
MRRToConsolidate DECIMAL(10,2),
MRRConsolidated DECIMAL(10,2),
consolidationRemaining DECIMAL(10,2),
daysSinceUpgrade INT,
domain VARCHAR(100),
PRIMARY KEY (accountName, paymentProfileID));

INSERT INTO rpt_workspace.cDunn_planReconciliation
SELECT A.accountName, A.paymentProfileID, A.recordDateTime, A.ConsolidationMonthlyPaymentChange, IFNULL(SUM(B.MRR),0) AS MRR,
A.ConsolidationMonthlyPaymentChange + IFNULL(SUM(B.MRR),0) AS 'ConsolidationRemaining', DATEDIFF(CURRENT_DATE,A.recordDateTime) AS DaysSinceUpgrade,
A.domain
FROM rpt_main_02.stg_consolidationARR A
LEFT JOIN rpt_workspace.cDunn_consolidationTransactions B ON A.accountName = B.accountName
GROUP BY 1;

DELETE A
FROM rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.stg_consolidationARR B ON A.accountName = B.accountName
WHERE A.recordType = 'LOSSES' AND A.recordDateTime >= B.recordDateTime AND A.recordDateTime <= DATE_ADD(B.recordDateTime, INTERVAL 60 DAY)
AND DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

INSERT INTO rpt_main_02.output_RevenueSummaryMonthly  
	(monthFriendly, paymentProfileID, recordDateTime, recordType, recordTypeNew, domainLevelRecordType, domainLevelRecordTypeNew,
		MonthlyPaymentChange, OldProductName, NewProductName, currencyChange, accountName, startMonth, domain, OldMonthlyPayment)
	
SELECT DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)'), A.paymentProfileID, NOW(), 
CASE WHEN A.consolidationRemaining > 0 THEN "UPGRADES" ELSE "DOWNGRADES" END,
CASE WHEN A.consolidationRemaining > 0 THEN "EXPANSION" ELSE "REDUCTION" END,
CASE WHEN A.consolidationRemaining > 0 THEN "UPGRADES" ELSE "DOWNGRADES" END,
CASE WHEN A.consolidationRemaining > 0 THEN "EXPANSION" ELSE "REDUCTION" END,
consolidationRemaining, "ConsolidationUpdate", "ConsolidationUpdate", 0, A.accountName, DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00'),
A.domain,0
FROM rpt_workspace.cDunn_planReconciliation A
WHERE A.consolidationRemaining != 0
AND daysSinceUpgrade = 60;

INSERT IGNORE INTO rpt_workspace.cDunn_begOfMonthPlans
SELECT m.monthFriendly, m.startMonth, m.endMonth, hpp.paymentProfileID, hpp.productID, pp.mainContactDomain, SUM(hpp.planRate_USD/hpp.paymentTerm)
FROM rpt_main_02.ref_months m
JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.modifyDateTime <= m.startMonth
	AND hpp.hist_effectiveThruDateTime > m.startMonth AND m.startMonth < NOW()
STRAIGHT_JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = hpp.paymentProfileID
WHERE hpp.productID >= 3 AND hpp.planRate_USD > 0 AND hpp.paymentType IN(1,2,3,6,8,10) 
AND startMonth >= '2016-05-01'
AND DATE_FORMAT(startMonth, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
AND DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY 1,4
;

INSERT IGNORE INTO rpt_workspace.cDunn_domainRollupMonthly
SELECT startMonth, mainContactDomain, COUNT(*), SUM(MRR)
FROM rpt_workspace.cDunn_begOfMonthPlans
WHERE DATE_FORMAT(startMonth, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
AND DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY 1,2;

DELETE FROM rpt_workspace.cDunn_domainRollupMonthly WHERE startMonth IS NULL;

INSERT IGNORE INTO rpt_workspace.cDunn_allPlansPurchased
SELECT fwp.paymentProfileID, fwp.winDate, pp.mainContactDomain
FROM rpt_main_02.arc_paymentProfile_firstWinProduct fwp
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = fwp.paymentProfileID
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = pp.mainContactDomain
WHERE isp.domain IS NULL;

INSERT IGNORE INTO rpt_workspace.cDunn_allDomainsPurchased
SELECT m.startMonth, A.domain, COUNT(DISTINCT(A.paymentProfileID))
FROM rpt_workspace.cDunn_allPlansPurchased A
JOIN rpt_main_02.ref_months m ON A.winDate < m.startMonth
WHERE DATE_FORMAT(m.startMonth, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
AND DAYOFMONTH(CURRENT_DATE)=1
GROUP BY 1,2
;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT OUTER JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.domain = B.domain 
	AND DATE_FORMAT(A.recordDateTime, '%Y-%m-01 00:00:00') = B.startMonth
SET trueWin = 
	CASE WHEN ispDomain = 1 THEN 1
		WHEN B.domain IS NOT NULL THEN 0 ELSE 1 END
	WHERE recordType = 'WINS'
		AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
	
UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT OUTER JOIN rpt_workspace.cDunn_domainRollupMonthly B ON A.domain = B.mainContactDomain 
	AND DATE_FORMAT(A.recordDateTime, '%Y-%m-01 00:00:00') = B.startMonth AND Plans >= 2
SET trueLoss = 
	CASE WHEN ispDomain = 1 THEN 1
		WHEN B.mainContactDomain IS NOT NULL THEN 0 ELSE 1 END
	WHERE recordType = 'LOSSES'
		AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
	
UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET domainLevelRecordType =
	CASE WHEN recordType IN('UPGRADES','DOWNGRADES') THEN recordType
		WHEN recordType = 'WINS' AND trueWin = 1 THEN 'WINS' 
		WHEN recordType = 'WINS' AND trueWin = 0 THEN 'UPGRADES'
		WHEN recordType = 'LOSSES' AND trueLoss = 1 THEN 'LOSSES' 
		WHEN recordType = 'LOSSES' AND trueLoss = 0 THEN 'DOWNGRADES' END
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m'); 

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT OUTER JOIN rpt_workspace.cDunn_domainRollupMonthly B ON A.domain = B.mainContactDomain AND DATE_FORMAT(A.recordDateTime, '%Y-%m-01 00:00:00') = B.startMonth
SET A.domainStartingMRR = 
	CASE WHEN A.ispDomain = 1 THEN IFNULL(A.OldMonthlyPayment,0)
		ELSE IFNULL(B.MRR,0) END
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* Viral Sourcing Code */

DROP TABLE IF EXISTS rpt_main_02.stg_viralSourcingBookings;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_viralSourcingBookings
(userID BIGINT,
insertByUserID BIGINT,
domain VARCHAR(100),
insertByUserDomain VARCHAR(100),
isISP TINYINT,
insertByUserIsISP TINYINT,
sourceFriendly VARCHAR(100),
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_viralSourcingBookings
SELECT rsm.mainContactUserID, u.insertByUserID, u.domain, uu.domain AS inserterDomain, 
CASE WHEN isp1.domain IS NOT NULL THEN 1 ELSE 0 END AS isISP,
CASE WHEN isp2.domain IS NOT NULL THEN 1 ELSE 0 END AS sharerIsISP,
CASE WHEN isp1.domain IS NOT NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to ISP)'
	WHEN isp1.domain IS NOT NULL AND isp2.domain IS NULL THEN 'Sharing (Org to ISP)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to Org)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain = uu.domain THEN 'Sharing (Org to Org In Domain)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain != uu.domain THEN 'Sharing (Org to Org Out Domain)'
		END AS sourceFriendly
FROM rpt_main_02.output_RevenueSummaryMonthly rsm
JOIN rpt_main_02.userAccount u ON rsm.mainContactUserID = u.userID
JOIN rpt_main_02.userAccount uu ON uu.userID = u.insertByUserID
LEFT JOIN rpt_main_02.arc_ISPDomains isp1 ON isp1.domain = u.domain
LEFT JOIN rpt_main_02.arc_ISPDomains isp2 ON isp2.domain = uu.domain
WHERE rsm.SignupSubSourceFriendly = "Sharing"
AND DATE_FORMAT(rsm.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m')
GROUP BY 1
LIMIT 455454545
;

UPDATE rpt_main_02.output_RevenueSummaryMonthly rsm
JOIN rpt_main_02.stg_viralSourcingBookings B ON rsm.mainContactUserID = B.userID
SET rsm.SignupSourceFriendly = B.sourceFriendly;

UPDATE rpt_main_02.output_RevenueSummaryMonthly 
SET SignupSourceFriendly = 'Sharing (Inserted by Smartsheet FinOps)'
WHERE futureLoss IS NULL AND bucket = 'Viral' AND SignupSourceFriendly = 'Sharing' AND SignupSubSourceFriendly = 'Sharing';

UPDATE rpt_main_02.output_RevenueSummaryMonthly SET domainLevelRecordType = "DOWNGRADES"
WHERE monthlyPaymentChange < 0 AND ConsolidationACV > 0 AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

/* Updated Record Type Terminology 6-1-16 */

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET recordTypeNew = CASE WHEN recordType = 'WINS' THEN 'NEW'
			WHEN recordType = 'UPGRADES' THEN 'EXPANSION'
			WHEN recordType = 'DOWNGRADES' THEN 'REDUCTION'
			WHEN recordType = 'LOSSES' THEN 'CANCEL' END
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');


UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET domainLevelRecordTypeNew = CASE WHEN domainLevelRecordType = 'WINS' THEN 'NEW'
			WHEN domainLevelRecordType = 'UPGRADES' THEN 'EXPANSION'
			WHEN domainLevelRecordType = 'DOWNGRADES' THEN 'REDUCTION'
			WHEN domainLevelRecordType = 'LOSSES' THEN 'CANCEL' END
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
		
	
UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET startMonth = DATE_FORMAT(recordDateTime, '%Y-%m-01 00:00:00') WHERE startMonth IS NULL;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_workspace.pj_domainDataCoverage ddc ON ddc.domain = A.domain
SET A.companySize = ddc.companySize
WHERE A.companySize IS NULL
or A.companySize = 'Not Available';


UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET trialStartDate = (SELECT MAX(trialDateTime)
	FROM rpt_main_02.rpt_trials t
WHERE t.userID = A.mainContactUserID AND t.trialDateTime < A.recordDateTime)
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');


/*
alter table rpt_main_02.output_RevenueSummaryMonthly
add salesAssisted int,
add salesRep varchar(50),
add salesRepRole varchar(50),
add salesTeam varchar(50);
*/

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.parent_payment_profile_ID__c AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,A.recordDateTime),'%Y-%m-01')=DATE_FORMAT(B.CloseDate,'%Y-%m-01')
AND B.StageName='Closed Won' AND B.ARR_Variance__c > 0
LEFT JOIN ss_sfdc_02.user C
ON B.ownerID=C.Id
LEFT JOIN ss_sfdc_02.user_role D
ON C.userRoleId=D.Id
SET A.salesRep=CONCAT(C.firstName,' ',C.lastName), A.salesRepRole=B.Owner_Role_at_Close__c, A.salesAssisted= CASE WHEN B.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END
WHERE A.domainLevelRecordTypeNew IN ('NEW','EXPANSION') AND A.currencyChange=0 AND DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam=
CASE WHEN salesRepRole IN ('Commercial Sales', 'NAS', 'NAS Management', 'NBR', 'NBR Management','CDM','CDM Management','CDM Team Management', 'SDR', 'SDR Manager', 'Commercial SE', 'Commercial SE Manager') THEN 'Commercial Assisted'
WHEN salesRepRole IN ('ENT Sales', 'AE','BDR', 'Strategic SE', 'Strategic SE Manager') THEN 'Strategic'
WHEN salesRepRole IN ('Channel Sales', 'CSR') THEN 'Partner'
END
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam='Strategic'
WHERE salesRepRole NOT IN ('Commercial Sales', 'NAS', 'NAS Management', 'NBR', 'NBR Management','CDM','CDM Management','CDM Team Management', 'SDR', 'SDR Manager', 'Commercial SE', 'Commercial SE Manager', 'ENT Sales', 'AE', 'BDR', 'Strategic SE', 'Strategic SE Manager', 'Channel Sales', 'CSR')
AND territory IN ('EMEA','Los Angeles','Mid Atlantic','Midwest','Northeast','NY Metro','Pacific Northwest','Rust Belt','San Francisco','South Bay','South Central','Southeast 1','Southeast 2')
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam='Commercial Assisted'
WHERE salesRepRole NOT IN ('Commercial Sales', 'NAS', 'NAS Management', 'NBR', 'NBR Management','CDM','CDM Management','CDM Team Management', 'SDR', 'SDR Manager', 'Commercial SE', 'Commercial SE Manager', 'ENT Sales', 'AE', 'BDR', 'Strategic SE', 'Strategic SE Manager', 'Channel Sales', 'CSR')
AND (territory NOT IN ('EMEA','Los Angeles','Mid Atlantic','Midwest','Northeast','NY Metro','Pacific Northwest','Rust Belt','San Francisco','South Bay','South Central','Southeast 1','Southeast 2')
OR territory='' OR territory IS NULL)
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

-- Manual November 2017 Assisted Fixes

update rpt_main_02.output_RevenueSummaryMonthly
set salesRep = 'Matt Lane',
salesRepRole = 'NAS',
salesAssisted =1
where paymentProfileID= 10170700 and recordDateTime = '2017-11-01 07:00:00'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

update rpt_main_02.output_RevenueSummaryMonthly
set salesRep = 'Glenn Baker',
salesRepRole = 'AE',
salesAssisted =1
where paymentProfileID= 4964045 and recordDateTime = '2017-11-06 21:35:48'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

update rpt_main_02.output_RevenueSummaryMonthly
set salesRep = 'Ryan Raynis',
salesRepRole = 'AE',
salesAssisted =1
where paymentProfileID= 10383673 and recordDateTime = '2017-11-01 03:35:26'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

update rpt_main_02.output_RevenueSummaryMonthly
set salesRep = 'Nate Evans',
salesRepRole = 'CDM',
salesAssisted =1
where paymentProfileID= 1278982 and recordDateTime = '2017-11-02 16:18:48'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

update rpt_main_02.output_RevenueSummaryMonthly
set salesRep = 'Cam Becker',
salesRepRole = 'CDM',
salesAssisted =1
where paymentProfileID= 10425028 and recordDateTime = '2017-11-07 08:00:00'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

-- Rep role Fixes

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesRepRole = 'CDM' WHERE paymentProfileID = 7104557
AND recordDateTime = '2018-01-25 18:55:03';


/*
update rpt_main_02.output_RevenueSummaryMonthly
set salesRepRole='Strategic SE', salesTeam='Strategic'
where salesRep in ('Tom Zylstra','Max Zulauf');

update rpt_main_02.output_RevenueSummaryMonthly
set salesRepRole='CDM Team Management', salesTeam='Commercial Assisted'
where salesRep='Amir Khorram';

update rpt_main_02.output_RevenueSummaryMonthly
set salesTeam='Commercial Assisted', salesRepRole='CDM'
where salesRep='Drew Johansson' and recordDateTime < '2016-09-01';

update rpt_main_02.output_RevenueSummaryMonthly
set salesTeam='Commercial Assisted', salesRepRole='NAS'
where salesRep='Sarah Raasch' and recordDateTime < '2016-07-01';

update rpt_main_02.output_RevenueSummaryMonthly
set salesTeam='Commercial Assisted', salesRepRole='CDM'
where salesRep='Brian Vandenheuvel' and recordDateTime < '2016-04-01';

update rpt_main_02.output_RevenueSummaryMonthly
set salesTeam='Commercial Assisted', salesRepRole='NAS'
where salesRep='Sean MacKelvie' and recordDateTime < '2016-03-01';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='David Sparks' , salesRepRole='NAS', salesTeam='Commercial Assisted'
where paymentProfileID=8319157 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Colton Bielaski' , salesRepRole='NAS', salesTeam='Commercial Assisted'
where paymentProfileID=8324081 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Sean Jackson' , salesRepRole='CDM', salesTeam='Commercial Assisted'
where paymentProfileID=8325186 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Catrina Sheputis' , salesRepRole='NBR', salesTeam='Commercial Assisted'
where paymentProfileID=8116044 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Kari Cross' , salesRepRole='NAS', salesTeam='Commercial Assisted'
where paymentProfileID=8325689 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Lejuane Williams' , salesRepRole='NBR', salesTeam='Commercial Assisted'
where paymentProfileID=8319085 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Catrina Sheputis' , salesRepRole='NBR', salesTeam='Commercial Assisted'
where paymentProfileID=8163753 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Andrew Spence' , salesRepRole='CDM', salesTeam='Commercial Assisted'
where paymentProfileID=8325796 and monthFriendly= '2016-11(Nov)';

update rpt_main_02.output_RevenueSummaryMonthly
set salesAssisted=1, salesRep='Colton Bielaski' , salesRepRole='CDM', salesTeam='Commercial Assisted'
where paymentProfileID=8317392 and monthFriendly= '2016-11(Nov)';
*/

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam='Commercial Assisted', salesRepRole='CDM'
WHERE salesRep='Lee Rushing' AND recordDateTime < '2017-02-04';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam='Unassisted'
WHERE salesAssisted=0 AND domainLevelRecordTypeNew IN ('NEW','EXPANSION')
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam='Customer Success'
WHERE domainLevelRecordTypeNew IN ('CANCEL','REDUCTION')
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly WHERE paymentProfileID = 5635769 AND domainLevelRecordType IS NULL;

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesAssisted = 1, salesTeam = NULL 
WHERE NewProductName = 'ConsolidationUpdate'
AND DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
LEFT JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.parent_payment_profile_ID__c AND DATE_FORMAT(B.CloseDate,'%Y-%m') = '2017-05'
AND B.StageName='Closed Won' AND B.Amount>0 AND B.Product__c!='SERVICES'
LEFT JOIN ss_sfdc_02.user C
ON B.ownerID=C.Id
LEFT JOIN ss_sfdc_02.user_role D
ON C.userRoleId=D.Id
SET A.salesRep=CONCAT(C.firstName,' ',C.lastName), A.salesRepRole=D.Name, A.salesAssisted= CASE WHEN B.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END
WHERE A.paymentProfileID IN(9100941,7367173) AND DATE_FORMAT(A.recordDateTime, '%Y-%m') = '2017-06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly
SET salesTeam=
CASE WHEN salesRepRole IN ('Commercial Sales', 'NAS', 'NAS Management', 'NBR', 'NBR Management','CDM','CDM Management','CDM Team Management', 'SDR', 'SDR Manager', 'Commercial SE', 'Commercial SE Manager') THEN 'Commercial Assisted'
WHEN salesRepRole IN ('ENT Sales', 'AE','BDR', 'Strategic SE', 'Strategic SE Manager') THEN 'Strategic'
WHEN salesRepRole IN ('Channel Sales', 'CSR') THEN 'Partner'
END
WHERE paymentProfileID IN(9100941,7367173) AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2017-06';

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.ref_geoClassification B ON B.country = A.ipCountry
SET A.geoClassification = B.geoRegion
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.ref_emergingDevelopedMarkets B ON B.country = A.ipCountry
SET A.market= B.market
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DROP TABLE IF EXISTS rpt_workspace.cDunn_domainFirstMonth;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_domainFirstMonth
(domain VARCHAR(100),
startMonth DATETIME,
PRIMARY KEY (domain));

INSERT INTO rpt_workspace.cDunn_domainFirstMonth
SELECT domain, MIN(startMonth)
FROM rpt_workspace.cDunn_allDomainsPurchased
GROUP BY 1;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_workspace.cDunn_domainFirstMonth B ON A.domain = B.domain
SET A.newLogoMonth = DATE_SUB(B.startMonth, INTERVAL 1 MONTH)
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.output_RevenueSummaryMonthly B ON A.paymentProfileID = B.paymentProfileID AND B.domainLevelRecordType = 'WINS'
SET A.newLogoMonth = DATE_FORMAT(B.recordDateTime, '%Y-%m-01 00:00:00') 
WHERE A.ispDomain = 1 AND A.newLogoMonth IS NULL
AND DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.output_RevenueSummaryMonthly B ON A.mainContactUserID = B.mainContactUserID AND B.domainLevelRecordType = 'WINS'
SET A.newLogoMonth = DATE_FORMAT(B.recordDateTime, '%Y-%m-01 00:00:00') 
WHERE A.ispDomain = 1 AND A.newLogoMonth IS NULL
AND DATE_FORMAT(A.recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
;

DELETE FROM rpt_main_02.output_RevenueSummaryMonthly 
WHERE domainLevelRecordType IS NULL AND futureLoss IS NULL AND currencyChange = 0;

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
JOIN rpt_main_02.rpt_signupSource ss ON ss.userID = A.mainContactUserID
JOIN rpt_main_02.arc_integratedContentCategory B ON ss.slp = B.slpURL
SET 	A.slp = ss.slp,
	A.slpCategory = B.category
WHERE DATE_FORMAT(recordDateTime, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.output_RevenueSummaryMonthly A
SET MonthlyPaymentChange = '74.00',
	NewMonthlyPayment = '10013.92',
	recordType = 'UPGRADES',
	domainLevelRecordType = 'UPGRADES',
	recordTypeNew = 'EXPANSION',
	domainLevelRecordTypeNew = 'EXPANSION'
WHERE paymentProfileID = 2415094 AND recordDateTime = '2018-01-05 21:53:54';
			
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryMonthlyV2.csv insert");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryMonthlyV2.csv select");

DROP TABLE IF EXISTS rpt_main_02.output_RevenueSummaryMonthlyTableau;
CREATE TABLE IF NOT EXISTS rpt_main_02.output_RevenueSummaryMonthlyTableau
SELECT rsm.monthFriendly,
rsm.mainContactUserID,
rsm.paymentProfileID,
rsm.ownerID,
rsm.organization,
rsm.NewAccountType,
rsm.NewPaymentType,
rsm.OldAccountType,
rsm.OldPaymetType,
rsm.PaymentStartDate,
rsm.DaysToBuy,
rsm.NewProductName,
rsm.NewUserLimit,
rsm.NewPaymentTerm,
rsm.NewPaymentTermAnnual,
rsm.OldProductName,
rsm.OldUserLimit,
rsm.OldPaymentTerm,
rsm.OldPaymentTermAnnual,
rsm.NewMonthlyPayment,
rsm.OldMonthlyPayment,
rsm.MonthlyPaymentChange,
rsm.paymentProfileInsertDateTime,
rsm.modifyDateTime,
rsm.Bucket,
rsm.SignupSourceFriendly,
rsm.SignupSubSourceFriendly,
rsm.SignupCampaign,
rsm.SignupSegment,
rsm.recordtype,
rsm.ipCountry,
rsm.ipRegion,
rsm.ipCity,
rsm.recordDateTime,
rsm.excludeLoss,
rsm.currencyChange, 
ua.languageFriendly, 
rsm.domain AS Domain,
CASE 
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NULL THEN rsm.NewProductName 
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NOT NULL THEN rsm.OldProductName
ELSE rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID) END AS OriginalProductName,
CASE
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NULL THEN rpt_main_02.SMARTSHEET_PAYMENTTERM(rsm.NewPaymentTerm)
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NOT NULL THEN rpt_main_02.SMARTSHEET_PAYMENTTERM(rsm.OldPaymentTerm)
WHEN fwp.productID IS NOT NULL AND fwp.paymentTerm = 0 THEN rpt_main_02.SMARTSHEET_PAYMENTTERM(rsm.NewPaymentTerm)
ELSE rpt_main_02.SMARTSHEET_PAYMENTTERM(fwp.paymentTerm) END AS OriginalPaymentTerm,
CASE
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NULL THEN rsm.NewMonthlyPayment*12
WHEN fwp.productID IS NULL AND rsm.OldProductName IS NOT NULL THEN rsm.OldMonthlyPayment*12
ELSE (fwp.planRate_USD/fwp.paymentTerm)*12 END AS OriginalValue_ACV,
CASE WHEN rsm.paymentStartDate != MIN(rsm2.paymentStartDate) AND rsm.recordType = "WINS" THEN 1 ELSE 0 END AS ReWin,
CASE WHEN pp.mainContactDomain LIKE '%.edu%' THEN 1 ELSE 0 END AS IsEDU,
CASE WHEN pp.promoCode LIKE '%NONPROFIT%' THEN 1 ELSE 0 END AS IsNP,
rsm.salesAssisted,
rsm.salesRep,
rsm.salesRepRole,
rsm.salesTeam,
rsm.futureLoss,
rsm.reseller,
rsm.customerSuccess AS CustomerSuccess,
REPLACE(rsm.trpValue, '"','') AS trpvalue,
CASE WHEN ua.domain = 'ge.com' AND DATE_FORMAT(rsm.recordDateTime, '%Y-%m-%d') = '2015-12-22' 
	AND rsm.recordType = "LOSSES" THEN 1 ELSE 0 END AS DecGELoss,
	
	CASE WHEN opp.Security_Pack__c = 'true' THEN 1 ELSE 0 END AS 'SecurityPack',
	CASE WHEN opp.Integration_Pack__c = 'true' THEN 1 ELSE 0 END AS 'IntegrationPack',
	CASE WHEN opp.Dashboards__c = 'true' THEN 1 ELSE 0 END AS 'Sights',
	CASE WHEN opp.Salesforce_Integration__c = 'true' THEN 1 ELSE 0 END AS 'SalesforceIntegration',
	opp.Misc_ACV__c AS MiscACV,
rsm.ispDomain,
rsm.trueWin,
rsm.trueLoss,
rsm.domainLevelRecordType,
CASE WHEN opp.Dashboards__c = 'true' AND opp.Dashboard_Seats_Enabled__c > 0 THEN opp.Dashboard_Seats_Enabled__c 
	ELSE 0 END AS 'SightLicenses',
CASE WHEN opp.Dashboards__c = 'true' THEN
	CASE WHEN opp.Dashboard_Seats_Enabled__c IS NULL THEN 'Unbundled'
	WHEN opp.Dashboard_Seats_Enabled__c > 0 THEN 'Unbundled'
	 ELSE 'Bundled' END END AS "Bundled?",
	 rsm.recordTypeNew,
	 rsm.domainLevelRecordTypeNew,
	 rsm.trpCategory,
     rsm.lpv,
     rsm.lpa,
     rsm.companySize,
     rsm.lang,
     rsm.fortune1000,
     rsm.trialStartDate,
     rsm.territory,
     rsm.OldMonthlyPaymentLocal,
     rsm.NewMonthlyPaymentLocal,
     rsm.currencyCode,
     rsm.geoClassification,
     rsm.market,
     rsm.newLogoMonth,
     rsm.slp,
     rsm.slpCategory,
     (rsm.domainStartingMRR*12) as domainStartingARR
	

FROM rpt_main_02.output_RevenueSummaryMonthly rsm
LEFT OUTER JOIN rpt_main_02.userAccount ua ON rsm.mainContactUserID=ua.userID
LEFT OUTER JOIN rpt_main_02.arc_paymentProfile_firstWinProduct fwp ON rsm.paymentProfileID=fwp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly rsm2 ON rsm.mainContactUserID = rsm2.mainContactUserID AND rsm2.recordType = "WINS" 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile pp ON rsm.paymentProfileID=pp.paymentProfileID
LEFT JOIN  ss_sfdc_02.domain d ON ua.domain = d.Domain_Name_URL__c

LEFT OUTER JOIN
(
	SELECT o.*, CONCAT(u.firstName,' ',u.lastName) AS SalesRep, ur.name AS userRole
	FROM ss_sfdc_02.opportunity o
	LEFT JOIN ss_sfdc_02.user u ON o.ownerID=u.Id
	LEFT JOIN ss_sfdc_02.user_role ur ON u.userRoleId=ur.Id
	WHERE StageName = 'Closed Won'
	AND parent_payment_profile_ID__c IS NOT NULL 
	AND o.product__c != 'Services'
) opp ON rsm.paymentProfileID=opp.parent_payment_profile_ID__c
	AND DATE_FORMAT(TIMESTAMPADD(HOUR,-8,rsm.recordDateTime),'%Y-%m-01')=DATE_FORMAT(opp.CloseDate,'%Y-%m-01')

WHERE DATE_FORMAT(rsm.recordDateTime, '%Y-%m-%d') < CURRENT_DATE

GROUP BY 1,2,3,4,30	
HAVING DecGELoss = 0
ORDER BY recordDateTime DESC, mainContactUserID
;

UPDATE rpt_main_02.output_RevenueSummaryMonthlyTableau
SET salesAssisted = 1 
WHERE paymentProfileID IN(8979951,8979678,8090566,6658945) AND DATE_FORMAT(recordDateTime, '%Y-%m') = '2017-03';

SELECT * FROM  rpt_main_02.output_RevenueSummaryMonthlyTableau;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryMonthlyV2.csv select");
