SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard2V2.sql");

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
set sql_safe_updates=0;

DROP TABLE rpt_workspace.js_csNetBookings;
CREATE TABLE rpt_workspace.js_csNetBookings
(paymentProfileID int,
mainContactUserID int,
recordDateTime datetime,
planLevelRecordType varchar(50),
domainLevelRecordType varchar(50),
NewProductName varchar(50),
OldProductName varchar(50),
NewMonthlyPayment dec(10,2),
OldMonthlyPayment dec(10,2),
MonthlyPaymentChange dec(10,2),
NewUserLimit int,
OldUserLimit int,
OldPaymentTerm int,
OldPaymentType varchar(50),
paymentStartDate datetime,
domain varchar(50),
ISP int,
accountName varchar(100),
accountID varchar(100),
csRep varchar(50),
tier varchar(50),
health varchar(50),
cancellationComment varchar(100),
salesEngagement int,
csEngagement int,
lastContactDate date,
territory varchar(50),
segment varchar(50),
index (paymentProfileID),
index (recordDateTime),
index (domain),
index (accountID));

insert into rpt_workspace.js_csNetBookings(paymentProfileID, mainContactUserID, recordDateTime, planLevelrecordType, domainLevelRecordType, NewProductName, OldProductName, 
NewMonthlyPayment, OldMonthlyPayment, MonthlyPaymentChange, NewUserLimit, OldUserLimit, OldPaymentTerm, OldPaymentType, paymentStartDate, domain, accountName, accountID, 
csRep, tier, health, territory)
SELECT rsm.paymentProfileID, rsm.mainContactUserID, rsm.recordDateTime, rsm.recordTypeNew, rsm.domainLevelRecordTypeNew, rsm.NewProductName, rsm.OldProductName, rsm.NewMonthlyPayment, 
rsm.OldMonthlyPayment, rsm.MonthlyPaymentChange, rsm.NewUserLimit, rsm.OldUserLimit, rsm.OldPaymentTerm, rsm.OldPaymetType, rsm.PaymentStartDate, 
rsm.domain, acc.Name, acc.Id, rsm.customerSuccess, B.tier, B.health, acc.Territory__c
FROM rpt_main_02.output_RevenueSummaryMonthly rsm
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = rsm.domain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
LEFT OUTER JOIN rpt_workspace.js_csLastTierHealth B ON B.accountId = acc.Id
WHERE rsm.futureLoss IS NULL AND rsm.currencyChange = 0 and (rsm.MonthlyPaymentChange is not null or rsm.MonthlyPaymentChange!=0)
AND rsm.recordDateTime >= '2017-01-01' and acc.Customer_Success__c is not null and acc.Customer_Success__c!=' '
GROUP BY rsm.paymentProfileID, rsm.recordDateTime;

update rpt_workspace.js_csNetBookings A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set ISP=1;

update rpt_workspace.js_csNetBookings
set ISP=1
where accountName like '%ISP Account%' and ISP is null;

update rpt_workspace.js_csNetBookings
set csRep='CustomerSuccess@'
where (csRep is null or csRep in (' ', 'Tasha Bishop'));

update rpt_workspace.js_csNetBookings
set NewUserLimit=0
where planLevelRecordType='CANCEL';

update rpt_workspace.js_csNetBookings
set OldUserLimit=0
where OldUserLimit is null;

update rpt_workspace.js_csNetBookings
set segment=
case when territory like 'Mid-Market%' then 'Mid-Market' 
when territory like 'SMB%' then 'SMB' 
when territory like 'Major%' then 'Major'
when territory like 'Vertical Market: Retail%' then 'Retail'
when territory like 'Vertical Market: EDU%' then 'EDU'
when territory like 'Vertical Market: Healthcare%' then 'Healthcare'
when territory like 'Vertical Market: Gov%' then 'Gov'
when (territory like 'Unassigned%' or territory='') then 'No Territory'
else 'Strategic'
end;

update rpt_workspace.js_csNetBookings
set segment='CustomerSuccess@'
where csRep='CustomerSuccess@';

update rpt_workspace.js_csNetBookings A
set lastContactDate=
(select lastContactDate from rpt_workspace.js_lastContactDate B
where A.accountID=B.accountID);

update rpt_workspace.js_csNetBookings A
set cancellationComment=
(select cancelComment from rpt_main_02.rpt_cancelComment B
where A.paymentProfileID=B.parentPaymentProfileID and A.domainLevelRecordType='CANCEL' 
and DATE_FORMAT(A.recordDateTime,'%Y-%m-01')=DATE_FORMAT(B.cancelCommentDate,'%Y-%m-01') limit 1);

alter table rpt_workspace.js_csNetBookings
add customer varchar(50);

update rpt_workspace.js_csNetBookings
set customer=domain
where ISP is null;

update rpt_workspace.js_csNetBookings
set customer=concat(domain,'-',paymentProfileID)
where ISP=1;

update rpt_workspace.js_csNetBookings
set domain='cree.com', ISP=null, customer='cree.com', accountName='Cree, Inc.', accountId='0014000000mw0SpAAI', csRep='Reid Kilwine', 
territory='Major: East - Open (CDM)', segment='Major'
where paymentProfileID=6892090;

update rpt_workspace.js_csNetBookings
set domain='okq8.se', ISP=null, customer='okq8.se', accountName='OK-Q8', accountId='0013300001cH1XWAA0', csRep='Liz Tanonis', 
territory='Unassigned (CDM)', segment='No Territory'
where paymentProfileID=3975994;

update rpt_workspace.js_csNetBookings
set domain='ascension.org', ISP=null, customer='ascension.org', accountName='Ascension Health', accountId='0014000000uWnXWAA0', csRep='Johannah Brown',
territory='Major: East3 - Jennifer Abramowitz (CDM)', segment='Major'
where paymentProfileID=8494109;

update rpt_workspace.js_csNetBookings
set domain='cbre.com', ISP=null, customer='cbre.com', accountName='CB Richard Ellis Group', accountId='0014000000mw0MvAAI', csRep='Dillon Brady',
territory='Los Angeles', segment='Strategic'
where paymentProfileID=4047305;

UPDATE rpt_workspace.js_csNetBookings
SET domain = 'incitecpivot.com.au',
customer = 'Incitec Pivot Limited',
accountId = '0013300001f6HPxAAM',
csRep = 'Andrew Rustemeyer',
territory = 'Unassigned (CDM)',
segment = 'No Territory'
WHERE paymentProfileID = 7598286;

DROP TABLE IF EXISTS rpt_main_02.stg_cs30DayActivity;
DROP TABLE IF EXISTS rpt_main_02.stg_planTotalACV;

SELECT paymentProfileID, mainContactUserID, recordDateTime, planLevelRecordType, domainLevelRecordType, NewProductName, OldProductName, NewMonthlyPayment,
OldMonthlyPayment, MonthlyPaymentChange, NewUserLimit, OldUserLimit, OldPaymentTerm, OldPaymentType, paymentStartDate, domain, ISP, accountName, accountID,
csRep, tier, health, lastContactDate, territory, segment, customer
FROM rpt_workspace.js_csNetBookings LIMIT 5434343
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard2V2.sql");

