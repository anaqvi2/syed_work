SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("monthlyBookingsSnapshots.csv");

DELETE FROM rpt_main_02.stg_monthlyBookingsSnapshots
	WHERE DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

INSERT INTO rpt_main_02.stg_monthlyBookingsSnapshots
SELECT m.monthFriendly, 
	rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID) AS 'Product Name', 
	COUNT(DISTINCT(hpp.paymentProfileID)) AS 'Plans',
	SUM((hpp.planRate_USD/hpp.paymentTerm)) AS 'MRR',
		SUM(hpp.userLimit) AS 'Seats Purchased',
		m.startMonth
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON hpp.hist_effectiveThruDateTime > m.startMonth
	AND hpp.modifyDateTime <= m.startMonth
	AND m.startMonth <= NOW() AND m.startMonth >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m-01 00:00:00')
WHERE hpp.productID > 2 AND hpp.planRate > 0 AND hpp.paymentType IN(1,2,3,6,8,10) AND hpp.accountType != 2
	GROUP BY 1,2;
	
SELECT monthFriendly,
productName AS 'Product Name',
plans AS 'Plans',
MRR,
seatsPurchased AS 'Seats Purchased',
startMonth
FROM rpt_main_02.stg_monthlyBookingsSnapshots;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("monthlyBookingsSnapshots.csv");