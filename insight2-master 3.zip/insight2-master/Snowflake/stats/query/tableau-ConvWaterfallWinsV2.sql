SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ConvWaterfallWinsV2.csv");

DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_wins;

-- Grab detailed wins
CREATE TABLE rpt_main_02.stg_conv_waterfall_wins 
(
	SourceUserID int,
	`First Payment Month` datetime,
	paymentProfileID int,
	ownerID int,
	`Payment Account Type` varchar(50),
	`Payment Type` varchar(50),
	PaymentStartDate datetime,
	PaymentStartMonth datetime,
	productID varchar(50),
	userLimit int,
	paymentTerm int,
	monthlyPayment decimal (42,14),
	`Insert Date Time` datetime,
	`Modify Date Time` datetime,
	placeholder varchar(20),
	Bucket varchar(50),
	trialStartMonth datetime,
	trialStartDateTime datetime,
	`Trial Bucket` varchar(50),
	`Trial Account Type` varchar(50),
	source varchar(100),
	subsource varchar(100),
	campaign varchar(100),
	segment varchar(100),
	workingSource varchar(100),
	workingSubsource varchar(100),
	workingBucket varchar(50),
	`IP Country` varchar(50),
	`IP Region` varchar(100),
	`IP City` varchar(100),
	languageFriendly varchar(200),
	isStrongLead int
)
;

INSERT INTO rpt_main_02.stg_conv_waterfall_wins
SELECT DISTINCT
mainContactUserID as SourceUserID,
date_format(PaymentStartDate, '%Y-%m-01 00:00:00') as `First Payment Month`,
rsm.paymentProfileID,
ownerID,
NewAccountType as `Payment Account Type`,
NewPaymentType as `Payment Type`,
PaymentStartDate,
date_format(PaymentStartDate, '%Y-%m-01') as PaymentStartMonth,
newproductname as productID,
newuserlimit as userLimit,
newpaymentTerm as paymentTerm,
newmonthlypayment as monthlyPayment,
recordDateTime as `Insert Date Time`,
rsm.modifyDateTime as `Modify Date Time`,
null,
rsm.Bucket,
trials.trialStartMonth,
trials.trialStartDateTime,
trials.bucket as `Trial Bucket`,
trials.accountType as `Trial Account Type`,
trials.source,
trials.subsource,
trials.campaign,
trials.segment,
CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.sourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.sourceFriendly
END
ELSE 
CASE rpt_signupSourceUser.sourceFriendly IS NULL /* if we already have source info, use it */
WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 
ELSE
CASE rpt_signupSourceUser.sourceFriendly != "PPC"	 /* if there is an ancestor source and a user source */
WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly /* use the anscestor source if the user source is sharing */
ELSE rpt_signupSourceUser.sourceFriendly	 /* otherwise use the user source */
END
END
END AS 'Working Source',

CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.subSourceFriendly IS NULL
WHEN 1 THEN "Sharing"
ELSE rpt_signupSourceUser.subSourceFriendly
END
ELSE 
CASE rpt_signupSourceUser.subSourceFriendly IS NULL /* if we already have source info, use it */
WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 
ELSE 
CASE rpt_signupSourceUser.subSourceFriendly != "PPC"	 /* if there is an ancestor sub source and a user sub source */
WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly /* use the anscestor sub source if the user source is sharing */
ELSE rpt_signupSourceUser.subSourceFriendly	 /* otherwise use the user sub source */
END
END
END AS 'Working Sub Source',

CASE rpt_signupSourceAncestor.email IS NULL 
WHEN 1 THEN 
CASE rpt_signupSourceUser.bucket IS NULL
WHEN 1 THEN "Viral"
ELSE rpt_signupSourceUser.bucket
END
ELSE rpt_signupSourceAncestor.bucket 
END AS 'Working Bucket',
rsm.ipCountry AS "IP Country",
rsm.ipRegion AS "IP Region",
rsm.ipCity AS "IP City",
trials.languageFriendly,

CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
WHEN 1 THEN 1
ELSE 0
END AS 'Is Strong Lead'

FROM rpt_main_02.output_RevenueSummaryMonthly rsm

LEFT JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = rsm.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.userAccount ua	 ON ua.userID = ppc.userID
LEFT OUTER JOIN rpt_main_02.rpt_userAncestor ON ua.emailAddress = rpt_userAncestor.userEmailAddress
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceAncestor ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
LEFT OUTER JOIN rpt_main_02.stg_trialsByMonth trials ON trials.userID = ppc.userID 
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY) ON ua.userID = rpt_clientLogCountsByUserArchived.userID
WHERE rsm.recordType='WINS'
AND rsm.paymentStartDate >= '2012-01-01'
;


-- Aggregate wins and substitute ID values for names
-- This will make indexing and matching to trial combos easier
DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_w;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_waterfall_w
(
	bucketID INT,
	sourceID INT,
	subsourceID INT,
	campaignID INT,
	segmentID INT,
	-- trialStartMonth varchar(50),
	trialStartMonth datetime,
	accountType varchar(10),
	-- `First Payment Month` varchar(50),
	`First Payment Month` datetime,
	`IP Country` varchar(100),
	`IP Region` varchar(100),
	`IP City` varchar(200),
	languageFriendly varchar(200),
	wins int,
	strongLeadWins int,
	newMonthlyPayment decimal (42,14),	
	
	strongLeadMRR decimal(42,14),
	
	wins_basic int,
	wins_adv int,
	wins_team int,
	wins_ent int,
	
	strongLeadWins_basic int,
	strongLeadWins_adv int,
	strongLeadWins_team int,
	strongLeadWins_ent int,
	
	MRR_basic decimal (42,14),
	MRR_adv decimal (42,14),
	MRR_team decimal (42,14),
	MRR_ent decimal (42,14),
	
	strongLeadMRR_basic decimal (42,14),
	strongLeadMRR_adv decimal (42,14),
	strongLeadMRR_team decimal (42,14),
	strongLeadMRR_ent decimal (42,14),

	wins_First30D int,
	wins_First60D int,
	strongLeadWins_First30D int,
	strongLeadWins_First60D int,

	KEY ix_unique (bucketID, sourceID, subsourceID, campaignID, segmentID, trialStartMonth, accountType, `First Payment Month`, 
		`IP Country`, `IP Region`, `IP City`,languageFriendly)
)
;

-- TRUNCATE TABLE rpt_main_02.stg_conv_waterfall_w;

INSERT INTO rpt_main_02.stg_conv_waterfall_w
SELECT 
bucketID, 
sourceID, 
subsourceID, 
campaignID, 
segmentID, 
trialStartMonth, `Trial Account Type`, `First Payment Month`, 
`IP Country`, `IP Region`, `IP City`, 
languageFriendly, 
count(*) AS wins, 
sum(case when isStrongLead = 1 then 1 else 0 end) AS strongLeadWins,
sum(monthlyPayment),

sum(case when isStrongLead = 1 then monthlyPayment else 0 end) AS strongLeadMRR,

sum(case when productID = 'Basic' then 1 else 0 end) AS wins_basic,
sum(case when productID = 'Advanced' then 1 else 0 end) AS wins_adv,
sum(case when productID in ('Team','Team Plus') then 1 else 0 end) AS wins_team,
sum(case when productID = 'Enterprise' then 1 else 0 end) AS wins_ent,

sum(case when productID = 'Basic' and isStrongLead = 1 then 1 else 0 end) AS strongLeadWins_basic,
sum(case when productID = 'Advanced' and isStrongLead = 1 then 1 else 0 end) AS strongLeadWins_adv,
sum(case when productID in ('Team','Team Plus') and isStrongLead = 1 then 1 else 0 end) AS strongLeadWins_team,
sum(case when productID = 'Enterprise' and isStrongLead = 1 then 1 else 0 end) AS strongLeadWins_ent,

sum(case when productID = 'Basic' then monthlyPayment else 0 end) AS MRR_basic,
sum(case when productID = 'Advanced' then monthlyPayment else 0 end) AS MRR_adv,
sum(case when productID in ('Team','Team Plus') then monthlyPayment else 0 end) AS MRR_team,
sum(case when productID = 'Enterprise' then monthlyPayment else 0 end) AS MRR_ent,

sum(case when productID = 'Basic' and isStrongLead = 1 then monthlyPayment else 0 end) AS strongLeadMRR_basic,
sum(case when productID = 'Advanced' and isStrongLead = 1 then monthlyPayment else 0 end) AS strongLeadMRR_adv,
sum(case when productID in ('Team','Team Plus') and isStrongLead = 1 then monthlyPayment else 0 end) AS strongLeadMRR_team,
sum(case when productID = 'Enterprise' and isStrongLead = 1 then monthlyPayment else 0 end) AS strongLeadMRR_ent,

sum(case when datediff(PaymentStartDate,trialStartDateTime) <= 30 then 1 else 0 end) as wins_First30D,
sum(case when datediff(PaymentStartDate,trialStartDateTime) between 31 and 60 then 1 else 0 end) as wins_First60D,

sum(case when isStrongLead = 1 and datediff(PaymentStartDate,trialStartDateTime) <= 30 then 1 else 0 end) as strongLeadWins_First30D,
sum(case when isStrongLead = 1 and datediff(PaymentStartDate,trialStartDateTime) between 31 and 60 then 1 else 0 end) as strongLeadWins_First60D

# select * from stg_conv_waterfall_wins;

FROM rpt_main_02.stg_conv_waterfall_wins w
LEFT JOIN rpt_main_02.dim_bucket db ON w.bucket=db.bucketName
LEFT JOIN rpt_main_02.dim_source ds ON w.source=ds.sourceName
LEFT JOIN rpt_main_02.dim_subsource dss ON w.subsource=dss.subsourceName
LEFT JOIN rpt_main_02.dim_campaign dc ON w.campaign=dc.campaignName
LEFT JOIN rpt_main_02.dim_segment dseg ON w.segment=dseg.segmentName
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12
;

UPDATE rpt_main_02.stg_conv_waterfall_w SET campaignID = 0 WHERE campaignID IS NULL;
UPDATE rpt_main_02.stg_conv_waterfall_w SET segmentID = 0 WHERE segmentID IS NULL;


/*
-- wins
select bucket, source, subsource, campaign, segment, trialStartMonth, `First Payment Month`, `Trial Account Type`, `Trial Bucket`, 
`IP Country`, `IP Region`, `IP City`, count(*) as wins
from rpt_main_02.stg_conv_waterfall_wins 
group by 1,2,3,4,5,6,7,8,9,10,11,12
;
*/

-- Combine trial and win data into a single table for months where trials and wins exist for all key combo matches 
DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_tw;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_waterfall_tw 
(
  `bucketID` int(11) DEFAULT NULL,
  `sourceID` int(11) DEFAULT NULL,
  `subsourceID` int(11) DEFAULT NULL,
  `campaignID` int(11) DEFAULT NULL,
  `segmentID` int(11) DEFAULT NULL,
  -- `trialStartMonth` varchar(50) DEFAULT NULL,
  `trialStartMonth` datetime DEFAULT NULL,
  `accountType` varchar(10) DEFAULT NULL,
  `IP Country` varchar(100) DEFAULT NULL,
  `IP Region` varchar(100) DEFAULT NULL,
  `IP City` varchar(200) DEFAULT NULL,
  languageFriendly varchar(200) DEFAULT NULL,
  -- `First Payment Month` varchar(50) DEFAULT NULL,
  `First Payment Month` datetime DEFAULT NULL, 
  `trials` decimal(32,0) DEFAULT NULL,
  `strongLeads` decimal(32,0) DEFAULT 0,
  `wins` decimal(32,0) DEFAULT NULL,
  `strongLeadWins` decimal(32,0) DEFAULT NULL,
  `newMonthlyPayment` decimal (42,14) DEFAULT 0,
  
  strongLeadMRR decimal(42,14),
  
  	wins_basic int,
	wins_adv int,
	wins_team int,
	wins_ent int,
	
	strongLeadWins_basic int,
	strongLeadWins_adv int,
	strongLeadWins_team int,
	strongLeadWins_ent int,
	
	MRR_basic decimal (42,14),
	MRR_adv decimal (42,14),
	MRR_team decimal (42,14),
	MRR_ent decimal (42,14),
	
	strongLeadMRR_basic decimal (42,14),
	strongLeadMRR_adv decimal (42,14),
	strongLeadMRR_team decimal (42,14),
	strongLeadMRR_ent decimal (42,14),

	wins_First30D int,
	wins_First60D int,
	strongLeadWins_First30D int,
	strongLeadWins_First60D int,
	
  KEY `bucketID` (`bucketID`,`sourceID`,`subsourceID`,`campaignID`,`segmentID`,`trialStartMonth`,`accountType`,`First Payment Month`,
  `IP Country`,`IP Region`,`IP City`,languageFriendly)
)
;

-- TRUNCATE TABLE rpt_main_02.stg_conv_waterfall_tw;

INSERT INTO rpt_main_02.stg_conv_waterfall_tw
SELECT 
t.bucketID, 
t.sourceID, 
t.subsourceID, 
t.campaignID, 
t.segmentID, 
t.trialStartMonth, 
t.accountType, 
t.`IP Country`, t.`IP Region`, t.`IP City`,
t.languageFriendly,
w.`First Payment Month`,
sum(trials) as trials,
sum(strongLeads) as strongLeads,
sum(ifnull(wins,0)) as wins,
sum(ifnull(strongLeadWins,0)) as strongLeadWins,
sum(ifnull(newMonthlyPayment,0)) as newMonthlyPayment,
sum(ifnull(strongLeadMRR,0)) as strongLeadMRR,
sum(ifnull(wins_basic,0)) as wins_basic,
sum(ifnull(wins_adv,0)) as wins_adv,
sum(ifnull(wins_team,0)) as wins_team,
sum(ifnull(wins_ent,0)) as wins_ent,

sum(ifnull(strongLeadWins_basic,0)) as strongLeadWins_basic,
sum(ifnull(strongLeadWins_adv,0)) as strongLeadWins_adv,
sum(ifnull(strongLeadWins_team,0)) as strongLeadWins_team,
sum(ifnull(strongLeadWins_ent,0)) as strongLeadWins_ent,
	
sum(ifnull(MRR_basic,0)) as MRR_basic,
sum(ifnull(MRR_adv,0)) as MRR_adv,
sum(ifnull(MRR_team,0)) as MRR_team,
sum(ifnull(MRR_ent,0)) as MRR_ent,

sum(ifnull(strongLeadMRR_basic,0)) as strongLeadMRR_basic,
sum(ifnull(strongLeadMRR_adv,0)) as strongLeadMRR_adv,
sum(ifnull(strongLeadMRR_team,0)) as strongLeadMRR_team,
sum(ifnull(strongLeadMRR_ent,0)) as strongLeadMRR_ent,

sum(ifnull(wins_First30D,0)) as wins_First30D,
sum(ifnull(wins_First60D,0)) as wins_First60D,
sum(ifnull(strongLeadWins_First30D,0)) as strongLeadWins_First30D,
sum(ifnull(strongLeadWins_First60D,0)) as strongLeadWins_First60D

FROM rpt_main_02.stg_conv_waterfall_trials t
JOIN rpt_main_02.stg_conv_waterfall_w w 

ON t.bucketID=w.bucketID
AND t.sourceID=w.sourceID
AND t.subsourceID=w.subsourceID
AND t.campaignID=w.campaignID
AND t.segmentID=w.segmentID
AND t.trialStartMonth=w.trialStartMonth
AND t.`IP Country`=w.`IP Country`
AND t.`IP Region`=w.`IP Region`
AND t.`IP City`=w.`IP City`
AND t.accountType=w.accountType
and t.languageFriendly=w.languageFriendly

GROUP BY 
t.bucketID, 
t.sourceID, 
t.subsourceID, 
t.campaignID, 
t.segmentID, 
t.trialStartMonth, 
t.accountType, 
t.`IP Country`, t.`IP Region`, t.`IP City`,
t.languageFriendly,
w.`First Payment Month` 
;


-- Identify and insert all wins into table where there are no trials for key combo match but there are wins
INSERT INTO rpt_main_02.stg_conv_waterfall_tw (bucketID, sourceID, subsourceID, campaignID, segmentID, 
trialStartMonth, accountType, `First Payment Month`, `IP Country`, `IP Region`, `IP City`, trials, strongLeads, wins, strongLeadWins, newMonthlyPayment, languageFriendly,
strongLeadMRR, wins_basic, wins_adv, wins_team, wins_ent,
strongLeadWins_basic, strongLeadWins_adv, strongLeadWins_team, strongLeadWins_ent,
MRR_basic, MRR_adv, MRR_team, MRR_ent,
strongLeadMRR_basic, strongLeadMRR_adv, strongLeadMRR_team, strongLeadMRR_ent,
wins_First30D, wins_First60D,
strongLeadWins_First30D, strongLeadWins_First60D
)

SELECT DISTINCT
w.bucketID, w.sourceID, w.subsourceID, w.campaignID, w.segmentID, 
w.trialStartMonth, 
w.accountType, w.`First Payment Month`, w.`IP Country`, w.`IP Region`, w.`IP City`, 0 as trials, 0 as strongLeads, wins, strongLeadWins, newMonthlyPayment, languageFriendly,
strongLeadMRR,
wins_basic, wins_adv, wins_team, wins_ent,
strongLeadWins_basic, strongLeadWins_adv, strongLeadWins_team, strongLeadWins_ent,
MRR_basic, MRR_adv, MRR_team, MRR_ent,
strongLeadMRR_basic, strongLeadMRR_adv, strongLeadMRR_team, strongLeadMRR_ent,
wins_First30D, wins_First60D,
strongLeadWins_First30D, strongLeadWins_First60D

FROM rpt_main_02.stg_conv_waterfall_w w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_conv_waterfall_tw tw
	WHERE (w.bucketID)= (tw.bucketID)
	AND  (w.sourceID)= (tw.sourceID)
	AND  (w.subsourceID)= (tw.subsourceID)
	AND  (w.campaignID)= (tw.campaignID)
	AND  (w.segmentID)= (tw.segmentID)
	AND  (w.trialStartMonth)= (tw.trialStartMonth)
	AND  (w.`IP Country`)=  (tw.`IP Country`)
	AND  (w.`IP Region`)=  (tw.`IP Region`)
	AND  (w.`IP City`)=  (tw.`IP City`)
	AND  (w.`First Payment Month`)= (tw.`First Payment Month`)
	AND  (w.languageFriendly)=(tw.languageFriendly)
)
;


-- Create table to stage trial data 
DROP TABLE IF EXISTS rpt_main_02.stg_conv_stg_tr;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_conv_stg_tr 
(
	bucketID int,
	sourceID int,
	subsourceID int,
	campaignID int,
	segmentID int,
	trialStartMonth datetime,
	accountType varchar(50),
	`IP Country` varchar(50),
	`IP Region` varchar(100),
	`IP City` varchar(100),
	trials int,
	strongLeads int,
	wins int,
	strongLeadWins int,
	newMonthlyPayment decimal(42,14),
	languageFriendly varchar(200),
	strongLeadMRR decimal(42,14),
	wins_basic int,
	wins_adv int,
	wins_team int,
	wins_ent int,
	
	strongLeadWins_basic int,
	strongLeadWins_adv int,
	strongLeadWins_team int,
	strongLeadWins_ent int,
	
	MRR_basic decimal (42,14),
	MRR_adv decimal (42,14),
	MRR_team decimal (42,14),
	MRR_ent decimal (42,14),
	
	strongLeadMRR_basic decimal (42,14),
	strongLeadMRR_adv decimal (42,14),
	strongLeadMRR_team decimal (42,14),
	strongLeadMRR_ent decimal (42,14),

	wins_first30D int,
	wins_first60D int,
	strongLeadWins_First30D int,
	strongLeadWins_First60D int
)
;

INSERT INTO rpt_main_02.stg_conv_stg_tr
SELECT DISTINCT
w.bucketID, w.sourceID, w.subsourceID, w.campaignID, w.segmentID, 
w.trialStartMonth, 
w.accountType, w.`IP Country`, w.`IP Region`, w.`IP City`, trials, strongLeads, 0 as wins, 0 as strongLeadWins, 0 as newMonthlyPayment, w.languageFriendly,
0 as strongLeadMRR,
0 as wins_basic, 0 as wins_adv, 0 as wins_team, 0 as wins_ent,
0 as strongLeadWins_basic, 0 as strongLeadWins_adv, 0 as strongLeadWins_team, 0 as strongLeadWins_ent,
0 as MRR_basic, 0 as MRR_adv, 0 as MRR_team, 0 as MRR_ent,
0 as strongLeadMRR_basic, 0 as strongLeadMRR_adv, 0 as strongLeadMRR_team, 0 as strongLeadMRR_ent,
0 as wins_first30D, 0 as wins_first60D,
0 as strongLeadWins_First30D, 0 as strongLeadWins_First60D
FROM rpt_main_02.stg_conv_waterfall_trials w

WHERE NOT EXISTS 
(
	SELECT * FROM rpt_main_02.stg_conv_waterfall_tw tw
	WHERE (w.bucketID)= (tw.bucketID)
	AND  (w.sourceID)= (tw.sourceID)
	AND  (w.subsourceID)= (tw.subsourceID)
	AND  (w.campaignID)= (tw.campaignID)
	AND  (w.segmentID)= (tw.segmentID)
	AND  (w.trialStartMonth)= (tw.trialStartMonth)
	AND  (w.`IP Country`)=  (tw.`IP Country`)
	AND  (w.`IP Region`)=  (tw.`IP Region`)
	AND  (w.`IP City`)=  (tw.`IP City`)
	AND  (w.languageFriendly)=(tw.languageFriendly)
)
;




-- Insert placeholder records for trials for every key combo and First Payment Month
-- This will allow conv rates to calculate correctly across months
-- Call stored proc to iterate through all months


INSERT INTO rpt_main_02.stg_conv_waterfall_tw (bucketID, sourceID, subsourceId, campaignID, segmentID, trialStartMonth, accountType, 
`IP Country`, `IP Region`, `IP City`,`First Payment Month`, trials, strongLeads, wins, strongLeadWins, newMonthlyPayment, languageFriendly,
strongLeadMRR,
wins_basic, wins_adv, wins_team, wins_ent,
strongLeadWins_basic, strongLeadWins_adv, strongLeadWins_team, strongLeadWins_ent,
MRR_basic, MRR_adv, MRR_team, MRR_ent,
strongLeadMRR_basic, strongLeadMRR_adv, strongLeadMRR_team, strongLeadMRR_ent,
wins_first30D, wins_first60D,
strongLeadWins_First30D, strongLeadWins_First60D
)
SELECT bucketID, sourceID, subsourceID, campaignID, segmentId, trialStartMonth, accountType, 
`IP Country`, `IP Region`, `IP City`, trialStartMonth, trials, strongLeads, wins, strongLeadWins, newMonthlyPayment, languageFriendly, strongLeadMRR,
wins_basic, wins_adv, wins_team, wins_ent,
strongLeadWins_basic, strongLeadWins_adv, strongLeadWins_team, strongLeadWins_ent,
MRR_basic, MRR_adv, MRR_team, MRR_ent,
strongLeadMRR_basic, strongLeadMRR_adv, strongLeadMRR_team, strongLeadMRR_ent,
wins_first30D, wins_first60D,
strongLeadWins_First30D, strongLeadWins_First60D
FROM rpt_main_02.stg_conv_stg_tr
;



-- Select data for report output
SELECT 	
IFNULL(bucketName,'Viral') as bucket, 
sourceName as source, 
subsourceName as subsource, 
campaignName as campaign, 
segmentName as segment,
trialStartMonth, accountType, `First Payment Month`, `IP Country`,`IP Region`,`IP City`, 
CASE when ref_weightedStrongLeadFactor.weightedStrongLeadFactor is null then 0 
else ref_weightedStrongLeadFactor.weightedStrongLeadFactor END as "Weighted Strong Lead Factor",
languageFriendly,
sum(trials) as trials, 
sum(strongLeads) as strongLeads,
sum(wins) as wins, 
sum(strongLeadWins) as strongLeadWins,
sum(newMonthlyPayment) as newMonthlyPayment,
sum(strongLeadMRR) as strongLeadMRR,
sum(wins_basic) as wins_basic, 
sum(wins_adv) as wins_adv, 
sum(wins_team) as wins_team, 
sum(wins_ent) as wins_ent,
sum(strongLeadWins_basic) as strongLeadWins_basic, 
sum(strongLeadWins_adv) as strongLeadWins_adv, 
sum(strongLeadWins_team) as strongLeadWins_team, 
sum(strongLeadWins_ent) as strongLeadWins_ent,
sum(MRR_basic) as MRR_basic, 
sum(MRR_adv) as MRR_adv, 
sum(MRR_team) as MRR_team, 
sum(MRR_ent) as MRR_ent,
sum(strongLeadMRR_basic) as strongLeadMRR_basic, 
sum(strongLeadMRR_adv) as strongLeadMRR_adv, 
sum(strongLeadMRR_team) as strongLeadMRR_team, 
sum(strongLeadMRR_ent) as strongLeadMRR_ent,
sum(wins_first30D) as wins_first30D,
sum(wins_first60D) as wins_first60D,
sum(strongLeadWins_First30D) as strongLeadWins_First30D,
sum(strongLeadWins_First60D) as strongLeadWins_First60D

FROM rpt_main_02.stg_conv_waterfall_tw a
LEFT JOIN rpt_main_02.dim_bucket db on a.bucketID=db.bucketID
LEFT JOIN rpt_main_02.dim_source ds on a.sourceID=ds.sourceID
LEFT JOIN rpt_main_02.dim_subsource dss on a.subsourceID=dss.subsourceID
LEFT JOIN rpt_main_02.dim_campaign dc on a.campaignID=dc.campaignID
LEFT JOIN rpt_main_02.dim_segment dseg on a.segmentID=dseg.segmentID
LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON a.`IP Country` = ref_weightedStrongLeadFactor.IPCountry
WHERE DAYOFWEEK(CURRENT_DATE()) in(3,5)
group by 1,2,3,4,5,6,7,8,9,10,11,12,13
;



DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_wins;
DROP TABLE IF EXISTS rpt_main_02.stg_conv_waterfall_tw;




/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ConvWaterfallWinsV2.csv");
