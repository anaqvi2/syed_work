SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("nonEntBillToRenewalsV2.sql");

SELECT pp.paymentProfileID, pp.mainContactDomain AS domain, pp.mainContactEmailAddress, pp.productName, pp.paymentTermFriendly, pp.paymentTypeFriendly, 
(pp.planRate_USD/pp.paymentTerm)*12 AS ARR,
CASE WHEN pp.paymentTerm = 12 THEN
		CASE WHEN pp.nextPaymentDate > NOW() THEN pp.nextPaymentDate 
			/*If there's an out of date nextPaymentDate, add the next term*/
			WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/* Out of date next payment date more than a year old */
			WHEN pp.nextPaymentDate IS NOT NULL 
				THEN DATE_FORMAT(CONCAT(DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 1 YEAR), '%Y'), "-",
					MONTH(pp.nextPaymentDate), "-",DAY(pp.nextPaymentDate)), "%Y-%m-%d 00:00:00")
			/*If there's a recent actual last payment, add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT(DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 1 YEAR), '%Y'), "-",
					MONTH(pp.actualLastPaymentDate), "-",DAY(pp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) + 1) YEAR) END
	WHEN pp.paymentTerm IN (1,6) THEN 
		CASE WHEN pp.nextPaymentDate > NOW() THEN pp.nextPaymentDate
			/*If there's an out of date nextPaymentDate, add the next term*/
			WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN pp.paymentTerm = 1 
			THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +(pp.paymentTerm) MONTH) END
	WHEN pp.paymentTerm IN(24,36) THEN
		CASE WHEN pp.nextPaymentDate > NOW() THEN pp.nextPaymentDate
		/*If there's an out of date nextPaymentDate, add the next term*/
		WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
		WHEN pp.nextPaymentDate IS NOT NULL THEN MIN(B.npd)
		END
		ELSE "Other" END AS RenewalDate
FROM rpt_main_02.rpt_paymentProfile pp
LEFT JOIN rpt_main_02.stg_multiYearPaymentTerms B ON pp.paymentProfileID = B.paymentProfileID AND B.npd > NOW()
WHERE pp.paymentType IN(2,10) AND pp.productID NOT IN(6,11) AND pp.countAsPaid = 1
GROUP BY pp.paymentProfileID
HAVING DATE_FORMAT(RenewalDate, '%Y-%m') = DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH), '%Y-%m')
ORDER BY 8
;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("nonEntBillToRenewalsV2.sql");
