SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("SLPTRPmappingV2.sql");

SET @@sql_mode = '';


/*
drop table if exists rpt_workspace.js_slpTRPmapping;
create table if not exists rpt_workspace.js_slpTRPmapping
(userID int,
emailAddress varchar(50),
domain varchar(50),
F1000domain int,
country varchar(50),
language varchar(50),
signupDateTime datetime,
slpCode varchar(100),
trpCode varchar(100),
lpvCode varchar(100),
lpaCode varchar(100),
lang varchar(50),
signupBucket varchar(50),
signupSource varchar(50),
signupSubSource varchar(50),
signupCampaign varchar(50),
worm varchar(200),
trpCategory varchar(100),
paymentProfileID int,
trial int,
wsl dec(4,2),
win int,
winARR dec(10,2),
winDateTime datetime,
salesAssisted int,
dateDiff int,
becameLicensed int,
primary key (userID),
index (domain),
index (signupDateTime),
index (paymentProfileID),
index (winDateTime));

alter table rpt_workspace.js_slpTRPmapping
add winProductName varchar(50);
*/

select max(signupDateTime) from rpt_workspace.js_slpTRPmapping into @maxSignupDateTime;

insert ignore into rpt_workspace.js_slpTRPmapping(userID, signupDateTime, slpCode, trpCode, lpvCode, lpaCode, lang, signupBucket, signupSource, signupSubSource, signupCampaign)
select userID, signupInsertDateTime, slp, trpValue, landingPageVersion, lpa, lang, bucket, sourceFriendly, subSourceFriendly, campaign from rpt_main_02.rpt_signupSource
where signupInsertDateTime >= @maxSignupDateTime;

update rpt_workspace.js_slpTRPmapping
set signupCampaign='NULL'
where signupCampaign is null;

update rpt_workspace.js_slpTRPmapping
set worm=concat(signupBucket,', ',signupSource,', ',signupSubSource,', ',signupCampaign)
where signupDateTime >= @maxSignupDateTime;

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.ref_trpValues B
on A.trpCode=B.trpValue
set A.trpCode=concat(A.trpCode,' ',B.trpName), A.trpCategory=B.trpCategory
where signupDateTime >= @maxSignupDateTime;

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.userAccount B
on A.userID=B.userID
set A.emailAddress=B.emailAddress, A.domain=B.domain, A.country=B.countryFriendly, A.language=B.languageFriendly
where signupDateTime >= @maxSignupDateTime;

delete from rpt_workspace.js_slpTRPmapping
where domain like '%smartsheet%';

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.ref_Oct2016fortune1000 B
on A.domain=B.domain
set A.F1000domain=1
where signupDateTime >= @maxSignupDateTime;

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.stg_tableauTrialReport B
on A.userID=B.userID
set A.trial=1, A.paymentProfileID=B.paymentProfileID, A.wsl=B.WeightedStrongLeadFactor*B.IsStrongLeadAdjusted, A.winDateTime=B.winDate, A.winARR=B.MRR*12, A.winProductName=B.firstWinProduct;

update rpt_workspace.js_slpTRPmapping
set win=1
where winDateTime is not null;

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.arc_paymentProfile_firstWinProduct B
on A.userID=B.sourceUserID
join ss_sfdc_02.opportunity C
on B.paymentProfileID=C.Parent_Payment_Profile_ID__c
set A.salesAssisted=1
where A.win=1 and DATE_FORMAT(TIMESTAMPADD(HOUR,-7,B.winDate),'%Y-%m-01')=DATE_FORMAT(C.CloseDate,'%Y-%m-01') 
and C.StageName='Closed Won' and C.Amount>0 and C.Product__c!='SERVICES';

update rpt_workspace.js_slpTRPmapping
set datediff=datediff(winDateTime, signupDateTime);

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.hist_paymentProfile B
on A.userID=B.ownerID
set A.becameLicensed=1
where B.accountType!=3 and B.productID > 2;

/*
alter table rpt_workspace.js_slpTRPmapping
add ISP int;
*/

update rpt_workspace.js_slpTRPmapping A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set A.ISP=1;

/*
alter table rpt_workspace.js_slpTRPmapping
add newLogo int;
*/

UPDATE rpt_workspace.js_slpTRPmapping A
LEFT JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.domain = B.domain AND DATE_FORMAT(A.signupDateTime, '%Y-%m-01 00:00:00') = B.startMonth
SET A.newLogo = CASE WHEN A.ISP=1 THEN 0
WHEN B.domain IS NULL THEN 1 ELSE 0 END
where signupDateTime >= @maxSignupDateTime;

UPDATE rpt_workspace.js_slpTRPmapping A
JOIN rpt_main_02.arc_integratedContentCategory B ON A.slpCode = B.slpURL
SET A.slpCategory = B.category;

select * from rpt_workspace.js_slpTRPmapping;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("SLPTRPmappingV2.sql");

