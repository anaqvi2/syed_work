SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("FY18GrowthScorecardV2.sql");

insert ignore into rpt_workspace.js_thresholdStagingTable(monthDate, threshold)
select monthYear, threshold from rpt_workspace.js_5kTransactionsFinal;

update rpt_workspace.js_thresholdStagingTable A
set overThreshold=
(select count(*) from rpt_workspace.js_5kTransactionsFinal B
where A.monthDate=B.monthYear and A.threshold=B.threshold and B.recordType in ('New','Expansion'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_workspace.js_thresholdStagingTable A
set underThreshold=
(select count(*) from rpt_workspace.js_5kTransactionsFinal B
where A.monthDate=B.monthYear and A.threshold=B.threshold and B.recordType in ('Cancel','Reduction'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_workspace.js_thresholdStagingTable
set netThreshold=overThreshold-underThreshold;

update rpt_workspace.js_thresholdStagingTable A
set canceledFromOverThreshold=
(select count(*) from rpt_workspace.js_5kTransactionsFinal B
where A.monthDate=B.monthYear and A.threshold=B.threshold and B.recordType='Cancel')
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');


update rpt_workspace.js_GScancelRateStaging A
set multiUserLogosCancelled=
(select count(distinct domain) from rpt_main_02.output_RevenueSummaryMonthly B
where date_format(B.recordDateTime, '%Y%m') = date_format(A.monthDate, '%Y%m') and B.domainLevelRecordTypeNew='CANCEL' 
and B.ispDomain=0 and B.futureLoss is null and B.OldProductName in ('Team','Enterprise','Enterprise_Legacy','Business'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_workspace.js_GScancelRateStaging A
set multiUserLogosAtStart=
(select count(*) from rpt_workspace.js_acvBandsCustomers B
where B.monthYear=A.monthDate and B.ISP is null and B.maxProductName in ('Team','Enterprise','Enterprise_Legacy','Business'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_workspace.js_GScancelRateStaging
set multiUserLogosCancelRate=multiUserLogosCancelled/multiUserLogosAtStart;






update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
join rpt_workspace.js_thresholdStagingTable B
on A.monthDate=B.monthDate
set A.NetChangeMajorLeagueA=B.netThreshold
where B.threshold='5k Threshold' and date_format(A.monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
join rpt_workspace.js_thresholdStagingTable B
on A.monthDate=B.monthDate
set A.NetChangeAllStarA=B.netThreshold
where B.threshold='50k Threshold' and date_format(A.monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
join rpt_workspace.js_thresholdStagingTable B
on A.monthDate=B.monthDate
set A.NetChangeMVPA=B.netThreshold
where B.threshold='100k Threshold' and date_format(A.monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A 
join rpt_workspace.js_thresholdStagingTable B
on A.monthDate=B.monthDate
set A.LogoCancel5KHigherA=B.canceledFromOverThreshold
where B.threshold='5k Threshold' and date_format(A.monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A 
set FarmTeamNewMultiUserLogosA=
(select count(distinct domain) from rpt_main_02.output_RevenueSummaryMonthly B
where date_format(B.recordDateTime, '%Y%m') = date_format(A.monthDate, '%Y%m') and B.domainLevelRecordTypeNew='NEW' 
and B.ispDomain=0 and B.NewProductName in ('Team','Enterprise','Enterprise_Legacy','Business'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
set NewViralMultiUserLogosA=
(select count(distinct domain) from rpt_main_02.output_RevenueSummaryMonthly B
where B.domainLevelRecordTypeNew='NEW' and B.newProductName in ('Enterprise','Enterprise_Legacy','Business','Team') and B.ispDomain=0 and B.Bucket='Viral' 
and B.SignupSourceFriendly in ('Sharing (Org to Org In Domain)','Sharing (ISP to ORG)','Sharing (Org to Org Out Domain)')
and date_format(B.recordDateTime, '%Y%m') = date_format(A.monthDate, '%Y%m'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 1 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
set CollabsConvertingToLicensedA=
(select count(*) from rpt_workspace.cDunn_collabReport B
where date_format(B.licenseDate, '%Y%m')=date_format(A.monthDate, '%Y%m') or date_format(B.winDate, '%Y%m')=date_format(A.monthDate, '%Y%m'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 3 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
set CollabsInsertedAndLoggedInA=
(select count(*) from rpt_workspace.cDunn_collabReport B
where B.timeToFirstLogin < 720 and date_format(B.insertDateTime, '%Y-%m')=date_format(A.monthDate, '%Y-%m'))
where date_format(monthDate, '%Y%m') >= date_format(date_sub(current_date(),interval 3 month), '%Y%m');

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals A
join rpt_workspace.js_GScancelRateStaging B
on A.monthDate=B.monthDate
set A.MultiUserLogoCancelRateA=B.multiUserLogosCancelRate;



update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set NetChangeMajorLeagueA=0
where NetChangeMajorLeagueA is null and monthDate <= current_date() and monthDate >= '2016-02-01';

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set NetChangeAllStarA=0
where NetChangeAllStarA is null and monthDate <= current_date() and monthDate >= '2016-02-01';

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set NetChangeMVPA=0
where NetChangeMVPA is null and monthDate <= current_date() and monthDate >= '2016-02-01';

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set LogoCancel5KHigherA=0
where LogoCancel5KHigherA is null and monthDate <= current_date() and monthDate >= '2016-02-01';


update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set FarmTeamNewMultiUserLogosA=null
where FarmTeamNewMultiUserLogosA=0 and monthDate > current_date();

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set NewViralMultiUserLogosA=null
where NewViralMultiUserLogosA=0 and monthDate > current_date();

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set CollabsConvertingToLicensedA=null
where CollabsConvertingToLicensedA=0 and monthDate > current_date();

update rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals
set CollabsInsertedAndLoggedInA=null
where CollabsInsertedAndLoggedInA=0 and monthDate > current_date();

select * from rpt_main_02.rpt_fy18GrowthScorecardGoalsActuals;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("FY18GrowthScorecardV2.sql");

