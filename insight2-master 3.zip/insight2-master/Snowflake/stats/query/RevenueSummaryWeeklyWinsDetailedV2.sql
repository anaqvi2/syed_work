SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("RevenueSummaryWinsDetailsV2.csv");


SELECT weeks.ISOWeek AS weekFriendly,
ppc.userID AS SourceUserID,
hist_paymentProfile.paymentProfileID,
hist_paymentProfile.ownerID,
organization.name AS organizationName,
userAccount.emailAddress,
rpt_main_02.SMARTSHEET_ACCOUNTTYPE(hist_paymentProfile.accountType) AS accountType,
rpt_main_02.SMARTSHEET_PAYMENTTYPE(hist_paymentProfile.paymentType) AS paymentType,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") AS PaymentStartDate,
DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, '%Y*%m(%b)') AS PaymentStartMonth,
CASE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentProfileInsertDateTime) < 0
	WHEN 1 THEN NULL
	ELSE DATEDIFF(hist_paymentProfile.paymentStartDateTime, ppc.paymentProfileInsertDateTime) END AS DaysToBuy,
rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID) AS 'Product Name',
CASE WHEN hist_paymentProfile.userLimit = 0 THEN 
	CASE hist_paymentProfile.productID
		WHEN 0 THEN 0
		WHEN 1 THEN 0
		WHEN 2 THEN 0
		WHEN 3 THEN 1
		WHEN 4 THEN 1
		WHEN 5 THEN 1
		WHEN 6 THEN 25
		WHEN 7 THEN 3
		WHEN 8 THEN 10  ELSE 0 END 
	ELSE hist_paymentProfile.userLimit END AS userLimit,
hist_paymentProfile.paymentTerm,
hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm AS MonthlyPayment,
(hist_paymentProfile.planRate_USD/hist_paymentProfile.paymentTerm)*12 AS YearlyPayment,
hist_paymentProfile.insertDateTime,
hist_paymentProfile.modifyDateTime,
MAX(hist_effectiveThruDateTime),

CASE rpt_signupSourceUser.bucket IS NULL 
	WHEN 1 THEN "Viral"
	ELSE rpt_signupSourceUser.bucket
END AS 'Bucket',
		
CASE rpt_signupSourceUser.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.sourceFriendly
END AS SignupSourceFriendly,

CASE rpt_signupSourceUser.subSourceFriendly IS NULL
	WHEN 1 THEN "Sharing"
	ELSE rpt_signupSourceUser.subSourceFriendly
END AS SignupSubSourceFriendly,

rpt_signupSourceUser.campaign 	AS SignupCampaign,
rpt_signupSourceUser.segment 	AS SignupSegment,
rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode) AS BillingCountry,

DATE_FORMAT(MAX(trialDateTime),"%Y-%m-%d") AS MostRecentTrialStart,
DATEDIFF(hist_paymentProfile.paymentStartDateTime,MAX(trialDateTime)) AS MostRecentDaysToBuy,
COUNT(arc_DailyWellQualifiedProsumer.userID) AS contactedByProsumerTeam,
CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
	WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_main_02.SMARTSHEET_COUNTRYNAME(hist_paymentProfile.billToCountryCode)
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
rpt_userIPLocation.ipRegion AS "IP Region",
rpt_userIPLocation.ipCity AS "IP City",
userAccount.languageFriendly,
hist_paymentProfile.currencyCode,
CASE WHEN DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d") IN('2007-12-25',
'2008-01-01',
'2008-05-26',
'2008-07-04',
'2008-09-01',
'2008-11-27',
'2008-11-28',
'2008-12-25',
'2009-01-01',
'2009-05-25',
'2009-07-03',
'2009-09-07',
'2009-11-26',
'2009-11-27',
'2009-12-25',
'2010-01-01',
'2010-05-31',
'2010-07-05',
'2010-09-06',
'2010-11-25',
'2010-11-26',
'2010-12-24',
'2011-01-01',
'2011-05-30',
'2011-07-04',
'2011-09-05',
'2011-11-24',
'2011-11-25',
'2011-12-26',
'2012-01-02',
'2012-05-28',
'2012-07-04',
'2012-09-03',
'2012-11-22',
'2012-11-23',
'2012-12-25',
'2013-01-01',
'2013-05-27',
'2013-07-04',
'2013-09-02',
'2013-11-28',
'2013-11-29',
'2013-12-25',
'2014-01-01',
'2014-05-26',
'2014-07-04',
'2014-09-01',
'2014-11-27',
'2014-11-28',
'2014-12-25',
'2015-01-01',
'2015-05-25',
'2015-07-03',
'2015-09-07',
'2015-11-26',
'2015-11-27',
'2015-12-25',
'2016-01-01',
'2016-05-30',
'2016-07-04',
'2016-09-05',
'2016-11-24',
'2016-11-25',
'2016-12-26') THEN 1 ELSE 0 END AS 'Holiday'

FROM rpt_main_02.hist_paymentProfile
JOIN rpt_main_02.ref_weeks weeks ON hist_paymentProfile.hist_effectiveThruDateTime > weeks.endWeek
	AND hist_paymentProfile.modifyDateTime <= weeks.endWeek
	AND paymentStartDateTime BETWEEN weeks.startWeek AND weeks.endWeek
	AND weeks.startWeek <= NOW()
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hist_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser ON ppc.userID = rpt_signupSourceUser.userID 
LEFT OUTER JOIN rpt_main_02.userAccount ON ppc.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.organization ON hist_paymentProfile.ownerID = organization.organizationID AND hist_paymentProfile.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedProsumer ON arc_DailyWellQualifiedProsumer.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON hist_paymentProfile.paymentProfileID = rpt_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY) ON rpt_paymentProfile.mainContactUserID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.ref_holidays holiday ON holiday.holidayDate = DATE_FORMAT(hist_paymentProfile.paymentStartDateTime, "%Y-%m-%d")


WHERE hist_paymentProfile.productID >= 3
AND hist_paymentProfile.accountType !=2 
AND hist_paymentProfile.planRate_USD > 0
AND hist_paymentProfile.paymentType != 4
and DAYOFMONTH(CURRENT_DATE()) = 15
GROUP BY 1,2

ORDER BY 1 DESC,9,3
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("RevenueSummaryWinsDetailsV2.csv");
