SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-sales_carson_A_usageDashboardSMBV2.sql");

SELECT mainContactUserID, 
productName, 
paymentProfileID, 
mainContactDomain, 
parentPaymentProfileID, 
mainContactEmailAddress, 
sheetCount, sheetsCreated, 
sheetsShared, usersSharedTo, 
trialDate, persona,
paymentStartDate, StartDate, 
daysSinceLastLogin, Last30DayLogins, 
Last90DayLogins, totalLogins, 
userLimit, bonusUserCount, 
seatCount, activeProfileCount, 
accountType, ACV, 
sharedToByUserID, ppID,
masterDomain, everPaid, 
productGroup2, ipCountry, 
ipRegion, ipCity, role, 
REPLACE(fullName,",","") AS 'fullName', 
Territory,
REPLACE(accountName,",","") AS accountName, 
paidCollab,
totalCollabs,
internalCollabs,
accountID,
CSM,
last30DayLoginPlan,
userAccountID,
userAccountName,
SysAdmin, dashboardCount,
REPLACE(jobTitle,",","") AS jobTitle,
REPLACE(industry,",","") AS industry,
edu,
netPromoterScore,
reportCount, sightsEnabled, closedByReseller, paymentTermFriendly, renewalDate, lastContactDate, phoneNumber
FROM rpt_main_02.arc_cDunn_templateUsersNew
WHERE Territory LIKE '%SMB%'
;
 
 
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-sales_carson_A_usageDashboardSMBV2.sql");
