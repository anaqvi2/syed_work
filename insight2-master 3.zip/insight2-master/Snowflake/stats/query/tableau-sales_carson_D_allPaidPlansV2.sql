SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-sales_carson_D_allPaidPlansV2.csv");

SET @@sql_mode = '';

SELECT ppi.paymentProfileID, ppi.sourceUserID, ppi.mainContactUserID, pp.paymentStartDateClean, ppi.productName, ppi.domain, ppi.ACV, ppi.userLimit AS 'LicensesPaidFor',
ppi.bonusUsers, ppi.licensedUsers, ppi.pendingUsers, ppi.assignedUsers AS 'Licensed+Pending',
ppi.salesforceAccountName, CASE WHEN isp.domain IS NOT NULL THEN 1 ELSE 0 END AS 'ispDomain',
acc.Name AS 'AccountName', acc.Territory__c AS 'Territory',
CONCAT(u.FirstName," ",u.lastName) AS salesRep,
CONCAT(cs.FirstName," ",cs.lastName) AS csRep,
acc.NumberOfEmployees AS NumberOfEmployees,
ip.ipCountry
FROM rpt_main_02.rpt_paidPlanInfo ppi
JOIN rpt_main_02.rpt_paymentProfile pp ON ppi.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.organization o ON o.paymentProfileID = ppi.paymentProfileID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = ppi.domain
LEFT OUTER JOIN ss_sfdc_02.account acc ON acc.Id = ppi.accountId
LEFT OUTER JOIN ss_sfdc_02.user u ON u.Id = acc.OwnerId
LEFT OUTER JOIN ss_sfdc_02.user cs ON cs.Id = acc.Customer_Success__c
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = ppi.mainContactUserID
;
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-sales_carson_D_allPaidPlansV2.csv");
