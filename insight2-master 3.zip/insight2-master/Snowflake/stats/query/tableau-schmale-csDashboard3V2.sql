SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard3V2.sql");

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET sql_safe_updates=0;

DROP TABLE IF EXISTS rpt_workspace.js_servicesAtClose;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_servicesAtClose
(opportunityID VARCHAR(50),
paymentProfileID INT,
accountID VARCHAR(50),
closeWonDate DATE,
ARR DEC(10,2),
territoryAtClose VARCHAR(100),
segmentAtClose VARCHAR(50),
csRepAtClose VARCHAR(50),
PRIMARY KEY (opportunityID),
INDEX (paymentProfileID),
INDEX (accountID),
INDEX (closeWonDate),
INDEX (territoryAtClose),
INDEX (segmentAtClose),
INDEX (csRepAtClose));

INSERT INTO rpt_workspace.js_servicesAtClose(opportunityID, paymentProfileID, accountID, closeWonDate, csRepAtClose, ARR)
SELECT Id, Parent_Payment_Profile_ID__c, AccountId, CloseDate, Customer_Success_at_Close__c, (Opportunity_One_Time_Total__c/hce.exchangeRate) 
FROM ss_sfdc_02.opportunity o
JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = o.currencyISOCode AND o.CloseDate BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE StageName='Closed Won' AND CloseDate >= '2016-01-01' AND Opportunity_One_Time_Total__c > 0 AND Parent_Payment_Profile_ID__c!=0;

UPDATE rpt_workspace.js_servicesAtClose A
JOIN ss_sfdc_02.account B
ON A.accountID=B.Id
SET csRepAtClose='CustomerSuccess@'
WHERE (A.csRepAtClose='' OR A.csRepAtClose IS NULL OR A.csRepAtClose='Tasha Bishop');

UPDATE rpt_workspace.js_servicesAtClose A
JOIN ss_sfdc_02.account B
ON A.accountId=B.Id
JOIN rpt_workspace.js_territoryHistory2016 C
ON B.Name=C.accountName
SET A.territoryAtClose=C.oldTerritory
WHERE A.closeWonDate >= C.modifyDateTime AND A.closeWonDate < C.hist_effectiveThruDateTime;

UPDATE rpt_workspace.js_servicesAtClose A
JOIN ss_sfdc_02.account B
ON A.accountID=B.Id
SET A.territoryatClose=B.Territory__c
WHERE A.territoryAtClose IS NULL;

UPDATE rpt_workspace.js_servicesAtClose
SET segmentAtClose= CASE
WHEN territoryAtClose LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territoryAtClose LIKE 'SMB%' THEN 'SMB' 
WHEN territoryAtClose LIKE 'Major%' THEN 'Major'
WHEN territoryAtClose LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territoryAtClose LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territoryAtClose LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territoryAtClose LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN territoryAtClose LIKE '%Partner%' THEN 'Partner'
WHEN (territoryAtClose LIKE 'Unassigned%' OR territoryAtClose='Not Enough Information (ISR3)' OR territoryAtClose='' OR territoryAtClose IS NULL) THEN 'No Territory'
ELSE 'Strategic'
END
WHERE territoryAtClose IS NOT NULL;

DELETE FROM rpt_workspace.js_servicesAtClose
WHERE (csRepAtClose='' OR csRepAtClose IS NULL OR csRepAtClose='Tasha Bishop') AND (territoryAtClose IS NULL OR territoryAtClose='');

-- Manual Fixes
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10249062 AND closeWonDate = '2017-12-27';
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10561852 AND closeWonDate = '2017-11-30';
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10571992 AND closeWonDate = '2017-11-30';
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10709384 AND closeWonDate = '2017-12-21' AND csRepAtClose = 'Paul McCormack';
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10894404 AND closeWonDate = '2018-01-20';
DELETE FROM rpt_workspace.js_servicesAtClose WHERE paymentProfileID = 10465943 AND closeWonDate = '2017-11-13';

DROP TABLE IF EXISTS rpt_workspace.js_csRetentionCalcSegmentQTD;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csRetentionCalcSegmentQTD
(paymentProfileID INT,
domain VARCHAR(50),
ISP INT,
customer VARCHAR(50),
csRep VARCHAR(50),
csRepID VARCHAR(50),
accountName VARCHAR(50),
accountID VARCHAR(50),
territory VARCHAR(50),
segment VARCHAR(50),
currentACV DEC(10,2),
csRepAtClose VARCHAR(100),
PRIMARY KEY (paymentProfileID),
INDEX (domain),
INDEX (ISP),
INDEX (customer),
INDEX (csRep),
INDEX (csRepID),
INDEX (accountName),
INDEX (accountID));

INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcSegmentQTD(paymentProfileID, domain, currentACV)
SELECT paymentProfileID, domain, ACV FROM rpt_main_02.rpt_paidPlanInfo A
LIMIT 435455445;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD A
JOIN ss_sfdc_02.domain B
ON A.domain=B.Domain_Name_URL__c
JOIN ss_sfdc_02.account C
ON B.Account__c=C.Id
SET A.accountName=C.Name, A.accountID=C.Id, A.csRepID=C.Customer_Success__c, A.territory=C.Territory__c;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD A
JOIN rpt_workspace.js_csNetBookings B ON A.paymentProfileID = B.paymentProfileID
JOIN ss_sfdc_02.user u ON CONCAT(u.firstName," ",u.lastName) = B.csRep
SET A.csRepID = u.Id
WHERE A.accountName = 'Conduent';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD A
SET csRep=
(SELECT CONCAT(B.FirstName, ' ', B.LastName) FROM ss_sfdc_02.user B
WHERE A.csRepID=B.Id);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET csRep='CustomerSuccess@'
WHERE csRepID IS NULL OR csRepID=' ' OR csRep='Tasha Bishop';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD A
JOIN rpt_main_02.arc_ISPDomains B
ON A.domain=B.domain
SET A.ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET segment=
CASE WHEN ISP = 1 THEN 'ISP'
WHEN territory LIKE 'Mid-Market%' THEN 'Mid-Market' 
WHEN territory LIKE 'SMB%' THEN 'SMB' 
WHEN territory LIKE 'Major%' THEN 'Major'
WHEN territory LIKE 'Vertical Market: Retail%' THEN 'Retail'
WHEN territory LIKE 'Vertical Market: EDU%' THEN 'EDU'
WHEN territory LIKE 'Vertical Market: Healthcare%' THEN 'Healthcare'
WHEN territory LIKE 'Vertical Market: Gov%' THEN 'Gov'
WHEN territory LIKE '%Partner%' THEN 'Partner'
WHEN (territory LIKE 'Unassigned%' OR territory='Not Enough Information (ISR3)' OR territory='' OR territory IS NULL) THEN 'No Territory'
ELSE 'Strategic'
END;

INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcSegmentQTD(paymentProfileID, domain, currentACV, territory, segment, csRep, accountName, accountID)
SELECT paymentProfileID, domain, 0, territory, CASE WHEN A.ispDomain = 1 THEN 'ISP' ELSE segment END AS segment, 
customerSuccess, accountName, accountID FROM rpt_main_02.output_RevenueSummaryMonthly A
JOIN ss_sfdc_02.domain B
ON A.domain=B.Domain_Name_URL__c
JOIN ss_sfdc_02.account C
ON B.Account__c=C.Id
WHERE A.recordTypeNew='Cancel' AND A.recordDateTime >= '2017-11-01' AND A.recordDateTime < '2018-02-01' 
AND A.currencyChange=0 AND A.futureLoss IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET domain = 'incitecpivot.com.au',
customer = 'Incitec Pivot Limited',
accountId = '0013300001f6HPxAAM',
csRep = 'Andrew Rustemeyer',
territory = 'Unassigned (CDM)',
segment = 'No Territory'
WHERE paymentProfileID = 7598286;


UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET customer=domain
WHERE ISP IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET customer=CONCAT(domain,'-',paymentProfileID)
WHERE ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET domain='cree.com', ISP=NULL, customer='cree.com', accountName='Cree, Inc.', accountId='0014000000mw0SpAAI', csRep='Reid Kilwine',  
csRepID='00533000003uxWZAAY', territory='Major: East - Open (CDM)', segment='Major'
WHERE paymentProfileID=6892090;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET domain='okq8.se', ISP=NULL, customer='okq8.se', accountName='OK-Q8', accountId='0013300001cH1XWAA0', csRep='Liz Tanonis',
csRepID='00540000002n544AAA', territory='Unassigned (CDM)', segment='No Territory'
WHERE paymentProfileID=3975994;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET domain='ascension.org', ISP=NULL, customer='ascension.org', accountName='Ascension Health', accountId='0014000000uWnXWAA0', csRep='Johannah Brown',
csRepID='00533000003OTdUAAW', territory='Major: East3 - Jennifer Abramowitz (CDM)', segment='Major'
WHERE paymentProfileID=8494109;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET domain='cbre.com', ISP=NULL, customer='cbre.com', accountName='CB Richard Ellis Group', accountId='0014000000mw0MvAAI', csRep='Dillon Brady',
csRepID='00540000002nyJaAAI', territory='Los Angeles', segment='Strategic'
WHERE paymentProfileID=4047305;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET currentACV=ROUND(currentACV, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD A
LEFT JOIN ss_sfdc_02.opportunity o ON A.paymentProfileID = o.parent_payment_profile_ID__c 
AND o.CloseDate >= '2017-11-01' AND o.CloseDate < '2018-02-01' AND o.StageName IN('Closed Won', 'Closed Lost')
AND ARR_Variance__c != 0
SET A.csRepAtClose = o.Customer_Success_at_Close__c;


DROP TABLE IF EXISTS rpt_workspace.js_csRetentionCalcSegmentQTDFinal;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csRetentionCalcSegmentQTDFinal
(paymentProfileID INT,
accountType VARCHAR(50),
domain VARCHAR(50),
ISP INT,
customer VARCHAR(50),
csRep VARCHAR(50),
csRepID VARCHAR(50),
accountName VARCHAR(50),
accountID VARCHAR(50),
territory VARCHAR(50),
segment VARCHAR(50),
currentACV DEC(10,2),
quarterServicesACVbySegment DEC(10,2),
quarterNewACVbySegment DEC(10,2),
quarterExpansionACVbySegment DEC(10,2),
quarterCancelACVbySegment DEC(10,2),
quarterReductionACVbySegment DEC(10,2),
quarterNewACVbyOther DEC(10,2),
quarterExpansionACVbyOther DEC(10,2),
quarterCancelACVbyOther DEC(10,2),
quarterReductionACVbyOther DEC(10,2),
csRepAtClose VARCHAR(100),
PRIMARY KEY (paymentProfileID, segment),
INDEX (domain),
INDEX (ISP),
INDEX (customer),
INDEX (csRepID),
INDEX (accountName),
INDEX (accountID),
INDEX (territory),
INDEX (segment));

INSERT INTO rpt_workspace.js_csRetentionCalcSegmentQTDFinal(paymentProfileID, accountType, domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV, csRepAtClose)
SELECT paymentProfileID, 'Currently Owned', domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV, csRepAtClose 
FROM rpt_workspace.js_csRetentionCalcSegmentQTD;

/* insert ignore into rpt_workspace.js_csRetentionCalcSegmentQTDFinal(paymentProfileID, accountType, domain, ISP, csRep, accountName, territory, segment)
select paymentProfileID, 'Previously Owned', domain, ispDomain, customerSuccess, accountName, territory, segment 
from rpt_main_02.output_RevenueSummaryMonthly 
where recordDateTime >= '2017-11-01' and recordDateTime < '2018-02-01' and currencyChange=0 and futureLoss is null and segment is not null; */

INSERT IGNORE INTO rpt_workspace.js_csRetentionCalcSegmentQTDFinal(paymentProfileID, accountType, csRep, territory, segment)
SELECT paymentProfileId, 'Previously Owned', csRepAtClose, territoryAtClose, segmentAtClose FROM rpt_workspace.js_servicesAtClose
WHERE closeWonDate >= '2017-11-01' AND closeWonDate < '2018-02-01';

/* delete from rpt_workspace.js_csRetentionCalcSegmentQTDFinal
where csRep is null or csRep='' limit 44444444; */

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.paymentProfileID=B.paymentProfileID
SET A.domain=B.mainContactDomain
WHERE A.domain IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN rpt_main_02.arc_ISPDomains B
ON A.domain=B.domain
SET ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET ISP=0
WHERE ISP IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN ss_sfdc_02.domain B
ON A.domain=B.Domain_Name_URL__c
JOIN ss_sfdc_02.account C
ON B.Account__c=C.Id
SET A.accountName=B.Name
WHERE A.accountName IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET customer=domain
WHERE ISP=0;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET customer=CONCAT(domain,'-',paymentProfileID)
WHERE ISP=1;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN ss_sfdc_02.account B
ON A.AccountName=B.Name
SET A.accountID=B.Id;


UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterNewACVbySegment=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.segment=B.segment AND B.domainLevelRecordTypeNew='New' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterExpansionACVbySegment=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.segment=B.segment AND B.domainLevelRecordTypeNew='Expansion' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterCancelACVbySegment=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.segment=B.segment AND B.domainLevelRecordTypeNew='Cancel' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterReductionACVbySegment=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND A.segment=B.segment AND B.domainLevelRecordTypeNew='Reduction' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterServicesACVBySegment=
(SELECT SUM(ARR) FROM rpt_workspace.js_servicesAtClose B
WHERE A.paymentProfileID=B.paymentProfileID AND A.segment=B.segmentAtClose AND B.closeWonDate >= '2017-11-01' AND B.closeWonDate < '2018-02-01');

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterNewACVbySegment=ROUND(quarterNewACVbySegment, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterExpansionACVbySegment=ROUND(quarterExpansionACVbySegment, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterCancelACVbySegment=ROUND(quarterCancelACVbySegment, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterReductionACVbySegment=ROUND(quarterReductionACVbySegment, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterServicesACVbySegment=ROUND(quarterServicesACVbySegment, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterNewACVbySegment=0
WHERE quarterNewACVbySegment IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterExpansionACVbySegment=0
WHERE quarterExpansionACVbySegment IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterCancelACVbySegment=0
WHERE quarterCancelACVbySegment IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterReductionACVbySegment=0
WHERE quarterReductionACVbySegment IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterServicesACVbySegment=0
WHERE quarterServicesACVbySegment IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterNewACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.segment!=B.segment OR B.segment IS NULL) AND B.domainLevelRecordTypeNew='New' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterExpansionACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.segment!=B.segment OR B.segment IS NULL) AND B.domainLevelRecordTypeNew='Expansion' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterCancelACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.segment!=B.segment OR B.segment IS NULL) AND B.domainLevelRecordTypeNew='Cancel' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
SET quarterReductionACVbyOther=
(SELECT SUM(MonthlyPaymentChange)*12 FROM rpt_main_02.output_RevenueSummaryMonthly B
WHERE A.paymentProfileID=B.paymentProfileID AND (A.segment!=B.segment OR B.segment IS NULL) AND B.domainLevelRecordTypeNew='Reduction' AND 
B.recordDateTime >= '2017-11-01' AND B.recordDateTime < '2018-02-01' AND B.currencyChange=0 AND B.futureLoss IS NULL);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterNewACVbyOther=ROUND(quarterNewACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterExpansionACVbyOther=ROUND(quarterExpansionACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterCancelACVbyOther=ROUND(quarterCancelACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterReductionACVbyOther=ROUND(quarterReductionACVbyOther, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterNewACVbyOther=0
WHERE quarterNewACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterExpansionACVbyOther=0
WHERE quarterExpansionACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterCancelACVbyOther=0
WHERE quarterCancelACVbyOther IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET quarterReductionACVbyOther=0
WHERE quarterReductionACVbyOther IS NULL;

/* delete from rpt_workspace.js_csRetentionCalcSegmentQTDFinal
where accountType='Currently Owned' and quarterServicesACVbySegment=0 and quarterNewACVbySegment=0 and quarterExpansionACVbySegment=0 
and quarterCancelACVbySegment=0 and quarterReductionACVbySegment=0 
and (quarterNewACVbyOther!=0 or quarterExpansionACVbyOther!=0 or quarterCancelACVbyOther!=0 or quarterReductionACVbyOther!=0);

delete from rpt_workspace.js_csRetentionCalcSegmentQTDFinal
where accountType='Currently Owned' and currentACV=0 and quarterServicesACVbySegment=0 and quarterNewACVbySegment=0 and quarterExpansionACVbySegment=0 
and quarterCancelACVbySegment=0 and quarterReductionACVbySegment=0; */

DELETE FROM rpt_workspace.js_csRetentionCalcSegmentQTDFinal 
WHERE paymentProfileID = 9781684 AND quarterCancelACVBySegment = '-16800.00';

DELETE FROM rpt_workspace.js_csRetentionCalcSegmentQTDFinal 
WHERE paymentProfileID = 9694798 AND quarterReductionACVBySegment = '-3000.00';

DELETE FROM rpt_workspace.js_csRetentionCalcSegmentQTDFinal 
WHERE paymentProfileID = 9810533 AND quarterReductionACVBySegment = '-6900.00';

DROP TABLE IF EXISTS rpt_workspace.js_csRetentionCalcSegmentQTDFinalStaging;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_csRetentionCalcSegmentQTDFinalStaging
(paymentProfileID INT,
currentACV DEC(10,2),
PRIMARY KEY (paymentProfileID));

INSERT INTO rpt_workspace.js_csRetentionCalcSegmentQTDFinalStaging
SELECT paymentProfileID, currentACV FROM rpt_workspace.js_csRetentionCalcSegmentQTDFinal
WHERE accountType='Currently Owned';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN rpt_workspace.js_csRetentionCalcSegmentQTDFinalStaging B
ON A.paymentProfileID=B.paymentProfileID
SET A.currentACV=B.currentACV
WHERE A.accountType='Previously Owned';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal A
JOIN rpt_main_02.rpt_paymentProfile B
ON A.paymentProfileID=B.paymentProfileID
SET A.currentACV=(B.planRate_USD/B.paymentTerm)*12
WHERE A.currentACV IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET currentACV=ROUND(currentACV, 0);

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET currentACV=0
WHERE currentACV IS NULL;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET currentACV=0
WHERE accountType='Previously Owned' AND 
quarterServicesACVbySegment!=0 AND quarterNewACVbySegment=0 AND quarterExpansionACVbySegment=0 AND quarterCancelACVbySegment=0 AND quarterReductionACVbySegment=0;

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET segment = 'No Territory' WHERE segment IS NULL OR segment = '';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTDFinal
SET CsRep = 'CustomerSuccess@' WHERE CsRep = '';

UPDATE rpt_workspace.js_csRetentionCalcSegmentQTD
SET CsRep = 'CustomerSuccess@' WHERE CsRep = '';

SELECT * FROM rpt_workspace.js_csRetentionCalcSegmentQTDFinal;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard3V2.sql");
