select "******************************************************************************************************************************", NOW();
select "******** Throwaway Part 4: Marketo Push Data - start ******** ", NOW();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CALL rpt_main_02.SMARTSHEET_START_LOG ("Throwaway Part 4: Marketo Push Data");
SET @@sql_mode = '';


CALL rpt_main_02.SMARTSHEET_START_LOG ("Max record IDs");

SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenID" INTO @NewMaxaccessTokenID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenSessionID" INTO @NewMaxaccessTokenSessionID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxbrandID" INTO @NewMaxbrandID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDInsert" INTO @NewMaxContainerIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDModify" INTO @NewMaxContainerIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxgoogleAppsDomainID"  INTO @NewMaxgoogleAppsDomainID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxHPPmodifyDateTime"  INTO @NewMaxHPPmodifyDateTime;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxmailDistributionID"  INTO @NewMaxmailDistributionID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxopedIDIdentifierID"  INTO @NewMaxopedIDIdentifierID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationID"  INTO @NewMaxorganizationID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationUserRoleID"  INTO @NewMaxorganizationUserRoleID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NEWmaxPaymentProfileID" 	 INTO @NEWmaxPaymentProfileID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxreminderID"  INTO @NewMaxreminderID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxRequestLogID" INTO @NewMaxRequestLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsessionLogID" INTO @NewMaxsessionLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDInsert" INTO @NewMaxsheetLinkIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDModify" INTO @NewMaxsheetLinkIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestID" 	 INTO @NewMaxsignupRequestID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestTrackingItemID"  INTO @NewMaxsignupRequestTrackingItemID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsiteSettingElementValueID"  INTO @NewMaxsiteSettingElementValueID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDInsert"  INTO @NewMaxTemplateIDInsert;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDModify" INTO @NewMaxTemplateIDModify;
SELECT maximumValue  		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserID"  INTO @NewMaxuserID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxworkspaceID"  INTO @NewMaxworkspaceID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserDataID" INTO @NewMaxuserDataID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorgUserModifyDate" INTO @NewMaxorgUserModifyDate;

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Max record IDs");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_userPaymentFunnelProgress table - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_userPaymentFunnelProgress");


-- Identify individual trials since 2012

DROP TABLE IF EXISTS rpt_main_02.stg_user_trials;
CREATE TABLE rpt_main_02.stg_user_trials
(
	userID int,
	PRIMARY KEY (userID)
)
;



-- Grab users that have had a trial
INSERT INTO rpt_main_02.stg_user_trials
SELECT DISTINCT userID
FROM rpt_main_02.rpt_trials
WHERE 
trialDateTime >= '2012-01-01'
AND firstTrial = 1
AND trialType = 1
;

-- TEST COMMENT

-- Grab remaining users that have not had a trial
INSERT INTO rpt_main_02.stg_user_trials
SELECT DISTINCT ua.userID
FROM rpt_main_02.userAccount ua
LEFT JOIN rpt_main_02.stg_user_trials b ON ua.userID=b.userID
WHERE b.userID IS NULL
AND ua.insertDateTime >= '2012-01-01'
;

-- Retrieve payment process page views for trial users
-- DROP TABLE IF EXISTS rpt_main_02.rpt_payment_waterfall_actions;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_payment_waterfall_actions
(
	insertByUserID INT,
	logDate DATE,
	objectID INT,
	actionID INT,
	parm1Int INT,
	parm1String VARCHAR(100),
	logCount INT,
	key ix_unique (insertByUserID, logDate, objectID, actionID, parm1Int, parm1String),
	key ix_logdate (logdate),
	key ix_insertByUserID (insertByUserID)
)
;

 SELECT MAX(logDate) FROM rpt_main_02.rpt_payment_waterfall_actions INTO @maxLogDate;
 
 INSERT INTO rpt_main_02.rpt_payment_waterfall_actions
 SELECT 
 	arc.insertByUserID, 
 	arc.logDate,
 	arc.objectID,
 	arc.actionID,
 	arc.parm1Int,
 	arc.parm1String,
	 arc.logCount
 FROM rpt_main_02.arc_clientEventRollup arc
 JOIN rpt_main_02.stg_user_trials m ON m.userID=arc.insertByUserID
 LEFT OUTER JOIN rpt_main_02.rpt_payment_waterfall_actions p 
 	ON arc.insertByUserID=p.insertByUserID
	 AND arc.logDate=p.logDate
 	AND arc.objectID=p.objectID
	 AND arc.actionID=p.actionID
	 AND arc.parm1Int=p.parm1Int
	 AND arc.parm1String=p.parm1String
 WHERE arc.objectID IN (2151,2152,2153,2155,2161)
 /* the line below is being left out for now due to the non-capture of clicks for users that elect to purchase with PayPal */
  -- OR (objectID = 2001 AND actionID = 22 AND parm1Int = 7018 AND parm1String = "btn_save" )
 AND p.insertByUserID IS NULL
 AND arc.logDate >= @maxLogDate
 ;



-- Determine user view count by phase in the payment funnel

/* DROP TABLE if exists rpt_main_02.rpt_paymentWaterfallPhasesNew;
CREATE TABLE if not exists rpt_main_02.rpt_paymentWaterfallPhasesNew
(userID BIGINT,
logCount INT,
FunnelPhase VARCHAR(50),
PRIMARY KEY (userID, FunnelPhase),
KEY userID(userID)); */


INSERT IGNORE INTO rpt_main_02.rpt_paymentWaterfallPhasesNew
SELECT userID, 1, "HadTrial"
FROM rpt_main_02.rpt_trials t
WHERE t.trialType = 1 AND t.firstTrial = 1
AND t.trialDateTime >= '2012-01-01'
AND t.trialDateTime >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
GROUP BY 1;

INSERT IGNORE INTO rpt_main_02.rpt_paymentWaterfallPhasesNew
SELECT insertByUserID, SUM(logCount), 
	CASE WHEN objectID = 2151 THEN 'ViewedStep1'
	WHEN objectID = 2152 THEN 'ViewedStep2'
	WHEN objectID = 2153 THEN 'ViewedStep3'
	WHEN objectID = 2161 AND actionID = 52 THEN 'PayPal Start'
	WHEN objectID = 2161 AND actionID = 53 THEN 'PayPal Complete'
	WHEN objectID = 2155 THEN 'ViewedConfirmPage' ELSE NULL END
FROM rpt_main_02.rpt_payment_waterfall_actions 
WHERE objectID != 2001 AND logDate >= DATE_SUB(CURRENT_DATE, INTERVAL 7 DAY)
GROUP BY 1,3;

INSERT IGNORE INTO rpt_main_02.rpt_paymentWaterfallPhasesNew
SELECT ap.userID, 1, "LicensedUser"
FROM rpt_workspace.cDunn_allPaid ap
JOIN rpt_main_02.rpt_trials t ON t.userID = ap.userID AND t.trialType = 1 AND t.firstTrial = 1 AND t.trialDateTime >= '2012-01-01'
GROUP BY 1;





-- This table is used for determining the farthest step a user has reached in the payment funnel
DROP TABLE rpt_main_02.rpt_userPaymentFunnelProgress;
CREATE TABLE rpt_main_02.rpt_userPaymentFunnelProgress
(
	userID BIGINT,
	ViewedStep1 TINYINT DEFAULT 0,
	ViewedStep2 TINYINT DEFAULT 0,
	ViewedStep3 TINYINT DEFAULT 0,
	PayPalStart TINYINT DEFAULT 0,
	PayPalComplete TINYINT DEFAULT 0,
	ViewedConfirmPage TINYINT DEFAULT 0,
	PRIMARY KEY (userID)
)
;

INSERT INTO rpt_main_02.rpt_userPaymentFunnelProgress (userID)
SELECT DISTINCT userID
FROM rpt_main_02.rpt_paymentWaterfallPhasesNew
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.ViewedStep1 = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'ViewedStep1'
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.ViewedStep2 = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'ViewedStep2'
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.ViewedStep3 = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'ViewedStep3'
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.PayPalStart = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'PayPal Start'
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.PayPalComplete = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'PayPal Complete'
;

UPDATE rpt_main_02.rpt_userPaymentFunnelProgress upfp
JOIN rpt_main_02.rpt_paymentWaterfallPhasesNew stg ON upfp.userID=stg.userID
SET upfp.ViewedConfirmPage = CASE WHEN stg.logCount > 0 THEN 1 ELSE 0 END
WHERE stg.funnelPhase = 'ViewedConfirmPage'
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_userPaymentFunnelProgress");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_DailyWellQualifiedLeads table - start ******** ", NOW();

/*Start rpt_main_02.arc_DailyWellQualifiedLeads*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_DailyWellQualifiedLeads");


/*DROP TABLE IF EXISTS rpt_main_02.arc_DailyWellQualifiedLeads;
CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_DailyWellQualifiedLeads(
	snapshotDate DATE,
	random FLOAT(10,9), 
	userID BIGINT, 
	dailyCount INT,
	PRIMARY KEY(userID)); 
CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_DailyWellQualifiedProsumer(
	snapshotDate DATE,
	userID BIGINT, 
	dailyCount INT,
	SSOwner VARCHAR(20),
	PRIMARY KEY(userID)); */

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_DailyWellQualifiedLeads(snapshotDate, random, userID)
SELECT 
MIN(rpt_main_02.arc_wellQualifiedLeads.snapshotDate) AS minSnapshotDate,
RAND(),
rpt_main_02.arc_wellQualifiedLeads.userID
FROM rpt_main_02.arc_wellQualifiedLeads
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedLeads ON arc_DailyWellQualifiedLeads.userID = arc_wellQualifiedLeads.userID
WHERE arc_DailyWellQualifiedLeads.snapshotDate IS NULL
GROUP BY 3
HAVING minSnapshotDate = CURRENT_DATE()
;
COMMIT;

UPDATE rpt_main_02.arc_DailyWellQualifiedLeads
JOIN rpt_main_02.arc_wellQualifiedLeads ON arc_wellQualifiedLeads.snapshotDate = arc_DailyWellQualifiedLeads.snapshotDate  
	AND arc_wellQualifiedLeads.userID = arc_DailyWellQualifiedLeads.userID
SET arc_DailyWellQualifiedLeads.leadStrength = arc_wellQualifiedLeads.leadStrength
WHERE arc_DailyWellQualifiedLeads.leadStrength IS NULL
;
COMMIT;

SET @num = 0;
COMMIT;

UPDATE rpt_main_02.arc_DailyWellQualifiedLeads
SET dailyCount = @num:=@num + 1	WHERE dailyCount IS NULL AND snapshotDate = CURRENT_DATE()
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_DailyWellQualifiedLeads");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.googleAppsDomain");


DROP TABLE IF EXISTS rpt_main_02.googleAppsDomain;
CREATE TABLE IF NOT EXISTS rpt_main_02.googleAppsDomain LIKE ss_core_02.googleAppsDomain;
INSERT rpt_main_02.googleAppsDomain  
SELECT *  
FROM ss_core_02.googleAppsDomain
WHERE googleAppsDomainID <= @NewMaxgoogleAppsDomainID
;

ALTER TABLE rpt_main_02.googleAppsDomain CONVERT TO CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_520_ci`;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.googleAppsDomain");

select "******************************************************************************************************************************", NOW();
select "******** rpt_paidDomains table - start ******** ", NOW();

/*Might be able to combine with domain rollup table in the future*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paidDomains insert");
 
DROP TABLE IF EXISTS rpt_main_02.rpt_paidDomains;
CREATE TABLE rpt_main_02.rpt_paidDomains(mainContactDomain VARCHAR(100), companyName VARCHAR(100), maxProduct VARCHAR(50), PRIMARY KEY (mainContactDomain));
INSERT INTO rpt_main_02.rpt_paidDomains (mainContactDomain, companyName, maxProduct)
SELECT rpt_paymentProfile.mainContactDomain,
rpt_paymentProfile.companyName,
CASE MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(rpt_paymentProfile.productID))
	WHEN 1 THEN "Cancelled"
	WHEN 2 THEN "Trial"
	WHEN 3 THEN "Free"
	WHEN 4 THEN "Student"
	WHEN 5 THEN "Basic"
	WHEN 6 THEN "Advanced"
	WHEN 7 THEN "Premium"
	WHEN 8 THEN "Team"
	WHEN 9 THEN "Team Plus"
	WHEN 10 THEN "Business"
	WHEN 11 THEN "Enterprise_Legacy"
	WHEN 12 THEN "Enterprise"
END AS maxProduct

FROM rpt_main_02.rpt_paymentProfile
WHERE rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.paymentType NOT IN (4,5,7) AND paymentTotal > 0
GROUP BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paidDomains insert");


select "******************************************************************************************************************************", NOW();
select "******** rpt_domainRollup table - start ******** ", NOW();

/*Start rpt_main_02.rpt_domainRollup*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_domainRollup insert");


DROP TABLE IF EXISTS rpt_main_02.rpt_domainRollup;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_domainRollup(
	domain VARCHAR(100), 
	last30DaysLoginCount INT, 
	usersWhoLoggedInCount INT, 
	sheetCreatorsCount INT, 
	sheetCount INT, 
	paidUserCount INT,
	usersInTrial INT,
	usersLoggedInPast12Months INT, 
	googleAppsDomain TINYINT DEFAULT 0, 
	PRIMARY KEY(domain))
;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_domainRollup(domain, last30DaysLoginCount, usersWhoLoggedInCount, sheetCreatorsCount, sheetCount, paidUserCount)
SELECT 
	domain, 
	SUM(last30DaysLoginCount),
	COUNT(rpt_loginCountTotal.loginCount), 
	COUNT(rpt_paymentProfile.paymentProfileID), 
	SUM(rpt_containerCountsByUser.sheetCount),
	SUM(CASE WHEN rpt_paymentProfile.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END)
FROM rpt_main_02.rpt_containerCountsByUser
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser FORCE INDEX (PRIMARY) ON rpt_featureCountRollupByUser.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal FORCE INDEX (PRIMARY) ON rpt_loginCountTotal.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile FORCE INDEX (idx_rpt_paymentProfileMainContactUserID) ON rpt_main_02.rpt_paymentProfile.mainContactUserID = rpt_featureCountRollupByUser.userID AND rpt_main_02.rpt_paymentProfile.accountType !=3
WHERE domain != ''
  GROUP BY 1;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_domainRollup insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_domainRollup update");

SET AUTOCOMMIT = 0;
DROP TABLE IF EXISTS rpt_main_02.tmp_usersInTrial;
CREATE TEMPORARY TABLE IF NOT EXISTS rpt_main_02.tmp_usersInTrial
(INDEX (mainContactDomain))
SELECT mainContactDomain, COUNT(DISTINCT mainContactUserID) usersInTrial
FROM rpt_main_02.rpt_paymentProfile
WHERE productID = 1
GROUP BY mainContactDomain
;

UPDATE rpt_main_02.rpt_domainRollup dr
JOIN rpt_main_02.tmp_usersInTrial pp ON dr.domain = pp.mainContactDomain
SET dr.usersInTrial = pp.usersInTrial
;
COMMIT;
SET AUTOCOMMIT = 1;

SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_domainRollup A
SET usersLoggedInPast12Months = (SELECT COUNT(DISTINCT(lct.userID))
	FROM rpt_main_02.userAccount u
	JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = u.userID
	WHERE u.domain = A.domain
	AND lct.lastLogin >= DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH))
	;
COMMIT;
SET AUTOCOMMIT = 1;

SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_domainRollup rd
  JOIN rpt_main_02.googleAppsDomain gd ON rd.domain = gd.domain
SET rd.googleAppsDomain = 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_domainRollup update");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_launchedSolutionsByUser Update - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_launchedSolutionsByUser");

insert ignore into rpt_main_02.rpt_launchedSolutionsByUser(containerID, userID, name, insertDateTime, Department, sourceID)
select c1.containerID, 
c1.insertbyuserID as userID, 
c2.name, 
c1.insertDateTime, 
case when c1.sourceID IN ('37135095','37135142','37135073','37135052','37135121') THEN "Human Resources"
	when c1.sourceID IN ('35400725','36629285','35400371','35400736','35400756') then "IT & Operations"
	when c1.sourceID IN ('37065261','30627331','31010875','30765397','31381577','31010888','30818109') THEN "Marketing"
	when c1.sourceID IN ('34285368','34285408','34285401','34285339','34285382') THEN "Product Development"
	when c1.sourceID IN ('33457416','32259965','33457411','32259239','33457796','33758874') THEN "Project Management"
	WHEN c1.sourceID IN ('35796086','35796064','35406663','35796108') THEN "Sales" 
		END as Department,
c1.sourceID
from rpt_main_02.container c1 
	join rpt_main_02.container c2 FORCE INDEX (PRIMARY) on c1.sourceID = c2.containerID
where c1.sourceID IN ('37135095','37135142','37135073','37135052','37135121','35400725','36629285','35400371','35400736','35400756','37065261','30627331','31010875','30765397','31381577','31010888','30818109','34285368','34285408','34285401','34285339','34285382','33457416','32259965','33457411','32259239','33457796','33758874','35796086','35796064','35406663','35796108');

update rpt_main_02.rpt_launchedSolutionsByUser set name = replace(name,'Solution - ','');

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_launchedSolutionsByUser");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** Throwaway Part 4: Marketo Push Data - end ******** ", NOW();
/*End*/


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Throwaway Part 4: Marketo Push Data");