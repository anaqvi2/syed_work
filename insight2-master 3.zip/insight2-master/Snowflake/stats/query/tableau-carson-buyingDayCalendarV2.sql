
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-carson-buyingDayCalendar.csv");

SET @@sql_mode = '';


DROP TABLE IF EXISTS rpt_main_02.buyingDayCalendar;
CREATE TABLE IF NOT EXISTS rpt_main_02.buyingDayCalendar
(DATE DATE,
buyingDays DECIMAL(10,2),
PRIMARY KEY (DATE));

INSERT INTO rpt_main_02.buyingDayCalendar
SELECT d.dailyDate, 
CASE WHEN DAYOFWEEK(d.dailyDate) IN(1,7) THEN 0.25 
	WHEN h.holidayDate IS NOT NULL THEN 0.25 ELSE 1 END
FROM rpt_main_02.ref_Dates d
LEFT OUTER JOIN rpt_main_02.ref_holidays h ON h.holidayDate = d.dailyDate
WHERE d.dailyDate <= date_add(curdate(), interval 1 year);

select max(date(recordDateTime)) from rpt_main_02.output_RevenueSummaryMonthly 
WHERE recordDateTime < NOW() INTO @maxDate;

SELECT * FROM rpt_main_02.buyingDayCalendar where DATE < @maxDate;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-carson-buyingDayCalendar.csv");