
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT MAX(signupDate) FROM rpt_workspace.cDunn_signupLoginMader1 INTO @maxOldSignup;

DELETE FROM rpt_workspace.cDunn_signupLoginMader1 WHERE signupDate >= DATE_SUB(@maxOldSignup, INTERVAL 3 DAY);

SELECT MAX(signupDate) FROM rpt_workspace.cDunn_signupLoginMader1 INTO @maxSignup;

INSERT IGNORE INTO rpt_workspace.cDunn_signupLoginMader1 (userID, paymentProfileID, domain, signupDate, firstLogin, bucket, sourceFriendly, subSource, productName, ipCountry)
SELECT ss.userID, pp.paymentProfileID, ua.domain, ss.signupInsertDateTime, MIN(sl.insertDateTime), 
ss.bucket, ss.sourceFriendly, ss.subSourceFriendly, pp.productName, ip.ipCountry
FROM rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.userAccount ua ON ua.userID = ss.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog sl ON sl.userID = ss.userID AND sl.insertDateTime >= ss.signupInsertDateTime
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile pp ON ss.userID = pp.mainContactUserID AND pp.accountType != 3
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = ua.userID
WHERE ss.signupInsertDateTime > @maxSignup
GROUP BY 1
ORDER BY 4;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET secondDelay = TIMESTAMPDIFF(SECOND, A.signupDate, A.firstLogin) WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET minuteDelay = TIMESTAMPDIFF(MINUTE, A.signupDate, A.firstLogin) WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET isIspDomain = (SELECT CASE WHEN isp.domain IS NULL THEN 'Non-ISP' ELSE 'ISP' END
	FROM rpt_main_02.arc_ISPDomains isp
	WHERE A.domain = isp.domain
	GROUP BY A.userID) WHERE signupDate >= @maxSignup;
	
UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET isIspDomain = 'Non-ISP' WHERE isIspDomain IS NULL;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
JOIN rpt_main_02.rpt_signupSource ss ON ss.userID = A.userID
SET subSource = ss.subSourceFriendly WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET everPaidPlan = (SELECT CASE WHEN MAX(hpp.productID) > 2 THEN 1 ELSE 0 END 
	FROM rpt_main_02.hist_paymentProfile hpp
	WHERE hpp.ownerID = A.userID AND hpp.accountType != 3) WHERE signupDate >= @maxSignup;
	
UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET accountOwner = (SELECT MAX(pp.hasPaid) FROM rpt_main_02.rpt_paymentProfile pp WHERE pp.mainContactUserID = A.userID) WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET accountOwner = 0 WHERE accountOwner IS NULL AND signupDate >= @maxSignup;


UPDATE rpt_workspace.cDunn_signupLoginMader1 A
JOIN rpt_main_02.rpt_sessionLog sl ON sl.userID = A.userID AND sl.insertDateTime = A.firstLogin
SET A.sessionLogID = sl.sessionLogID WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
JOIN rpt_main_02.rpt_sessionLog sl ON sl.userID = A.userID
SET A.loginType = sl.loginType
WHERE sl.userID = A.userID AND sl.sessionLogID = A.sessionLogID AND signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
STRAIGHT_JOIN rpt_main_02.rpt_userIPLocation ip  ON ip.userID = A.userID
SET A.ipCountry = ip.ipCountry WHERE signupDate >= @maxSignup;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET ispDomain = (SELECT isp.domain 
	FROM rpt_main_02.arc_ISPDomains isp
	WHERE A.domain = isp.domain) WHERE signupDate >= @maxSignup;
	
UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET secondRange = 
	CASE WHEN A.secondDelay = 0 THEN "0 Delay"
		WHEN A.secondDelay <= 15 THEN "15 Sec"
		WHEN A.secondDelay <= 30 THEN "30 Sec"
		WHEN A.secondDelay <= 45 THEN "45 Sec"
		WHEN A.secondDelay <= 60 THEN "1 Min"
		WHEN A.secondDelay <= 75 THEN "1.25 Min"
		WHEN A.secondDelay <= 90 THEN "1.5 Min"
		WHEN A.secondDelay <= 105 THEN "1.75 Min"
		WHEN A.secondDelay <= 120 THEN "2 Min"
		WHEN A.secondDelay <= 135 THEN "2.25 Min"
		WHEN A.secondDelay <= 150 THEN "2.5 Min"
		WHEN A.secondDelay <= 165 THEN "2.75 Min"
		WHEN A.secondDelay <= 180 THEN "3 Min"
		WHEN A.secondDelay <= 195 THEN "3.25 Min"
		WHEN A.secondDelay <= 210 THEN "3.5 Min"
		WHEN A.secondDelay <= 225 THEN "3.75 Min"
		WHEN A.secondDelay <= 240 THEN "4 Min"
		WHEN A.secondDelay <= 255 THEN "4.25 Min"
		WHEN A.secondDelay <= 270 THEN "4.5 Min"
		WHEN A.secondDelay <= 285 THEN "4.75 Min"
		WHEN A.secondDelay <= 300 THEN "5 Min"
		WHEN A.secondDelay <= 900 THEN "5-15 Min"
		WHEN A.secondDelay <= 7200 THEN "15 Min - 2 Hours"
		WHEN A.secondDelay <= 172800 THEN "2-48 Hours"
		WHEN A.secondDelay > 172800 THEN "48 Hours +"
		WHEN A.secondDelay IS NULL THEN "Never Logged In" END WHERE secondRange IS NULL;
		
UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET secondRangeTodd =  
CASE WHEN A.secondDelay = 0 THEN "0 Delay"
	WHEN A.secondDelay <= 15 THEN "Under 15 Sec"
	WHEN A.secondDelay <= 60 THEN "15-60 Seconds"
	WHEN A.secondDelay <= 300 THEN "1-5 Minutes"
	WHEN A.secondDelay > 300 THEN "5+ Minutes"
	WHEN A.secondDelay IS NULL THEN "Never Logged In" END WHERE secondRangeTodd IS NULL;
	
/* ALTER TABLE rpt_workspace.cDunn_signupLoginMader1
ADD emailAddress VARCHAR(100);

ALTER TABLE rpt_workspace.cDunn_signupLoginMader1
ADD microsoftDomain TINYINT; */


UPDATE rpt_workspace.cDunn_signupLoginMader1 A
JOIN rpt_main_02.userAccount u ON u.userID = A.userID
SET A.emailAddress = u.emailAddress;

UPDATE rpt_workspace.cDunn_signupLoginMader1 A
SET microsoftDomain = CASE WHEN domain LIKE '%onmicrosoft%' THEN 1 ELSE 0 END;
	
SELECT * FROM rpt_workspace.cDunn_signupLoginMader1 LIMIT 5000000;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("signupLoginDelayV2.sql");
