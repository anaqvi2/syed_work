
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-paymentTransactionFullV2.sql");

SET @@sql_mode = '';


DROP TABLE IF EXISTS rpt_workspace.cDunn_paymentErrorTerms;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_paymentErrorTerms
(paymentProfileID BIGINT,
paymentTermStartDate DATETIME,
paymentTermEndDate DATETIME,
paymentErrors INT,
termNumber INT,
paymentDateTime DATETIME,
PRIMARY KEY (paymentProfileID, paymentTermStartDate));

INSERT INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, MIN(paymentDateTime), 
CASE WHEN DATE_ADD(paymentDateTime, INTERVAL 30 DAY) > NOW() THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentDateTime, INTERVAL 30 DAY) END, 1
FROM rpt_main_02.rpt_paymentTransactionReport 
WHERE result > 0
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 2
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 1 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 3
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 2 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 4
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 3 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 5
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 4 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 6
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 5 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 7
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 6 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 8
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 7 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 9
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 8 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 10
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 9 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.cDunn_paymentErrorTerms (paymentProfileID, paymentTermStartDate, paymentTermEndDate, termNumber)
SELECT paymentProfileID, paymentTermEndDate, 
CASE WHEN DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) > CONCAT(CURRENT_DATE," 00:00:00") THEN CONCAT(CURRENT_DATE," 00:00:00") ELSE DATE_ADD(paymentTermEndDate, INTERVAL 30 DAY) END, 11
FROM rpt_workspace.cDunn_paymentErrorTerms 
WHERE termNumber = 10 
AND paymentTermEndDate < CONCAT(CURRENT_DATE," 00:00:00")
GROUP BY 1;

UPDATE rpt_workspace.cDunn_paymentErrorTerms A
SET paymentErrors = (SELECT COUNT(*)
	FROM rpt_main_02.rpt_paymentTransactionReport B
		WHERE A.paymentProfileID = B.paymentProfileID AND B.result > 0 AND B.paymentDateTime BETWEEN A.paymentTermStartDate AND A.paymentTermEndDate);
		
UPDATE rpt_workspace.cDunn_paymentErrorTerms A
	JOIN rpt_main_02.rpt_paymentTransactionReport B ON A.paymentProfileID = B.paymentProfileID 
		AND B.result > 0 AND B.paymentDateTime BETWEEN A.paymentTermStartDate AND A.paymentTermEndDate
	SET A.paymentDateTime = B.paymentDateTime;
		
DELETE FROM rpt_workspace.cDunn_paymentErrorTerms
WHERE paymentErrors = 0;

SELECT A.*, 'SuccessfulTransaction' AS 'Error'
FROM rpt_main_02.rpt_paymentTransactionReport A
WHERE result = 0

UNION ALL

SELECT A.*, 'Error'
FROM rpt_main_02.rpt_paymentTransactionReport A
JOIN rpt_workspace.cDunn_paymentErrorTerms B ON A.paymentProfileID = B.paymentProfileID AND A.paymentDateTime = B.paymentDateTime
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-paymentTransactionFullV2.sql");