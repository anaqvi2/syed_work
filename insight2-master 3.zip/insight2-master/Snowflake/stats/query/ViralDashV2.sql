SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ViralDashV2.sql");

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; 

-- Setup queries for coefficient and cycle times

INSERT IGNORE INTO rpt_workspace.cDunn_basicSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Basic'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 3
AND DAYOFMONTH(CURRENT_DATE) = 1;

INSERT IGNORE INTO rpt_workspace.cDunn_advancedSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Advanced'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 4
AND DAYOFMONTH(CURRENT_DATE) = 1;

INSERT IGNORE INTO rpt_workspace.cDunn_enterpriseSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Enterprise_Legacy'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 6
AND DAYOFMONTH(CURRENT_DATE) = 1;

INSERT IGNORE INTO rpt_workspace.cDunn_enterpriseNewSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Enterprise'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 11
AND DAYOFMONTH(CURRENT_DATE) = 1;

INSERT IGNORE INTO rpt_workspace.cDunn_teamSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Team'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 7
AND DAYOFMONTH(CURRENT_DATE) = 1;


INSERT IGNORE INTO rpt_workspace.cDunn_businessSharingProportion (startMonth, endMonth, userID, productName)
SELECT m.startMonth, m.endMonth, hpp.ownerID, 'Business'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON m.startMonth >= hpp.modifyDateTime AND m.startMonth < hpp.hist_effectiveThruDateTime
WHERE m.monthFriendly = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') AND hpp.productID = 10
AND DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY 1,3
;

DELETE FROM rpt_workspace.cDunn_trialSharingProportion 
WHERE DATE_FORMAT(startMonth, '%Y-%m')= DATE_FORMAT(CURRENT_DATE, '%Y-%m')
AND DAYOFWEEK(NOW()) IN(2,5);

INSERT IGNORE INTO rpt_workspace.cDunn_trialSharingProportion (startMonth, endMonth, userID, productName)
SELECT DATE_FORMAT(t.trialDateTime, '%Y-%m-01 00:00:00'), CONCAT(LAST_DAY(DATE_FORMAT(t.trialDateTime,'%Y-%m-%d')),' 23:59:59'),
t.userID, 'Trial'
FROM rpt_main_02.rpt_trials t
WHERE t.trialType = 1 AND DATE_FORMAT(trialDateTime, '%Y-%m')= DATE_FORMAT(CURRENT_DATE, '%Y-%m') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1,3
;

SELECT MIN(sessionLogID) FROM rpt_main_02.rpt_sessionLog WHERE insertDateTime >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') INTO @minSessionID;
SELECT MAX(sessionLogID) FROM rpt_main_02.rpt_sessionLog 
WHERE insertDateTime >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') 
AND insertDateTime < CONCAT(LAST_DAY(DATE_FORMAT(CURRENT_DATE,'%Y-%m-%d')),' 23:59:59') INTO @maxSessionID;

DELETE FROM rpt_workspace.cDunn_collabSharingProportion WHERE startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

INSERT IGNORE INTO rpt_workspace.cDunn_collabSharingProportion (userID, sessions, startMonth)
SELECT sl.userID, COUNT(DISTINCT(sl.sessionLogID)), DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
FROM rpt_main_02.rpt_sessionLog sl
LEFT JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = sl.userID AND hpp.accountType != 3 
	AND sl.insertDateTime BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime
WHERE sl.sessionLogID >= @minSessionID AND sl.sessionLogID < @maxSessionID
AND (hpp.productID IN(0,2) OR hpp.ownerID IS NULL)
AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

DELETE FROM rpt_workspace.cDunn_sharingMonths WHERE startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

INSERT IGNORE INTO rpt_workspace.cDunn_sharingMonths
SELECT g.insertByUserID, DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00'), COUNT(*)
FROM rpt_main_02.gridAccessMap g
WHERE g.insertDateTime >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND g.insertDateTime <= CONCAT(LAST_DAY(DATE_FORMAT(CURRENT_DATE,'%Y-%m-%d')),' 23:59:59')
AND g.access < 50 AND g.insertByUserID != g.userID AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;


SELECT MIN(sessionLogID) FROM rpt_main_02.rpt_sessionLog WHERE insertDateTime >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') INTO @minSessionID;
SELECT MAX(sessionLogID) FROM rpt_main_02.rpt_sessionLog 
WHERE insertDateTime >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') 
AND insertDateTime < CONCAT(LAST_DAY(DATE_FORMAT(CURRENT_DATE,'%Y-%m-%d')),' 23:59:59') INTO @maxSessionID;
DELETE FROM rpt_workspace.cDunn_monthlySessions WHERE startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

INSERT INTO rpt_workspace.cDunn_monthlySessions
SELECT DATE_FORMAT(insertDateTime, '%Y-%m-01 00:00:00') AS startMonth, userID, COUNT(DISTINCT(sessionLogID)) AS 'Sessions'
FROM rpt_main_02.rpt_sessionLog sl
WHERE sl.sessionLogID >= @minSessionID AND sl.sessionLogID < @maxSessionID AND
userID >= 1000000
AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1,2;

UPDATE rpt_workspace.cDunn_basicSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_advancedSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_teamSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_enterpriseSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_businessSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_trialSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_enterpriseNewSharingProportion A
JOIN rpt_workspace.cDunn_sharingMonths B ON A.userID = B.insertByUserID AND A.startMonth = B.startMonth
SET A.inMonthShare = 1 
WHERE B.insertByUserID IS NOT NULL AND A.startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_basicSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_advancedSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_teamSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_enterpriseSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_enterpriseNewSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_businessSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_trialSharingProportion A
LEFT JOIN rpt_workspace.cDunn_monthlySessions B ON A.startMonth = B.startMonth AND A.userID = B.userID
SET newUserLoggedIn = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);


DELETE FROM rpt_workspace.cDunn_sharingNumbers WHERE startMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5);

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn)
FROM rpt_workspace.cDunn_advancedSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn)
FROM rpt_workspace.cDunn_basicSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn) 
FROM rpt_workspace.cDunn_teamSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn) 
FROM rpt_workspace.cDunn_businessSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;


INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn)
FROM rpt_workspace.cDunn_enterpriseSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn)
FROM rpt_workspace.cDunn_enterpriseNewSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, productName, COUNT(*), SUM(inMonthShare), SUM(newUserLoggedIn)
FROM rpt_workspace.cDunn_trialSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

INSERT INTO rpt_workspace.cDunn_sharingNumbers
SELECT startMonth, 'Collaborator', COUNT(*), SUM(inMonthShare), COUNT(*)
FROM rpt_workspace.cDunn_collabSharingProportion
WHERE startMonth >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01 00:00:00') AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

-- Insert and updating of viral dash table

SELECT MAX(insertDateTime) FROM rpt_workspace.cDunn_collabReport INTO @maxCollab;

INSERT IGNORE INTO rpt_workspace.cDunn_collabReport (userID, firstSharedTo, insertDateTime, insertByUserID, domain)

SELECT u.userID, MIN(g.insertDateTime), u.insertDateTime, u.insertByUserID, u.domain
FROM rpt_main_02.userAccount u
JOIN rpt_main_02.gridAccessMap g FORCE INDEX (gridAccessMap_idx1) ON u.userID = g.userID AND g.access < 50
WHERE u.insertDateTime >= DATE_SUB(@maxCollab, INTERVAL 5 MINUTE) AND g.insertDateTime >= DATE_SUB(@maxCollab, INTERVAL 5 MINUTE)
AND g.insertDateTime >= u.insertDateTime AND g.insertDateTime <= DATE_ADD(u.insertDateTime, INTERVAL 5 SECOND) AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ss ON ss.userID = A.insertByUserID
SET insertByUserBucket = ss.bucket,
insertByUserSource = ss.sourceFriendly,
insertByUserSubSource = ss.subSourceFriendly,
insertByUserCampaign = ss.campaign
WHERE A.insertByUserBucket IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_trials t ON t.userID = A.insertByUserID
SET insertByUserBucket = 'Viral' WHERE t.userID IS NOT NULL AND A.insertByUserBucket IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserSource = 'Sharing' WHERE insertByUserBucket = 'Viral' AND insertByUserSource IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserSubSource = 'Sharing' WHERE insertByUserSource = 'Sharing' AND insertByUserSubSource IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserWorm = CONCAT(insertByUserSource,"/",insertByUserSubSource,"/",insertByUserCampaign) 
WHERE A.insertByUserCampaign IS NOT NULL AND A.insertByUserWorm IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserWorm = CONCAT(insertByUserSource,"/",insertByUserSubSource,"/","Null") 
WHERE A.insertByUserCampaign IS NULL AND A.insertByUserWorm IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.userID
SET loggedIn = CASE WHEN lct.loginCount >= 1 THEN 1 ELSE 0 END WHERE DAYOFWEEK(NOW()) IN(2,5);


UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserPlan = (SELECT rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID)
				FROM rpt_main_02.hist_paymentProfile hpp
				WHERE hpp.ownerID = A.insertByUserID
				AND A.firstSharedTo BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime GROUP BY A.insertByUserID, A.firstSharedTo)
				WHERE insertByUserPlan IS NULL AND DAYOFWEEK(NOW()) IN(2,5);
				
UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.userID
SET A.loginCount = lct.loginCount WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.userID
SET A.daysSinceLastLogin = lct.daysSinceLastLogin
WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET trialDate = (SELECT MIN(t.trialDateTime)
	FROM rpt_main_02.rpt_trials t
	WHERE t.userID = A.userID AND t.trialDateTime > A.firstSharedTo AND t.firstTrial = 1) WHERE A.trialDate IS NULL AND DAYOFWEEK(NOW()) IN(2,5);


UPDATE rpt_workspace.cDunn_collabReport A
SET converted = (SELECT CASE WHEN fwp.winDate IS NOT NULL THEN 1 ELSE 0 END
	FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE DAYOFWEEK(NOW()) IN(2,5);
	
UPDATE rpt_workspace.cDunn_collabReport A
SET convertedToLicense = NULL WHERE converted = 1 AND DAYOFWEEK(NOW()) IN(2,5);
	
UPDATE rpt_workspace.cDunn_collabReport A
SET convertedToLicense = (SELECT CASE WHEN hpp.ownerID IS NOT NULL THEN 1 ELSE 0 END
		FROM rpt_main_02.hist_paymentProfile hpp
		WHERE hpp.ownerID = A.userID AND hpp.accountType != 3 AND hpp.productID IN(6,7,10,11) AND hpp.modifyDateTime > A.firstSharedTo GROUP BY A.userID)
		WHERE A.converted IS NULL AND DAYOFWEEK(NOW()) IN(2,5);
		
/* ALTER TABLE rpt_workspace.cDunn_collabReport
ADD firstLogin DATETIME AFTER loginCount; */

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.userID
SET A.firstLogin = lct.firstLogin WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET timeToFirstLogin = TIMESTAMPDIFF(HOUR,firstSharedTo,firstLogin) WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET insertByUserPlan = 'Collaborator' WHERE (insertByUserPlan IN('Free','Cancelled') OR insertByUserPlan IS NULL) AND DAYOFWEEK(NOW()) IN(2,5);

/* ALTER TABLE rpt_workspace.cDunn_collabReport 
ADD Trial TINYINT; */

UPDATE rpt_workspace.cDunn_collabReport 
SET Trial = CASE WHEN trialDate IS NOT NULL THEN 1 ELSE 0 END WHERE DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add insertByUserFirstSession datetime,
add viralCycleTime int,
add isSuccessful tinyint,
add sharesBeforeFirstLogin int
; */

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.insertByUserID
SET A.insertByUserFirstSession = lct.firstLogin WHERE DAYOFWEEK(NOW()) IN(2,5);


UPDATE rpt_workspace.cDunn_collabReport A
SET isSuccessful = CASE WHEN timeToFirstLogin <= 168 THEN 1 ELSE 0 END WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET sharesBeforeFirstLogin = (SELECT COUNT(gridID) FROM rpt_main_02.gridAccessMap g
	WHERE g.userID = A.userID AND g.access < 50 AND g.insertDateTime < A.firstLogin) 
WHERE A.firstLogin IS NOT NULL AND sharesBeforeFirstLogin IS NULL AND DAYOFWEEK(NOW()) IN(2,5);
	
/* alter table rpt_workspace.cDunn_collabReport
add domain varchar(100); */

/* ALTER TABLE rpt_workspace.cDunn_collabReport
ADD ipCountry VARCHAR(100),
ADD isISPDomain VARCHAR(25); */

SET @@sql_mode = '';

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = A.userID
SET A.ipCountry = ip.ipCountry WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
SET A.isISPDomain = CASE WHEN isp.domain IS NOT NULL THEN 'ISP Domain' ELSE 'Org Domain' END WHERE isISPDomain IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add language varchar(100); */

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_main_02.userAccount u ON u.userID = A.userID
SET A.language = u.languageFriendly WHERE DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add inDomain tinyint; */

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_main_02.userAccount u ON u.userID = A.insertByUserID
SET inDomain = CASE WHEN u.domain = A.domain THEN 1 ELSE 0 END WHERE DAYOFWEEK(NOW()) IN(2,5);

/* ALTER TABLE rpt_workspace.cDunn_collabReport
ADD winDate DATETIME,
ADD licenseDate DATETIME; */

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_main_02.arc_sourceUser_firstWinProduct fwp ON fwp.sourceUserID = A.userID
SET A.winDate = fwp.winDate WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET licenseDate = (SELECT CASE WHEN hpp.ownerID IS NOT NULL THEN MIN(modifyDateTime) ELSE NULL END
		FROM rpt_main_02.hist_paymentProfile hpp
		WHERE hpp.ownerID = A.userID AND hpp.accountType != 3 AND hpp.productID IN(6,7,10,11) AND hpp.modifyDateTime > A.firstSharedTo GROUP BY A.userID)
		WHERE A.converted IS NULL AND DAYOFWEEK(NOW()) IN(2,5);
		

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = A.userID AND hpp.modifyDateTime = A.licenseDate AND hpp.productID IN(6,7,10,11) AND hpp.accountType = 2
SET A.licensedProduct = rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID)
WHERE A.licenseDate IS NOT NULL AND DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add winProduct varchar(25); */

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_main_02.arc_sourceUser_firstWinProduct fwp ON fwp.sourceUserID = A.userID
SET A.winProduct = rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID)
WHERE A.winDate IS NOT NULL AND DAYOFWEEK(NOW()) IN(2,5);

/* ALTER TABLE rpt_workspace.cDunn_collabReport
ADD top20Acct TINYINT; */

DROP TABLE IF EXISTS rpt_workspace.cDunn_topTwenty;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_topTwenty
(domain VARCHAR(100),
ARR DECIMAL(10,2),
PRIMARY KEY (domain));

INSERT INTO rpt_workspace.cDunn_topTwenty
SELECT A.domain, SUM(ACV)
FROM rpt_main_02.rpt_paidPlanInfo A
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
WHERE isp.domain IS NULL
GROUP BY 1
ORDER BY 2 DESC
LIMIT 20;

UPDATE rpt_workspace.cDunn_collabReport A
LEFT JOIN rpt_workspace.cDunn_topTwenty B ON A.domain = B.domain
SET A.top20Acct = CASE WHEN B.domain IS NOT NULL THEN 1 ELSE 0 END WHERE DAYOFWEEK(NOW()) IN(2,5); 


/* ALTER TABLE rpt_workspace.cDunn_collabReport
ADD first90DayBuy TINYINT DEFAULT 0,
ADD firstDay90License TINYINT DEFAULT 0; */

UPDATE rpt_workspace.cDunn_collabReport A
SET viralCycleTime = TIMESTAMPDIFF(DAY,insertByUserFirstSession,firstLogin) WHERE DATEDIFF(firstSharedTo,insertByUserFirstSession) <= 180 AND DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add totalCycleTime int,
add trialCycleTime int; */

UPDATE rpt_workspace.cDunn_collabReport A
SET totalCycleTime = TIMESTAMPDIFF(DAY,insertByUserFirstSession,winDate) WHERE DATEDIFF(firstSharedTo,insertByUserFirstSession) <= 180 AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET totalCycleTime = TIMESTAMPDIFF(DAY,insertByUserFirstSession,licenseDate) 
WHERE totalCycletime IS NULL AND DATEDIFF(firstSharedTo,insertByUserFirstSession) <= 180 AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
SET trialCycleTime = TIMESTAMPDIFF(DAY,insertByUserFirstSession,trialDate) 
WHERE DATEDIFF(firstSharedTo,insertByUserFirstSession) <= 180 AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport
SET first90DayBuy = CASE WHEN converted = 1 AND DATEDIFF(winDate, firstSharedTo) <= 90 THEN 1 ELSE 0 END WHERE converted = 1 AND DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport
SET firstDay90License = CASE WHEN convertedToLicense = 1 AND DATEDIFF(licenseDate, firstSharedTo) <= 90 THEN 1 ELSE 0 END WHERE convertedToLicense = 1 AND DAYOFWEEK(NOW()) IN(2,5);

/*ALTER TABLE rpt_workspace.cDunn_collabReport
ADD ispDomain TINYINT;*/

UPDATE rpt_workspace.cDunn_collabReport A
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
SET A.ispDomain = CASE WHEN isp.domain IS NOT NULL THEN 1 ELSE 0 END
WHERE A.ispDomain IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

/*
ALTER TABLE rpt_workspace.cDunn_collabReport
ADD insertedByPhishingUsers int;
*/



INSERT IGNORE INTO rpt_workspace.js_emailsSent(userID, uniqueRecipients)
SELECT A.insertByUserID, COUNT(DISTINCT toUserID) 
FROM rpt_main_02.arc_mailDistribution A
JOIN rpt_main_02.userAccount B
ON A.insertByUserID=B.userID
WHERE A.sessionLogID!=0 AND B.insertDateTime >= '2016-01-01' AND A.insertByUserID!=A.toUserID AND DAYOFWEEK(NOW()) IN(2,5)
GROUP BY 1;

UPDATE rpt_workspace.js_emailsSent A
JOIN rpt_main_02.userAccount B
ON A.userID=B.userID
SET A.emailAddress=B.emailAddress, A.firstName=B.firstName, A.lastName=B.lastName, A.insertDate=B.insertDateTime, A.insertByUserID=B.insertByUserID
WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.js_emailsSent A
SET insertByUserEmailAddress=
(SELECT emailAddress FROM rpt_main_02.userAccount B
WHERE A.insertByUserID=B.userID) WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.js_emailsSent A
SET productName=
(SELECT productName FROM rpt_main_02.rpt_paymentProfile B
WHERE A.userID=B.mainContactUserID AND B.accountType!=3 LIMIT 1) WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.js_emailsSent A
SET signupIPAddress=
(SELECT ipAddress FROM rpt_main_02.rpt_signupSource B
WHERE A.userID=B.userID) WHERE DAYOFWEEK(NOW()) IN(2,5);

DELETE FROM rpt_workspace.js_emailsSent
WHERE uniqueRecipients < 200;

DELETE FROM rpt_workspace.js_emailsSent
WHERE productName IN ('Basic','Advanced','Team','Enterprise', 'Enterprise_Legacy','Business');

INSERT IGNORE INTO rpt_workspace.js_insertedByPhishingUsers(userID)
SELECT A.userID 
FROM rpt_main_02.userAccount A
JOIN rpt_workspace.js_emailsSent B
ON A.insertByUserID=B.userID
WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.js_insertedByPhishingUsers A
SET loggedIn=
(SELECT userLoggedInAtLeastOnce 
FROM rpt_main_02.rpt_loginCountTotal B
WHERE A.userID=B.userID) WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
JOIN rpt_workspace.js_insertedByPhishingUsers B
ON A.userID=B.userID
SET A.insertedByPhishingUsers=1
WHERE B.loggedIn=0 AND A.insertDateTime >= '2016-11-01' AND DAYOFWEEK(NOW()) IN(2,5);

/* alter table rpt_workspace.cDunn_collabReport
add monetized tinyint,
add totalPopulation int,
add sharingPopulation int,
add loggedInPopulation int;

alter table rpt_workspace.cDunn_collabReport
add startMonth Datetime; */

UPDATE rpt_workspace.cDunn_collabReport
SET startMonth = DATE_FORMAT(firstSharedTo, '%Y-%m-01 00:00:00') WHERE startMonth IS NULL AND DAYOFWEEK(NOW()) IN(2,5);

/* create index startMonth on rpt_workspace.cDunn_collabReport (startMonth); 
CREATE INDEX insertByUserPlan ON rpt_workspace.cDunn_collabReport (insertByUserPlan); */

UPDATE rpt_workspace.cDunn_collabReport
SET monetized = CASE WHEN winDate IS NOT NULL THEN 1
			WHEN licenseDate IS NOT NULL THEN 1 
				ELSE 0 END 
			WHERE DAYOFWEEK(NOW()) IN(2,5);
	
UPDATE rpt_workspace.cDunn_collabReport A
STRAIGHT_JOIN rpt_workspace.cDunn_sharingNumbers B ON A.startMonth = B.startMonth AND A.insertByUserPlan = B.productName
SET A.totalPopulation = B.users 
WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
STRAIGHT_JOIN rpt_workspace.cDunn_sharingNumbers B ON A.startMonth = B.startMonth AND A.insertByUserPlan = B.productName
SET A.sharingPopulation = B.inMonthShares
WHERE DAYOFWEEK(NOW()) IN(2,5);

UPDATE rpt_workspace.cDunn_collabReport A
STRAIGHT_JOIN rpt_workspace.cDunn_sharingNumbers B ON A.startMonth = B.startMonth AND A.insertByUserPlan = B.productName
SET A.loggedInPopulation = B.inMonthLoggedIn
WHERE DAYOFWEEK(NOW()) IN(2,5);

SELECT * FROM rpt_workspace.cDunn_collabReport;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ViralDashV2.sql");

