SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-forecastingResults6V2.sql");

delete from rpt_workspace.js_dailyActualsBreakdown
where recordDate >= '2017-02-01';

insert into rpt_workspace.js_dailyActualsBreakdown
select recordDate, concat(ARRSource,'-',recordType,'-',assistedType) as ARRSource, recordType, assistedType, ARR as ARRActual, paymentProfileID, domain, ISP, salesRep, salesRepRole, accountName, accountID, opportunityID from rpt_workspace.js_actualsStaging
where recordDate >= '2017-02-01' and recordType in ('NEW','EXPANSION') and assistedType in ('Unassisted','Commercial Assisted');

select * from rpt_workspace.js_dailyActualsBreakdown;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-forecastingResults6V2.sql");

