SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("salesCohortsPerformanceV2.sql");

drop table if exists rpt_workspace.js_cohortPerformanceStaging2;
create table if not exists rpt_workspace.js_cohortPerformanceStaging2
(repName varchar(50),
title varchar(50),
startClass varchar(50),
startClassSize int,
startDate date,
closeDate date,
dateDiff int,
commissionableARR dec(10,2),
opportunityName varchar(100),
index (repName),
index (startClass),
index (startDate),
index (closeDate));

insert into rpt_workspace.js_cohortPerformanceStaging2(repName, title, startClass, startDate, closeDate, dateDiff, commissionableARR, opportunityName)
select A.repName, A.title, A.startClass, A.startDate, B.closeDate, datediff(B.closeDate, A.startDate), B.Commissionable_ACV__c, B.Name from rpt_workspace.js_cohortPerformanceStaging A
join ss_sfdc_02.opportunity B
on A.repID=B.ownerID and A.startDate <= B.closeDate and B.closeDate < current_date and B.Commissionable_ACV__c > 0
where B.stageName='Closed Won';

update rpt_workspace.js_cohortPerformanceStaging2 A
set startClassSize=
(select count(*) from rpt_workspace.js_cohortPerformanceStaging B
where A.startClass=B.startClass and A.title=B.title);

update rpt_workspace.js_cohortPerformanceStaging2 set opportunityName = REPLACE(opportunityName, '\n', '');
update rpt_workspace.js_cohortPerformanceStaging2 set opportunityName = REPLACE(opportunityName, '\r', '');
update rpt_workspace.js_cohortPerformanceStaging2 set opportunityName = REPLACE(opportunityName, '\r\n', '');

select * from rpt_workspace.js_cohortPerformanceStaging2;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("salesCohortsPerformanceV2.sql");

