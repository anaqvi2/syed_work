--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.INET_ATON (IP_ADDRESS VARCHAR)
  RETURNS DOUBLE
  LANGUAGE JAVASCRIPT
AS '
ip_parts = IP_ADDRESS.split(''.'');
return parseInt(ip_parts[0])*(16777216) + parseInt(ip_parts[1])*(65536) + parseInt(ip_parts[2])*(256) + parseInt(ip_parts[3]);
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_ACCOUNTTYPE(5)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_ACCOUNTTYPE (ACCOUNTTYPE DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var accountTypeName;
switch (ACCOUNTTYPE) {
  case 1:
    accountTypeName = ''Standard'';
    break;
  case 2:
    accountTypeName = ''Multi-user'';
    break;
  case 3:
    accountTypeName = ''Organization'';
    break;
  default:
    accountTypeName = ''Account Type ''.concat(ACCOUNTTYPE);
}
return accountTypeName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_ACCOUNTTYPE(5)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_AUTHRESULT (AUTHTYPE DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var AuthResultName;
switch (AUTHTYPE) {
  case 1:
    AuthResultName = ''SUCCESS'';
    break;
  case 0:
    AuthResultName = ''No error'';
    break;
  case -1:
    AuthResultName = ''INVALID_USER_OR_PASSWORD'';
    break;
  case -2:
    AuthResultName = ''LOGIN_TICKET_DOES_NOT_EXIST'';
    break;
  case -3:
    AuthResultName = ''DUPLICATE_LOGIN_TICKETS'';
    break;
  case -4:
    AuthResultName = ''LOGIN_TICKET_CORRUPT'';
    break;
  case -5:
    AuthResultName = ''LOGIN_TICKET_NOT_VALID'';
    break;
  case -6:
    AuthResultName = ''ACCOUNT_LOCKEDOUT'';
    break;
  case -7:
    AuthResultName = ''REUSED_REQUEST_DIGEST'';
    break;
  case -8:
    AuthResultName = ''INVALID_REQUEST_DIGEST'';
    break;
  case -9:
    AuthResultName = ''NO_MATCHING_USER'';
    break;
  case -10:
    AuthResultName = ''INVALID_EMAIL_FORMAT'';
    break;
  case -11:
    AuthResultName = ''USER_NOT_CONFIRMED'';
    break;
  case -12:
    AuthResultName = ''ACCOUNT_BLOCKED'';
    break;
  case -13:
    AuthResultName = ''INVALID_UPDATE_TICKET'';
    break;
  case -14:
    AuthResultName = ''ACCOUNT_LOCKEDOUT_MAX'';
    break;
  case -15:
    AuthResultName = ''BLOCKED_IP_ADDRESS'';
    break;
  case -16:
    AuthResultName = ''SAML_REQUIRED_FOR_AUTH'';
    break;
  case -17:
    AuthResultName = ''ACCESS_TOKEN_REQUIRED'';
    break;
  case -18:
    AuthResultName = ''ACCESS_TOKEN_EXPIRED'';
    break;
  case -19:
    AuthResultName = ''Rest User Credentials'';
    break;
  case -20:
    AuthResultName = ''INVALID_ASSUME_USER'';
    break;
  case -21:
    AuthResultName = ''ASSUME_USER_REQUIRED'';
    break;
  case -22:
    AuthResultName = ''LEGACY_PASSWORD_FORMAT'';
    break;
  default:
    AuthResultName = ''AuthResult ''.concat(AUTHTYPE);
}
return AuthResultName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_AUTHRESULT(-22)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_BROWSERBUCKET (USERAGENT VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var browserBucket;
switch (true) {
  case /BlackBerry/.test(USERAGENT):
    browserBucket = ''BlackBerry'';
    break;
  case /Firefox/.test(USERAGENT):
    browserBucket = ''Firefox'';
    break;
  case /MSIE/.test(USERAGENT):
    browserBucket = ''IE'';
    break;
  case /Trident/.test(USERAGENT):
    browserBucket = ''IE'';
    break;
  case /Chrome/.test(USERAGENT):
    browserBucket = ''Chrome'';
    break;
  case /Safari/.test(USERAGENT):
    browserBucket = ''Safari'';
    break;
  case /Opera/.test(USERAGENT):
    browserBucket = ''Opera'';
    break;
  case /Camino/.test(USERAGENT):
    browserBucket = ''Camino'';
    break;
  case /Mac OS.*Smartsheet/.test(USERAGENT):
    browserBucket = ''Native iOS App'';
    break;
  case /Android.*Smartsheet/.test(USERAGENT):
    browserBucket = ''Native Android App'';
    break;
  default:
    browserBucket = ''Other Browser''

}
return browserBucket;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_BROWSERBUCKET('I AM A Opera 11 DEVICE')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_BROWSERDEVICE (USERAGENT VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var browserDevice;
switch (true) {
  case USERAGENT.includes(''myTouch''):
    browserDevice = ''myTouch'';
    break;
  case USERAGENT.includes(''Nexus''):
    browserDevice = ''Nexus'';
    break;
  case USERAGENT.includes(''LG''):
    browserDevice = ''LG'';
    break;
  case USERAGENT.includes(''SGH''):
    browserDevice = ''SAMSUNG-SGH'';
    break;
  case USERAGENT.includes(''APA9292KT''):
    browserDevice = ''HTC-EVO (APA9292KT)'';
    break;
  case USERAGENT.includes(''ADR6300''):
    browserDevice = ''HTC-Incredible (ADR6300)'';
    break;
  case USERAGENT.includes(''HTC''):
    browserDevice = ''HTC'';
    break;
  case USERAGENT.includes(''Treo''):
    browserDevice = ''Treo'';
    break;
  case USERAGENT.includes(''Droid2''):
    browserDevice = ''Droid2'';
    break;
  case USERAGENT.includes(''DroidX''):
    browserDevice = ''DroidX'';
    break;
  case USERAGENT.includes('' Droid''):
    browserDevice = ''Droid'';
    break;
  case USERAGENT.includes(''Xoom''):
    browserDevice = ''Xoom'';
    break;
  case USERAGENT.includes(''BlackBerry''):
    browserDevice = ''BlackBerry'';
    break;
  case USERAGENT.includes(''Nokia''):
    browserDevice = ''Nokia'';
    break;
  case USERAGENT.includes(''PlayBook''):
    browserDevice = ''Playbook'';
    break;
  case USERAGENT.includes(''iPod''):
    browserDevice = ''iPod'';
    break;			
  case USERAGENT.includes(''iPhone''):
    browserDevice = ''iPhone'';
    break;
  case USERAGENT.includes(''iPad''):
    browserDevice = ''iPad'';
    break;
  case USERAGENT.includes(''Mobile''):
    browserDevice = ''Mobile Device'';
    break;
  case USERAGENT.includes(''Mini''):
    browserDevice = ''Mobile Device'';
    break;
  case USERAGENT.includes(''Fennec''):
    browserDevice = ''Mobile Device'';
    break;
  case USERAGENT.includes(''Android''):
    browserDevice = ''Mobile Device'';
    break;
  case USERAGENT.includes(''pixi''):
    browserDevice = ''pixi'';
    break;
  default:
    browserDevice = ''Computer''
}
return browserDevice;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_BROWSERDEVICE('My BlackBerry device')
--;

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_BROWSERNAME (USERAGENT VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var browserName;
switch (true) {
  case /Mac OS X.*Smartsheet 1\.0\.1/.test(USERAGENT):
    browserName = ''iOS App 1.0.1'';
    break;
  case /Mac OS X.*Smartsheet 1\.0/.test(USERAGENT):
    browserName = ''iOS App 1\.0'';
    break;
  case /Mac OS X.*Smartsheet 1\.1/.test(USERAGENT):
    browserName = ''iOS App 1\.1'';
    break;
  case /Mac OS X.*Smartsheet 1\.2/.test(USERAGENT):
    browserName = ''iOS App 1\.2'';
    break;
  case /Mac OS X.*Smartsheet 1\.3/.test(USERAGENT):
    browserName = ''iOS App 1\.3'';
    break;
  case /Mac OS X.*Smartsheet 1\.4/.test(USERAGENT):
    browserName = ''iOS App 1\.4'';
    break;
  case /Mac OS X.*Smartsheet/.test(USERAGENT):
    browserName = ''iOS App v.'';
    break;
  case /Android.*Smartsheet 1\.0/.test(USERAGENT):
    browserName = ''Android App 1\.0'';
    break;
  case /Android.*Smartsheet 1\.1/.test(USERAGENT):
    browserName = ''Android App 1\.1'';
    break;
  case /Android.*Smartsheet 1\.2/.test(USERAGENT):
    browserName = ''Android App 1\.2'';
    break;
  case /Android.*Smartsheet/.test(USERAGENT):
    browserName = ''Android App v.'';
    break;
  case /BlackBerry/.test(USERAGENT):
    browserName = ''BlackBerry'';
    break;
  case /Firefox\\/10/.test(USERAGENT):
    browserName = ''Firefox 10'';
    break;
  case /Firefox\\/11/.test(USERAGENT):
    browserName = ''Firefox 11'';
    break;
  case /Firefox\\/12/.test(USERAGENT):
    browserName = ''Firefox 12'';
    break;
  case /Firefox\\/13/.test(USERAGENT):
    browserName = ''Firefox 13'';
    break;
  case /Firefox\\/14/.test(USERAGENT):
    browserName = ''Firefox 14'';
    break;
  case /Firefox\\/15/.test(USERAGENT):
    browserName = ''Firefox 15'';
    break;
  case /Firefox\\/16/.test(USERAGENT):
    browserName = ''Firefox 16'';
    break;
  case /Firefox\\/17/.test(USERAGENT):
    browserName = ''Firefox 17'';
    break;
  case /Firefox\\/18/.test(USERAGENT):
    browserName = ''Firefox 18'';
    break;
  case /Firefox\\/19/.test(USERAGENT):
    browserName = ''Firefox 19'';
    break;
  case /Firefox\\/20/.test(USERAGENT):
    browserName = ''Firefox 20'';
    break;
  case /Firefox\\/21/.test(USERAGENT):
    browserName = ''Firefox 21'';
    break;
  case /Firefox\\/22/.test(USERAGENT):
    browserName = ''Firefox 22'';
    break;
  case /Firefox\\/23/.test(USERAGENT):
    browserName = ''Firefox 23'';
    break;
  case /Firefox\\/24/.test(USERAGENT):
    browserName = ''Firefox 24'';
    break;
  case /Firefox\\/25/.test(USERAGENT):
    browserName = ''Firefox 25'';
    break;
  case /Firefox\\/26/.test(USERAGENT):
    browserName = ''Firefox 26'';
    break;
  case /Firefox\\/27/.test(USERAGENT):
    browserName = ''Firefox 27'';
    break;
  case /Firefox\\/28/.test(USERAGENT):
    browserName = ''Firefox 28'';
    break;
  case /Firefox\\/29/.test(USERAGENT):
    browserName = ''Firefox 29'';
    break;
  case /Firefox\\/30/.test(USERAGENT):
    browserName = ''Firefox 30'';
    break;
  case /Firefox\\/31/.test(USERAGENT):
    browserName = ''Firefox 31'';
    break;
  case /Firefox\\/32/.test(USERAGENT):
    browserName = ''Firefox 32'';
    break;
  case /Firefox\\/1/.test(USERAGENT):
    browserName = ''Firefox 1'';
    break;
  case /Firefox\\/2/.test(USERAGENT):
    browserName = ''Firefox 2'';
    break;
  case /Firefox\\/3/.test(USERAGENT):
    browserName = ''Firefox 3'';
    break;
  case /Firefox\\/4/.test(USERAGENT):
    browserName = ''Firefox 4'';
    break;
  case /Firefox\\/5/.test(USERAGENT):
    browserName = ''Firefox 5'';
    break;
  case /Firefox\\/6/.test(USERAGENT):
    browserName = ''Firefox 6'';
    break;
  case /Firefox\\/7/.test(USERAGENT):
    browserName = ''Firefox 7'';
    break;
  case /Firefox\\/8/.test(USERAGENT):
    browserName = ''Firefox 8'';
    break;
  case /Firefox\\/9/.test(USERAGENT):
    browserName = ''Firefox 9'';
    break;
  case /Firefox/.test(USERAGENT):
    browserName = ''Firefox v.'';
    break;
  case /MSIE 4\./.test(USERAGENT):
    browserName = ''IE 4'';
    break;
  case /MSIE 5\./.test(USERAGENT):
    browserName = ''IE 5'';
    break;
  case /MSIE 6\./.test(USERAGENT):
    browserName = ''IE 6'';
    break;
  case /MSIE 7\./.test(USERAGENT):
    browserName = ''IE 7'';
    break;
  case /MSIE 8\./.test(USERAGENT):
    browserName = ''IE 8'';
    break;
  case /MSIE 9\./.test(USERAGENT):
    browserName = ''IE 9'';
    break;
  case /MSIE 10\./.test(USERAGENT):
    browserName = ''IE 10'';
    break;
  case /Trident.*rv:11/.test(USERAGENT):
    browserName = ''IE 11'';
    break;
  case /Trident.*rv:12/.test(USERAGENT):
    browserName = ''IE 12'';
    break;
  case /Trident.*rv:13/.test(USERAGENT):
    browserName = ''IE 13'';
    break;
  case /Trident.*rv:14/.test(USERAGENT):
    browserName = ''IE 14'';
    break;
  case /Trident.*rv:15/.test(USERAGENT):
    browserName = ''IE 15'';
    break;
  case /Chrome\\/10/.test(USERAGENT):
    browserName = ''Chrome 10'';
    break;
  case /Chrome\\/11/.test(USERAGENT):
    browserName = ''Chrome 11'';
    break;
  case /Chrome\\/12/.test(USERAGENT):
    browserName = ''Chrome 12'';
    break;
  case /Chrome\\/13/.test(USERAGENT):
    browserName = ''Chrome 13'';
    break;
  case /Chrome\\/14/.test(USERAGENT):
    browserName = ''Chrome 14'';
    break;
  case /Chrome\\/15/.test(USERAGENT):
    browserName = ''Chrome 15'';
    break;
  case /Chrome\\/16/.test(USERAGENT):
    browserName = ''Chrome 16'';
    break;
  case /Chrome\\/17/.test(USERAGENT):
    browserName = ''Chrome 17'';
    break;
  case /Chrome\\/18/.test(USERAGENT):
    browserName = ''Chrome 18'';
    break;
  case /Chrome\\/19/.test(USERAGENT):
    browserName = ''Chrome 19'';
    break;
  case /Chrome\\/20/.test(USERAGENT):
    browserName = ''Chrome 20'';
    break;
  case /Chrome\\/21/.test(USERAGENT):
    browserName = ''Chrome 21'';
    break;
  case /Chrome\\/22/.test(USERAGENT):
    browserName = ''Chrome 22'';
    break;
  case /Chrome\\/23/.test(USERAGENT):
    browserName = ''Chrome 23'';
    break;
  case /Chrome\\/24/.test(USERAGENT):
    browserName = ''Chrome 24'';
    break;
  case /Chrome\\/25/.test(USERAGENT):
    browserName = ''Chrome 25'';
    break;
  case /Chrome\\/26/.test(USERAGENT):
    browserName = ''Chrome 26'';
    break;
  case /Chrome\\/27/.test(USERAGENT):
    browserName = ''Chrome 27'';
    break;
  case /Chrome\\/28/.test(USERAGENT):
    browserName = ''Chrome 28'';
    break;
  case /Chrome\\/29/.test(USERAGENT):
    browserName = ''Chrome 29'';
    break;
  case /Chrome\\/30/.test(USERAGENT):
    browserName = ''Chrome 30'';
    break;
  case /Chrome\\/31/.test(USERAGENT):
    browserName = ''Chrome 31'';
    break;
  case /Chrome\\/32/.test(USERAGENT):
    browserName = ''Chrome 32'';
    break;
  case /Chrome\\/33/.test(USERAGENT):
    browserName = ''Chrome 33'';
    break;
  case /Chrome\\/34/.test(USERAGENT):
    browserName = ''Chrome 34'';
    break;
  case /Chrome\\/35/.test(USERAGENT):
    browserName = ''Chrome 35'';
    break;
  case /Chrome\\/36/.test(USERAGENT):
    browserName = ''Chrome 36'';
    break;
  case /Chrome\\/37/.test(USERAGENT):
    browserName = ''Chrome 37'';
    break;
  case /Chrome\\/38/.test(USERAGENT):
    browserName = ''Chrome 38'';
    break;
  case /Chrome\\/39/.test(USERAGENT):
    browserName = ''Chrome 39'';
    break;
  case /Chrome\\/1/.test(USERAGENT):
    browserName = ''Chrome 1'';
    break;  
  case /Chrome\\/2/.test(USERAGENT):
    browserName = ''Chrome 2'';
    break;
  case /Chrome\\/3/.test(USERAGENT):
    browserName = ''Chrome 3'';
    break;
  case /Chrome\\/4/.test(USERAGENT):
    browserName = ''Chrome 4'';
    break;
  case /Chrome\\/5/.test(USERAGENT):
    browserName = ''Chrome 5'';
    break;
  case /Chrome\\/6/.test(USERAGENT):
    browserName = ''Chrome 6'';
    break;
  case /Chrome\\/7/.test(USERAGENT):
    browserName = ''Chrome 7'';
    break;
  case /Chrome\\/8/.test(USERAGENT):
    browserName = ''Chrome 8'';
    break;
  case /Chrome\\/9/.test(USERAGENT):
    browserName = ''Chrome 9'';
    break;
  case /Chrome/.test(USERAGENT):
    browserName = ''Chrome v.'';
    break;
  case /3\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 3'';
    break; 
  case /3\._\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 3'';
    break; 
  case /4\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 4'';
    break; 
  case /4\._\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 4'';
    break; 
  case /5\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 5'';
    break; 
  case /5\._\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 5'';
    break; 
  case /6\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 6'';
    break; 
  case /6\.___ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 6'';
    break; 
  case /7\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 7'';
    break; 
  case /7\.___ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 7'';
    break; 	
  case /7\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 8'';
    break; 
  case /7\.___ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 8'';
    break; 	
  case /7\._ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 9'';
    break; 
  case /7\.___ Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari 9'';
    break; 	
  case /Mobile.*Safari/.test(USERAGENT):
    browserName = ''Mobile Safari v.'';
    break; 
  case /3\._ Safari/.test(USERAGENT):
    browserName = ''Safari 3'';
    break; 
  case /3\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 3'';
    break; 
  case /4\._ Safari/.test(USERAGENT):
    browserName = ''Safari 4'';
    break; 
  case /4\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 4'';
    break; 
  case /5\._ Safari/.test(USERAGENT):
    browserName = ''Safari 5'';
    break; 
  case /5\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 5'';
    break; 
  case /6\._ Safari/.test(USERAGENT):
    browserName = ''Safari 6'';
    break; 
  case /6\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 6'';
    break; 
  case /6\._\._\.____ Safari/.test(USERAGENT):
    browserName = ''Safari 6'';
    break; 	
  case /7\._ Safari/.test(USERAGENT):
    browserName = ''Safari 7'';
    break; 
  case /7\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 7'';
    break; 
  case /7\._\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 7'';
    break; 
  case /8\._ Safari/.test(USERAGENT):
    browserName = ''Safari 8'';
    break; 
  case /8\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 8'';
    break; 
  case /8\._\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 8'';
    break; 
  case /9\._ Safari/.test(USERAGENT):
    browserName = ''Safari 9'';
    break; 
  case /9\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 9'';
    break; 
  case /9\._\._\._ Safari/.test(USERAGENT):
    browserName = ''Safari 9'';
    break; 
  case /Safari\\/7534\.48\.3/.test(USERAGENT):
    browserName = ''Safari 5'';
    break;
  case /Safari\\/8536\.25/.test(USERAGENT):
    browserName = ''Safari 6'';
    break;
  case /Safari/.test(USERAGENT):
    browserName = ''Safari v.'';
    break; 
  case /Opera\\/8/.test(USERAGENT):
    browserName = ''Opera 8'';
    break;
  case /Opera 8/.test(USERAGENT):
    browserName = ''Opera 8'';
    break;
  case /Opera\\/9/.test(USERAGENT):
    browserName = ''Opera 9'';
    break;
  case /Opera 9/.test(USERAGENT):
    browserName = ''Opera 9'';
    break;
  case /Opera\\/10/.test(USERAGENT):
    browserName = ''Opera 10'';
    break;
  case /Opera 10/.test(USERAGENT):
    browserName = ''Opera 10'';
    break;
  case /Opera\\/11/.test(USERAGENT):
    browserName = ''Opera 11'';
    break;
  case /Opera 11/.test(USERAGENT):
    browserName = ''Opera 11'';
    break;
  case /Opera\\/12/.test(USERAGENT):
    browserName = ''Opera 12'';
    break;
  case /Opera 12/.test(USERAGENT):
    browserName = ''Opera 12'';
    break;
  case /Opera/.test(USERAGENT):
    browserName = ''Opera v.'';
    break;
  case /Camino/.test(USERAGENT):
    browserName = ''Camino'';
    break;
  case /Mobile/.test(USERAGENT):
    browserName = ''Other Mobile Browser'';
    break;
  default:
    browserName = ''Other Browser''
}
return browserName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_BROWSERNAME('I AM A Opera 11 DEVICE')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_BROWSEROS (USERAGENT VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var browserOS;
switch (true) {
  case USERAGENT.includes(''sunOS''):
    browserOS = ''sunOS'';
    break;
  case USERAGENT.includes(''FreeBSD''):
    browserOS = ''FreeBSD'';
    break;
  case USERAGENT.includes(''openBSD''):
    browserOS = ''openBSD'';
    break;
  case USERAGENT.includes(''SymbianOS''):
    browserOS = ''SymbianOS'';
    break;
  case USERAGENT.includes(''Symbian''):
    browserOS = ''SymbianOS'';
    break;
  case USERAGENT.includes(''webOS''):
    browserOS = ''webOS'';
    break;
  case USERAGENT.includes(''BlackBerry''):
    browserOS = ''BlackBerry'';
    break;
  case USERAGENT.includes(''Android''):
    browserOS = ''Android'';
    break;
  case USERAGENT.includes(''Linux''):
    browserOS = ''Linux'';
    break;
  case USERAGENT.includes(''Windows CE''):
    browserOS = ''Windows CE'';
    break;
  case USERAGENT.includes(''Windows Phone OS''):
    browserOS = ''Windows Phone OS'';
    break;
  case USERAGENT.includes(''Windows''):
    browserOS = ''Windows'';
    break;
  case USERAGENT.includes(''OS 3''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''OS 4''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''OS 5''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''OS 6''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''OS 7''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''OS 8''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''iPhone OS''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''iPad''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''iPhone''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''iOS''):
    browserOS = ''iOS'';
    break;
  case USERAGENT.includes(''Mac''):
    browserOS = ''Mac'';
    break;
  case USERAGENT.includes(''crOS ''):
    browserOS = ''Chrome OS'';
    break;
  default: 
    browserOS = ''Other OS'';
}
return browserOS;
'
;

--######################################################################################

--SELECT MAIN.PUBLIC.SMARTSHEET_BROWSEROS('My BlackBerry device')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_COUNTRYNAME (COUNTRYCODE VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var countryName;
switch (COUNTRYCODE) {
  case ''AF'':
    countryName = ''Afghanistan'';
    break;
  case ''Afghanistan'':
    countryName = ''Afghanistan'';
    break;
  case ''AX'':
    countryName = ''Aland Islands'';
    break;
  case ''AL'':
    countryName = ''Albania'';
    break;
  case ''DZ'':
    countryName = ''Algeria'';
    break;
  case ''AS'':
    countryName = ''American Samoa'';
    break;
  case ''AD'':
    countryName = ''Andorra'';
    break;
  case ''AO'':
    countryName = ''Angola'';
    break;
  case ''AI'':
    countryName = ''Anguilla'';
    break;
  case ''AQ'':
    countryName = ''Antarctica'';
    break;
  case ''AG'':
    countryName = ''Antigua and Barbuda'';
    break;
  case ''AR'':
    countryName = ''Argentina'';
    break;
  case ''AM'':
    countryName = ''Armenia'';
    break;
  case ''AW'':
    countryName = ''Aruba'';
    break;
  case ''AU'':
    countryName = ''Australia'';
    break;
  case ''AUST'':
    countryName = ''Australia'';
    break;
  case ''AUSTRALIA'':
    countryName = ''Australia'';
    break;
  case ''AT'':
    countryName = ''Austria'';
    break;
  case ''Osterreich'':
    countryName = ''Austria'';
    break;
  case ''AZ'':
    countryName = ''Azerbaidjan'';
    break;
  case ''BS'':
    countryName = ''Bahamas'';
    break;
  case ''BH'':
    countryName = ''Bahrain'';
    break;
  case ''BD'':
    countryName = ''Bangladesh'';
    break;
  case ''BB'':
    countryName = ''Barbados'';
    break;
  case ''BY'':
    countryName = ''Belarus'';
    break;
  case ''BE'':
    countryName = ''Belgium'';
    break;
  case ''Belgium'':
    countryName = ''Belgium'';
    break;
  case ''BZ'':
    countryName = ''Belize'';
    break;
  case ''BJ'':
    countryName = ''Benin'';
    break;
  case ''BM'':
    countryName = ''Bermuda'';
    break;
  case ''BT'':
    countryName = ''Bhutan'';
    break;
  case ''BO'':
    countryName = ''Bolivia'';
    break;
  case ''BQ'':
    countryName = ''Bonaire'';
    break;
  case ''BA'':
    countryName = ''Bosnia-Herzegovina'';
    break;
  case ''BW'':
    countryName = ''Botswana'';
    break;
  case ''Botswana'':
    countryName = ''Botswana'';
    break;
  case ''BV'':
    countryName = ''Bouvet Island'';
    break;
  case ''BR'':
    countryName = ''Brazil'';
    break;
  case ''Brasil'':
    countryName = ''Brazil'';
    break;
  case ''Brazil'':
    countryName = ''Brazil'';
    break;
  case ''IO'':
    countryName = ''British Indian Ocean Territory'';
    break;
  case ''BN'':
    countryName = ''Brunei Darussalam'';
    break;
  case ''BG'':
    countryName = ''Bulgaria'';
    break;
  case ''Bulgaria'':
    countryName = ''Bulgaria'';
    break;
  case ''BF'':
    countryName = ''Burkina Faso'';
    break;
  case ''BI'':
    countryName = ''Burundi'';
    break;
  case ''KH'':
    countryName = ''Cambodia'';
    break;
  case ''CM'':
    countryName = ''Cameroon'';
    break;
  case ''CA'':
    countryName = ''Canada'';
    break;
  case ''Canada'':
    countryName = ''Canada'';
    break;
  case ''Newfoundland'':
    countryName = ''Canada'';
    break;
  case ''CV'':
    countryName = ''Cape Verde'';
    break;
  case ''KY'':
    countryName = ''Cayman Islands'';
    break;
  case ''Cayman Islands'':
    countryName = ''Cayman Islands'';
    break;
  case ''CF'':
    countryName = ''Central African Republic'';
    break;
  case ''TD'':
    countryName = ''Chad'';
    break;
  case ''CL'':
    countryName = ''Chile'';
    break;
  case ''Chile'':
    countryName = ''Chile'';
    break;
  case ''CN'':
    countryName = ''China'';
    break;
  case ''China'':
    countryName = ''China'';
    break;
  case ''CX'':
    countryName = ''Christmas Island'';
    break;
  case ''CC'':
    countryName = ''Cocos Islands'';
    break;
  case ''CO'':
    countryName = ''Colombia'';
    break;
  case ''Colombia'':
    countryName = ''Colombia'';
    break;
  case ''KM'':
    countryName = ''Comoros'';
    break;
  case ''CD'':
    countryName = ''Congo'';
    break;
  case ''CG'':
    countryName = ''Congo'';
    break;
  case ''CK'':
    countryName = ''Cook Islands'';
    break;
  case ''CR'':
    countryName = ''Costa Rica'';
    break;
  case ''Costa Rica'':
    countryName = ''Costa Rica'';
    break;
  case ''CI'':
    countryName = ''Cote D\\''Ivoire'';
    break;
  case ''HR'':
    countryName = ''Croatia'';
    break;
  case ''CU'':
    countryName = ''Cuba'';
    break;
  case ''CW'':
    countryName = ''Curacao'';
    break;
  case ''CY'':
    countryName = ''Cyprus'';
    break;
  case ''CZ'':
    countryName = ''Czech Republic'';
    break;
  case ''Czech Republic'':
    countryName = ''Czech Republic'';
    break;
  case ''DK'':
    countryName = ''Denmark'';
    break;
  case ''Denmark'':
    countryName = ''Denmark'';
    break;
  case ''DJ'':
    countryName = ''Djibouti'';
    break;
  case ''DM'':
    countryName = ''Dominica'';
    break;
  case ''DO'':
    countryName = ''Dominican Republic'';
    break;
  case ''Republica Dominicana'':
    countryName = ''Dominican Republic'';
    break;
  case ''EC'':
    countryName = ''Ecuador'';
    break;
  case ''Ecuador'':
    countryName = ''Ecuador'';
    break;
  case ''EG'':
    countryName = ''Egypt'';
    break;
  case ''SV'':
    countryName = ''El Salvador'';
    break;
  case ''GQ'':
    countryName = ''Equatorial Guinea'';
    break;
  case ''ER'':
    countryName = ''Eritrea'';
    break;
  case ''EE'':
    countryName = ''Estonia'';
    break;
  case ''Estonia'':
    countryName = ''Estonia'';
    break;
  case ''ET'':
    countryName = ''Ethiopia'';
    break;
  case ''FK'':
    countryName = ''Falkland Islands'';
    break;
  case ''FO'':
    countryName = ''Faroe Islands'';
    break;
  case ''FJ'':
    countryName = ''Fiji'';
    break;
  case ''Fiji'':
    countryName = ''Fiji'';
    break;
  case ''FI'':
    countryName = ''Finland'';
    break;
  case ''FR'':
    countryName = ''France'';
    break;
  case ''FRANCE'':
    countryName = ''France'';
    break;
  case ''GF'':
    countryName = ''French Guyana'';
    break;
  case ''PF'':
    countryName = ''French Polynesia'';
    break;
  case ''TF'':
    countryName = ''French Southern Territories'';
    break;
  case ''GA'':
    countryName = ''Gabon'';
    break;
  case ''GM'':
    countryName = ''Gambia'';
    break;
  case ''GE'':
    countryName = ''Georgia'';
    break;
  case ''DE'':
    countryName = ''Germany'';
    break;
  case ''Deutschland'':
    countryName = ''Germany'';
    break;
  case ''Germany'':
    countryName = ''Germany'';
    break;
  case ''GH'':
    countryName = ''Ghana'';
    break;
  case ''GI'':
    countryName = ''Gibraltar'';
    break;
  case ''GR'':
    countryName = ''Greece'';
    break;
  case ''GREECE'':
    countryName = ''Greece'';
    break;
  case ''GL'':
    countryName = ''Greenland'';
    break;
  case ''GD'':
    countryName = ''Grenada'';
    break;
  case ''GP'':
    countryName = ''Guadeloupe'';
    break;
  case ''GU'':
    countryName = ''Guam'';
    break;
  case ''GT'':
    countryName = ''Guatemala'';
    break;
  case ''GUATEMALA'':
    countryName = ''Guatemala'';
    break;
  case ''GG'':
    countryName = ''Guernsey'';
    break;
  case ''GN'':
    countryName = ''Guinea'';
    break;
  case ''GW'':
    countryName = ''Guinea-Bissau'';
    break;
  case ''GY'':
    countryName = ''Guyana'';
    break;
  case ''HT'':
    countryName = ''Haiti'';
    break;
  case ''HM'':
    countryName = ''Heard and McDonald Islands'';
    break;
  case ''HN'':
    countryName = ''Honduras'';
    break;
  case ''HK'':
    countryName = ''Hong Kong'';
    break;
  case ''HU'':
    countryName = ''Hungary'';
    break;
  case ''Hungary'':
    countryName = ''Hungary'';
    break;
  case ''IS'':
    countryName = ''Iceland'';
    break;
  case ''IN'':
    countryName = ''India'';
    break;
  case ''India'':
    countryName = ''India'';
    break;
  case ''ID'':
    countryName = ''Indonesia'';
    break;
  case ''INDONESIA'':
    countryName = ''Indonesia'';
    break;
  case ''IR'':
    countryName = ''Iran'';
    break;
  case ''IQ'':
    countryName = ''Iraq'';
    break;
  case ''IE'':
    countryName = ''Ireland'';
    break;
  case ''Ireland'':
    countryName = ''Ireland'';
    break;
  case ''IM'':
    countryName = ''Isle of Man'';
    break;
  case ''IL'':
    countryName = ''Israel'';
    break;
  case ''Israel'':
    countryName = ''Israel'';
    break;
  case ''IT'':
    countryName = ''Italy'';
    break;
  case ''Italia'':
    countryName = ''Italy'';
    break;
  case ''ITALY'':
    countryName = ''Italy'';
    break;
  case ''JM'':
    countryName = ''Jamaica'';
    break;
  case ''JP'':
    countryName = ''Japan'';
    break;
  case ''Japan'':
    countryName = ''Japan'';
    break;
  case ''JE'':
    countryName = ''Jersey'';
    break;
  case ''JO'':
    countryName = ''Jordan'';
    break;
  case ''KZ'':
    countryName = ''Kazakhstan'';
    break;
  case ''KE'':
    countryName = ''Kenya'';
    break;
  case ''KI'':
    countryName = ''Kiribati'';
    break;
  case ''KP'':
    countryName = ''Korea'';
    break;
  case ''KW'':
    countryName = ''Kuwait'';
    break;
  case ''KG'':
    countryName = ''Kyrgyzstan'';
    break;
  case ''LA'':
    countryName = ''Laos'';
    break;
  case ''LV'':
    countryName = ''Latvia'';
    break;
  case ''Latvia'':
    countryName = ''Latvia'';
    break;
  case ''LB'':
    countryName = ''Lebanon'';
    break;
  case ''Lebanon'':
    countryName = ''Lebanon'';
    break;
  case ''LS'':
    countryName = ''Lesotho'';
    break;
  case ''LR'':
    countryName = ''Liberia'';
    break;
  case ''LY'':
    countryName = ''Libya'';
    break;
  case ''Libya'':
    countryName = ''Libyan Arab Jamahiriya'';
    break;
  case ''LI'':
    countryName = ''Liechtenstein'';
    break;
  case ''LT'':
    countryName = ''Lithuania'';
    break;
  case ''Lithuania'':
    countryName = ''Lithuania'';
    break;
  case ''LU'':
    countryName = ''Luxembourg'';
    break;
  case ''MO'':
    countryName = ''Macau'';
    break;
  case ''MK'':
    countryName = ''Macedonia'';
    break;
  case ''MG'':
    countryName = ''Madagascar'';
    break;
  case ''MW'':
    countryName = ''Malawi'';
    break;
  case ''MY'':
    countryName = ''Malaysia'';
    break;
  case ''Malaysia'':
    countryName = ''Malaysia'';
    break;
  case ''MV'':
    countryName = ''Maldives'';
    break;
  case ''ML'':
    countryName = ''Mali'';
    break;
  case ''MT'':
    countryName = ''Malta'';
    break;
  case ''MH'':
    countryName = ''Marshall Islands'';
    break;
  case ''MQ'':
    countryName = ''Martinique'';
    break;
  case ''MR'':
    countryName = ''Mauritania'';
    break;
  case ''MU'':
    countryName = ''Mauritius'';
    break;
  case ''YT'':
    countryName = ''Mayotte'';
    break;
  case ''MX'':
    countryName = ''Mexico'';
    break;
  case ''77710'':
    countryName = ''Mexico'';
    break;
  case ''Mexico'':
    countryName = ''Mexico'';
    break;
  case ''Mexico D.F (Mexico)'':
    countryName = ''Mexico'';
    break;
  case ''FM'':
    countryName = ''Micronesia'';
    break;
  case ''MD'':
    countryName = ''Moldavia'';
    break;
  case ''MC'':
    countryName = ''Monaco'';
    break;
  case ''MN'':
    countryName = ''Mongolia'';
    break;
  case ''ME'':
    countryName = ''Montenegro'';
    break;
  case ''MS'':
    countryName = ''Montserrat'';
    break;
  case ''MA'':
    countryName = ''Morocco'';
    break;
  case ''Morocco'':
    countryName = ''Morocco'';
    break;
  case ''MZ'':
    countryName = ''Mozambique'';
    break;
  case ''MM'':
    countryName = ''Myanmar'';
    break;
  case ''NA'':
    countryName = ''Namibia'';
    break;
  case ''NR'':
    countryName = ''Nauru'';
    break;
  case ''NP'':
    countryName = ''Nepal'';
    break;
  case ''NL'':
    countryName = ''Netherlands'';
    break;
  case ''Netherlands'':
    countryName = ''Netherlands'';
    break;
  case ''The Netherlands'':
    countryName = ''Netherlands'';
    break;
  case ''NC'':
    countryName = ''New Caledonia'';
    break;
  case ''NZ'':
    countryName = ''New Zealand'';
    break;
  case ''New Zealand'':
    countryName = ''New Zealand'';
    break;
  case ''NI'':
    countryName = ''Nicaragua'';
    break;
  case ''NE'':
    countryName = ''Niger'';
    break;
  case ''NG'':
    countryName = ''Nigeria'';
    break;
  case ''NU'':
    countryName = ''Niue'';
    break;
  case ''NF'':
    countryName = ''Norfolk Island'';
    break;
  case ''MP'':
    countryName = ''Northern Mariana Islands'';
    break;
  case ''NO'':
    countryName = ''Norway'';
    break;
  case ''Norway'':
    countryName = ''Norway'';
    break;
  case ''OM'':
    countryName = ''Oman'';
    break;
  case ''ZZ'':
    countryName = ''Other'';
    break;
  case ''PK'':
    countryName = ''Pakistan'';
    break;
  case ''PW'':
    countryName = ''Palau'';
    break;
  case ''PS'':
    countryName = ''Palestine'';
    break;
  case ''PA'':
    countryName = ''Panama'';
    break;
  case ''Panama'':
    countryName = ''Panama'';
    break;
  case ''PG'':
    countryName = ''Papua New Guinea'';
    break;
  case ''PY'':
    countryName = ''Paraguay'';
    break;
  case ''Paraguay'':
    countryName = ''Paraguay'';
    break;
  case ''PE'':
    countryName = ''Peru'';
    break;
  case ''Peru'':
    countryName = ''Peru'';
    break;
  case ''PH'':
    countryName = ''Philippines'';
    break;
  case ''PN'':
    countryName = ''Pitcairn Islands'';
    break;
  case ''PL'':
    countryName = ''Poland'';
    break;
  case ''Capgemini'':
    countryName = ''Poland'';
    break;
  case ''Krakow'':
    countryName = ''Poland'';
    break;
  case ''Poland'':
    countryName = ''Poland'';
    break;
  case ''Polska'':
    countryName = ''Poland'';
    break;
  case ''PT'':
    countryName = ''Portugal'';
    break;
  case ''Portugal'':
    countryName = ''Portugal'';
    break;
  case ''PR'':
    countryName = ''Puerto Rico'';
    break;
  case ''QA'':
    countryName = ''Qatar'';
    break;
  case ''RE'':
    countryName = ''Reunion'';
    break;
  case ''RO'':
    countryName = ''Romania'';
    break;
  case ''Romania'':
    countryName = ''Romania'';
    break;
  case ''RU'':
    countryName = ''Russia'';
    break;
  case ''Russia'':
    countryName = ''Russia'';
    break;
  case ''Russian Federation'':
    countryName = ''Russia'';
    break;
  case ''RW'':
    countryName = ''Rwanda'';
    break;
  case ''BL'':
    countryName = ''Saint Barthelemy'';
    break;
  case ''SH'':
    countryName = ''Saint Helena'';
    break;
  case ''KN'':
    countryName = ''Saint Kitts and Nevis Anguilla'';
    break;
  case ''LC'':
    countryName = ''Saint Lucia'';
    break;
  case ''MF'':
    countryName = ''Saint Martin'';
    break;
  case ''SX'':
    countryName = ''Saint Martin'';
    break;
  case ''VC'':
    countryName = ''Saint Vincent and Grenadines'';
    break;
  case ''WS'':
    countryName = ''Samoa'';
    break;
  case ''SM'':
    countryName = ''San Marino'';
    break;
  case ''ST'':
    countryName = ''Sao Tome and Principe'';
    break;
  case ''SA'':
    countryName = ''Saudi Arabia'';
    break;
  case ''SN'':
    countryName = ''Senegal'';
    break;
  case ''RS'':
    countryName = ''Serbia'';
    break;
  case ''SC'':
    countryName = ''Seychelles'';
    break;
  case ''SL'':
    countryName = ''Sierra Leone'';
    break;
  case ''SG'':
    countryName = ''Singapore'';
    break;
  case ''SK'':
    countryName = ''Slovakia'';
    break;
  case ''Slovakia'':
    countryName = ''Slovakia'';
    break;
  case ''SI'':
    countryName = ''Slovenia'';
    break;
  case ''Slovenia'':
    countryName = ''Slovenia'';
    break;
  case ''SB'':
    countryName = ''Solomon Islands'';
    break;
  case ''SO'':
    countryName = ''Somalia'';
    break;
  case ''ZA'':
    countryName = ''South Africa'';
    break;
  case ''RSA'':
    countryName = ''South Africa'';
    break;
  case ''South Africa'':
    countryName = ''South Africa'';
    break;
  case ''GS'':
    countryName = ''South Georgia and the South Sandwich Islands'';
    break;
  case ''KR'':
    countryName = ''South Korea'';
    break;
  case ''SS'':
    countryName = ''South Sudan'';
    break;
  case ''ES'':
    countryName = ''Spain'';
    break;
  case ''Espana'':
    countryName = ''Spain'';
    break;
  case ''Spain'':
    countryName = ''Spain'';
    break;
  case ''LK'':
    countryName = ''Sri Lanka'';
    break;
  case ''PM'':
    countryName = ''St. Pierre and Miquelon'';
    break;
  case ''SD'':
    countryName = ''Sudan'';
    break;
  case ''SR'':
    countryName = ''Suriname'';
    break;
  case ''SJ'':
    countryName = ''Svalbard and Jan Mayen Islands'';
    break;
  case ''SZ'':
    countryName = ''Swaziland'';
    break;
  case ''SE'':
    countryName = ''Sweden'';
    break;
  case ''Sweden'':
    countryName = ''Sweden'';
    break;
  case ''CH'':
    countryName = ''Switzerland'';
    break;
  case ''Switzerland'':
    countryName = ''Switzerland'';
    break;
  case ''SY'':
    countryName = ''Syrian Arab Republic'';
    break;
  case ''TW'':
    countryName = ''Taiwan'';
    break;
  case ''Taiwan'':
    countryName = ''Taiwan'';
    break;
  case ''TJ'':
    countryName = ''Tajikistan'';
    break;
  case ''TZ'':
    countryName = ''Tanzania'';
    break;
  case ''Tanzania'':
    countryName = ''Tanzania'';
    break;
  case ''TH'':
    countryName = ''Thailand'';
    break;
  case ''Thailand'':
    countryName = ''Thailand'';
    break;
  case ''TL'':
    countryName = ''Timor-Leste'';
    break;
  case ''TG'':
    countryName = ''Togo'';
    break;
  case ''TK'':
    countryName = ''Tokelau'';
    break;
  case ''TO'':
    countryName = ''Tonga'';
    break;
  case ''TT'':
    countryName = ''Trinidad and Tobago'';
    break;
  case ''TN'':
    countryName = ''Tunisia'';
    break;
  case ''TR'':
    countryName = ''Turkey'';
    break;
  case ''Turkey'':
    countryName = ''Turkey'';
    break;
  case ''TM'':
    countryName = ''Turkmenistan'';
    break;
  case ''TC'':
    countryName = ''Turks and Caicos Islands'';
    break;
  case ''TV'':
    countryName = ''Tuvalu'';
    break;
  case ''UG'':
    countryName = ''Uganda'';
    break;
  case ''UA'':
    countryName = ''Ukraine'';
    break;
  case ''AE'':
    countryName = ''United Arab Emirates'';
    break;
  case ''UAE'':
    countryName = ''United Arab Emirates'';
    break;
  case ''GB'':
    countryName = ''United Kingdom'';
    break;
  case ''England'':
    countryName = ''United Kingdom'';
    break;
  case ''United Kingdom'':
    countryName = ''United Kingdom'';
    break;
  case ''UK'':
    countryName = ''United Kingdom'';
    break;
  case ''US'':
    countryName = ''United States'';
    break;
  case ''United States'':
    countryName = ''United States'';
    break;
  case ''United States of America'':
    countryName = ''United States'';
    break;
  case ''USA'':
    countryName = ''United States'';
    break;
  case ''UM'':
    countryName = ''United States Minor Outlying Islands'';
    break;
  case ''UY'':
    countryName = ''Uruguay'';
    break;
  case ''Uruguay'':
    countryName = ''Uruguay'';
    break;
  case ''UZ'':
    countryName = ''Uzbekistan'';
    break;
  case ''VU'':
    countryName = ''Vanuatu'';
    break;
  case ''VA'':
    countryName = ''Vatican City'';
    break;
  case ''VE'':
    countryName = ''Venezuela'';
    break;
  case ''VN'':
    countryName = ''Vietnam'';
    break;
  case ''VG'':
    countryName = ''Virgin Islands'';
    break;
  case ''VI'':
    countryName = ''Virgin Islands'';
    break;
  case ''WF'':
    countryName = ''Wallis and Futuna'';
    break;
  case ''EH'':
    countryName = ''Western Sahara'';
    break;
  case ''YE'':
    countryName = ''Yemen'';
    break;
  case ''ZM'':
    countryName = ''Zambia'';
    break;
  case ''ZW'':
    countryName = ''Zimbabwe'';
    break;
  default:
    countryName = ''Country ''.concat(COUNTRYCODE);
}
return countryName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_COUNTRYNAME ('CI')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_GET_BUCKET (SOURCE VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var get_bucket;
switch (SOURCE) {
  case ''Sharing'':
  case ''Referrals'':
  case ''Application'':
    get_bucket = ''Viral'';
    break;
  case ''Affiliate'':
  case ''Campaign'':
  case ''Email Campaigns'':
  case ''General Awareness'':
  case ''Free Directory'':
  case ''SEO'':
  case ''Social'':
  case ''Website Links'':
  case ''Blog Posse'':
    get_bucket = ''Other'';
    break;
  case ''Partner'':
  case ''App Store'':
    get_bucket = ''Partner'';
    break;
  case ''Paid Placement'':
  case ''PPC - Foreign Language'':
  case ''PPC - English - International'':
  case ''PPC'':
  case ''Paid - Social'':
  case ''Paid - Email'':
    get_bucket = ''Paid'';
    break;
  default:
    get_bucket = ''--unknown bucket--''
}
return get_bucket;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_GET_BUCKET('Paid - Email')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER (URL VARCHAR, PARAMETERNAME VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var parameterValue;
var PARAMETERNAMELength;
var startPosition;
var endPosition;

startPosition = URL.indexOf(''?''.concat(PARAMETERNAME, ''=''));
if (startPosition == -1) {
  startPosition = URL.indexOf(''&''.concat(PARAMETERNAME, ''=''));
}
if (startPosition > -1) {
  
  PARAMETERNAMELength = PARAMETERNAME.length + 2;

  endPosition = URL.indexOf(''&'', startPosition + 1);

  if (endPosition > -1) {
    parameterValue = URL.substr(startPosition + PARAMETERNAMELength, endPosition - (startPosition + PARAMETERNAMELength));
  }
  else {
    parameterValue = URL.substr(startPosition + PARAMETERNAMELength);
  }

}
  
return parameterValue;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER('https://smartsheet.snowflakecomputing.com/console#/sql/worksheet?myparm1=foo&myparm2=987', 'myparm1')
--      ,MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER('https://smartsheet.snowflakecomputing.com/console#/sql/worksheet?myparm1=foo&myparm2=987', 'myparm2')
--      ,MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER('https://smartsheet.snowflakecomputing.com/console#/sql/worksheet?myparm1=foo&myparm2=987', 'myparm3')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_GET_SOURCE (SUBSOURCE VARCHAR)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var get_source;
switch(SUBSOURCE) {
  case ''Signup with Sharing Tracking Codes'':
  case ''Signup Inserted by Smartsheet User'':
    get_source = ''Sharing'';
    break;
  case ''Web Forms - Powered BY Smartsheet'':
  case ''Published Sheet - Powered by Smartsheet'':
    get_source = ''Application'';
    break;
  case ''Mail Link'':
  case ''My Smartsheet Referral'':
  case ''Referral Rewards'':
    get_source = ''Referrals'';
    break;
  case ''Amazon Web Services'':
  case ''AWS Marketplace'':
  case ''Brad Egeland'':
  case ''Crowdsourcing.org'':
  case ''Sitepoint'':
  case ''Sage Non-Profit'':
  case ''Office Arrow'':
  case ''VA Network'':
  case ''Veronica Conway'':
  case ''Jott'':
  case ''Success Connections'':
  case ''smallbiztrends.com'':
  case ''A Clayton\\''s Secretary'':
  case ''Officebundle.com'':
  case ''Caroline Melville Society of Virtual Assistants'':
  case ''Caroline Melville Virtually Sorted'':
  case ''Baird Consulting'':
  case ''Biz Recipes'':
  case ''OnlineBizU'':
  case ''Assistant Match'':
  case ''Ki-Work'':
  case ''Tradeshow Coach'':
  case ''Regina Minger'':
  case ''Kindle'':
  case ''Stack Overflow'':
    get_source = ''Affiliate'';
    break;
  case ''TJ McCue'':
  case ''NAPS'':
    get_source = ''Campaign'';
    break;
  case ''Email'':
    get_source = ''Email Campaigns'';
    break;
  case ''Smartsheet Search'':
  case ''Smartsheet Search (Not Provided)'':
  case ''Smartsheet Paid Google Search'':
  case ''Smartsheet Paid Bing Search'':
  case ''Direct Navigation'':
  case ''Distributed Container'':
    get_source = ''General Awareness'';
    break;
  case ''Google Templates'':
  case ''thesmallbusinessweb.com'':
    get_source = ''Free Directory'';
    break;
  case ''SEO'':
  case ''SEO (Not Provided)'':
    get_source = ''SEO'';
    break;
  case ''YouTube (unpaid)'':
  case ''Twitter (unpaid)'':
  case ''Social Media (generic)'':
  case ''Facebook (unpaid)'':
  case ''LinkedIn (unpaid)'':
  case ''Google+ (unpaid)'':
  case ''Social Media Coordinator - Keri'':
  case ''Slideshare.net'':
    get_source = ''Social'';
    break;
  case ''External Source Links'':
    get_source = ''Website Links'';
    break;
  case ''Apple App Store'':
  case ''Android App Store'':
  case ''Google Play Store'':
    get_source = ''App Store'';
    break;
  case ''Elizabeth Harrin (blog posse)'':
  case ''Robert Kelly (blog posse)'':
  case ''Lindsay Scott (blog posse)'':
    get_source = ''Blog Posse'';
    break;
  case ''Google App. Marketplace'':
  case ''Chrome Web Store'':
  case ''Intuit'':
  case ''Zimbra'':
  case ''Salesforce.com'':
  case ''Box'':
  case ''Cloud Alliance for Google Apps'':
  case ''Centrify'':
  case ''Google Drive - New File'':
  case ''Google Drive - Import'':
  case ''Zapier'':
  case ''Dropbox'':
  case ''123 Contact Form'':
  case ''Marketo Launchpoint'':
  case ''Docusign'':
  case ''MailChimp'':
  case ''Harvest'':
  case ''Evernote'':
  case ''Amazon Mechanical Turk'':
  case ''AppGuru'':
  case ''Backupify'':
  case ''Bitium'':
  case ''Easy Insight'':
  case ''OneLogin'':
  case ''PingOne'':
  case ''Klipfolio'':
  case ''Tools4ever'':
  case ''Okta'':
  case ''Third Party Authorization Flow'':
  case ''BetterCloud'':
  case ''Smartsheet Merge (Google Docs Add-on)'':
  case ''Smartsheet Forms (Google Forms Add-on)'':
  case ''Microsoft'':
  case ''Wave'':
    get_source = ''Partner'';
    break;
  case ''Serchen'':
  case ''The Deck'':
  case ''PM Sherpa'':
  case ''GetApp.com'':
  case ''Geekwire'':
  case ''USA Today'':
  case ''Pac NW Soccer'':
  case ''Spiceworks'':
    get_source = ''Paid Placement'';
    break;
  case ''Spanish - Google Search Test'':
  case ''Spanish - Google Display Network Test'':
  case ''Spanish (US) - Google Display'':
  case ''Spanish (US) - Google Search'':
  case ''Spanish (Mexico) - Google Display'':
  case ''Spanish (Mexico) - Google Search'':
  case ''Spanish (Spain) - Google Display'':
  case ''Spanish (Spain) - Google Search'':
  case ''Spanish (Other) - Google Display'':
  case ''Spanish (Other) - Google Search'':
  case ''Spanish (Argentina)  Google Display'':
  case ''Spanish (Argentina)  Google Search'':
  case ''Spanish (Peru)  Google Display'':
  case ''Spanish (Peru)  Google Search'':
  case ''Spanish (Venezuela)  Google Display'':
  case ''Spanish (Venezuela)  Google Search'':
  case ''Spanish (Chile)  Google Display'':
  case ''Spanish (Chile)  Google Search'':
  case ''Spanish (Guatemala)  Google Display'':
  case ''Spanish (Guatemala)  Google Search'':
  case ''Spanish (Ecuador)  Google Display'':
  case ''Spanish (Ecuador)  Google Search'':
  case ''French (Tier 1) - Google Display'':
  case ''French (Tier 1) - Google Search'':
  case ''French (Tier 2) - Google Display'':
  case ''French (Tier 2) - Google Search'':
  case ''Portuguese (Brazil) - Google Display'':
  case ''Portuguese (Brazil) - Google Search'':
  case ''Portuguese (Portugal) - Google Display'':
  case ''Portuguese (Portugal) - Google Search'':
  case ''German - Google Display'':
  case ''German - Google Search'':
  case ''Italian - Google Display'':
  case ''Italian - Google Search'':
  case ''Bing Search - French'':
  case ''Bing Search - German'':
  case ''Bing Search - Portuguese (Brazil)'':
  case ''Bing Search - Portuguese (Portugal)'':
  case ''Bing Search - Spanish'':
  case ''Bing Search - Italian'':
  case ''Google Search - Russian'':
  case ''Yandex (paid)'':
  case ''Google Search - Japanese'':
  case ''Yahoo Japan'':
    get_source = ''PPC - Foreign Language'';
    break;
  case ''Bing Search (Canada)'':
  case ''Bing Search (Singapore)'':
  case ''Bing Search (UK)'':
  case ''South Africa - Google Display'':
  case ''South Africa - Google Search'':
  case ''Israel - Google Display'':
  case ''Israel - Google Search'':
  case ''Saudi Arabia - Google Display'':
  case ''Saudi Arabia - Google Search'':
  case ''Belgium - Google Display'':
  case ''Belgium - Google Search'':
  case ''Finland - Google Display'':
  case ''Finland - Google Search'':
  case ''Denmark - Google Display'':
  case ''Denmark - Google Search'':
  case ''Netherlands - Google Display'':
  case ''Netherlands - Google Search'':
  case ''Norway - Google Display'':
  case ''Norway - Google Search'':
  case ''Sweden - Google Display'':
  case ''Sweden - Google Search'':
  case ''Germany - Google Display'':
  case ''Germany - Google Search'':
  case ''France - Google Display'':
  case ''France - Google Search'':
  case ''Spain - Google Display'':
  case ''Spain - Google Search'':
  case ''Italy - Google Display'':
  case ''Italy - Google Search'':
  case ''Turkey - Google Display'':
  case ''Turkey - Google Search'':
  case ''Russia - Google Display'':
  case ''Russia - Google Search'':
  case ''Hong Kong - Google Display'':
  case ''Hong Kong - Google Search'':
  case ''Singapore - Google Display'':
  case ''Singapore - Google Search'':
  case ''Japan - Google Display'':
  case ''Japan - Google Search'':
  case ''South Korea - Google Display'':
  case ''South Korea - Google Search'':
  case ''China - Google Display'':
  case ''China - Google Search'':
  case ''Mexico - Google Display'':
  case ''Mexico - Google Search'':
  case ''Brazil - Google Display'':
  case ''Brazil - Google Search'':
  case ''Columbia - Google Display'':
  case ''Columbia - Google Search'':
  case ''Argentina - Google Display'':
  case ''Argentina - Google Search'':
  case ''India - Google Display'':
  case ''India - Google Search'':
  case ''Indonesia - Google Display'':
  case ''Indonesia - Google Search'':
  case ''Malaysia - Google Display'':
  case ''Malaysia - Google Search'':
  case ''Philippines - Google Display'':
  case ''Philippines - Google Search'':
  case ''_Display - Managed Placements - Tier 1 International'':
  case ''_Display - Managed Placements - Tier 2 International'':
  case ''_Google Search - International - Tier 1'':
  case ''_Google Search - International - Tier 2'':
  case ''Google Display International - Text Ads'':
  case ''Google Display International - Image Ads'':
  case ''Bing Search - International - Tier 1'':
  case ''Google Search Companion Marketing (International)'':
    get_source = ''PPC - English - International'';
    break;
  case ''_Google Search'':
  case ''_Google Display Network'':
  case ''Yahoo'':
  case ''Ask.com'':
  case ''_Google Search'':
  case ''Go2Web20.net'':
  case ''_Bing Search'':
  case ''_Bing Content Network'':
  case ''Ad Ready Network'':
  case ''Facebook'':
  case ''LinkedIn'':
  case ''LinkedIn InMail'':
  case ''LinkedIn International (paid)'':
  case ''_Google Display (iPad only)'':
  case ''_Google Search (iPad only)'':
  case ''Google Remarketing (Paid Visitors)'':
  case ''Google Remarketing (Non-paid Visitors)'':
  case ''Google Remarketing (Nurture Signups)'':
  case ''Bing Search (French - Canada)'':
  case ''Bing Search (French - France)'':
  case ''Youtube (promoted videos)'':
  case ''_Display - Managed Placements'':
  case ''Google Adwords Sitelinks'':
  case ''Google Mobile Search (iphone)'':
  case ''Google Mobile Search (non-iphone)'':
  case ''Enterprise Display Test - Spreadsheet Hell - Desktop'':
  case ''Enterprise Display Test - Spreadsheet Hell - Mobile'':
  case ''BlueKai - (Google)'':
  case ''Similar Audiences - (Google)'':
  case ''Gmail Ads'':
  case ''Gmail Ads - International'':
  case ''Google Display - Interest Targeted'':
  case ''Video for Adwords'':
  case ''Google Business Category Display'':
  case ''Seattle GEO Target (Google Search)'':
  case ''Seattle GEO Target (Bing Search)'':
  case ''Seattle GEO Target (Google Display Image)'':
  case ''Seattle GEO Target (Bing Content)'':
  case ''Seattle GEO Target (Google Text Display)'':
  case ''Google Display - Image Ads'':
  case ''Google Display - Text Ads'':
  case ''Google Search Companion Marketing'':
  case ''Similar Audiences (Google) - International'':
  case ''Google Display - Interest Targeted (International)'':
  case ''Bing Display - Text Ads (USA)'':
  case ''Bing Display - Text Ads (English Not USA)'':
  case ''Bing Sitelinks'':
  case ''Display - Select Keyword'':
  case ''Display - Select Keyword (International)'':
    get_source = ''PPC'';
    break;
  case ''Twitter (paid)'':
    get_source = ''Paid - Social'';
    break;
  case ''DemandMetric.com'':
  case ''ProjectManagers.net'':
  case ''ProjectsAtWork.com'':
  case ''ProjectManagement.com'':
    get_source = ''Paid - Email'';
    break;
  default:
    get_source = ''--unknown source--'';
}
return get_source;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_GET_SOURCE ('ProjectManagement.com')
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_LOGINTYPENAME (LOGINTYPE DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var loginTypeName;
switch(LOGINTYPE) {
  case 1:
    loginTypeName = ''Drupal Login (deprecated)'';
    break;
  case 2:
    loginTypeName = ''Login Form'';
    break;
  case 3:
    loginTypeName = ''Request Digest (deprecated)'';
    break;
  case 4:
    loginTypeName = ''Login Ticket Drupal (deprecated)'';
    break;
  case 5:
    loginTypeName = ''OPS Monitor (deprecated)'';
    break;
  case 6:
    loginTypeName = ''OPS Console (deprecated)'';
    break;
  case 7:
    loginTypeName = ''Login Ticket Auto Signin'';
    break;
  case 8:
    loginTypeName = ''Login Ticket Remember Me'';
    break;
  case 9:
    loginTypeName = ''API'';
    break;
  case 10:
    loginTypeName = ''Login Ticket Password Reset'';
    break;
  case 11:
    loginTypeName = ''Update Request'';
    break;
  case 12:
    loginTypeName = ''Quick Add'';
    break;
  case 13:
    loginTypeName = ''Editable Publish'';
    break;
  case 14:
    loginTypeName = ''OpenID'';
    break;
  case 15:
    loginTypeName = ''Read-only Publish'';
    break;
  case 16:
    loginTypeName = ''Intuit Workplace (deprecated)'';
    break;
  case 17:
    loginTypeName = ''Ops Console OpenID (deprecated)'';
    break;
  case 18:
    loginTypeName = ''Gadget Session Exchange'';
    break;
  case 19:
    loginTypeName = ''SSO Salesforce'';
    break;
  case 20:
    loginTypeName = ''SSO SAML'';
    break;
  case 21:
    loginTypeName = ''Rest User Credentials'';
    break;
  case 22:
    loginTypeName = ''Rest Access Token'';
    break;
  case 23:
    loginTypeName = ''Login Ticket Remember Me Mobile'';
    break;
  case 24:
    loginTypeName = ''API'';
    break;
  case 25:
    loginTypeName = ''Rest Auth Code'';
    break;
  case 26:
    loginTypeName = ''Rest Refresh Token'';
    break;
  case 27:
    loginTypeName = ''Rest Unauthenticated'';
    break;
  case 28:
    loginTypeName = ''Rest Google Auth'';
    break;
  case 29:
    loginTypeName = ''Google OAuth2'';
    break;
  case 30:
    loginTypeName = ''Google OAuth2'';
    break;
  case 31:
    loginTypeName = ''Signup'';
    break;
  case 32:
    loginTypeName = ''MS Azure AD'';
    break;
  case 33:
    loginTypeName = ''Rest Google JWT Auth'';
    break;
  case 34:
    loginTypeName = ''Web Form'';
    break;
  case 35:
    loginTypeName = ''Download Ticket'';
    break;
  case 36:
    loginTypeName = ''Rest Azure JWT Auth'';
    break;
  case 37:
    loginTypeName = ''Rest Azure Ticket Auth'';
    break;
  case 38:
    loginTypeName = ''Approval Request'';
    break;
  default:
    loginTypeName = ''login ''.concat(LOGINTYPE);
}
return loginTypeName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_LOGINTYPENAME(38)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_PAYMENTTERM (PAYMENTTERM DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var paymentTerm;
switch (PAYMENTTERM) {
  case 1:
    paymentTerm = ''Monthly'';
    break;
  case 6:
    paymentTerm = ''Semi-Annual'';
    break;
  case 12:
    paymentTerm = ''Annual'';
    break;
  default:
    paymentTerm = ''Payment Term ''.concat(PAYMENTTERM)
}
return paymentTerm;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_PAYMENTTERM(5)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_PAYMENTTYPE (PAYMENTTYPE DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var paymentTypeName;
switch (PAYMENTTYPE) {
  case 0:
    paymentTypeName = ''None'';
    break;
  case 1:
    paymentTypeName = ''Credit Card'';
    break;
  case 2:
    paymentTypeName = ''Bill To'';
    break;
  case 3:
    paymentTypeName = ''Custom'';
    break;
  case 4:
    paymentTypeName = ''Promo'';
    break;
  case 5:
    paymentTypeName = ''Paid by Other'';
    break;
  case 6:
    paymentTypeName = ''Third Party'';
    break;
  case 7:
    paymentTypeName = ''Third Party - By Other'';
    break;
  case 8:
    paymentTypeName = ''PayPal'';
    break;
  case 9:
    paymentTypeName = ''Developer'';
    break;
  case 10:
    paymentTypeName = ''Bill To App'';
    break;
  default:
    paymentTypeName = ''Payment Type ''.concat(PAYMENTTYPE)
}
return paymentTypeName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_PAYMENTTYPE(5)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME (PRODUCTID DOUBLE)
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var productName;
switch (PRODUCTID) {
  case -1:
    productName = null;
    break;
  case 0:
    productName = ''Cancelled'';
    break;
  case 1:
    productName = ''Trial'';
    break;
  case 2:
    productName = ''Free'';
    break;
  case 3:
    productName = ''Basic'';
    break;
  case 4:
    productName = ''Advanced'';
    break;
  case 5:
    productName = ''Premium'';
    break;
  case 7:
    productName = ''Team'';
    break;
  case 8:
    productName = ''Team Plus'';
    break;
  case 6:
    productName = ''Enterprise_Legacy'';
    break;
  case 9:
    productName = ''Student'';
    break;
  case 10:
    productName = ''Business'';
    break;
  case 11:
    productName = ''Enterprise'';
    break;
  default:
    paymentTerm = ''Product ''.concat(PRODUCTID)
}
return productName;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(5)
--;

--######################################################################################

CREATE OR REPLACE FUNCTION MAIN.PUBLIC.SMARTSHEET_WEEK (STARTDATETIME VARCHAR)  -- COULD NOT FIGURE OUT HOW TO USE TIMESTAMP FOR PARAMETER
  RETURNS VARCHAR
  LANGUAGE JAVASCRIPT
AS '
var weekFriendly;

//SET weekFriendly = (LEFT(YEARWEEK(DATEADD(DAY, 1, STARTDATETIME),3),4) = YEAR(STARTDATETIME) ? YEAR(STARTDATETIME) : YEAR(STARTDATETIME) + 1).concat(
//                     ''*'', (WEEK(DATEADD(DAY, 1, STARTDATETIME),3) < 10 ? ''0''.concat(WEEK(DATEADD(DAY, 1, STARTDATETIME),3)) : WEEK(DATEADD(DAY, 1, STARTDATETIME),3))

weekFriendly = ''2018-02'';  // hard-coded value provided by Paivand on 2018-02-12 to expedite POC efforts

return weekFriendly;
'
;

--SELECT MAIN.PUBLIC.SMARTSHEET_WEEK('2017-06-15')
--;

