/***************************************************************************************************************************
 * This is running once a night, so it doesn't need to be as fast as the every 5 minute pull...			                   *
 * Updated 2015-12-01 to start using temp tables in order to minimize locking rpt_main_02 and ss_core_02 tables.           *
 ***************************************************************************************************************************/
# 

SELECT CURRENT_DATABASE();

-- debug

-- prevent us from locking any tables in core that might slow/stop replication

-- debug


-- debug - test longer wait timeout
SET tokudb_lock_timeout = 300000;

# Variable Declaration
SET v_processId = 0;
CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "Total");

--CALL rpt_main_02.utl_logProcessStart('marketo_nightly_update.sql',NULL,'','INFO',5, @v_processId);

INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG (
  PROCESS_ID
 ,PROCESS_NAME
 ,PARENT_PROCESS_ID
 ,PARENT_PROCESS_NAME
 ,LOG_LEVEL
 ,START_TIME
 ,PROCESS_TEXT
)
WITH CTE_PARAMS AS (
  SELECT COLUMN1 AS PROCESS_NAME
        ,COLUMN2 AS PARENT_PROCESS_ID
        ,COLUMN3 AS PROCESS_TEXT
        ,COLUMN4 AS LOG_LEVEL
        ,COLUMN5 AS LEVEL_CTRL_NUM
        ,COLUMN6 AS PROCESS_ID
    FROM VALUES ('marketo_nightly_update.sql',NULL,'','INFO',5, $v_processId)
)
SELECT X.PROCESS_ID AS PROCESS_ID
      ,P.PROCESS_NAME AS PROCESS_NAME
      ,P.PARENT_PROCESS_ID AS PARENT_PROCESS_ID
      ,UPL.PROCESS_NAME AS PARENT_PROCESS_NAME
      ,P.LOG_LEVEL AS LOG_LEVEL
      ,CURRENT_TIMESTAMP()::TIMESTAMP_NTZ AS START_TIME
      ,P.PROCESS_TEXT AS PROCESS_TEXT
  FROM CTE_PARAMS P
       JOIN UTL_LOG_LEVEL ULL
         ON ULL.LOG_LEVEL = P.LOG_LEVEL
       JOIN UTL_PROCESS_LOG UPL
         ON UPL.PROCESS_ID = P.PARENT_PROCESS_ID
       CROSS JOIN (SELECT MAIN.PUBLIC.SEQ_UTL_PROCESS_LOG.NEXTVAL PROCESS_ID FROM DUAL) X
 WHERE ULL.LOG_LEVEL_NUM <= P.LEVEL_CTRL_NUM
;

-- Begin section for nightly batch process fields
SELECT '************************************* marketo_nightly_update.sql start: ', CURRENT_TIMESTAMP;
SET marketoNightlyStartDateTime = CURRENT_TIMESTAMP();
SELECT @marketoNightlyStartDateTime;

SET highestNightlyUpdatePriority = 6;  	 -- updates for new leads from previous day plus more urgent data
SET mediumHighNightlyUpdatePriority = 5;  -- lead scoring
SET mediumNightlyUpdatePriority = 4;   	 -- activity indicators
SET lowestNightlyUpdatePriority = 2;   	 -- domain rollup type info

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.signupSource");

-- back fill with the friendly signup information
UPDATE arc_marketo_upload 
LEFT OUTER JOIN MAIN.RPT.signupSource ON arc_marketo_upload.userID = rpt_signupSource.userID  
SET 
	arc_marketo_upload.signupBucket = CASE rpt_signupSource.bucket IS NULL	-- viral bucket users don't have signup record
											WHEN 1 THEN "Viral"
											ELSE rpt_signupSource.bucket
										END,
	arc_marketo_upload.signupSource = CASE rpt_signupSource.sourceFriendly IS NULL
											WHEN 1 THEN "Sharing"
											ELSE rpt_signupSource.sourceFriendly
										END,
	arc_marketo_upload.signupSubSource = CASE rpt_signupSource.subSourceFriendly IS NULL
											WHEN 1 THEN "Sharing"
											ELSE rpt_signupSource.subSourceFriendly
										END,
	arc_marketo_upload.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, pushToMarketo),							-- flip the bit back to indicate record needs to be pushed.
	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()

WHERE
	COALESCE(arc_marketo_upload.signupBucket, "") != COALESCE(rpt_signupSource.bucket, "Viral") OR  -- most viral leads won't have a rpt_signupSource record, so if it is null, treat it as Viral
	COALESCE(arc_marketo_upload.signupSource, "") != COALESCE(rpt_signupSource.sourceFriendly, "Sharing") OR
	COALESCE(arc_marketo_upload.signupSubSource, "") != COALESCE(rpt_signupSource.subsourceFriendly, "Sharing")   	
;
SELECT "************************************* rpt_signupSource rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.signupSource");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "historyHighestPlan temp");

-- *************************************************************************************************************************
-- Update the highest paid plan from history
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_hist_paymentProfile_maxProduct;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_hist_paymentProfile_maxProduct
(INDEX (userID))
SELECT mu.userID, mp.paymentProfileID, mp.maxProduct FROM arc_marketo_upload mu
JOIN (
    SELECT pp.paymentProfileID,
    CASE MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(pp.productID))
        WHEN 1 THEN "Cancelled"
        WHEN 2 THEN "Trial"
        WHEN 3 THEN "Free"
        WHEN 4 THEN "Student"
        WHEN 5 THEN "Basic"
        WHEN 6 THEN "Advanced"
        WHEN 7 THEN "Premium"
        WHEN 8 THEN "Team"
        WHEN 9 THEN "Team Plus"
        WHEN 10 THEN "Business"
        WHEN 11 THEN "Enterprise_Legacy"
        WHEN 12 THEN "Enterprise"
    END AS maxProduct
    FROM ss_core_02.hist_paymentProfile pp
    WHERE pp.productID IN (3, 4, 5, 6, 7, 8, 10, 11) AND pp.planRate > 0  -- Explicitly search among just paid plans. Exclude "Cancelled", "Trial", "Free", and "Student".
    GROUP BY pp.paymentProfileID
) mp ON mu.paymentProfileID = mp.paymentProfileID
WHERE COALESCE(mu.historyHighestPlan, "") != COALESCE(mp.maxProduct, "")
;
SELECT "************************************* temp historyHighestPlan rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "historyHighestPlan temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "historyHighestPlan updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_hist_paymentProfile_maxProduct mp ON mu.userID = mp.userID
SET
    mu.historyHighestPlan = mp.maxProduct,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update historyHighestPlan rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "historyHighestPlan updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.containerCountsByUser");

-- Sheet, report, import, branded workspace counts
UPDATE arc_marketo_upload mu
JOIN MAIN.RPT.containerCountsByUser ccu ON mu.userID = ccu.userID
SET
    mu.sheetCount = ccu.sheetCount,
    mu.reportCount = ccu.reportCount,
    mu.importedSheetCount = ccu.importedSheetCount,
    mu.templateCount = ccu.templateCount,
    mu.usedBrandedWorkspace =
        CASE WHEN ccu.brandedWorkspaceCount > 0
            THEN 1 ELSE 0 END,
    mu.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.sheetCount, "") != COALESCE(ccu.sheetCount, "") OR
    COALESCE(mu.reportCount, "") != COALESCE(ccu.reportCount, "") OR
    COALESCE(mu.importedSheetCount, "") != COALESCE(ccu.importedSheetCount, "") OR
    COALESCE(mu.templateCount, "") != COALESCE(ccu.templateCount, "") OR
    (COALESCE(mu.usedBrandedWorkspace, 0) = 0 AND COALESCE(ccu.brandedWorkspaceCount, 0) > 0) -- only push if they had not used branded Workspace before, but now have a count
;
SELECT "************************************* sheetCount, reportCount rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.containerCountsByUser");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "eventLogCount updates");

-- Lifetime Activity Count
UPDATE arc_marketo_upload 
JOIN MAIN.RPT.clientLogCountsByUserArchived clcua ON arc_marketo_upload.userID = clcua.userID
SET 
	arc_marketo_upload.eventLogCount = clcua.lifetimeLogCount,
	arc_marketo_upload.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, pushToMarketo),
	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()	
WHERE COALESCE(arc_marketo_upload.eventLogCount, "") != COALESCE(clcua.lifetimeLogCount, "")
;
SELECT "************************************* eventLogCount rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();


CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "eventLogCount updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.loginCountTotal");

-- Login Activity
UPDATE arc_marketo_upload mu
JOIN MAIN.RPT.loginCountTotal lct ON mu.userID = lct.userID
SET
    mu.lastLogin = lct.lastLogin,
    mu.loginCount = lct.loginCount,
    mu.lastMobileLogin = lct.lastMobileLogin,
    mu.iOSAppLoginCount = lct.nativeIosSessionCount,
    mu.androidAppLoginCount = lct.nativeAndroidSessionCount,
    
    
    mu.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.lastLogin, "") != COALESCE(lct.lastLogin, "") OR
    COALESCE(mu.lastMobileLogin, "") != COALESCE(lct.lastMobileLogin, "") OR
    COALESCE(mu.loginCount, "") != COALESCE(lct.loginCount, "") OR
    COALESCE(mu.iOSAppLoginCount, "") != COALESCE(lct.nativeIosSessionCount, "") OR
    COALESCE(mu.androidAppLoginCount, "") != COALESCE(lct.nativeAndroidSessionCount, "")
;
SELECT "************************************* rpt_loginCountTotal rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.loginCountTotal");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.featureCountRollupByUser");

-- Added webForm count, usedReminders, usedCellLinking, hieracrhyCount, usedDriveAttachment
UPDATE arc_marketo_upload mu
JOIN MAIN.RPT.featureCountRollupByUser fcru ON mu.userID = fcru.userID
SET
    mu.sharingCount = fcru.sharingCount,
    mu.discussionCount = fcru.discussionCreatedCount,
    mu.attachmentCount = fcru.attachmentCreatedCount,
    mu.webFormCount = fcru.webFormCount,
    
    mu.hierarchyCount = fcru.hierarchyCount,
    mu.columnPropertyFormCount = fcru.columnPropertyFormCount,
    mu.usedChangeView =
        CASE WHEN fcru.usedChangeView > 0
            THEN 1 ELSE 0 END,

    mu.imagesInGridCount = fcru.imagesInGridCount,
    mu.cardViewViewCount = fcru.cardViewViewCount,
    mu.highestSharedSheetPermission = leadflow.MARKETO_SHARE_PERMISSION(fcru.highestSharedSheetPermission),
    mu.usedReminders =
        CASE WHEN fcru.reminderCount > 0
            THEN 1 ELSE 0 END,
    mu.usedCellLinking =
        CASE WHEN fcru.cellLinkCount > 0
            THEN 1 ELSE 0 END,
    mu.usedDriveAttachment =
        CASE WHEN fcru.googleDriveAttachmentCount > 0
            THEN 1 ELSE 0 END,
    mu.usedEvernoteAttachment =
        CASE WHEN fcru.evernoteAttachmentCount > 0
            THEN 1 ELSE 0 END,
    mu.clickedImportProjectCount = fcru.clickedImportProject,
    mu.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.sharingCount, "") != COALESCE(fcru.sharingCount, "") OR  	-- coalesce using "" instead of 0 forces pushing 0 into marketo
    COALESCE(mu.discussionCount, "") != COALESCE(fcru.discussionCreatedCount, "") OR
    COALESCE(mu.attachmentCount, "") != COALESCE(fcru.attachmentCreatedCount, "") OR
    COALESCE(mu.webFormCount, "") != COALESCE(fcru.webFormCount, "") OR
    COALESCE(mu.hierarchyCount, "") != COALESCE(fcru.hierarchyCount, "") OR
    COALESCE(mu.columnPropertyFormCount, "") != COALESCE(fcru.columnPropertyFormCount, "") OR
    (COALESCE(mu.usedChangeView, 0) = 0 AND COALESCE(fcru.usedChangeView, 0) > 0) OR -- only push if they had not used change view before, but now have a count
    COALESCE(mu.imagesInGridCount, "") != COALESCE(fcru.imagesInGridCount, "") OR
    COALESCE(mu.cardViewViewCount, "") != COALESCE(fcru.cardViewViewCount, "") OR
    COALESCE(mu.highestSharedSheetPermission, "") != leadflow.MARKETO_SHARE_PERMISSION(fcru.highestSharedSheetPermission) OR
    (COALESCE(mu.usedReminders, 0) = 0 AND COALESCE(fcru.reminderCount, 0) > 0) OR -- only push if they had not used reminders before, but now have a count
    (COALESCE(mu.usedCellLinking, 0) = 0 AND COALESCE(fcru.cellLinkCount, 0) > 0) OR -- only push if they had not used cell linking before, but now have a count
    (COALESCE(mu.usedDriveAttachment, 0) = 0 AND COALESCE(fcru.googleDriveAttachmentCount, 0) > 0) OR
    (COALESCE(mu.usedEvernoteAttachment, 0) = 0 AND COALESCE(fcru.evernoteAttachmentCount, 0) > 0) OR
    COALESCE(mu.clickedImportProjectCount, "") != COALESCE(fcru.clickedImportProject, "")
;
SELECT "************************************* rpt_featureCountRollupByUser rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.featureCountRollupByUser");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.dashboardCountByUser");

-- Added webForm count, usedReminders, usedCellLinking, hieracrhyCount, usedDriveAttachment
UPDATE arc_marketo_upload mu
    JOIN MAIN.RPT.dashboardCountByUser dcbu ON mu.userID = dcbu.userID
SET
    mu.dashboardCount = dcbu.dashboardsCreated,
    mu.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.dashboardCount, "") != COALESCE(dcbu.dashboardsCreated, "")
;
SELECT "************************************* rpt_dashboardCountByUser rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.dashboardCountByUser");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "clickedProjectImportCount");

-- Added webForm count, usedReminders, usedCellLinking, hieracrhyCount, usedDriveAttachment
UPDATE arc_marketo_upload mu
SET
    mu.userTags       = leadflow.MARKETO_IMPORT_MS_PROJECT(mu.userTags, mu.clickedImportProjectCount),
    mu.pushToMarketo  = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.userTags, '') != COALESCE(leadflow.MARKETO_IMPORT_MS_PROJECT(mu.userTags, mu.clickedImportProjectCount), '');
SELECT "************************************* clickedProjectImportCount rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "clickedProjectImportCount");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.ARC.DailyWellQualifiedLeads temp");

-- *************************************************************************************************************************
-- Well Qualified
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_arc_DailyWellQualifiedLeads_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_arc_DailyWellQualifiedLeads_to_sync
(INDEX (userID))
SELECT wql.userID FROM arc_marketo_upload mu
JOIN MAIN.ARC.DailyWellQualifiedLeads wql ON mu.userID = wql.userID
WHERE COALESCE(mu.isEverWellQualified, "") != 1
;
SELECT "************************************* temp isEverWellQualified rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.ARC.DailyWellQualifiedLeads temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.ARC.DailyWellQualifiedLeads updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_arc_DailyWellQualifiedLeads_to_sync wql ON mu.userID = wql.userID
SET
    mu.isEverWellQualified = 1,
    mu.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update isEverWellQualified rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.ARC.DailyWellQualifiedLeads updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "isStrongLead updates");

-- Strong Lead
UPDATE arc_marketo_upload 
JOIN MAIN.RPT.clientLogCountsByUserArchived ON arc_marketo_upload.userID = rpt_clientLogCountsByUserArchived.userID
SET 
	arc_marketo_upload.isStrongLead = 1,
	arc_marketo_upload.pushToMarketo = GREATEST(@mediumNightlyUpdatePriority, pushToMarketo),
	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()		
WHERE COALESCE(arc_marketo_upload.isStrongLead, "") != 1 AND rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
;
SELECT "************************************* isStrongLead rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "isStrongLead updates");

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.paidDomains");

-- Update highest domain product
UPDATE arc_marketo_upload mu
LEFT OUTER JOIN MAIN.RPT.paidDomains pd ON mu.emailDomain = pd.mainContactDomain
SET
    mu.domainsHighestPlan = pd.MaxProduct,
    mu.pushToMarketo = GREATEST(@lowestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.domainsHighestPlan, "") != COALESCE(pd.MaxProduct, "")
    AND mu.isOrgDomain = 1  -- Filter out ISP domains. Highest paid plan data for an ISP domain are not helpful.
;
SELECT "************************************* domainsHighestPlan rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.paidDomains");


-- could be used to set isOrgDomain flag if needed, right now handled every 5 minutes
-- UPDATE arc_marketo_upload 
-- LEFT OUTER JOIN MAIN.ARC.ISPDomains ON arc_marketo_upload.emailDomain = arc_ISPDomains.domain
-- SET arc_marketo_upload.isOrgDomain = CASE WHEN arc_ISPDomains.domain IS NULL THEN 1 ELSE 0 END,
-- 	arc_marketo_upload.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, pushToMarketo),
-- 	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()	
-- WHERE (arc_ISPDomains.domain IS NOT NULL AND arc_marketo_upload.isOrgDomain = 1)  OR (arc_ISPDomains.domain IS NULL AND arc_marketo_upload.isOrgDomain = 0)
-- ;


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.domainRollup setting temp");

-- *************************************************************************************************************************
-- Update domain rollup info
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_domainRollup_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_domainRollup_to_sync
(INDEX (userID))
SELECT mu.userID, dr.domain, dr.googleAppsDomain FROM arc_marketo_upload mu
LEFT OUTER JOIN MAIN.RPT.domainRollup dr ON mu.emailDomain = dr.domain
WHERE
    COALESCE(mu.isGoogleAppsInstalledDomain, 0) != COALESCE(dr.googleAppsDomain, 0)
    -- OR COALESCE(mu.domainUseInPastYear, 0) != COALESCE(dr.usersLoggedInPast12Months, 0)  -- MKTO0340
    -- OR COALESCE(mu.currentDomainTrials, 0) != COALESCE(dr.usersInTrial, 0))              -- MKTO0340
    AND mu.isOrgDomain = 1 -- set domain fields only when its a real domain
;
SELECT "************************************* temp rpt_domainRollup setting rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.domainRollup setting temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.domainRollup setting updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_rpt_domainRollup_to_sync dr ON mu.userID = dr.userID
SET mu.isGoogleAppsInstalledDomain = dr.googleAppsDomain,
-- 	mu.domainUseInPastYear = dr.usersLoggedInPast12Months,  -- MKTO0340
-- 	mu.currentDomainTrials = dr.usersInTrial,               -- MKTO0340
	mu.pushToMarketo = GREATEST(@lowestNightlyUpdatePriority, mu.pushToMarketo),
	mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update rpt_domainRollup setting rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.domainRollup setting updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.domainRollup clearing temp");

-- *************************************************************************************************************************
-- Clear domain rollup info
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_domainRollup_clear_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_domainRollup_clear_to_sync
(INDEX (userID))
SELECT mu.userID, dr.domain FROM arc_marketo_upload mu
LEFT OUTER JOIN MAIN.RPT.domainRollup dr ON mu.emailDomain = dr.domain
WHERE
    COALESCE(mu.isGoogleAppsInstalledDomain, 0) != 0
    -- OR COALESCE(mu.domainUseInPastYear, 0) != 0  -- MKTO0340
    -- OR COALESCE(mu.currentDomainTrials, 0) != 0) -- MKTO0340
    AND mu.isOrgDomain = 0 -- clear these values if it not an org domain anymore
;
SELECT "************************************* temp rpt_domainRollup clearing rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.domainRollup clearing temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.domainRollup clearing updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_rpt_domainRollup_clear_to_sync dr ON mu.userID = dr.userID
SET
    mu.isGoogleAppsInstalledDomain = 0,
    --	mu.domainUseInPastYear = 0, -- MKTO0340
    --	mu.currentDomainTrials = 0, -- MKTO0340
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update rpt_domainRollup clearing rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.domainRollup clearing updates");


-- *************************************************************************************************************************
-- Lock debugging
-- *************************************************************************************************************************
-- SELECT COUNT(*), information_schema.tokudb_locks.*, pl.* FROM information_schema.tokudb_locks
-- JOIN information_schema.PROCESSLIST pl ON pl.ID = locks_mysql_thread_id
-- WHERE locks_table_schema != "rpt_workspace"
-- GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
-- ;
-- SELECT "************************************* lock debugging : ", ROW_COUNT(), CURRENT_TIMESTAMP();


-- *************************************************************************************************************************
-- Debugging
-- *************************************************************************************************************************
# SHOW VARIABLES LIKE 'tx_isolation'
# ;
# EXPLAIN
# UPDATE arc_marketo_upload mu
# LEFT OUTER JOIN MAIN.RPT.userIPLocation ul ON mu.userID = ul.userID
# SET
#     mu.ipCountry = ul.ipCountry,
#     mu.ipRegion = ul.ipRegion,
#     mu.ipCity = ul.ipCity,
#     mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
#     mu.updateDateTime = CURRENT_TIMESTAMP()
# WHERE
#     (mu.ipCountry IS NULL AND ul.ipCountry IS NOT NULL) OR -- only update if need and have value
#     (mu.ipRegion IS NULL AND ul.ipRegion IS NOT NULL) OR
#     (mu.ipCity IS NULL AND ul.ipCity IS NOT NULL)
# ;
# SHOW FULL PROCESSLIST
# ;

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.userIPLocation");

-- Update country information
UPDATE arc_marketo_upload mu
LEFT OUTER JOIN MAIN.RPT.userIPLocation ul ON mu.userID = ul.userID
SET
    mu.ipCountry = ul.ipCountry,
    mu.ipRegion = ul.ipRegion,
    mu.ipCity = ul.ipCity,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    (mu.ipCountry IS NULL AND ul.ipCountry IS NOT NULL) OR -- only update if need and have value
    (mu.ipRegion IS NULL AND ul.ipRegion IS NOT NULL) OR
    (mu.ipCity IS NULL AND ul.ipCity IS NOT NULL)
;
SELECT "************************************* rpt_userIPLocation rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.userIPLocation");


-- debug
SELECT @@tokudb_last_lock_timeout;


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "ss_account_02.siteSettingElementValue");

-- *************************************************************************************************************************
-- Update AB Test Variations
-- Create temporary table of all users and their corresponding abtest values
-- (updated 2016-12-19 to speed up query with temp table)
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_sitesetting_abtest;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sitesetting_abtest
(INDEX (userID))
    SELECT
        ssev.userID,
        -- add order so order doesn't keep changing triggering an update
        GROUP_CONCAT(DISTINCT siteSettingElementName, ':', FLOOR(valueNumeric) ORDER BY siteSettingElementValueID DESC
                     SEPARATOR ';') AS NewABTestValue
    FROM ss_account_02.siteSettingElementValue ssev
        JOIN leadflow.arc_marketo_upload mu ON mu.userID = ssev.userID
    WHERE ssev.siteSettingElementName LIKE 'SS_ABTEST%'
    GROUP BY ssev.userID;
SELECT "************************************* ABTests temp rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

-- Update AB Test Variations
-- Updated 2016-12-27: Concatenate any optimizely bucket ID info to the beginning of the ABTests field
UPDATE arc_marketo_upload mu
    JOIN tmp_sitesetting_abtest ss ON ss.userID = mu.userID
SET
    mu.ABTests        = CASE
                            WHEN ss.NewABTestValue IS NULL AND mu.optimizelyBuckets IS NULL THEN NULL
                            ELSE CONCAT_WS(';', mu.optimizelyBuckets, ss.NewABTestValue)
                        END,
    mu.pushToMarketo  = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.ABTests, '') != COALESCE(ss.NewABTestValue, '') COLLATE utf8mb4_unicode_520_ci
;
SELECT "************************************* ABTests rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "ss_account_02.siteSettingElementValue");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "ss_core_02.organizationUserRole");

-- *************************************************************************************************************************
-- Update organization roles
-- (updated 2016-01-26 to account for special GE request; see MKTO1817 for details)
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
    LEFT JOIN (
                  SELECT
                      our.userID,
                      our.organizationID,
                      CONCAT_WS(';',
                                GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                                CASE WHEN org.mainContactUserID IS NOT NULL
                                    THEN 'MAIN_CONTACT'
                                ELSE NULL END) AS newOrgRoles
                  FROM ss_core_02.organizationUserRole our
                      JOIN arc_marketo_upload mu ON mu.userID = our.userID
                      LEFT JOIN ss_core_02.organization org ON mu.userID = org.mainContactUserID AND org.state = 1
                  GROUP BY our.userID
              ) orgRole ON mu.userID = orgRole.userID
SET
    mu.organizationRoles = orgRole.newOrgRoles,
    mu.pushToMarketo     = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime    = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.organizationRoles, "") != COALESCE(orgRole.newOrgRoles, "") COLLATE utf8mb4_unicode_520_ci
    AND COALESCE(orgRole.organizationID, 0) != 1030645 -- Exclude GE. Their org roles are updated in next query.
;
SELECT "************************************* organizationRoles rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "ss_core_02.organizationUserRole");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "ss_core_02.organizationUserRole GE");

-- See MKTO1817. We are adding an additional field to distinguish whether a GE customer was
-- added by a specific user in order to include them in specialized Marketo campaigns.
UPDATE arc_marketo_upload mu
    JOIN (
             SELECT
                 our.userID,
                 CONCAT_WS(';',
                           GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                           CASE WHEN org.mainContactUserID IS NOT NULL
                               THEN 'MAIN_CONTACT'
                           ELSE NULL END,
                           CONCAT('LICENSE_ADDED_BY:', COALESCE(our2.insertByUserID, 0))) AS newOrgRoles
             FROM ss_core_02.organizationUserRole our
                 JOIN arc_marketo_upload mu ON our.userID = mu.userID AND our.organizationID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
                 LEFT JOIN ss_core_02.organizationUserRole our2 ON our.userID = our2.userID AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insertByUserID to be specifically from the LICENSE_USER role
                 LEFT JOIN ss_core_02.organization org ON mu.userID = org.mainContactUserID AND org.state = 1
             GROUP BY our.userID
             ORDER BY our.userID ASC
         ) orgRole ON mu.userID = orgRole.userID
SET
    mu.organizationRoles = orgRole.newOrgRoles,
    mu.pushToMarketo     = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime    = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.organizationRoles, "") != COALESCE(orgRole.newOrgRoles, "") COLLATE utf8mb4_unicode_520_ci
;
SELECT "************************************* GE organizationRoles rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "ss_core_02.organizationUserRole GE");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.launchedSolutionsByUser");

-- *************************************************************************************************************************
-- Update solutions used
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
JOIN
    (
        SELECT sbu.userID, GROUP_CONCAT(DISTINCT rpt_main_02.SMARTSHEET_SOLUTIONDEPT(sbu.Department), ':', sbu.name ORDER BY sbu.insertDateTime DESC SEPARATOR ';') AS newSolutionsUsed -- add order to eliminate unnecessary updates
        FROM MAIN.RPT.launchedSolutionsByUser sbu
        GROUP BY sbu.userID
        ORDER BY sbu.userID ASC
    ) solUsed ON mu.userID = solUsed.userID
SET
    mu.solutionsUsed = solUsed.newSolutionsUsed,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.solutionsUsed, "") != COALESCE(solUsed.newSolutionsUsed, "")
;
SELECT "************************************* solutionsUsed rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.launchedSolutionsByUser");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.userRole");

-- *************************************************************************************************************************
-- Update inferred role
-- Inferred role definitions. Priority is ranked based on most reliable data.
--   1. sfdcTitle: Role inferred from the lead/contact title in SFDC.
--   2. 411Title: Role inferred from lead title in 411 database.
--   3. signupCampaign: Role inferred from the lead's signup campaign.
--   4. categoryTemplate: Role inferred from a user's most used templates
--      (at least 40% of their sheets are of the same template type as long as they have at least 5 sheets)
-- *************************************************************************************************************************

-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE arc_marketo_upload mu
    JOIN MAIN.RPT.userRole ur ON mu.userID = ur.userID
SET
    mu.inferredRole =
        CASE
            WHEN COALESCE(mu.inferredRole, "") LIKE "signupRole%" THEN mu.inferredRole
            WHEN ur.sfdcRole IS NOT NULL THEN CONCAT("sfdcTitle:", ur.sfdcRole)
            WHEN ur.lead411Role IS NOT NULL THEN CONCAT("411Title:", ur.lead411Role)
            WHEN ur.signupCampaignRole IS NOT NULL THEN CONCAT("signupCampaign:", ur.signupCampaignRole)
            WHEN ur.templateCategoryRole IS NOT NULL THEN CONCAT("categoryTemplate:", ur.templateCategoryRole)
        END,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.inferredRole, "") !=
        CASE
            WHEN COALESCE(mu.inferredRole, "") LIKE "signupRole%" THEN mu.inferredRole
            WHEN ur.sfdcRole IS NOT NULL THEN CONCAT("sfdcTitle:", ur.sfdcRole)
            WHEN ur.lead411Role IS NOT NULL THEN CONCAT("411Title:", ur.lead411Role)
            WHEN ur.signupCampaignRole IS NOT NULL THEN CONCAT("signupCampaign:", ur.signupCampaignRole)
            WHEN ur.templateCategoryRole IS NOT NULL THEN CONCAT("categoryTemplate:", ur.templateCategoryRole)
            ELSE ""
        END
;
-- ORIGINAL
-- UPDATE arc_marketo_upload mu
-- JOIN MAIN.RPT.userRole ur ON mu.userID = ur.userID
-- SET
--     mu.inferredRole =
--         CASE
--             WHEN ur.sfdcRole IS NOT NULL THEN CONCAT("sfdcTitle:", ur.sfdcRole)
--             WHEN ur.lead411Role IS NOT NULL THEN CONCAT("411Title:", ur.lead411Role)
--             WHEN ur.signupCampaignRole IS NOT NULL THEN CONCAT("signupCampaign:", ur.signupCampaignRole)
--             WHEN ur.templateCategoryRole IS NOT NULL THEN CONCAT("categoryTemplate:", ur.templateCategoryRole)
--         END,
--     mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
--     mu.updateDateTime = CURRENT_TIMESTAMP()
-- WHERE
--     COALESCE(mu.inferredRole, "") !=
--         CASE
--             WHEN ur.sfdcRole IS NOT NULL THEN CONCAT("sfdcTitle:", ur.sfdcRole)
--             WHEN ur.lead411Role IS NOT NULL THEN CONCAT("411Title:", ur.lead411Role)
--             WHEN ur.signupCampaignRole IS NOT NULL THEN CONCAT("signupCampaign:", ur.signupCampaignRole)
--             WHEN ur.templateCategoryRole IS NOT NULL THEN CONCAT("categoryTemplate:", ur.templateCategoryRole)
--             ELSE ""
--         END
-- ;
SELECT "************************************* inferredRole rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.userRole");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organizationName/accountRole temp");

-- *************************************************************************************************************************
-- Update organization name and accountRole
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_paymentProfile_organization_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_paymentProfile_organization_to_sync
(INDEX (userID))
    SELECT
        mu.userID,
        parentPP.paymentProfileID,
        org.name,
        org.organizationID,
        org.mainContactUserID
    FROM arc_marketo_upload mu
        LEFT OUTER JOIN ss_core_02.paymentProfile parentPP ON mu.parentPaymentProfileID = parentPP.paymentProfileID
        LEFT OUTER JOIN ss_core_02.organization org ON parentPP.OWNER_ID = org.organizationID AND parentPP.accountType = 3
    WHERE
        COALESCE(org.name, "") COLLATE utf8mb4_unicode_520_ci != COALESCE(mu.organizationName, "") OR
        COALESCE(org.organizationID, "") != COALESCE(mu.organizationID, "") OR
        COALESCE(mu.accountRole, "") !=
        COALESCE(rpt_main_02.MARKETO_ACCOUNT_ROLE(mu.paymentProfileID, parentPP.paymentProfileID, org.mainContactUserID, mu.userID), '') COLLATE
        utf8mb4_unicode_520_ci
;
SELECT "************************************* temp organizationName, accountRole rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organizationName/accountRole temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organizationName/accountRole updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_paymentProfile_organization_to_sync pporg ON mu.userID = pporg.userID  -- Must join on userID to prevent updating more records than necessary
SET
    mu.organizationName = pporg.name,
    mu.organizationID = pporg.organizationID,
    mu.accountRole = rpt_main_02.MARKETO_ACCOUNT_ROLE(mu.paymentProfileID, pporg.paymentProfileID, pporg.mainContactUserID, mu.userID),
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update organizationName, accountRole rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organizationName/accountRole updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization product name temp");

-- *************************************************************************************************************************
-- Update organization product name for all org users
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_organizationUserRole_paymentProfiles_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_organizationUserRole_paymentProfiles_to_sync
(INDEX (userID))
SELECT
    mui.userID,
    -- Triple nested function: 1. Get max product rank, 2. convert rank back to productID, 3. convert productID to product name.
    rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_main_02.SMARTSHEET_PRODUCTRANKCONVERT(MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(ppp.productID)))) maxOrgProduct
FROM arc_marketo_upload mui
JOIN ss_core_02.organizationUserRole our ON mui.userID = our.userID AND our.state != 3             -- Ignore declined users
JOIN ss_core_02.organization org ON our.organizationID = org.organizationID AND org.state = 1      -- Include only active orgs
JOIN ss_core_02.paymentProfile ppp ON our.organizationID = ppp.OWNER_ID AND ppp.accountType = 3     -- Just want org accounts
GROUP BY mui.userID
;
SELECT "************************************* temp orgProductName rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization product name temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization product name updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
LEFT JOIN tmp_organizationUserRole_paymentProfiles_to_sync orgProducts ON mu.userID = orgProducts.userID
SET
    mu.orgProductName = orgProducts.maxOrgProduct,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.orgProductName, '') != COALESCE(orgProducts.maxOrgProduct, '')
;
SELECT "************************************* update orgProductName rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization product name updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization license limit temp");

-- *************************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_org_user_role_nightly_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_user_role_nightly_updates
(KEY (userID))
    SELECT
        mu.userID,
        uid.organizationID,
        -- Set defaults to zero
        IFNULL(ppp.userLimit, 0) paidLicenseLimit,
        IFNULL(ppp.bonusUserCount, 0) bonusLicenseLimit,
        IFNULL(SUM(our.state = 1), 0) assignedLicenseCount,
        IFNULL(SUM(our.state = 2), 0) pendingLicenseCount
    FROM arc_marketo_upload mu
        JOIN (
                 (SELECT our1.userID, our1.organizationID
                  FROM ss_core_02.organizationUserRole our1
                      JOIN arc_marketo_upload mu ON our1.userID = mu.userID
                  WHERE
                      our1.role = 'USER_ADMIN'
                      AND our1.state = 1)
                 UNION
                 (SELECT org.mainContactUserID, org.organizationID
                  FROM ss_core_02.organization org
                      JOIN arc_marketo_upload mu ON org.mainContactUserID = mu.userID
                  WHERE org.state = 1)
                 ORDER BY 1 ASC
             ) uid ON mu.userID = uid.userID
        LEFT JOIN ss_core_02.paymentProfile ppp ON
                                                    uid.organizationID = ppp.OWNER_ID
                                                    AND ppp.accountType = 3
        LEFT JOIN ss_core_02.organizationUserRole our ON
                                                          uid.organizationID = our.organizationID
                                                          AND our.role = 'LICENSE_USER'
                                                          AND our.state IN (1, 2)
    GROUP BY uid.userID, uid.organizationID
;
SELECT "************************************* temp org license limit rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

-- 2. Create temporary table comparing existing values
DROP TABLE IF EXISTS tmp_org_user_role_license_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_user_role_license_updates
(INDEX (userID))
    SELECT
        mu.userID,
        lic.paidLicenseLimit,
        lic.bonusLicenseLimit,
        lic.assignedLicenseCount,
        lic.pendingLicenseCount
    FROM arc_marketo_upload mu
        LEFT JOIN tmp_org_user_role_nightly_updates lic ON mu.userID = lic.userID
    WHERE
        COALESCE(mu.bonusLicenseLimit, '') != COALESCE(lic.bonusLicenseLimit, '')
        OR COALESCE(mu.assignedLicenseCount, '') != COALESCE(lic.assignedLicenseCount, '')
        OR COALESCE(mu.pendingLicenseCount, '') != COALESCE(lic.pendingLicenseCount, '')
;
SELECT "************************************* temp org license limit diff rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization license limit temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization license limit updates");

-- 3. Update license limits in leads table
UPDATE arc_marketo_upload mu
    JOIN tmp_org_user_role_license_updates lic ON mu.userID = lic.userID
SET
    mu.userLimit = lic.paidLicenseLimit,
    mu.bonusLicenseLimit = lic.bonusLicenseLimit,
    mu.assignedLicenseCount = lic.assignedLicenseCount,
    mu.pendingLicenseCount = lic.pendingLicenseCount,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update org license limit rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization license limit updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization license tag temp");

-- *************************************************************************************************************************
-- Update organization license tags
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_lic_tag_nightly_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_lic_tag_nightly_updates
(INDEX (userID))
    SELECT
        lic.userID,
        leadflow.MARKETO_LICENSE_TAG(lic.assignedLicenseCount, lic.pendingLicenseCount, lic.paidLicenseLimit,
                                     mu.previousUserLimit, COUNT(our.organizationUserRoleID)) licenseTags
    FROM arc_marketo_upload mu
        JOIN tmp_org_user_role_nightly_updates lic ON mu.userID = lic.userID
        LEFT JOIN ss_core_02.organizationUserRole our
            ON lic.organizationID = our.organizationID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insertDateTime >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
    GROUP BY lic.userID, lic.organizationID
;
SELECT "************************************* temp org license tag rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization license tag temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "organization license tag updates");

-- 2. Update license tags in leads table
UPDATE arc_marketo_upload mu
    JOIN tmp_lic_tag_nightly_updates tag ON mu.userID = tag.userID
SET
    mu.licenseTags = tag.licenseTags,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.licenseTags, '') != COALESCE(tag.licenseTags, '')
;
SELECT "************************************* update org license tag rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "organization license tag updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "trialEndDateDateTime temp");

-- *************************************************************************************************************************
-- Update trialEndDateDateTime name
-- Needed for when parentPaymentProfile changes it doesn't get handled in marketoLeadsUploadCondeep.sql
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_paymentProfile_trialEndDateDateTime_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_paymentProfile_trialEndDateDateTime_to_sync
(INDEX (userID))
SELECT
    mu.userID,
    pp.paymentProfileID pppaymentProfileID,
    pp.productID ppproductID,
    pp.paymentEndDateTime pppaymentEndDateTime,
    parentpp.paymentEndDateTime parentpppaymentEndDateTime,
    parentpp.paymentStartDateTime parentpppaymentStartDateTime
FROM arc_marketo_upload mu
JOIN ss_core_02.paymentProfile pp ON mu.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN ss_core_02.paymentProfile parentpp ON mu.parentPaymentProfileID = parentpp.paymentProfileID
WHERE
    (COALESCE(mu.trialEndDateDateTime, "") != COALESCE(pp.paymentEndDateTime, parentpp.paymentEndDateTime) AND pp.productID = 1) OR
    COALESCE(mu.parentPaymentStartDateTime, "") != COALESCE(parentpp.paymentStartDateTime, "")
;
SELECT "************************************* temp trialEndDateDateTime rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "trialEndDateDateTime temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "trialEndDateDateTime updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_paymentProfile_trialEndDateDateTime_to_sync tmp ON mu.userID = tmp.userID  -- Must join on userID to prevent updating more records than necessary
SET
    mu.trialEndDateDateTime =
        CASE
            -- get the end date from the paymentProfile, but it will be null if it is a team trial, if so, get it from the parent
            WHEN tmp.ppproductID = 1  THEN COALESCE(tmp.pppaymentEndDateTime, tmp.parentpppaymentEndDateTime)  -- 1=in trial,
            ELSE mu.trialEndDateDateTime -- don't over write, this will stay the end date time of last trial
        END,
    -- get the date from the parent, will be null if no parent
    mu.parentPaymentStartDateTime = tmp.parentpppaymentStartDateTime,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update trialEndDateDateTime rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "trialEndDateDateTime updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.ARC.churnScoring");

UPDATE arc_marketo_upload
JOIN MAIN.ARC.churnScoring ON arc_marketo_upload.paymentProfileID = arc_churnScoring.paymentProfileID
SET arc_marketo_upload.churnRiskCategory = 'Basic-Week5-NoExpansion',
	arc_marketo_upload.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, pushToMarketo),
	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()	
WHERE COALESCE(arc_marketo_upload.churnRiskCategory, "") != 'Basic-Week5-NoExpansion'  AND
	willChurn_wk5 = willChurn_maxWeek AND willChurn_wk5 = 1
;
SELECT "************************************* churnRiskCategory.Basic-Week5-NoExpansion rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.ARC.churnScoring");

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.userPaymentFunnelProgress");

UPDATE arc_marketo_upload 
JOIN MAIN.RPT.userPaymentFunnelProgress upfp ON arc_marketo_upload.userID = upfp.userID
SET 
	arc_marketo_upload.upgradeWizardProgress = MARKETO_UPGRADE_WIZARD_PROGRESS(ViewedConfirmPage, PayPalComplete, PayPalStart, ViewedStep3, ViewedStep2, ViewedStep1),
	arc_marketo_upload.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, pushToMarketo),
	arc_marketo_upload.updateDateTime = CURRENT_TIMESTAMP()		
WHERE COALESCE(arc_marketo_upload.upgradeWizardProgress, "") != MARKETO_UPGRADE_WIZARD_PROGRESS(ViewedConfirmPage, PayPalComplete, PayPalStart, ViewedStep3, ViewedStep2, ViewedStep1)
;
SELECT "************************************* upgradeWizardProgress rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.userPaymentFunnelProgress");

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.paidPlanCurrentUsers temp");

-- *************************************************************************************************************************
-- Update Persona
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_paidPlanCurrentUsers_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_paidPlanCurrentUsers_to_sync
(INDEX (userID))
SELECT mu.userID, ppcu.Persona FROM arc_marketo_upload mu
LEFT JOIN MAIN.RPT.paidPlanCurrentUsers ppcu ON mu.userID = ppcu.mainContactUserID
WHERE COALESCE(mu.persona, "") != COALESCE(ppcu.Persona, "")
;
SELECT "************************************* temp persona rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.paidPlanCurrentUsers temp");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.paidPlanCurrentUsers updates");

-- 2. Update leads table
UPDATE arc_marketo_upload mu
JOIN tmp_rpt_paidPlanCurrentUsers_to_sync ppcu ON mu.userID = ppcu.userID
SET
    mu.persona = ppcu.Persona,
    mu.pushToMarketo = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* update persona rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.paidPlanCurrentUsers updates");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.ARC.domainEmailExclusion collabs");

-- *************************************************************************************************************************
-- Match marketing email opt outs for collabs inserted by excluded domains
-- Added 2016-04-01
-- Updated 2016-08-03 to add organization level exclusions
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_collabs_opt_out;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_collabs_opt_out
(PRIMARY KEY (userID))
    SELECT
        mu2.userID,
        (COALESCE(dee.excludeFromMarketingEmail, 0) = 1 AND COALESCE(dex.includeForMarketingEmail, 0) = 0) AS excludeFromMarketingEmail
    FROM MAIN.ARC.domainEmailExclusion dee
        JOIN leadflow.arc_marketo_upload mu
             USE INDEX (idx_emailDomain) ON dee.domain = mu.emailDomain
        JOIN ss_core_02.userAccount ua ON mu.userID = ua.insertByUserID
        -- Get all collabs who were inserted by the excluded domain users
        LEFT JOIN MAIN.ARC.domainEmailExclusion dee2
            ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = dee2.domain AND COALESCE(dee2.excludeFromMarketingEmail, 0) = 1
        -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.ARC.organizationEmailExclusion oee
            ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = mu.emailDomain AND COALESCE(oee.excludeFromMarketingEmail, 0) = 1
        JOIN leadflow.arc_marketo_upload mu2
            ON ua.userID = mu2.userID -- Get all collabs in sync table to check if domainOptOut needs to be updated
        LEFT JOIN MAIN.ARC.domainEmailExclusionExceptions dex ON mu2.emailAddress = dex.emailAddress
    WHERE
        dee2.domain IS NULL  -- Only update collabs in domains that are NOT in the exclusion table
        AND oee.organizationID IS NULL
        AND dee.excludeFromMarketingEmail = 1
        -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
        AND dee.domain != 'smartsheet.com'
    UNION
    SELECT
        mu2.userID,
        (COALESCE(oee.excludeFromMarketingEmail, 0) = 1 AND COALESCE(dex.includeForMarketingEmail, 0) = 0) AS excludeFromMarketingEmail
    FROM ss_core_02.organizationUserRole our
        JOIN MAIN.ARC.organizationEmailExclusion oee
            ON our.organizationID = oee.organizationID AND oee.excludeFromMarketingEmail = 1 AND
               -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
               oee.organizationID != 1000008
        JOIN leadflow.arc_marketo_upload mu ON our.userID = mu.userID
        JOIN ss_core_02.userAccount ua ON mu.userID = ua.insertByUserID
        -- Get all collabs who were inserted by the excluded users
        LEFT JOIN MAIN.ARC.organizationEmailExclusion oee2
            ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = mu.emailDomain AND COALESCE(oee2.excludeFromMarketingEmail, 0) = 1
        -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.ARC.domainEmailExclusion dee
            ON rpt_main_02.MARKETO_EXTRACT_DOMAIN(ua.emailAddress) = dee.domain AND COALESCE(dee.excludeFromMarketingEmail, 0) = 1
        JOIN leadflow.arc_marketo_upload mu2
            ON ua.userID = mu2.userID -- Get all collabs in sync table to check if domainOptOut needs to be updated
        LEFT JOIN MAIN.ARC.domainEmailExclusionExceptions dex ON mu2.emailAddress = dex.emailAddress
    WHERE
        oee2.organizationID IS NULL  -- Only update collabs in parent payment profile that are NOT in the exclusion table
        AND dee.domain IS NULL
        AND our.state IN (1, 2)
    GROUP BY mu2.userID
;
SELECT "************************************* temp collab domainOptOut rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

UPDATE leadflow.arc_marketo_upload mu
    JOIN tmp_collabs_opt_out coo ON mu.userID = coo.userID
SET
    mu.domainOptOut   = coo.excludeFromMarketingEmail,
    mu.pushToMarketo  = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.domainOptOut, 0) != COALESCE(coo.excludeFromMarketingEmail, 0)
;
SELECT "************************************* update collab domainOptOut rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.ARC.domainEmailExclusion collabs");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.ARC.domainEmailExclusion");

-- *************************************************************************************************************************
-- Update marketing email opt outs by domain
-- Updated 2016-01-22 to move exceptions to MAIN.ARC.domainEmailExclusionExceptions table
-- Updated 2016-08-03 to add organization level exclusions
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_opt_out_changes;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_opt_out_changes
(PRIMARY KEY (userID))
    SELECT
        mu.userID,
        MAX((COALESCE(dee.excludeFromMarketingEmail, 0) = 1 OR
             COALESCE(oee.excludeFromMarketingEmail, 0) = 1)) shouldExclude,
        -- Only time someone can opt out is when they want their domain to be excluded and DON'T have an exception
        ((COALESCE(dee.excludeFromMarketingEmail, 0) = 1 OR COALESCE(oee.excludeFromMarketingEmail, 0) = 1) AND
         COALESCE(dex.includeForMarketingEmail, 0) = 0)       newDomainOptOut
    FROM leadflow.arc_marketo_upload mu
        LEFT JOIN ss_core_02.organizationUserRole our
            ON mu.userID = our.userID AND our.role = 'MEMBER' AND our.state IN (1, 2)
        LEFT JOIN MAIN.ARC.domainEmailExclusion dee ON mu.emailDomain = dee.domain
        LEFT JOIN MAIN.ARC.organizationEmailExclusion oee ON our.organizationID = oee.organizationID
        LEFT JOIN MAIN.ARC.domainEmailExclusionExceptions dex ON mu.emailAddress = dex.emailAddress
        LEFT JOIN tmp_collabs_opt_out coo ON mu.userID = coo.userID
    WHERE
        coo.userID IS NULL
        AND COALESCE(mu.domainOptOut, 0) !=
            ((COALESCE(dee.excludeFromMarketingEmail, 0) = 1 OR COALESCE(oee.excludeFromMarketingEmail, 0) = 1) AND
             COALESCE(dex.includeForMarketingEmail, 0) = 0)
    GROUP BY mu.userID
;
SELECT "************************************* domainOptOut temp rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

UPDATE leadflow.arc_marketo_upload mu
    JOIN tmp_opt_out_changes ooc ON mu.userID = ooc.userID
SET
    mu.domainOptOut   = ooc.newDomainOptOut,
    mu.pushToMarketo  = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime = CURRENT_TIMESTAMP()
;
SELECT "************************************* domainOptOut rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.ARC.domainEmailExclusion");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "MAIN.RPT.csaReport");

-- *************************************************************************************************************************
-- Update tier, health, and CSA drip bucket by domain
-- (Added 2016-03-22)
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_csaReport;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_csaReport
(INDEX (userID))
    SELECT
        mu.userID,
        cs.accountHealth,
        cs.accountTier,
        cs.AccountToBeAssigned,
        cs.territory
    FROM arc_marketo_upload mu
        LEFT JOIN SFDC.PUBLIC.domain d ON mu.emailDomain = d.Domain_Name_URL__c
        LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
        LEFT JOIN MAIN.RPT.csReport cs ON a.Id = cs.accountId
    WHERE
        (
            COALESCE(mu.accountHealth, "") != COALESCE(cs.accountHealth, "") OR
            COALESCE(mu.accountTier, "") != COALESCE(cs.accountTier, "") OR
            COALESCE(mu.accountCSADripBucket, "") != COALESCE(cs.AccountToBeAssigned, "") OR
            COALESCE(mu.accountTerritory, "") != COALESCE(cs.territory, "")
        )
        AND mu.isOrgDomain = 1  -- Ignore ISP domains.
;
SELECT "************************************* temp csaReport rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

UPDATE arc_marketo_upload mu
    JOIN tmp_csaReport cs ON mu.userID = cs.userID
SET
    mu.accountHealth        = cs.accountHealth,
    mu.accountTier          = cs.accountTier,
    mu.accountCSADripBucket = cs.AccountToBeAssigned,
    mu.accountTerritory     = cs.territory,
    mu.pushToMarketo        = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime       = CURRENT_TIMESTAMP()
;
SELECT "************************************* update csaReport rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "MAIN.RPT.csaReport");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "domain and account users");

-- *********************************************************************************************************************
-- Update customer success rep and domain owner info for all leads. The fast version of these queries are in the
-- 5 min script, so this is just for LEFT JOIN cleanup. This runs much slower.
-- (added 2016-07-28)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_sfdc_domain_account_reps;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_reps
(INDEX (Domain_Name_URL__c))
    SELECT
        d.Domain_Name_URL__c,
        csu.Email     csEmail,
        csu.FIRST_NAME csFIRST_NAME,
        csu.LAST_NAME  csLAST_NAME,
        csu.Phone     csPhone,
        dou.Email     doEmail,
        dou.FIRST_NAME doFIRST_NAME,
        dou.LAST_NAME  doLAST_NAME,
        dou.Title     doTitle,
        dou.Phone     doPhone
    FROM SFDC.PUBLIC.domain d
        LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
        LEFT JOIN SFDC.PUBLIC.user csu ON a.Customer_Success__c = csu.Id
        LEFT JOIN SFDC.PUBLIC.user dou
            ON d.OWNER_ID = dou.Id AND dou.ID != '00540000002nu18AAA' # Exclude Andrew Imhoff.
    # Ignore ISP domains. Use MAIN.ARC.ISPDomains instead of isOrgDomain field to avoid join on arc_marketo_upload.
    WHERE d.Domain_Name_URL__c NOT IN (SELECT domain
                                       FROM MAIN.ARC.ISPDomains)
;
SELECT '************************************* sfdc domain and account reps: ', ROW_COUNT(), CURRENT_TIMESTAMP();

DROP TABLE IF EXISTS tmp_sfdc_domain_account_users;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_users
(INDEX (userID))
    SELECT
        mu.userID,
        d.*
    FROM leadflow.arc_marketo_upload mu
        LEFT OUTER JOIN tmp_sfdc_domain_account_reps d ON mu.emailDomain = d.Domain_Name_URL__c
        LEFT OUTER JOIN ss_core_02.organization org ON mu.userID = org.mainContactUserID AND org.state = 1
    WHERE
        (COALESCE(mu.successRepEmail, '') != COALESCE(d.csEmail, '')
         OR COALESCE(mu.successRepFIRST_NAME, '') != COALESCE(d.csFIRST_NAME, '')
         OR COALESCE(mu.successRepLAST_NAME, '') != COALESCE(d.csLAST_NAME, '')
         OR COALESCE(mu.successRepPhoneNumber, '') != COALESCE(d.csPhone, '')
         OR COALESCE(mu.domainOwnerEmail, '') != COALESCE(d.doEmail, '')
         OR COALESCE(mu.domainOwnerFIRST_NAME, '') != COALESCE(d.doFIRST_NAME, '')
         OR COALESCE(mu.domainOwnerLAST_NAME, '') != COALESCE(d.doLAST_NAME, '')
         OR COALESCE(mu.domainOwnerTitle, '') != COALESCE(d.doTitle, '')
         OR COALESCE(mu.domainOwnerPhoneNumber, '') != COALESCE(d.doPhone, ''))
        # Don't want to reintroduce leads who may have been purged.
        AND
        (org.mainContactUserID IS NOT NULL # MKTO3303 include all active org main contacts
         OR mu.productName IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR mu.orgProductName IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR COALESCE(mu.lastLogin, '2000-01-01') >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 180 DAY))  # MKTO3290 include paid, trial, or active in last 180 days
    ORDER BY mu.userID ASC  # Need to order by userID to prevent deadlocks.
;
SELECT '************************************* sfdc domain and account changes: ', ROW_COUNT(), CURRENT_TIMESTAMP();

UPDATE arc_marketo_upload mu
    JOIN tmp_sfdc_domain_account_users d ON mu.userID = d.userID
SET
    mu.successRepEmail        = d.csEmail,
    mu.successRepFIRST_NAME    = d.csFIRST_NAME,
    mu.successRepLAST_NAME     = d.csLAST_NAME,
    mu.successRepPhoneNumber  = d.csPhone,
    mu.domainOwnerEmail       = d.doEmail,
    mu.domainOwnerFIRST_NAME   = d.doFIRST_NAME,
    mu.domainOwnerLAST_NAME    = d.doLAST_NAME,
    mu.domainOwnerTitle       = d.doTitle,
    mu.domainOwnerPhoneNumber = d.doPhone,
    mu.pushToMarketo          = GREATEST(@highestNightlyUpdatePriority, mu.pushToMarketo),
    mu.updateDateTime         = CURRENT_TIMESTAMP()
;
SELECT '************************************* sfdc domain and account rows: ', ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "domain and account users");

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "tmp_app_behavior_score_leads leads");

###########################################################################################################################
# Get list of leads that should get updated app behavior scores
###########################################################################################################################
DROP TABLE IF EXISTS tmp_app_behavior_score_leads;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_app_behavior_score_leads
(
    PRIMARY KEY (userID)
)
    SELECT DISTINCT userID
    FROM leadflow.arc_marketo_upload_journal
    WHERE
        journalDateTime >= @marketoNightlyStartDateTime
        AND pushToMarketo >= @mediumNightlyUpdatePriority;
SELECT "************************************* tmp_app_behavior_score_leads rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "tmp_app_behavior_score_leads leads");

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "appBehaviorScoreNew reset");

-- *************************************************************************************************************************
-- Update app behavior scores
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
    JOIN tmp_app_behavior_score_leads tmp ON mu.userID = tmp.userID
SET mu.appBehaviorScoreNew =
    # cap the existing app score at 100 by subtracting 100 if over 100 else 0 to allow all the existing score through
    CASE
        WHEN
            mu.appBehaviorScoreNew IS NULL AND
            mu.wasSharedToPriorToTrial = 1 AND
            getAppBehaviorScoreV1(mu.loginCount, mu.eventLogCount, mu.sheetCount, mu.sharingCount, mu.reportCount, mu.teamTrial, mu.accountRole) > 100
            THEN getAppBehaviorScoreV1(mu.loginCount, mu.eventLogCount, mu.sheetCount, mu.sharingCount, mu.reportCount, mu.teamTrial, mu.accountRole) - 100
        ELSE mu.appBehaviorScoreNew
    END
;
SELECT "************************************* appBehaviorScoreNew existing score resetting rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "appBehaviorScoreNew reset");


-- *************************************************************************************************************************
-- Lock debugging
-- *************************************************************************************************************************
-- SELECT COUNT(*), information_schema.tokudb_locks.*, pl.* FROM information_schema.tokudb_locks
-- JOIN information_schema.PROCESSLIST pl ON pl.ID = locks_mysql_thread_id
-- WHERE locks_table_schema != "rpt_workspace"
-- GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
-- ;
-- SELECT "************************************* lock debugging : ", ROW_COUNT(), CURRENT_TIMESTAMP();


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "appBehaviorScoreNew/Old");

-- *************************************************************************************************************************
-- Update app behavior scores
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
    JOIN tmp_app_behavior_score_leads tmp on mu.userID = tmp.userID
SET
    mu.appBehaviorScoreOld = COALESCE(mu.appBehaviorScoreNew, 0),
    mu.appBehaviorScoreNew = getAppBehaviorScoreV1(mu.loginCount, mu.eventLogCount, mu.sheetCount, mu.sharingCount, mu.reportCount, mu.teamTrial, mu.accountRole)
;
SELECT "************************************* appBehaviorScoreOld and New rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "appBehaviorScoreNew/Old");

SHOW PROCESSLIST;

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "appBehaviorScore");

UPDATE arc_marketo_upload mu
    JOIN tmp_app_behavior_score_leads tmp ON mu.userID = tmp.userID
SET
    mu.appBehaviorScore = COALESCE(mu.appBehaviorScoreNew, 0) - COALESCE(mu.appBehaviorScoreOld, 0),
    mu.pushToMarketo    = GREATEST(@mediumHighNightlyUpdatePriority, mu.pushToMarketo), -- bump up priority for lead scoring
    mu.updateDateTime   = CURRENT_TIMESTAMP()
WHERE
    -- only push changes for leads that are still candidates for initial sales outreach
    -- which is in a trial or within 14 days after their trial expired
    (mu.productName = ('Trial') OR (mu.productName = ('Free') AND mu.trialEndDateDateTime > DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 14 DAY)))
;
SELECT "************************************* appBehaviorScore rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "appBehaviorScore");


SHOW PROCESSLIST;

CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "leadflow.arc_marketo_upload_sync_history");

-- *************************************************************************************************************************
-- Log curent sync queue
-- *************************************************************************************************************************
INSERT INTO leadflow.arc_marketo_upload_sync_history
SELECT CURRENT_TIMESTAMP(), "marketo_nightly_update.sql", muf.priority, COUNT(mu.userID)
FROM leadflow.arc_marketo_upload_flags muf
LEFT OUTER JOIN leadflow.arc_marketo_upload mu ON muf.priority = mu.pushToMarketo
WHERE muf.priority != 0
GROUP BY muf.priority
ORDER BY muf.priority DESC
;
SELECT "************************************* updating sync queue history rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "leadflow.arc_marketo_upload_sync_history");


CALL leadflow.SMARTSHEET_START_LOG("Marketo Nightly", "net promoter score users");

-- *************************************************************************************************************************
-- Capture any new Net Promoter Score data
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_net_promoter_score_users;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_net_promoter_score_users
    SELECT
        allnps.Email,
        allnps.userID__c,
        allnps.Net_Promoter_Score__c,
        allnps.Net_Promoter_Score_Reason__c,
        mu.productName,
        mu.successRepEmail,
        mu.accountHealth,
        mu.accountTier,
        mu.persona,
        mu.organizationRoles,
        MAX(allnps.LastModifiedDate)
    FROM (
             SELECT
                 Email,
                 userID__c,
                 LastModifiedDate,
                 Net_Promoter_Score__c,
                 Net_Promoter_Score_Reason__c
             FROM SFDC.PUBLIC.lead
             WHERE
                 NOT (COALESCE(Net_Promoter_Score__c, 0) = 0
                      AND COALESCE(Net_Promoter_Score_Reason__c, '') = '')
             UNION ALL
             SELECT
                 Email,
                 userID__c,
                 LastModifiedDate,
                 Net_Promoter_Score__c,
                 Net_Promoter_Score_Reason__c
             FROM SFDC.PUBLIC.contact
             WHERE
                 NOT (COALESCE(Net_Promoter_Score__c, 0) = 0
                      AND COALESCE(Net_Promoter_Score_Reason__c, '') = '')
         ) allnps
        LEFT JOIN leadflow.arc_marketo_upload mu ON allnps.userID__c = mu.userID
    GROUP BY allnps.Email
;
SELECT "************************************* net promoter score user rows: ", ROW_COUNT(), CURRENT_TIMESTAMP();

INSERT IGNORE INTO leadflow.arc_marketo_lead_nps
(emailAddress, userID, netPromoterScore, netPromoterScoreReason, productName, successRepEmail, accountHealth, accountTier, persona, organizationRoles)
    SELECT
        Email,
        userID__c,
        Net_Promoter_Score__c,
        Net_Promoter_Score_Reason__c,
        productName,
        successRepEmail,
        accountHealth,
        accountTier,
        persona,
        organizationRoles
    FROM tmp_net_promoter_score_users nps
;
SELECT "************************************* net promoter score user inserts: ", ROW_COUNT(), CURRENT_TIMESTAMP();

CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "net promoter score users");


-- *************************************************************************************************************************
-- Debug
-- *************************************************************************************************************************



CALL rpt_main_02.utl_logProcessEnd(@v_processId);
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Nightly", "Total");
