-- **************************************************************************************************************************
-- This is running every 5 minutes, so it has to run super fast...
-- **************************************************************************************************************************
--  --SET $@sql_mode = '';

SET window_start_date_time = (SELECT IFNULL(MAX(LAST_BATCH_DATE_TIME), '2018-01-01') FROM LEADFLOW.PUBLIC.BATCH)
;
SET window_end_date_time = DATEADD(MINUTE, 5, $window_start_date_time)
;

use database LEADFLOW_DD;

SELECT CURRENT_DATABASE();

-- debug
--SHOW VARIABLES LIKE 'tx_isolation';
-- prevent us from locking any tables in core that might slow/stop replication
--SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- debug - test longer wait timeout
SET tokudb_lock_timeout = 300000;

-- debug
--SHOW VARIABLES LIKE 'tx_isolation';

SELECT '************************************* start: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
-- Determine and save where we left off last time...
UPDATE arc.marketo_upload_control SET active = 0 WHERE active = 1;

SELECT '************************************* reset arc.marketo_upload_control active rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

INSERT INTO arc.marketo_upload_control(
max_amu_insert_Date_Time,
max_amu_update_Date_Time,
max_amu_ua_Id,
max_amu_ua_Modify_Date_Time,
max_amu_pp_Id,
max_amu_pp_Modify_Date_Time,
max_amu_Trial_Start_Date_Time,
max_sscore_ua_Id,
max_sscore_ua_Modify_Date_Time,
max_sscore_ua_Insert_Date_Time,
max_sscore_pp_Id,
max_sscore_pp_Modify_Date_Time,
max_sscore_pp_Insert_Date_Time,
max_sscore_sl_Session_Log_ID
)
SELECT *
FROM 
(SELECT MAX(insert_Date_Time)::TIMESTAMP_NTZ AS max_amu_insert_Date_Time
      ,MAX(update_Date_Time)::TIMESTAMP_NTZ AS max_amu_update_Date_Time
      ,MAX(user_Id) AS max_amu_ua_Id
      ,MAX(user_Account_Modify_Date_Time)::TIMESTAMP_NTZ AS max_amu_ua_Modify_Date_Time
      ,MAX(payment_Profile_Id) AS max_amu_pp_Id
      ,MAX(pp_Modify_Date_Time)::TIMESTAMP_NTZ AS max_amu_pp_Modify_Date_Time
      ,MAX(trial_Start_Date_Time)::TIMESTAMP_NTZ AS max_amu_Trial_Start_Date_Time
FROM arc.marketo_upload
) amu
INNER JOIN
(SELECT MAX(user_Id) AS max_sscore_ua_Id
      ,MAX(modify_Date_Time)::TIMESTAMP_NTZ AS max_sscore_ua_Modify_Date_Time
      ,MAX(insert_Date_Time)::TIMESTAMP_NTZ AS max_sscore_ua_Insert_Date_Time
FROM CORE.PUBLIC.user_Account
) ua 
INNER JOIN
(SELECT MAX(payment_Profile_Id) AS max_sscore_pp_Id
      ,MAX(modify_Date_Time)::TIMESTAMP_NTZ AS max_sscore_pp_Modify_Date_Time
      ,MAX(insert_Date_Time)::TIMESTAMP_NTZ AS max_sscore_pp_Insert_Date_Time
FROM CORE.PUBLIC.payment_Profile
) pp
INNER JOIN
(SELECT MAX(session_Log_ID) AS max_sscore_sl_Session_Log_ID
FROM CORE.PUBLIC.session_Log
) sl;

SELECT '************************************* INSERT INTO arc.marketo_upload_control rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

UPDATE arc.marketo_upload_control SET active = 1 WHERE active IS NULL;  -- Temporary hack by DARREN!

SELECT * FROM arc.marketo_upload_control WHERE active = 1;

SET (
      max_amu_ua_Modify_Date_Time
     ,max_amu_pp_Modify_Date_Time
     ,max_amu_Trial_Start_Date_Time
     ,max_amu_ua_Id
     ,max_amu_pp_Id
     ,max_sscore_pp_Id
     ,max_sscore_pp_Modify_Date_Time
     ,max_sscore_ua_Id
     ,max_sscore_ua_Modify_Date_Time
     ,max_sscore_sl_Session_Log_ID
    ) = (
      ( SELECT max_amu_ua_Modify_Date_Time FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_amu_pp_Modify_Date_Time FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_amu_Trial_Start_Date_Time FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_amu_ua_Id FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_amu_pp_Id FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_sscore_ua_Id FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_sscore_ua_Modify_Date_Time FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_sscore_pp_Id FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_sscore_pp_Modify_Date_Time FROM arc.marketo_upload_control WHERE active = 1 )
     ,( SELECT max_sscore_sl_Session_Log_ID FROM arc.marketo_upload_control WHERE active = 1 )
    )
;

SET insertPriority = (SELECT  10 ); -- highest priority, gets pushed to marketo first
SET updatePriority = (SELECT  8 ); -- second highest priority

-- Added 2016-03-03
-- Use this variable for all date dependent lookbacks. Now when there are replication
-- issues, we only need to change the INTERVAL in one place.
SET marketoLookbackDateTime = (SELECT  DATEADD(HOUR, -72, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ) );

SET marketoLookbackDateTime_Start = (SELECT  DATEADD(HOUR, -24, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ) );
SET marketoLookbackDateTimeEnd = (SELECT  DATEADD(HOUR, -12, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ) );

SELECT '************************************* MAX(user_Account_Modify_Date_Time), MAX(pp_Modify_Date_Time), last_Trial_Date rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- lock debugging
-- SELECT COUNT(*), information_schema.tokudb_locks.*, pl.* FROM information_schema.tokudb_locks

-- WHERE locks_table_schema != 'WORKSPACE' 
-- GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
-- ;
-- SELECT '************************************* lock debugging : ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


/* REMOVE ABOVE WHEN WE GO TO PRODUCTION   */

-- Stage the leads
-- DROP TABLE IF EXISTS tmp.marketo_leads;
CREATE TABLE IF NOT EXISTS tmp.marketo_leads LIKE arc.marketo_upload;

-- truncate instead of drop and recreate to try to get more consistent query plans
TRUNCATE TABLE tmp.marketo_leads;

-- ANALYZE TABLE tmp.marketo_leads;

-- Insert New trials since last run

INSERT /*IGNORE*/ INTO tmp.marketo_leads
        (
        insert_Source, 
        -- primary key
        user_ID,

        -- syncing mechanism fields
        push_To_Marketo,
        insert_Date_Time,
        -- update_Date_Time,  
        -- upload_Date_Time,
        -- upload_Status,
        user_Account_Modify_Date_Time,
        pp_Modify_Date_Time,
        trial_Modify_Date_Time,

        -- sales force fields -- all set in following section
        -- salesforce_Owner_At_Import,
        -- salesforce_Status,
        -- smartscore_Code,
        -- salesforce_Lead_Source,

        -- userAccount fields
        first_Name,
        last_Name,
        email_Address,
        email_Domain,
        -- is_Org_Domain,
        website,
        news_Flags,
        status_Flags,
        locale,
        time_Zone,
        ABTests,
        -- ip_Country,
        used_Google_Authentication,
        -- is_Google_Apps_Installed_Domain,
        -- domains_Highest_Plan,
        was_Shared_To_Prior_To_Trial,
       -- payment_Profile fields
        payment_Profile_ID,
        parent_Payment_Profile_ID,
        product_Name,
        user_Limit,
        payment_Start_Date_Time,
        next_Payment_Date,
        payment_Term,
        plan_Rate,
        monthly_Plan_Rate_USD,
        currency_Code,
        team_Trial,
        trial_Start_Date_Time,
        trial_End_Date_Date_Time,
        is_Trial_Restart,
        primary_Contact_Phone,
        bill_To_Address,
        bill_To_City,
        bill_To_Region_Code,
        bill_To_Post_Code,
        bill_To_Country_Code,
        signup_Tracking_Keyword,
        signup_Tracking_m_code,
        signup_Tracking_c_code,
        signup_Tracking_s_code,
        marketo_Tracking_Cookie,
        organization_Name,
        account_Role,
        app_Opt_Out,
        container_Count,
        signup_Request_ID
    )
SELECT
        'leadSeed' AS insert_Source,
        -- primary key
        ls.user_ID,

        -- syncing mechanism fields
        $insertPriority, -- push_To_Marketo,  
        CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, -- insert_Date_Time,
        -- update_Date_Time,
        -- upload_Date_Time,
        -- upload_Status,
        ls.user_Account_Modify_Date_Time,
        ls.pp_Modify_Date_Time,
        ls.trial_Modify_Date_Time, -- trial_Modify_Date_Time,

        -- sales force fields   
        -- salesforce_Owner_At_Import,
        -- salesforce_Status,
        -- smartscore_Code,
        -- salesforce_Lead_Source,

        -- userAccount fields
        ls.first_Name,
        ls.last_Name,
        ls.email_Address, -- email_Address,
        ls.email_Domain,
        -- is_Org_Domain,
        ls.email_Domain AS website,
        ls.news_Flags, -- news_Flags,
        ls.status_Flags, -- status_Flags,
        ls.locale,
        ls.time_Zone, -- time_Zone,
        ls.ABTests, 
        -- ip_Country,
        CASE WHEN ls.google_User_ID IS NULL THEN 0 ELSE 1 END AS used_Google_Authentication,
        -- is_Google_Apps_Installed_Domain, 
        -- domains_Highest_Plan,
        -- using payment_Profile insert date time because user could be inserted a second before the access map record
        ls.was_Shared_To_Prior_To_Trial,

        -- payment_Profile fields
        ls.payment_Profile_ID,
        ls.parent_Payment_Profile_ID,
        ls.product_Name,
        ls.user_Limit,
        ls.payment_Start_Date_Time,
        ls.next_Payment_Date,
        ls.payment_Term,
        ls.plan_Rate,
        ls.monthly_Plan_Rate_USD,
        ls.currency_Code,
        ls.team_Trial,
        ls.trial_Start_Date_Time,
        ls.trial_End_Date_Date_Time,   

        ls.is_Trial_Restart,
        ls.primary_Contact_Phone,
        ls.bill_To_Address,
        ls.bill_To_City,
        ls.bill_To_Region_Code,
        ls.bill_To_Post_Code,
        ls.bill_To_Country_Code,

        ls.signup_Tracking_Keyword,
        ls.signup_Tracking_m_code,
        ls.signup_Tracking_c_code,
        ls.signup_Tracking_s_code,
        ls.marketo_Tracking_Cookie,
        ls.organization_Name,
        ls.account_Role,
        BITNOT(BITAND(ls.news_Flags, 1)), -- app_Opt_Out
        ls.container_Count,
        ls.signup_Request_ID
  FROM PUBLIC.LEAD_SEED ls
 WHERE ls.account_Type != 3
   AND ls.payment_Profile_Id > $max_amu_pp_Id
   AND ls.pp_Insert_Date_Time <= DATEADD(MINUTE, -1440, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
   AND ls.insert_Date_Time > $window_start_date_time
   AND ls.insert_Date_Time <= $window_end_date_time
   AND NOT EXISTS (
       SELECT 1
         FROM tmp.marketo_leads ml
        WHERE ml.user_ID = ls.user_ID
       )
;
SELECT '************************************* tmp.marketo_leads - trials rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT COUNT(*) FROM tmp.marketo_leads;

SELECT $max_amu_pp_Id;  -- record the where clause boundry above




-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------
-- toddj - 3/4/2015 - code to catch updated payment profiles not just inserted ones


-- *********************************************************************************************************************
-- find and include the current leads in trial
-- *********************************************************************************************************************
MERGE INTO tmp.marketo_leads T
  USING (
    SELECT
        'insight-trial' AS insert_Source,
        hpp.owner_ID     AS user_ID,
        hpp.payment_Profile_ID,
        CASE WHEN hppOld.product_ID IS NULL
            THEN 0
        ELSE 1 END      AS is_Trial_Restart,
        --  First time is a trial in which the user did not previously have a payment Profile
        hpp.modify_Date_Time AS trial_Modify_Date_Time
    FROM CORE.hist.payment_Profile hpp
        --  Compare to previous hist_payment_Profile entry
        LEFT OUTER JOIN CORE.hist.payment_Profile hppOld
            ON hpp.payment_Profile_ID = hppOld.payment_Profile_ID
               --  This accounts for 1 second delays in the hist_effective_Thru_Date_Time
               AND (hpp.modify_Date_Time = DATEADD(SECOND, 1, hppOld.hist_effective_Thru_Date_Time)
                    OR hpp.modify_Date_Time = hppOld.hist_effective_Thru_Date_Time)
               --  This will ignore previous records that were trials
               AND (hppOld.product_ID != 1 OR hppOld.product_ID IS NULL)
    WHERE hpp.product_ID = 1 --  in trial
          AND (hpp.modify_Date_Time != hpp.hist_effective_Thru_Date_Time OR hpp.modify_Date_Time != DATEADD(SECOND, -1, hpp.hist_effective_Thru_Date_Time)) --  Ignore zero or negative second trials.
--          AND hpp.modify_Date_Time >= $marketoLookbackDateTime --  replication may be behind so look back extra
          AND hpp.modify_Date_Time > $window_start_date_time
          AND hpp.modify_Date_Time <= $window_end_date_time
          AND hpp.account_Type != 3 --  don't include org trials
          AND hpp.hist_effective_Thru_Date_Time >= '9999-12-31'
          AND NOT EXISTS (
              SELECT 1
                FROM arc.marketo_upload mu
               WHERE mu.user_ID = hpp.owner_ID
              )
    ORDER BY hpp.modify_Date_Time DESC --  newest first
  ) S
    ON S.user_ID = T.user_ID
  WHEN NOT MATCHED THEN INSERT (
         insert_Source,
         user_ID,
         payment_Profile_ID,
         is_Trial_Restart,
         trial_Modify_Date_Time
       )
       VALUES (
         S.insert_Source,
         S.user_ID,
         S.payment_Profile_ID,
         S.is_Trial_Restart,
         S.trial_Modify_Date_Time
       )
  WHEN MATCHED THEN UPDATE SET
         insert_Source = S.insert_Source,
         payment_Profile_ID = S.payment_Profile_ID,
         is_Trial_Restart = S.is_Trial_Restart,
         trial_Modify_Date_Time = S.trial_Modify_Date_Time
;
SELECT '************************************* new tmp.marketo_leads - insight-trial rows: ', (SELECT "number of rows inserted" + "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT COUNT(*) FROM tmp.marketo_leads;


-- *********************************************************************************************************************
-- find and include the current customers with a basic or higher plan (including student)
-- *********************************************************************************************************************
MERGE INTO tmp.marketo_leads T
  USING (
    SELECT  
        'insight-customer' AS insert_Source,
      pp.owner_ID AS user_ID,                                       
      pp.payment_Profile_ID AS payment_Profile_ID,                                      
      0 AS is_Trial_Restart, 
      NULL AS trial_Modify_Date_Time
    FROM CORE.hist.payment_Profile pp 
    LEFT OUTER JOIN arc.marketo_upload mu ON mu.payment_Profile_ID = pp.payment_Profile_ID
    WHERE pp.modify_Date_Time > $window_start_date_time
      AND pp.modify_Date_Time <= $window_end_date_time
--(pp.modify_Date_Time >= $marketoLookbackDateTime) -- replication may be behind so look back extra
      AND pp.hist_effective_Thru_Date_Time >= '9999-12-31'
      AND pp.product_ID >= 3        -- basic or higher (paid product plus student)
      AND pp.account_Type != 3      -- not an org account_Type
      AND pp.owner_ID >= 1000000    -- the starting range of the real records
      AND mu.payment_Profile_ID IS NULL  -- doesn't already exist in the upload table
  ) S
  ON S.user_ID = T.user_ID
  WHEN NOT MATCHED THEN INSERT (
         insert_Source,
         user_ID,
         payment_Profile_ID,
         is_Trial_Restart,
         trial_Modify_Date_Time
       )
       VALUES (
         S.insert_Source,
         S.user_ID,
         S.payment_Profile_ID,
         S.is_Trial_Restart,
         S.trial_Modify_Date_Time
       )
  WHEN MATCHED THEN UPDATE SET
         insert_Source = S.insert_Source,
         payment_Profile_ID = S.payment_Profile_ID,
         is_Trial_Restart = S.is_Trial_Restart,
         trial_Modify_Date_Time = S.trial_Modify_Date_Time
;
SELECT '************************************* tmp.marketo_leads - paying customers from hist_payment_Profile rows: ', (SELECT "number of rows inserted" + "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT COUNT(*) FROM tmp.marketo_leads;




-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------
-- twj - new processing of all users without payment profiles

-- *********************************************************************************************************************
-- Updated 2016-01-12
-- Inserting all other new users from userAccount
-- Includes a 24 hour pad in case replication is having issues
-- *********************************************************************************************************************
INSERT /*IGNORE*/ INTO tmp.marketo_leads
(
    insert_Source,
    user_ID,
    payment_Profile_ID,
    is_Trial_Restart,
    trial_Modify_Date_Time
)
SELECT
    'insight-user' AS insert_Source,
    ua.user_ID,
    pp.payment_Profile_ID,
    0 AS is_Trial_Restart,
    NULL AS trial_Modify_Date_Time
FROM CORE.PUBLIC.user_Account ua
LEFT OUTER JOIN CORE.PUBLIC.payment_Profile pp ON ua.user_ID = pp.owner_ID AND pp.account_Type != 3
LEFT OUTER JOIN arc.marketo_upload mu ON ua.user_ID = mu.user_ID
WHERE ua.insert_Date_Time > $window_start_date_time
  AND ua.insert_Date_Time <= $window_end_date_time
--  AND  ua.insert_Date_Time >= $marketoLookbackDateTime
  AND  mu.user_ID IS NULL
   AND NOT EXISTS (
       SELECT 1
         FROM tmp.marketo_leads X
        WHERE X.user_ID = ua.user_ID
       )
;
SELECT '************************************* tmp.marketo_leads - inserting insight-user rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- Added 2016-12-29
-- Prevent low-value leads from getting into Marketo. These are users who have:
--   1. Never logged in
--   2. Been inserted by a different user from a free plan (Cancelled, Trial, Free, Student)
-- This should also help with preventing phished users from clogging up the Marketo database
-- *********************************************************************************************************************
DELETE FROM tmp.marketo_leads tmlx
 USING (
   SELECT DISTINCT
          tml.user_ID
     FROM tmp.marketo_leads tml
          JOIN CORE.PUBLIC.user_Account ua
            ON ua.user_ID = tml.user_ID
           AND ua.insert_By_User_ID != 0
          LEFT JOIN CORE.PUBLIC.payment_Profile pp
            ON pp.owner_ID = ua.insert_By_User_ID
           AND pp.account_Type != 3
          LEFT JOIN CORE.PUBLIC.session_Log sl
            ON sl.user_ID = tml.user_ID
           AND sl.login_Type NOT IN (11, 34)
           AND sl.login_Auth_Result = 1
    WHERE COALESCE(pp.product_ID, 0) IN (0, 1, 2, 9)    -- Free plans, including Student. Use coalesce to treat collab (no PP) as free plan.
      AND sl.session_Log_ID IS NULL     -- Never logged in
 ) x
 WHERE tmlx.user_ID = x.user_ID
;

SELECT '************************************* tmp.marketo_leads - deleting low-value user rows: ', (SELECT "number of rows deleted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- Added 2015-12-30
-- Inserting users who have logged in recently but are not in the upload table already
-- This backfills active collaborators
-- *********************************************************************************************************************
INSERT /*IGNORE*/ INTO tmp.marketo_leads (
  insert_Source
 ,user_ID
 ,payment_Profile_ID
 ,is_Trial_Restart
 ,trial_Modify_Date_Time
)
SELECT 'insight-active' AS insert_Source
      ,ua.user_ID
      ,MAX(pp.payment_Profile_ID) AS payment_Profile_ID
      ,0 AS is_Trial_Restart
      ,NULL AS trial_Modify_Date_Time
  FROM CORE.PUBLIC.user_Account ua
       LEFT OUTER JOIN CORE.PUBLIC.payment_Profile pp
         ON pp.owner_ID = ua.user_ID
        AND pp.account_Type != 3
       LEFT OUTER JOIN CORE.PUBLIC.session_Log sl
         ON sl.user_ID = ua.user_ID
        AND sl.login_Auth_Result = 1
        AND sl.login_Type != 11 -- Include successful logins but exclude 'Update Request' logins.
 WHERE ua.user_ID >= 1000001  -- first valid user_ID
   AND sl.session_Log_ID >= ($max_sscore_sl_Session_Log_ID - 4000000)  -- This looks back approximately 24 hours
   AND sl.insert_Date_Time > $window_start_date_time
   AND sl.insert_Date_Time <= $window_end_date_time
   AND NOT EXISTS (
         SELECT 1
           FROM LEADFLOW.arc.marketo_upload mu
          WHERE mu.user_ID = ua.user_ID
       )
   AND NOT EXISTS (
         SELECT 1
           FROM tmp.marketo_leads ml
          WHERE ml.user_ID = ua.user_ID
       )
 GROUP BY ua.user_ID
;
SELECT '************************************* tmp.marketo_leads - inserting insight-active rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Inserting into tmp.marketo_leads all users already in arc.marketo_upload w/o a payment_Profile_ID that now have one
INSERT /*IGNORE*/ INTO tmp.marketo_leads 
SELECT mk_upload.* 
FROM arc.marketo_upload mk_upload 
JOIN CORE.PUBLIC.payment_Profile pp
  ON mk_upload.user_ID = pp.owner_ID
 AND pp.account_Type != 3
  AND pp.modify_Date_Time > $window_start_date_time
  AND pp.modify_Date_Time <= $window_end_date_time
-- AND (pp.modify_Date_Time >= $marketoLookbackDateTime) -- replication may be behind so look back extra
WHERE mk_upload.payment_Profile_ID IS NULL
   AND NOT EXISTS (
       SELECT 1
         FROM tmp.marketo_leads X
        WHERE X.user_ID = mk_upload.user_ID
       )
;
SELECT '************************************* tmp.marketo_leads - inserting -newPP rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


--  *********************************************************************************************************************
--  Added 2017-06-01
--  Remove leads that come from temporary email address domains. We never want these in Marketo.
--  However, if the user changes their email to a permanent one, they will come in with their next login.
--  This is hardcoded for now, but will be developed properly in Yoda.
--  See MKTO4285 for details.
--  *********************************************************************************************************************
DELETE FROM tmp.marketo_leads tml
 USING CORE.PUBLIC.user_Account ua
       JOIN MAIN.arc.domain_Black_List bl
         ON bl.domain = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address)
 WHERE tml.user_ID = ua.user_ID
;
SELECT '************************************* tmp.marketo_leads - deleting temporary email user rows: ', (SELECT "number of rows deleted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;



-- debug OLD
-- --SHOW VARIABLES LIKE 'tx_isolation'
-- ;
-- EXPLAIN UPDATE tmp.marketo_leads tml

-- SET tml.payment_Profile_ID = pp.payment_Profile_ID,
--  tml.insert_Source = CONCAT(tml.insert_Source, '-newPP') 
-- WHERE tml.payment_Profile_ID IS NULL
-- ;
-- SHOW FULL PROCESSLIST
-- ;

-- fill in new payment profile information
-- *********************************************************************************************************************
-- BEGIN hist_payment_Profile updates for LEADFLOW.arc.marketo_upload (updated 2015-10-27)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to tmp.marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query--1: Retrieve changes made to hist_payment_Profile records
DROP TABLE IF EXISTS tmp.hist_payment_Profile_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.hist_payment_Profile_to_sync
/*(INDEX (owner_ID))*/ AS
    SELECT pp.owner_ID, pp.payment_Profile_ID FROM tmp.marketo_leads tml
    JOIN LEADFLOW.arc.marketo_upload mu ON tml.user_ID = mu.user_ID  -- 2015-11-12 FIX: Need to join mu in order for the WHERE clause to be effective
    JOIN CORE.PUBLIC.payment_Profile pp
    ON tml.user_ID = pp.owner_ID
   AND pp.account_Type != 3
--   AND (pp.modify_Date_Time >= $marketoLookbackDateTime) -- replication may be behind so look back extra
   AND pp.modify_Date_Time > $window_start_date_time
   AND pp.modify_Date_Time <= $window_end_date_time
    WHERE mu.payment_Profile_ID IS NULL
;
SELECT '************************************* tmp.marketo_leads - getting -newPP rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update tmp.marketo_leads with changes that will be added to arc.marketo_upload later

UPDATE tmp.marketo_leads tml
SET tml.payment_Profile_ID = pp.payment_Profile_ID,
    tml.insert_Source = CONCAT(tml.insert_Source, '-newPP')

FROM tmp.hist_payment_Profile_to_sync pp

WHERE  tml.user_ID = pp.owner_ID
;
SELECT '************************************* tmp.marketo_leads - updating -newPP rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- FINISH hist_payment_Profile updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************



-- Set Signup ID
-- 2016-12-21 - Moved up in the script as it is neede for amplified trial signup
UPDATE tmp.marketo_leads tml
   SET signup_Request_ID = srx.signup_Request_ID
  FROM (
         SELECT user_ID
               ,signup_Request_ID
           FROM (
                  SELECT sr.user_ID
                        ,sr.signup_Request_ID
                        ,ROW_NUMBER() OVER (PARTITION BY sr.user_ID ORDER BY sr.result_Status, sr.signup_Request_ID ASC) AS SeqNum
                    FROM ACCOUNT.PUBLIC.signup_Request sr /*USE INDEX(signupRequest_idx1)*/
                )
          WHERE SeqNum = 1
       ) srx
 WHERE tml.insert_Source != 'leadSeed'
   AND srx.user_ID = tml.user_ID
;
SELECT '************************************* signup_Request_ID rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- 2016-12-21 - Create temporary table of all new lead signup request info
-- so we don't have to touch the core table multiple times
DROP TABLE IF EXISTS tmp.new_lead_signup_info;
CREATE TABLE IF NOT EXISTS tmp.new_lead_signup_info LIKE ACCOUNT.PUBLIC.signup_Request_Tracking_Item;
INSERT INTO tmp.new_lead_signup_info
    SELECT sr.*
    FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item sr
        JOIN LEADFLOW.tmp.marketo_leads tml ON sr.signup_Request_ID = tml.signup_Request_ID
;

-- ANALYZE TABLE tmp.new_lead_signup_info;

-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------

-- *********************************************************************************************************************
-- BEGIN userAccount updates for LEADFLOW.arc.marketo_upload (updated 2015-12-03)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to tmp.marketo_leads and execute updates
-- *********************************************************************************************************************
-- Query--1: Retrieve userAccount records
DROP TABLE IF EXISTS tmp.userAccount_info_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.userAccount_info_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT
        tml.user_ID,
        ua.modify_Date_Time,
        ua.first_Name,
        ua.last_Name,
        ua.email_Address,
        ua.news_Flags,
        ua.status_Flags,
        ua.locale,
        ua.time_Zone,
        ua.insert_By_User_ID
    FROM tmp.marketo_leads tml
        LEFT OUTER JOIN CORE.PUBLIC.user_Account ua ON tml.user_ID = ua.user_ID
    WHERE tml.insert_Source != 'leadSeed'
;
SELECT '************************************* temp tmp.marketo_leads - updating userAccount info: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update tmp.marketo_leads with changes that will be added to arc.marketo_upload later
-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE tmp.marketo_leads tml
SET
    tml.user_Account_Modify_Date_Time  = uax.modify_Date_Time,
    tml.first_Name                     = uax.first_Name,
    tml.last_Name                      = uax.last_Name,
    tml.email_Address                  = uax.email_Address,
    tml.email_Domain                   = uax.email_Domain,
    tml.website                        = uax.website,
    tml.news_Flags                     = uax.news_Flags,
    tml.status_Flags                   = uax.status_Flags,
    tml.is_User_Agreement_Accepted     = uax.is_User_Agreement_Accepted,
    tml.locale                         = uax.locale,
    tml.time_Zone                      = uax.time_Zone,
    tml.app_Opt_Out                    = uax.app_Opt_Out,
    tml.user_Account_Insert_By_User_ID = uax.insert_By_User_ID
FROM (
       SELECT ua.user_ID,
              ua.modify_Date_Time,
              COALESCE(ua.first_Name, srfn.item_Value) AS first_Name,
              COALESCE(MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name), MAIN.PUBLIC.MARKETO_LAST_NAME(srln.item_Value)) AS last_Name,
              ua.email_Address,
              MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS email_Domain,
              MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS website,
              ua.news_Flags,
              ua.status_Flags,
              IFF(BITAND(ua.status_Flags, 8) = 8, 1, 0) AS is_User_Agreement_Accepted, -- LICENSED_ACCEPTED is 4th bit in status_Flags bitmask, which is 1000 in  (8 in decimal)
              ua.locale,
              ua.time_Zone,
              BITNOT(BITAND(ua.news_Flags, 1)) AS app_Opt_Out,
              ua.insert_By_User_ID
         FROM tmp.marketo_leads tml
              JOIN tmp.userAccount_info_to_sync ua
                ON ua.user_ID = tml.user_ID
              LEFT JOIN tmp.new_lead_signup_info srfn
                ON srfn.signup_Request_ID = tml.signup_Request_ID
               AND srfn.item_Name = 'su_fname'
              LEFT JOIN tmp.new_lead_signup_info srln
                ON srln.signup_Request_ID = tml.signup_Request_ID
               AND srln.item_Name = 'su_lname'
     ) uax
WHERE uax.user_ID = tml.user_ID
;
--UPDATE tmp.marketo_leads tml
--SET
--    tml.user_Account_Modify_Date_Time  = ua.modify_Date_Time,
--    tml.first_Name                     = COALESCE(ua.first_Name, srfn.item_Value) AS first_Name,
--    tml.last_Name                      = COALESCE(MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name), MAIN.PUBLIC.MARKETO_LAST_NAME(srln.item_Value)) AS last_Name,
--    tml.email_Address                  = ua.email_Address,
--    tml.email_Domain                   = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS email_Domain,
--    tml.website                        = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS website,
--    tml.news_Flags                     = ua.news_Flags,
--    tml.status_Flags                   = ua.status_Flags,
--    tml.is_User_Agreement_Accepted     = IFF(BITAND(ua.status_Flags, 8) = 8, 1, 0) AS is_User_Agreement_Accepted,
--    tml.locale                         = ua.locale,
--    tml.time_Zone                      = ua.time_Zone,
--    tml.app_Opt_Out                    = BITNOT(BITAND(ua.news_Flags, 1)) AS app_Opt_Out,
--    tml.user_Account_Insert_By_User_ID = ua.insert_By_User_ID
-- FROM tmp.userAccount_info_to_sync ua
--      LEFT JOIN tmp.new_lead_signup_info srfn
--        ON srfn.signup_Request_ID = tml.signup_Request_ID
--       AND srfn.item_Name = 'su_fname'
--      LEFT JOIN tmp.new_lead_signup_info srln
--        ON srln.signup_Request_ID = tml.signup_Request_ID
--       AND srln.item_Name = 'su_lname'
-- WHERE ua.user_ID = tml.user_ID

-- ORIGINAL
-- UPDATE tmp.marketo_leads tml

-- SET
--     tml.user_Account_Modify_Date_Time = ua.modify_Date_Time,
--     tml.first_Name = ua.first_Name,
--     tml.last_Name = MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name),
--     tml.email_Address = ua.email_Address,
--     tml.email_Domain = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address),
--     tml.website = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address),
--     tml.news_Flags = ua.news_Flags,
--     tml.status_Flags = ua.status_Flags,
--     tml.is_User_Agreement_Accepted = CASE WHEN ua.status_Flags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in status_Flags bitmask, which is 1000 in  (8 in decimal)
--     tml.locale = ua.locale,
--     tml.time_Zone = ua.time_Zone,
--     tml.app_Opt_Out = NOT(ua.news_Flags & 1),
--     tml.user_Account_Insert_By_User_ID = ua.insert_By_User_ID
-- ;
SELECT '************************************* update tmp.marketo_leads - updating userAccount info: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- FINISH userAccount updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp.first_shared;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.first_shared
/*(INDEX (user_ID))*/ AS
    SELECT
        grid_Access_Map.user_ID,
        MIN(grid_Access_Map.insert_Date_Time) AS first_Shared_To_Date
    FROM CORE.PUBLIC.grid_Access_Map
        -- need to join back to tmp.marketo_leads table so we don't process the whole gridAccessMap table each time
        JOIN tmp.marketo_leads ON marketo_leads.user_ID = grid_Access_Map.user_ID
    WHERE grid_Access_Map.user_ID <> grid_Access_Map.insert_By_User_ID
    GROUP BY grid_Access_Map.user_ID
;

-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE tmp.marketo_leads tml
   SET pp_modify_Date_time          = x.modify_Date_time,
       parent_Payment_Profile_ID    = x.parent_Payment_Profile_ID,
       product_Name                 = x.product_Name,
       user_Limit                   = x.user_Limit,
       payment_Start_Date_Time      = x.payment_Start_Date_Time,
       next_Payment_Date            = x.next_Payment_Date,
       payment_Type                 = x.payment_Type,
       payment_Term                 = x.payment_Term,
       currency_Code                = x.currency_Code,
       team_Trial                   = x.team_Trial,
       trial_Start_Date_Time        = x.trial_Start_Date_Time,
       primary_Contact_Phone        = x.primary_Contact_Phone,
       bill_To_Address              = x.bill_To_Address,
       bill_To_City                 = x.bill_To_City,
       bill_To_Region_Code          = x.bill_To_Region_Code,
       bill_To_Post_Code            = x.bill_To_Post_Code,
       bill_To_Country_Code         = x.bill_To_Country_Code,
       was_Shared_To_Prior_To_Trial = x.was_Shared_To_Prior_To_Trial
  FROM (
         SELECT 
             tml2.user_ID,
             pp.modify_Date_time,
             pp.parent_Payment_Profile_ID,
             MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(pp.product_ID) AS product_Name,
             pp.user_Limit,
             pp.payment_Start_Date_Time,
             pp.next_Payment_Date,
             LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type) AS payment_Type,
             pp.payment_Term,
             pp.currency_Code,
             CASE WHEN pp.account_Type = 2 AND pp.product_ID = 1 THEN 1 ELSE 0 END AS team_Trial,
             CASE
                 WHEN pp.product_ID = 1 THEN pp.payment_Start_Date_Time -- 1=in trial
                 ELSE NULL
             END AS trial_Start_Date_Time,
             COALESCE(pp.primary_Contact_Phone, sr.item_Value) AS primary_Contact_Phone, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(pp.bill_To_Address1, pp.bill_To_Address2) AS bill_To_Address, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             pp.bill_To_City, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             pp.bill_To_Region_Code, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             pp.bill_To_Post_Code, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             pp.bill_To_Country_Code, -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
             --  only set true if in trial now
             CASE WHEN pp.product_ID = 1 AND pp.insert_Date_Time >= gam.first_Shared_To_Date THEN 1 ELSE 0 END AS was_Shared_To_Prior_To_Trial
           FROM tmp.marketo_leads tml2
                LEFT OUTER JOIN CORE.PUBLIC.payment_Profile pp ON tml2.payment_Profile_ID = pp.payment_Profile_ID
                LEFT OUTER JOIN tmp.first_shared gam ON tml2.user_ID = gam.user_ID
--              LEFT OUTER JOIN
--              (
--                  SELECT
--                      grid_Access_Map.user_ID,
--                      MIN(grid_Access_Map.insert_Date_Time) AS first_Shared_To_Date
--                  FROM CORE.PUBLIC.grid_Access_Map
--                      -- need to join back to tmp.marketo_leads table so we don't process the whole gridAccessMap table each time
          
--                  WHERE grid_Access_Map.user_ID <> grid_Access_Map.insert_By_User_ID
--                  GROUP BY user_ID
--              ) gam
--                  ON gam.user_Id = tml.user_Id
                LEFT OUTER JOIN tmp.new_lead_signup_info sr ON tml2.signup_Request_ID = sr.signup_Request_ID AND sr.item_Name = 'su_phone'
          WHERE insert_Source != 'leadSeed'
       ) x
 WHERE x.user_ID = tml.user_ID
;
-- ORIGINAL
-- UPDATE tmp.marketo_leads tml
--     LEFT OUTER JOIN CORE.PUBLIC.payment_Profile pp ON tml.payment_Profile_ID = pp.payment_Profile_ID
--     LEFT OUTER JOIN
--     (
--         SELECT
--             grid_Access_Map.user_ID,
--             MIN(grid_Access_Map.insert_Date_Time) AS first_Shared_To_Date
--         FROM CORE.PUBLIC.grid_Access_Map
--             -- need to join back to tmp.marketo_leads table so we don't process the whole gridAccessMap table each time

--         WHERE grid_Access_Map.user_ID <> grid_Access_Map.insert_By_User_ID
--         GROUP BY user_ID
--     ) gam
--         ON gam.user_Id = tml.user_Id
-- SET
--     tml.ppModify_Datetime = pp.modify_Datetime,
--     tml.parent_Payment_Profile_ID = pp.parent_Payment_Profile_ID,
--     tml.product_Name = MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(pp.product_ID),
--     tml.user_Limit = pp.user_Limit,
--     tml.payment_Start_Date_Time = pp.payment_Start_Date_Time,
--     tml.next_Payment_Date = pp.next_Payment_Date,
--     tml.payment_Term = pp.payment_Term,
--     tml.currency_Code = pp.currency_Code,
--     tml.team_Trial = CASE WHEN pp.account_Type = 2 AND pp.product_ID = 1 THEN 1 ELSE 0 END,
--     tml.trial_Start_Date_Time =
--     CASE
--     WHEN pp.product_ID = 1  THEN pp.payment_Start_Date_Time  -- 1=in trial
--     ELSE NULL
--     END,
--     tml.primary_Contact_Phone = pp.primary_Contact_Phone,    -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     tml.bill_To_Address = MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(pp.bill_To_Address1, pp.bill_To_Address2),     -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     tml.bill_To_City = pp.bill_To_City,      -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     tml.bill_To_Region_Code = pp.bill_To_Region_Code,        -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     tml.bill_To_Post_Code = pp.bill_To_Post_Code,        -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     tml.bill_To_Country_Code = pp.bill_To_Country_Code,  -- code handling payment_Profile updates below will pull from from parentPayment_Profiles for owners
--     --  only set true if in trial now 
--     tml.was_Shared_To_Prior_To_Trial = CASE WHEN pp.product_ID = 1 AND  pp.insert_Date_Time >= gam.first_Shared_To_Date THEN 1 ELSE 0 END
-- WHERE insert_Source != 'leadSeed'
-- ;
SELECT '************************************* tmp.marketo_leads - updating payment_Profile info: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- update fields from parent

UPDATE tmp.marketo_leads ml
   SET trial_End_Date_Date_Time       = x.trial_End_Date_Date_Time
      ,parent_Payment_Start_Date_Time = x.parent_Payment_Start_Date_Time
      ,payment_Start_Date_Time        = x.payment_Start_Date_Time
  FROM (
         SELECT ml2.user_ID,
                CASE
                    -- get the end date from the payment_Profile, but it will be null if it is a team trial, if so, get it from the parent
                    WHEN pp.product_ID = 1  THEN COALESCE(pp.payment_End_Date_Time, parentPP.payment_End_Date_Time)  -- 1=in trial,
                    ELSE trial_End_Date_Date_Time                       -- don't over write, this will stay the end date time of last trial
                END AS trial_End_Date_Date_Time,
                parentPP.payment_Start_Date_Time AS parent_Payment_Start_Date_Time,
                CASE
                    WHEN
                        pp.account_Type = 2 AND
                        pp.product_ID = 7 AND
                        pp.payment_Start_Date_Time < parentPP.payment_Start_Date_Time
                    THEN parentPP.payment_Start_Date_Time
                    ELSE ml2.payment_Start_Date_Time
                END AS payment_Start_Date_Time
           FROM tmp.marketo_leads ml2
                JOIN CORE.PUBLIC.payment_Profile pp
                  ON pp.payment_Profile_ID = ml2.payment_Profile_ID
                LEFT OUTER JOIN CORE.PUBLIC.payment_Profile parentPP
                  ON parentPP.payment_Profile_ID = ml2.parent_Payment_Profile_ID
          WHERE ml2.insert_Source != 'leadSeed'
       ) x
 WHERE ml.user_ID = x.user_ID
;
SELECT '************************************* trial_End_Date_Date_Time rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;



UPDATE tmp.marketo_leads
SET  organization_Name = organization.name,
    marketo_leads.organization_ID = organization.organization_ID,
    account_Role = 
        CASE
            WHEN marketo_leads.payment_Profile_ID IS NOT NULL AND parentPP.payment_Profile_ID IS NULL THEN 'Individual'  -- this is the user not part of a multi-user plan
            WHEN marketo_leads.payment_Profile_ID IS NULL AND parentPP.payment_Profile_ID IS NULL THEN NULL  -- this is for users with no payment profile
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID THEN 'Owner'  -- this is the user who created the organization and team trial
            ELSE 'Member'                                                               -- this is the user added to the team trial
        END,
    marketo_leads.plan_Rate =
        CASE 
            WHEN  parentPP.payment_Profile_ID IS NULL THEN marketo_leads.plan_Rate  -- no parent, so keep the existing value
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID THEN parentPP.plan_Rate  -- use the plan_Rate from the org for the owner
            ELSE marketo_leads.plan_Rate                                            -- members don't pay, keep existing value
        END,    
    monthly_Plan_Rate_USD =
        CASE 
            WHEN  parentPP.payment_Profile_ID IS NULL THEN monthly_Plan_Rate_USD  -- no parent, so keep the existing value
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID AND parentPP.payment_Term != 0 THEN  -- use the plan_Rate from the org for the owner
                CASE 
                    WHEN parentPP.currency_Code = 'USD' 
                    THEN parentPP.plan_Rate/parentPP.payment_Term 
                    ELSE (parentPP.plan_Rate/hce.exchange_Rate)/parentPP.payment_Term
                END
            ELSE monthly_Plan_Rate_USD                                      -- members don't pay, keep existing value
        END
FROM CORE.PUBLIC.payment_Profile parentPP
LEFT OUTER JOIN CORE.PUBLIC.organization ON parentPP.owner_ID = organization.organization_ID AND parentPP.account_Type = 3
LEFT OUTER JOIN CORE.hist.currency_Exchange hce ON parentPP.currency_Code = hce.currency_Code
            AND parentPP.payment_Start_Date_Time BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time

WHERE insert_Source != 'leadSeed'

AND  marketo_leads.parent_Payment_Profile_ID = parentPP.payment_Profile_ID
;
SELECT '************************************* organization_Name, account_Role, parent payment values rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE tmp.marketo_leads tml
   SET org_Product_Name = mp.maxOrgProduct
  FROM (
         SELECT mu.user_ID
                -- Triple nested function: 1. Get max product by rank, 2. convert rank back to product_ID, 3. convert product_ID to product name.
               ,MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(
                  MAIN.PUBLIC.SMARTSHEET_PRODUCTRANKCONVERT(
                    MAX(MAIN.PUBLIC.SMARTSHEET_PRODUCTRANK(ppp.product_ID))
                  )
                ) AS maxOrgProduct
           FROM tmp.marketo_leads mu
                LEFT JOIN CORE.PUBLIC.organization_User_Role our
                  ON our.user_ID = mu.user_ID
                 AND our.state != 3              -- Ignore declined users
                LEFT JOIN CORE.PUBLIC.organization org
                  ON org.organization_ID = our.organization_ID
                 AND org.state = 1      -- Include only active orgs
                LEFT JOIN CORE.PUBLIC.payment_Profile ppp
                  ON ppp.owner_ID = our.organization_ID
                 AND ppp.account_Type = 3     -- Just want org accounts
          WHERE mu.insert_Source != 'leadSeed'
          GROUP BY mu.user_ID
       ) mp
 WHERE tml.user_ID = mp.user_ID
;
SELECT '************************************* org_Product_Name rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- Updated 2016-06-23
-- *********************************************************************************************************************
UPDATE tmp.marketo_leads tml
SET
    tml.user_Limit = lic.paid_LicenseLimit,
    tml.bonus_License_Limit = lic.bonus_License_Limit,
    tml.assigned_License_Count = lic.assigned_License_Count,
    tml.pending_License_Count = lic.pending_License_Count
FROM (
    SELECT
        uid.user_ID,
        ANY_VALUE(IFNULL(ppp.user_Limit, 0)) paid_LicenseLimit,
        ANY_VALUE(IFNULL(ppp.bonus_User_Count, 0)) bonus_License_Limit,
        IFNULL(SUM(IFF(our.state = 1, 1, 0)), 0) assigned_License_Count,
        IFNULL(SUM(IFF(our.state = 2, 1, 0)), 0) pending_License_Count
    FROM tmp.marketo_leads tml
    JOIN (
        SELECT our1.user_ID, our1.organization_ID
        FROM CORE.PUBLIC.organization_User_Role our1
        JOIN tmp.marketo_leads tml ON our1.user_ID = tml.user_ID
        WHERE
            our1.role = 'USER_ADMIN'
            AND our1.state = 1
        UNION
        SELECT org.main_Contact_User_ID, org.organization_ID
        FROM CORE.PUBLIC.organization org
        JOIN tmp.marketo_leads tml ON org.main_Contact_User_ID = tml.user_ID
        WHERE org.state = 1
    ) uid ON tml.user_ID = uid.user_ID
    LEFT JOIN CORE.PUBLIC.payment_Profile ppp ON
        uid.organization_ID = ppp.owner_ID
        AND ppp.account_Type = 3
    LEFT JOIN CORE.PUBLIC.organization_User_Role our ON
        uid.organization_ID = our.organization_ID
        AND our.role = 'LICENSE_USER'
        AND our.state IN (1, 2)
    GROUP BY uid.user_ID, uid.organization_ID
) lic
WHERE tml.insert_Source != 'leadSeed'
AND tml.user_ID = lic.user_ID
;
SELECT '************************************* licenseLimit rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update organization license tags
-- Updated 2016-07-05
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp.tml_lic_tag_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.tml_lic_tag_updates
/*(INDEX (user_ID))*/ AS
    SELECT
        lic.user_ID,
        LEADFLOW.PUBLIC.MARKETO_LICENSE_TAG(
          ANY_VALUE(lic.assigned_License_Count)
         ,ANY_VALUE(lic.pending_License_Count)
         ,ANY_VALUE(lic.paid_LicenseLimit)
         ,ANY_VALUE(tml.previous_User_Limit)
         ,COUNT(our.organization_User_Role_ID)
        ) AS license_Tags
    FROM tmp.marketo_leads tml
        JOIN (
                 SELECT
                     our1.user_ID,
                     our1.organization_ID,
                     tml.assigned_License_Count,
                     tml.pending_License_Count,
                     tml.user_Limit paid_LicenseLimit
                 FROM CORE.PUBLIC.organization_User_Role our1
                     JOIN tmp.marketo_leads tml ON our1.user_ID = tml.user_ID
                 WHERE
                     our1.role = 'USER_ADMIN'
                     AND our1.state = 1
                 UNION
                 SELECT
                     org.main_Contact_User_ID,
                     org.organization_ID,
                     tml.assigned_License_Count,
                     tml.pending_License_Count,
                     tml.user_Limit
                 FROM CORE.PUBLIC.organization org
                     JOIN tmp.marketo_leads tml ON org.main_Contact_User_ID = tml.user_ID
                 WHERE org.state = 1
             ) lic ON tml.user_ID = lic.user_ID
        LEFT JOIN CORE.PUBLIC.organization_User_Role our
            ON lic.organization_ID = our.organization_ID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insert_Date_Time >= DATEADD(DAY, -7, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
    GROUP BY lic.user_ID, lic.organization_ID
;
SELECT '************************************* getting licenseTag rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE tmp.marketo_leads tml
SET  tml.license_Tags = tag.license_Tags
FROM tmp.tml_lic_tag_updates tag

WHERE tml.insert_Source != 'leadSeed'

AND  tml.user_ID = tag.user_ID;
SELECT '************************************* updating licenseTag rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update organization roles
-- Added 2017-01-10
-- *********************************************************************************************************************
UPDATE tmp.marketo_leads tml
   SET organization_Roles = orgRole.new_OrgRoles
  FROM (
         SELECT tml.user_ID
               ,COALESCE(ANY_VALUE(our.organization_ID), ANY_VALUE(org.organization_ID)) AS organization_ID
               ,ARRAY_TO_STRING(ARRAY_AGG(DISTINCT our.role) WITHIN GROUP (ORDER BY our.role ASC), ';')
                || ';' || IFF(ANY_VALUE(org.main_Contact_User_ID) IS NOT NULL, 'MAIN_CONTACT', '') AS new_OrgRoles
           FROM tmp.marketo_leads tml
                LEFT JOIN CORE.PUBLIC.organization_User_Role our
                  ON our.user_ID = tml.user_ID
                LEFT JOIN CORE.PUBLIC.organization org
                  ON org.main_Contact_User_ID = tml.user_ID
                 AND org.state = 1
          WHERE COALESCE(our.organization_ID, org.organization_ID) IS NOT NULL
          GROUP BY tml.user_ID
       ) orgRole
WHERE tml.user_ID = orgRole.user_ID
  AND COALESCE(orgRole.organization_ID, 0) != 1030645 -- Exclude GE. Their org roles are updated below.
;
SELECT '************************************* organization_Roles rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

UPDATE tmp.marketo_leads tml
   SET organization_Roles = orgRole.new_OrgRoles
  FROM (
         SELECT our.user_ID
               ,COALESCE(ANY_VALUE(our.organization_ID), ANY_VALUE(org.organization_ID)) AS organization_ID
               ,ARRAY_TO_STRING(ARRAY_AGG(DISTINCT our.role) WITHIN GROUP (ORDER BY our.role ASC), ';')
                || ';' || IFF(ANY_VALUE(org.main_Contact_User_ID) IS NOT NULL, 'MAIN_CONTACT', '')
                || ';' || CONCAT('LICENSE_ADDED_BY:', COALESCE(ANY_VALUE(our2.insert_By_User_ID), 0)) AS new_OrgRoles
           FROM CORE.PUBLIC.organization_User_Role our
                JOIN tmp.marketo_leads tml
                  ON our.user_ID = tml.user_ID
                 AND our.organization_ID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
                LEFT JOIN CORE.PUBLIC.organization_User_Role our2
                  ON our.user_ID = our2.user_ID
                 AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insert_By_User_ID to be specifically from the LICENSE_USER role
                LEFT JOIN CORE.PUBLIC.organization org
                  ON tml.user_ID = org.main_Contact_User_ID
                 AND org.state = 1
          GROUP BY our.user_ID
          ORDER BY our.user_ID ASC
       ) orgRole
 WHERE tml.user_ID = orgRole.user_ID
;
SELECT '************************************* GE organization_Roles rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- BEGIN used_Google_Authentication updates for LEADFLOW.arc.marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to tmp.marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query--1: Retrieve changes made to openIDIdentifier records
DROP TABLE IF EXISTS tmp.openIDIdentifiers_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.openIDIdentifiers_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT goog.user_ID FROM tmp.marketo_leads tml
    LEFT OUTER JOIN CORE.PUBLIC.open_IDIdentifier goog ON tml.user_Id = goog.user_ID
    WHERE insert_Source != 'leadSeed' AND provider IN ('GoogleApps', 'Google_OAuth2')
;
SELECT '************************************* tmp.marketo_leads - getting used_Google_Authentication info: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update tmp.marketo_leads with changes that will be added to arc.marketo_upload later

UPDATE tmp.marketo_leads tml
SET tml.used_Google_Authentication = CASE WHEN goog.user_ID IS NULL THEN 0 ELSE 1 END

FROM tmp.openIDIdentifiers_to_sync goog

WHERE  tml.user_Id = goog.user_ID
;
SELECT '************************************* tmp.marketo_leads - updating used_Google_Authentication info: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- FINISH used_Google_Authentication updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************


-- Signup Tracking Info --------------------------------------------------------------------

--  2017-09-12 Add signup_Landing_Page data for new leads

UPDATE tmp.marketo_leads tml
SET tml.signup_Landing_Page = sr.item_Value
FROM tmp.new_lead_signup_info sr

WHERE  tml.signup_Request_ID = sr.signup_Request_ID AND item_Name = 'slp' AND item_Value != ''
;
SELECT '************************************* signup_Landing_Page rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--  2017-10-24 Add signup_Variation data for new leads

UPDATE tmp.marketo_leads tml
SET tml.signup_Variation = sr.item_Value
FROM tmp.new_lead_signup_info sr

WHERE  tml.signup_Request_ID = sr.signup_Request_ID AND item_Name = 'su_variation' AND item_Value != ''
;
SELECT '************************************* signup_Variation rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- 2016-12-21 - Added to account for amplified trial signup
-- Capture Optimizely Experiment and Variation IDs

UPDATE tmp.marketo_leads tml
   SET optimizely_Buckets = CASE WHEN sr.item_Value != '{}' THEN REPLACE(REPLACE(REPLACE(REPLACE(sr.item_Value,'"',''),',',';'),'{',''),'}','') END
  FROM tmp.new_lead_signup_info sr
 WHERE tml.signup_Request_ID = sr.signup_Request_ID
   AND sr.item_Name = 'optimizely_Buckets'
;
SELECT '************************************* signupTracking_optimizely_code rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- 2016-12-27 - Added to account for amplified trial signup
-- Capture Optimizely Experiment and Variation IDs in the ABTests field
UPDATE tmp.marketo_leads tml
   SET ABTests =
         CASE
           WHEN ab.NewABTestValue IS NULL AND tml2.optimizely_Buckets IS NULL THEN NULL
           ELSE tml.optimizely_Buckets || ';' || ab.NewABTestValue
         END
  FROM tmp.marketo_leads tml2
       LEFT JOIN (
         SELECT ssev.user_ID
                -- add order so order doesn't keep changing triggering an update
               ,ARRAY_TO_STRING(ARRAY_AGG(DISTINCT ssev.site_Setting_Element_Name) WITHIN GROUP (ORDER BY /*ssev.site_Setting_Element_Value_ID DESC*/ ssev.site_Setting_Element_Name), ';')
                || ';' || ':'
                || ';' || TO_VARCHAR(FLOOR(ANY_VALUE(ssev.value_Numeric))) AS NewABTestValue
           FROM tmp.marketo_leads tml
                JOIN ACCOUNT.PUBLIC.site_Setting_Element_Value ssev
                  ON ssev.user_ID = tml.user_ID
          WHERE ssev.site_Setting_Element_Name LIKE 'SS_ABTEST%'
          GROUP BY ssev.user_ID
       ) ab
         ON tml2.user_ID = ab.user_ID
 WHERE tml.user_ID = tml2.user_ID
;
SELECT '************************************* ABTests rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign source

UPDATE tmp.marketo_leads tml
SET  signup_Tracking_s_code = srti.item_Value
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti

WHERE insert_Source != 'leadSeed'

AND  tml.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 's';
SELECT '************************************* signup_Tracking_s_code rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign campaign

UPDATE tmp.marketo_leads tml
SET  signup_Tracking_c_code = srti.item_Value
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti

WHERE insert_Source != 'leadSeed'

AND  tml.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'c';
SELECT '************************************* signup_Tracking_c_code rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign segment

UPDATE tmp.marketo_leads tml
SET  signup_Tracking_m_code = srti.item_Value
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti

WHERE insert_Source != 'leadSeed'

AND  tml.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'm';
SELECT '************************************* signup_Tracking_m_code rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign keyword

UPDATE tmp.marketo_leads tml
SET  signup_Tracking_Keyword = srti.item_Value
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti

WHERE insert_Source != 'leadSeed'

AND  tml.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'k';
SELECT '************************************* signup_Tracking_Keyword rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign Marketo Tracking Cookie

UPDATE tmp.marketo_leads tml
SET  marketo_Tracking_Cookie = srti.item_Value
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti

WHERE insert_Source != 'leadSeed'

AND  tml.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = '_mkto_trk';
SELECT '************************************* marketo_Tracking_Cookie rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign App Launch Type

UPDATE tmp.marketo_leads tml
   SET signup_Tracking_App_Launch_Type = srti.item_Value::INTEGER
  FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti
 WHERE tml.insert_Source != 'leadSeed'
   AND srti.signup_Request_ID = tml.signup_Request_ID
   AND srti.item_Name = 'Type'
   AND srti.item_Type = 2
;
SELECT '************************************* signup_Tracking_App_Launch_Type rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- Inferred Viral
UPDATE tmp.marketo_leads tml
SET signup_Bucket = 'Inferred Viral'
WHERE signup_Tracking_App_Launch_Type IN (2,6) -- grid or workspace sharing
    OR user_Account_Insert_By_User_ID != 0
;
SELECT '************************************* Inferred Viral rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Inferred Title (updated 2015-10-27)
-- Need to use STRAIGHT_JOIN in order to force join execution order. Without it, the query does
-- a full table scan of arc.lead411EmployeeConfidence first.
UPDATE tmp.marketo_leads tml
   SET inferred_Title = COALESCE(le.job_Title, le2.job_Title)
  FROM tmp.marketo_leads tml2
       LEFT JOIN MAIN.arc.lead411_Employee_Confidence2017 lec
         ON tml2.email_Address = lec.hypothesized_Email
        AND lec.confidence != -1
       LEFT JOIN MAIN.arc.lead411_Employees201703 le
         ON lec.person_ID = le.person_ID
       LEFT JOIN MAIN.arc.lead411_Employee_Confidence lec2
         ON tml2.email_Address = lec2.hypothesized_Email
        AND lec2.confidence != -1
       LEFT JOIN MAIN.arc.lead411_Employees le2
         ON lec2.person_ID = le2.person_ID
 WHERE tml.user_ID = tml2.user_ID
;
SELECT '************************************* Inferred Title rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- 2016-12-21 - Added to account for amplified trial signup
-- Overwrite inferred_Title with signup title if there's a value

UPDATE tmp.marketo_leads tml
SET tml.inferred_Title = COALESCE(sr.item_Value, tml.inferred_Title)

FROM tmp.new_lead_signup_info sr

WHERE  tml.signup_Request_ID = sr.signup_Request_ID AND sr.item_Name = 'su_title'
;
SELECT '************************************* Signup Title rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- 2016-12-21 - Added inferred role to account for amplified trial signup
-- This is too complicated to do in the nightly query.

UPDATE tmp.marketo_leads tml
SET tml.inferred_Role = COALESCE(
    CASE
        WHEN sr.item_Value IS NOT NULL THEN CONCAT('signupRole:', sr.item_Value)
        ELSE NULL
    END,
    tml.inferred_Role) -- Just in case theres an existing value and there's no signup role, don't overwrite it.

FROM tmp.new_lead_signup_info sr

WHERE  tml.signup_Request_ID = sr.signup_Request_ID AND sr.item_Name = 'su_role'
;

UPDATE tmp.marketo_leads
SET container_Count =
(
    SELECT COUNT(*)
    FROM CORE.PUBLIC.container
    WHERE marketo_leads.user_ID = container.insert_By_User_ID
          AND container.container_Type = 2
          AND container.delete_Status = 0
          AND container.payment_Profile_ID = marketo_leads.payment_Profile_ID  -- payment_Profile_ID for its index
)
WHERE insert_Source != 'leadSeed'
;
SELECT '************************************* container_Count rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE tmp.marketo_leads tml
SET
    tml.insert_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
    tml.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
    tml.push_To_Marketo  = $insertPriority
WHERE insert_Source != 'leadSeed'
;
SELECT '************************************* tmp.marketo_leads - insert_Date_Time info: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- -------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------




-- Update misc. fields on the temp table before transferring to upload table

-- Set Org domain flag

UPDATE tmp.marketo_leads
SET is_Org_Domain = CASE WHEN d.domain IS NULL THEN 1 ELSE 0 END

FROM MAIN.arc.ISPDomains d

WHERE  marketo_leads.email_Domain = d.domain
;
SELECT '************************************* is_Org_Domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update user_Tags for all users.
-- Added 2016-08-11
-- 'insertedByOutDomain' = a user who was inserted by a non-ISP domain user with a different domain
-- 'insertedByIn_Domain'  = a user who was inserted by a non-ISP domain user with the same domain
-- 'insertedByISPDomain' = a user who was inserted by an ISP domain user
-- 'insertedBySelf'      = a user who created their own account
-- *********************************************************************************************************************

UPDATE tmp.marketo_leads tmlx
   SET user_Tags = x.user_Tags
  FROM (
         SELECT tml.user_ID
               ,LEADFLOW.PUBLIC.MARKETO_IMPORT_MS_PROJECT(
                  LEADFLOW.PUBLIC.MARKETO_USER_TAG(
                    CASE
                      WHEN isp.domain IS NULL AND ua.insert_By_User_ID != 0
                        THEN 1
                      WHEN isp.domain IS NOT NULL AND ua.insert_By_User_ID != 0
                        THEN 0
                      ELSE -1
                    END
                  ,tml.email_Domain
                  ,COALESCE(MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(uai.email_Address), '')
                  ,src.item_Value
                  ,sre.item_Value
                  )
                ,mu.clicked_Import_Project_Count
                ) AS user_Tags
           FROM tmp.marketo_leads tml
                JOIN CORE.PUBLIC.user_Account ua
                  ON ua.user_ID = tml.user_ID
                LEFT OUTER JOIN LEADFLOW.ARC.marketo_upload mu
                  ON mu.user_ID = tml.user_ID
                LEFT OUTER JOIN CORE.PUBLIC.user_Account uai
                  ON uai.user_ID = ua.insert_By_User_ID
                -- See if it's an ISP domain
                LEFT OUTER JOIN MAIN.ARC.ISPDomains isp
                  ON isp.domain = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(uai.email_Address)
                LEFT OUTER JOIN tmp.new_lead_signup_info src
                  ON src.signup_Request_ID = tml.signup_Request_ID
                 AND src.item_Name = 'su_contactme'
                LEFT OUTER JOIN tmp.new_lead_signup_info sre
                  ON sre.signup_Request_ID = tml.signup_Request_ID
                 AND sre.item_Name = 'signupEmail'
       ) x
 WHERE tmlx.user_ID = x.user_ID
;
SELECT '************************************* user_Tags rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- BEGIN google_Apps_Domain updates for LEADFLOW.arc.marketo_upload (updated 2015-12-11)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core/rpt_main tables and put it in a temporary table.
--     Query--2: Join temp table to tmp.marketo_leads and execute updates
-- *********************************************************************************************************************
-- Query--1: Retrieve changes made to rpt_domainRollup records
DROP TABLE IF EXISTS tmp.rpt_domainRollup_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.rpt_domainRollup_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT
        tml.user_ID,
        dr.google_Apps_Domain
    FROM tmp.marketo_leads tml
        LEFT OUTER JOIN MAIN.rpt.domain_Rollup dr ON tml.email_Domain = dr.domain
    WHERE tml.is_Org_Domain = 1
;
SELECT '************************************* temp is_Google_Apps_Installed_Domain rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update tmp.marketo_leads with changes that will be added to arc.marketo_upload later

UPDATE tmp.marketo_leads tml
SET tml.is_Google_Apps_Installed_Domain = dr.google_Apps_Domain

FROM tmp.rpt_domainRollup_to_sync dr

WHERE  tml.user_ID = dr.user_ID
;
SELECT '************************************* update is_Google_Apps_Installed_Domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
-- *********************************************************************************************************************
-- FINISH used_Google_Authentication updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************


-- update organization name and account_Role, and payment fields if owner
/* toddj - 2-2-2015 - commenting out, the fields set below are coming through LeadSeed.  The code below pulling
 * this data out of CORE is not necessary and won't work because the CORE is likely to be well behind when the lead comes through here.
 * 
UPDATE tmp.marketo_leads 
JOIN CORE.PUBLIC.payment_Profile pp on tmp.marketo_leads.payment_Profile_Id = pp.payment_Profile_Id
LEFT OUTER JOIN CORE.PUBLIC.payment_Profile parentPP ON marketo_leads.parent_Payment_Profile_ID = parentPP.payment_Profile_ID
LEFT OUTER JOIN CORE.PUBLIC.organization ON parentPP.owner_ID = organization.organization_ID AND parentPP.account_Type = 3
LEFT OUTER JOIN CORE.hist.currency_Exchange hce ON parentPP.currency_Code = hce.currency_Code
            AND parentPP.payment_Start_Date_Time BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time
SET organization_Name = organization.name,
    account_Role = 
        CASE 
            WHEN  parentPP.payment_Profile_ID IS NULL THEN 'Individual'  -- this is the user who created the organization and team trial
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID THEN 'Owner'  -- this is the user who created the organization and team trial
            ELSE 'Member'                                                               -- this is the user added to the team trial
        END,
    marketo_leads.plan_Rate =
        CASE 
            WHEN  parentPP.payment_Profile_ID IS NULL THEN marketo_leads.plan_Rate  -- no parent, so keep the existing value
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID THEN parentPP.plan_Rate  -- use the plan_Rate from the org for the owner
            ELSE marketo_leads.plan_Rate                                            -- members don't pay, keep existing value
        END,    
    monthly_Plan_Rate_USD =
        CASE 
            WHEN  parentPP.payment_Profile_ID IS NULL THEN monthly_Plan_Rate_USD  -- no parent, so keep the existing value
            WHEN organization.main_Contact_User_ID = marketo_leads.user_ID THEN -- use the plan_Rate from the org for the owner
                CASE 
                    WHEN parentPP.currency_Code = 'USD' 
                    THEN parentPP.plan_Rate/parentPP.payment_Term 
                    ELSE (parentPP.plan_Rate/hce.exchange_Rate)/parentPP.payment_Term
                END
            ELSE monthly_Plan_Rate_USD                                      -- members don't pay, keep existing value
        END
;  

SELECT '************************************* organization_Name, account_Role, parent payment values rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
*/


-- Set paid domain rollup info

UPDATE tmp.marketo_leads tml
   SET domains_Highest_Plan = pd.Max_Product
  FROM MAIN.RPT.PAID_DOMAINS pd
 WHERE tml.is_Org_Domain = 1  -- Filter out ISP domains. Highest paid plan data for an ISP domain are not helpful.
   AND pd.main_Contact_Domain = tml.email_Domain
;

SELECT '************************************* domains_Highest_Plan rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update domain_Opt_Out for excluded domains and organizations
-- *********************************************************************************************************************
UPDATE LEADFLOW.tmp.marketo_leads tmlx
   SET domain_Opt_Out = x.domain_Opt_Out
  FROM (
         SELECT tml.user_ID
               ,(COALESCE(dee.exclude_From_Marketing_Email, 0) = 1 OR COALESCE(oee.exclude_From_Marketing_Email, 0) = 1) AS domain_Opt_Out
           FROM LEADFLOW.tmp.marketo_leads tml
                LEFT JOIN MAIN.ARC.DOMAIN_EMAIL_EXCLUSION dee
                  ON dee.domain = tml.email_Domain
                LEFT JOIN CORE.PUBLIC.ORGANIZATION_USER_ROLE our
                  ON our.user_ID = tml.user_ID
                 AND our.role = 'MEMBER'
                 AND our.state IN (1, 2)
                LEFT JOIN MAIN.ARC.ORGANIZATION_EMAIL_EXCLUSION oee
                  ON oee.organization_ID = our.organization_ID
       ) x
 WHERE tmlx.user_ID = x.user_ID
;
SELECT '************************************* domain_Opt_Out rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update domain_Opt_Out for collabs of excluded domains and organizations.
-- Added 2016-04-01
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp.tml_collabs_opt_out;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.tml_collabs_opt_out
/*(INDEX (user_ID))*/ AS
  WITH X AS (
    SELECT tml2.user_ID, dee.exclude_From_Marketing_Email FROM MAIN.arc.domain_Email_Exclusion dee
        JOIN tmp.marketo_leads tml /***USE INDEX (idx_email_Domain)***/ ON dee.domain = tml.email_Domain
        JOIN CORE.PUBLIC.user_Account ua ON tml.user_ID = ua.insert_By_User_ID  -- Get all collabs who were inserted by the excluded domain users
        LEFT JOIN MAIN.arc.domain_Email_Exclusion dee2 ON MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = dee2.domain AND COALESCE(dee2.exclude_From_Marketing_Email, 0) = 1  -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.arc.organization_Email_Exclusion oee ON MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = tml.email_Domain AND COALESCE(oee.exclude_From_Marketing_Email, 0) = 1
        JOIN tmp.marketo_leads tml2 ON ua.user_ID = tml2.user_ID  -- Get all collabs in sync table to check if domain_Opt_Out needs to be updated
    WHERE
        dee2.domain IS NULL  -- Only update collabs in domains that are NOT in the exclusion table
        AND oee.organization_ID IS NULL
        AND dee.exclude_From_Marketing_Email = 1
        AND dee.domain != 'smartsheet.com'
    UNION
    SELECT tml2.user_ID, oee.exclude_From_Marketing_Email FROM CORE.PUBLIC.organization_User_Role our
        JOIN MAIN.arc.organization_Email_Exclusion oee ON our.organization_ID = oee.organization_ID AND oee.exclude_From_Marketing_Email = 1 AND oee.organization_ID != 1000008  -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
        JOIN tmp.marketo_leads tml ON our.user_ID = tml.user_ID
        JOIN CORE.PUBLIC.user_Account ua ON tml.user_ID = ua.insert_By_User_ID  -- Get all collabs who were inserted by the excluded users
        LEFT JOIN MAIN.arc.organization_Email_Exclusion oee2 ON MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = tml.email_Domain AND COALESCE(oee2.exclude_From_Marketing_Email, 0) = 1  -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.arc.domain_Email_Exclusion dee ON MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = dee.domain AND COALESCE(dee.exclude_From_Marketing_Email, 0) = 1
        JOIN tmp.marketo_leads tml2 ON ua.user_ID = tml2.user_ID  -- Get all collabs in sync table to check if domain_Opt_Out needs to be updated
    WHERE
        oee2.organization_ID IS NULL  -- Only update collabs in parent payment profile that are NOT in the exclusion table
        AND dee.domain IS NULL
        AND our.state IN (1, 2)
  )
  SELECT user_ID
        ,ANY_VALUE(exclude_From_Marketing_Email) AS exclude_From_Marketing_Email
    FROM X
  GROUP BY user_ID
;
SELECT '************************************* collab domain_Opt_Out rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE tmp.marketo_leads tml
SET tml.domain_Opt_Out = coo.exclude_From_Marketing_Email

FROM tmp.tml_collabs_opt_out coo

WHERE  tml.user_ID = coo.user_ID
;
SELECT '************************************* collab domain_Opt_Out updates: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Set supplemental company data.
-- Updated 2016-06-01
-- *********************************************************************************************************************
-- Updated 2016-12-21 to account for amplified trial signup
-- Updated 2017-10-19 with new hierarchy ISP exceptions
-- 
UPDATE tmp.marketo_leads tmlx
   SET company = x.company
      ,number_Of_Employees = x.number_Of_Employees
  FROM (
         SELECT tml.user_ID
                -- use company name if found in the order of any of the above sources
               ,CASE
                  WHEN tml.is_Org_Domain = 1 THEN COALESCE(a.Name, sm.data_Value, src.item_Value, lc.company_Name, lc2.company_Name, lc3.company_Name)
                  ELSE org.name
                END AS company
               ,CASE
                  WHEN tml.is_Org_Domain = 1
                    THEN COALESCE(
                      CASE
                          WHEN srcs.item_Value LIKE '%-%' THEN TRIM(SPLIT_PART(srcs.item_Value, '-', -1))::INTEGER
                          WHEN srcs.item_Value LIKE '%<%' THEN TRIM(SPLIT_PART(srcs.item_Value, '<', -1))::INTEGER
                          WHEN srcs.item_Value LIKE '%>%' THEN TRIM(SPLIT_PART(srcs.item_Value, '>', -1))::INTEGER
                          WHEN srcs.item_Value LIKE '%+%' THEN TRIM(SPLIT_PART(srcs.item_Value, '+', 1))::INTEGER
                          WHEN srcs.item_Value::INTEGER != 0 THEN srcs.item_Value::INTEGER
                          ELSE NULL
                      END
                     ,CASE
                          WHEN lc.employee_Range LIKE '%-%' THEN TRIM(SPLIT_PART(lc.employee_Range, '-', -1))::INTEGER
                          WHEN lc.employee_Range LIKE '%<%' THEN TRIM(SPLIT_PART(lc.employee_Range, '<', -1))::INTEGER
                          WHEN lc.employee_Range LIKE '%>%' THEN TRIM(SPLIT_PART(lc.employee_Range, '>', -1))::INTEGER
                          WHEN lc.employee_Range::INTEGER != 0 THEN lc.employee_Range::INTEGER
                          ELSE NULL
                      END
                     ,CASE
                          WHEN lc2.employee_Range LIKE '%-%' THEN TRIM(SPLIT_PART(lc2.employee_Range, '-', -1))::INTEGER
                          WHEN lc2.employee_Range LIKE '%<%' THEN TRIM(SPLIT_PART(lc2.employee_Range, '<', -1))::INTEGER
                          WHEN lc2.employee_Range LIKE '%>%' THEN TRIM(SPLIT_PART(lc2.employee_Range, '>', -1))::INTEGER
                          WHEN lc2.employee_Range::INTEGER != 0 THEN lc2.employee_Range::INTEGER
                          ELSE NULL
                      END
                     ,CASE
                          WHEN lc3.employee_Range LIKE '%-%' THEN TRIM(SPLIT_PART(lc3.employee_Range, '-', -1))::INTEGER
                          WHEN lc3.employee_Range LIKE '%<%' THEN TRIM(SPLIT_PART(lc3.employee_Range, '<', -1))::INTEGER
                          WHEN lc3.employee_Range LIKE '%>%' THEN TRIM(SPLIT_PART(lc3.employee_Range, '>', -1))::INTEGER
                          WHEN lc3.employee_Range::INTEGER != 0 THEN lc3.employee_Range::INTEGER
                          ELSE NULL
                      END
                    )
                  ELSE NULL
                END AS number_Of_Employees
           FROM tmp.marketo_leads tml
                JOIN SFDC.PUBLIC.domain d
                  ON d.Domain_Name_URL__c = tml.email_Domain
                LEFT OUTER JOIN SFDC.PUBLIC.account a
                  ON a.Id = d.Account__c
                LEFT OUTER JOIN CORE.PUBLIC.sales_Marketing_User_Data sm
                  ON sm.user_ID = tml.user_ID
                 AND sm.data_Key = 'company'
                LEFT OUTER JOIN MAIN.arc.lead411_Companies201703 lc
                  ON lc.domain = tml.email_Domain
                LEFT OUTER JOIN MAIN.arc.lead411_Companies_V2 lc2
                  ON lc2.domain = tml.email_Domain
                LEFT OUTER JOIN MAIN.arc.lead411_Companies lc3
                  ON lc3.domain = tml.email_Domain
                LEFT OUTER JOIN tmp.new_lead_signup_info src
                  ON src.signup_Request_ID = tml.signup_Request_ID
                 AND src.item_Name = 'su_company'
                 AND src.item_Value != ''
                LEFT OUTER JOIN tmp.new_lead_signup_info srcs
                  ON srcs.signup_Request_ID = tml.signup_Request_ID
                 AND srcs.item_Name = 'su_company_size'
                 AND srcs.item_Value != ''
                LEFT OUTER JOIN CORE.PUBLIC.organization_User_Role our
                  ON our.user_ID = tml.user_ID
                 AND our.role = 'MEMBER'
                LEFT OUTER JOIN CORE.PUBLIC.organization org
                  ON org.organization_ID = our.organization_ID
       ) x
WHERE tmlx.user_ID = x.user_ID
;
-- ORIGINAL
-- UPDATE tmp.marketo_leads tml
--     LEFT JOIN SFDC.PUBLIC.domain d ON tml.email_Domain = d.Domain_Name_URL__c
--     LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
--     LEFT JOIN MAIN.arc.lead411_Companies lc ON tml.email_Domain = lc.domain
--     LEFT JOIN MAIN.arc.lead411_Companies_V2 lc2 ON tml.email_Domain = lc2.domain
-- SET
--     tml.company           = COALESCE(a.Name, lc2.company_Name, lc.company_Name, tml.email_Domain), -- use company name if found, otherwise just use the domain
--     tml.number_Of_Employees = COALESCE(
--         CASE
--         WHEN lc2.employee_Range LIKE '%-%' THEN CONVERT(TRIM(SPLIT_PART(lc2.employee_Range, '-', -1)), UNSIGNED)
--         WHEN lc2.employee_Range LIKE '%<%' THEN CONVERT(TRIM(SPLIT_PART(lc2.employee_Range, '<', -1)), UNSIGNED)
--         WHEN lc2.employee_Range LIKE '%>%' THEN CONVERT(TRIM(SPLIT_PART(lc2.employee_Range, '>', -1)), UNSIGNED)
--         WHEN CONVERT(lc2.employee_Range, UNSIGNED) != 0 THEN CONVERT(lc2.employee_Range, UNSIGNED)
--         ELSE NULL
--         END,
--         CASE
--         WHEN lc.employee_Range LIKE '%-%' THEN CONVERT(TRIM(SPLIT_PART(lc.employee_Range, '-', -1)), UNSIGNED)
--         WHEN lc.employee_Range LIKE '%<%' THEN CONVERT(TRIM(SPLIT_PART(lc.employee_Range, '<', -1)), UNSIGNED)
--         WHEN lc.employee_Range LIKE '%>%' THEN CONVERT(TRIM(SPLIT_PART(lc.employee_Range, '>', -1)), UNSIGNED)
--         WHEN CONVERT(lc.employee_Range, UNSIGNED) != 0 THEN CONVERT(lc.employee_Range, UNSIGNED)
--         ELSE NULL
--         END
--     )
-- ;
SELECT '************************************* supplemental data rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

----##########################################################################################
--  Set fit_Score and fit_Rating for ONLY users who have had a trial
--  Ignore zero second trials because these are from users who move directly to a paid plan
----##########################################################################################

UPDATE LEADFLOW.tmp.marketo_leads tmlx
   SET fit_Score = x.fit_Score
  FROM (
         SELECT tml.user_ID
               ,COALESCE(
                  mu.fit_Score
                 ,LEADFLOW.PUBLIC.GETFIT_SCOREV2(
                    IFF(tml.is_Org_Domain, 1, 0)
                   ,tml.locale
                   ,tml.signup_Tracking_s_code
                   ,tml.signup_Tracking_c_code
                   ,tml.signup_Tracking_m_code
                   ,IFF(tml.was_Shared_To_Prior_To_Trial, 1, 0)
                   ,IFF(tml.user_Account_Insert_By_User_ID > 0, 1, 0)
                   ,IFF(tml.signup_Tracking_App_Launch_Type, 1, 0)
                  )
                ) AS fit_Score
           FROM LEADFLOW.tmp.marketo_leads tml
                JOIN CORE.hist.payment_Profile hpp  /***FORCE INDEX (hist_payment_Profile_idxPK)***/
                LEFT OUTER JOIN LEADFLOW.arc.marketo_upload mu
                  ON mu.user_ID = tml.user_ID
          WHERE tml.payment_Profile_ID = hpp.payment_Profile_ID
            AND hpp.product_ID = 1
            AND hpp.modify_Date_Time != hpp.hist_effective_Thru_Date_Time
       ) x
WHERE tmlx.user_ID = x.user_ID
;

--  UPDATE tmp.marketo_leads tml
--  SET fit_Score = getFit_ScoreV2(tml.is_Org_Domain, tml.locale, tml.signup_Tracking_s_code, tml.signup_Tracking_c_code, tml.signup_Tracking_m_code,
--                               tml.was_Shared_To_Prior_To_Trial, IFF(tml.user_Account_Insert_By_User_ID > 0, 1, 0), tml.signup_Tracking_App_Launch_Type)
--  ;

--  Only set fit_Rating if fit_Score is also set
UPDATE tmp.marketo_leads tml
SET fit_Rating = 
    CASE
        WHEN tml.fit_Score >=50 THEN 'A' -- 5% likely to convert to paid plan
        WHEN tml.fit_Score >=23 THEN 'B' -- 2.3% likely to convert to paid plan
        WHEN tml.fit_Score >=10 THEN 'C' -- 1% likely to convert to paid plan
        ELSE 'D'
    END
WHERE tml.fit_Score IS NOT NULL
;
SELECT '************************************* fit_Score rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- **************************************************************************************************************************
-- BEGIN Sales Rep Assignment
-- **************************************************************************************************************************
-- 2015-03-06 - toddj - this code below used to be in marketoLeadAssignment stored procedure
-- 2016-03-04 - jmarzinke - begin cleanup and documentation of sales assignment code


-- Pre-assign all leads with a payment profile to 'NeedsOwner' for later reassignment
UPDATE tmp.marketo_leads
SET salesforce_Owner_At_Import = 'NeedsOwner'
WHERE payment_Profile_ID IS NOT NULL
;
SELECT '************************************* NeedsOwner rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Set lead source to 'Smartscored' for all Trial users with the following criteria

UPDATE tmp.marketo_leads tmlx
   SET salesforce_Lead_Source = x.salesforce_Lead_Source
  FROM (
         SELECT tml.user_ID
               ,'Smartscored' AS salesforce_Lead_Source
           FROM tmp.marketo_leads tml
                JOIN MAIN.arc.do_Not_Contact_List dncl
                  ON dncl.email_Address = tml.email_Address
                LEFT OUTER JOIN MAIN.arc.ISPDomains isp
                  ON isp.domain = tml.email_Domain
          WHERE tml.product_Name = 'Trial'  
            AND isp.domain IS NULL  -- Only smartscore non-ISP domains
            AND dncl.email_Address IS NULL
            AND (tml.locale LIKE 'en_%' OR SUBSTR(tml.locale,4,6) IN ('SE', 'NO', 'NL', 'DK', 'FI'))  -- ('Sweden','Norway','Netherlands','Denmark','Finland')
            AND tml.email_Domain NOT IN ('smartsheet.com')  -- Don't smartscore Smartsheet employees
            AND tml.email_Domain NOT LIKE 'student.%'  -- Don't smartscore all students
            AND tml.email_Domain NOT LIKE 'students.%' 
            AND tml.email_Domain NOT LIKE 'stud.%' 
            AND tml.email_Domain NOT LIKE 'stu.%' 
            AND tml.email_Domain NOT LIKE '%mail.%.edu' 
            AND tml.email_Domain NOT LIKE '%k12%' 
            AND (tml.was_Shared_To_Prior_To_Trial = 0 OR tml.container_Count > 0) -- if they were shared to, make sure they created a sheet.
          GROUP BY tml.user_ID
       ) x
 WHERE tmlx.user_ID = x.user_ID
;
SELECT '************************************* Smartscored rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- BEGIN SFDC domain updates for LEADFLOW.arc.sfdc_domains (updated 2016-05-19)
-- Use temp table to prevent locks on SFDC.PUBLIC.domain, which is slowing down the whole script
-- *********************************************************************************************************************
-- Query--1: Retrieve SFDC domain changes
DROP TABLE IF EXISTS tmp.sfdc_domains;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.sfdc_domains
/*(INDEX (Domain_Name_URL__c))*/ AS
SELECT sfd.Domain_Name_URL__c, sfu.Owner_at_Import__c, sfd.Status__c
FROM LEADFLOW.arc.sfdc_domains lfd
JOIN SFDC.PUBLIC.domain sfd ON lfd.company_Domain = sfd.Domain_Name_URL__c
JOIN SFDC.PUBLIC.user sfu ON sfd.Owner_Id = sfu.Id
;
SELECT '************************************* sfdc_domains.sfdc_Owner/Status__c SFDC.PUBLIC.domain temp: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update LEADFLOW table to match SFDC where possible and delete matched records

UPDATE LEADFLOW.arc.sfdc_domains lfd
SET lfd.sfdc_Owner = sfd.Owner_at_Import__c,
    lfd.Status__c = sfd.Status__c

FROM tmp.sfdc_domains sfd

WHERE  lfd.company_Domain = sfd.Domain_Name_URL__c
;
SELECT '************************************* sfdc_domains.sfdc_Owner/Status__c SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
-- *********************************************************************************************************************
-- FINISH SFDC domain updates for LEADFLOW.arc.sfdc_domains
-- *********************************************************************************************************************


-- Update SSOwner to match SFDCOwner
UPDATE LEADFLOW.arc.sfdc_domains
SET
    SSOwner = sfdc_Owner,
    value_Check = 3
WHERE
    sfdc_Owner != SSOwner
    AND sfdc_Owner NOT IN ('Andrew Imhoff', 'Leads Uploader', 'Marketo Integration', 'Desk Integration')
;
SELECT '************************************* sfdc_domains.SSOwner value_Check rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Delete unassigned leads
DELETE FROM LEADFLOW.arc.sfdc_domains 
WHERE
    sfdc_Owner = 'Andrew Imhoff'
    AND Status__c = 'Unassigned'
--    AND date_Added < $marketoLookbackDateTime
  AND date_Added > $window_start_date_time
  AND date_Added <= $window_end_date_time
;
SELECT '************************************* sfdc_domains.sfdc_Owner delete rows: ', (SELECT "number of rows deleted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains -- most specific to least specific matching

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfu.Owner_at_Import__c
FROM SFDC.PUBLIC.domain
JOIN SFDC.PUBLIC.user sfu ON domain.Owner_Id = sfu.Id

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)') 
AND domain.Owner_ID IN (
    SELECT ID FROM SFDC.PUBLIC.user 
    WHERE user_Role_ID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))

AND  domain.Domain_Name_URL__c = marketo_leads.email_Domain
;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to last 4 sections of a domain - aci.health.nsw.gov.au becomes health.nsw.gov.au

UPDATE LEADFLOW.tmp.marketo_leads tml
   SET salesforce_Owner_At_Import = sfu.Owner_at_Import__c
  FROM SFDC.PUBLIC.domain d
       JOIN SFDC.PUBLIC.user sfu
         ON sfu.Id = d.Owner_Id
 WHERE tml.salesforce_Owner_At_Import = 'NeedsOwner'
   AND d.Status__c IN ('Assigned', 'Assigned (Named)') 
   AND d.Domain_Name_URL__c = SPLIT_PART(tml.email_Domain, '.', -4)
   AND d.Owner_ID IN (
         SELECT u.ID
           FROM SFDC.PUBLIC.user u
          WHERE u.user_Role_ID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC')
       )
;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to last 3 sections of a domain - 13lob.freeserve.co.uk becomes freeserve.co.uk 

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfu.Owner_at_Import__c
FROM SFDC.PUBLIC.domain
JOIN SFDC.PUBLIC.user sfu ON domain.Owner_Id = sfu.Id

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)') 
AND domain.Owner_ID IN (
    SELECT ID FROM SFDC.PUBLIC.user 
    WHERE user_Role_ID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))

AND  domain.Domain_Name_URL__c = SPLIT_PART(marketo_leads.email_Domain, '.', -3)
;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to just last 2 sections of domain - 00518.mygbiz.com becomes mygbiz.com

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfu.Owner_at_Import__c
FROM SFDC.PUBLIC.domain
JOIN SFDC.PUBLIC.user sfu ON domain.Owner_Id = sfu.Id

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)') 
AND domain.Owner_ID IN (
    SELECT ID FROM SFDC.PUBLIC.user 
    WHERE user_Role_ID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))

AND  domain.Domain_Name_URL__c = SPLIT_PART(marketo_leads.email_Domain, '.', -2)
;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- check for foreign versions of exisitng domains abb.com.nz - 09vantage.co.nz becomes 09vantage.co

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfu.Owner_at_Import__c
FROM SFDC.PUBLIC.domain
JOIN SFDC.PUBLIC.user sfu ON domain.Owner_Id = sfu.Id

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND domain.Status__c IN ('Assigned', 'Assigned (Named)') 
AND domain.Owner_ID IN (
    SELECT ID FROM SFDC.PUBLIC.user 
    WHERE user_Role_ID IN ('00E40000001CABcEAO','00E40000001CABhEAO','00E40000001CbVCEA0','00E40000001CbVHEA0','00E33000001Xuz1EAC'))

AND  domain.Domain_Name_URL__c = SPLIT_PART(marketo_leads.email_Domain, '.', 2)
;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains -- most specific to least specific matching

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'

AND  sfdc_domains.company_Domain = marketo_leads.email_Domain;
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to last 4 sections of a domain - aci.health.nsw.gov.au becomes health.nsw.gov.au

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'

AND  sfdc_domains.company_Domain = SPLIT_PART(marketo_leads.email_Domain, '.', -4);
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to last 3 sections of a domain - 13lob.freeserve.co.uk becomes freeserve.co.uk 

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'

AND  sfdc_domains.company_Domain = SPLIT_PART(marketo_leads.email_Domain, '.', -3);
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update salesforce_Owner_At_Import for previously existing domains - handle matches to just last 2 sections of domain - 00518.mygbiz.com becomes mygbiz.com

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'

AND  sfdc_domains.company_Domain = SPLIT_PART(marketo_leads.email_Domain, '.', -2);
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- check for foreign versions of exisitng domains abb.com.nz - 09vantage.co.nz becomes 09vantage.co

UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'

AND  sfdc_domains.company_Domain = SPLIT_PART(marketo_leads.email_Domain, '.', 2);
SELECT '************************************* SFDC.PUBLIC.domain rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- only allow edu domain from paid accounts through
-- UPDATE tmp.marketo_leads 
-- SET marketo_leads.salesforce_Lead_Source = NULL
-- WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND email_Domain LIKE '%.edu%';
-- Update salesforce_Owner_At_Import for all other leads
-- Insert new Prosumer domains to arc.sfdc_domains

/* INSERT INTO arc.sfdc_domains (company_Domain, date_Added)
SELECT email_Domain, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.marketo_leads
LEFT OUTER JOIN MAIN.arc.ISPDomains ON marketo_leads.email_Domain = ISPDomains.domain
WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND marketo_leads.email_Domain IS NOT NULL
AND ISPDomains.user_Count IS NULL -- Remove ISP domains
AND email_Domain NOT IN (SELECT company_Domain FROM arc.sfdc_domains)
GROUP BY 1
;
-- Assign owners for new domains
SET null_Count = (SELECT  MAX(null_Count)  FROM arc.sfdc_domains); -- find starting point for count for randomdistribution
UPDATE arc.sfdc_domains
SET null_Count = $null_Count:=@null_Count + 1 
WHERE SSOwner IS NULL;
-- Assign owners based on 00-99 assignment table.  Generated via stored procedure LeadAssignment();

UPDATE arc.sfdc_domains
SET  sfdc_domains.SSOwner = lead_Assignment_NBR.SSOwner
FROM arc.leadAssignmentNBR

WHERE sfdc_domains.SSOwner IS NULL
AND  RIGHT(null_Count,2) = lead_Assignment_NBR.Assignment_ID;
-- Update salesforce_Owner_At_Import for these now assigned domains

UPDATE tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'
AND  sfdc_domains.company_Domain = marketo_leads.email_Domain; */

-- code included now to flag if the lead is coming in from a beachhead domain
INSERT INTO LEADFLOW.arc.sfdc_domains (company_Domain, date_Added, beachhead_Domain)
SELECT email_Domain, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, ANY_VALUE(CASE WHEN d.Domain_Name_URL__c IS NOT NULL THEN 1 ELSE 0 END)
FROM LEADFLOW.tmp.marketo_leads
LEFT OUTER JOIN MAIN.arc.ISPDomains isp ON marketo_leads.email_Domain = isp.domain
LEFT OUTER JOIN SFDC.PUBLIC.domain d ON d.Domain_Name_URL__c = marketo_leads.email_Domain AND d.Beachhead_Domain__c = 'true'
WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner' AND marketo_leads.email_Domain IS NOT NULL
AND isp.user_Count IS NULL -- Remove ISP domains
AND email_Domain NOT IN (SELECT company_Domain FROM arc.sfdc_domains)
GROUP BY 1
;
SELECT '************************************* beachhead domain rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign owners for new domains
SET null_Count = (SELECT  MAX(null_Count)  FROM LEADFLOW.arc.sfdc_domains); -- find starting point for count for randomdistribution including both ISR2 and ISR1 reps
SET beachhead_IDCount = (SELECT  MAX(beachhead_Domain_ID)  FROM LEADFLOW.arc.sfdc_domains);  -- find starting point for beachhead assignment


CREATE OR REPLACE SEQUENCE LEADFLOW.ARC.SEQ_BEACHHEAD_IDCOUNT
;

UPDATE LEADFLOW.arc.sfdc_domains
SET beachhead_Domain_ID = $beachhead_IDCount + LEADFLOW.ARC.SEQ_BEACHHEAD_IDCOUNT.NEXTVAL
WHERE SSOwner IS NULL AND beachhead_Domain = 1
;
SELECT '************************************* LEADFLOW.arc.sfdc_domains rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

CREATE OR REPLACE SEQUENCE LEADFLOW.ARC.SEQ_NULL_COUNT
;

UPDATE LEADFLOW.arc.sfdc_domains
SET null_Count = $null_Count + LEADFLOW.ARC.SEQ_NULL_COUNT.NEXTVAL
WHERE SSOwner IS NULL AND (beachhead_Domain IS NULL OR beachhead_Domain = 0)
;
SELECT '************************************* LEADFLOW.arc.sfdc_domains rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign beachhead owners based on 000-999 assignment table. 

UPDATE LEADFLOW.arc.sfdc_domains
SET  sfdc_domains.SSOwner = lead_Assignment_NBR.SSOwner
FROM LEADFLOW.arc.lead_Assignment_NBR

WHERE sfdc_domains.SSOwner IS NULL AND sfdc_domains.beachhead_Domain = 1
AND  RIGHT(beachhead_Domain_ID,3) = lead_Assignment_NBR.Assignment_ID;
SELECT '************************************* LEADFLOW.arc.sfdc_domains rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign owners for non-beachhead domains using 000-999 table that consists ISR1 reps.

UPDATE LEADFLOW.arc.sfdc_domains
SET  sfdc_domains.SSOwner = lead_Assignment_NAS.SSOwner
FROM LEADFLOW.arc.lead_Assignment_NAS

WHERE sfdc_domains.SSOwner IS NULL AND (beachhead_Domain IS NULL OR beachhead_Domain = 0)
AND  RIGHT(null_Count,3) = lead_Assignment_NAS.Assignment_ID;
SELECT '************************************* LEADFLOW.arc.sfdc_domains rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE LEADFLOW.tmp.marketo_leads
SET  marketo_leads.salesforce_Owner_At_Import = sfdc_domains.SSOwner
FROM LEADFLOW.arc.sfdc_domains

WHERE marketo_leads.salesforce_Owner_At_Import = 'NeedsOwner'
AND  sfdc_domains.company_Domain = marketo_leads.email_Domain;
SELECT '************************************* arc.sfdc_domains rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- this is for the leads that are not really smartscored, we're just pre-assigning owners so activity triggers
-- that happen later can cause the lead to be pushed to SFDC

UPDATE LEADFLOW.tmp.marketo_leads tml
   SET salesforce_Owner_At_Import = lan.SSOwner
  FROM arc.lead_Assignment_NAS lan
 WHERE tml.salesforce_Owner_At_Import = 'NeedsOwner'
   AND lan.Assignment_ID = RIGHT(tml.user_ID,3)
;
SELECT '************************************* arc.leadAssignmentNAS rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Assign salesforce_Owner_Role_At_Import

UPDATE LEADFLOW.tmp.marketo_leads A
SET salesforce_Owner_Role_At_Import = ur.Name

FROM SFDC.PUBLIC.user u
JOIN SFDC.PUBLIC.user_role ur ON ur.Id = u.User_Role_ID

WHERE  u.Owner_at_Import__c = A.salesforce_Owner_At_Import
;
SELECT '************************************* salesforce_Owner_Role_At_Import rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update remaining salesforce related fields (Updated 2016-08-03)
UPDATE tmp.marketo_leads tmlx
   SET smartscore_Code = x.smartscore_Code
      ,salesforce_Status = x.salesforce_Status
  FROM (
         SELECT tml.User_ID
               ,CASE
                  WHEN tml.is_Trial_Restart = 1 THEN 'Org+Restart'
                  WHEN tml.was_Shared_To_Prior_To_Trial = 1 THEN 'Org+Shared'
                  WHEN tml.signup_Request_ID IS NULL THEN 'Org+Viral'
                  WHEN tml.used_Google_Authentication = 1 THEN 'Org+Google'
                  WHEN tml.locale NOT LIKE ('en_%') THEN 'Org+OtherLanguage'
                  ELSE 'Org+English'
                END AS smartscore_Code
               ,CASE
                  WHEN dee.domain IS NULL OR oee.organization_ID IS NULL THEN 'Pending' -- pending leads get sales, webinar emails
                  ELSE 'New' -- new just gets webinar emails
                END AS salesforce_Status
           FROM tmp.marketo_leads tml
                LEFT JOIN MAIN.arc.domain_Email_Exclusion dee ON tml.email_Domain = dee.domain AND dee.exclude_From_Sales_Email = 1
                LEFT JOIN CORE.PUBLIC.organization_User_Role our ON tml.user_ID = our.user_ID AND our.role = 'MEMBER' AND our.state IN (1, 2)
                LEFT JOIN MAIN.arc.organization_Email_Exclusion oee ON our.organization_ID = oee.organization_ID
                LEFT JOIN MAIN.arc.do_Not_Contact_List dnc ON tml.email_Address = dnc.email_Address
          WHERE tml.salesforce_Lead_Source IS NOT NULL
       ) x
 WHERE tmlx.user_ID = x.user_ID
;
SELECT '************************************* SFDC fields() rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- **************************************************************************************************************************
-- FINISH Sales Rep Assignment
-- **************************************************************************************************************************


-- **************************************************************************************************************************
-- BEGIN Add Success Rep Details, Account Tier, Account Health, and Account CSA Drip Bucket
-- **************************************************************************************************************************

UPDATE tmp.marketo_leads tmlx
   SET account_Health            = x.account_Health
      ,account_Tier              = x.account_Tier
      ,account_CSADrip_Bucket    = x.account_CSADrip_Bucket
      ,account_Territory         = x.account_Territory
      ,success_Rep_Email         = x.success_Rep_Email
      ,success_Rep_First_Name    = x.success_Rep_First_Name
      ,success_Rep_Last_Name     = x.success_Rep_Last_Name
      ,success_Rep_Phone_Number  = x.success_Rep_Phone_Number
      ,domain_Owner_Email        = x.domain_Owner_Email
      ,domain_Owner_First_Name   = x.domain_Owner_First_Name
      ,domain_Owner_Last_Name    = x.domain_Owner_Last_Name
      ,domain_Owner_Title        = x.domain_Owner_Title
      ,domain_Owner_Phone_Number = x.domain_Owner_Phone_Number
  FROM (
         SELECT tml.user_ID
               ,cs.account_Health
               ,cs.account_Tier
               ,cs.Account_To_Be_Assigned AS account_CSADrip_Bucket
               ,cs.territory AS account_Territory
               ,csu.Email AS success_Rep_Email
               ,csu.First_Name AS success_Rep_First_Name
               ,csu.Last_Name AS success_Rep_Last_Name
               ,csu.Phone AS success_Rep_Phone_Number
               ,dou.Email AS domain_Owner_Email
               ,dou.First_Name AS domain_Owner_First_Name
               ,dou.Last_Name AS domain_Owner_Last_Name
               ,dou.Title AS domain_Owner_Title
               ,dou.Phone AS domain_Owner_Phone_Number
           FROM tmp.marketo_leads tml
                LEFT JOIN SFDC.PUBLIC.domain d ON tml.email_Domain = d.Domain_Name_URL__c
                LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
                LEFT JOIN MAIN.rpt.cs_Report cs ON a.Id = cs.account_Id
                LEFT JOIN SFDC.PUBLIC.user csu ON a.Customer_Success__c = csu.Id
                LEFT JOIN SFDC.PUBLIC.user dou ON d.Owner_Id = dou.Id AND dou.ID != '00540000002nu18AAA'  -- Exclude Andrew Imhoff. We don't want emails to come from him.
          WHERE tml.is_Org_Domain = 1  -- Ignore ISP domains.
       ) x
 WHERE tmlx.user_ID = x.user_ID
;
SELECT '************************************* customer success account rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- **************************************************************************************************************************
-- FINISH Add Success Rep Details, Account Tier, Account Health, and Account CSA Drip Bucket
-- **************************************************************************************************************************


-- **************************************************************************************************************************
-- BEGIN Copy All tmp.marketo_leads To arc.marketo_upload Table
-- **************************************************************************************************************************

-- Copy all fields into arc.marketo_upload, ignoring any with duplicate keys
INSERT /*IGNORE*/ INTO arc.marketo_upload
    SELECT *
    FROM tmp.marketo_leads L
    WHERE insert_Source NOT LIKE '%-newPP'
      AND NOT EXISTS (
          SELECT 1
            FROM arc.marketo_upload U
           WHERE U.user_ID = L.user_ID
          )
    ORDER BY user_ID ASC
; -- Order by user_ID to minimize lock wait/deadlock collisions with Marketo importer updates
SELECT '************************************* arc.marketo_upload INSERT INTO insert_Source NOT LIKE %-newPP', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Replace all fields into arc.marketo_upload where a user has a payment profile where previously didn't
-- (e.g., A collaborator begins a trial)
MERGE INTO arc.marketo_upload T
  USING (
    SELECT *
    FROM tmp.marketo_leads
    ORDER BY user_ID ASC  -- Order by user_ID to minimize lock wait/deadlock collisions with Marketo importer updates
  ) S
    ON S.user_ID = T.user_ID
  WHEN NOT MATCHED THEN INSERT VALUES (
    S.USER_ID, S.PUSH_TO_MARKETO, S.INSERT_DATE_TIME, S.UPDATE_DATE_TIME, S.UPLOAD_DATE_TIME, S.UPLOAD_STATUS, S.USER_ACCOUNT_MODIFY_DATE_TIME,
    S.PP_MODIFY_DATE_TIME, S.TRIAL_MODIFY_DATE_TIME, S.SALESFORCE_OWNER_AT_IMPORT, S.SALESFORCE_STATUS, S.SMARTSCORE_CODE, S.SALESFORCE_LEAD_SOURCE,
    S.FIRST_NAME, S.LAST_NAME, S.EMAIL_ADDRESS, S.EMAIL_DOMAIN, S.IS_ORG_DOMAIN, S.WEBSITE, S.NEWS_FLAGS, S.STATUS_FLAGS, S.LOCALE, S.TIME_ZONE, S.ABTESTS,
    S.IP_COUNTRY, S.USED_GOOGLE_AUTHENTICATION, S.IS_GOOGLE_APPS_INSTALLED_DOMAIN, S.DOMAINS_HIGHEST_PLAN, S.DOMAIN_USE_IN_PAST_YEAR, S.CURRENT_DOMAIN_TRIALS,
    S.WAS_SHARED_TO_PRIOR_TO_TRIAL, S.PAYMENT_PROFILE_ID, S.PARENT_PAYMENT_PROFILE_ID, S.PRODUCT_NAME, S.ACCOUNT_ROLE, S.USER_LIMIT, S.PAYMENT_START_DATE_TIME,
    S.NEXT_PAYMENT_DATE, S.PAYMENT_TERM, S.PLAN_RATE, S.MONTHLY_PLAN_RATE_USD, S.CURRENCY_CODE, S.TEAM_TRIAL, S.TRIAL_START_DATE_TIME, S.TRIAL_END_DATE_DATE_TIME,
    S.IS_TRIAL_RESTART, S.PRIMARY_CONTACT_PHONE, S.BILL_TO_ADDRESS, S.BILL_TO_CITY, S.BILL_TO_REGION_CODE, S.BILL_TO_POST_CODE, S.BILL_TO_COUNTRY_CODE,
    S.ORGANIZATION_NAME, S.HISTORY_HIGHEST_PLAN, S.SIGNUP_TRACKING_KEYWORD, S.SIGNUP_TRACKING_S_CODE, S.SIGNUP_TRACKING_C_CODE, S.SIGNUP_TRACKING_M_CODE,
    S.SIGNUP_BUCKET, S.SIGNUP_SOURCE, S.SIGNUP_SUB_SOURCE, S.MARKETO_TRACKING_COOKIE, S.LAST_LOGIN, S.LAST_MOBILE_LOGIN, S.IS_EVER_WELL_QUALIFIED,
    S.IS_STRONG_LEAD, S.EVENT_LOG_COUNT, S.LOGIN_COUNT, S.SHEET_COUNT, S.SHARING_COUNT, S.REPORT_COUNT, S.COMPANY, S.NUMBER_OF_EMPLOYEES, S.CHURN_RISK_CATEGORY,
    S.ROLE, S.USED_REMINDERS, S.USED_BRANDED_WORKSPACE, S.USED_DRIVE_ATTACHMENT, S.USED_EVERNOTE_ATTACHMENT, S.USED_CELL_LINKING, S.USED_CHANGE_VIEW,
    S.DISCUSSION_COUNT, S.IMPORTED_SHEET_COUNT, S.TEMPLATE_COUNT, S.WEB_FORM_COUNT, S.COLUMN_PROPERTY_FORM_COUNT, S.HIERARCHY_COUNT, S.ATTACHMENT_COUNT,
    S.UPGRADE_WIZARD_PROGRESS, S.INSERT_SOURCE, S.FIT_SCORE, S.FIT_RATING, S.APP_BEHAVIOR_SCORE, S.APP_BEHAVIOR_SCORE_OLD, S.APP_BEHAVIOR_SCORE_NEW,
    S.RECURRING_BILLING_CANCELLED, S.DOMAIN_OPT_OUT, S.APP_OPT_OUT, S.CONTAINER_COUNT, S.SIGNUP_REQUEST_ID, S.SIGNUP_TRACKING_APP_LAUNCH_TYPE,
    S.USER_ACCOUNT_INSERT_BY_USER_ID, S.PARENT_PAYMENT_START_DATE_TIME, S.PERSONA, S.IP_REGION, S.ORGANIZATION_ROLES, S.INFERRED_TITLE, S.I_OSAPP_LOGIN_COUNT,
    S.ANDROID_APP_LOGIN_COUNT, S.HIGHEST_SHARED_SHEET_PERMISSION, S.SOLUTIONS_USED, S.SALESFORCE_OWNER_ROLE_AT_IMPORT, S.IP_CITY, S.IS_USER_AGREEMENT_ACCEPTED,
    S.IMAGES_IN_GRID_COUNT, S.ORGANIZATION_ID, S.INFERRED_ROLE, S.DASHBOARDS_ENABLED_DATE_TIME, S.DASHBOARD_COUNT, S.SUCCESS_REP_EMAIL, S.SUCCESS_REP_FIRST_NAME,
    S.SUCCESS_REP_LAST_NAME, S.SUCCESS_REP_PHONE_NUMBER, S.ACCOUNT_HEALTH, S.ACCOUNT_TIER, S.ACCOUNT_CSADRIP_BUCKET, S.DOMAIN_OWNER_EMAIL,
    S.DOMAIN_OWNER_FIRST_NAME, S.DOMAIN_OWNER_LAST_NAME, S.DOMAIN_OWNER_TITLE, S.DOMAIN_OWNER_PHONE_NUMBER, S.ORG_PRODUCT_NAME, S.BONUS_LICENSE_LIMIT,
    S.ASSIGNED_LICENSE_COUNT, S.PENDING_LICENSE_COUNT, S.LICENSE_TAGS, S.CARD_VIEW_VIEW_COUNT, S.LAST_BULLETIN_CLOSE_DATE_TIME, S.ACCOUNT_TERRITORY,
    S.PREVIOUS_USER_LIMIT, S.USER_TAGS, S.OPTIMIZELY_BUCKETS, S.PAYMENT_TYPE, S.CLICKED_IMPORT_PROJECT_COUNT, S.SIGNUP_LANDING_PAGE, S.SIGNUP_VARIATION
  )
  WHEN MATCHED THEN UPDATE SET
    PUSH_TO_MARKETO = S.PUSH_TO_MARKETO
   ,INSERT_DATE_TIME = S.INSERT_DATE_TIME
   ,UPDATE_DATE_TIME = S.UPDATE_DATE_TIME
   ,UPLOAD_DATE_TIME = S.UPLOAD_DATE_TIME
   ,UPLOAD_STATUS = S.UPLOAD_STATUS
   ,USER_ACCOUNT_MODIFY_DATE_TIME = S.USER_ACCOUNT_MODIFY_DATE_TIME
   ,PP_MODIFY_DATE_TIME = S.PP_MODIFY_DATE_TIME
   ,TRIAL_MODIFY_DATE_TIME = S.TRIAL_MODIFY_DATE_TIME
   ,SALESFORCE_OWNER_AT_IMPORT = S.SALESFORCE_OWNER_AT_IMPORT
   ,SALESFORCE_STATUS = S.SALESFORCE_STATUS
   ,SMARTSCORE_CODE = S.SMARTSCORE_CODE
   ,SALESFORCE_LEAD_SOURCE = S.SALESFORCE_LEAD_SOURCE
   ,FIRST_NAME = S.FIRST_NAME
   ,LAST_NAME = S.LAST_NAME
   ,EMAIL_ADDRESS = S.EMAIL_ADDRESS
   ,EMAIL_DOMAIN = S.EMAIL_DOMAIN
   ,IS_ORG_DOMAIN = S.IS_ORG_DOMAIN
   ,WEBSITE = S.WEBSITE
   ,NEWS_FLAGS = S.NEWS_FLAGS
   ,STATUS_FLAGS = S.STATUS_FLAGS
   ,LOCALE = S.LOCALE
   ,TIME_ZONE = S.TIME_ZONE
   ,ABTESTS = S.ABTESTS
   ,IP_COUNTRY = S.IP_COUNTRY
   ,USED_GOOGLE_AUTHENTICATION = S.USED_GOOGLE_AUTHENTICATION
   ,IS_GOOGLE_APPS_INSTALLED_DOMAIN = S.IS_GOOGLE_APPS_INSTALLED_DOMAIN
   ,DOMAINS_HIGHEST_PLAN = S.DOMAINS_HIGHEST_PLAN
   ,DOMAIN_USE_IN_PAST_YEAR = S.DOMAIN_USE_IN_PAST_YEAR
   ,CURRENT_DOMAIN_TRIALS = S.CURRENT_DOMAIN_TRIALS
   ,WAS_SHARED_TO_PRIOR_TO_TRIAL = S.WAS_SHARED_TO_PRIOR_TO_TRIAL
   ,PAYMENT_PROFILE_ID = S.PAYMENT_PROFILE_ID
   ,PARENT_PAYMENT_PROFILE_ID = S.PARENT_PAYMENT_PROFILE_ID
   ,PRODUCT_NAME = S.PRODUCT_NAME
   ,ACCOUNT_ROLE = S.ACCOUNT_ROLE
   ,USER_LIMIT = S.USER_LIMIT
   ,PAYMENT_START_DATE_TIME = S.PAYMENT_START_DATE_TIME
   ,NEXT_PAYMENT_DATE = S.NEXT_PAYMENT_DATE
   ,PAYMENT_TERM = S.PAYMENT_TERM
   ,PLAN_RATE = S.PLAN_RATE
   ,MONTHLY_PLAN_RATE_USD = S.MONTHLY_PLAN_RATE_USD
   ,CURRENCY_CODE = S.CURRENCY_CODE
   ,TEAM_TRIAL = S.TEAM_TRIAL
   ,TRIAL_START_DATE_TIME = S.TRIAL_START_DATE_TIME
   ,TRIAL_END_DATE_DATE_TIME = S.TRIAL_END_DATE_DATE_TIME
   ,IS_TRIAL_RESTART = S.IS_TRIAL_RESTART
   ,PRIMARY_CONTACT_PHONE = S.PRIMARY_CONTACT_PHONE
   ,BILL_TO_ADDRESS = S.BILL_TO_ADDRESS
   ,BILL_TO_CITY = S.BILL_TO_CITY
   ,BILL_TO_REGION_CODE = S.BILL_TO_REGION_CODE
   ,BILL_TO_POST_CODE = S.BILL_TO_POST_CODE
   ,BILL_TO_COUNTRY_CODE = S.BILL_TO_COUNTRY_CODE
   ,ORGANIZATION_NAME = S.ORGANIZATION_NAME
   ,HISTORY_HIGHEST_PLAN = S.HISTORY_HIGHEST_PLAN
   ,SIGNUP_TRACKING_KEYWORD = S.SIGNUP_TRACKING_KEYWORD
   ,SIGNUP_TRACKING_S_CODE = S.SIGNUP_TRACKING_S_CODE
   ,SIGNUP_TRACKING_C_CODE = S.SIGNUP_TRACKING_C_CODE
   ,SIGNUP_TRACKING_M_CODE = S.SIGNUP_TRACKING_M_CODE
   ,SIGNUP_BUCKET = S.SIGNUP_BUCKET
   ,SIGNUP_SOURCE = S.SIGNUP_SOURCE
   ,SIGNUP_SUB_SOURCE = S.SIGNUP_SUB_SOURCE
   ,MARKETO_TRACKING_COOKIE = S.MARKETO_TRACKING_COOKIE
   ,LAST_LOGIN = S.LAST_LOGIN
   ,LAST_MOBILE_LOGIN = S.LAST_MOBILE_LOGIN
   ,IS_EVER_WELL_QUALIFIED = S.IS_EVER_WELL_QUALIFIED
   ,IS_STRONG_LEAD = S.IS_STRONG_LEAD
   ,EVENT_LOG_COUNT = S.EVENT_LOG_COUNT
   ,LOGIN_COUNT = S.LOGIN_COUNT
   ,SHEET_COUNT = S.SHEET_COUNT
   ,SHARING_COUNT = S.SHARING_COUNT
   ,REPORT_COUNT = S.REPORT_COUNT
   ,COMPANY = S.COMPANY
   ,NUMBER_OF_EMPLOYEES = S.NUMBER_OF_EMPLOYEES
   ,CHURN_RISK_CATEGORY = S.CHURN_RISK_CATEGORY
   ,ROLE = S.ROLE
   ,USED_REMINDERS = S.USED_REMINDERS
   ,USED_BRANDED_WORKSPACE = S.USED_BRANDED_WORKSPACE
   ,USED_DRIVE_ATTACHMENT = S.USED_DRIVE_ATTACHMENT
   ,USED_EVERNOTE_ATTACHMENT = S.USED_EVERNOTE_ATTACHMENT
   ,USED_CELL_LINKING = S.USED_CELL_LINKING
   ,USED_CHANGE_VIEW = S.USED_CHANGE_VIEW
   ,DISCUSSION_COUNT = S.DISCUSSION_COUNT
   ,IMPORTED_SHEET_COUNT = S.IMPORTED_SHEET_COUNT
   ,TEMPLATE_COUNT = S.TEMPLATE_COUNT
   ,WEB_FORM_COUNT = S.WEB_FORM_COUNT
   ,COLUMN_PROPERTY_FORM_COUNT = S.COLUMN_PROPERTY_FORM_COUNT
   ,HIERARCHY_COUNT = S.HIERARCHY_COUNT
   ,ATTACHMENT_COUNT = S.ATTACHMENT_COUNT
   ,UPGRADE_WIZARD_PROGRESS = S.UPGRADE_WIZARD_PROGRESS
   ,INSERT_SOURCE = S.INSERT_SOURCE
   ,FIT_SCORE = S.FIT_SCORE
   ,FIT_RATING = S.FIT_RATING
   ,APP_BEHAVIOR_SCORE = S.APP_BEHAVIOR_SCORE
   ,APP_BEHAVIOR_SCORE_OLD = S.APP_BEHAVIOR_SCORE_OLD
   ,APP_BEHAVIOR_SCORE_NEW = S.APP_BEHAVIOR_SCORE_NEW
   ,RECURRING_BILLING_CANCELLED = S.RECURRING_BILLING_CANCELLED
   ,DOMAIN_OPT_OUT = S.DOMAIN_OPT_OUT
   ,APP_OPT_OUT = S.APP_OPT_OUT
   ,CONTAINER_COUNT = S.CONTAINER_COUNT
   ,SIGNUP_REQUEST_ID = S.SIGNUP_REQUEST_ID
   ,SIGNUP_TRACKING_APP_LAUNCH_TYPE = S.SIGNUP_TRACKING_APP_LAUNCH_TYPE
   ,USER_ACCOUNT_INSERT_BY_USER_ID = S.USER_ACCOUNT_INSERT_BY_USER_ID
   ,PARENT_PAYMENT_START_DATE_TIME = S.PARENT_PAYMENT_START_DATE_TIME
   ,PERSONA = S.PERSONA
   ,IP_REGION = S.IP_REGION
   ,ORGANIZATION_ROLES = S.ORGANIZATION_ROLES
   ,INFERRED_TITLE = S.INFERRED_TITLE
   ,I_OSAPP_LOGIN_COUNT = S.I_OSAPP_LOGIN_COUNT
   ,ANDROID_APP_LOGIN_COUNT = S.ANDROID_APP_LOGIN_COUNT
   ,HIGHEST_SHARED_SHEET_PERMISSION = S.HIGHEST_SHARED_SHEET_PERMISSION
   ,SOLUTIONS_USED = S.SOLUTIONS_USED
   ,SALESFORCE_OWNER_ROLE_AT_IMPORT = S.SALESFORCE_OWNER_ROLE_AT_IMPORT
   ,IP_CITY = S.IP_CITY
   ,IS_USER_AGREEMENT_ACCEPTED = S.IS_USER_AGREEMENT_ACCEPTED
   ,IMAGES_IN_GRID_COUNT = S.IMAGES_IN_GRID_COUNT
   ,ORGANIZATION_ID = S.ORGANIZATION_ID
   ,INFERRED_ROLE = S.INFERRED_ROLE
   ,DASHBOARDS_ENABLED_DATE_TIME = S.DASHBOARDS_ENABLED_DATE_TIME
   ,DASHBOARD_COUNT = S.DASHBOARD_COUNT
   ,SUCCESS_REP_EMAIL = S.SUCCESS_REP_EMAIL
   ,SUCCESS_REP_FIRST_NAME = S.SUCCESS_REP_FIRST_NAME
   ,SUCCESS_REP_LAST_NAME = S.SUCCESS_REP_LAST_NAME
   ,SUCCESS_REP_PHONE_NUMBER = S.SUCCESS_REP_PHONE_NUMBER
   ,ACCOUNT_HEALTH = S.ACCOUNT_HEALTH
   ,ACCOUNT_TIER = S.ACCOUNT_TIER
   ,ACCOUNT_CSADRIP_BUCKET = S.ACCOUNT_CSADRIP_BUCKET
   ,DOMAIN_OWNER_EMAIL = S.DOMAIN_OWNER_EMAIL
   ,DOMAIN_OWNER_FIRST_NAME = S.DOMAIN_OWNER_FIRST_NAME
   ,DOMAIN_OWNER_LAST_NAME = S.DOMAIN_OWNER_LAST_NAME
   ,DOMAIN_OWNER_TITLE = S.DOMAIN_OWNER_TITLE
   ,DOMAIN_OWNER_PHONE_NUMBER = S.DOMAIN_OWNER_PHONE_NUMBER
   ,ORG_PRODUCT_NAME = S.ORG_PRODUCT_NAME
   ,BONUS_LICENSE_LIMIT = S.BONUS_LICENSE_LIMIT
   ,ASSIGNED_LICENSE_COUNT = S.ASSIGNED_LICENSE_COUNT
   ,PENDING_LICENSE_COUNT = S.PENDING_LICENSE_COUNT
   ,LICENSE_TAGS = S.LICENSE_TAGS
   ,CARD_VIEW_VIEW_COUNT = S.CARD_VIEW_VIEW_COUNT
   ,LAST_BULLETIN_CLOSE_DATE_TIME = S.LAST_BULLETIN_CLOSE_DATE_TIME
   ,ACCOUNT_TERRITORY = S.ACCOUNT_TERRITORY
   ,PREVIOUS_USER_LIMIT = S.PREVIOUS_USER_LIMIT
   ,USER_TAGS = S.USER_TAGS
   ,OPTIMIZELY_BUCKETS = S.OPTIMIZELY_BUCKETS
   ,PAYMENT_TYPE = S.PAYMENT_TYPE
   ,CLICKED_IMPORT_PROJECT_COUNT = S.CLICKED_IMPORT_PROJECT_COUNT
   ,SIGNUP_LANDING_PAGE = S.SIGNUP_LANDING_PAGE
   ,SIGNUP_VARIATION = S.SIGNUP_VARIATION
;

SELECT '************************************* arc.marketo_upload REPLACE insert_Source LIKE ''%-newPP'' rows: ', (SELECT "number of rows inserted" + "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- **************************************************************************************************************************
-- FINISH Copy All tmp.marketo_leads To arc.marketo_upload Table
-- **************************************************************************************************************************



-- **************************************************************************************************************************
-- BEGIN Update all fields that need to be current
-- **************************************************************************************************************************


-- create table for all userAccount records that have changed
DROP TABLE IF EXISTS tmp.userAccount_marketoSync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.userAccount_marketoSync LIKE CORE.PUBLIC.user_Account;

-- find all the records in CORE.PUBLIC.user_Account that have changed recently
INSERT /*IGNORE*/ INTO tmp.userAccount_marketoSync
    SELECT ua.*
    FROM LEADFLOW.arc.marketo_upload mk_upload
        JOIN CORE.PUBLIC.user_Account ua ON mk_upload.user_ID = ua.user_ID
    WHERE ua.modify_Date_Time > $window_start_date_time
      AND ua.modify_Date_Time <= $window_end_date_time
-- AND ua.modify_Date_Time >= $marketoLookbackDateTime
   AND NOT EXISTS (
       SELECT 1
         FROM tmp.marketo_leads X
        WHERE X.user_ID = ua.user_ID
       )
    ORDER BY mk_upload.user_ID ASC
;
SELECT '************************************* userAccount changes: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- update the record if we can detect a change that we care about
-- Updated 2016-12-21 to account for amplified trial signup
-- UPDATE
UPDATE arc.marketo_upload mk_uploadx
   SET push_To_Marketo               = x.push_To_Marketo
      ,update_Date_Time              = x.update_Date_Time
      ,user_Account_Modify_Date_Time = x.user_Account_Modify_Date_Time
      ,email_Address                 = x.email_Address
      ,email_Domain                  = x.email_Domain
      ,website                       = x.website
      ,first_Name                    = x.first_Name
      ,last_Name                     = x.last_Name
      ,news_Flags                    = x.news_Flags
      ,app_Opt_Out                   = x.app_Opt_Out
      ,status_Flags                  = x.status_Flags
      ,is_User_Agreement_Accepted    = x.is_User_Agreement_Accepted
      ,locale                        = x.locale
      ,time_Zone                     = x.time_Zone
  FROM (
         SELECT mk_upload.user_ID
               ,GREATEST($updatePriority, mk_upload.push_To_Marketo) AS push_To_Marketo -- indicate record needs to be pushed, using GREATEST so we never lower the priority
               ,CURRENT_TIMESTAMP()::TIMESTAMP_NTZ AS update_Date_Time
               ,ua.modify_Date_Time AS user_Account_Modify_Date_Time -- reset the flag to indicate when it last changed
               ,ua.email_Address
               ,MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS email_Domain
               ,MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address) AS website -- uses same value as domain for now
               ,COALESCE(ua.first_Name, srfn.item_Value) AS first_Name
               ,COALESCE(MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name), MAIN.PUBLIC.MARKETO_LAST_NAME(srln.item_Value)) AS last_Name
               ,ua.news_Flags AS news_Flags
               ,BITNOT(BITAND(ua.news_Flags, 1)) AS app_Opt_Out
               ,ua.status_Flags AS status_Flags
               ,CASE WHEN BITAND(ua.status_Flags, 8) = 8 THEN 1 ELSE 0 END AS is_User_Agreement_Accepted -- LICENSED_ACCEPTED is 4th bit in status_Flags bitmask, which is 1000 in  (8 in decimal)
               ,ua.locale
               ,ua.time_Zone --  the timestamp gets updated and use the current record from history
           FROM arc.marketo_upload mk_upload
                JOIN tmp.userAccount_marketoSync ua ON mk_upload.user_ID = ua.user_ID
                LEFT JOIN ACCOUNT.PUBLIC.signup_Request_Tracking_Item srfn ON mk_upload.signup_Request_ID = srfn.signup_Request_ID AND srfn.item_Name = 'su_fname'
                LEFT JOIN ACCOUNT.PUBLIC.signup_Request_Tracking_Item srln ON mk_upload.signup_Request_ID = srln.signup_Request_ID AND srln.item_Name = 'su_lname'
          WHERE (mk_upload.email_Address != ua.email_Address /***COLLATE utf8mb4_unicode_520_ci***/ OR            -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
                 -- mk_upload.email_Domain != ua.email_Domain OR             -- don't need email_Domain or website because email_Address change will trigger these
                 COALESCE(mk_upload.first_Name, '') != COALESCE(ua.first_Name, srfn.item_Name, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR    -- could be null so use coalesce for null handling
                 COALESCE(mk_upload.last_Name, '') != COALESCE(MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name), srln.item_Name) /***COLLATE utf8mb4_unicode_520_ci***/ OR
                 COALESCE(mk_upload.news_Flags, '') != COALESCE(ua.news_Flags, '') OR
                 COALESCE(mk_upload.status_Flags, '') != COALESCE(ua.status_Flags, '') OR
                 COALESCE(mk_upload.locale, '') != COALESCE(ua.locale, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR
                 COALESCE(mk_upload.time_Zone, '') != COALESCE(ua.time_Zone, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR
                 COALESCE(mk_upload.user_Account_Modify_Date_Time, '') != COALESCE(ua.modify_Date_Time, '')
                )
            AND mk_upload.user_Account_Modify_Date_Time <= ua.modify_Date_Time  -- only if the modify_Date_Time is changed in the right direction
            AND mk_upload.push_To_Marketo != 10  -- Fix for MKTO1603. This prevents creating duplicate lead records (by user_ID) in Marketo if user changes email address immediately after creating account
       ) x
 WHERE mk_uploadx.user_ID = x.user_ID
;
-- ORIGINAL
-- UPDATE arc.marketo_upload mk_upload

-- SET
--     mk_upload.push_To_Marketo             = GREATEST($updatePriority, mk_upload.push_To_Marketo), -- indicate record needs to be pushed, using GREATEST so we never lower the priority
--     mk_upload.update_Date_Time            = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
--     mk_upload.user_Account_Modify_Date_Time = ua.modify_Date_Time, -- reset the flag to indicate when it last changed
--     mk_upload.email_Address              = ua.email_Address,
--     mk_upload.email_Domain               = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address),
--     mk_upload.website                   = MAIN.PUBLIC.MARKETO_EXTRACT_DOMAIN(ua.email_Address), -- uses same value as domain for now
--     mk_upload.first_Name                 = ua.first_Name,
--     mk_upload.last_Name                  = MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name),
--     mk_upload.news_Flags                 = ua.news_Flags,
--     mk_upload.app_Opt_Out                 = NOT (ua.news_Flags & 1),
--     mk_upload.status_Flags               = ua.status_Flags,
--     mk_upload.is_User_Agreement_Accepted   = CASE WHEN ua.status_Flags & 8 = 8 THEN 1 ELSE 0 END, -- LICENSED_ACCEPTED is 4th bit in status_Flags bitmask, which is 1000 in  (8 in decimal)
--     mk_upload.locale                    = ua.locale,
--     mk_upload.time_Zone                  = ua.time_Zone
-- --  the timestamp gets updated and use the current record from history 
-- WHERE
--     (mk_upload.email_Address != ua.email_Address /***COLLATE utf8mb4_unicode_520_ci***/ OR             -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
--      -- mk_upload.email_Domain != ua.email_Domain OR              -- don't need email_Domain or website because email_Address change will trigger these
--      COALESCE(mk_upload.first_Name, '') != COALESCE(ua.first_Name, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR -- could be null so use coalesce for null handling
--      COALESCE(mk_upload.last_Name, '') != MAIN.PUBLIC.MARKETO_LAST_NAME(ua.last_Name) /***COLLATE utf8mb4_unicode_520_ci***/ OR
--      COALESCE(mk_upload.news_Flags, '') != COALESCE(ua.news_Flags, '') OR
--      COALESCE(mk_upload.status_Flags, '') != COALESCE(ua.status_Flags, '') OR
--      COALESCE(mk_upload.locale, '') != COALESCE(ua.locale, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR
--      COALESCE(mk_upload.time_Zone, '') != COALESCE(ua.time_Zone, '') /***COLLATE utf8mb4_unicode_520_ci***/ OR
--      COALESCE(mk_upload.user_Account_Modify_Date_Time, '') != COALESCE(ua.modify_Date_Time, '')
--     )
--     AND mk_upload.user_Account_Modify_Date_Time <= ua.modify_Date_Time  -- only if the modify_Date_Time is changed in the right direction
--     AND mk_upload.push_To_Marketo != 10  -- Fix for MKTO1603. This prevents creating duplicate lead records (by user_ID) in Marketo if user changes email address immediately after creating account
-- ;
SELECT '************************************* arc.marketo_upload rows updated from userAccount changes: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- BEGIN userAccount.is_Org_Domain updates for LEADFLOW.arc.marketo_upload (updated 2015-12-03)
-- This is done in two queries in order to eliminate locks on MAIN tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to arc.marketo_upload and execute updates
-- *********************************************************************************************************************
-- Query--1: Retrieve changes made to userAccount.is_Org_Domain records
-- Need to separate out is_Org_Domain flag because the if the email address changes, the domain needs to be updated first before
-- we can check to see if that domain is an Org domain
DROP TABLE IF EXISTS tmp.userAccount_ISPDomains_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.userAccount_ISPDomains_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT
        mu.user_ID,
        ispd.domain
    FROM arc.marketo_upload mu
        JOIN tmp.userAccount_marketoSync ua ON mu.user_ID = ua.user_ID
        LEFT OUTER JOIN MAIN.arc.ISPDomains ispd ON mu.email_Domain = ispd.domain
    WHERE
        (
            (ispd.domain IS NOT NULL AND mu.is_Org_Domain = 1)
            OR (ispd.domain IS NULL AND mu.is_Org_Domain = 0)
        )
        AND mu.user_Account_Modify_Date_Time <= ua.modify_Date_Time
    ORDER BY mu.user_ID ASC
;
SELECT '************************************* temp arc.marketo_upload rows updated from userAccount.is_Org_Domain changes: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update arc.marketo_upload with the userAccount.is_Org_Domain changes

UPDATE arc.marketo_upload mu
SET mu.is_Org_Domain = CASE WHEN ispd.domain IS NULL THEN 1 ELSE 0 END,
    mu.push_To_Marketo = GREATEST($updatePriority, mu.push_To_Marketo),  -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mu.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ

FROM tmp.userAccount_ISPDomains_to_sync ispd

WHERE  mu.user_ID = ispd.user_ID
;
SELECT '************************************* update arc.marketo_upload rows updated from userAccount.is_Org_Domain changes: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
-- *********************************************************************************************************************
-- FINISH userAccount.is_Org_Domain updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************


DROP TABLE IF EXISTS tmp.payment_Profile_marketoSync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.payment_Profile_marketoSync LIKE CORE.PUBLIC.payment_Profile;

INSERT /*IGNORE*/ INTO tmp.payment_Profile_marketoSync
    SELECT pp.*
    FROM CORE.PUBLIC.payment_Profile pp
--    WHERE pp.modify_Date_Time >= $marketoLookbackDateTime
    WHERE pp.modify_Date_Time > $window_start_date_time
      AND pp.modify_Date_Time <= $window_end_date_time
   AND NOT EXISTS (
       SELECT 1
         FROM tmp.payment_Profile_marketoSync X
        WHERE X.payment_Profile_ID = pp.payment_Profile_ID
       )
    ORDER BY pp.owner_ID ASC
    -- SELECT pp.*
    -- FROM LEADFLOW.arc.marketo_upload mk_upload

    -- WHERE pp.modify_Date_Time >= $marketoLookbackDateTime
    -- ORDER BY mk_upload.user_ID ASC
;
SELECT '************************************* payment_Profile changes: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- BEGIN Payment Profile updates for LEADFLOW.arc.marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to arc.marketo_upload and execute updates
-- *********************************************************************************************************************

-- Query--1: Retrieve changes made to payment_Profile records
DROP TABLE IF EXISTS coreTableData_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS coreTableData_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT
        mu.user_ID,
        hce.exchange_Rate                                        hceexchange_Rate,
        org.main_Contact_User_ID                                   orgmain_Contact_User_ID,
        org.name                                                orgname,
        org.organization_ID                                      orgorganization_ID,
        ppp.bill_To_Address1                                      pppbill_To_Address1,
        ppp.bill_To_Address2                                      pppbill_To_Address2,
        ppp.bill_To_City                                          pppbill_To_City,
        ppp.bill_To_Country_Code                                   pppbill_To_Country_Code,
        ppp.bill_To_Post_Code                                      pppbill_To_Post_Code,
        ppp.bill_To_Region_Code                                    pppbill_To_Region_Code,
        ppp.currency_Code                                        pppcurrency_Code,
        ppp.payment_End_Date_Time                                  ppppayment_End_Date_Time,
        ppp.payment_Flags                                        ppppayment_Flags,
        ppp.payment_Profile_ID                                    ppppayment_Profile_ID,
        ppp.payment_Start_Date_Time                                ppppayment_Start_Date_Time,
        ppp.payment_Term                                         ppppayment_Term,
        ppp.plan_Rate                                            pppplan_Rate,
        ppp.primary_Contact_Phone                                 pppprimary_Contact_Phone,
        pp.account_Type                                          ppaccount_Type,
        pp.bill_To_Address1                                       ppbill_To_Address1,
        pp.bill_To_Address2                                       ppbill_To_Address2,
        pp.bill_To_City                                           ppbill_To_City,
        pp.bill_To_Country_Code                                    ppbill_To_Country_Code,
        pp.bill_To_Post_Code                                       ppbill_To_Post_Code,
        pp.bill_To_Region_Code                                     ppbill_To_Region_Code,
        pp.currency_Code                                         ppcurrency_Code,
        pp.modify_Date_Time                                       ppmodify_Date_Time,
        LEADFLOW.PUBLIC.SMARTSHEET_NEXTPAYMENTDATE(
            CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
            pp.next_Payment_Date,
            ppp.next_Payment_Date,
            pp.payment_Term,
            pp.actual_Last_Payment_Date,
            ppp.actual_Last_Payment_Date,
            pp.account_Type,
            pp.payment_Start_Date_Time,
            ppp.payment_Start_Date_Time,
            COALESCE(pp.promo_Code, ''),
            COALESCE(ppp.promo_Code, ''),
            pp.insert_Date_Time,
            ppp.insert_Date_Time)                                 ppnext_Payment_Date,
        pp.payment_Profile_ID                                     pppayment_Profile_ID,
        pp.parent_Payment_Profile_ID                               ppparent_Payment_Profile_ID,
        pp.payment_End_Date_Time                                   pppayment_End_Date_Time,
        pp.payment_Flags                                         pppayment_Flags,
        LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTSTARTDATETIME(
            pp.account_Type,
            pp.product_ID,
            pp.payment_Start_Date_Time,
            ppp.payment_Start_Date_Time)                           pppayment_Start_Date_Time,
        pp.payment_Term                                          pppayment_Term,
        pp.plan_Rate                                             ppplan_Rate,
        pp.primary_Contact_Phone                                  ppprimary_Contact_Phone,
        IFF(ppp.payment_Profile_ID IS NULL,
           COALESCE(pp.primary_Contact_Phone, sr.item_Value),
           IFF(org.main_Contact_User_ID = mu.user_ID,
              COALESCE(ppp.primary_Contact_Phone, sr.item_Value),
              COALESCE(pp.primary_Contact_Phone, sr.item_Value)))  primary_Contact_Phone,
        pp.product_ID                                            ppproduct_ID,
        pp.user_Limit                                            ppuser_Limit,
        mu.user_Limit                                            previous_User_Limit,
        IFF (ppp.payment_Profile_ID IS NULL,
           LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type),
           IFF (org.main_Contact_User_ID = mu.user_ID,
              LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(ppp.payment_Type),
              LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type))) pppayment_Type,
        pp.actual_Last_Payment_Date                                ppactual_Last_Payment_Date,
        pp.promo_Code                                            pppromo_Code,
        pp.insert_Date_Time                                       ppinsert_Date_Time
    FROM LEADFLOW.arc.marketo_upload mu
        JOIN tmp.payment_Profile_marketoSync pp ON mu.payment_Profile_ID = pp.payment_Profile_ID
        LEFT OUTER JOIN CORE.PUBLIC.payment_Profile ppp ON pp.parent_Payment_Profile_ID = ppp.payment_Profile_ID
        LEFT OUTER JOIN CORE.PUBLIC.organization org ON ppp.owner_ID = org.organization_ID AND ppp.account_Type = 3  --  mu.user_ID = org.main_Contact_User_IDs
        LEFT OUTER JOIN CORE.hist.currency_Exchange hce ON pp.currency_Code = hce.currency_Code AND
                                                                pp.payment_Start_Date_Time BETWEEN hce.modify_Date_Time AND hce.hist_effective_Thru_Date_Time
        LEFT OUTER JOIN ACCOUNT.PUBLIC.signup_Request_Tracking_Item sr ON mu.signup_Request_ID = sr.signup_Request_ID AND sr.item_Name = 'su_phone'
    WHERE
        (
            COALESCE(mu.product_Name, '') != MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(pp.product_ID) /***COLLATE utf8mb4_unicode_520_ci***/ OR   -- one of the fields we care about changes, this will minimize unneeded pushes to marketo
            COALESCE(mu.user_Limit, -1) != COALESCE(pp.user_Limit, -1) OR
            COALESCE(mu.parent_Payment_Profile_ID, 0) != COALESCE(pp.parent_Payment_Profile_ID, 0) OR   -- could be null so use coalesce for null handling
            COALESCE(mu.payment_Start_Date_Time, '') != COALESCE(LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTSTARTDATETIME(pp.account_Type, pp.product_ID, pp.payment_Start_Date_Time, ppp.payment_Start_Date_Time), '') OR
            (COALESCE(mu.trial_End_Date_Date_Time, '') != COALESCE(pp.payment_End_Date_Time, ppp.payment_End_Date_Time) AND pp.product_ID = 1) OR
            COALESCE(mu.next_Payment_Date, '') != COALESCE(LEADFLOW.PUBLIC.SMARTSHEET_NEXTPAYMENTDATE(CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, pp.next_Payment_Date, ppp.next_Payment_Date, pp.payment_Term, pp.actual_Last_Payment_Date, ppp.actual_Last_Payment_Date, pp.account_Type, pp.payment_Start_Date_Time, ppp.payment_Start_Date_Time, COALESCE(pp.promo_Code, ''), COALESCE(ppp.promo_Code, ''), pp.insert_Date_Time, ppp.insert_Date_Time), '') OR  -- could be null so use coalesce for null handling
            COALESCE(mu.payment_Term, -1) != pp.payment_Term OR
            (COALESCE(mu.plan_Rate, -1) != pp.plan_Rate AND ppp.payment_Profile_ID IS NULL) OR  -- the plan_Rate is changed and there is no parent
            (COALESCE(mu.plan_Rate, -1) != COALESCE(ppp.plan_Rate, -1) AND org.main_Contact_User_ID = mu.user_ID) OR  -- the plan_Rate is changed from the parent value
            COALESCE(mu.currency_Code, '') != pp.currency_Code /***COLLATE utf8mb4_unicode_520_ci***/ OR
            COALESCE(mu.recurring_Billing_Cancelled, -1) !=  LEADFLOW.PUBLIC.MARKETO_RECURRING_BILLING_CANCELLED(ppp.payment_Profile_ID, org.main_Contact_User_ID, mu.user_ID, pp.payment_Flags, ppp.payment_Flags) OR

            (COALESCE(mu.primary_Contact_Phone, '') != COALESCE(pp.primary_Contact_Phone, sr.item_Value, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the primary_Contact_Phone is changed and there is no parent
            (COALESCE(mu.primary_Contact_Phone, '') != COALESCE(ppp.primary_Contact_Phone, sr.item_Value, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID) OR  -- the primary_Contact_Phone is changed from the parent value

            (COALESCE(mu.bill_To_Address, '') != MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(pp.bill_To_Address1, pp.bill_To_Address2) /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the bill_To_Address is changed and there is no parent
            (COALESCE(mu.bill_To_Address, '') != MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(ppp.bill_To_Address1, ppp.bill_To_Address2) /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID ) OR  -- the bill_To_Address is changed from the parent value

            (COALESCE(mu.bill_To_City, '') != COALESCE(pp.bill_To_City, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the bill_To_City is changed and there is no parent
            (COALESCE(mu.bill_To_City, '') != COALESCE(ppp.bill_To_City, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID ) OR  -- the bill_To_City is changed from the parent value

            (COALESCE(mu.bill_To_Region_Code, '') != COALESCE(pp.bill_To_Region_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the bill_To_Region_Code is changed and there is no parent
            (COALESCE(mu.bill_To_Region_Code, '') != COALESCE(ppp.bill_To_Region_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID ) OR  -- the bill_To_Region_Code is changed from the parent value

            (COALESCE(mu.bill_To_Post_Code, '') != COALESCE(pp.bill_To_Post_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the bill_To_Post_Code is changed and there is no parent
            (COALESCE(mu.bill_To_Post_Code, '') != COALESCE(ppp.bill_To_Post_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID ) OR  -- the bill_To_Post_Code is changed from the parent value

            (COALESCE(mu.bill_To_Country_Code, '') != COALESCE(pp.bill_To_Country_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND ppp.payment_Profile_ID IS NULL) OR  -- the bill_To_Country_Code is changed and there is no parent
            (COALESCE(mu.bill_To_Country_Code, '') != COALESCE(ppp.bill_To_Country_Code, '') /***COLLATE utf8mb4_unicode_520_ci***/ AND org.main_Contact_User_ID = mu.user_ID ) OR  -- the bill_To_Country_Code is changed from the parent value

            COALESCE(mu.payment_Type, -1) != IFF (ppp.payment_Profile_ID IS NULL, LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type), IFF(org.main_Contact_User_ID = mu.user_ID, LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(ppp.payment_Type), LEADFLOW.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type)))
        )
        AND COALESCE(mu.pp_Modify_Date_Time, '') <= COALESCE(pp.modify_Date_Time, '')
    ORDER BY mu.user_ID ASC
;
SELECT '************************************* temporary table rows grabbed from core database: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update arc.marketo_upload with the payment_Profile changes

UPDATE LEADFLOW.arc.marketo_upload mu
SET mu.push_To_Marketo              = GREATEST($updatePriority, mu.push_To_Marketo), -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mu.update_Date_Time             = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
    mu.pp_Modify_Date_Time           = tmp.ppmodify_Date_Time, -- reset the flag to indicate when it last changed
    mu.product_Name                = MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(tmp.ppproduct_ID),
    mu.user_Limit                  = tmp.ppuser_Limit,
    mu.previous_User_Limit          = tmp.previous_User_Limit,
    mu.payment_Start_Date_Time       = tmp.pppayment_Start_Date_Time,
    -- get the date from the parent, will be null if no parent
    mu.parent_Payment_Start_Date_Time = tmp.ppppayment_Start_Date_Time,
    mu.next_Payment_Date            = tmp.ppnext_Payment_Date,
    mu.payment_Type                = tmp.pppayment_Type,
    mu.payment_Term                = tmp.pppayment_Term,
    mu.plan_Rate                   =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppplan_Rate -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppplan_Rate -- owner, use the plan_Rate from the org for the owner
            ELSE tmp.ppplan_Rate -- member, so use profile value
        END,
    mu.currency_Code               = tmp.ppcurrency_Code,
    mu.monthly_Plan_Rate_USD        = COALESCE(
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL
                THEN
                    CASE
                        WHEN tmp.ppcurrency_Code = 'USD' THEN tmp.ppplan_Rate / tmp.pppayment_Term
                        ELSE (tmp.ppplan_Rate / tmp.hceexchange_Rate) / tmp.pppayment_Term
                    END -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID
                THEN --  owner, use the plan_Rate from the org for the owner
                    CASE
                        WHEN tmp.pppcurrency_Code = 'USD' THEN tmp.pppplan_Rate / tmp.ppppayment_Term
                        ELSE (tmp.pppplan_Rate / tmp.hceexchange_Rate) / tmp.ppppayment_Term
                    END
            ELSE
                CASE
                    WHEN tmp.ppcurrency_Code = 'USD' THEN tmp.ppplan_Rate / tmp.pppayment_Term
                    ELSE (tmp.ppplan_Rate / tmp.hceexchange_Rate) / tmp.pppayment_Term
                END -- member, so use profile value
        END, 0
    ),
    mu.parent_Payment_Profile_ID     = tmp.ppparent_Payment_Profile_ID,
    -- Updated 2016-12-21 to account for amplified trial signup
    -- UPDATE
    mu.primary_Contact_Phone        = tmp.primary_Contact_Phone,
    -- ORIGINAL
    -- mu.primary_Contact_Phone =
    --     CASE
    --         WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppprimary_Contact_Phone                          -- no parent, so use profile value
    --         WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppprimary_Contact_Phone  -- owner, use the primary_Contact_Phone from the org for the owner
    --         ELSE tmp.ppprimary_Contact_Phone                                                                 -- member, so use profile value
    --     END,
    -- combine to address fields into one bill_To_Address
    mu.bill_To_Address              =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(tmp.ppbill_To_Address1, tmp.ppbill_To_Address2) -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(tmp.pppbill_To_Address1, tmp.pppbill_To_Address2) -- owner, use the bill_To_Address from the org for the owner
            ELSE MAIN.PUBLIC.MARKETO_BILLING_ADDRESS(tmp.ppbill_To_Address1, tmp.ppbill_To_Address2) -- member, so use profile value
        END,
    mu.bill_To_City                 =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppbill_To_City -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppbill_To_City -- owner, use the bill_To_City from the org for the owner
            ELSE tmp.ppbill_To_City -- member, so use profile value
        END,
    mu.bill_To_Region_Code           =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppbill_To_Region_Code -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppbill_To_Region_Code -- owner, use the bill_To_Region_Code from the org for the owner
            ELSE tmp.ppbill_To_Region_Code -- member, so use profile value
        END,
    mu.bill_To_Post_Code             =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppbill_To_Post_Code -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppbill_To_Post_Code -- owner, use the bill_To_Post_Code from the org for the owner
            ELSE tmp.ppbill_To_Post_Code -- member, so use profile value
        END,
    mu.bill_To_Country_Code          =
        CASE
            WHEN tmp.ppppayment_Profile_ID IS NULL THEN tmp.ppbill_To_Country_Code -- no parent, so use profile value
            WHEN tmp.orgmain_Contact_User_ID = mu.user_ID THEN tmp.pppbill_To_Country_Code -- owner, use the bill_To_Country_Code from the org for the owner
            ELSE tmp.ppbill_To_Country_Code -- member, so use profile value
        END,
    mu.trial_Start_Date_Time         =
        CASE
            WHEN tmp.ppproduct_ID = 1 THEN tmp.pppayment_Start_Date_Time -- 1=in trial
            ELSE mu.trial_Start_Date_Time -- don't over write, this will stay the start date time of last trial
        END,
    -- get the end date from the payment_Profile, but it will be null if it is a team trial, if so, get it from the parent
    mu.trial_End_Date_Date_Time       =
        CASE
            WHEN tmp.ppproduct_ID = 1 THEN COALESCE(tmp.pppayment_End_Date_Time, tmp.ppppayment_End_Date_Time) -- 1=in trial,
            ELSE mu.trial_End_Date_Date_Time -- don't over write, this will stay the end date time of last trial
        END,
    mu.organization_Name           = tmp.orgname,
    mu.organization_ID             = tmp.orgorganization_ID,
    -- account_Type changes should be triggered by parent_Payment_Profile_ID changes
    mu.team_Trial                  =
        CASE
            WHEN tmp.ppaccount_Type = 2 AND tmp.ppproduct_ID = 1 THEN 1
            ELSE 0
        END, -- team_Trial - set for member(account_Type = 2) of trial(product = 1)
    mu.account_Role                = MAIN.PUBLIC.MARKETO_ACCOUNT_ROLE(mu.payment_Profile_ID, tmp.ppppayment_Profile_ID, tmp.orgmain_Contact_User_ID, mu.user_ID),
    mu.recurring_Billing_Cancelled  = LEADFLOW.PUBLIC.MARKETO_RECURRING_BILLING_CANCELLED(tmp.ppppayment_Profile_ID, tmp.orgmain_Contact_User_ID,
                                                                                 mu.user_ID, tmp.pppayment_Flags, tmp.ppppayment_Flags)

FROM coreTableData_to_sync tmp

WHERE  mu.user_ID = tmp.user_ID
;
SELECT '************************************* arc.marketo_upload rows updated from payment_Profile changes: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- FINISH Payment Profile updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************


-- When a change is made to payment_Flags for organizations --

UPDATE arc.marketo_upload mu
SET 
    mu.push_To_Marketo             = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time            = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, -- since this is always an org, use the parent
    mu.recurring_Billing_Cancelled = LEADFLOW.PUBLIC.MARKETO_RECURRING_BILLING_CANCELLED(ppp.payment_Profile_ID, organization.main_Contact_User_ID, mu.user_ID,
                                                                       ppp.payment_Flags, ppp.payment_Flags)
FROM tmp.payment_Profile_marketoSync ppp
JOIN CORE.PUBLIC.organization ON ppp.owner_ID = organization.organization_ID

WHERE COALESCE(mu.recurring_Billing_Cancelled, -1) != LEADFLOW.PUBLIC.MARKETO_RECURRING_BILLING_CANCELLED(ppp.payment_Profile_ID, organization.main_Contact_User_ID, mu.user_ID, ppp.payment_Flags, ppp.payment_Flags)
    AND COALESCE(mu.pp_Modify_Date_Time, '') <= COALESCE(ppp.modify_Date_Time, '')

AND  mu.parent_Payment_Profile_ID = ppp.payment_Profile_ID AND ppp.account_Type = 3
AND organization.main_Contact_User_ID = mu.user_ID
;
SELECT '************************************* organization payment_Flags rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

----#####################################################################################################################
--  Update is_Trial_Restart for all users with recent payment profile changes.
--  (added 2017-08-10)
----#####################################################################################################################

DROP TABLE IF EXISTS tmp.is_trial_restart;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.is_trial_restart
/*(PRIMARY KEY (payment_Profile_ID))*/ AS
        SELECT
            pp.payment_Profile_ID,
            MAX(CASE WHEN hppPrev.product_ID IS NULL
                THEN 0
                ELSE 1 END) newIsTrialRestart
        FROM tmp.payment_Profile_marketoSync pp
            LEFT OUTER JOIN CORE.hist.payment_Profile hpp
                ON pp.payment_Profile_ID = hpp.payment_Profile_ID
            LEFT OUTER JOIN CORE.hist.payment_Profile hppPrev
                ON hpp.payment_Profile_ID = hppPrev.payment_Profile_ID
                   --  This accounts for 1 second delays in the hist_effective_Thru_Date_Time
                   AND (hpp.modify_Date_Time = DATEADD(SECOND, 1, hppPrev.hist_effective_Thru_Date_Time)
                        OR hpp.modify_Date_Time = hppPrev.hist_effective_Thru_Date_Time)
                   --  This will ignore previous records that were trials
                   AND (hppPrev.product_ID != 1 OR hppPrev.product_ID IS NULL)
        WHERE
            hpp.product_ID = 1
            AND (hppPrev.product_ID != 1 OR hppPrev.product_ID IS NULL)
            AND NOT (hpp.modify_Date_Time = hpp.hist_effective_Thru_Date_Time OR
                     hpp.modify_Date_Time = DATEADD(SECOND, 1, hpp.hist_effective_Thru_Date_Time)) -- Ignore zero or negative second trials.
        GROUP BY pp.payment_Profile_ID;
SELECT '************************************* is_Trial_Restart rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;



UPDATE LEADFLOW.arc.marketo_upload mu
SET 
    mu.is_Trial_Restart = tmp.newIsTrialRestart,
    mu.push_To_Marketo  = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.is_trial_restart tmp

WHERE mu.is_Trial_Restart != tmp.newIsTrialRestart
AND  mu.payment_Profile_ID = tmp.payment_Profile_ID;
SELECT '************************************* is_Trial_Restart updates: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- Update org_Product_Name for all users who are members of organizations, whether licensed or not.
-- (added 2016-04-25)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp.org_pp_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.org_pp_updates
/*(PRIMARY KEY (user_ID))*/ AS
    SELECT mu.user_ID
    FROM arc.marketo_upload mu
        JOIN CORE.PUBLIC.organization_User_Role our ON mu.user_ID = our.user_ID
        JOIN CORE.PUBLIC.payment_Profile ppp ON our.organization_ID = ppp.owner_ID
--    WHERE our.modify_Date_Time >= $marketoLookbackDateTime
    WHERE our.modify_Date_Time > $window_start_date_time
      AND our.modify_Date_Time <= $window_end_date_time
    UNION
    SELECT mu.user_ID
    FROM arc.marketo_upload mu
        JOIN CORE.PUBLIC.organization_User_Role our ON mu.user_ID = our.user_ID
        JOIN CORE.PUBLIC.payment_Profile ppp ON our.organization_ID = ppp.owner_ID
--    WHERE ppp.modify_Date_Time >= $marketoLookbackDateTime
    WHERE ppp.modify_Date_Time > $window_start_date_time
      AND ppp.modify_Date_Time <= $window_end_date_time
    ORDER BY user_ID
;
SELECT '************************************* organizationUser_Role and payment_Profile updates: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

DROP TABLE IF EXISTS tmp.max_org_product_name;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.max_org_product_name
/*(PRIMARY KEY (user_ID))*/ AS
    SELECT
        mu.user_ID,
        -- Triple nested function: 1. Get max product by rank, 2. convert rank back to product_ID, 3. convert product_ID to product name.
        MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(MAIN.PUBLIC.SMARTSHEET_PRODUCTRANKCONVERT(MAX(MAIN.PUBLIC.SMARTSHEET_PRODUCTRANK(ppp.product_ID)))) maxOrgProduct
    FROM arc.marketo_upload mu
        JOIN tmp.org_pp_updates uids ON mu.user_ID = uids.user_ID
        LEFT JOIN CORE.PUBLIC.organization_User_Role our ON mu.user_ID = our.user_ID AND our.state != 3              -- Ignore declined users
        LEFT JOIN CORE.PUBLIC.organization org ON our.organization_ID = org.organization_ID AND org.state = 1      -- Include only active orgs
        LEFT JOIN CORE.PUBLIC.payment_Profile ppp ON our.organization_ID = ppp.owner_ID AND ppp.account_Type = 3     -- Just want org accounts
    GROUP BY mu.user_ID
;
SELECT '************************************* getting org_Product_Name rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc.marketo_upload mu
SET 
    mu.org_Product_Name = mp.maxOrgProduct,
    mu.push_To_Marketo  = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.max_org_product_name mp

WHERE COALESCE(mu.org_Product_Name, '') != COALESCE(mp.maxOrgProduct, '') -- /***COLLATE utf8mb4_unicode_520_ci***/

AND  mu.user_ID = mp.user_ID;
SELECT '************************************* updating org_Product_Name rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- (added 2016-06-23)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp.org_user_role_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.org_user_role_updates
/*(PRIMARY KEY (user_ID, organization_ID))*/ AS
    SELECT
        mu.user_ID,
        uid.organization_ID,
        IFNULL(ANY_VALUE(ppp.user_Limit), 0)      paid_LicenseLimit,
        IFNULL(ANY_VALUE(ppp.bonus_User_Count), 0) bonus_License_Limit,
        IFNULL(SUM(IFF(our.state = 1, 1, 0)), 0) assigned_License_Count,
        IFNULL(SUM(IFF(our.state = 2, 1, 0)), 0) pending_License_Count
    FROM arc.marketo_upload mu
        JOIN (
                 (SELECT
                      our.user_ID,
                      our.organization_ID
                  FROM CORE.PUBLIC.organization_User_Role our
                      JOIN (
                               SELECT organization_ID
                               FROM CORE.PUBLIC.organization_User_Role
--                               WHERE modify_Date_Time >= $marketoLookbackDateTime
                               WHERE modify_Date_Time > $window_start_date_time
                                 AND modify_Date_Time <= $window_end_date_time
                               GROUP BY organization_ID
                           ) updates ON our.organization_ID = updates.organization_ID
                  WHERE
                      our.role = 'USER_ADMIN'
                      AND our.state = 1)
                 UNION
                 (SELECT
                      main_Contact_User_ID,
                      organization_ID
                  FROM CORE.PUBLIC.organization
--                  WHERE modify_Date_Time >= $marketoLookbackDateTime
                 WHERE modify_Date_Time > $window_start_date_time
                   AND modify_Date_Time <= $window_end_date_time
                      AND state = 1)
                 ORDER BY 1 ASC
             ) uid ON mu.user_ID = uid.user_ID
        LEFT JOIN CORE.PUBLIC.payment_Profile ppp ON
                                                    uid.organization_ID = ppp.owner_ID
                                                    AND ppp.account_Type = 3
        LEFT JOIN CORE.PUBLIC.organization_User_Role our ON
                                                          uid.organization_ID = our.organization_ID
                                                          AND our.role = 'LICENSE_USER'
                                                          AND our.state IN (1, 2)
    GROUP BY mu.user_ID, uid.organization_ID
;
SELECT '************************************* getting org license limit rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc.marketo_upload mu
SET 
    mu.user_Limit            = lic.paid_LicenseLimit,
    mu.bonus_License_Limit    = lic.bonus_License_Limit,
    mu.assigned_License_Count = lic.assigned_License_Count,
    mu.pending_License_Count  = lic.pending_License_Count,
    mu.push_To_Marketo        = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time       = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.org_user_role_updates lic

WHERE COALESCE(mu.user_Limit, -9999) != lic.paid_LicenseLimit
    OR COALESCE(mu.bonus_License_Limit, -9999) != lic.bonus_License_Limit
    OR COALESCE(mu.assigned_License_Count, -9999) != lic.assigned_License_Count
    OR COALESCE(mu.pending_License_Count, -9999) != lic.pending_License_Count

AND  mu.user_ID = lic.user_ID;
SELECT '************************************* updating org license limit rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update organization license tags
-- (added 2016-07-05)
-- *********************************************************************************************************************

DROP TABLE IF EXISTS tmp.lic_tag_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.lic_tag_updates
/*(INDEX (user_ID))*/ AS
    SELECT
        lic.user_ID,
        LEADFLOW.PUBLIC.MARKETO_LICENSE_TAG(ANY_VALUE(lic.assigned_License_Count), ANY_VALUE(lic.pending_License_Count), ANY_VALUE(lic.paid_LicenseLimit),
                                     ANY_VALUE(mu.previous_User_Limit), COUNT(our.organization_User_Role_ID)) license_Tags
    FROM arc.marketo_upload mu
        JOIN tmp.org_user_role_updates lic ON mu.user_ID = lic.user_ID
        LEFT JOIN CORE.PUBLIC.organization_User_Role our
            ON lic.organization_ID = our.organization_ID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insert_Date_Time >= DATEADD(DAY, -7, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
    GROUP BY lic.user_ID, lic.organization_ID
;
SELECT '************************************* getting org license tag rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc.marketo_upload mu
SET 
    mu.license_Tags    = tag.license_Tags,
    mu.push_To_Marketo  = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.lic_tag_updates tag

WHERE COALESCE(mu.license_Tags, '') != COALESCE(tag.license_Tags, '') -- /***COLLATE utf8mb4_unicode_520_ci***/

AND  mu.user_ID = tag.user_ID;
SELECT '************************************* updating org license tag rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update last bulletin close date time
-- (added 2016-07-06)
-- *********************************************************************************************************************

UPDATE arc.marketo_upload mu
SET
    mu.last_Bulletin_Close_Date_Time = maxClose.maxClose_DateTime,
    mu.push_To_Marketo             = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time            = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM (
             SELECT
                 ce.insert_By_User_ID,
                 MAX(ce.event_Date_Time) maxClose_DateTime
             FROM MAIN.arc.client_Event_Bulletin ce
--             WHERE ce.event_Date_Time >= $marketoLookbackDateTime
               WHERE ce.event_Date_Time > $window_start_date_time
                 AND ce.event_Date_Time <= $window_end_date_time
                 AND ce.object_ID = 10717  -- 'Desktop - Bulletin Bar' object
                 AND ce.action_ID = 2 -- 'Close' action
             GROUP BY ce.insert_By_User_ID
             ORDER BY ce.insert_By_User_ID
         ) maxClose
WHERE mu.user_ID = maxClose.insert_By_User_ID
  AND COALESCE(mu.last_Bulletin_Close_Date_Time, '') != COALESCE(maxClose.maxClose_DateTime, '')
;
SELECT '************************************* updating last bulletin close date time rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update dashboardsEnabledStart_Date for all user_ConfigSetting and orgConfigSetting changes in the last day.
-- config_Property_ID = 4024 AND value_Boolean = 1 means the dashboards feature is enabled for a user or org
-- *********************************************************************************************************************

UPDATE arc.marketo_upload mux
   SET dashboards_Enabled_Date_Time = x.dashboards_Enabled_Date_Time
      ,push_To_Marketo = x.push_To_Marketo
      ,update_Date_Time = x.update_Date_Time
  FROM (
         SELECT mu.user_ID
               ,CASE
                  WHEN ocs.is_Final = 1 AND ocs.value_Boolean = 1 THEN ocs.modify_Date_Time
                  WHEN ocs.is_Final = 1 AND ocs.value_Boolean = 0 THEN NULL
                  WHEN ucs.value_Boolean = 1 THEN ucs.modify_Date_Time
                  WHEN ucs.value_Boolean = 0 THEN NULL
                  WHEN ocs.value_Boolean = 1 THEN ocs.modify_Date_Time
                  ELSE NULL
                END AS dashboards_Enabled_Date_Time
               ,GREATEST($updatePriority, mu.push_To_Marketo) AS push_To_Marketo
               ,CURRENT_TIMESTAMP()::TIMESTAMP_NTZ AS update_Date_Time
           FROM arc.marketo_upload mu
                JOIN (
                  -- Get all org setting users
                  SELECT our.user_ID
                    FROM ACCOUNT.PUBLIC.org_Config_Setting ocs
                         JOIN CORE.PUBLIC.organization_User_Role our ON ocs.organization_ID = our.organization_ID
--                   WHERE ocs.modify_Date_Time >= $marketoLookbackDateTime
                   WHERE ocs.modify_Date_Time > $window_start_date_time
                     AND ocs.modify_Date_Time <= $window_end_date_time
                     AND ocs.config_Property_ID = 4024
                   GROUP BY our.user_ID
                  UNION
                  -- Get all user setting users
                  SELECT ucs.user_ID
                    FROM ACCOUNT.PUBLIC.user_Config_Setting ucs
--                   WHERE ucs.modify_Date_Time >= $marketoLookbackDateTime
                   WHERE ucs.modify_Date_Time > $window_start_date_time
                     AND ucs.modify_Date_Time <= $window_end_date_time
                     AND ucs.config_Property_ID = 4024
                  UNION
                  -- Get all current users to check if their enable date should be cleared
                  SELECT user_ID
                    FROM arc.marketo_upload
                   WHERE dashboards_Enabled_Date_Time IS NOT NULL
                  ORDER BY user_ID
                ) uid
                LEFT OUTER JOIN ACCOUNT.PUBLIC.org_Config_Setting ocs ON mu.organization_ID = ocs.organization_ID AND ocs.config_Property_ID = 4024
                LEFT OUTER JOIN ACCOUNT.PUBLIC.user_Config_Setting ucs ON mu.user_ID = ucs.user_ID AND ucs.config_Property_ID = 4024
    WHERE COALESCE(mu.dashboards_Enabled_Date_Time, '1900-01-01') !=
                  CASE
                    WHEN ocs.is_Final = 1 AND ocs.value_Boolean = 1 THEN ocs.modify_Date_Time
                    WHEN ocs.is_Final = 1 AND ocs.value_Boolean = 0 THEN '1900-01-01'
                    WHEN ucs.value_Boolean = 1 THEN ucs.modify_Date_Time
                    WHEN ucs.value_Boolean = 0 THEN '1900-01-01'
                    WHEN ocs.value_Boolean = 1 THEN ocs.modify_Date_Time
                    ELSE '1900-01-01'
                  END
       ) x
 WHERE mux.user_ID = x.user_ID
;
SELECT '************************************* dashboards_Enabled_Date_Time rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;



-- *********************************************************************************************************************
-- BEGIN salesMarketingUserData updates for LEADFLOW.arc.marketo_upload (updated 2015-10-26)
-- This is done in two queries in order to eliminate locks on CORE tables. Even though the session
-- is running as READ UNCOMMITTED, UPDATE...SELECT or UPDATE...JOIN queries will still put locks on the
-- SELECT/JOIN tables.
--
--     Query--1: Grab the needed data from core tables and put it in a temporary table.
--     Query--2: Join temp table to tmp.marketo_leads and execute updates
-- *********************************************************************************************************************

-- Query--1: Retrieve role information changes made to salesMarketingUserData records
DROP TABLE IF EXISTS tmp.salesMarketingUserData_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.salesMarketingUserData_to_sync
/*(INDEX (user_ID))*/ AS
    SELECT smud.user_ID, smud.data_Value FROM arc.marketo_upload mk_upload
    JOIN CORE.PUBLIC.sales_Marketing_User_Data smud ON smud.user_ID = mk_upload.user_ID AND smud.data_Key = 'role'
    WHERE mk_upload.role IS NULL AND smud.data_Value IS NOT NULL  -- only update if need and have value
    ORDER BY mk_upload.user_ID ASC
;
SELECT '************************************* getting salesMarketingUserData rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Query--2: Update arc.marketo_upload with changes

UPDATE arc.marketo_upload mk_upload
SET mk_upload.role = tsmud.data_Value,
    mk_upload.push_To_Marketo = GREATEST($updatePriority, mk_upload.push_To_Marketo),   -- indicate record needs to be pushed, using GREATEST so we never lower the priority
    mk_upload.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ

FROM tmp.salesMarketingUserData_to_sync tsmud

WHERE  mk_upload.user_Id = tsmud.user_ID
;
SELECT '************************************* updating salesMarketingUserData rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- *********************************************************************************************************************
-- FINISH salesMarketingUserData updates for LEADFLOW.arc.marketo_upload
-- *********************************************************************************************************************


-- *********************************************************************************************************************
-- Update organization_Roles for customers in the GE organization. We are adding an additional field to distinguish
-- whether a GE customer was added by a specific user in order to include them in specialized Marketo campaigns.
-- (added 2016-01-26 to account for special GE request; see MKTO1817 for details)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp.ge_orgRoles;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.ge_orgRoles
/*(PRIMARY KEY (user_ID))*/ AS
    SELECT
        our.user_ID
       ,ARRAY_TO_STRING(ARRAY_AGG(DISTINCT our.role) WITHIN GROUP (ORDER BY our.role ASC), ';') ||
        CASE
          WHEN ANY_VALUE(org.main_Contact_User_ID) IS NOT NULL
            THEN ';' || 'MAIN_CONTACT'
          ELSE ''
        END ||
        ';' || CONCAT('LICENSE_ADDED_BY:', COALESCE(ANY_VALUE(our2.insert_By_User_ID), 0)) AS new_OrgRoles
    FROM CORE.PUBLIC.organization_User_Role our
        JOIN arc.marketo_upload mu ON our.user_ID = mu.user_ID AND our.organization_ID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
        LEFT JOIN CORE.PUBLIC.organization_User_Role our2 ON our.user_ID = our2.user_ID AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insert_By_User_ID to be specifically from the LICENSE_USER role
        LEFT JOIN CORE.PUBLIC.organization org ON mu.user_ID = org.main_Contact_User_ID AND org.state = 1
    GROUP BY our.user_ID
    ORDER BY our.user_ID ASC
;
SELECT '************************************* getting GE organization_Roles rows: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc.marketo_upload mu
SET 
    mu.organization_Roles = orgRole.new_OrgRoles,
    mu.push_To_Marketo     = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time    = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
FROM tmp.ge_orgRoles orgRole

WHERE COALESCE(mu.organization_Roles, '') != COALESCE(orgRole.new_OrgRoles, '') /***COLLATE utf8mb4_unicode_520_ci***/

AND  mu.user_ID = orgRole.user_ID;
SELECT '************************************* updating GE organization_Roles rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *********************************************************************************************************************
-- Update customer success rep info for all leads where the CS info for the SFDC account has changed recently.
-- Need to create temp table of just recent data so the query is fast.
-- (added 2016-03-22)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp.sfdc_domain_account_rep;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.sfdc_domain_account_rep
/*(INDEX (Domain_Name_URL__c))*/ AS
    SELECT
        d.Domain_Name_URL__c,
        csu.Email     csEmail,
        csu.First_Name csFirst_Name,
        csu.Last_Name  csLast_Name,
        csu.Phone     csPhone,
        dou.Email     doEmail,
        dou.First_Name doFirst_Name,
        dou.Last_Name  doLast_Name,
        dou.Title     doTitle,
        dou.Phone     doPhone
    FROM SFDC.PUBLIC.domain d
        JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
        LEFT JOIN SFDC.PUBLIC.user csu ON a.Customer_Success__c = csu.Id
        LEFT JOIN SFDC.PUBLIC.user dou ON d.Owner_Id = dou.Id AND dou.ID != '00540000002nu18AAA' --  Exclude Andrew Imhoff.
--    WHERE (a.Last_Modified_Date >= $marketoLookbackDateTime OR d.Last_Modified_Date >= $marketoLookbackDateTime)
     WHERE (
             (a.Last_Modified_Date > $window_start_date_time AND a.Last_Modified_Date <= $window_end_date_time) OR
             (d.Last_Modified_Date > $window_start_date_time AND d.Last_Modified_Date <= $window_end_date_time)
           )
        --  Ignore ISP domains. Use MAIN.arc.ISPDomains instead of is_Org_Domain field to avoid join on arc.marketo_upload.
        AND d.Domain_Name_URL__c NOT IN (SELECT domain
                                         FROM MAIN.arc.ISPDomains)
;
SELECT '************************************* sfdc domain and account reps: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

DROP TABLE IF EXISTS tmp.sfdc_domain_account_user;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp.sfdc_domain_account_user
/*(INDEX (user_ID))*/ AS
    SELECT
        mu.user_ID,
        d.*
    FROM arc.marketo_upload mu
        JOIN tmp.sfdc_domain_account_rep d ON mu.email_Domain = d.Domain_Name_URL__c
        LEFT OUTER JOIN CORE.PUBLIC.organization org ON mu.user_ID = org.main_Contact_User_ID AND org.state = 1
    WHERE
        (COALESCE(mu.success_Rep_Email, '') != COALESCE(d.csEmail, '')
         OR COALESCE(mu.success_Rep_First_Name, '') != COALESCE(d.csFirst_Name, '')
         OR COALESCE(mu.success_Rep_Last_Name, '') != COALESCE(d.csLast_Name, '')
         OR COALESCE(mu.success_Rep_Phone_Number, '') != COALESCE(d.csPhone, '')
         OR COALESCE(mu.domain_Owner_Email, '') != COALESCE(d.doEmail, '')
         OR COALESCE(mu.domain_Owner_First_Name, '') != COALESCE(d.doFirst_Name, '')
         OR COALESCE(mu.domain_Owner_Last_Name, '') != COALESCE(d.doLast_Name, '')
         OR COALESCE(mu.domain_Owner_Title, '') != COALESCE(d.doTitle, '')
         OR COALESCE(mu.domain_Owner_Phone_Number, '') != COALESCE(d.doPhone, ''))
        --  Don't want to reintroduce leads who may have been purged.
        AND
        (org.main_Contact_User_ID IS NOT NULL --  MKTO3303 include all active org main contacts
         OR mu.product_Name IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR mu.org_Product_Name IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR COALESCE(mu.last_Login, '2000-01-01') >= DATEADD(DAY, -180, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ))  --  MKTO3290 include paid, trial, or active in last 180 days
    ORDER BY mu.user_ID ASC  --  Need to order by user_ID to prevent deadlocks.
;
SELECT '************************************* sfdc account changes: ', 0 AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc.marketo_upload mu
SET mu.success_Rep_Email        = d.csEmail,
    mu.success_Rep_First_Name    = d.csFirst_Name,
    mu.success_Rep_Last_Name     = d.csLast_Name,
    mu.success_Rep_Phone_Number  = d.csPhone,
    mu.domain_Owner_Email       = d.doEmail,
    mu.domain_Owner_First_Name   = d.doFirst_Name,
    mu.domain_Owner_Last_Name    = d.doLast_Name,
    mu.domain_Owner_Title       = d.doTitle,
    mu.domain_Owner_Phone_Number = d.doPhone,
    mu.push_To_Marketo          = GREATEST($updatePriority, mu.push_To_Marketo),
    mu.update_Date_Time         = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ

FROM tmp.sfdc_domain_account_user d

WHERE  mu.user_ID = d.user_ID
;
SELECT '************************************* customer success rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- **************************************************************************************************************************
-- FINISH Update all fields that need to be current
-- **************************************************************************************************************************


-- Get AB Test Variations
-- 2015-01-16 toddj - disabling until code can be added to check to see if the value is changing before flipping the push_To_Marketo flag is flipped
--
-- drop table if exists tmp.update_users;
-- create table tmp.update_users as
-- select user_Id
-- from arc.marketo_upload
-- where insert_Date_Time > (select DATEADD(minute, -10, max(max_sscore_ua_Insert_Date_Time)) from arc.marketo_upload_control where active = 0);
-- --create index idxtmp on tmp.update_users(user_Id);
--
-- UPDATE arc.marketo_upload amu
-- SET amu.push_To_Marketo = GREATEST($updatePriority, amu.push_To_Marketo),
-- amu.update_Date_Time = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
-- ABTests =
-- (
--         SELECT
--         GROUP_CONCAT(DISTINCT site_Setting_Element_Name,':',FLOOR(value_Numeric) ORDER BY site_Setting_Element_Value_ID ASC SEPARATOR ';') AS ABTests
--         FROM ACCOUNT.PUBLIC.site_Setting_Element_Value ssev
--         WHERE site_Setting_Element_Name LIKE '%SS_ABTEST%'
--         AND amu.user_ID = ssev.user_ID
--         AND ssev.user_ID in (select user_Id from tmp.update_users)
--         GROUP BY ssev.user_ID
--         HAVING ABTests is not null
-- )
-- where amu.ABTests is null
-- and amu.user_ID in (select user_Id from tmp.update_users);
-- SELECT '************************************* ABTests rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- Log current state of the Marketo sync queue
INSERT INTO LEADFLOW.arc.marketo_upload_sync_history
SELECT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'marketoLeadsUploadCondeep.sql', muf.priority, COUNT(mu.user_ID)
FROM LEADFLOW.arc.marketo_upload_flags muf
LEFT OUTER JOIN LEADFLOW.arc.marketo_upload mu ON muf.priority = mu.push_To_Marketo
WHERE muf.priority != 0
GROUP BY muf.priority
ORDER BY muf.priority DESC
;
SELECT '************************************* updating sync queue history rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- debug
--SHOW VARIABLES LIKE 'tx_isolation';


-- **************************************************************************************************************************
-- Miscellaneous ETL queries not related to LEADFLOW
-- These are needed to capture data for reporting needs.
-- **************************************************************************************************************************

-- Get latest bulletin client event
SET maxBulletinClientEventID = (SELECT MAX(client_Event_ID) FROM MAIN.arc.client_Event_Bulletin)
;
SELECT $maxBulletinClientEventID;

-- Capture all bulletin client events since the lastest one.
INSERT /*IGNORE*/ INTO MAIN.arc.client_Event_Bulletin
    SELECT
        ce.*,
        sl.user_ID insert_By_User_ID
    FROM LOG.PUBLIC.client_Event ce
        LEFT JOIN CORE.PUBLIC.session_Log sl ON ce.session_Log_ID = sl.session_Log_ID
    WHERE
        ce.client_Event_ID >= $maxBulletinClientEventID
        -- bulletin objects: 10717, 'Desktop - Bulletin Bar'; 10718, 'Desktop - Bulletin Bar link'; 13650, 'Settings Form - Show Marketing Bulletins'
        AND ce.object_ID IN (10717, 10718)
   AND NOT EXISTS (
       SELECT 1
         FROM MAIN.arc.client_Event_Bulletin X
        WHERE X.client_Event_ID = ce.client_Event_ID
       )
;
SELECT '************************************* bulletin client event rows: ', (SELECT "number of rows inserted" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Correct NULL insert_By_User_ID values that may have resulted from out-of-sync replication

UPDATE MAIN.arc.client_Event_Bulletin ce
SET  ce.insert_By_User_ID = sl.user_ID
FROM CORE.PUBLIC.session_Log sl

WHERE ce.insert_By_User_ID IS NULL

AND  ce.session_Log_ID = sl.session_Log_ID;
SELECT '************************************* bulletin client event null insert_By_User_ID rows: ', (SELECT "number of rows updated" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))) AS ROWCOUNT, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

INSERT INTO LEADFLOW.PUBLIC.BATCH (LAST_BATCH_DATE_TIME, time_now) VALUES ($window_end_date_time, current_timestamp())
;

