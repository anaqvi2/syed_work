/***************************************************************************************************************************
 * This is running once a night, so it doesn't need to be as fast as the every 5 minute pull...			                   *
 * Updated 2015-12-01 to start using temp tables in order to minimize locking MAIN and CORE tables.           *
 ***************************************************************************************************************************/-- --SET $@sql_mode = '';

SELECT CURRENT_DATABASE();

-- debug
--SHOW VARIABLES LIKE 'tx_isolation';
-- prevent us from locking any tables in core that might slow/stop replication
--SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
-- debug
--SHOW VARIABLES LIKE 'tx_isolation';

-- debug - test longer wait timeout
SET tokudb_lock_timeout = 300000;
-- Variable Declaration
SET v_process_Id = (SELECT  0 );
--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'Total');
--CALL MAIN.utl_logProcessStart('marketo_nightly_update.sql',NULL,'','INFO',5, $v_process_Id);

-- Begin section for nightly batch process fields
SELECT '************************************* marketo_nightly_update.sql start: ' , CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SET marketoNightlyStart_DateTime = (SELECT  CURRENT_TIMESTAMP()::TIMESTAMP_NTZ );
SELECT $marketoNightlyStart_DateTime;

SET highestNightlyUpdatePriority = (SELECT  6 );  	 -- updates for new leads from previous day plus more urgent data
SET mediumHighNightlyUpdatePriority = (SELECT  5 );  -- lead scoring
SET mediumNightlyUpdatePriority = (SELECT  4 );   	 -- activity indicators
SET lowestNightlyUpdatePriority = (SELECT  2 );   	 -- domain rollup type info

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.signup_Source');

-- back fill with the friendly signup information

UPDATE arc_marketo_upload 
LEFT OUTER 
SET marketo_upload.signup_Bucket = CASE signup_Source.bucket IS NULL	-- viral bucket users don't have signup record
											WHEN 1 THEN 'Viral'
											ELSE signup_Source.bucket
										END,
	marketo_upload.signup_Source = CASE signup_Source.source_Friendly IS NULL
											WHEN 1 THEN 'Sharing'
											ELSE signup_Source.source_Friendly
										END,
	marketo_upload.signup_Sub_Source = CASE signup_Source.sub_Source_Friendly IS NULL
											WHEN 1 THEN 'Sharing'
											ELSE signup_Source.sub_Source_Friendly
										END,
	marketo_upload.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, push_To_Marketo),							-- flip the bit back to indicate record needs to be pushed.
	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()


FROM MAIN.rpt.signup_Source 
WHERE COALESCE(marketo_upload.signup_Bucket, '') != COALESCE(signup_Source.bucket, 'Viral') OR  -- most viral leads won't have a rpt_signup_Source record, so if it is null, treat it as Viral
	COALESCE(marketo_upload.signup_Source, '') != COALESCE(signup_Source.source_Friendly, 'Sharing') OR
	COALESCE(marketo_upload.signup_Sub_Source, '') != COALESCE(rpt_signup_Source.subsource_Friendly, 'Sharing')   	

AND marketo_upload.user_ID = signup_Source.user_ID  

;
SELECT '************************************* rpt_signup_Source rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.signup_Source');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'history_Highest_Plan temp');

-- *************************************************************************************************************************
-- Update the highest paid plan from history
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_hist_payment_Profile_max_Product;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_hist_payment_Profile_max_Product
(INDEX (user_ID))
SELECT mu.user_ID, mp.payment_Profile_ID, mp.max_Product FROM arc_marketo_upload mu
JOIN (
    SELECT pp.payment_Profile_ID,
    CASE MAX(MAIN.SMARTSHEET_PRODUCTRANK(pp.product_ID))
        WHEN 1 THEN 'Cancelled'
        WHEN 2 THEN 'Trial'
        WHEN 3 THEN 'Free'
        WHEN 4 THEN 'Student'
        WHEN 5 THEN 'Basic'
        WHEN 6 THEN 'Advanced'
        WHEN 7 THEN 'Premium'
        WHEN 8 THEN 'Team'
        WHEN 9 THEN 'Team Plus'
        WHEN 10 THEN 'Business'
        WHEN 11 THEN 'Enterprise_Legacy'
        WHEN 12 THEN 'Enterprise'
    END AS max_Product
    FROM CORE.hist.payment_Profile pp
    WHERE pp.product_ID IN (3, 4, 5, 6, 7, 8, 10, 11) AND pp.plan_Rate > 0  -- Explicitly search among just paid plans. Exclude 'Cancelled', 'Trial', 'Free', and 'Student'.
    GROUP BY pp.payment_Profile_ID
) mp ON mu.payment_Profile_ID = mp.payment_Profile_ID
WHERE COALESCE(mu.history_Highest_Plan, '') != COALESCE(mp.max_Product, '')
;
SELECT '************************************* temp history_Highest_Plan rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'history_Highest_Plan temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'history_Highest_Plan updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.history_Highest_Plan = mp.max_Product,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_hist_payment_Profile_max_Product mp 
WHERE mu.user_ID = mp.user_ID

;
SELECT '************************************* update history_Highest_Plan rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'history_Highest_Plan updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.container_Counts_By_User');

-- Sheet, report, import, branded workspace counts

UPDATE arc_marketo_upload mu

SET mu.sheet_Count = ccu.sheet_Count,
    mu.report_Count = ccu.report_Count,
    mu.imported_Sheet_Count = ccu.imported_Sheet_Count,
    mu.template_Count = ccu.template_Count,
    mu.used_Branded_Workspace =
        CASE WHEN ccu.branded_Workspace_Count > 0
            THEN 1 ELSE 0 END,
    mu.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.container_Counts_By_User ccu 
WHERE COALESCE(mu.sheet_Count, '') != COALESCE(ccu.sheet_Count, '') OR
    COALESCE(mu.report_Count, '') != COALESCE(ccu.report_Count, '') OR
    COALESCE(mu.imported_Sheet_Count, '') != COALESCE(ccu.imported_Sheet_Count, '') OR
    COALESCE(mu.template_Count, '') != COALESCE(ccu.template_Count, '') OR
    (COALESCE(mu.used_Branded_Workspace, 0) = 0 AND COALESCE(ccu.branded_Workspace_Count, 0) > 0) -- only push if they had not used branded Workspace before, but now have a count

AND mu.user_ID = ccu.user_ID

;
SELECT '************************************* sheet_Count, report_Count rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.container_Counts_By_User');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'event_Log_Count updates');

-- Lifetime Activity Count

UPDATE arc_marketo_upload 

SET marketo_upload.event_Log_Count = clcua.lifetime_Log_Count,
	marketo_upload.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, push_To_Marketo),
	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()	

FROM MAIN.rpt.client_Log_Counts_By_User_Archived clcua 
WHERE COALESCE(marketo_upload.event_Log_Count, '') != COALESCE(clcua.lifetime_Log_Count, '')

AND marketo_upload.user_ID = clcua.user_ID

;
SELECT '************************************* event_Log_Count rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'event_Log_Count updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.login_Count_Total');

-- Login Activity

UPDATE arc_marketo_upload mu

SET mu.last_Login = lct.last_Login,
    mu.login_Count = lct.login_Count,
    mu.last_Mobile_Login = lct.last_Mobile_Login,
    mu.i_OSApp_Login_Count = lct.native_Ios_Session_Count,
    mu.android_App_Login_Count = lct.native_Android_Session_Count,
    
    
    mu.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.login_Count_Total lct 
WHERE COALESCE(mu.last_Login, '') != COALESCE(lct.last_Login, '') OR
    COALESCE(mu.last_Mobile_Login, '') != COALESCE(lct.last_Mobile_Login, '') OR
    COALESCE(mu.login_Count, '') != COALESCE(lct.login_Count, '') OR
    COALESCE(mu.i_OSApp_Login_Count, '') != COALESCE(lct.native_Ios_Session_Count, '') OR
    COALESCE(mu.android_App_Login_Count, '') != COALESCE(lct.native_Android_Session_Count, '')

AND mu.user_ID = lct.user_ID

;
SELECT '************************************* rpt_login_Count_Total rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.login_Count_Total');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.feature_Count_Rollup_By_User');

-- Added webForm count, used_Reminders, used_Cell_Linking, hieracrhyCount, used_Drive_Attachment

UPDATE arc_marketo_upload mu

SET mu.sharing_Count = fcru.sharing_Count,
    mu.discussion_Count = fcru.discussion_Created_Count,
    mu.attachment_Count = fcru.attachment_Created_Count,
    mu.web_Form_Count = fcru.web_Form_Count,
    
    mu.hierarchy_Count = fcru.hierarchy_Count,
    mu.column_Property_Form_Count = fcru.column_Property_Form_Count,
    mu.used_Change_View =
        CASE WHEN fcru.used_Change_View > 0
            THEN 1 ELSE 0 END,

    mu.images_In_Grid_Count = fcru.images_In_Grid_Count,
    mu.card_View_View_Count = fcru.card_View_View_Count,
    mu.highest_Shared_Sheet_Permission = LEADFLOW.MARKETO_SHARE_PERMISSION(fcru.highest_Shared_Sheet_Permission),
    mu.used_Reminders =
        CASE WHEN fcru.reminder_Count > 0
            THEN 1 ELSE 0 END,
    mu.used_Cell_Linking =
        CASE WHEN fcru.cell_Link_Count > 0
            THEN 1 ELSE 0 END,
    mu.used_Drive_Attachment =
        CASE WHEN fcru.google_Drive_Attachment_Count > 0
            THEN 1 ELSE 0 END,
    mu.used_Evernote_Attachment =
        CASE WHEN fcru.evernote_Attachment_Count > 0
            THEN 1 ELSE 0 END,
    mu.clicked_Import_Project_Count = fcru.clicked_Import_Project,
    mu.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.feature_Count_Rollup_By_User fcru 
WHERE COALESCE(mu.sharing_Count, '') != COALESCE(fcru.sharing_Count, '') OR  	-- coalesce using '' instead of 0 forces pushing 0 into marketo
    COALESCE(mu.discussion_Count, '') != COALESCE(fcru.discussion_Created_Count, '') OR
    COALESCE(mu.attachment_Count, '') != COALESCE(fcru.attachment_Created_Count, '') OR
    COALESCE(mu.web_Form_Count, '') != COALESCE(fcru.web_Form_Count, '') OR
    COALESCE(mu.hierarchy_Count, '') != COALESCE(fcru.hierarchy_Count, '') OR
    COALESCE(mu.column_Property_Form_Count, '') != COALESCE(fcru.column_Property_Form_Count, '') OR
    (COALESCE(mu.used_Change_View, 0) = 0 AND COALESCE(fcru.used_Change_View, 0) > 0) OR -- only push if they had not used change view before, but now have a count
    COALESCE(mu.images_In_Grid_Count, '') != COALESCE(fcru.images_In_Grid_Count, '') OR
    COALESCE(mu.card_View_View_Count, '') != COALESCE(fcru.card_View_View_Count, '') OR
    COALESCE(mu.highest_Shared_Sheet_Permission, '') != LEADFLOW.MARKETO_SHARE_PERMISSION(fcru.highest_Shared_Sheet_Permission) OR
    (COALESCE(mu.used_Reminders, 0) = 0 AND COALESCE(fcru.reminder_Count, 0) > 0) OR -- only push if they had not used reminders before, but now have a count
    (COALESCE(mu.used_Cell_Linking, 0) = 0 AND COALESCE(fcru.cell_Link_Count, 0) > 0) OR -- only push if they had not used cell linking before, but now have a count
    (COALESCE(mu.used_Drive_Attachment, 0) = 0 AND COALESCE(fcru.google_Drive_Attachment_Count, 0) > 0) OR
    (COALESCE(mu.used_Evernote_Attachment, 0) = 0 AND COALESCE(fcru.evernote_Attachment_Count, 0) > 0) OR
    COALESCE(mu.clicked_Import_Project_Count, '') != COALESCE(fcru.clicked_Import_Project, '')

AND mu.user_ID = fcru.user_ID

;
SELECT '************************************* rpt_featureCountRollupByUser rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.feature_Count_Rollup_By_User');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.dashboard_Count_By_User');

-- Added webForm count, used_Reminders, used_Cell_Linking, hieracrhyCount, used_Drive_Attachment

UPDATE arc_marketo_upload mu
    
SET mu.dashboard_Count = dcbu.dashboards_Created,
    mu.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.dashboard_Count_By_User dcbu 
WHERE COALESCE(mu.dashboard_Count, '') != COALESCE(dcbu.dashboards_Created, '')

AND mu.user_ID = dcbu.user_ID

;
SELECT '************************************* rpt_dashboard_CountByUser rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.dashboard_Count_By_User');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'clickedProjectImportCount');

-- Added webForm count, used_Reminders, used_Cell_Linking, hieracrhyCount, used_Drive_Attachment
UPDATE arc_marketo_upload mu
SET
    mu.user_Tags       = LEADFLOW.MARKETO_IMPORT_MS_PROJECT(mu.user_Tags, mu.clicked_Import_Project_Count),
    mu.push_To_Marketo  = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.user_Tags, '') != COALESCE(LEADFLOW.MARKETO_IMPORT_MS_PROJECT(mu.user_Tags, mu.clicked_Import_Project_Count), '');
SELECT '************************************* clickedProjectImportCount rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'clickedProjectImportCount');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.arc.Daily_Well_Qualified_Leads temp');

-- *************************************************************************************************************************
-- Well Qualified
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_arc_DailyWell_QualifiedLeads_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_arc_DailyWell_QualifiedLeads_to_sync
(INDEX (user_ID))
SELECT wql.user_ID FROM arc_marketo_upload mu
JOIN MAIN.arc.Daily_Well_Qualified_Leads wql ON mu.user_ID = wql.user_ID
WHERE COALESCE(mu.is_Ever_Well_Qualified, '') != 1
;
SELECT '************************************* temp is_Ever_Well_Qualified rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.arc.Daily_Well_Qualified_Leads temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.arc.Daily_Well_Qualified_Leads updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.is_Ever_Well_Qualified = 1,
    mu.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_arc_DailyWell_QualifiedLeads_to_sync wql 
WHERE mu.user_ID = wql.user_ID

;
SELECT '************************************* update is_Ever_Well_Qualified rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.arc.Daily_Well_Qualified_Leads updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'is_Strong_Lead updates');

-- Strong Lead

UPDATE arc_marketo_upload 

SET marketo_upload.is_Strong_Lead = 1,
	marketo_upload.push_To_Marketo = GREATEST($mediumNightlyUpdatePriority, push_To_Marketo),
	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()		

FROM MAIN.rpt.client_Log_Counts_By_User_Archived 
WHERE COALESCE(marketo_upload.is_Strong_Lead, '') != 1 AND client_Log_Counts_By_User_Archived.first_Day_Log_Count  > 150 

AND marketo_upload.user_ID = client_Log_Counts_By_User_Archived.user_ID

;
SELECT '************************************* is_Strong_Lead rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'is_Strong_Lead updates');

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.paid_Domains');

-- Update highest domain product

UPDATE arc_marketo_upload mu
LEFT OUTER 
SET mu.domains_Highest_Plan = pd.Max_Product,
    mu.push_To_Marketo = GREATEST($lowestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.paid_Domains pd 
WHERE COALESCE(mu.domains_Highest_Plan, '') != COALESCE(pd.Max_Product, '')
    AND mu.is_Org_Domain = 1  -- Filter out ISP domains. Highest paid plan data for an ISP domain are not helpful.

AND mu.email_Domain = pd.main_Contact_Domain

;
SELECT '************************************* domains_Highest_Plan rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.paid_Domains');


-- could be used to set is_Org_Domain flag if needed, right now handled every 5 minutes
-- 
UPDATE arc_marketo_upload 
-- LEFT OUTER 
SET marketo_upload.is_Org_Domain = CASE WHEN ISPDomains.domain IS NULL THEN 1 ELSE 0 END,
-- 	marketo_upload.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, push_To_Marketo),
-- 	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()	
-- 
FROM MAIN.arc.ISPDomains 
WHERE (ISPDomains.domain IS NOT NULL AND marketo_upload.is_Org_Domain = 1)  OR (ISPDomains.domain IS NULL AND marketo_upload.is_Org_Domain = 0)
-- 
AND marketo_upload.email_Domain = ISPDomains.domain
-- 
;


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup setting temp');

-- *************************************************************************************************************************
-- Update domain rollup info
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_domainRollup_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_domainRollup_to_sync
(INDEX (user_ID))
SELECT mu.user_ID, dr.domain, dr.google_Apps_Domain FROM arc_marketo_upload mu
LEFT OUTER JOIN MAIN.rpt.domain_Rollup dr ON mu.email_Domain = dr.domain
WHERE
    COALESCE(mu.is_Google_Apps_Installed_Domain, 0) != COALESCE(dr.google_Apps_Domain, 0)
    -- OR COALESCE(mu.domain_Use_In_Past_Year, 0) != COALESCE(dr.users_Logged_In_Past12_Months, 0)  -- MKTO0340
    -- OR COALESCE(mu.current_Domain_Trials, 0) != COALESCE(dr.users_In_Trial, 0))              -- MKTO0340
    AND mu.is_Org_Domain = 1 -- set domain fields only when its a real domain
;
SELECT '************************************* temp rpt_domainRollup setting rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup setting temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup setting updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.is_Google_Apps_Installed_Domain = dr.google_Apps_Domain,
-- 	mu.domain_Use_In_Past_Year = dr.users_Logged_In_Past12_Months,  -- MKTO0340
-- 	mu.current_Domain_Trials = dr.users_In_Trial,               -- MKTO0340
	mu.push_To_Marketo = GREATEST($lowestNightlyUpdatePriority, mu.push_To_Marketo),
	mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_rpt_domainRollup_to_sync dr 
WHERE mu.user_ID = dr.user_ID

;
SELECT '************************************* update rpt_domainRollup setting rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup setting updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup clearing temp');

-- *************************************************************************************************************************
-- Clear domain rollup info
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_domainRollup_clear_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_domainRollup_clear_to_sync
(INDEX (user_ID))
SELECT mu.user_ID, dr.domain FROM arc_marketo_upload mu
LEFT OUTER JOIN MAIN.rpt.domain_Rollup dr ON mu.email_Domain = dr.domain
WHERE
    COALESCE(mu.is_Google_Apps_Installed_Domain, 0) != 0
    -- OR COALESCE(mu.domain_Use_In_Past_Year, 0) != 0  -- MKTO0340
    -- OR COALESCE(mu.current_Domain_Trials, 0) != 0) -- MKTO0340
    AND mu.is_Org_Domain = 0 -- clear these values if it not an org domain anymore
;
SELECT '************************************* temp rpt_domainRollup clearing rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup clearing temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup clearing updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.is_Google_Apps_Installed_Domain = 0,
    --	mu.domain_Use_In_Past_Year = 0, -- MKTO0340
    --	mu.current_Domain_Trials = 0, -- MKTO0340
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_rpt_domainRollup_clear_to_sync dr 
WHERE mu.user_ID = dr.user_ID

;
SELECT '************************************* update rpt_domainRollup clearing rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.domain_Rollup clearing updates');


-- *************************************************************************************************************************
-- Lock debugging
-- *************************************************************************************************************************
-- SELECT COUNT(*), information_schema.tokudb_locks.*, pl.* FROM information_schema.tokudb_locks

-- WHERE locks_table_schema != 'WORKSPACE'
-- GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
-- ;
-- SELECT '************************************* lock debugging : ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


-- *************************************************************************************************************************
-- Debugging
-- *************************************************************************************************************************-- --SHOW VARIABLES LIKE 'tx_isolation'-- ;-- EXPLAIN-- UPDATE arc_marketo_upload mu-- LEFT OUTER JOIN MAIN.rpt.user_IPLocation ul ON mu.user_ID = ul.user_ID-- SET--     mu.ip_Country = ul.ip_Country,--     mu.ip_Region = ul.ip_Region,--     mu.ip_City = ul.ip_City,--     mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),--     mu.update_Date_Time = CURRENT_TIMESTAMP()-- WHERE--     (mu.ip_Country IS NULL AND ul.ip_Country IS NOT NULL) OR -- only update if need and have value--     (mu.ip_Region IS NULL AND ul.ip_Region IS NOT NULL) OR--     (mu.ip_City IS NULL AND ul.ip_City IS NOT NULL)-- ;-- SHOW FULL PROCESSLIST-- ;

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.user_IPLocation');

-- Update country information

UPDATE arc_marketo_upload mu
LEFT OUTER 
SET mu.ip_Country = ul.ip_Country,
    mu.ip_Region = ul.ip_Region,
    mu.ip_City = ul.ip_City,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.user_IPLocation ul 
WHERE (mu.ip_Country IS NULL AND ul.ip_Country IS NOT NULL) OR -- only update if need and have value
    (mu.ip_Region IS NULL AND ul.ip_Region IS NOT NULL) OR
    (mu.ip_City IS NULL AND ul.ip_City IS NOT NULL)

AND mu.user_ID = ul.user_ID

;
SELECT '************************************* rpt_userIPLocation rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.user_IPLocation');


-- debug
SELECT $@tokudb_last_lock_timeout;


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'ACCOUNT.PUBLIC.site_Setting_Element_Value');

-- *************************************************************************************************************************
-- Update AB Test Variations
-- Create temporary table of all users and their corresponding abtest values
-- (updated 2016-12-19 to speed up query with temp table)
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_sitesetting_abtest;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sitesetting_abtest
(INDEX (user_ID))
    SELECT
        ssev.user_ID,
        -- add order so order doesn't keep changing triggering an update
        GROUP_CONCAT(DISTINCT site_Setting_Element_Name, ':', FLOOR(value_Numeric) ORDER BY site_Setting_Element_Value_ID DESC
                     SEPARATOR ';') AS NewABTestValue
    FROM ACCOUNT.PUBLIC.site_Setting_Element_Value ssev
        JOIN LEADFLOW.arc.marketo_upload mu ON mu.user_ID = ssev.user_ID
    WHERE ssev.site_Setting_Element_Name LIKE 'SS_ABTEST%'
    GROUP BY ssev.user_ID;
SELECT '************************************* ABTests temp rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- Update AB Test Variations
-- Updated 2016-12-27: Concatenate any optimizely bucket ID info to the beginning of the ABTests field

UPDATE arc_marketo_upload mu
    
SET mu.ABTests        = CASE
                            WHEN ss.NewABTestValue IS NULL AND mu.optimizely_Buckets IS NULL THEN NULL
                            ELSE CONCAT_WS('
FROM tmp_sitesetting_abtest ss 
WHERE ss.user_ID = mu.user_ID

;', mu.optimizely_Buckets, ss.NewABTestValue)
                        END,
    mu.push_To_Marketo  = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.ABTests, '') != COALESCE(ss.NewABTestValue, '') /***COLLATE utf8mb4_unicode_520_ci
***/;
SELECT '************************************* ABTests rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'ACCOUNT.PUBLIC.site_Setting_Element_Value');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'CORE.PUBLIC.organization_User_Role');

-- *************************************************************************************************************************
-- Update organization roles
-- (updated 2016-01-26 to account for special GE request; see MKTO1817 for details)
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
    LEFT JOIN (
                  SELECT
                      our.user_ID,
                      our.organization_ID,
                      CONCAT_WS(';',
                                GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                                CASE WHEN org.main_Contact_User_ID IS NOT NULL
                                    THEN 'MAIN_CONTACT'
                                ELSE NULL END) AS new_OrgRoles
                  FROM CORE.PUBLIC.organization_User_Role our
                      JOIN arc_marketo_upload mu ON mu.user_ID = our.user_ID
                      LEFT JOIN CORE.PUBLIC.organization org ON mu.user_ID = org.main_Contact_User_ID AND org.state = 1
                  GROUP BY our.user_ID
              ) orgRole ON mu.user_ID = orgRole.user_ID
SET
    mu.organization_Roles = orgRole.new_OrgRoles,
    mu.push_To_Marketo     = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time    = CURRENT_TIMESTAMP()
WHERE
    COALESCE(mu.organization_Roles, '') != COALESCE(orgRole.new_OrgRoles, '') /***COLLATE utf8mb4_unicode_520_ci
***/    AND COALESCE(orgRole.organization_ID, 0) != 1030645 -- Exclude GE. Their org roles are updated in next query.
;
SELECT '************************************* organization_Roles rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'CORE.PUBLIC.organization_User_Role');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'CORE.PUBLIC.organization_User_Role GE');

-- See MKTO1817. We are adding an additional field to distinguish whether a GE customer was
-- added by a specific user in order to include them in specialized Marketo campaigns.
UPDATE arc_marketo_upload mu
    JOIN (
             SELECT
                 our.user_ID,
                 CONCAT_WS(';',
                           GROUP_CONCAT(DISTINCT our.role ORDER BY our.role ASC SEPARATOR ';'),
                           CASE WHEN org.main_Contact_User_ID IS NOT NULL
                               THEN 'MAIN_CONTACT'
                           ELSE NULL END,
                           CONCAT('LICENSE_ADDED_BY:', COALESCE(our2.insert_By_User_ID, 0))) AS new_OrgRoles
             FROM CORE.PUBLIC.organization_User_Role our
                 JOIN arc_marketo_upload mu ON our.user_ID = mu.user_ID AND our.organization_ID = 1030645 -- Org ID 1030645 is GE. Calculate special org roles for them.
                 LEFT JOIN CORE.PUBLIC.organization_User_Role our2 ON our.user_ID = our2.user_ID AND our2.role = 'LICENSE_USER' -- Want the LICENSE_ADDED_BY insert_By_User_ID to be specifically from the LICENSE_USER role
                 LEFT JOIN CORE.PUBLIC.organization org ON mu.user_ID = org.main_Contact_User_ID AND org.state = 1
             GROUP BY our.user_ID
             ORDER BY our.user_ID ASC
         ) orgRole ON mu.user_ID = orgRole.user_ID
SET
    mu.organization_Roles = orgRole.new_OrgRoles,
    mu.push_To_Marketo     = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time    = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.organization_Roles, '') != COALESCE(orgRole.new_OrgRoles, '') /***COLLATE utf8mb4_unicode_520_ci
***/;
SELECT '************************************* GE organization_Roles rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'CORE.PUBLIC.organization_User_Role GE');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.launched_Solutions_By_User');

-- *************************************************************************************************************************
-- Update solutions used
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
JOIN
    (
        SELECT sbu.user_ID, GROUP_CONCAT(DISTINCT MAIN.SMARTSHEET_SOLUTIONDEPT(sbu.Department), ':', sbu.name ORDER BY sbu.insert_Date_Time DESC SEPARATOR ';') AS newSolutionsUsed -- add order to eliminate unnecessary updates
        FROM MAIN.rpt.launched_Solutions_By_User sbu
        GROUP BY sbu.user_ID
        ORDER BY sbu.user_ID ASC
    ) solUsed ON mu.user_ID = solUsed.user_ID
SET
    mu.solutions_Used = solUsed.newSolutionsUsed,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()
WHERE COALESCE(mu.solutions_Used, '') != COALESCE(solUsed.newSolutionsUsed, '')
;
SELECT '************************************* solutions_Used rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.launched_Solutions_By_User');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.user_Role');

-- *************************************************************************************************************************
-- Update inferred role
-- Inferred role definitions. Priority is ranked based on most reliable data.
--   1. sfdc_Title: Role inferred from the lead/contact title in SFDC.
--   2. 411Title: Role inferred from lead title in 411 database.
--   3. signup_Campaign: Role inferred from the lead's signup campaign.
--   4. categoryTemplate: Role inferred from a user's most used templates
--      (at least 40% of their sheets are of the same template type as long as they have at least 5 sheets)
-- *************************************************************************************************************************

-- Updated 2016-12-21 to account for amplified trial signup
-- 
UPDATE
UPDATE arc_marketo_upload mu
    
SET mu.inferred_Role =
        CASE
            WHEN COALESCE(mu.inferred_Role, '') LIKE 'signupRole%' THEN mu.inferred_Role
            WHEN ur.sfdc_Role IS NOT NULL THEN CONCAT('sfdc_Title:', ur.sfdc_Role)
            WHEN ur.lead411_Role IS NOT NULL THEN CONCAT('411Title:', ur.lead411_Role)
            WHEN ur.signup_Campaign_Role IS NOT NULL THEN CONCAT('signup_Campaign:', ur.signup_Campaign_Role)
            WHEN ur.template_Category_Role IS NOT NULL THEN CONCAT('categoryTemplate:', ur.template_Category_Role)
        END,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM MAIN.rpt.user_Role ur 
WHERE COALESCE(mu.inferred_Role, '') !=
        CASE
            WHEN COALESCE(mu.inferred_Role, '') LIKE 'signupRole%' THEN mu.inferred_Role
            WHEN ur.sfdc_Role IS NOT NULL THEN CONCAT('sfdc_Title:', ur.sfdc_Role)
            WHEN ur.lead411_Role IS NOT NULL THEN CONCAT('411Title:', ur.lead411_Role)
            WHEN ur.signup_Campaign_Role IS NOT NULL THEN CONCAT('signup_Campaign:', ur.signup_Campaign_Role)
            WHEN ur.template_Category_Role IS NOT NULL THEN CONCAT('categoryTemplate:', ur.template_Category_Role)
            ELSE ''
        END

AND mu.user_ID = ur.user_ID

;
-- ORIGINAL
-- UPDATE arc_marketo_upload mu

-- SET
--     mu.inferred_Role =
--         CASE
--             WHEN ur.sfdc_Role IS NOT NULL THEN CONCAT('sfdc_Title:', ur.sfdc_Role)
--             WHEN ur.lead411_Role IS NOT NULL THEN CONCAT('411Title:', ur.lead411_Role)
--             WHEN ur.signup_Campaign_Role IS NOT NULL THEN CONCAT('signup_Campaign:', ur.signup_Campaign_Role)
--             WHEN ur.template_Category_Role IS NOT NULL THEN CONCAT('categoryTemplate:', ur.template_Category_Role)
--         END,
--     mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
--     mu.update_Date_Time = CURRENT_TIMESTAMP()
-- WHERE
--     COALESCE(mu.inferred_Role, '') !=
--         CASE
--             WHEN ur.sfdc_Role IS NOT NULL THEN CONCAT('sfdc_Title:', ur.sfdc_Role)
--             WHEN ur.lead411_Role IS NOT NULL THEN CONCAT('411Title:', ur.lead411_Role)
--             WHEN ur.signup_Campaign_Role IS NOT NULL THEN CONCAT('signup_Campaign:', ur.signup_Campaign_Role)
--             WHEN ur.template_Category_Role IS NOT NULL THEN CONCAT('categoryTemplate:', ur.template_Category_Role)
--             ELSE ''
--         END
-- ;
SELECT '************************************* inferred_Role rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.user_Role');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization_Name/account_Role temp');

-- *************************************************************************************************************************
-- Update organization name and account_Role
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_payment_Profile_organization_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_payment_Profile_organization_to_sync
(INDEX (user_ID))
    SELECT
        mu.user_ID,
        parentPP.payment_Profile_ID,
        org.name,
        org.organization_ID,
        org.main_Contact_User_ID
    FROM arc_marketo_upload mu
        LEFT OUTER JOIN CORE.PUBLIC.payment_Profile parentPP ON mu.parent_Payment_Profile_ID = parentPP.payment_Profile_ID
        LEFT OUTER JOIN CORE.PUBLIC.organization org ON parentPP.owner_ID = org.organization_ID AND parentPP.account_Type = 3
    WHERE
        COALESCE(org.name, '') /***COLLATE utf8mb4_unicode_520_ci***/ != COALESCE(mu.organization_Name, '') OR
        COALESCE(org.organization_ID, '') != COALESCE(mu.organization_ID, '') OR
        COALESCE(mu.account_Role, '') !=
        COALESCE(MAIN.MARKETO_ACCOUNT_ROLE(mu.payment_Profile_ID, parentPP.payment_Profile_ID, org.main_Contact_User_ID, mu.user_ID), '') COLLATE
        utf8mb4_unicode_520_ci
;
SELECT '************************************* temp organization_Name, account_Role rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization_Name/account_Role temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization_Name/account_Role updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.organization_Name = pporg.name,
    mu.organization_ID = pporg.organization_ID,
    mu.account_Role = MAIN.MARKETO_ACCOUNT_ROLE(mu.payment_Profile_ID, pporg.payment_Profile_ID, pporg.main_Contact_User_ID, mu.user_ID),
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_payment_Profile_organization_to_sync pporg 
WHERE mu.user_ID = pporg.user_ID  -- Must join on user_ID to prevent updating more records than necessary

;
SELECT '************************************* update organization_Name, account_Role rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization_Name/account_Role updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization product name temp');

-- *************************************************************************************************************************
-- Update organization product name for all org users
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_organizationUser_Role_payment_Profiles_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_organizationUser_Role_payment_Profiles_to_sync
(INDEX (user_ID))
SELECT
    mui.user_ID,
    -- Triple nested function: 1. Get max product rank, 2. convert rank back to product_ID, 3. convert product_ID to product name.
    MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(MAIN.SMARTSHEET_PRODUCTRANKCONVERT(MAX(MAIN.SMARTSHEET_PRODUCTRANK(ppp.product_ID)))) maxOrgProduct
FROM arc_marketo_upload mui
JOIN CORE.PUBLIC.organization_User_Role our ON mui.user_ID = our.user_ID AND our.state != 3             -- Ignore declined users
JOIN CORE.PUBLIC.organization org ON our.organization_ID = org.organization_ID AND org.state = 1      -- Include only active orgs
JOIN CORE.PUBLIC.payment_Profile ppp ON our.organization_ID = ppp.owner_ID AND ppp.account_Type = 3     -- Just want org accounts
GROUP BY mui.user_ID
;
SELECT '************************************* temp org_Product_Name rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization product name temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization product name updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu
LEFT 
SET mu.org_Product_Name = orgProducts.maxOrgProduct,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_organizationUser_Role_payment_Profiles_to_sync orgProducts 
WHERE COALESCE(mu.org_Product_Name, '') != COALESCE(orgProducts.maxOrgProduct, '')

AND mu.user_ID = orgProducts.user_ID

;
SELECT '************************************* update org_Product_Name rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization product name updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization license limit temp');

-- *************************************************************************************************************************
-- Update organization license limits: paid, bonus, assigned, pending
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_org_user_role_nightly_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_user_role_nightly_updates
(KEY (user_ID))
    SELECT
        mu.user_ID,
        uid.organization_ID,
        -- Set defaults to zero
        IFNULL(ppp.user_Limit, 0) paid_LicenseLimit,
        IFNULL(ppp.bonus_User_Count, 0) bonus_License_Limit,
        IFNULL(SUM(our.state = 1), 0) assigned_License_Count,
        IFNULL(SUM(our.state = 2), 0) pending_License_Count
    FROM arc_marketo_upload mu
        JOIN (
                 (SELECT our1.user_ID, our1.organization_ID
                  FROM CORE.PUBLIC.organization_User_Role our1
                      JOIN arc_marketo_upload mu ON our1.user_ID = mu.user_ID
                  WHERE
                      our1.role = 'USER_ADMIN'
                      AND our1.state = 1)
                 UNION
                 (SELECT org.main_Contact_User_ID, org.organization_ID
                  FROM CORE.PUBLIC.organization org
                      JOIN arc_marketo_upload mu ON org.main_Contact_User_ID = mu.user_ID
                  WHERE org.state = 1)
                 ORDER BY 1 ASC
             ) uid ON mu.user_ID = uid.user_ID
        LEFT JOIN CORE.PUBLIC.payment_Profile ppp ON
                                                    uid.organization_ID = ppp.owner_ID
                                                    AND ppp.account_Type = 3
        LEFT JOIN CORE.PUBLIC.organization_User_Role our ON
                                                          uid.organization_ID = our.organization_ID
                                                          AND our.role = 'LICENSE_USER'
                                                          AND our.state IN (1, 2)
    GROUP BY uid.user_ID, uid.organization_ID
;
SELECT '************************************* temp org license limit rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

-- 2. Create temporary table comparing existing values
DROP TABLE IF EXISTS tmp_org_user_role_license_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_org_user_role_license_updates
(INDEX (user_ID))
    SELECT
        mu.user_ID,
        lic.paid_LicenseLimit,
        lic.bonus_License_Limit,
        lic.assigned_License_Count,
        lic.pending_License_Count
    FROM arc_marketo_upload mu
        LEFT JOIN tmp_org_user_role_nightly_updates lic ON mu.user_ID = lic.user_ID
    WHERE
        COALESCE(mu.bonus_License_Limit, '') != COALESCE(lic.bonus_License_Limit, '')
        OR COALESCE(mu.assigned_License_Count, '') != COALESCE(lic.assigned_License_Count, '')
        OR COALESCE(mu.pending_License_Count, '') != COALESCE(lic.pending_License_Count, '')
;
SELECT '************************************* temp org license limit diff rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization license limit temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization license limit updates');

-- 3. Update license limits in leads table

UPDATE arc_marketo_upload mu
    
SET mu.user_Limit = lic.paid_LicenseLimit,
    mu.bonus_License_Limit = lic.bonus_License_Limit,
    mu.assigned_License_Count = lic.assigned_License_Count,
    mu.pending_License_Count = lic.pending_License_Count,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_org_user_role_license_updates lic 
WHERE mu.user_ID = lic.user_ID

;
SELECT '************************************* update org license limit rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization license limit updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization license tag temp');

-- *************************************************************************************************************************
-- Update organization license tags
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_lic_tag_nightly_updates;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_lic_tag_nightly_updates
(INDEX (user_ID))
    SELECT
        lic.user_ID,
        LEADFLOW.MARKETO_LICENSE_TAG(lic.assigned_License_Count, lic.pending_License_Count, lic.paid_LicenseLimit,
                                     mu.previous_User_Limit, COUNT(our.organization_User_Role_ID)) license_Tags
    FROM arc_marketo_upload mu
        JOIN tmp_org_user_role_nightly_updates lic ON mu.user_ID = lic.user_ID
        LEFT JOIN CORE.PUBLIC.organization_User_Role our
            ON lic.organization_ID = our.organization_ID
               AND our.role = 'LICENSE_USER'
               AND our.state IN (1, 2)
               AND our.insert_Date_Time >= DATEADD(DAY, -7, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
    GROUP BY lic.user_ID, lic.organization_ID
;
SELECT '************************************* temp org license tag rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization license tag temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'organization license tag updates');

-- 2. Update license tags in leads table

UPDATE arc_marketo_upload mu
    
SET mu.license_Tags = tag.license_Tags,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_lic_tag_nightly_updates tag 
WHERE COALESCE(mu.license_Tags, '') != COALESCE(tag.license_Tags, '')

AND mu.user_ID = tag.user_ID

;
SELECT '************************************* update org license tag rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'organization license tag updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'trial_End_Date_Date_Time temp');

-- *************************************************************************************************************************
-- Update trial_End_Date_Date_Time name
-- Needed for when parentPayment_Profile changes it doesn't get handled in marketoLeadsUploadCondeep.sql
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_payment_Profile_trial_End_Date_Date_Time_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_payment_Profile_trial_End_Date_Date_Time_to_sync
(INDEX (user_ID))
SELECT
    mu.user_ID,
    pp.payment_Profile_ID pppayment_Profile_ID,
    pp.product_ID ppproduct_ID,
    pp.payment_End_Date_Time pppayment_End_Date_Time,
    parentpp.payment_End_Date_Time parentpppayment_End_Date_Time,
    parentpp.payment_Start_Date_Time parentpppayment_Start_Date_Time
FROM arc_marketo_upload mu
JOIN CORE.PUBLIC.payment_Profile pp ON mu.payment_Profile_ID = pp.payment_Profile_ID
LEFT OUTER JOIN CORE.PUBLIC.payment_Profile parentpp ON mu.parent_Payment_Profile_ID = parentpp.payment_Profile_ID
WHERE
    (COALESCE(mu.trial_End_Date_Date_Time, '') != COALESCE(pp.payment_End_Date_Time, parentpp.payment_End_Date_Time) AND pp.product_ID = 1) OR
    COALESCE(mu.parent_Payment_Start_Date_Time, '') != COALESCE(parentpp.payment_Start_Date_Time, '')
;
SELECT '************************************* temp trial_End_Date_Date_Time rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'trial_End_Date_Date_Time temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'trial_End_Date_Date_Time updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.trial_End_Date_Date_Time =
        CASE
            -- get the end date from the payment_Profile, but it will be null if it is a team trial, if so, get it from the parent
            WHEN tmp.ppproduct_ID = 1  THEN COALESCE(tmp.pppayment_End_Date_Time, tmp.parentpppayment_End_Date_Time)  -- 1=in trial,
            ELSE mu.trial_End_Date_Date_Time -- don't over write, this will stay the end date time of last trial
        END,
    -- get the date from the parent, will be null if no parent
    mu.parent_Payment_Start_Date_Time = tmp.parentpppayment_Start_Date_Time,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_payment_Profile_trial_End_Date_Date_Time_to_sync tmp 
WHERE mu.user_ID = tmp.user_ID  -- Must join on user_ID to prevent updating more records than necessary

;
SELECT '************************************* update trial_End_Date_Date_Time rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'trial_End_Date_Date_Time updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.arc.churn_Scoring');


UPDATE arc_marketo_upload

SET marketo_upload.churn_Risk_Category = 'Basic-Week5-NoExpansion',
	marketo_upload.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, push_To_Marketo),
	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()	

FROM MAIN.arc.churn_Scoring 
WHERE COALESCE(marketo_upload.churn_Risk_Category, '') != 'Basic-Week5-NoExpansion'  AND
	will_Churn_wk5 = will_Churn_max_Week AND will_Churn_wk5 = 1

AND marketo_upload.payment_Profile_ID = churn_Scoring.payment_Profile_ID

;
SELECT '************************************* churn_Risk_Category.Basic-Week5-NoExpansion rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.arc.churn_Scoring');

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.user_Payment_Funnel_Progress');


UPDATE arc_marketo_upload 

SET marketo_upload.upgrade_Wizard_Progress = MARKETO_UPGRADE_WIZARD_PROGRESS(Viewed_Confirm_Page, Pay_Pal_Complete, Pay_Pal_Start, Viewed_Step3, Viewed_Step2, Viewed_Step1),
	marketo_upload.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, push_To_Marketo),
	marketo_upload.update_Date_Time = CURRENT_TIMESTAMP()		

FROM MAIN.rpt.user_Payment_Funnel_Progress upfp 
WHERE COALESCE(marketo_upload.upgrade_Wizard_Progress, '') != MARKETO_UPGRADE_WIZARD_PROGRESS(Viewed_Confirm_Page, Pay_Pal_Complete, Pay_Pal_Start, Viewed_Step3, Viewed_Step2, Viewed_Step1)

AND marketo_upload.user_ID = upfp.user_ID

;
SELECT '************************************* upgrade_Wizard_Progress rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.user_Payment_Funnel_Progress');

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.paid_Plan_Current_Users temp');

-- *************************************************************************************************************************
-- Update Persona
-- *************************************************************************************************************************
-- 1. Create temporary table containing only needed columns
DROP TABLE IF EXISTS tmp_rpt_paidPlanCurrentUsers_to_sync;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_rpt_paidPlanCurrentUsers_to_sync
(INDEX (user_ID))
SELECT mu.user_ID, ppcu.Persona FROM arc_marketo_upload mu
LEFT JOIN MAIN.rpt.paid_Plan_Current_Users ppcu ON mu.user_ID = ppcu.main_Contact_User_ID
WHERE COALESCE(mu.persona, '') != COALESCE(ppcu.Persona, '')
;
SELECT '************************************* temp persona rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.paid_Plan_Current_Users temp');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.paid_Plan_Current_Users updates');

-- 2. Update leads table

UPDATE arc_marketo_upload mu

SET mu.persona = ppcu.Persona,
    mu.push_To_Marketo = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_rpt_paidPlanCurrentUsers_to_sync ppcu 
WHERE mu.user_ID = ppcu.user_ID

;
SELECT '************************************* update persona rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.paid_Plan_Current_Users updates');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.arc.domain_Email_Exclusion collabs');

-- *************************************************************************************************************************
-- Match marketing email opt outs for collabs inserted by excluded domains
-- Added 2016-04-01
-- Updated 2016-08-03 to add organization level exclusions
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_collabs_opt_out;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_collabs_opt_out
(PRIMARY KEY (user_ID))
    SELECT
        mu2.user_ID,
        (COALESCE(dee.exclude_From_Marketing_Email, 0) = 1 AND COALESCE(dex.include_For_Marketing_Email, 0) = 0) AS exclude_From_Marketing_Email
    FROM MAIN.arc.domain_Email_Exclusion dee
        JOIN LEADFLOW.arc.marketo_upload mu
             USE INDEX (idx_email_Domain) ON dee.domain = mu.email_Domain
        JOIN CORE.PUBLIC.user_Account ua ON mu.user_ID = ua.insert_By_User_ID
        -- Get all collabs who were inserted by the excluded domain users
        LEFT JOIN MAIN.arc.domain_Email_Exclusion dee2
            ON MAIN.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = dee2.domain AND COALESCE(dee2.exclude_From_Marketing_Email, 0) = 1
        -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.arc.organization_Email_Exclusion oee
            ON MAIN.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = mu.email_Domain AND COALESCE(oee.exclude_From_Marketing_Email, 0) = 1
        JOIN LEADFLOW.arc.marketo_upload mu2
            ON ua.user_ID = mu2.user_ID -- Get all collabs in sync table to check if domain_Opt_Out needs to be updated
        LEFT JOIN MAIN.arc.domain_Email_Exclusion_Exceptions dex ON mu2.email_Address = dex.email_Address
    WHERE
        dee2.domain IS NULL  -- Only update collabs in domains that are NOT in the exclusion table
        AND oee.organization_ID IS NULL
        AND dee.exclude_From_Marketing_Email = 1
        -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
        AND dee.domain != 'smartsheet.com'
    UNION
    SELECT
        mu2.user_ID,
        (COALESCE(oee.exclude_From_Marketing_Email, 0) = 1 AND COALESCE(dex.include_For_Marketing_Email, 0) = 0) AS exclude_From_Marketing_Email
    FROM CORE.PUBLIC.organization_User_Role our
        JOIN MAIN.arc.organization_Email_Exclusion oee
            ON our.organization_ID = oee.organization_ID AND oee.exclude_From_Marketing_Email = 1 AND
               -- Get all users (except smartsheet.com) who have been excluded from Marketing emails
               oee.organization_ID != 1000008
        JOIN LEADFLOW.arc.marketo_upload mu ON our.user_ID = mu.user_ID
        JOIN CORE.PUBLIC.user_Account ua ON mu.user_ID = ua.insert_By_User_ID
        -- Get all collabs who were inserted by the excluded users
        LEFT JOIN MAIN.arc.organization_Email_Exclusion oee2
            ON MAIN.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = mu.email_Domain AND COALESCE(oee2.exclude_From_Marketing_Email, 0) = 1
        -- Check if dee2.domain IS NULL to exclude collabs whose domains are the same as the domains already excluded
        LEFT JOIN MAIN.arc.domain_Email_Exclusion dee
            ON MAIN.MARKETO_EXTRACT_DOMAIN(ua.email_Address) = dee.domain AND COALESCE(dee.exclude_From_Marketing_Email, 0) = 1
        JOIN LEADFLOW.arc.marketo_upload mu2
            ON ua.user_ID = mu2.user_ID -- Get all collabs in sync table to check if domain_Opt_Out needs to be updated
        LEFT JOIN MAIN.arc.domain_Email_Exclusion_Exceptions dex ON mu2.email_Address = dex.email_Address
    WHERE
        oee2.organization_ID IS NULL  -- Only update collabs in parent payment profile that are NOT in the exclusion table
        AND dee.domain IS NULL
        AND our.state IN (1, 2)
    GROUP BY mu2.user_ID
;
SELECT '************************************* temp collab domain_Opt_Out rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE LEADFLOW.arc.marketo_upload mu
    
SET mu.domain_Opt_Out   = coo.exclude_From_Marketing_Email,
    mu.push_To_Marketo  = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_collabs_opt_out coo 
WHERE COALESCE(mu.domain_Opt_Out, 0) != COALESCE(coo.exclude_From_Marketing_Email, 0)

AND mu.user_ID = coo.user_ID

;
SELECT '************************************* update collab domain_Opt_Out rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.arc.domain_Email_Exclusion collabs');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.arc.domain_Email_Exclusion');

-- *************************************************************************************************************************
-- Update marketing email opt outs by domain
-- Updated 2016-01-22 to move exceptions to MAIN.arc.domain_Email_Exclusion_Exceptions table
-- Updated 2016-08-03 to add organization level exclusions
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_opt_out_changes;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_opt_out_changes
(PRIMARY KEY (user_ID))
    SELECT
        mu.user_ID,
        MAX((COALESCE(dee.exclude_From_Marketing_Email, 0) = 1 OR
             COALESCE(oee.exclude_From_Marketing_Email, 0) = 1)) shouldExclude,
        -- Only time someone can opt out is when they want their domain to be excluded and DON'T have an exception
        ((COALESCE(dee.exclude_From_Marketing_Email, 0) = 1 OR COALESCE(oee.exclude_From_Marketing_Email, 0) = 1) AND
         COALESCE(dex.include_For_Marketing_Email, 0) = 0)       new_DomainOptOut
    FROM LEADFLOW.arc.marketo_upload mu
        LEFT JOIN CORE.PUBLIC.organization_User_Role our
            ON mu.user_ID = our.user_ID AND our.role = 'MEMBER' AND our.state IN (1, 2)
        LEFT JOIN MAIN.arc.domain_Email_Exclusion dee ON mu.email_Domain = dee.domain
        LEFT JOIN MAIN.arc.organization_Email_Exclusion oee ON our.organization_ID = oee.organization_ID
        LEFT JOIN MAIN.arc.domain_Email_Exclusion_Exceptions dex ON mu.email_Address = dex.email_Address
        LEFT JOIN tmp_collabs_opt_out coo ON mu.user_ID = coo.user_ID
    WHERE
        coo.user_ID IS NULL
        AND COALESCE(mu.domain_Opt_Out, 0) !=
            ((COALESCE(dee.exclude_From_Marketing_Email, 0) = 1 OR COALESCE(oee.exclude_From_Marketing_Email, 0) = 1) AND
             COALESCE(dex.include_For_Marketing_Email, 0) = 0)
    GROUP BY mu.user_ID
;
SELECT '************************************* domain_Opt_Out temp rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE LEADFLOW.arc.marketo_upload mu
    
SET mu.domain_Opt_Out   = ooc.new_DomainOptOut,
    mu.push_To_Marketo  = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time = CURRENT_TIMESTAMP()

FROM tmp_opt_out_changes ooc 
WHERE mu.user_ID = ooc.user_ID

;
SELECT '************************************* domain_Opt_Out rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.arc.domain_Email_Exclusion');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'MAIN.rpt.csa_Report');

-- *************************************************************************************************************************
-- Update tier, health, and CSA drip bucket by domain
-- (Added 2016-03-22)
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_csaReport;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_csaReport
(INDEX (user_ID))
    SELECT
        mu.user_ID,
        cs.account_Health,
        cs.account_Tier,
        cs.Account_To_Be_Assigned,
        cs.territory
    FROM arc_marketo_upload mu
        LEFT JOIN SFDC.PUBLIC.domain d ON mu.email_Domain = d.Domain_Name_URL__c
        LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
        LEFT JOIN MAIN.rpt.cs_Report cs ON a.Id = cs.account_Id
    WHERE
        (
            COALESCE(mu.account_Health, '') != COALESCE(cs.account_Health, '') OR
            COALESCE(mu.account_Tier, '') != COALESCE(cs.account_Tier, '') OR
            COALESCE(mu.account_CSADrip_Bucket, '') != COALESCE(cs.Account_To_Be_Assigned, '') OR
            COALESCE(mu.account_Territory, '') != COALESCE(cs.territory, '')
        )
        AND mu.is_Org_Domain = 1  -- Ignore ISP domains.
;
SELECT '************************************* temp csaReport rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc_marketo_upload mu
    
SET mu.account_Health        = cs.account_Health,
    mu.account_Tier          = cs.account_Tier,
    mu.account_CSADrip_Bucket = cs.Account_To_Be_Assigned,
    mu.account_Territory     = cs.territory,
    mu.push_To_Marketo        = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time       = CURRENT_TIMESTAMP()

FROM tmp_csaReport cs 
WHERE mu.user_ID = cs.user_ID

;
SELECT '************************************* update csaReport rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'MAIN.rpt.csa_Report');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'domain and account users');

-- *********************************************************************************************************************
-- Update customer success rep and domain owner info for all leads. The fast version of these queries are in the
-- 5 min script, so this is just for LEFT JOIN cleanup. This runs much slower.
-- (added 2016-07-28)
-- *********************************************************************************************************************
DROP TABLE IF EXISTS tmp_sfdc_domain_account_reps;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_reps
(INDEX (Domain_Name_URL__c))
    SELECT
        d.Domain_Name_URL__c,
        csu.Email     csEmail,
        csu.First_Name csFirst_Name,
        csu.Last_Name  csLast_Name,
        csu.Phone     csPhone,
        dou.Email     doEmail,
        dou.First_Name doFirst_Name,
        dou.Last_Name  doLast_Name,
        dou.Title     doTitle,
        dou.Phone     doPhone
    FROM SFDC.PUBLIC.domain d
        LEFT JOIN SFDC.PUBLIC.account a ON d.Account__c = a.Id
        LEFT JOIN SFDC.PUBLIC.user csu ON a.Customer_Success__c = csu.Id
        LEFT JOIN SFDC.PUBLIC.user dou
            ON d.Owner_Id = dou.Id AND dou.ID != '00540000002nu18AAA'-- Exclude Andrew Imhoff.
   -- Ignore ISP domains. Use MAIN.arc.ISPDomains instead of is_Org_Domain field to avoid join on arc_marketo_upload.
    WHERE d.Domain_Name_URL__c NOT IN (SELECT domain
                                       FROM MAIN.arc.ISPDomains)
;
SELECT '************************************* sfdc domain and account reps: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

DROP TABLE IF EXISTS tmp_sfdc_domain_account_users;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_sfdc_domain_account_users
(INDEX (user_ID))
    SELECT
        mu.user_ID,
        d.*
    FROM LEADFLOW.arc.marketo_upload mu
        LEFT OUTER JOIN tmp_sfdc_domain_account_reps d ON mu.email_Domain = d.Domain_Name_URL__c
        LEFT OUTER JOIN CORE.PUBLIC.organization org ON mu.user_ID = org.main_Contact_User_ID AND org.state = 1
    WHERE
        (COALESCE(mu.success_Rep_Email, '') != COALESCE(d.csEmail, '')
         OR COALESCE(mu.success_Rep_First_Name, '') != COALESCE(d.csFirst_Name, '')
         OR COALESCE(mu.success_Rep_Last_Name, '') != COALESCE(d.csLast_Name, '')
         OR COALESCE(mu.success_Rep_Phone_Number, '') != COALESCE(d.csPhone, '')
         OR COALESCE(mu.domain_Owner_Email, '') != COALESCE(d.doEmail, '')
         OR COALESCE(mu.domain_Owner_First_Name, '') != COALESCE(d.doFirst_Name, '')
         OR COALESCE(mu.domain_Owner_Last_Name, '') != COALESCE(d.doLast_Name, '')
         OR COALESCE(mu.domain_Owner_Title, '') != COALESCE(d.doTitle, '')
         OR COALESCE(mu.domain_Owner_Phone_Number, '') != COALESCE(d.doPhone, ''))
       -- Don't want to reintroduce leads who may have been purged.
        AND
        (org.main_Contact_User_ID IS NOT NULL-- MKTO3303 include all active org main contacts
         OR mu.product_Name IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR mu.org_Product_Name IN ('Trial', 'Basic', 'Advanced', 'Premium', 'Team', 'Team Plus', 'Business', 'Enterprise', 'Enterprise_Legacy')
         OR COALESCE(mu.last_Login, '2000-01-01') >= DATEADD(DAY, -180, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)) -- MKTO3290 include paid, trial, or active in last 180 days
    ORDER BY mu.user_ID ASC -- Need to order by user_ID to prevent deadlocks.
;
SELECT '************************************* sfdc domain and account changes: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


UPDATE arc_marketo_upload mu
    
SET mu.success_Rep_Email        = d.csEmail,
    mu.success_Rep_First_Name    = d.csFirst_Name,
    mu.success_Rep_Last_Name     = d.csLast_Name,
    mu.success_Rep_Phone_Number  = d.csPhone,
    mu.domain_Owner_Email       = d.doEmail,
    mu.domain_Owner_First_Name   = d.doFirst_Name,
    mu.domain_Owner_Last_Name    = d.doLast_Name,
    mu.domain_Owner_Title       = d.doTitle,
    mu.domain_Owner_Phone_Number = d.doPhone,
    mu.push_To_Marketo          = GREATEST($highestNightlyUpdatePriority, mu.push_To_Marketo),
    mu.update_Date_Time         = CURRENT_TIMESTAMP()

FROM tmp_sfdc_domain_account_users d 
WHERE mu.user_ID = d.user_ID

;
SELECT '************************************* sfdc domain and account rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'domain and account users');

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'tmp_app_behavior_score_leads leads');
--##########################################################################################################################-- Get list of leads that should get updated app behavior scores--##########################################################################################################################
DROP TABLE IF EXISTS tmp_app_behavior_score_leads;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_app_behavior_score_leads
(
    PRIMARY KEY (user_ID)
)
    SELECT DISTINCT user_ID
    FROM LEADFLOW.arc.marketo_upload_journal
    WHERE
        journal_Date_Time >= $marketoNightlyStart_DateTime
        AND push_To_Marketo >= $mediumNightlyUpdatePriority;
SELECT '************************************* tmp_app_behavior_score_leads rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'tmp_app_behavior_score_leads leads');

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'app_Behavior_Score_New reset');

-- *************************************************************************************************************************
-- Update app behavior scores
-- *************************************************************************************************************************

UPDATE arc_marketo_upload mu
    
SET mu.app_Behavior_Score_New =
   -- cap the existing app score at 100 by subtracting 100 if over 100 else 0 to allow all the existing score through
    CASE
        WHEN
            mu.app_Behavior_Score_New IS NULL AND
            mu.was_Shared_To_Prior_To_Trial = 1 AND
            getAppBehaviorScoreV1(mu.login_Count, mu.event_Log_Count, mu.sheet_Count, mu.sharing_Count, mu.report_Count, mu.team_Trial, mu.account_Role) > 100
            THEN getAppBehaviorScoreV1(mu.login_Count, mu.event_Log_Count, mu.sheet_Count, mu.sharing_Count, mu.report_Count, mu.team_Trial, mu.account_Role) - 100
        ELSE mu.app_Behavior_Score_New
    END

FROM tmp_app_behavior_score_leads tmp 
WHERE mu.user_ID = tmp.user_ID

;
SELECT '************************************* app_Behavior_Score_New existing score resetting rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'app_Behavior_Score_New reset');


-- *************************************************************************************************************************
-- Lock debugging
-- *************************************************************************************************************************
-- SELECT COUNT(*), information_schema.tokudb_locks.*, pl.* FROM information_schema.tokudb_locks

-- WHERE locks_table_schema != 'WORKSPACE'
-- GROUP BY locks_table_schema, locks_table_name, locks_mysql_thread_id
-- ;
-- SELECT '************************************* lock debugging : ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'app_Behavior_Score_New/Old');

-- *************************************************************************************************************************
-- Update app behavior scores
-- *************************************************************************************************************************
UPDATE arc_marketo_upload mu
    JOIN tmp_app_behavior_score_leads tmp on mu.user_ID = tmp.user_ID
SET
    mu.app_Behavior_Score_Old = COALESCE(mu.app_Behavior_Score_New, 0),
    mu.app_Behavior_Score_New = getAppBehaviorScoreV1(mu.login_Count, mu.event_Log_Count, mu.sheet_Count, mu.sharing_Count, mu.report_Count, mu.team_Trial, mu.account_Role)
;
SELECT '************************************* app_Behavior_Score_Old and New rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'app_Behavior_Score_New/Old');

SHOW PROCESSLIST;

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'app_Behavior_Score');


UPDATE arc_marketo_upload mu
    
SET mu.app_Behavior_Score = COALESCE(mu.app_Behavior_Score_New, 0) - COALESCE(mu.app_Behavior_Score_Old, 0),
    mu.push_To_Marketo    = GREATEST($mediumHighNightlyUpdatePriority, mu.push_To_Marketo), -- bump up priority for lead scoring
    mu.update_Date_Time   = CURRENT_TIMESTAMP()

FROM tmp_app_behavior_score_leads tmp 
WHERE -- only push changes for leads that are still candidates for initial sales outreach
    -- which is in a trial or within 14 days after their trial expired
    (mu.product_Name = ('Trial') OR (mu.product_Name = ('Free') AND mu.trial_End_Date_Date_Time > DATEADD(DAY, -14, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)))

AND mu.user_ID = tmp.user_ID

;
SELECT '************************************* app_Behavior_Score rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'app_Behavior_Score');


SHOW PROCESSLIST;

--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'LEADFLOW.arc.marketo_upload_sync_history');

-- *************************************************************************************************************************
-- Log curent sync queue
-- *************************************************************************************************************************
INSERT INTO LEADFLOW.arc.marketo_upload_sync_history
SELECT CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, 'marketo_nightly_update.sql', muf.priority, COUNT(mu.user_ID)
FROM LEADFLOW.arc.marketo_upload_flags muf
LEFT OUTER JOIN LEADFLOW.arc.marketo_upload mu ON muf.priority = mu.push_To_Marketo
WHERE muf.priority != 0
GROUP BY muf.priority
ORDER BY muf.priority DESC
;
SELECT '************************************* updating sync queue history rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'LEADFLOW.arc.marketo_upload_sync_history');


--CALL LEADFLOW.SMARTSHEET_START_LOG('Marketo Nightly', 'net promoter score users');

-- *************************************************************************************************************************
-- Capture any new Net Promoter Score data
-- *************************************************************************************************************************
DROP TABLE IF EXISTS tmp_net_promoter_score_users;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp_net_promoter_score_users
    SELECT
        allnps.Email,
        allnps.user_ID__c,
        allnps.Net_Promoter_Score__c,
        allnps.Net_Promoter_Score_Reason__c,
        mu.product_Name,
        mu.success_Rep_Email,
        mu.account_Health,
        mu.account_Tier,
        mu.persona,
        mu.organization_Roles,
        MAX(allnps.Last_Modified_Date)
    FROM (
             SELECT
                 Email,
                 user_ID__c,
                 Last_Modified_Date,
                 Net_Promoter_Score__c,
                 Net_Promoter_Score_Reason__c
             FROM SFDC.PUBLIC.lead
             WHERE
                 NOT (COALESCE(Net_Promoter_Score__c, 0) = 0
                      AND COALESCE(Net_Promoter_Score_Reason__c, '') = '')
             UNION ALL
             SELECT
                 Email,
                 user_ID__c,
                 Last_Modified_Date,
                 Net_Promoter_Score__c,
                 Net_Promoter_Score_Reason__c
             FROM SFDC.PUBLIC.contact
             WHERE
                 NOT (COALESCE(Net_Promoter_Score__c, 0) = 0
                      AND COALESCE(Net_Promoter_Score_Reason__c, '') = '')
         ) allnps
        LEFT JOIN LEADFLOW.arc.marketo_upload mu ON allnps.user_ID__c = mu.user_ID
    GROUP BY allnps.Email
;
SELECT '************************************* net promoter score user rows: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

INSERT INTO LEADFLOW.arc.marketo_lead_nps
(email_Address, user_ID, net_Promoter_Score, net_Promoter_Score_Reason, product_Name, success_Rep_Email, account_Health, account_Tier, persona, organization_Roles)
    SELECT
        Email,
        user_ID__c,
        Net_Promoter_Score__c,
        Net_Promoter_Score_Reason__c,
        product_Name,
        success_Rep_Email,
        account_Health,
        account_Tier,
        persona,
        organization_Roles
    FROM tmp_net_promoter_score_users nps
;
SELECT '************************************* net promoter score user inserts: ', ROW_COUNT(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'net promoter score users');


-- *************************************************************************************************************************
-- Debug
-- *************************************************************************************************************************
--SHOW VARIABLES LIKE 'tx_isolation';


--CALL MAIN.utl_logProcessEnd($v_process_Id);
--CALL LEADFLOW.SMARTSHEET_STOP_LOG('Marketo Nightly', 'Total');