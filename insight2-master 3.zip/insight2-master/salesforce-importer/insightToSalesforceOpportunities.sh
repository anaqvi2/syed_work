echo 'Starting insightToSalesforceOpportunities.sh'


SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
SFDC_HOME=${WORKSPACE}/salesforce-importer

LOG_DATE=$1
LOG_FILE=${STATS_HOME}/logs/insightToSalesforceOpportunities_${LOG_DATE}.log
exec > $LOG_FILE 2>&1

DB_SERVER=127.0.0.1
DB_NAME=ss_core_02

echo "Deleting log and report files older than 7 days..."
find ${STATS_HOME}/logs/insightToSalesforceOpportunities* -mtime +7 -type f -delete -print

. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_HOME}/reportFuncs.sh

SQL_FILE=${SFDC_HOME}/sfdc_opportunityUpload.sql
echo "**** $(date +%X) : Running file ${SQL_FILE} ****"
mysql -h ${DB_SERVER} -D ${DB_NAME} -u ${DB_USER} -p${DB_PWD} --force -v --unbuffered < ${SQL_FILE}
SQLSTATUS=$?
echo SQLSTATUS=$?

# did the SQL file work?
if [ $SQLSTATUS == 1 ]
then
	echo "ERROR: Something failed during the call to the database."
	exit 1
else
	echo "We didn't detect any errors in the SQL File."
	exit 0
fi

# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
grep -iw error ${LOG_FILE} > ${LOG_FILE}.results
cat ${LOG_FILE} >> ${LOG_FILE}.results

echo 'Finished insightToSalesforceOpportunities.sh'
