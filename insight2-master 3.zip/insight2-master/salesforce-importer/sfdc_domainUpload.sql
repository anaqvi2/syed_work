INSERT IGNORE INTO rpt_main_02.stg_allDomainsPurchased
SELECT DISTINCT domain FROM rpt_workspace.cDunn_allPlansPurchased;

DROP TABLE IF EXISTS rpt_main_02.stg_paidDomainInfoOld;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_paidDomainInfoOld LIKE rpt_main_02.stg_sfdc_domain_stats;

INSERT INTO rpt_main_02.stg_paidDomainInfoOld
SELECT * FROM rpt_main_02.stg_sfdc_domain_stats;


DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_domain_stats;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sfdc_domain_stats
(
	domain VARCHAR(100),
	maxProduct VARCHAR(50),
	paidLicensedUsers INT,
	assignedLicensedUsers INT,
	pendingLicensedUsers INT,
	bonusUserCount INT,
	ACV_Wins_AllTime DECIMAL(38,10),
	ACV_Upgrades_AllTime DECIMAL(38,10),
	ACV_Downgrades_AllTime DECIMAL(38,10),
	ACV_Losses_AllTime DECIMAL(38,10),
	ACV_Wins_Last12Mo DECIMAL(38,10),
	ACV_Upgrades_Last12Mo DECIMAL(38,10),
	ACV_Downgrades_Last12Mo DECIMAL(38,10),
	ACV_Losses_Last12Mo DECIMAL(38,10),
	Account_Health__c VARCHAR(25),
	Account_Tier__c VARCHAR(25),
	Domain_Opt_Out__c INT,
	ISP__c INT,
	highestPlanID BIGINT,
	plans INT,
	nextRenewalDate DATETIME,
	collaborators INT,
	maxACV DECIMAL(10,2),
	jiraEnabled TINYINT,
	salesforceEnabled TINYINT,
	sightsEnabledUsers INT,
	highestPlanMainContactEmail VARCHAR(100),
	30DayLicensedLoginRate DECIMAL(10,2),
	90DayLicensedLoginRate DECIMAL(10,2),
	30DayLoginRateAll DECIMAL(10,2),
	90DayLoginRateAll DECIMAL(10,2),
	Product_Engagement_Status VARCHAR(25),
	PRIMARY KEY ix_domain (domain)
)
;
DROP TABLE IF EXISTS ss_sfdc_02.`arc_sfdc_domainUpload`;

CREATE TABLE IF NOT EXISTS ss_sfdc_02.`arc_sfdc_domainUpload` (
  `domain` VARCHAR(100) NOT NULL DEFAULT '',
  `maxProduct` VARCHAR(50) DEFAULT NULL,
  `paidLicensedUsers` INT(11) DEFAULT NULL,
  `assignedLicensedUsers` INT(11) DEFAULT NULL,
  `pendingLicensedUsers` INT(11) DEFAULT NULL,
  `bonusUserCount` INT(11) DEFAULT NULL,
  `ACV_Wins_AllTime` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Upgrades_AllTime` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Downgrades_AllTime` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Losses_AllTime` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Wins_Last12Mo` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Upgrades_Last12Mo` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Downgrades_Last12Mo` DECIMAL(38,10) DEFAULT NULL,
  `ACV_Losses_Last12Mo` DECIMAL(38,10) DEFAULT NULL,
  Account_Health__c VARCHAR(25),
  Account_Tier__c VARCHAR(25),
  Domain_Opt_Out__c INT,
  ISP__c INT,
highestPlanID BIGINT,
plans INT,
nextRenewalDate DATETIME,
collaborators INT,
maxACV DECIMAL(10,2),
	jiraEnabled TINYINT,
	salesforceEnabled TINYINT,
	sightsEnabledUsers INT,
	highestPlanMainContactEmail VARCHAR(100),
	30DayLicensedLoginRate DECIMAL(10,2),
	90DayLicensedLoginRate DECIMAL(10,2),
	30DayLoginRateAll DECIMAL(10,2),
	90DayLoginRateAll DECIMAL(10,2),
Product_Engagement_Status VARCHAR(25),
  PRIMARY KEY (`domain`)
) DEFAULT CHARSET=utf8
;




INSERT INTO rpt_main_02.stg_sfdc_domain_stats
SELECT 
pp.mainContactDomain,
rpt_main_02.`SMARTSHEET_PRODUCTNAME`(rpt_main_02.`SMARTSHEET_PRODUCTRANKCONVERT`(MAX(rpt_main_02.`SMARTSHEET_PRODUCTRANK`(pp.productID)))),
SUM(pp.userLimit) AS paidLicensedUsers,
SUM(pp.activeProfileCount) AS assignedLicensedUsers,
SUM(pp.seatCount-activeProfileCount) AS pendingLicensedUsers,
SUM(pp.bonusUserCount) AS bonusUserCount,
0 AS ACV_Wins_AllTime,
0 AS ACV_Upgrades_AllTime,
0 AS ACV_Downgrades_AllTime,
0 AS ACV_Losses_AllTime,

0 AS ACV_Wins_Last12Mo,
0 AS ACV_Upgrades_Last12Mo,
0 AS ACV_Downgrades_Last12Mo,
0 AS ACV_Losses_Last12Mo,
B.accountHealth,
B.accountTier,
0 AS Domain_Opt_Out__c,
0 AS ISP__c,
NULL AS highestPlanID,
COUNT(DISTINCT(pp.paymentProfileID)),

MIN(CASE WHEN pp.nextPaymentDate > NOW() THEN pp.nextPaymentDate 
	ELSE CASE WHEN pp.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(pp.actualLastPaymentDate), "-",DAY(pp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(pp.paymentStartDateClean)) + 1) YEAR) END
		WHEN pp.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN pp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.nextPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN pp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL pp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN pp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -pp.paymentTerm MONTH) 
			THEN DATE_ADD(pp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN pp.paymentTerm = 1 
			THEN DATE_ADD(pp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(pp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(pp.paymentStartDateClean, INTERVAL +(pp.paymentTerm) MONTH) END
		ELSE "Other" END END),
		
	NULL AS collaborators,
	MAX((pp.planRate_USD/pp.paymentTerm)*12),
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL


FROM rpt_main_02.rpt_paymentProfile pp
LEFT OUTER JOIN rpt_main_02.rpt_csReport B ON pp.mainContactDomain = B.domain
WHERE pp.countAsPaid = 1
GROUP BY 1
;

INSERT IGNORE INTO rpt_main_02.stg_sfdc_domain_stats
SELECT domain,"Cancelled",0,0,0,0,0,0,0,0,0,0,0,0,
NULL,
NULL,
0,0,NULL,0,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL
FROM rpt_main_02.stg_allDomainsPurchased
WHERE domain != '';

DROP TABLE rpt_main_02.stg_domainCollabCount;
CREATE TABLE rpt_main_02.stg_domainCollabCount
(domain VARCHAR(100),
collaborators INT,
PRIMARY KEY (domain));

INSERT INTO rpt_main_02.stg_domainCollabCount
SELECT sheetPlanDomain, COUNT(DISTINCT(userID))
FROM rpt_main_02.rpt_paidPlanSheetAccess
WHERE userPlanID IS NULL AND loginCount > 0 AND access < 50
GROUP BY 1;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
JOIN rpt_main_02.stg_domainCollabCount B ON A.domain = B.domain
SET A.collaborators = B.collaborators;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.domain = A.domain AND ppi.ACV = A.maxACV
SET A.highestPlanID = ppi.paymentProfileID;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.highestPlanID
SET highestPlanMainContactEmail = pp.mainContactEmailAddress;


DROP TABLE IF EXISTS rpt_workspace.cDunn_salesforceEnabledOrgs;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_salesforceEnabledOrgs
(organizationID BIGINT,
paymentProfileID BIGINT,
domain VARCHAR(100),
PRIMARY KEY (paymentProfileID),
KEY domain (domain));

INSERT INTO rpt_workspace.cDunn_salesforceEnabledOrgs
SELECT ocs.organizationID, pp.paymentProfileID, pp.mainContactDomain
FROM ss_account_02.orgConfigSetting ocs
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.ownerID = ocs.organizationID AND pp.accountType = 3
WHERE ocs.configPropertyID IN(4008,4021) AND valueBoolean = 1 GROUP BY 2;

DROP TABLE IF EXISTS rpt_workspace.cDunn_jiraEnabledOrgs;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_jiraEnabledOrgs
(organizationID BIGINT,
paymentProfileID BIGINT,
domain VARCHAR(100),
PRIMARY KEY (paymentProfileID),
KEY domain (domain));

INSERT INTO rpt_workspace.cDunn_jiraEnabledOrgs
SELECT ocs.organizationID, pp.paymentProfileID, pp.mainContactDomain
FROM ss_account_02.orgConfigSetting ocs
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.ownerID = ocs.organizationID AND pp.accountType = 3
WHERE ocs.configPropertyID = 4022  AND valueBoolean = 1;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
LEFT JOIN rpt_workspace.cDunn_jiraEnabledOrgs B ON A.domain = B.domain
SET A.jiraEnabled = CASE WHEN B.domain IS NOT NULL THEN 1 ELSE 0 END;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
LEFT JOIN rpt_workspace.cDunn_salesforceEnabledOrgs B ON A.domain = B.domain
SET A.salesforceEnabled = CASE WHEN B.domain IS NOT NULL THEN 1 ELSE 0 END;

DROP TABLE IF EXISTS rpt_workspace.cDunn_sightsEnabledUsersByPlan;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_sightsEnabledUsersByPlan
(organizationID BIGINT,
paymentProfileID BIGINT,
domain VARCHAR(100),
sightsEnabledUsers INT,
PRIMARY KEY (paymentProfileID),
KEY domain (domain));

INSERT INTO rpt_workspace.cDunn_sightsEnabledUsersByPlan
SELECT ocs.organizationID, pp.paymentProfileID, pp.mainContactDomain, pp.activeProfileCount
FROM ss_account_02.orgConfigSetting ocs
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.ownerID = ocs.organizationID AND pp.accountType = 3
WHERE ocs.configPropertyID = 4024;

INSERT IGNORE INTO rpt_workspace.cDunn_sightsEnabledUsersByPlan
SELECT A.planID, pp.paymentProfileID, pp.mainContactDomain, COUNT(DISTINCT(userID)) 
FROM rpt_workspace.js_csPlanReportSightsUsers A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.planID GROUP BY 1;

UPDATE rpt_main_02.stg_sfdc_domain_stats A
SET sightsEnabledUsers = (SELECT SUM(sightsEnabledUsers) 
	FROM rpt_workspace.cDunn_sightsEnabledUsersByPlan B
WHERE B.domain = A.domain);


DROP TABLE IF EXISTS rpt_main_02.stg_3090DayDomainActivity;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_3090DayDomainActivity
(domain VARCHAR(100),
plans INT,
licensedUsers INT,
30DayLoggedInLicensedUsers INT,
90DayLoggedInLicensedUsers INT,
30DayLicensedLoginRate DECIMAL(10,2),
90DayLicensedLoginRate DECIMAL(10,2),
totalUsers INT,
30DayLoggedInUsers INT,
90DayLoggedInUsers INT,
30DayLoginRateAll DECIMAL(10,2),
90DayLoginRateAll DECIMAL(10,2),
PRIMARY KEY (domain))
;

INSERT INTO rpt_main_02.stg_3090DayDomainActivity (domain, plans, licensedUsers, 30DayLoggedInLicensedUsers, 90DayLoggedInLicensedUsers)
SELECT ppcu.planDomain, COUNT(DISTINCT(ppcu.planID)), COUNT(DISTINCT(ppcu.mainContactUserID)), COUNT(DISTINCT(lct.userID)), COUNT(DISTINCT(lct2.userID))
FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
LEFT JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID AND lct.daysSinceLastLogin <= 30
LEFT JOIN rpt_main_02.rpt_loginCountTotal lct2 ON lct2.userID = ppcu.mainContactUserID AND lct2.daysSinceLastLogin <= 90
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = ppcu.planDomain
WHERE isp.domain IS NULL
GROUP BY 1
;

UPDATE rpt_main_02.stg_3090DayDomainActivity 
SET 	30DayLicensedLoginRate = 30DayLoggedInLicensedUsers/licensedUsers,
	90DayLicensedLoginRate = 90DayLoggedInLicensedUsers/licensedUsers;

DROP TABLE IF EXISTS rpt_workspace.cDunn_domainTotalUsers;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_domainTotalUsers
(domain VARCHAR(100),
totalUsers INT,
30DayLoggedInUsers INT,
90DayLoggedInUsers INT,
30DayLoginRateAll DECIMAL(10,2),
90DayLoginRateAll DECIMAL(10,2),
PRIMARY KEY (domain));

INSERT INTO rpt_workspace.cDunn_domainTotalUsers
SELECT masterDomain, COUNT(DISTINCT(mainContactUserID)), 
COUNT(DISTINCT(CASE WHEN daysSinceLastLogin <= 30 THEN mainContactUserID ELSE NULL END)),
COUNT(DISTINCT(CASE WHEN daysSinceLastLogin <= 90 THEN mainContactUserID ELSE NULL END)),
NULL,
NULL
FROM rpt_main_02.arc_cDunn_templateUsersNew
WHERE mainContactUserID >= 1000000 AND accountType != 3
GROUP BY 1;

UPDATE rpt_workspace.cDunn_domainTotalUsers
SET 	30DayLoginRateAll = 30DayLoggedInUsers/totalUsers,
	90DayLoginRateAll = 90DayLoggedInUsers/totalUsers;
	



UPDATE rpt_main_02.stg_3090DayDomainActivity A
JOIN rpt_workspace.cDunn_domainTotalUsers B ON A.domain = B.domain
SET A.totalUsers = B.totalUsers,
A.30DayLoggedInUsers = B.30DayLoggedInUsers,
A.90DayLoggedInUsers = B.90DayLoggedInUsers,
A.30DayLoginRateAll = B.30DayLoginRateAll,
A.90DayLoginRateAll = B.90DayLoginRateAll;


UPDATE rpt_main_02.stg_sfdc_domain_stats A
JOIN rpt_main_02.stg_3090DayDomainActivity B ON A.domain = B.domain
SET 	A.30DayLicensedLoginRate = B.30DayLicensedLoginRate,
	A.90DayLicensedLoginRate = B.90DayLicensedLoginRate,
	A.30DayLoginRateAll = B.30DayLoginRateAll,
	A.90DayLoginRateAll = B.90DayLoginRateAll;
	
DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_domainRSMRollup;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sfdc_domainRSMRollup (domain VARCHAR(100), recordType VARCHAR(15),monthlyPaymentChange DECIMAL(43,14), PRIMARY KEY (domain, recordType));
INSERT INTO rpt_main_02.stg_sfdc_domainRSMRollup (domain, recordType, monthlyPaymentChange)
SELECT mainContactUserAccount.domain, rsm.recordType, SUM(rsm.monthlyPaymentChange*12)
FROM rpt_main_02.output_RevenueSummaryMonthly rsm 
LEFT OUTER JOIN rpt_main_02.userAccount mainContactUserAccount  ON rsm.mainContactUserID = mainContactUserAccount.userID
GROUP BY mainContactUserAccount.domain, rsm.recordType;
	
DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo (domain VARCHAR(100), recordType VARCHAR(15),monthlyPaymentChange DECIMAL(43,14), PRIMARY KEY (domain, recordType));
INSERT INTO rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo (domain, recordType, monthlyPaymentChange)
SELECT mainContactUserAccount.domain, rsm.recordType, SUM(rsm.monthlyPaymentChange*12)
FROM rpt_main_02.output_RevenueSummaryMonthly rsm 
LEFT OUTER JOIN rpt_main_02.userAccount mainContactUserAccount ON rsm.mainContactUserID = mainContactUserAccount.userID
WHERE rsm.recordDateTime >= DATE_SUB(NOW(),INTERVAL 12 MONTH)
GROUP BY mainContactUserAccount.domain, rsm.recordType;

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollup ON ds.domain = stg_sfdc_domainRSMRollup.domain AND recordType = "Wins"
SET ds.ACV_Wins_AllTime = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollup ON ds.domain = stg_sfdc_domainRSMRollup.domain AND recordType = "Upgrades"
SET ds.ACV_Upgrades_AllTime = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollup ON ds.domain = stg_sfdc_domainRSMRollup.domain AND recordType = "Downgrades"
SET ds.ACV_Downgrades_AllTime = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollup ON ds.domain = stg_sfdc_domainRSMRollup.domain AND recordType = "Losses"
SET ds.ACV_Losses_AllTime = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo ON ds.domain = stg_sfdc_domainRSMRollupLast12Mo.domain AND recordType = "Wins"
SET ds.ACV_Wins_Last12Mo = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo ON ds.domain = stg_sfdc_domainRSMRollupLast12Mo.domain AND recordType = "Upgrades"
SET ds.ACV_Upgrades_Last12Mo = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo ON ds.domain = stg_sfdc_domainRSMRollupLast12Mo.domain AND recordType = "Downgrades"
SET ds.ACV_Downgrades_Last12Mo = (monthlyPaymentChange);

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.stg_sfdc_domainRSMRollupLast12Mo ON ds.domain = stg_sfdc_domainRSMRollupLast12Mo.domain AND recordType = "Losses"
SET ds.ACV_Losses_Last12Mo = (monthlyPaymentChange);


UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Upgrades_AllTime = 0 WHERE ACV_Upgrades_AllTime IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Downgrades_AllTime = 0 WHERE ACV_Downgrades_AllTime IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Losses_AllTime = 0 WHERE ACV_Losses_AllTime IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Wins_Last12Mo = 0 WHERE ACV_Wins_Last12Mo IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Upgrades_Last12Mo = 0 WHERE ACV_Upgrades_Last12Mo IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Downgrades_Last12Mo = 0 WHERE ACV_Downgrades_Last12Mo IS NULL;
UPDATE rpt_main_02.stg_sfdc_domain_stats SET ACV_Losses_Last12Mo = 0 WHERE ACV_Losses_Last12Mo IS NULL;

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.arc_domainEmailExclusion ON ds.domain = arc_domainEmailExclusion.domain
SET ds.Domain_Opt_Out__c = CASE WHEN arc_domainEmailExclusion.domain IS NOT NULL THEN 1 ELSE 0 END;

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON ds.domain = arc_ISPDomains.domain
SET ds.ISP__c = CASE WHEN arc_ISPDomains.domain IS NOT NULL THEN 1 ELSE 0 END;

DROP TABLE IF EXISTS rpt_main_02.stg_sfdc_domainPE;

CREATE TABLE rpt_main_02.`stg_sfdc_domainPE` (
  domain VARCHAR(100) NOT NULL DEFAULT '',
  quadScore TINYINT,
  PRIMARY KEY (`domain`)
) DEFAULT CHARSET=utf8
;

DROP TABLE IF EXISTS rpt_workspace.ts_ScatterQuad;

CREATE TABLE rpt_workspace.ts_ScatterQuad as
SELECT domain,productID,round(licensedUsers/userLimit,2) as utilization,round(toothbrushSuperUsers/licensedUsers,2) as superUserPercent
FROM rpt_main_02.rpt_csPlanReport
;

INSERT INTO rpt_main_02.stg_sfdc_domainPE
SELECT domain,MIN(IF(superUserPercent>=.2,(IF(utilization>=.8,4,3)),(IF(utilization>=.8,2,1)))+IF(productID IN (3,4),4,0))
FROM rpt_workspace.ts_ScatterQuad
GROUP BY 1
;

UPDATE rpt_main_02.stg_sfdc_domain_stats ds
JOIN rpt_main_02.stg_sfdc_domainPE pe ON ds.domain = pe.domain
SET ds.Product_Engagement_Status=
CASE WHEN IF(pe.quadScore<=4,pe.quadScore,pe.quadScore-4)=4 THEN 'Grow' WHEN IF(pe.quadScore<=4,pe.quadScore,pe.quadScore-4)=3 THEN 'Deploy' WHEN IF(pe.quadScore<=4,pe.quadScore,pe.quadScore-4)=2 THEN 'Activate' WHEN IF(pe.quadScore<=4,pe.quadScore,pe.quadScore-4)=1 THEN 'Salvage' END
;

/* INSERT INTO ss_sfdc_02.arc_sfdc_domainUpload
SELECT A.*
FROM rpt_main_02.stg_sfdc_domain_stats A
LEFT JOIN rpt_main_02.stg_paidDomainInfoOld B ON A.domain = B.domain
WHERE B.domain IS NULL;

INSERT IGNORE INTO ss_sfdc_02.arc_sfdc_domainUpload
SELECT A.*
FROM rpt_main_02.stg_sfdc_domain_stats A
LEFT JOIN rpt_main_02.stg_paidDomainInfoOld B ON A.domain = B.domain
	AND A.maxProduct = B.maxProduct AND IFNULL(A.highestPlanID,0) = IFNULL(B.highestPlanID,0) AND IFNULL(A.plans,0) = IFNULL(B.plans,0) 
	AND IFNULL(A.nextRenewalDate,0) = IFNULL(B.nextRenewalDate,0)
	AND IFNULL(A.collaborators,0) = IFNULL(B.collaborators,0) AND IFNULL(A.maxACV,0) = IFNULL(B.maxACV,0)
	AND IFNULL(A.paidLicensedUsers,0) = IFNULL(B.paidLicensedUsers,0) AND IFNULL(A.assignedLicensedUsers,0) = IFNULL(B.assignedLicensedUsers,0)
	AND IFNULL(A.pendingLicensedUsers,0) = IFNULL(B.pendingLicensedUsers,0) AND IFNULL(A.ACV_Wins_AllTime,0) = IFNULL(B.ACV_Wins_AllTime,0)
	AND IFNULL(A.ACV_Upgrades_AllTime,0) = IFNULL(B.ACV_Upgrades_AllTime,0) AND IFNULL(A.ACV_Downgrades_AllTime,0) = IFNULL(B.ACV_Downgrades_AllTime,0)
	AND IFNULL(A.ACV_Losses_AllTime,0) = IFNULL(B.ACV_Losses_AllTime,0) AND IFNULL(A.ACV_Wins_Last12Mo,0) = IFNULL(B.ACV_Wins_Last12Mo,0)
	AND IFNULL(A.ACV_Upgrades_Last12Mo,0) = IFNULL(B.ACV_Upgrades_Last12Mo,0) AND IFNULL(A.ACV_Downgrades_Last12Mo,0) = IFNULL(B.ACV_Downgrades_Last12Mo,0)
	AND IFNULL(A.ACV_Losses_Last12Mo,0) = IFNULL(B.ACV_Losses_Last12Mo,0)
WHERE B.domain IS NULL; */

INSERT INTO ss_sfdc_02.arc_sfdc_domainUpload
SELECT * FROM rpt_main_02.stg_sfdc_domain_stats;