# java
import SQLForce
from com.ziclix.python.sql import zxJDBC

# python
from datetime import datetime
import subprocess

# script
import config

def build_db_cursor():
    # set up our database connection
    d, u, p, v = "jdbc:mysql://127.0.0.1/", config.DATABASE_USER, config.DATABASE_PASSWORD, "org.gjt.mm.mysql.Driver"
    db = zxJDBC.connect(d, u, p, v)
    c = db.cursor()

    return db, c

def build_mapper(smartsheet_list, salesforce_list):
    # our mapper: salesforce -> smartsheet
    # we map this direction because Salesforce is case sensitive. you can use the
    # Dictionary keys as a list and perform comprehensions later.
    mapper = {}
    for x in smartsheet_list:
        for y in salesforce_list:
            if x.lower() == y.lower() or x.lower() + "__c" == y.lower():
                mapper[x] = y

    return mapper

def fetch_salesforce_columns():
    # lets first get our list of fields from Salesforce
    desc_statement = "CONNECT PROFILE Main\nDESCRIBE Lead"
    p = subprocess.Popen(["java", "-jar", "sqlforce.jar"], stdout=subprocess.PIPE, stdin=subprocess.PIPE)
    output = p.communicate(input=desc_statement)[0]

    salesforce_list = []
    for each in output.split('\n'):
        salesforce_list.append(each)

    return salesforce_list

def fetch_smartsheet_columns():
    # grab our DESCRIBE and parse it
    db, c = build_db_cursor()
    c.execute("DESCRIBE rpt_main_02.arc_sfdc_upload")
    results = c.fetchall()
    c.close()
    db.close()

    smartsheet_list = []
    for each in results:
        smartsheet_list.append(each[0])

    return smartsheet_list

def main():
    smartsheet_list = fetch_smartsheet_columns()
    salesforce_list = fetch_salesforce_columns()

    mapper = build_mapper(smartsheet_list, salesforce_list)


    # abuse our dictionary into a list
    salesforce_columns = []
    for each in mapper:
        salesforce_columns.append(each)

    # and then build this into a string for SQL
    smartsheet_columns = ",".join(salesforce_columns)

    # perform our select
    db, c = build_db_cursor()
    c.execute("select uploadID from rpt_main_02.arc_sfdc_upload where uploadDateTime is NULL")
    results = c.fetchall()

    # we need to save our IDs so we can set the uploadDateTime later
    id_list = []
    for each in results:
        id_list.append( str(each[0]) )
    id_string = ",".join(id_list)

    # this is the only section we really care about

    count = 0
    try:
        session = SQLForce.Session("main")
        for each in id_list:
            c.execute("select " + smartsheet_columns + " from rpt_main_02.arc_sfdc_upload WHERE uploadID=?", [each])
            results = c.fetchall()

            data = []
            for result in results[0]:
                if type(result) == unicode:
                    data.append( result.encode('ascii', 'replace') )
                else:
                    data.append( result )

            # shove all our data into salesforce
            session.insert("Lead", salesforce_columns, [data])
            c.execute("UPDATE rpt_main_02.arc_sfdc_upload set uploadDateTime = NOW() WHERE uploadID=?", [each])
            c.execute("COMMIT")
            count += 1
    except Exception, e:
        print "!!! successfully imported " + str(count) + " items"
        print "!!! we failed on uploadID:" + str(each)
        raise e

    c.close()
    db.close()
    print ">>> successfully imported " + str(count) + " items"

if __name__ == "__main__":
    main()

