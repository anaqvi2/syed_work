/**************************************** NAS Assignment ****************************************/

-- This needs to be run manually to setup the lead assignment table.

-- Table that holds a record of all/only NAS reps, start from scratch each time  
DROP TABLE leadflow.stg_leadRedistributionNAS;

CREATE TABLE leadflow.stg_leadRedistributionNAS 
(ID INT NOT NULL AUTO_INCREMENT, 
SSOwner VARCHAR(50), 
Weight DECIMAL(38,10), 
LeadRate DECIMAL(38,10), 
LeadAllotment INT, 
LeadCount INT, 
PRIMARY KEY (ID));


-- Fill the table with reps and weighting
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (1, "AndrewBr", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (2, "AndreyM", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (3, "BlakeT", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (4, "ChrisB", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (5, "ClayB", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (6, "CourtniK", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (7, "DrewD", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (8, "EricB", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (9, "ErinB", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (10, "Evan", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (11, "HayleyV", 0.8);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (12, "JordanT", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (13, "Kari", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (14, "LaurenV", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (15, "LukeW", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (16, "MaddyL", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (17, "MarkL", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (18, "MarkW", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (19, "MattL", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (20, "NickK", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (21, "NikkiS", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (22, "Rich", 0.8);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (23, "RyanG", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (24, "Sam", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (25, "SaraA", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (26, "ScottY", 0);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (27, "SeanMa", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (28, "StephenR", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (29, "ThomasP", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (30, "TimS", 1);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (31, "ToryG", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (32, "DanRe", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (33, "CurranP", 1.25);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (34, "JamesK", 1.5);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (35, "PaulB", 1.5);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (36, "NickW", 1.5);
INSERT INTO leadflow.stg_leadRedistributionNAS (ID, SSOwner, Weight) VALUES (37, "HedroL", 1.5);

SELECT COUNT(SSOwner)
FROM leadflow.stg_leadRedistributionNAS 
INTO @repCount;

SELECT SUM(Weight) 
FROM leadflow.stg_leadRedistributionNAS 
INTO @totalWeight;

-- find each reps porition of the whole 
UPDATE leadflow.stg_leadRedistributionNAS A
SET A.leadRate = A.Weight/@totalWeight;

UPDATE leadflow.stg_leadRedistributionNAS A
SET A.LeadAllotment = CEILING(A.leadRate* 1000),   	-- use ceiling to make sure we fill all the slots
								LeadCount = 0;  	-- need to set to number so incrementing later works

-- should add up close to 1.00
-- SELECT SUM(LeadRate) FROM leadflow.stg_leadRedistributionNAS;

-- should be just above 1000, if not the set will not be complete (slots will be empty and some lead matches might get missed)
-- SELECT SUM(LeadAllotment) FROM leadflow.stg_leadRedistributionNAS;


-- need stored procedure so we can do lopping
DELIMITER $$
USE leadflow$$
DROP PROCEDURE IF EXISTS LeadAssignmentNAS$$

CREATE PROCEDURE LeadAssignmentNAS()
BEGIN
	-- blank out names, filling in names helps us keep our place in the loop
	UPDATE leadflow.arc_leadAssignmentNAS SET SSOwner = NULL;

	SELECT COUNT(SSOwner)FROM leadflow.stg_leadRedistributionNAS INTO @repCount;

	SELECT  -1 INTO @LastAssignment; 
	
	-- loop until all the slots are filled
	WHILE @LastAssignment < 999 DO
	
		SELECT 1 INTO @repCounter;		
		
		-- loop through all the reps, until they have used up their allotment
		WHILE @repCounter <= @repCount DO 
		
			UPDATE leadflow.arc_leadAssignmentNAS
			LEFT OUTER JOIN  leadflow.stg_leadRedistributionNAS ON stg_leadRedistributionNAS.ID = @repCounter
			SET arc_leadAssignmentNAS.SSOwner = stg_leadRedistributionNAS.SSOwner,
			stg_leadRedistributionNAS.LeadCount = LeadCount + 1
			WHERE AssignmentID = @LastAssignment + 1 AND LeadAllotment > LeadCount; 
			
			-- using max insted of incrementing because we don't want to increment if that rep already used their allotment of leads
			SELECT MAX(AssignmentID) FROM leadflow.arc_leadAssignmentNAS WHERE SSOwner IS NOT NULL INTO @LastAssignment;
			
			SET @repCounter = @repCounter + 1;
		END WHILE;		
	END WHILE;
END$$

DELIMITER ;

-- execute the procedure created uiabove once
CALL leadflow.LeadAssignmentNAS();

-- check the distribution and put back in NAS sheet
SELECT SSOwner, COUNT(*) FROM leadflow.arc_leadAssignmentNAS GROUP BY 1;


