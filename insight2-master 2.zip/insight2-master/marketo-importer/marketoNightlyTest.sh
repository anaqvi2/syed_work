echo 'Starting marketoNightly.sh'

SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
MARKETO_HOME=${WORKSPACE}/marketo-importer

LOG_DATE=$1
DB_NAME=$2
LOG_FILE=${STATS_HOME}/logs/marketoNightlyTest_${DB_NAME}_${LOG_DATE}.log
echo $LOG_FILE
echo "mew1"
exec > $LOG_FILE 2>&1
echo $?

# See if there were any errors in the log file
echo "mew2"
echo "mew3"
MEW="$(grep -iw mew ${LOG_FILE})"
echo "${MEW}"
echo "mew4"

# did the SQL file work?
# If there were errors in the log file, then still return 1
echo "ERROR: There were errors detected during execution."
exit 1

# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

echo 'Finished marketoNightly.sh'
