
DELIMITER $$
DROP FUNCTION IF EXISTS `getAppBehaviorScoreV1`$$
CREATE FUNCTION `getAppBehaviorScoreV1`(loginCount INT, eventLogCount INT, sheetCount INT, sharingCount INT,  reportCount INT,
				isTeamTrial INT, accountRole VARCHAR(100)) RETURNS INT
    DETERMINISTIC
BEGIN

DECLARE getBehaviorScore INT;

SET getBehaviorScore = 
	COALESCE(loginCount, 0) + 										-- +1 for every login
	COALESCE(eventLogCount / 100, 0)  +								-- +1 for every 100 client events
	(COALESCE(sheetCount, 0) * 5) +  								-- +5 for every sheet
	(COALESCE(sharingCount, 0) * 5)	+								-- +5 for every share
	(LEAST(COALESCE(sharingCount, 0), 1) * 15) +					-- +15 extra for first share
	(COALESCE(reportCount, 0) * 5)	+								-- +5 for every report
	(LEAST(COALESCE(reportCount, 0), 1) * 15);						-- +15 extra for first report
--	(greatest(COALESCE(workspaceCount - 1, 0), 0) * 5)	+			-- +5 for every workspace, -1 to not count 'Sheets' workspace
--	(greatest(LEAST(COALESCE(workspaceCount - 1, 0), 1), 0) * 15);	-- +15 extra for second workspace
	
IF isTeamTrial = 1 -- team trials get 10 points more
	THEN SET getBehaviorScore = getBehaviorScore + 10;  
END IF;  

IF isTeamTrial = 1 AND accountRole = "Owner"  -- team trial owners get an additional 10 points
	THEN SET getBehaviorScore = getBehaviorScore + 10;
END IF;

RETURN getBehaviorScore;
END$$


DELIMITER ;