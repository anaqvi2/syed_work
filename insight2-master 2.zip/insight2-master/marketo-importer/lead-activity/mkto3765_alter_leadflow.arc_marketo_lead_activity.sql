USE leadflow;

SELECT DATABASE();

# SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
#
# SELECT 6 INTO @highestNightlyUpdatePriority;  	 -- updates for new leads from previous day plus more urgent data
# SELECT 5 INTO @mediumHighNightlyUpdatePriority;  -- lead scoring
# SELECT 4 INTO @mediumNightlyUpdatePriority;   	 -- activity indicators
# SELECT 2 INTO @lowestNightlyUpdatePriority;   	 -- domain rollup type info

ALTER TABLE leadflow.arc_marketo_lead_activity
    ADD COLUMN marketoGUID VARCHAR(128) NULL
    FIRST,
    CHANGE ID id BIGINT(20) NULL,
    DROP PRIMARY KEY;
SELECT "************************************* drop primary key: ", ROW_COUNT(), NOW();

UPDATE leadflow.arc_marketo_lead_activity
SET marketoGUID = id;
SELECT "************************************* copy id to marketoGUID: ", ROW_COUNT(), NOW();

ALTER TABLE leadflow.arc_marketo_lead_activity
    CHANGE marketoGUID marketoGUID VARCHAR(128)
CHARSET utf8mb4
COLLATE utf8mb4_unicode_520_ci NOT NULL,
    ADD PRIMARY KEY (marketoGUID);
SELECT "************************************* add new primary key: ", ROW_COUNT(), NOW();
