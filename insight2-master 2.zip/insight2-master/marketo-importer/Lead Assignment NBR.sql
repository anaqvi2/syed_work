/**************************************** NBR Assignment ****************************************/

-- This needs to be run manually to setup the lead assignment table.

-- Table that holds a record of all/only NBR reps, start from scratch each time  
DROP TABLE leadflow.stg_leadRedistributionNBR;

CREATE TABLE leadflow.stg_leadRedistributionNBR 
(ID INT NOT NULL AUTO_INCREMENT, 
SSOwner VARCHAR(50), 
Weight DECIMAL(38,10), 
LeadRate DECIMAL(38,10), 
LeadAllotment INT, 
LeadCount INT, 
PRIMARY KEY (ID));


-- Fill the table with reps and weighting
-- as of now, all the reps get equal weighting, but this code supports putting in a weighting value.

INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (1, "BrendanF", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (2, "PatM", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (3, "JasonR", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (4, "NateG", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (5, "GreyG", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (6, "StevenW", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (7, "AndrewF", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (8, "SarahS", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (9, "ConorH", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (10, "JonD", 1);
-- INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (11, "MeganS", 1); -- no longer with company, turned off new leads 2017-10-16 
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (11, "JeffW", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (12, "EricG", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (13, "CatrinaS", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (14, "NadiaO", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (15, "SurfW", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (16, "MarkD", 1);
-- INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (18, "RyanC", 1);  -- moving to cdm role, turned off new leads 2017-10-16
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (17, "BrianK", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (18, "KyleJO", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (19, "DrewDu", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (20, "DevinB", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (21, "DanielF", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (22, "DaneM", 1);
-- INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (25, "KyleB", 1);  -- moving to cdm role, turned off new leads 2017-10-16
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (23, "BrianW", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (24, "CarlyC", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (25, "MattG", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (26, "RickM", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (27, "LeahC", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (28, "ClaytonH", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (29, "Darren", 1);
-- INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (33, "Chad", 1);  -- moving to cdm role, turned off new leads 2017-10-16
-- INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (34, "NickN", 1);  -- moving to cdm role, turned off new leads 2017-10-16
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (30, "JeffWa", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (31, "JesseR", 1);

-- new reps turned on 10/19
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (32, "AkiraB", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (33, "EricF", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (34, "RyanJ", 1);
INSERT INTO leadflow.stg_leadRedistributionNBR (ID, SSOwner, Weight) VALUES (35, "RyanT", 1);




SELECT COUNT(SSOwner)
FROM leadflow.stg_leadRedistributionNBR 
INTO @repCount;

SELECT SUM(Weight) 
FROM leadflow.stg_leadRedistributionNBR 
INTO @totalWeight;

-- find each reps porition of the whole 
UPDATE leadflow.stg_leadRedistributionNBR A
SET A.leadRate = A.Weight/@totalWeight;

UPDATE leadflow.stg_leadRedistributionNBR A
SET A.LeadAllotment = CEILING(A.leadRate* 1000),   	-- use ceiling to make sure we fill all the slots
								LeadCount = 0;  	-- need to set to number so incrementing later works

-- should add up close to 1.00
-- SELECT SUM(LeadRate) FROM leadflow.stg_leadRedistributionNBR;

-- should be just above 1000, if not the set will not be complete (slots will be empty and some lead matches might get missed)
-- SELECT SUM(LeadAllotment) FROM leadflow.stg_leadRedistributionNBR;


-- need stored procedure so we can do lopping
DELIMITER $$
USE leadflow$$
DROP PROCEDURE IF EXISTS LeadAssignmentNBR$$

CREATE PROCEDURE LeadAssignmentNBR()
BEGIN
	-- blank out names, filling in names helps us keep our place in the loop
	UPDATE leadflow.arc_leadAssignmentNBR SET SSOwner = NULL;

	SELECT COUNT(SSOwner)FROM leadflow.stg_leadRedistributionNBR INTO @repCount;

	SELECT  -1 INTO @LastAssignment; 
	
	-- loop until all the slots are filled
	WHILE @LastAssignment < 999 DO
	
		SELECT 1 INTO @repCounter;		
		
		-- loop through all the reps, until they have used up their allotment
		WHILE @repCounter <= @repCount DO 
		
			UPDATE leadflow.arc_leadAssignmentNBR
			LEFT OUTER JOIN  leadflow.stg_leadRedistributionNBR ON stg_leadRedistributionNBR.ID = @repCounter
			SET arc_leadAssignmentNBR.SSOwner = stg_leadRedistributionNBR.SSOwner,
			stg_leadRedistributionNBR.LeadCount = LeadCount + 1
			WHERE AssignmentID = @LastAssignment + 1 AND LeadAllotment > LeadCount; 
			
			-- using max insted of incrementing because we don't want to increment if that rep already used their allotment of leads
			SELECT MAX(AssignmentID) FROM leadflow.arc_leadAssignmentNBR WHERE SSOwner IS NOT NULL INTO @LastAssignment;
			
			SET @repCounter = @repCounter + 1;
		END WHILE;		
	END WHILE;
END$$

DELIMITER ;

-- execute the procedure created uiabove once
CALL leadflow.LeadAssignmentNBR();

-- check the distribution and put back in NBR sheet
SELECT SSOwner, COUNT(*) FROM leadflow.arc_leadAssignmentNBR GROUP BY 1;



