USE leadflow;

SELECT DATABASE();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
# SET GLOBAL innodb_online_alter_log_max_size = 268435456;
# SELECT 6 INTO @highestNightlyUpdatePriority;  	 -- updates for new leads from previous day plus more urgent data
# SELECT 5 INTO @mediumHighNightlyUpdatePriority;  -- lead scoring
# SELECT 4 INTO @mediumNightlyUpdatePriority;   	 -- activity indicators
# SELECT 2 INTO @lowestNightlyUpdatePriority;   	 -- domain rollup type info

SELECT '************************************* rows: ', ROW_COUNT(), NOW();

DROP TABLE IF EXISTS leadflow.arc_marketo_upload_baseline_20180109;
CREATE TABLE IF NOT EXISTS leadflow.arc_marketo_upload_baseline_20180109 LIKE leadflow.arc_marketo_upload;
INSERT INTO leadflow.arc_marketo_upload_baseline_20180109
    SELECT *
    FROM leadflow.arc_marketo_upload;

SELECT '************************************* rows: ', ROW_COUNT(), NOW();

SELECT COUNT(1)
FROM leadflow.arc_marketo_upload;
SELECT COUNT(1)
FROM leadflow.arc_marketo_upload_baseline_20180109;

# DROP TABLE IF EXISTS leadflow.tmp_company;
# CREATE TABLE IF NOT EXISTS leadflow.tmp_company
# (
#     INDEX (userID)
# )
#         SELECT
#             mu.userID,
#             mu.isOrgDomain,
#             mu.company,
#             CASE
#             WHEN mu.isOrgDomain = 1 THEN COALESCE(a.Name, sm.dataValue, sr.itemValue, lc.companyName, lc2.companyName, lc3.companyName)
#             ELSE org.name
#             END             newCompany,
#             a.Name,
#             sr.itemValue,
#             sm.dataValue,
#             lc.companyName  companyName1,
#             lc2.companyName companyName2,
#             lc3.companyName companyName3,
#             org.name        orgName
#         FROM leadflow.arc_marketo_upload mu
#             LEFT OUTER JOIN ss_sfdc_02.domain d ON mu.emailDomain = d.Domain_Name_URL__c
#             LEFT OUTER JOIN ss_sfdc_02.account a ON d.Account__c = a.Id
#             LEFT OUTER JOIN ss_core_02.salesMarketingUserData sm ON mu.userID = sm.userID AND sm.dataKey = 'company'
#             LEFT OUTER JOIN rpt_main_02.arc_lead411Companies201703 lc ON mu.emailDomain = lc.domain
#             LEFT OUTER JOIN rpt_main_02.arc_lead411CompaniesV2 lc2 ON mu.emailDomain = lc2.domain
#             LEFT OUTER JOIN rpt_main_02.arc_lead411Companies lc3 ON mu.emailDomain = lc3.domain
#             LEFT OUTER JOIN ss_account_02.signupRequestTrackingItem sr ON mu.signupRequestID = sr.signupRequestID AND sr.itemName = 'su_company'
#             LEFT OUTER JOIN ss_core_02.organizationUserRole our ON mu.userID = our.userID AND our.role = 'MEMBER'
#             LEFT OUTER JOIN ss_core_02.organization org ON our.organizationID = org.organizationID
#         WHERE COALESCE(mu.company, '') != COALESCE(CASE
#                                                    WHEN mu.isOrgDomain = 1 THEN COALESCE(a.Name, sm.dataValue, sr.itemValue, lc.companyName,
#                                                                                          lc2.companyName, lc3.companyName)
#                                                    ELSE org.name
#                                                    END, '') COLLATE utf8mb4_unicode_520_ci;
# SELECT '************************************* rows: ', ROW_COUNT(), NOW();
#
# UPDATE leadflow.arc_marketo_upload mu
#     JOIN leadflow.tmp_company tmp ON mu.userID = tmp.userID
# SET mu.company        = tmp.newCompany,
#     mu.pushToMarketo  = GREATEST(mu.pushToMarketo, 6),
#     mu.updateDateTime = CURRENT_TIMESTAMP();
# SELECT '************************************* rows: ', ROW_COUNT(), NOW();

# DROP TABLE IF EXISTS leadflow.tmp_numberofemployees;
# CREATE TABLE IF NOT EXISTS leadflow.tmp_numberofemployees
# (
#     INDEX (userID)
# )
#         SELECT
#             mu.userID,
#             mu.isOrgDomain,
#             mu.numberOfEmployees,
#             CASE WHEN mu.isOrgDomain = 1 THEN
#                 COALESCE(
#                     CASE
#                     WHEN lc.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '-', -1)), UNSIGNED)
#                     WHEN lc.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '<', -1)), UNSIGNED)
#                     WHEN lc.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc.employeeRange, '>', -1)), UNSIGNED)
#                     WHEN CONVERT(lc.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc.employeeRange, UNSIGNED)
#                     ELSE NULL
#                     END,
#                     CASE
#                     WHEN lc2.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '-', -1)), UNSIGNED)
#                     WHEN lc2.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '<', -1)), UNSIGNED)
#                     WHEN lc2.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc2.employeeRange, '>', -1)), UNSIGNED)
#                     WHEN CONVERT(lc2.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc2.employeeRange, UNSIGNED)
#                     ELSE NULL
#                     END,
#                     CASE
#                     WHEN lc3.employeeRange LIKE '%-%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '-', -1)), UNSIGNED)
#                     WHEN lc3.employeeRange LIKE '%<%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '<', -1)), UNSIGNED)
#                     WHEN lc3.employeeRange LIKE '%>%' THEN CONVERT(TRIM(SUBSTRING_INDEX(lc3.employeeRange, '>', -1)), UNSIGNED)
#                     WHEN CONVERT(lc3.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc3.employeeRange, UNSIGNED)
#                     ELSE NULL
#                     END
#                 ) ELSE NULL END newNumberOfEmployees,
#             lc.employeeRange    employeeRange1,
#             lc2.employeeRange   employeeRange2,
#             lc3.employeeRange   employeeRange3
#         FROM leadflow.arc_marketo_upload mu
#             LEFT OUTER JOIN rpt_main_02.arc_lead411Companies201703 lc ON mu.emailDomain = lc.domain
#             LEFT OUTER JOIN rpt_main_02.arc_lead411CompaniesV2 lc2 ON mu.emailDomain = lc2.domain
#             LEFT OUTER JOIN rpt_main_02.arc_lead411Companies lc3 ON mu.emailDomain = lc3.domain
#         WHERE COALESCE(mu.numberOfEmployees, '') != COALESCE(CASE
#                                                              WHEN mu.isOrgDomain = 1 THEN
#                                                                  COALESCE(
#                                                                      CASE
#                                                                      WHEN lc.employeeRange LIKE '%-%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc.employeeRange, '-', -1)), UNSIGNED)
#                                                                      WHEN lc.employeeRange LIKE '%<%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc.employeeRange, '<', -1)), UNSIGNED)
#                                                                      WHEN lc.employeeRange LIKE '%>%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc.employeeRange, '>', -1)), UNSIGNED)
#                                                                      WHEN CONVERT(lc.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc.employeeRange,
#                                                                                                                                 UNSIGNED)
#                                                                      ELSE NULL
#                                                                      END,
#                                                                      CASE
#                                                                      WHEN lc2.employeeRange LIKE '%-%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc2.employeeRange, '-', -1)), UNSIGNED)
#                                                                      WHEN lc2.employeeRange LIKE '%<%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc2.employeeRange, '<', -1)), UNSIGNED)
#                                                                      WHEN lc2.employeeRange LIKE '%>%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc2.employeeRange, '>', -1)), UNSIGNED)
#                                                                      WHEN CONVERT(lc2.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc2.employeeRange,
#                                                                                                                                  UNSIGNED)
#                                                                      ELSE NULL
#                                                                      END,
#                                                                      CASE
#                                                                      WHEN lc3.employeeRange LIKE '%-%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc3.employeeRange, '-', -1)), UNSIGNED)
#                                                                      WHEN lc3.employeeRange LIKE '%<%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc3.employeeRange, '<', -1)), UNSIGNED)
#                                                                      WHEN lc3.employeeRange LIKE '%>%' THEN CONVERT(
#                                                                          TRIM(SUBSTRING_INDEX(lc3.employeeRange, '>', -1)), UNSIGNED)
#                                                                      WHEN CONVERT(lc3.employeeRange, UNSIGNED) != 0 THEN CONVERT(lc3.employeeRange,
#                                                                                                                                  UNSIGNED)
#                                                                      ELSE NULL
#                                                                      END
#                                                                  ) ELSE NULL
#                                                              END, '');
# SELECT '************************************* rows: ', ROW_COUNT(), NOW();