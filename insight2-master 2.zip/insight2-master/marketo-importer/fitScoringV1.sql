CREATE TABLE rpt_main_02.rpt_fitScoreModelV1 (
	Category VARCHAR (50),
	Variable VARCHAR (50),
	Coefficient DECIMAL (18,8)
);


LOAD DATA LOCAL INFILE 'C:/fitScoreV1Coefficients.csv'
INTO TABLE rpt_main_02.rpt_fitScoreModelV1
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\r'
IGNORE 1 LINES
(Category, Variable, Coefficient);



-- create the function



DELIMITER $$
DROP FUNCTION IF EXISTS `getFitScoreV1`$$
CREATE FUNCTION `getFitScoreV1`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code INT, wasShared INT) RETURNS TINYINT(3)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;

SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X2 = CONCAT(X2a, "_", X2b);
-- SET X2=sc_code;
SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X4 = wasShared;

IF dm = '0' THEN SET aP = '.001';
-- isOrgDomain & not in model (higher volume)
ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';
-- isOrgDomain & in Model
ELSEIF dm = '1'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'Intercept'),
	beta1 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'locale' AND  c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'sc_code' AND c.Variable = X2), 
	beta3 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'wasSharedToPriorToTrial'), 
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4))+1);
	
	SET aP = (CASE WHEN P > .1 THEN .1
				   WHEN P <.001 THEN .001
				   WHEN P IS NULL THEN .015 
				   ELSE P 
			  END); 
END IF;

SET fP = ROUND(aP*1000);

RETURN fP;
END$$


DELIMITER ;
