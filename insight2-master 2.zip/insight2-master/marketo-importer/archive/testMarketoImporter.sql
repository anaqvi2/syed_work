# test performance of marketoUpload
use test;
select now();

-- Determine last payment profile loaded to Salesforce for Smartscoring
SELECT MAX(paymentProfileID__c) FROM arc_marketo_upload WHERE smartscore_code__c IS NOT NULL into @v_destMaxId;
-- If no Smartscore payment profile go off the last one loaded to sfdc
SELECT IFNULL(@v_destMaxId,(SELECT MAX(paymentProfileID__c) FROM arc_marketo_upload)) into @v_destMaxId;


DROP TABLE IF EXISTS stg_smartscoring_leads;
DROP TABLE IF EXISTS stg_sharedToUsers;
DROP TABLE IF EXISTS stg_smartscoring_leads_final;
DROP TABLE IF EXISTS stg_smartscoring_leads;

CREATE TEMPORARY TABLE IF NOT EXISTS stg_smartscoring_leads
(
	userID BIGINT,	
	insertDateTime DATETIME, 
	languageName VARCHAR(100), 
	domain VARCHAR(300)
)
;

INSERT stg_smartscoring_leads (userID, insertDateTime, languageName, domain)
SELECT 
	ua.userID, 
	pp.insertDateTime,
	rl.languageName, 
	SUBSTR(ua.emailAddress, INSTR(ua.emailAddress,'@') + 1) AS domain
	FROM ss_core_02.userAccount ua
	LEFT JOIN ref_language rl ON SUBSTR(ua.locale,1,2)=rl.languageCode
	LEFT JOIN ss_core_02.paymentProfile pp ON ua.userID=pp.ownerID and pp.accountType !=3
	WHERE rl.languageName = 'English' /* Only English locales */
	AND pp.paymentProfileID >= @v_destMaxId /* Pull new trials since last run*/
;

-- Determine which users are GoogleApps users
CREATE INDEX ix_userID ON stg_smartscoring_leads (userID);

CREATE TEMPORARY TABLE IF NOT EXISTS stg_smartscoring_leads_final
(userID BIGINT, insertDateTime DATETIME, languageName VARCHAR(100), domain VARCHAR(300), GoogleAppsFlag BOOL)
;

INSERT stg_smartscoring_leads_final (userID, insertDateTime, languageName, domain, GoogleAppsFlag)
SELECT DISTINCT sssl.userID,
sssl.insertDateTime,
sssl.languageName,
sssl.domain,
CASE WHEN oid.openIDIdentifierID IS NOT NULL THEN 1 ELSE 0 END AS GoogleAppsFlag
FROM stg_smartscoring_leads sssl
LEFT JOIN 
(
SELECT openIDIdentifierID, userID
FROM ss_core_02.openIDIdentifier
WHERE provider IN ('GoogleApps', 'GoogleOAuth2')
) oid ON sssl.userID=oid.userID
;

-- Determine which users were shared to prior to trial start
ALTER TABLE stg_smartscoring_leads_final ADD SharedPriorToTrial TINYINT;

UPDATE stg_smartscoring_leads_final SET SharedPriorToTrial = 0;

CREATE TEMPORARY TABLE IF NOT EXISTS stg_sharedToUsers
(userID BIGINT, firstSharedToDate DATETIME)
;

INSERT stg_sharedToUsers (userID, firstSharedToDate)
	SELECT gam.userID, min(gam.insertDateTime) as firstSharedToDate
	FROM ss_core_02.gridAccessMap gam
	JOIN stg_smartscoring_leads_final slf ON gam.userID=slf.userID
	WHERE gam.userID<>gam.insertByUserID
	GROUP BY gam.userID
;

CREATE INDEX ix_userID ON stg_sharedToUsers (userID);

UPDATE stg_smartscoring_leads_final stg
SET SharedPriorToTrial = 
(
	SELECT CASE WHEN stg.insertDateTime >= epd.firstSharedToDate THEN 1 ELSE 0 END
	FROM stg_sharedToUsers epd 
	WHERE stg.userID=epd.userID
)
;

UPDATE stg_smartscoring_leads_final SET SharedPriorToTrial = 0 WHERE SharedPriorToTrial IS NULL;

-- Insert Smartscore leads into archive table
INSERT INTO arc_DailySmartscoreLeads
(snapshotDate, userInsertDateTime, userID, userDomain, GoogleAppsFlag, SharedPriorToTrial, employeeCount, leadType, SignupRequestID, smartscoreDateTime)
SELECT 
	CURRENT_DATE(),
	sslf.insertDateTime,
	sslf.userID,
	sslf.domain,
	sslf.GoogleAppsFlag,
	sslf.SharedPriorToTrial,
	MAX(hcd.employeesTotal),
	"Prosumer", /*Default to Prosumer; Change based on Named Enterprise Table*/
	sr.signupRequestID,
	NOW()
FROM stg_smartscoring_leads_final sslf
LEFT OUTER JOIN arc_DailySmartscoreLeads ins ON sslf.userID=ins.userID
LEFT OUTER JOIN arc_HooversCompanyData hcd ON sslf.domain=hcd.companyDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON sslf.domain=sr.userID
WHERE ins.userID IS NULL

Group by 1,3
;

/*Remove users from ISP domains*/
DELETE FROM arc_DailySmartscoreLeads 
WHERE userDomain IN (SELECT DISTINCT domain FROM arc_ISPDomains);

DELETE FROM arc_DailySmartscoreLeads 
WHERE userDomain in ("smartsheet.com", "cps.edu");

/*Update SSOwner for Enterprise (Named) domains*/
UPDATE arc_DailySmartscoreLeads 
JOIN arc_sfdc_enterpriseDomains ON arc_sfdc_enterpriseDomains.companyDomain = arc_DailySmartscoreLeads.userDomain
SET arc_DailySmartscoreLeads.leadType = "Enterprise (Named)"
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL
AND snapshotDate = CURRENT_DATE();

/*check for alternate subdomains  ex:  kellogg.northwestern.edu */
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",-2) = arc_sfdc_enterpriseDomains.companyDomain 
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE arc_DailySmartscoreLeads.leadType = "Enterprise (Named)" AND arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*check for alternate subdomains for other sub domains ex: shopping.woolworths.com.au*/
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",-3) = arc_sfdc_enterpriseDomains.companyDomain 
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE arc_DailySmartscoreLeads.leadType = "Enterprise (Named)" AND arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*check for foreign versions of exisitng domains abb.com.nz*/
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",2) = arc_sfdc_enterpriseDomains.companyDomain 
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE arc_DailySmartscoreLeads.leadType = "Enterprise (Named)" AND arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*Update SSOwner for Jennifer's domains*/
UPDATE arc_DailySmartscoreLeads 
JOIN rpt_paidDomains 
	ON rpt_paidDomains.mainContactDomain = arc_DailySmartscoreLeads.userDomain AND rpt_paidDomains.maxProduct = "Enterprise" 
SET arc_DailySmartscoreLeads.leadType = "Enterprise (Other)"
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL
AND snapshotDate = CURRENT_DATE();

UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN rpt_paidDomains 
	ON rpt_paidDomains.mainContactDomain = arc_DailySmartscoreLeads.userDomain AND rpt_paidDomains.maxProduct = "Enterprise" 
SET arc_DailySmartscoreLeads.SSOwner = "Jennifer"
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL AND arc_DailySmartscoreLeads.leadType = "Enterprise (Other)"
AND snapshotDate = CURRENT_DATE();

/*Remove users from edu domains*/
DELETE FROM arc_DailySmartscoreLeads 
WHERE userDomain LIKE "%.edu%"
AND arc_DailySmartscoreLeads.SSOwner IS NULL ;

/*Update SSOwner for previously existing domains*/
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",-2)
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_domains.SSOwner 
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE() 
AND leadType = "Prosumer"
;

/*Update SSOwner for previously existing domains*/
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",-3)
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_domains.SSOwner 
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE() 
AND leadType = "Prosumer"
;

/*check for foreign versions of exisitng domains abb.com.nz*/
UPDATE arc_DailySmartscoreLeads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(arc_DailySmartscoreLeads.userDomain,".",2) = arc_sfdc_enterpriseDomains.companyDomain 
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE arc_DailySmartscoreLeads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE()
AND arc_DailySmartscoreLeads.leadType = "Prosumer"
;

/*Update SSOwner for ISR1s*/
/*Add ISR1 domains to arc_sdfc_domains*/
INSERT IGNORE arc_sfdc_domains (companyDomain, dateAdded)
SELECT userDomain, CURRENT_DATE()
FROM arc_DailySmartscoreLeads
LEFT OUTER JOIN arc_ISPDomains ON arc_DailySmartscoreLeads.userDomain = arc_ISPDomains.domain
WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND SSOwner IS NULL AND userDomain IS NOT NULL
AND arc_ISPDomains.userCount IS NULL /*Remove ISP domains*/
AND SharedPriorToTrial = 1 AND googleAppsFlag = 0
GROUP BY 1
;

/*Assign owners for new ISR1 domains*/
SELECT MAX(nullCount) INTO @nullCount FROM arc_sfdc_domains; /*find starting point for count for randomdistribution*/

UPDATE arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 WHERE SSOwner IS NULL;

UPDATE arc_sfdc_domains
SET SSOwner = "Chad" WHERE SSOwner IS NULL;


/*Update SSOwner for these now assigned domains*/
UPDATE arc_DailySmartscoreLeads LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailySmartscoreLeads.userDomain
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_domains.SSOwner WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND arc_DailySmartscoreLeads.SSOwner IS NULL;


/*Update SSOwner for all other reps*/

/*Insert new Prosumer domains to arc_sfdc_domains*/
INSERT arc_sfdc_domains (companyDomain, dateAdded)
SELECT userDomain, CURRENT_DATE()
FROM arc_DailySmartscoreLeads
LEFT OUTER JOIN arc_ISPDomains ON arc_DailySmartscoreLeads.userDomain = arc_ISPDomains.domain
WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND SSOwner IS NULL AND userDomain IS NOT NULL
AND arc_ISPDomains.userCount IS NULL /*Remove ISP domains*/
GROUP BY 1
;

/*Assign owners for new domains*/
SELECT MAX(nullCount) INTO @nullCount FROM arc_sfdc_domains; /*find starting point for count for randomdistribution*/

UPDATE arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 WHERE SSOwner IS NULL;


UPDATE arc_sfdc_domains
SET SSOwner = "AJ" WHERE nullCount  % 9 = 0  AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Darren" WHERE nullCount % 9 = 1 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Sarah" WHERE nullCount % 9 = 2 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Sean" WHERE nullCount % 9 = 3 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Joe" WHERE nullCount % 9 = 4 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Jeff" WHERE nullCount % 9 = 5 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Chris" WHERE nullCount % 9 = 6 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 9 = 7 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ryaire" WHERE nullCount % 9 = 8 AND SSOwner IS NULL;

/*UPDATE arc_sfdc_domains
SET SSOwner = "Kevin" WHERE nullCount  % 11 = 2 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Taylor" WHERE nullCount  % 10 = 1 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 8 = 0 AND SSOwner IS NULL;*/


/*Count the unassigned users for potential AB Test purposes*/
SET @reachoutNum = 0;
UPDATE arc_DailySmartscoreLeads
SET dailyCount = @reachoutNum:=@reachoutNum + 1	WHERE dailyCount IS NULL AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;

/*Update SSOwner for these now assigned domains*/
UPDATE arc_DailySmartscoreLeads LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailySmartscoreLeads.userDomain
SET arc_DailySmartscoreLeads.SSOwner = arc_sfdc_domains.SSOwner WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND arc_DailySmartscoreLeads.SSOwner IS NULL;




-- Insert into Salesforce upload table 
 INSERT INTO arc_marketo_upload
 (
 	Company,
 	OwnerID,
 	Status,
 	domain__c,
 	userID__c,
 	paymentProfileID__c,
 	parentPaymentProfileID__c,
 	FirstName,
 	LastName,
 	Email,
 	Street,
 	City,
 	State,
 	PostalCode,
 	Country,
 	Phone,
 	NumberOfEmployees,
 	AnnualRevenue,
 	Title,
 	Website,
 	LeadSource,
 	ExistingEnterpriseDomain,
 	Existing_paid_domain__c,
 	trial_start_date__c,
 	search_term__c,
 	Smartscore_Code__c,
 	Shared_To__c,
 	Domain_s_Highest_Plan__c
 )

SELECT 
CASE hcd.companyName IS NULL WHEN 1 THEN ss.userDomain ELSE hcd.companyName END AS companyName,
CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "Jason"	THEN "00540000002HyR1"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	ss.userDomain,
	ss.userID,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,
	ua.emailAddress,
	hcd.address,
	hcd.primaryCity,
	hcd.primaryState,
	hcd.postalCode,
 	rc.countryName,
	CONCAT(hcd.areaCode,"-",hcd.PrimaryContactPhone) AS phone,
	hcd.employeesTotal,
	hcd.revenue,
	NULL AS Title,
	ss.userDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,
	(SELECT COUNT(*) FROM rpt_paymentProfile ProfileCount LEFT OUTER JOIN arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
		WHERE ProfileCount.mainContactDomain = ss.userDomain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
 		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
	MAX(pp.paymentStartDateTime) AS Trial_Start_Date,
	NULL AS search_term,
	CASE 
	WHEN sr.signupRequestID IS NULL THEN 'Org+Viral'
	WHEN sr.signupRequestID IS NOT NULL AND googleAppsFlag = 1 AND sharedPriorToTrial = 0 THEN 'Org+Google'
	WHEN sr.signupRequestID IS NOT NULL AND sharedPriorToTrial = 1 AND googleAppsFlag = 0 THEN 'Org+SharedPrior'
	WHEN sr.signupRequestID IS NOT NULL AND sharedPriorToTrial = 1 AND googleAppsFlag = 1 THEN 'Org+Shared+Google'
	WHEN sr.signupRequestID IS NOT NULL AND googleAppsFlag = 0 AND sharedPriorToTrial = 0 THEN 'Org+English'
	ELSE 'Other' END AS smartscore_code,
	ss.sharedPriorToTrial,
	rpt_paidDomains.MaxProduct
FROM arc_DailySmartscoreLeads ss
LEFT JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT JOIN arc_HooversCompanyData hcd ON ss.userDomain=hcd.companyDomain
LEFT JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT JOIN ref_country rc ON SUBSTR(ua.locale,4)=rc.countryCode
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.userDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID=upload.userID__c
LEFT OUTER JOIN rpt_paidDomains ON ss.userDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress
WHERE pp.paymentProfileID IS NOT NULL
	AND pp.productID = 1
	AND ss.sharedPriorToTrial = 0 /*Exclude users who have been shared to prior to trial*/
	AND upload.userID__c IS NULL
	AND arc_doNotContactList.InsertDate IS NULL
	AND pp.paymentStartDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
GROUP BY ua.emailAddress
;


/*Adding shared to prior to trial users who have now created a sheet*/
INSERT INTO arc_marketo_upload
 (
 	Company,
 	OwnerID,
 	STATUS,
 	domain__c,
 	userID__c,
 	paymentProfileID__c,
 	parentPaymentProfileID__c,
 	FirstName,
 	LastName,
 	Email,
 	Street,
 	City,
 	State,
 	PostalCode,
 	Country,
 	Phone,
 	NumberOfEmployees,
 	AnnualRevenue,
 	Title,
 	Website,
 	LeadSource,
 	ExistingEnterpriseDomain,
 	Existing_paid_domain__c,
 	trial_start_date__c,
 	search_term__c,
 	Smartscore_Code__c,
 	Shared_To__c,
 	Domain_s_Highest_Plan__c,
 	containerCount,
 	FirstContainerFromTrialStart
 )
SELECT 
CASE hcd.companyName IS NULL WHEN 1 THEN ss.userDomain ELSE hcd.companyName END AS companyName,
CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	WHEN "Jason"	THEN "00540000002HyR1"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	ss.userDomain,
	ss.userID,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,
	ua.emailAddress,
	hcd.address,
	hcd.primaryCity,
	hcd.primaryState,
	hcd.postalCode,
 	rc.countryName,
	CONCAT(hcd.areaCode,"-",hcd.PrimaryContactPhone) AS phone,
	hcd.employeesTotal,
	hcd.revenue,
	NULL AS Title,
	ss.userDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,
	(SELECT COUNT(*) FROM rpt_paymentProfile ProfileCount LEFT OUTER JOIN arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
		WHERE ProfileCount.mainContactDomain = ss.userDomain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
 		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
	MAX(pp.paymentStartDateTime) AS Trial_Start_Date,
	NULL AS search_term,
	'Org+Shared' AS smartscore_code,
	ss.sharedPriorToTrial,
	rpt_paidDomains.MaxProduct,
	COUNT(containerID) AS ContainerCount,
	TIME_TO_SEC(TIMEDIFF(MIN(container.insertDateTime),MAX(pp.paymentStartDateTime)))/3600 AS hoursFromTrialStart
	
FROM arc_DailySmartscoreLeads ss
LEFT JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT JOIN arc_HooversCompanyData hcd ON ss.userDomain=hcd.companyDomain
LEFT JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT JOIN ref_country rc ON SUBSTR(ua.locale,4) = rc.countryCode
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.userDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID = upload.userID__c
LEFT OUTER JOIN rpt_paidDomains ON ss.userDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN ss_core_02.container ON pp.ownerID = container.insertByUserID AND container.containerType = 2 AND pp.accountType !=3
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress

WHERE upload.userID__c IS NULL AND ss.sharedPriorToTrial = 1 AND pp.productID = 1 AND arc_doNotContactList.InsertDate IS NULL
AND pp.paymentStartDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
AND ss.userDomain NOT in ("cps.edu")
GROUP BY 4,5
HAVING ContainerCount > 0 AND hoursFromTrialStart < 24
;

/*One off changes to the table*/
UPDATE arc_marketo_upload
SET Status = "Pending" where domain__c in ("google.com", "cisco.com")
AND uploadDateTime is NULL /*Any time you're making changes like this, be sure to add this qualifier so leads that have already been entered are not effected*/
;

/*Marketo*/
/*Adding shared to prior to trial users who have now created a sheet*/
INSERT INTO arc_marketo_upload
 (
 	Company,
 	OwnerID,
 	STATUS,
 	domain__c,
 	userID__c,
 	paymentProfileID__c,
 	parentPaymentProfileID__c,
 	FirstName,
 	LastName,
 	Email,
 	Street,
 	City,
 	State,
 	PostalCode,
 	Country,
 	Phone,
 	NumberOfEmployees,
 	AnnualRevenue,
 	Title,
 	Website,
 	LeadSource,
 	ExistingEnterpriseDomain,
 	Existing_paid_domain__c,
 	trial_start_date__c,
 	search_term__c,
 	Smartscore_Code__c,
 	Shared_To__c,
 	Domain_s_Highest_Plan__c,
 	containerCount,
 	FirstContainerFromTrialStart
 )
SELECT 
CASE hcd.companyName IS NULL WHEN 1 THEN ss.userDomain ELSE hcd.companyName END AS companyName,
CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	WHEN "Jason"	THEN "00540000002HyR1"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	ss.userDomain,
	ss.userID,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,
	ua.emailAddress,
	hcd.address,
	hcd.primaryCity,
	hcd.primaryState,
	hcd.postalCode,
 	rc.countryName,
	CONCAT(hcd.areaCode,"-",hcd.PrimaryContactPhone) AS phone,
	hcd.employeesTotal,
	hcd.revenue,
	NULL AS Title,
	ss.userDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,
	(SELECT COUNT(*) FROM rpt_paymentProfile ProfileCount LEFT OUTER JOIN arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
		WHERE ProfileCount.mainContactDomain = ss.userDomain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
 		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
	MAX(pp.paymentStartDateTime) AS Trial_Start_Date,
	NULL AS search_term,
	'Org+Shared' AS smartscore_code,
	ss.sharedPriorToTrial,
	rpt_paidDomains.MaxProduct,
	COUNT(containerID) AS ContainerCount,
	TIME_TO_SEC(TIMEDIFF(MIN(container.insertDateTime),MAX(pp.paymentStartDateTime)))/3600 AS hoursFromTrialStart
	
FROM arc_DailySmartscoreLeads ss
LEFT JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT JOIN arc_HooversCompanyData hcd ON ss.userDomain=hcd.companyDomain
LEFT JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT JOIN ref_country rc ON SUBSTR(ua.locale,4) = rc.countryCode
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.userDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID = upload.userID__c
LEFT OUTER JOIN rpt_paidDomains ON ss.userDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN ss_core_02.container ON pp.ownerID = container.insertByUserID AND container.containerType = 2 AND pp.accountType !=3
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress

WHERE upload.userID__c IS NULL AND ss.sharedPriorToTrial = 1 AND pp.productID = 1 AND arc_doNotContactList.InsertDate IS NULL
AND pp.paymentStartDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
AND ss.userDomain NOT in ("cps.edu")
GROUP BY 4,5
HAVING ContainerCount > 0 AND hoursFromTrialStart < 24
;


select now();