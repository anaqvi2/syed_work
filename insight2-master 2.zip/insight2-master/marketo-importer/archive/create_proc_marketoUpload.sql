# Insight
# Stored Procedure for marketo upload
#
# Revision History
# 2014-03-29:  BMW:  Init.
select '### Compiling procedure marketoUpload()' as '' from dual;
use test;
delimiter //

drop procedure if exists marketoUpload//

create procedure marketoUpload(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
							   )
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 

call utl_logProcessStart('marketoUpload',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

-- Determine last payment profile loaded to Salesforce for Smartscoring
set v_destMaxId = (SELECT MAX(paymentProfileId) FROM arc_marketo_upload WHERE smartscoreCode IS NOT NULL);
-- If no Smartscore payment profile go off the last one loaded to sfdc
SET v_destMaxId = (SELECT IFNULL(v_destMaxId,(SELECT MAX(paymentProfileId) FROM arc_marketo_upload)));


DROP TABLE IF EXISTS tmp_marketo_leads;
DROP TABLE IF EXISTS tmp_googleApps_users;
DROP TABLE IF EXISTS tmp_sharedToUsers;
DROP TABLE IF EXISTS tmp_marketo_leads;

CREATE TEMPORARY TABLE IF NOT EXISTS tmp_marketo_leads like arc_marketo_upload;


alter table tmp_marketo_leads add (leadType varchar(20));
alter table tmp_marketo_leads add (SSOwner varchar(20));
alter table tmp_marketo_leads add (modifyDateTime dateTime);
alter table tmp_marketo_leads add (snapshotDate dateTime);
alter table tmp_marketo_leads add (dailyCount int);


INSERT tmp_marketo_leads 
	(userID, 
	 emailAddress,
	 firstName,
	 lastName,
	 newsFlags,
	 insertDateTime,
	 modifyDateTime,
	 localeLanguage,
     localeCountry,
	 emailDomain,
     isGoogleAppsInstalledDomain,
     wasSharedToPriorToTrial
    )
SELECT 
	ua.userID, 
	ua.emailAddress,
	ua.firstName,
	ua.lastName,
	ua.newsFlags,
	ua.insertDateTime,
	ua.modifyDateTime,
	rl.languageName, 
	rl.countryName,
	SUBSTR(ua.emailAddress, INSTR(ua.emailAddress,'@') + 1) AS domain,
	case when goog.userID is null then 0 else 1 end as isGoogleAppsInstalledDomain,
    case when ua.insertDateTime < gam.firstSharedToDate then 1 else 0 end as wasSharedToPriorToTrial

	FROM ss_core_02.userAccount ua
	LEFT JOIN ref_localeCountryLanguage rl ON ua.locale=rl.localeCode
	LEFT JOIN ss_core_02.paymentProfile pp ON ua.userID=pp.ownerID and pp.accountType !=3
    left join (SELECT distinct userID
               FROM ss_core_02.openIDIdentifier
			   WHERE provider IN ('GoogleApps', 'GoogleOAuth2')
              ) goog
        on ua.userId = goog.userID
	left join (SELECT userID, min(insertDateTime) as firstSharedToDate
	           FROM ss_core_02.gridAccessMap
               WHERE userID<>insertByUserID
	           GROUP BY userID
              ) gam
		on gam.userId = ua.userId

	WHERE pp.paymentProfileID >= v_destMaxId /* Pull new trials since last run*/
	AND ua.insertDateTime >= date_format(CURRENT_DATE(),'%Y-%m-%d')
;

-- Set Org domain flag
UPDATE tmp_marketo_leads stg
LEFT JOIN arc_ISPDomains d ON stg.emailDomain=d.domain
SET IsOrgDomain = CASE WHEN d.domain IS NULL THEN 1 ELSE 0 END
;

select 0;

-- Assign source
UPDATE tmp_marketo_leads stg
SET signupTracking_s_code = 
(
	SELECT srti.itemValue
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	WHERE srti.itemName = 's'
	AND sr.userID=stg.userID	
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format(sr.insertDateTime,'%Y-%m-%d')
	AND sr.resultStatus = 1
)
;

-- Assign campaign
UPDATE tmp_marketo_leads stg
SET signupTracking_c_code = 
(
	SELECT srti.itemValue
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	-- JOIN stg_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = 'c'
	AND sr.userID=stg.userID
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format(sr.insertDateTime,'%Y-%m-%d')
	AND sr.resultStatus = 1
)
;
select 1;

-- Assign segment
UPDATE tmp_marketo_leads stg
SET signupTracking_m_code = 
(
	SELECT srti.itemValue
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	WHERE srti.itemName = 'm'
	AND sr.userID=stg.userID	
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format(sr.insertDateTime,'%Y-%m-%d')
	AND sr.resultStatus = 1
)
;

/*Remove users from ISP domains*/
DELETE FROM tmp_marketo_leads 
WHERE emailDomain IN (SELECT DISTINCT domain FROM arc_ISPDomains);

DELETE FROM tmp_marketo_leads 
WHERE emailDomain in ("smartsheet.com", "cps.edu");

/*Update SSOwner for Enterprise (Named) domains*/
UPDATE tmp_marketo_leads 
JOIN arc_sfdc_enterpriseDomains ON arc_sfdc_enterpriseDomains.companyDomain = tmp_marketo_leads.emailDomain
SET leadType = "Enterprise (Named)"
WHERE tmp_marketo_leads.SSOwner IS NULL
AND snapshotDate = CURRENT_DATE();


select 2;


/*check for alternate subdomains  ex:  kellogg.northwestern.edu */
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",-2) = arc_sfdc_enterpriseDomains.companyDomain 
SET tmp_marketo_leads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE tmp_marketo_leads.leadType = "Enterprise (Named)" AND tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*check for alternate subdomains for other sub domains ex: shopping.woolworths.com.au*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",-3) = arc_sfdc_enterpriseDomains.companyDomain 
SET tmp_marketo_leads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE tmp_marketo_leads.leadType = "Enterprise (Named)" AND tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*check for foreign versions of exisitng domains abb.com.nz*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",2) = arc_sfdc_enterpriseDomains.companyDomain 
SET tmp_marketo_leads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE tmp_marketo_leads.leadType = "Enterprise (Named)" AND tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE();

/*Update SSOwner for Jennifer's domains*/
UPDATE tmp_marketo_leads 
JOIN rpt_paidDomains 
	ON rpt_paidDomains.mainContactDomain = tmp_marketo_leads.emailDomain AND rpt_paidDomains.maxProduct = "Enterprise" 
SET tmp_marketo_leads.leadType = "Enterprise (Other)"
WHERE tmp_marketo_leads.SSOwner IS NULL
AND snapshotDate = CURRENT_DATE();



select 3;

UPDATE tmp_marketo_leads 
LEFT OUTER JOIN rpt_paidDomains 
	ON rpt_paidDomains.mainContactDomain = tmp_marketo_leads.emailDomain AND rpt_paidDomains.maxProduct = "Enterprise" 
SET tmp_marketo_leads.SSOwner = "Jennifer"
WHERE tmp_marketo_leads.SSOwner IS NULL AND tmp_marketo_leads.leadType = "Enterprise (Other)"
AND snapshotDate = CURRENT_DATE();

/*Remove users from edu domains*/
DELETE FROM tmp_marketo_leads 
WHERE emailDomain LIKE "%.edu%"
AND tmp_marketo_leads.SSOwner IS NULL ;

/*Update SSOwner for previously existing domains*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",-2)
SET tmp_marketo_leads.SSOwner = arc_sfdc_domains.SSOwner 
WHERE tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE() 
AND leadType = "Prosumer"
;

/*Update SSOwner for previously existing domains*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",-3)
SET tmp_marketo_leads.SSOwner = arc_sfdc_domains.SSOwner 
WHERE tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE() 
AND leadType = "Prosumer"
;

/*check for foreign versions of exisitng domains abb.com.nz*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_enterpriseDomains ON SUBSTRING_INDEX(tmp_marketo_leads.emailDomain,".",2) = arc_sfdc_enterpriseDomains.companyDomain 
SET tmp_marketo_leads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE tmp_marketo_leads.SSOwner IS NULL 
AND snapshotDate = CURRENT_DATE()
AND tmp_marketo_leads.leadType = "Prosumer"
;

/*Update SSOwner for all other reps*/
/*Insert new Prosumer domains to arc_sfdc_domains*/
INSERT arc_sfdc_domains (companyDomain, dateAdded)
SELECT emailDomain, CURRENT_DATE()
FROM tmp_marketo_leads
LEFT OUTER JOIN arc_ISPDomains ON tmp_marketo_leads.emailDomain = arc_ISPDomains.domain
WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND SSOwner IS NULL AND emailDomain IS NOT NULL
AND arc_ISPDomains.userCount IS NULL /*Remove ISP domains*/
AND emailDomain not in (select companyDomain from arc_sfdc_domains)
GROUP BY 1
;

/*Assign owners for new domains*/
SELECT MAX(nullCount) INTO @nullCount FROM arc_sfdc_domains; /*find starting point for count for randomdistribution*/

UPDATE arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 WHERE SSOwner IS NULL;

UPDATE arc_sfdc_domains
SET SSOwner = "AJ" WHERE nullCount  % 10 = 0  AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Darren" WHERE nullCount % 10 = 1 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Sarah" WHERE nullCount % 10 = 2 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Sean" WHERE nullCount % 10 = 3 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Joe" WHERE nullCount % 10 = 4 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Jeff" WHERE nullCount % 10 = 5 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Chris" WHERE nullCount % 10 = 6 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 10 = 7 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ryaire" WHERE nullCount % 10 = 8 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Chad" WHERE nullCount % 10 = 9 AND SSOwner IS NULL;

/*UPDATE arc_sfdc_domains
SET SSOwner = "Kevin" WHERE nullCount  % 11 = 2 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Taylor" WHERE nullCount  % 10 = 1 AND SSOwner IS NULL;
UPDATE arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 8 = 0 AND SSOwner IS NULL;*/


/*Count the unassigned users for potential AB Test purposes*/
SET @reachoutNum = 0;
UPDATE tmp_marketo_leads
SET dailyCount = @reachoutNum:=@reachoutNum + 1	
WHERE dailyCount IS NULL 
AND snapshotDate = CURRENT_DATE() 
AND leadType = "Prosumer" 
AND SSOwner IS NULL;

/*Update SSOwner for these now assigned domains*/
UPDATE tmp_marketo_leads 
LEFT OUTER JOIN arc_sfdc_domains ON arc_sfdc_domains.companyDomain = tmp_marketo_leads.emailDomain
SET tmp_marketo_leads.SSOwner = arc_sfdc_domains.SSOwner 
WHERE leadType = "Prosumer" 
AND snapshotDate = CURRENT_DATE() 
AND tmp_marketo_leads.SSOwner IS NULL;


-- Insert into Marketo upload table 
insert into arc_marketo_upload (
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`ownerID`,
    `arc_marketo_upload`.`status`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`userID`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`street`,
    `arc_marketo_upload`.`city`,
    `arc_marketo_upload`.`state`,
    `arc_marketo_upload`.`postalCode`,
    `arc_marketo_upload`.`country`,
    `arc_marketo_upload`.`phone`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`annualRevenue`,
    `arc_marketo_upload`.`title`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`leadSource`,
    `arc_marketo_upload`.`existingEnterpriseDomain`,
    `arc_marketo_upload`.`existingPaidDomain`,
    `arc_marketo_upload`.`trialStartDate`,
    `arc_marketo_upload`.`searchTerm`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`sharedTo`,
    `arc_marketo_upload`.`domainsHighestPlan`

    #`arc_marketo_upload`.`containerCount`,
    #`arc_marketo_upload`.`firstContainerFromTrialStart`
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`sourceBucket`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`isOrgDomain`,
    #`arc_marketo_upload`.`newsFlags`,
    #`arc_marketo_upload`.`statusFlags`,
    #`arc_marketo_upload`.`localeLanguage`,
    #`arc_marketo_upload`.`localeCountry`,
    #`arc_marketo_upload`.`timeZone`,
    #`arc_marketo_upload`.`productName`,
    #`arc_marketo_upload`.`userLimit`,
    #`arc_marketo_upload`.`paymentStartDateTime`,
    #`arc_marketo_upload`.`nextPaymentDate`,
    #`arc_marketo_upload`.`paymentTerm`,
    #`arc_marketo_upload`.`planRate`,
    #`arc_marketo_upload`.`monthlyPlanRate_USD`,
    #`arc_marketo_upload`.`currencyCode`,
    #`arc_marketo_upload`.`teamTrial`,
    #`arc_marketo_upload`.`trialEndDate`,
    #`arc_marketo_upload`.`isTrialRestart`,
    #`arc_marketo_upload`.`primaryContactPhone`,
    #`arc_marketo_upload`.`billToAddress`,
    #`arc_marketo_upload`.`billToCity`,
    #`arc_marketo_upload`.`billToRegionCode`,
    #`arc_marketo_upload`.`billToPostCode`,
    #`arc_marketo_upload`.`billToCountryCode`,
    #`arc_marketo_upload`.`marktetoTrackingCookie`,
    #`arc_marketo_upload`.`signupTrackingKeyword`,
    #`arc_marketo_upload`.`signupTracking_s_code`
    #`arc_marketo_upload`.`signupTracking_c_code`,
    #`arc_marketo_upload`.`signupTracking_m_code`,
    #`arc_marketo_upload`.`SourceSource`,
    #`arc_marketo_upload`.`SourceSubSource`,
    #`arc_marketo_upload`.`salesforceOwnerID`,
    #`arc_marketo_upload`.`salesforceStatus`,
    #`arc_marketo_upload`.`salesforceLeadSource`,
    #`arc_marketo_upload`.`numberOfEmployeesHvrs`,
    #`arc_marketo_upload`.`annualRevenueHvrs`,
    #`arc_marketo_upload`.`titleHvrs`,
    #`arc_marketo_upload`.`companyHvrs`,
    #`arc_marketo_upload`.`ipCountry`,
    #`arc_marketo_upload`.`organizationName`,
    #`arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    #`arc_marketo_upload`.`wasSharedToPriorToTrial`,
    #`arc_marketo_upload`.`historyHighestPlan`,
    #`arc_marketo_upload`.`sheetCount`
    #`arc_marketo_upload`.`lastLogin`,
    #`arc_marketo_upload`.`lastMobileLogin`,
    #`arc_marketo_upload`.`isEverWellQualified`,
    #`arc_marketo_upload`.`isStrongLead`,
    #`arc_marketo_upload`.`eventLogCount`,
    #`arc_marketo_upload`.`loginCount`,
    #`arc_marketo_upload`.`sharingCount`,
    #`arc_marketo_upload`.`reportCount`
)
SELECT 
CASE hcd.companyName IS NULL WHEN 1 THEN ss.emailDomain ELSE hcd.companyName END AS companyName,
CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "Jason"	THEN "00540000002HyR1"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	ss.emailDomain,
	ss.userID,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,
	ua.emailAddress,  
#10

	hcd.address,
	hcd.primaryCity,
	hcd.primaryState,
	hcd.postalCode,
 	ss.localeCountry,
	CONCAT(hcd.areaCode,"-",hcd.PrimaryContactPhone) AS phone,
	hcd.employeesTotal,
	hcd.revenue,
	NULL AS Title,
	ss.emailDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,
	(SELECT COUNT(*) FROM rpt_paymentProfile ProfileCount LEFT OUTER JOIN arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
		WHERE ProfileCount.mainContactDomain = ss.emailDomain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
 		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
	MAX(pp.paymentStartDateTime) AS Trial_Start_Date, 
#20

	NULL AS search_term,
	CASE 
	WHEN sr.signupRequestID IS NULL THEN 'Org+Viral'
	WHEN sr.signupRequestID IS NOT NULL AND ss.isGoogleAppsInstalledDomain = 1 AND ss.wasSharedToPriorToTrial = 0 THEN 'Org+Google'
	WHEN sr.signupRequestID IS NOT NULL AND ss.wasSharedToPriorToTrial = 1 AND ss.isGoogleAppsInstalledDomain = 0 THEN 'Org+SharedPrior'
	WHEN sr.signupRequestID IS NOT NULL AND ss.wasSharedToPriorToTrial = 1 AND ss.isGoogleAppsInstalledDomain = 1 THEN 'Org+Shared+Google'
	WHEN sr.signupRequestID IS NOT NULL AND ss.isGoogleAppsInstalledDomain = 0 AND ss.wasSharedToPriorToTrial = 0 THEN 'Org+English'
	ELSE 'Other' END AS smartscore_code,
	ss.wasSharedToPriorToTrial,
	rpt_paidDomains.MaxProduct

FROM tmp_marketo_leads ss
LEFT JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT JOIN arc_HooversCompanyData hcd ON ss.emailDomain=hcd.companyDomain
LEFT JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.emailDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID=upload.userId
LEFT OUTER JOIN rpt_paidDomains ON ss.emailDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress
WHERE pp.paymentProfileID IS NOT NULL
	AND pp.productID = 1
	AND ss.wasSharedToPriorToTrial = 0 /*Exclude users who have been shared to prior to trial*/
	AND upload.userId IS NULL
	AND arc_doNotContactList.InsertDate IS NULL
	AND pp.paymentStartDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
GROUP BY ua.emailAddress
;


/*Adding shared to prior to trial users who have now created a sheet*/

insert into arc_marketo_upload (
    `arc_marketo_upload`.`company`,
    `arc_marketo_upload`.`ownerID`,
    `arc_marketo_upload`.`status`,
    `arc_marketo_upload`.`emailDomain`,
    `arc_marketo_upload`.`userID`,
    `arc_marketo_upload`.`paymentProfileID`,
    `arc_marketo_upload`.`parentPaymentProfileID`,
    `arc_marketo_upload`.`firstName`,
    `arc_marketo_upload`.`lastName`,
    `arc_marketo_upload`.`emailAddress`,
    `arc_marketo_upload`.`street`,
    `arc_marketo_upload`.`city`,
    `arc_marketo_upload`.`state`,
    `arc_marketo_upload`.`postalCode`,
    `arc_marketo_upload`.`country`,
    `arc_marketo_upload`.`phone`,
    `arc_marketo_upload`.`numberOfEmployees`,
    `arc_marketo_upload`.`annualRevenue`,
    `arc_marketo_upload`.`title`,
    `arc_marketo_upload`.`website`,
    `arc_marketo_upload`.`leadSource`,
    `arc_marketo_upload`.`existingEnterpriseDomain`,
    `arc_marketo_upload`.`existingPaidDomain`,
    `arc_marketo_upload`.`trialStartDate`,
    `arc_marketo_upload`.`searchTerm`,
    `arc_marketo_upload`.`smartscoreCode`,
    `arc_marketo_upload`.`sharedTo`,
    `arc_marketo_upload`.`domainsHighestPlan`,
    `arc_marketo_upload`.`containerCount`,
    `arc_marketo_upload`.`firstContainerFromTrialStart`
    #`arc_marketo_upload`.`pushToMarketo`,
    #`arc_marketo_upload`.`insertDateTime`,
    #`arc_marketo_upload`.`sourceBucket`,
    #`arc_marketo_upload`.`uploadDateTime`,
    #`arc_marketo_upload`.`isOrgDomain`,
    #`arc_marketo_upload`.`newsFlags`,
    #`arc_marketo_upload`.`statusFlags`,
    #`arc_marketo_upload`.`localeLanguage`,
    #`arc_marketo_upload`.`localeCountry`,
    #`arc_marketo_upload`.`timeZone`,
    #`arc_marketo_upload`.`productName`,
    #`arc_marketo_upload`.`userLimit`,
    #`arc_marketo_upload`.`paymentStartDateTime`,
    #`arc_marketo_upload`.`nextPaymentDate`,
    #`arc_marketo_upload`.`paymentTerm`,
    #`arc_marketo_upload`.`planRate`,
    #`arc_marketo_upload`.`monthlyPlanRate_USD`,
    #`arc_marketo_upload`.`currencyCode`,
    #`arc_marketo_upload`.`teamTrial`,
    #`arc_marketo_upload`.`trialEndDate`,
    #`arc_marketo_upload`.`isTrialRestart`,
    #`arc_marketo_upload`.`primaryContactPhone`,
    #`arc_marketo_upload`.`billToAddress`,
    #`arc_marketo_upload`.`billToCity`,
    #`arc_marketo_upload`.`billToRegionCode`,
    #`arc_marketo_upload`.`billToPostCode`,
    #`arc_marketo_upload`.`billToCountryCode`,
    #`arc_marketo_upload`.`marktetoTrackingCookie`,
    #`arc_marketo_upload`.`signupTrackingKeyword`,
    #`arc_marketo_upload`.`signupTracking_s_code`,
    #`arc_marketo_upload`.`signupTracking_c_code`,
    #`arc_marketo_upload`.`signupTracking_m_code`,
    #`arc_marketo_upload`.`SourceSource`,
    #`arc_marketo_upload`.`SourceSubSource`,
    #`arc_marketo_upload`.`salesforceOwnerID`,
    #`arc_marketo_upload`.`salesforceStatus`,
    #`arc_marketo_upload`.`salesforceLeadSource`,
    #`arc_marketo_upload`.`numberOfEmployeesHvrs`,
    #`arc_marketo_upload`.`annualRevenueHvrs`,
    #`arc_marketo_upload`.`titleHvrs`,
    #`arc_marketo_upload`.`companyHvrs`,
    #`arc_marketo_upload`.`ipCountry`,
    #`arc_marketo_upload`.`organizationName`,
    #`arc_marketo_upload`.`isGoogleAppsInstalledDomain`,
    #`arc_marketo_upload`.`wasSharedToPriorToTrial`,
    #`arc_marketo_upload`.`historyHighestPlan`,
    #`arc_marketo_upload`.`sheetCount`
    #`arc_marketo_upload`.`lastLogin`,
    #`arc_marketo_upload`.`lastMobileLogin`,
    #`arc_marketo_upload`.`isEverWellQualified`,
    #`arc_marketo_upload`.`isStrongLead`,
    #`arc_marketo_upload`.`eventLogCount`,
    #`arc_marketo_upload`.`loginCount`,
    #`arc_marketo_upload`.`sharingCount`,
    #`arc_marketo_upload`.`reportCount`
)
SELECT 
CASE hcd.companyName IS NULL WHEN 1 THEN ss.emailDomain ELSE hcd.companyName END AS companyName,
CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	WHEN "Jason"	THEN "00540000002HyR1"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	ss.emailDomain,
	ss.userID,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,
	ua.emailAddress,
	hcd.address,
	hcd.primaryCity,
	hcd.primaryState,
	hcd.postalCode,
 	ss.localeCountry,
	CONCAT(hcd.areaCode,"-",hcd.PrimaryContactPhone) AS phone,
	hcd.employeesTotal,
	hcd.revenue,
	NULL AS Title,
	ss.emailDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,
	(SELECT COUNT(*) FROM rpt_paymentProfile ProfileCount LEFT OUTER JOIN arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
		WHERE ProfileCount.mainContactDomain = ss.emailDomain AND ProfileCount.accountType !=3 
		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
 		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
	MAX(pp.paymentStartDateTime) AS Trial_Start_Date,
	NULL AS search_term,
	'Org+Shared' AS smartscore_code,
	ss.wasSharedToPriorToTrial,
	rpt_paidDomains.MaxProduct,
	COUNT(containerID) AS ContainerCount,
	TIME_TO_SEC(TIMEDIFF(MIN(container.insertDateTime),MAX(pp.paymentStartDateTime)))/3600 AS hoursFromTrialStart
	
FROM tmp_marketo_leads ss
LEFT JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT JOIN arc_HooversCompanyData hcd ON ss.emailDomain=hcd.companyDomain
LEFT JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.emailDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID = upload.userId
LEFT OUTER JOIN rpt_paidDomains ON ss.emailDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN ss_core_02.container ON pp.ownerID = container.insertByUserID AND container.containerType = 2 AND pp.accountType !=3
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress

WHERE upload.userId IS NULL AND ss.wasSharedToPriorToTrial = 1 AND pp.productID = 1 AND arc_doNotContactList.InsertDate IS NULL
AND pp.paymentStartDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
AND ss.emailDomain NOT in ("cps.edu")
GROUP BY 4,5
HAVING ContainerCount > 0 AND hoursFromTrialStart < 24
;

/*One off changes to the table*/
UPDATE arc_marketo_upload
SET Status = "Pending" where emailDomain in ("google.com", "cisco.com")
AND uploadDateTime is NULL /*Any time you're making changes like this, be sure to add this qualifier so leads that have already been entered are not effected*/
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;

call test.marketoUpload(null,5);

