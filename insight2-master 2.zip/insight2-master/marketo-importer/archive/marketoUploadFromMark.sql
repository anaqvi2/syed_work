/***************************************************************************************************************************/
/* This is running every 5 minutes, so it has to run super fast...			*/
/***************************************************************************************************************************/

-- Determine last user loaded to Salesforce for Smartscoring


(SELECT max(insertDateTime) FROM rpt_main_02.arc_marketo_upload INTO @maxInsertDateTime);
(SELECT max(userAccountModifyDateTime) FROM rpt_main_02.arc_marketo_upload INTO @maxUserAccountModifyDateTime);
(SELECT max(ppModifyDateTime) FROM rpt_main_02.arc_marketo_upload INTO @maxPPModifyDateTime);



-- Trial details
DROP TABLE IF EXISTS rpt_main_02.tmp_trials;
CREATE TABLE rpt_main_02.tmp_trials
(
	paymentProfileID BIGINT,
	accountType INT,
	userID BIGINT,
	trialDateTime DATETIME,
	trialEndDateTime DATETIME,
	firstTrial INT,
	trialSessionID BIGINT,
	KEY ix_ppid (paymentProfileID),
	KEY ix_userID (userID),
	KEY ix_sessionID (trialSessionID)
)
;

INSERT INTO rpt_main_02.tmp_trials
SELECT  
	hpp.paymentProfileID,
	hpp.accountType,
	hpp.ownerID AS userID,
	hpp.modifyDateTime,
	MIN(hppNext.modifyDateTime) as trialEndDateTime,
	CASE WHEN hppOld.productID IS NULL THEN 1 ELSE 0 END as firstTrial /* First time is a trial in which the user did not previously have a payment Profile*/,
	hpp.sessionLogID

FROM ss_core_02.hist_paymentProfile hpp
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppOld ON hpp.paymentProfileID = hppOld.paymentProfileID 
	AND hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND    /*Compare to previous hist_paymentProfile entry */
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppNext ON hppNext.paymentProfileID = hpp.paymentProfileID 
	AND hppNext.modifyDateTime > hpp.modifyDateTime AND hppNext.productID != 1 /*Compare to next non-trial hist_paymentProfile entry */

WHERE hpp.productID = 1
AND (hppOld.productID != 1 OR hppOld.productID IS NULL) /*Eliminates instance of trials being extended, previous hist_paymentProfile was also a trial  */
AND hpp.modifyDateTime > @maxInsertDateTime  -- toddj - using right boundary?
GROUP BY 1,4
;


-- Stage the leads
DROP TABLE IF EXISTS rpt_main_02.tmp_marketo_leads;
CREATE TABLE IF NOT EXISTS rpt_main_02.tmp_marketo_leads LIKE rpt_main_02.arc_marketo_upload;

ALTER TABLE rpt_main_02.tmp_marketo_leads ADD (leadType VARCHAR(20) DEFAULT 'Prosumer'); -- toddj - should we default?
ALTER TABLE rpt_main_02.tmp_marketo_leads ADD (SSOwner VARCHAR(20));  -- assigned by sproc then decoded for owner name
ALTER TABLE rpt_main_02.tmp_marketo_leads ADD (modifyDateTime DATETIME); -- toddj - needed?
ALTER TABLE rpt_main_02.tmp_marketo_leads ADD (dailyCount INT); -- toddj - needed?
ALTER TABLE rpt_main_02.tmp_marketo_leads ADD (sessionLogID BIGINT); -- toddj - needed?



-- Insert New trials since last run
INSERT IGNORE rpt_main_02.tmp_marketo_leads 
	(userID, 
	 emailAddress,
	 firstName,
	 lastName,
	 newsFlags,
	 statusFlags,
	 insertDateTime,
	 modifyDateTime,
	 locale,
	 emailDomain,
     isGoogleAppsInstalledDomain,
     wasSharedToPriorToTrial,
	 timeZone,
	 snapshotDate,
	 sessionLogID
    )


SELECT 
	ua.userID, 
	ua.emailAddress,
	ua.firstName,
	ua.lastName,
	ua.newsFlags,
	ua.statusFlags,
	tt.trialDateTime,
	ua.modifyDateTime,
	ua.locale,
	SUBSTR(ua.emailAddress, INSTR(ua.emailAddress,'@') + 1) AS domain,
	CASE WHEN goog.userID IS NULL THEN 0 ELSE 1 END AS isGoogleAppsInstalledDomain,
    CASE WHEN ua.insertDateTime >= gam.firstSharedToDate THEN 1 ELSE 0 END AS wasSharedToPriorToTrial,
	ua.timeZone,
	CURRENT_DATE(),
	tt.trialSessionID

	FROM rpt_main_02.tmp_trials tt
	LEFT OUTER JOIN ss_core_02.userAccount ua ON tt.userID=ua.userID
	LEFT OUTER JOIN ss_core_02.paymentProfile pp ON ua.userID=pp.ownerID AND pp.accountType !=3
    LEFT OUTER JOIN 
			(
				SELECT DISTINCT userID
				FROM ss_core_02.openIDIdentifier
				WHERE provider IN ('GoogleApps', 'GoogleOAuth2')
			) goog
        ON ua.userId = goog.userID
	LEFT OUTER JOIN 
			(
				SELECT userID, min(insertDateTime) AS firstSharedToDate
				FROM ss_core_02.gridAccessMap
				WHERE userID <> insertByUserID
				GROUP BY userID
			) gam
		ON gam.userId = ua.userId
;


-- Set Org domain flag
UPDATE rpt_main_02.tmp_marketo_leads stg
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains d ON stg.emailDomain=d.domain
SET IsOrgDomain = CASE WHEN d.domain IS NULL THEN 1 ELSE 0 END
;


--------------------------------------------------------------------------------------------------------
-- Signup Tracking Info
--------------------------------------------------------------------------------------------------------

-- toddj - I do not understand this.
-- Assign source
UPDATE tmp_marketo_leads mk_stg
SET signupTracking_s_code = 
(

SELECT itemValue
FROM
(
SELECT a2.userID, a3.itemValue
FROM
(
SELECT a.userID, min(a.signupRequestID) AS minSignupRequestID
FROM 	
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = 's'
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a
GROUP BY a.userID
) a2

LEFT OUTER JOIN
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg2 ON sr.userID=stg2.userID
	WHERE srti.itemName = 's'
	AND date_format(stg2.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a3
ON a3.userID=a2.userID AND a3.signupRequestID=a2.minSignupRequestID
) s
WHERE mk_stg.userID=s.userID
)
;


-- Assign campaign
UPDATE tmp_marketo_leads mk_stg
SET signupTracking_c_code = 
(

SELECT itemValue
FROM
(
SELECT a2.userID, a3.itemValue
FROM
(
SELECT a.userID, min(a.signupRequestID) AS minSignupRequestID
FROM 	
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = 'c'
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a
GROUP BY a.userID
) a2

LEFT OUTER JOIN
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg2 ON sr.userID=stg2.userID
	WHERE srti.itemName = 'c'
	AND date_format(stg2.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a3
ON a3.userID=a2.userID AND a3.signupRequestID=a2.minSignupRequestID
) s
WHERE mk_stg.userID=s.userID
)
;



-- Assign segment
UPDATE tmp_marketo_leads mk_stg
SET signupTracking_m_code = 
(

SELECT itemValue
FROM
(
SELECT a2.userID, a3.itemValue
FROM
(
SELECT a.userID, min(a.signupRequestID) AS minSignupRequestID
FROM 	
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = 'm'
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a
GROUP BY a.userID
) a2

LEFT OUTER JOIN
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg2 ON sr.userID=stg2.userID
	WHERE srti.itemName = 'm'
	AND date_format(stg2.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a3
ON a3.userID=a2.userID AND a3.signupRequestID=a2.minSignupRequestID
) s
WHERE mk_stg.userID=s.userID
)
;



-- Assign keyword
UPDATE tmp_marketo_leads mk_stg
SET signupTrackingKeyword = 
(

SELECT itemValue
FROM
(
SELECT a2.userID, a3.itemValue
FROM
(
SELECT a.userID, min(a.signupRequestID) AS minSignupRequestID
FROM 	
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = 'k'
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a
GROUP BY a.userID
) a2

LEFT OUTER JOIN
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg2 ON sr.userID=stg2.userID
	WHERE srti.itemName = 'k'
	AND date_format(stg2.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a3
ON a3.userID=a2.userID AND a3.signupRequestID=a2.minSignupRequestID
) s
WHERE mk_stg.userID=s.userID
)
;

-- Assign Marketo Tracking Cookie
UPDATE tmp_marketo_leads mk_stg
SET marketoTrackingCookie = 
(

SELECT itemValue
FROM
(
SELECT a2.userID, a3.itemValue
FROM
(
SELECT a.userID, min(a.signupRequestID) AS minSignupRequestID
FROM 	
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg ON sr.userID=stg.userID
	WHERE srti.itemName = '_mkto_trk'
	AND date_format(stg.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a
GROUP BY a.userID
) a2

LEFT OUTER JOIN 
(
	SELECT sr.userID, srti.itemValue, sr.insertDateTime, sr.signupRequestID
	FROM ss_core_02.signupRequest sr
	JOIN ss_core_02.signupRequestTrackingItem srti ON sr.signupRequestID=srti.signupRequestID
	JOIN rpt_main_02.tmp_marketo_leads stg2 ON sr.userID=stg2.userID
	WHERE srti.itemName = '_mkto_trk'
	AND date_format(stg2.modifyDateTime,'%Y-%m-%d')=date_format((sr.insertDateTime),'%Y-%m-%d')
	AND sr.resultStatus = 1
	AND BINARY upper(srti.itemName) != srti.itemName
) a3
ON a3.userID=a2.userID AND a3.signupRequestID=a2.minSignupRequestID
) s
WHERE mk_stg.userID=s.userID
)
;



-- Assign Sales reps
CALL `rpt_main_02`.`marketoLeadAssignment`();


-- Get AB Test Variations
UPDATE tmp_marketo_leads mk_upload
SET ABTests = 
(
	SELECT 
	group_concat(
		concat(siteSettingElementName,':',floor(valueNumeric)) separator ';') AS ABTests
	FROM siteSettingElementValue ssev
	WHERE siteSettingElementName LIKE '%SS_ABTEST%'
	AND mk_upload.userID=ssev.userID
	GROUP BY ssev.userID
)
;


--------------------------------------------------------------------------------------------------------
-- Insert into Marketo upload table 
-- Note: This only inserts new users
-- We'll need to do updates for existing users separately
--------------------------------------------------------------------------------------------------------


INSERT INTO rpt_main_02.arc_marketo_upload 
(
	userID,
	ownerID,
	status,
	paymentProfileID,
	parentPaymentProfileID,
	organizationName,
	productName,
	userLimit,
	paymentStartDateTime,
	nextPaymentDate,
	paymentTerm,
	planRate,
	currencyCode,
	monthlyPlanRate_USD,
	teamTrial,
	firstName,
	lastName,
	emailAddress,
	emailDomain,
	insertDateTime,
	userAccountModifyDateTime,
	ppModifyDateTime,
	snapshotDate,
	isOrgDomain,
	newsFlags,
	statusFlags,
	primaryContactPhone, billToAddress1, billToAddress2, billToCity, billToRegionCode, billToPostCode, billToCountryCode,
	marketoTrackingCookie,
	locale,
	timeZone,
	signupTracking_s_code,
	signupTracking_c_code,
	signupTracking_m_code,
	signupTrackingKeyword,
	ABTests,
	isGoogleAppsInstalledDomain,
	ipCountry,
	website,
	leadSource,
	existingPaidDomain,
	trialStartDate,
	smartscoreCode,
	wasSharedToPriorToTrial,
	domainsHighestPlan,
	pushToMarketo,
	isTrialRestart,
	trialEndDate

)
SELECT 
	ss.userID,
	CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "Jason"	THEN "00540000002HyR1"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	ELSE "Error" END AS OwnerID,	
	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END AS STATUS,
	pp.paymentProfileID,
	pp.parentPaymentProfileID,
	o.name AS orgName,
	SMARTSHEET_PRODUCTNAME(pp.productID) AS productName,
	pp.userLimit,
	pp.paymentStartDateTime,
	pp.nextPaymentDate,
	pp.paymentTerm,
	pp.planRate,
	pp.currencyCode,
	CASE WHEN pp.currencyCode = 'USD' THEN pp.planRate/pp.paymentTerm ELSE (pp.planRate/hce.exchangeRate)/pp.paymentTerm END AS monthlyPlanRate,
	CASE WHEN trialPP.accountType = 2 THEN 1 ELSE 0 END AS TeamTrial,
	ua.firstName,
	CASE WHEN ua.lastName IS NULL THEN "No Last Name" 
		WHEN ua.lastName = " " THEN "No Last Name"
		ELSE ua.lastName END AS lastName,	
	ss.emailAddress,  
	ss.emailDomain,
	CURRENT_TIMESTAMP(),
	ss.modifyDateTime,
	#ss.userAccountModifyDateTime,
	pp.modifyDateTime,
	ss.snapshotDate,
	ss.isOrgDomain,
	ss.newsFlags,
	ss.statusFlags,

	
	pp.primaryContactPhone,
	pp.billToAddress1,
	pp.billToAddress2,
	pp.billToCity,
	pp.billToRegionCode,
	pp.billToPostCode,
	pp.billToCountryCode,
	ss.marketoTrackingCookie,
	
 	ss.locale,
	ss.timeZone,
	ss.signupTracking_s_code,
	ss.signupTracking_c_code,
	ss.signupTracking_m_code,
	ss.signupTrackingKeyword,
	ss.ABTests,
	ss.isGoogleAppsInstalledDomain,

	ref.countryName AS IPCountry,


	ss.emailDomain AS website,
	CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END AS leadSource,

	CASE WHEN rpt_paidDomains.MaxProduct IN ("Basic", "Advanced", "Premium", "Team", "Enterprise") THEN 1 ELSE 0 END AS ExistingPaidDomain_c,
 
	tt.trialDateTime AS trialStartDate,


	CASE 
	WHEN sr.signupRequestID IS NULL THEN 'Org+Viral'
	WHEN sr.signupRequestID IS NOT NULL AND ss.isGoogleAppsInstalledDomain = 1 AND ss.wasSharedToPriorToTrial = 0 THEN 'Org+Google'
	WHEN sr.signupRequestID IS NOT NULL AND ss.wasSharedToPriorToTrial = 1 AND ss.isGoogleAppsInstalledDomain = 0 THEN 'Org+SharedPrior'
	WHEN sr.signupRequestID IS NOT NULL AND ss.wasSharedToPriorToTrial = 1 AND ss.isGoogleAppsInstalledDomain = 1 THEN 'Org+Shared+Google'
	WHEN sr.signupRequestID IS NOT NULL AND ss.isGoogleAppsInstalledDomain = 0 AND ss.wasSharedToPriorToTrial = 0 THEN 'Org+English'
	ELSE 'Other' END AS smartscore_code,
	ss.wasSharedToPriorToTrial,
	rpt_paidDomains.MaxProduct AS domainsHighestPlan,
	1 AS pushToMarketo,
	CASE WHEN tt.firstTrial = 1 THEN 0 ELSE 1 END AS trialRestart,
	tt.trialEndDateTime

FROM rpt_main_02.tmp_marketo_leads ss
LEFT OUTER JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT OUTER JOIN ss_core_02.paymentProfile trialPP ON ss.userID=trialPP.ownerID AND trialPP.accountType !=3 AND trialPP.productID = 1
LEFT OUTER JOIN ss_core_02.userAccount ua ON ss.userID=ua.userID
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.emailDomain
LEFT OUTER JOIN arc_marketo_upload upload ON ss.userID=upload.userId
LEFT OUTER JOIN rpt_paidDomains ON ss.emailDomain = rpt_paidDomains.mainContactDomain
LEFT OUTER JOIN ss_core_02.signupRequest sr ON ss.userID=sr.userID
LEFT OUTER JOIN arc_doNotContactList ON ua.emailAddress = arc_doNotContactList.emailAddress
LEFT OUTER JOIN ss_core_02.sessionLog sl ON ss.sessionLogID=sl.sessionLogID
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref ON sl.sourceIP=ref.ipAddress
LEFT OUTER JOIN ss_core_02.organization o ON pp.parentPaymentProfileID=o.paymentProfileID
LEFT OUTER JOIN rpt_main_02.tmp_trials tt ON pp.paymentProfileID=tt.paymentProfileID
LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
	AND pp.paymentStartDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime

WHERE pp.paymentProfileID IS NOT NULL
	AND upload.userId IS NULL
GROUP BY ua.emailAddress
;


--------------------------------------------------------------------------------------------------------
-- Identify and update values for existing users
--------------------------------------------------------------------------------------------------------
UPDATE rpt_main_02.arc_marketo_upload mk_upload
JOIN rpt_main_02.tmp_marketo_leads ss ON mk_upload.userID=ss.userID
LEFT OUTER JOIN ss_core_02.paymentProfile pp ON ss.userID=pp.ownerID AND pp.accountType !=3
LEFT OUTER JOIN arc_hubspotExcludeList ON arc_hubspotExcludeList.domain = ss.emailDomain
LEFT OUTER JOIN rpt_main_02.tmp_trials tt ON pp.paymentProfileID=tt.paymentProfileID
LEFT OUTER JOIN ss_core_02.paymentProfile trialPP ON ss.userID=trialPP.ownerID AND trialPP.accountType !=3 AND trialPP.productID = 1
LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
	AND pp.paymentStartDateTime BETWEEN hce.insertDateTime and hce.hist_effectiveThruDateTime
SET
	mk_upload.paymentProfileID=ss.paymentProfileID,
	mk_upload.parentPaymentProfileID=ss.parentPaymentProfileID,
	mk_upload.emailAddress = ss.emailAddress,
	mk_upload.emailDomain = ss.emailDomain,
	mk_upload.ownerID = CASE ss.SSOwner
	WHEN "Ben" 	THEN "00540000001UFlV"
	WHEN "AJ"	THEN "00540000001UcZX"
	WHEN "Jennifer"	THEN "00540000001V65s"
	WHEN "Darren"	THEN "00540000001V66H"
	WHEN "Sarah"   	THEN "00540000002FcZI"	
	WHEN "Sean" 	THEN "00540000002Fm0c"
	WHEN "Joe" 		THEN "00540000002Fqe3"
	WHEN "Jeff"		THEN "00540000002GeyB"
	WHEN "Chris"	THEN "00540000002GeyG"

	WHEN "Chad"		THEN "00540000002HJjd"
	WHEN "Ryaire" 	THEN "00540000002HLLx"
	
	WHEN "Taylor" 	THEN "00540000001UFlf"
	WHEN "Kevin" 	THEN "00540000001UFla"
	
	WHEN "Eric" 	THEN "00540000001UiO2"
	WHEN "Max" 		THEN "00540000001TpXD"
	WHEN "Tyler" 	THEN "00540000001UFty"
	WHEN "Taryn" 	THEN "00540000001U30S"
	WHEN "Tim" 		THEN "00540000001U30X"
	WHEN "Gene" 	THEN "00540000001UFlQ"
	WHEN "Kara" 	THEN "00540000002HFLr"
	WHEN "Jacob" 	THEN "00540000002HRlc"
	WHEN "Jason"	THEN "00540000002HyR1"
	WHEN "ChrisK" 	THEN "00540000002HJwX"
	ELSE "Error" END,
	mk_upload.status = 	CASE WHEN arc_hubspotExcludeList.domain IS NULL THEN "Pending" ELSE "new" END, 
	mk_upload.website = ss.emailDomain,
	mk_upload.leadSource = CASE WHEN ss.leadType = "Enterprise (Named)" THEN 'Smartscored (Named)' 
		WHEN ss.leadType = "Enterprise (Other)" THEN 'Smartscored (Enterprise)' 
		WHEN ss.leadType = "Prosumer" THEN 'Smartscored' ELSE 'Other' END,
	mk_upload.newsFlags = ss.newsFlags,
	mk_upload.statusFlags = ss.statusFlags,
	mk_upload.locale = ss.locale,
	mk_upload.timeZone = ss.timeZone,
	mk_upload.productName = SMARTSHEET_PRODUCTNAME(pp.productID),
	mk_upload.userLimit = pp.userLimit,
	mk_upload.paymentStartDateTime = pp.paymentStartDateTime,
	mk_upload.nextPaymentDate = pp.nextPaymentDate,
	mk_upload.paymentTerm = pp.paymentTerm,
	mk_upload.planRate = pp.planRate,
	mk_upload.monthlyPlanRate_USD = CASE WHEN pp.currencyCode = 'USD' THEN pp.planRate/pp.paymentTerm ELSE (pp.planRate/hce.exchangeRate)/pp.paymentTerm END,
	mk_upload.currencyCode = pp.currencyCode,

	mk_upload.teamTrial = CASE WHEN trialPP.accountType = 2 THEN 1 ELSE 0 END,
	mk_upload.trialStartDate = tt.trialDateTime,
	mk_upload.trialEndDate = tt.trialEndDateTime,
	mk_upload.isTrialRestart = CASE WHEN tt.firstTrial = 1 THEN 0 ELSE 1 END,

	mk_upload.primaryContactPhone = pp.primaryContactPhone,
	mk_upload.billToAddress1 = pp.billToAddress1,
	mk_upload.billToAddress2 = pp.billToAddress2,
	mk_upload.billToCity = pp.billToCity,
	mk_upload.billToRegionCode = pp.billToRegionCode,
	mk_upload.billToPostCode = pp.billToPostCode,
	mk_upload.billToCountryCode = pp.billToCountryCode,
	mk_upload.ABTests = ss.ABTests,
	mk_upload.pushToMarketo = 1
WHERE mk_upload.userID IS NOT NULL
;




-- Begin section for fields that could be updated 



-- When a change is made to the user account record
UPDATE arc_marketo_upload mk_upload
JOIN ss_core_02.userAccount ua ON mk_upload.userID=ua.userID
SET 
	mk_upload.emailAddress = ua.emailAddress,
	mk_upload.firstName = ua.firstName,
	mk_upload.lastName = ua.lastName,
	mk_upload.newsFlags = ua.newsFlags,
	mk_upload.statusFlags = ua.statusFlags,
	mk_upload.locale = ua.locale,
	mk_upload.timeZone = ua.timeZone
WHERE ua.modifyDateTime >= @maxUserAccountModifyDateTime
;


-- When a change is made to the paymentProfile record
UPDATE arc_marketo_upload mk_upload
JOIN ss_core_02.paymentProfile pp ON mk_upload.paymentProfileID=pp.paymentProfileID
LEFT OUTER JOIN ss_core_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
	AND pp.paymentStartDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
SET
	mk_upload.productName = SMARTSHEET_PRODUCTNAME(pp.productID),
	mk_upload.userLimit = pp.userLimit,
	mk_upload.paymentStartDateTime = pp.paymentStartDateTime,
	mk_upload.nextPaymentDate = pp.nextPaymentDate,
	mk_upload.paymentTerm = pp.paymentTerm,
	mk_upload.planRate = pp.planRate,
	mk_upload.currencyCode = pp.currencyCode,
	mk_upload.monthlyPlanRate_USD = CASE WHEN pp.currencyCode = 'USD' THEN pp.planRate/pp.paymentTerm ELSE (pp.planRate/hce.exchangeRate)/pp.paymentTerm END,
	mk_upload.parentPaymentProfileID = pp.parentPaymentProfileID,
	mk_upload.primaryContactPhone =	pp.primaryContactPhone,
	mk_upload.billToAddress1 = pp.billToAddress1,
	mk_upload.billToAddress2 = pp.billToAddress2,
	mk_upload.billToCity = 	pp.billToCity,
	mk_upload.billToRegionCode = pp.billToRegionCode,
	mk_upload.billToPostCode = pp.billToPostCode,
	mk_upload.billToCountryCode = pp.billToCountryCode
WHERE pp.modifyDateTime >= @maxPPModifyDateTime
;

-- Update highest domain product
UPDATE rpt_main_02.arc_marketo_upload mk_upload
LEFT OUTER JOIN rpt_paidDomains ON mk_upload.emailDomain = rpt_paidDomains.mainContactDomain
SET mk_upload.domainsHighestPlan = rpt_paidDomains.MaxProduct
;

-- Changes to existing trials
DROP TABLE IF EXISTS rpt_main_02.tmp_mod_trials;
CREATE TABLE rpt_main_02.tmp_mod_trials
(
	paymentProfileID BIGINT,
	accountType INT,
	userID BIGINT,
	trialDateTime DATETIME,
	trialEndDateTime DATETIME,
	firstTrial INT,
	trialSessionID BIGINT,
	KEY ix_ppid (paymentProfileID),
	KEY ix_userID (userID),
	KEY ix_sessionID (trialSessionID)
)
;


INSERT INTO rpt_main_02.tmp_mod_trials
SELECT  
	hpp.paymentProfileID,
	hpp.accountType,
	hpp.ownerID AS userID,
	hpp.modifyDateTime,
	MIN(hppNext.modifyDateTime) AS trialEndDateTime,
	CASE WHEN hppOld.productID IS NULL THEN 1 ELSE 0 END AS firstTrial /* First time is a trial in which the user did not previously have a payment Profile*/,
	hpp.sessionLogID

FROM ss_core_02.hist_paymentProfile hpp
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppOld ON hpp.paymentProfileID = hppOld.paymentProfileID 
	AND hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND    /*Compare to previous hist_paymentProfile entry */
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppNext ON hppNext.paymentProfileID = hpp.paymentProfileID 
	AND hppNext.modifyDateTime > hpp.modifyDateTime AND hppNext.productID != 1 /*Compare to next non-trial hist_paymentProfile entry */
JOIN rpt_main_02.tmp_marketo_leads tmp ON tmp.userID=hpp.ownerID and hpp.accountType != 3
WHERE hpp.productID = 1
AND (hppOld.productID != 1 OR hppOld.productID IS NULL) /*Eliminates instance of trials being extended, previous hist_paymentProfile was also a trial  */
AND hpp.modifyDateTime > @maxPPModifyDateTime  
GROUP BY 1,4
;


UPDATE rpt_main_02.arc_marketo_upload mk_upload
JOIN rpt_main_02.tmp_mod_trials tmt ON mk_upload.paymentProfileID = tmt.paymentProfileID
SET 

	mk_upload.trialEndDate = tmt.trialEndDateTime,
	mk_upload.teamTrial = CASE WHEN tmt.accountType = 2 THEN 1 ELSE 0 END
;



/*One off changes to the table*/
UPDATE arc_marketo_upload
SET Status = "Pending" 
WHERE emailDomain IN ("google.com", "cisco.com")
AND uploadDateTime IS NULL /*Any time you're making changes like this, be sure to add this qualifier so leads that have already been entered are not effected*/
;