
-- toddj 2014-05-07
This file is obsolete now and has been replaced by a new one in a new location:
git@scm.smartsheet.com:insight-marketo-importer









#!/usr/bin/env ruby
require 'rubygems'
require 'active_record'
# forked gem markety
# forked from https://github.com/preact/markety
# fork URL https://github.com/smartsheet-platform/markety
require 'markety'
require 'benchmark'

#
# TODO
# - add status and datetime columns to insight
# - map additional fields / columns
# - add userID attribute to use as unique foreign key instead of email
#

#
# mysql config
#

ActiveRecord::Base.establish_connection(
  :adapter => 'mysql2',
  :host    => 'localhost',
  :username=> 'sasha',
  :database=> 'sasha'
)

class User < ActiveRecord::Base
  # point at the actual table
  self.table_name = "arc_marketo_upload"
end

#
# marketo config
#

marketo_userid = 'smartsheetsandbox1_86803602532B5EBB3A4CF4'
marketo_enckey = '8367686035219866553322BB55EEBBCD33AA56507106'
marketo_endpoint = 'https://383-VLX-233.mktoapi.com/soap/mktows/2_3'

# toggle verbose HTTP logging to stdout
log = false
# timeout for HTTP connections, in seconds
open_timeout = 300
read_timeout = 300 
# initialize Marketo connection
mclient = Markety.new_client(marketo_userid, marketo_enckey, marketo_endpoint, '2_3', log, open_timeout, read_timeout)

#
# main
#

elapsed = Benchmark.realtime {
  puts
  puts "Begin Smartsheet > Marketo data sync, #{Time.new}"
  puts

  # select all from insight_db:arc_marketo_upload where pushToMarketo == 1
  leads_to_upsert = User.where(pushToMarketo: 1)

  # use markety::syncMultipleLeads to upsert (insert and/or update) multiple leads
  # http://developers.marketo.com/documentation/soap/syncmultipleleads/
  # heuristics: first check against Smartsheet user ID, fall back on email address
  # confirmed: Marketo uses ForeignSysPersonID (unique) first, then email (not unique)
  puts "Total Insight leads to upsert: #{leads_to_upsert.length}"

  # execute only if there are any records to upsert
  if leads_to_upsert.length > 0
    puts "Creating upsert request..."
    lead_records = []
    leads_to_upsert.each_with_index {|lead, index|
      puts "  creating for lead #{index+1}: #{lead.userID}, #{lead.emailAddress}"
      lead_record = Markety::LeadRecord.new(lead.emailAddress,nil,lead.userID,"CUSTOM")
      lead_record.set_attribute('FirstName', lead.firstName)
      lead_record.set_attribute('LastName', lead.lastName)
      lead_record.set_attribute('Email', lead.emailAddress)
      # set any additional attributes
      lead_records << lead_record
    }

    puts "Upserting..."
    response = mclient.sync_multiple_lead_records(lead_records)
    
    # if a single entry is processed, a Hash is returned
    # we need an Array instead
    sync_status = response[:sync_status].kind_of?(Array) ? response[:sync_status] : [ response[:sync_status] ]
    puts "  Done upserting."

    # create an Array of Hashes, where each Hash is of the form:
    # {"STATUS" => {"MARKETO_ID","MARKETO_ID",...}
    # STATUS is one of CREATED, UPDATED, FAILED
    result = sync_status.inject(Hash.new([])) {|h,e| h[e[:status]] += [e[:lead_id]]; h}

    # print out stats
    # parse response, extract IDs for all updated, created, failed records
    puts "Inspecting results..."
    puts "  Total records processed: #{response[:sync_status].length}"
    result.each {|k,v| 
      puts "  Records #{k}: #{v.length}, Marketo IDs: #{v.join(",")}"
    }
    
    # !!! Marketo API does not return ForeignSystemPersonID at all - via UI or API
    # (see Marketo support forums for more info)
    # completely nuts and requires us to do more work
    # so, instead we have to match against Insight by email address
    # obviously, this doesn't work for leads without email addresses
    # here is how our logic works:
    # - getMultipleLeads by Marketo ID
    # - extract emails
    # - for updated and created
    # - update insight where email in (...) set pushToMarketo = 0
    # - update date/time and status (updated, created, failed)

    puts "Preparing to update Insight..."

    # CREATED
    created_ids = result["CREATED"]
    if !created_ids.empty?
      created_leads = mclient.get_multiple_leads_by_idnum(created_ids)
      created_emails = created_leads.collect{|lead| lead.email}
      # Marketo's getMultipleLeads is limited to batches of 100
      all_created_emails = []
      created_ids.each_slice(100) {|slice|
        created_leads = mclient.get_multiple_leads_by_idnum(slice)
        created_emails = created_leads.collect{|lead| lead.email}
        all_created_emails += created_emails 
      }
      puts "  Updating Insight for #{all_created_emails.length} created entries..."
      User.where("emailAddress" => created_emails).update_all("uploadStatus" => "CREATED", "uploadDateTime" => Time.now, "pushToMarketo" => false)
    end

    # UPDATED
    updated_ids = result["UPDATED"]
    if !updated_ids.empty?
      # Marketo's getMultipleLeads is limited to batches of 100
      all_updated_emails = []
      updated_ids.each_slice(100) {|slice|
        updated_leads = mclient.get_multiple_leads_by_idnum(slice)
        updated_emails = updated_leads.collect{|lead| lead.email}
        all_updated_emails += updated_emails 
      }
      puts "  Updating Insight for #{all_updated_emails.length} updated entries..."
      User.where("emailAddress" => all_updated_emails).update_all("uploadStatus" => "UPDATED", "uploadDateTime" => Time.now, "pushToMarketo" => false)
    end

    # FAILED
    failed_ids = result["FAILED"]
    if !failed_ids.empty?
      # Marketo's getMultipleLeads is limited to batches of 100
      all_failed_emails = []
      failed_ids.each_slice(100) {|slice|
        failed_leads = mclient.get_multiple_leads_by_idnum(slice)
        failed_emails = failed_leads.collect{|lead| lead.email}
        all_failed_emails += failed_emails 
      }
      puts "  Updating Insight for #{all_failed_emails.length} updated entries..."
      User.where("emailAddress" => all_failed_emails).update_all("uploadStatus" => "FAILED", "uploadDateTime" => Time.now)
    end
  end

  puts "  Done updating Insight."

  puts 
  puts "Completed Smartsheet > Marketo data sync, #{Time.new}"
}
puts "Total execution time: #{elapsed} seconds."
puts
