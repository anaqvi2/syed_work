
drop table arc_marketo_upload;
CREATE TABLE arc_marketo_upload (
   # BEGIN SFDC COLUMNS
   # These were copied over from table arc_sfdc_upload as we're now piping data through marketo first
   userID  bigint (20) not null primary key #Uniquely identifies Smartsheet user
  ,company varchar(100)
  ,ownerID varchar(25) 
  ,status varchar(25)
  ,paymentProfileID bigint(20)
  ,parentPaymentProfileID bigint(20)
  ,firstName varchar(40)
  ,lastName varchar(50)
  ,emailAddress varchar (200)
  ,emailDomain varchar (200)
  ,street varchar(100)
  ,city varchar(50)
  ,state varchar(25)
  ,postalCode varchar(25)
  ,country varchar(25)
  ,phone varchar(100)
  ,numberOfEmployees int(11)
  ,annualRevenue decimal(32,10)
  ,title varchar(50)
  ,website varchar(100)
  ,leadSource varchar(25)
  ,existingEnterpriseDomain tinyint(4)
  ,existingPaidDomain tinyint(1)
  ,searchTerm varchar(100)
  ,sourceBucket varchar(50)
  ,sharedTo varchar(20)
  ,containerCount int(11)
  ,firstContainerFromTrialStart decimal(38,10)
  # END SFDC COLUMNS

  # BEGIN NEW COLUMNS as specified for Marketo project
  ,pushToMarketo tinyint (1)  #Flag to indicate which records need to be pushed into Marketo.  ||    ||  Should be set to true whenever a record in the table is updated and reset to false by the piece pushing the data to Marketo after a successful API call.
  ,insertDateTime datetime #Date/time the record was inserted into the upload table  ||    ||  Set to Now() by SQL insert records into table
  ,uploadDateTime datetime #Date/time the record was last uploaded to Marketo  ||    ||  Set to Now() after a successful push to Marketo via their API

  #,website  varchar (300) #Duplicate of the content in domain__c but needed for salesforce because it is a standard field that resolves to a live http link  ||    ||  
  ,isOrgDomain tinyint (1) #  ||    ||  email address matched with list of known ISPs
  #,firstName  varchar (150) #  ||    ||    ,firstName  varchar (150),
  #,lastName  varchar (150) #  ||    ||    ,lastName  varchar (150),
  ,newsFlags int(11) #Pass whole bitmask  ||  Does the data show if Opt out and News flag are synonymous  ||    ,newsFlagsint (11),
  ,statusFlags int (11) #Pass whole bitmask  ||    ||    ,statusFlagsint (11),
  ,localeLanguage  varchar (15) #Don't include raw data - use the language and country split into individual pieces  ||    ||    ,locale  varchar (15),
  ,localeCountry  varchar (15) #Don't include raw data - use the language and country split into individual pieces  ||    ||    ,locale  varchar (15),
  ,timeZone  varchar (150) #  ||    ||    ,timeZone varchar (150),

  #,nickName varchar (150)
  #,loginPassword varchar (300)
  #,accountType tinyint (4)
  #,insertByUserID bigint (20)
  #,modifyByUserID bigint (20)
  #,modifyDateTime datetime
  #,sessionLogID bigint (20)

  ,productName  varchar (100) #  ||    ||  Convert productID to text value
  ,userLimit int (11) #  ||    ||    ,userLimitint (11),
  ,paymentStartDateTime datetime #  ||    ||    ,paymentStartDateTimedatetime ,
  ,nextPaymentDate datetime #  ||    ||    ,nextPaymentDatedatetime ,
  ,paymentTerm tinyint (4) #keep as integer  ||    ||    ,paymentTermtinyint (4),
  ,planRate Decimal (40) #native currency  ||    ||    ,planRateDecimal (40),
  ,monthlyPlanRate_USD Decimal (40) #convert all currencies to USD  ||    ||  paymentProfile.planRate / paymentProfile.paymentTerm
  ,currencyCode varchar (30) #  ||    ||    ,currencyCode varchar (30),
  ,teamTrial tinyint (1) #Leadscoring and Weight for Sales team. Improving lead quality.  ||    ||  0 not team trial, 1 in team trial, 2 owns team trial
  ,trialStartDate datetime #Primary mechanism for triggering trial emails  ||    ||    ,paymentStartDateTimedatetime ,
  ,trialEndDate datetime # We need this as someone's trial may be extended and we don't want to send "trial ending" emails to them.  ||    ||  
  ,isTrialRestart tinyint (1) #0 = first trial, 1 = trial restart  ||    ||  hist_paymentProfile table
  ,primaryContactPhone varchar (60) #  ||    ||    ,primaryContactPhone varchar (60),
  ,billToAddress varchar (300) #combine two address fields into this one  ||    ||  billToAddress1 & billToAddress2
  ,billToCity varchar (150) #  ||    ||    ,billToCity varchar (150),
  ,billToRegionCode varchar (150) #  ||    ||    ,billToRegionCode varchar (150),
  ,billToPostCode varchar (150) #  ||    ||    ,billToPostCode varchar (150),
  ,billToCountryCode varchar (150) #  ||    ||    ,billToCountryCode varchar (150),
  ,marktetoTrackingCookie  varchar (500) #Contains marketo identifier for user  ||    ||  itemValue  varchar (500),
  ,signupTrackingKeyword varchar(500)
  ,signupTracking_s_code varchar(500)
  ,signupTracking_c_code varchar(500)
  ,signupTracking_m_code varchar(500)
  #,Source_Bucket__c varchar (150) #not available instantly, populated nightly  ||    ||  rpt_signupSource table
  ,SourceSource varchar (150) #not available instantly, populated nightly  ||    ||  rpt_signupSource table
  ,SourceSubSource varchar (150) #not available instantly, populated nightly  ||    ||  rpt_signupSource table
  ,salesforceOwnerID varchar (75) #key to identify rep. owner of lead - this field will drive what records get synced to salesforce.Currently all the leads going into SFDC are getting assigned.  With the Marketo integration, the exact same set of leads will be getting assigned.  But since the total set will be larger (it will include ISP trials) some of the leads won't be assigned.  ||    ||  rep. assignment logic"
  ,salesforceStatus varchar (75) #blank status for unassigned leads  ||    ||  rep. assignment logic
  ,smartscoreCode varchar (150) #This logic won't change from existing logic.
  ,salesforceLeadSource varchar (75)
  ,numberOfEmployeesHvrs int (11) #  ||    ||  arc_HooversCompanyData
  ,annualRevenueHvrs Decimal (34) #  ||    ||  arc_HooversCompanyData
  ,titleHvrs varchar (150) #  ||    ||  not currently populated
  ,companyHvrs varchar (300) #Don't update with organization name.  Organization name will be separate field.  ||    ||  arc_HooversCompanyData or if not found then domain name
  ,ipCountry  varchar (200) #  ||    ||  rpt_signupSource table
  ,organizationName  varchar(100) #  ||    ||  organization.name  varchar(100)
  ,isGoogleAppsInstalledDomain tinyint (1) #The move to GoogleOAuth2 may have hampered our ability here.  Still gathering information.  ||    ||  +openIDIdentifier / GoogleAppsDomain table
  ,wasSharedToPriorToTrial tinyint (1) #in Salesforce upload table this is   ,Shared_To__c varchar (60), but it just contains boolean data  ||    ||  +gridAccessMap
  ,domainsHighestPlan varchar (60) #This field is more complex because it would need to be updated when someone elses payment profile changes.  ||  Can we insert at trial and populate nightly?  ||  rpt_paymentProfile, rpt_paidDomains
  ,historyHighestPlan varchar (60) #  ||  Can we insert at trial and populate nightly?  ||  
  ,sheetCount int  #  ||  Owned or Accessible?  ||  container
  ,lastLogin dateTime  #  ||    ||  rpt_loginCountTotal
  ,lastMobileLogin dateTime  #Mobile application only  ||    ||  sessionLog
  ,isEverWellQualified tinyint(1)  #is ever well qualified  ||    ||  
  ,isStrongLead tinyint(1)  #  ||    ||  
  ,eventLogCount int  #Leadscoring and Weight for Sales team. Improving lead quality.  ||    ||  rpt_clientLogCountsByUserArchived.lifetimeLogCount
  ,loginCount int  #  ||    ||  rpt_loginCountTotal.loginCount
  ,sharingCount int  #In Trial Drip  ||    ||  rpt_featureCountRollupByUser
  ,reportCount int  #In Trial Drip  ||    ||  stg_containerCountsByUser_data


  ,KEY idx_emailAddress (emailAddress)
  ,KEY idx_emailDomain (emailDomain)
  ,KEY idx_paymentProfileId (paymentProfileId)
) DEFAULT CHARSET=utf8
;



