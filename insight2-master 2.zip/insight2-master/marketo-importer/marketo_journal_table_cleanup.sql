SELECT DATABASE();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

# SELECT COUNT(1)
# FROM leadflow.arc_marketo_upload_journal_OLD
# WHERE journalDateTime >= '2016-11-01';

SELECT
    "************** journal cleanup rows: ",
    ROW_COUNT(),
    NOW();

INSERT INTO leadflow.arc_marketo_upload_journal_20161219
    SELECT *
    FROM leadflow.arc_marketo_upload_journal_OLD
    WHERE journalDateTime >= '2016-11-01';

SELECT
    "************** journal cleanup rows: ",
    ROW_COUNT(),
    NOW();
