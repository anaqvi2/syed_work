"Function","sql_mode","Create Function","character_set_client","collation_connection","Database Collation"
"getAppBehaviorScoreV1","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getAppBehaviorScoreV1`(loginCount INT, eventLogCount INT, sheetCount INT, sharingCount INT,  reportCount INT,
				isTeamTrial INT, accountRole varchar(100)) RETURNS int(11)
    DETERMINISTIC
BEGIN
DECLARE getBehaviorScore INT;
SET getBehaviorScore = 
	COALESCE(loginCount, 0) + 										
	COALESCE(eventLogCount / 100, 0)  +								
	(COALESCE(sheetCount, 0) * 5) +  								
	(COALESCE(sharingCount, 0) * 5)	+								
	(LEAST(COALESCE(sharingCount, 0), 1) * 15) +					
	(COALESCE(reportCount, 0) * 5)	+								
	(LEAST(COALESCE(reportCount, 0), 1) * 15);						


	
IF isTeamTrial = 1 
	THEN SET getBehaviorScore = getBehaviorScore + 10;  
end if;  
IF isTeamTrial = 1 AND accountRole = ""Owner""  
	THEN SET getBehaviorScore = getBehaviorScore + 10;
END IF;
RETURN getBehaviorScore;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"getFitScoreV1","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getFitScoreV1`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code INT, wasShared INT) RETURNS tinyint(3)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;
SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X2 = CONCAT(X2a, ""_"", X2b);

SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X4 = wasShared;
IF dm = '0' THEN SET aP = '.001';

ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';

ELSEIF dm = '1'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'Intercept'),
	beta1 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'locale' AND  c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'sc_code' AND c.Variable = X2), 
	beta3 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'wasSharedToPriorToTrial'), 
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4))+1);
	
	SET aP = (CASE WHEN P > .1 THEN .1
				   WHEN P <.001 THEN .001
				   WHEN P IS NULL THEN .015 
				   ELSE P 
			  END); 
END IF;
SET fP = ROUND(aP*1000);
RETURN fP;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"getFitScoreV2","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getFitScoreV2`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50),
                                            m_code      VARCHAR(50), wasShared INT, inserteduser TINYINT,
                                            itemValue   VARCHAR(25)) RETURNS tinyint(3)
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE beta5 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;
DECLARE X5 INT;
DECLARE X6 INT;
SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 				WHEN s_code = '' 	THEN 'Blank' 
 				ELSE s_code 
 			END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
				WHEN c_code = '' 	THEN 'Blank' 
				ELSE c_code 
			END);
SET X2 = CONCAT(X2a, ""_"", X2b);

SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   				WHEN m_code = '' 	THEN 'Blank' 
   				ELSE m_code 
   			END);
SET X4 = wasShared;
SET X5 = inserteduser;
SET X6 = itemValue;
IF (dm = 0 OR (X6 IN ('2','6','10','11') AND (X2a = 'None' or X2a = 'Blank'))) THEN SET aP = '.001';

ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';

ELSEIF dm = '1'
THEN SET 
	betaZero = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'Intercept'), 0),
	beta1 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'locale' AND  c.Variable = X1), 0),
	beta2 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'sc_code' AND c.Variable = X2), 0),
	beta3 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'm_code' AND  c.Variable = X3), 0),
	beta4 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'wasSharedToPriorToTrial'), 0),
	beta5 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'insertedByUser'), 0),
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))+1);
	 
	SET aP = (CASE WHEN P > .1 THEN .1
				  WHEN P <.001 THEN .001
				  WHEN P IS NULL THEN .015 
				  ELSE P 
			 END);
END IF;
SET fP = ROUND(aP*1000);
RETURN fP;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_ACCOUNT_ROLE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_ACCOUNT_ROLE`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE accountRole VARCHAR(50);
SET accountRole = 
	CASE 
		WHEN  parentPaymentProfileID IS NULL THEN ""Individual""  
		WHEN orgMainContactUserID = userID THEN ""Owner""  
		ELSE ""Member""								
	END;
RETURN accountRole;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_BILLING_ADDRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_BILLING_ADDRESS`(address1 VARCHAR(50), address2 VARCHAR(50)) RETURNS varchar(101) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE billingAddress VARCHAR(101);
	SET billingAddress = TRIM(CONCAT(COALESCE(address1,"""") ,"" "", COALESCE(address2,"""")));  
RETURN billingAddress;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_CLEAN_IPADDRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_CLEAN_IPADDRESS`(ipAddress VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE cleanIpAddress VARCHAR(50);
	SET cleanIpAddress = 
		CASE WHEN INSTR (ipAddress, "","" ) > 0
			THEN SUBSTRING_INDEX(ipAddress, "","", 1) 
			ELSE ipAddress
		END;
RETURN cleanIpAddress;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_EXTRACT_DOMAIN","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_EXTRACT_DOMAIN`(emailAddress VARCHAR(100)) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE domain VARCHAR(100);
	SET domain = SUBSTR(emailAddress, INSTR(emailAddress,'@') + 1);
RETURN domain;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_IMPORT_MS_PROJECT","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_IMPORT_MS_PROJECT`(userTags VARCHAR(255), clickedImportProjectCount INT) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
        DECLARE projectImport VARCHAR(255);
        DECLARE userTagsClean VARCHAR(255);
        SET userTagsClean = TRIM(TRAILING ';clickedImportMSProject' FROM userTags); # Strip existing clicked tag
        SET projectImport =
        CONCAT_WS(
            ';',
            userTagsClean,
            CASE WHEN COALESCE(clickedImportProjectCount, 0) > 0
                THEN 'clickedImportMSProject' END
        );
        RETURN CASE WHEN projectImport = ''
            THEN NULL
               ELSE projectImport END;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_IMPORT_MS_PROJECT_TEST","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_IMPORT_MS_PROJECT_TEST`(userTags VARCHAR(255), clickedImportProjectCount INT) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
        DECLARE projectImport VARCHAR(255);
        DECLARE userTagsClean VARCHAR(255);
        SET userTagsClean = TRIM(TRAILING ';clickedImportMSProject' FROM userTags);
        SET projectImport =
        CONCAT_WS(
            ';',
            userTagsClean,
            CASE WHEN COALESCE(clickedImportProjectCount, 0) > 0
                THEN 'clickedImportMSProject' END
        );
        RETURN CASE WHEN projectImport = ''
            THEN NULL
               ELSE projectImport END;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_LAST_NAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LAST_NAME`(lastName VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE processedLastName VARCHAR(50);
SET processedLastName = 
	CASE WHEN lastName IS NULL 	THEN NULL 
		WHEN lastName = """" 		THEN NULL 
		WHEN lastName = "" "" 	THEN NULL 
		ELSE lastName
  END;
RETURN processedLastName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_LICENSE_TAG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LICENSE_TAG`(assignedLicenseCount INT, pendingLicenseCount INT, paidLicenseLimit INT, previousPaidLicenseLimit INT, licenseUserCount INT) RETURNS varchar(256) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE licenseTags VARCHAR(256);
SET licenseTags = 
    CONCAT_WS(
        ';',
        CASE WHEN assignedLicenseCount + pendingLicenseCount >= paidLicenseLimit THEN 'assigned100Percent' END,
        CASE WHEN licenseUserCount >= 3 THEN 'assigned3OrMoreLast7Days' END,
        CASE WHEN paidLicenseLimit - previousPaidLicenseLimit < 0 THEN 'licenseLimitTrendingDown' END
    )
;
RETURN CASE WHEN licenseTags = '' THEN NULL ELSE licenseTags END;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_LICENSE_TAG_TEST","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LICENSE_TAG_TEST`(assignedLicenseCount int, pendingLicenseCount int, paidLicenseLimit int, previousPaidLicenseLimit int, licenseUserCount int) RETURNS varchar(256) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE licenseTags VARCHAR(256);
SET licenseTags = 
    CONCAT_WS(
        ';',
        CASE WHEN assignedLicenseCount + pendingLicenseCount >= paidLicenseLimit THEN 'assigned100Percent' END,
        CASE WHEN licenseUserCount >= 3 THEN 'assigned3OrMoreLast7Days' END,
        case when paidLicenseLimit - previousPaidLicenseLimit < 0 then 'licenseLimitTrendingDown' end
    )
;
RETURN case when licenseTags = '' then null else licenseTags end;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_RECURRING_BILLING_CANCELLED","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_RECURRING_BILLING_CANCELLED`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT, usersPaymentFlags tinyint, parentPaymentFlags tinyint) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
DECLARE isBillingCancelled TINYINT(1);
DECLARE paymentFlags TINYINT(1);
SET paymentFlags = 
	CASE 
		WHEN  parentPaymentProfileID IS NULL THEN usersPaymentFlags  	
		WHEN orgMainContactUserID = userID THEN parentPaymentFlags  	
		ELSE usersPaymentFlags								
	END;
	
set isBillingCancelled = 
	case 
		when paymentFlags & 16 = 16 then 1
		else 0
	end;
		
RETURN isBillingCancelled;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_SHARE_PERMISSION","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_SHARE_PERMISSION`(sharePermission INT) RETURNS varchar(25) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE sharePermissionName VARCHAR(25);
SET sharePermissionName = 
  CASE WHEN sharePermission IS NULL THEN ""None""
    WHEN sharePermission = 0 THEN ""None""
    WHEN sharePermission = 10 THEN ""View""
    WHEN sharePermission = 20 THEN ""Editor""
    WHEN sharePermission = 30 THEN ""EditorCanShare""
    WHEN sharePermission = 40 THEN ""Admin""
    WHEN sharePermission = 50 THEN ""Owner""
    ELSE CONCAT('Permission ', sharePermission)
  END;
return sharePermissionName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_SHARE_PERMISSION_TEST","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_SHARE_PERMISSION_TEST`(sharePermission INT) RETURNS varchar(25) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE sharePermissionName VARCHAR(25);
SET sharePermissionName = 
  CASE WHEN sharePermission IS NULL THEN ""None""
    WHEN sharePermission = 0 THEN ""None""
    WHEN sharePermission = 10 THEN ""View""
    WHEN sharePermission = 20 THEN ""Editor""
    WHEN sharePermission = 30 THEN ""EditorCanShare""
    WHEN sharePermission = 40 THEN ""Admin""
    WHEN sharePermission = 50 THEN ""Owner""
    ELSE CONCAT('Permission ', sharePermission)
  END;
return sharePermissionName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_UPGRADE_WIZARD_PROGRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_UPGRADE_WIZARD_PROGRESS`(ViewedConfirmPage TINYINT, PayPalComplete TINYINT, PayPalStart TINYINT, ViewedStep3 TINYINT, ViewedStep2 TINYINT, ViewedStep1 TINYINT) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE friendlyProgressValue VARCHAR(100);
SET friendlyProgressValue = 
	CASE 
		WHEN ViewedConfirmPage > 0 THEN ""Complete""
		WHEN PayPalComplete > 0 THEN ""PayPalComplete""
		WHEN PayPalStart > 0 THEN ""PayPalStart""
		WHEN ViewedStep3 > 0 THEN ""Step3""
		WHEN ViewedStep2 > 0 THEN ""Step2""
		WHEN ViewedStep1 > 0 THEN ""Step1""
		ELSE """" 
	END;
RETURN friendlyProgressValue;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_USER_TAG","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_USER_TAG`(isInsertedByOrgDomain TINYINT, insertedEmailDomain VARCHAR(100),
                                                            insertedByEmailDomain VARCHAR(100), signupContactMe VARCHAR(100),
                                                            signupEmail           VARCHAR(100)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
        DECLARE userTags VARCHAR(255);
        SET userTags =
        CONCAT_WS(
            ';',
            CASE
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain != insertedByEmailDomain
                THEN CONCAT('insertedByOutDomain', ':@', insertedByEmailDomain)
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain = insertedByEmailDomain
                THEN 'insertedByInDomain'
            WHEN isInsertedByOrgDomain = 0
                THEN 'insertedByISPDomain'
            WHEN isInsertedByOrgDomain = -1
                THEN 'insertedBySelf'
            END,
            CASE
            WHEN signupContactMe = 'on'
                THEN 'contactMe:1'
            WHEN signupEmail IS NOT NULL
                THEN 'contactMe:0'
            END
        );
        RETURN CASE WHEN userTags = ''
            THEN NULL
               ELSE userTags END;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_USER_TAG_TEST","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_USER_TAG_TEST`(isInsertedByOrgDomain   TINYINT,
                                                                 insertedEmailDomain     VARCHAR(100),
                                                                 insertedByEmailDomain   VARCHAR(100),
                                                                 signupContactMe         VARCHAR(100),
                                                                 signupEmail             VARCHAR(100),
                                                                 clickImportProjectCount INT) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
        DECLARE userTags VARCHAR(255);
        SET userTags =
        CONCAT_WS(
            ';',
            CASE
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain != insertedByEmailDomain
                THEN CONCAT('insertedByOutDomain', ':@', insertedByEmailDomain)
            WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain = insertedByEmailDomain
                THEN 'insertedByInDomain'
            WHEN isInsertedByOrgDomain = 0
                THEN 'insertedByISPDomain'
            WHEN isInsertedByOrgDomain = -1
                THEN 'insertedBySelf'
            END,
            CASE
            WHEN signupContactMe = 'on'
                THEN 'contactMe:1'
            WHEN signupEmail IS NOT NULL
                THEN 'contactMe:0'
            END,
            CASE
            WHEN COALESCE(clickImportProjectCount, 0) > 0
                THEN CONCAT('clickedImportProject:', clickImportProjectCount)
            END
        );
        RETURN CASE WHEN userTags = ''
            THEN NULL
               ELSE userTags END;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_ACCOUNTTYPE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_ACCOUNTTYPE`(accountType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE accountTypeName VARCHAR(50);
SET accountTypeName = 
  CASE accountType
     WHEN 1 THEN ""Standard""
     WHEN 2 THEN ""Multi-user""
     WHEN 3 THEN ""Organization""
     ELSE CONCAT('Account Type ', accountType)
  END;
return accountTypeName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_AUTHRESULT","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_AUTHRESULT`(AuthType SMALLINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE AuthResultName VARCHAR(50);
SET AuthResultName = 
	CASE AuthType
		WHEN 1 THEN ""SUCCESS""
		WHEN 0 THEN ""No error""
		WHEN -1 THEN ""INVALID_USER_OR_PASSWORD""
		WHEN -2 THEN ""LOGIN_TICKET_DOES_NOT_EXIST""
		WHEN -3 THEN ""DUPLICATE_LOGIN_TICKETS""
		WHEN -4 THEN ""LOGIN_TICKET_CORRUPT""
		WHEN -5 THEN ""LOGIN_TICKET_NOT_VALID""
		WHEN -6 THEN ""ACCOUNT_LOCKEDOUT""
		WHEN -7 THEN ""REUSED_REQUEST_DIGEST""
		WHEN -8 THEN ""INVALID_REQUEST_DIGEST""
		WHEN -9 THEN ""NO_MATCHING_USER""
		WHEN -10 THEN ""INVALID_EMAIL_FORMAT""
		WHEN -11 THEN ""USER_NOT_CONFIRMED""
		WHEN -12 THEN ""ACCOUNT_BLOCKED""
		WHEN -13 THEN ""INVALID_UPDATE_TICKET""
		WHEN -14 THEN ""ACCOUNT_LOCKEDOUT_MAX""
		WHEN -15 THEN ""BLOCKED_IP_ADDRESS""
		WHEN -16 THEN ""SAML_REQUIRED_FOR_AUTH""
		WHEN -17 THEN ""ACCESS_TOKEN_REQUIRED""
		WHEN -18 THEN ""ACCESS_TOKEN_EXPIRED""
		WHEN -19 THEN ""Rest User Credentials""
		WHEN -20 THEN ""INVALID_ASSUME_USER""
		WHEN -21 THEN ""ASSUME_USER_REQUIRED""
		WHEN -22 THEN ""LEGACY_PASSWORD_FORMAT""
		ELSE CONCAT ('AuthResult ', AuthType)
	END;
return AuthResultName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSERDEVICE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSERDEVICE`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE browserDevice VARCHAR(50);
  SET browserDevice = 
	CASE  
		WHEN INSTR(userAgent,'myTouch') 	THEN ""myTouch""
		WHEN INSTR(userAgent,'Nexus') 		THEN ""Nexus""
		WHEN INSTR(userAgent,'LG') 			THEN ""LG""
		WHEN INSTR(userAgent,'SGH') 		THEN ""SAMSUNG-SGH""
		WHEN INSTR(userAgent,'APA9292KT') 	THEN ""HTC-EVO (APA9292KT)""
		WHEN INSTR(userAgent,'ADR6300') 	THEN ""HTC-Incredible (ADR6300)""
		WHEN INSTR(userAgent,'HTC') 		THEN ""HTC""
		WHEN INSTR(userAgent,'Treo') 		THEN ""Treo""
		WHEN INSTR(userAgent,'Droid2') 		THEN ""Droid2""
		WHEN INSTR(userAgent,'DroidX') 		THEN ""DroidX""
		WHEN INSTR(userAgent,' Droid') 		THEN ""Droid""
		WHEN INSTR(userAgent,'Xoom') 		THEN ""Xoom""
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Nokia') 		THEN ""Nokia""
		WHEN INSTR(userAgent,'PlayBook') 	THEN ""Playbook""
		WHEN INSTR(userAgent,'iPod') 		THEN ""iPod""			
		WHEN INSTR(userAgent,'iPhone') 		THEN ""iPhone""
		WHEN INSTR(userAgent,'iPad') 		THEN ""iPad""
		WHEN INSTR(userAgent,'Mobile') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Mini') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Fennec') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Android') 	THEN ""Mobile Device""
		WHEN INSTR(userAgent,'pixi') 		THEN ""pixi""
		ELSE ""Computer""
	END;
return browserDevice;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSERNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSERNAME`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE browserName VARCHAR(50);
  SET browserName = 
	CASE
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0.1%') THEN ""iOS App 1.0.1"" 
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0%') THEN ""iOS App 1.0""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.1%') THEN ""iOS App 1.1""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.2%') THEN ""iOS App 1.2""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.3%') THEN ""iOS App 1.3""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.4%') THEN ""iOS App 1.4""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet%') THEN ""iOS App v?""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.0%') THEN ""Android App 1.0""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.1%') THEN ""Android App 1.1""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.2%') THEN ""Android App 1.2""
		WHEN userAgent LIKE ('%Android%Smartsheet%') THEN ""Android App v?""			
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Firefox/10') 	THEN ""Firefox 10""
		WHEN INSTR(userAgent,'Firefox/11') 	THEN ""Firefox 11""
		WHEN INSTR(userAgent,'Firefox/12') 	THEN ""Firefox 12""
		WHEN INSTR(userAgent,'Firefox/13') 	THEN ""Firefox 13""
		WHEN INSTR(userAgent,'Firefox/14') 	THEN ""Firefox 14""
		WHEN INSTR(userAgent,'Firefox/15') 	THEN ""Firefox 15""
		WHEN INSTR(userAgent,'Firefox/16') 	THEN ""Firefox 16""
		WHEN INSTR(userAgent,'Firefox/17') 	THEN ""Firefox 17""
		WHEN INSTR(userAgent,'Firefox/18') 	THEN ""Firefox 18""
		WHEN INSTR(userAgent,'Firefox/19') 	THEN ""Firefox 19""
		WHEN INSTR(userAgent,'Firefox/20') 	THEN ""Firefox 20""
		WHEN INSTR(userAgent,'Firefox/21') 	THEN ""Firefox 21""
		WHEN INSTR(userAgent,'Firefox/22') 	THEN ""Firefox 22""
		WHEN INSTR(userAgent,'Firefox/23') 	THEN ""Firefox 23""
		WHEN INSTR(userAgent,'Firefox/24') 	THEN ""Firefox 24""
		WHEN INSTR(userAgent,'Firefox/25') 	THEN ""Firefox 25""
		WHEN INSTR(userAgent,'Firefox/26') 	THEN ""Firefox 26""
		WHEN INSTR(userAgent,'Firefox/27') 	THEN ""Firefox 27""
		WHEN INSTR(userAgent,'Firefox/28') 	THEN ""Firefox 28""
		WHEN INSTR(userAgent,'Firefox/29') 	THEN ""Firefox 29""
		WHEN INSTR(userAgent,'Firefox/30') 	THEN ""Firefox 30""
		WHEN INSTR(userAgent,'Firefox/31') 	THEN ""Firefox 31""
		WHEN INSTR(userAgent,'Firefox/32') 	THEN ""Firefox 32""
		WHEN INSTR(userAgent,'Firefox/1') 	THEN ""Firefox 1""
		WHEN INSTR(userAgent,'Firefox/2') 	THEN ""Firefox 2""
		WHEN INSTR(userAgent,'Firefox/3') 	THEN ""Firefox 3""
		WHEN INSTR(userAgent,'Firefox/4') 	THEN ""Firefox 4""
		WHEN INSTR(userAgent,'Firefox/5') 	THEN ""Firefox 5""
		WHEN INSTR(userAgent,'Firefox/6') 	THEN ""Firefox 6""
		WHEN INSTR(userAgent,'Firefox/7') 	THEN ""Firefox 7""
		WHEN INSTR(userAgent,'Firefox/8') 	THEN ""Firefox 8""
		WHEN INSTR(userAgent,'Firefox/9') 	THEN ""Firefox 9""
		WHEN INSTR(userAgent,'Firefox') 	THEN ""Firefox v?""
		WHEN INSTR(userAgent,'MSIE 4.') 	THEN ""IE 4""
		WHEN INSTR(userAgent,'MSIE 5.') 	THEN ""IE 5""
		WHEN INSTR(userAgent,'MSIE 6.') 	THEN ""IE 6""
		WHEN INSTR(userAgent,'MSIE 7.') 	THEN ""IE 7""
		WHEN INSTR(userAgent,'MSIE 8.') 	THEN ""IE 8""
		WHEN INSTR(userAgent,'MSIE 9.') 	THEN ""IE 9""
		WHEN INSTR(userAgent,'MSIE 10.')  THEN ""IE 10""
		WHEN userAgent LIKE '%Trident%rv:11%' THEN ""IE 11""
		WHEN userAgent LIKE '%Trident%rv:12%' THEN ""IE 12""
		WHEN userAgent LIKE '%Trident%rv:13%' THEN ""IE 13""
		WHEN userAgent LIKE '%Trident%rv:14%' THEN ""IE 14""
		WHEN userAgent LIKE '%Trident%rv:15%' THEN ""IE 15""
		WHEN INSTR(userAgent,'Chrome/10') 	THEN ""Chrome 10""
		WHEN INSTR(userAgent,'Chrome/11') 	THEN ""Chrome 11""
		WHEN INSTR(userAgent,'Chrome/12') 	THEN ""Chrome 12""
		WHEN INSTR(userAgent,'Chrome/13') 	THEN ""Chrome 13""
		WHEN INSTR(userAgent,'Chrome/14') 	THEN ""Chrome 14""
		WHEN INSTR(userAgent,'Chrome/15') 	THEN ""Chrome 15""
		WHEN INSTR(userAgent,'Chrome/16') 	THEN ""Chrome 16""
		WHEN INSTR(userAgent,'Chrome/17') 	THEN ""Chrome 17""
		WHEN INSTR(userAgent,'Chrome/18') 	THEN ""Chrome 18""
		WHEN INSTR(userAgent,'Chrome/19') 	THEN ""Chrome 19""
		WHEN INSTR(userAgent,'Chrome/20') 	THEN ""Chrome 20""
		WHEN INSTR(userAgent,'Chrome/21') 	THEN ""Chrome 21""
		WHEN INSTR(userAgent,'Chrome/22') 	THEN ""Chrome 22""
		WHEN INSTR(userAgent,'Chrome/23') 	THEN ""Chrome 23""
		WHEN INSTR(userAgent,'Chrome/24') 	THEN ""Chrome 24""
		WHEN INSTR(userAgent,'Chrome/25') 	THEN ""Chrome 25""
		WHEN INSTR(userAgent,'Chrome/26') 	THEN ""Chrome 26""
		WHEN INSTR(userAgent,'Chrome/27') 	THEN ""Chrome 27""
		WHEN INSTR(userAgent,'Chrome/28') 	THEN ""Chrome 28""
		WHEN INSTR(userAgent,'Chrome/29') 	THEN ""Chrome 29""
		WHEN INSTR(userAgent,'Chrome/30') 	THEN ""Chrome 30""
		WHEN INSTR(userAgent,'Chrome/31') 	THEN ""Chrome 31""
		WHEN INSTR(userAgent,'Chrome/32') 	THEN ""Chrome 32""
		WHEN INSTR(userAgent,'Chrome/33') 	THEN ""Chrome 33""
		WHEN INSTR(userAgent,'Chrome/34') 	THEN ""Chrome 34""
		WHEN INSTR(userAgent,'Chrome/35') 	THEN ""Chrome 35""
		WHEN INSTR(userAgent,'Chrome/36') 	THEN ""Chrome 36""
		WHEN INSTR(userAgent,'Chrome/37') 	THEN ""Chrome 37""
		WHEN INSTR(userAgent,'Chrome/38') 	THEN ""Chrome 38""
		WHEN INSTR(userAgent,'Chrome/39') 	THEN ""Chrome 39""
		WHEN INSTR(userAgent,'Chrome/1') 	THEN ""Chrome 1""  
		WHEN INSTR(userAgent,'Chrome/2') 	THEN ""Chrome 2""
		WHEN INSTR(userAgent,'Chrome/3') 	THEN ""Chrome 3""
		WHEN INSTR(userAgent,'Chrome/4') 	THEN ""Chrome 4""
		WHEN INSTR(userAgent,'Chrome/5') 	THEN ""Chrome 5""
		WHEN INSTR(userAgent,'Chrome/6') 	THEN ""Chrome 6""
		WHEN INSTR(userAgent,'Chrome/7') 	THEN ""Chrome 7""
		WHEN INSTR(userAgent,'Chrome/8') 	THEN ""Chrome 8""
		WHEN INSTR(userAgent,'Chrome/9') 	THEN ""Chrome 9""
		WHEN INSTR(userAgent,'Chrome') 	THEN ""Chrome v?""
		WHEN userAgent LIKE ('%3._ Mobile%Safari%') THEN ""Mobile Safari 3"" 
		WHEN userAgent LIKE ('%3._._ Mobile%Safari%') THEN ""Mobile Safari 3"" 
		WHEN userAgent LIKE ('%4._ Mobile%Safari%')  THEN ""Mobile Safari 4"" 
		WHEN userAgent LIKE ('%4._._ Mobile%Safari%') THEN ""Mobile Safari 4"" 
		WHEN userAgent LIKE ('%5._ Mobile%Safari%') THEN ""Mobile Safari 5"" 
		WHEN userAgent LIKE ('%5._._ Mobile%Safari%') THEN ""Mobile Safari 5"" 
		WHEN userAgent LIKE ('%6._ Mobile%Safari%') THEN ""Mobile Safari 6"" 
		WHEN userAgent LIKE ('%6.___ Mobile%Safari%') THEN ""Mobile Safari 6"" 
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 7"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 7"" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 8"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 8"" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 9"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 9"" 	
		WHEN userAgent LIKE ('%Mobile%Safari%') THEN ""Mobile Safari v?"" 
		WHEN userAgent LIKE ('%3._ Safari%') 	THEN ""Safari 3"" 
		WHEN userAgent LIKE ('%3._._ Safari%') 	THEN ""Safari 3"" 
		WHEN userAgent LIKE ('%4._ Safari%') 	THEN ""Safari 4"" 
		WHEN userAgent LIKE ('%4._._ Safari%') 	THEN ""Safari 4"" 
		WHEN userAgent LIKE ('%5._ Safari%') 	THEN ""Safari 5"" 
		WHEN userAgent LIKE ('%5._._ Safari%') 	THEN ""Safari 5"" 
		WHEN userAgent LIKE ('%6._ Safari%') 	THEN ""Safari 6"" 
		WHEN userAgent LIKE ('%6._._ Safari%') 	THEN ""Safari 6"" 
		WHEN userAgent LIKE ('%6._._.____ Safari%') 	THEN ""Safari 6"" 	
		WHEN userAgent LIKE ('%7._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%7._._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%7._._._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%8._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%8._._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%8._._._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%9._ Safari%') 	THEN ""Safari 9"" 
		WHEN userAgent LIKE ('%9._._ Safari%') 	THEN ""Safari 9"" 
		WHEN userAgent LIKE ('%9._._._ Safari%') 	THEN ""Safari 9"" 
		WHEN INSTR(userAgent,'Safari/7534.48.3') 	THEN ""Safari 5""
		WHEN INSTR(userAgent,'Safari/8536.25') 	THEN ""Safari 6""
		WHEN userAgent LIKE ('%Safari%') 	THEN ""Safari v?"" 
		WHEN INSTR(userAgent,'Opera/8') 	THEN ""Opera 8""
		WHEN INSTR(userAgent,'Opera 8') 	THEN ""Opera 8""
		WHEN INSTR(userAgent,'Opera/9') 	THEN ""Opera 9""
		WHEN INSTR(userAgent,'Opera 9') 	THEN ""Opera 9""
		WHEN INSTR(userAgent,'Opera/10') 	THEN ""Opera 10""
		WHEN INSTR(userAgent,'Opera 10') 	THEN ""Opera 10""
		WHEN INSTR(userAgent,'Opera/11') 	THEN ""Opera 11""
		WHEN INSTR(userAgent,'Opera 11') 	THEN ""Opera 11""
		WHEN INSTR(userAgent,'Opera/12') 	THEN ""Opera 12""
		WHEN INSTR(userAgent,'Opera 12') 	THEN ""Opera 12""
		WHEN INSTR(userAgent,'Opera') 	THEN ""Opera v?""
		WHEN INSTR(userAgent,'Camino') 	THEN ""Camino""
		WHEN INSTR(userAgent,'Mobile') THEN ""Other Mobile Browser""
		ELSE ""Other Browser""
	END;
RETURN browserName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSEROS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSEROS`(userAgent NVARCHAR(255)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE browserOS VARCHAR(20);
  SET browserOS = 
	CASE
		WHEN INSTR(userAgent,'sunOS') 		THEN ""sunOS""
		WHEN INSTR(userAgent,'FreeBSD') 	THEN ""FreeBSD""
		WHEN INSTR(userAgent,'openBSD') 	THEN ""openBSD""
		WHEN INSTR(userAgent,'SymbianOS') 	THEN ""SymbianOS""
		WHEN INSTR(userAgent,'Symbian') 	THEN ""SymbianOS""
		WHEN INSTR(userAgent,'webOS') 		THEN ""webOS""
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Android') 	THEN ""Android""
		WHEN INSTR(userAgent,'Linux') 		THEN ""Linux""
		WHEN INSTR(userAgent,'Windows CE') 	THEN ""Windows CE""
		WHEN INSTR(userAgent,'Windows Phone OS') 	THEN ""Windows Phone OS""
		WHEN INSTR(userAgent,'Windows') 	THEN ""Windows""
		WHEN INSTR(userAgent,'OS 3') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 4') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 5') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 6') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 7') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 8') 		THEN ""iOS""
		WHEN INSTR(userAgent,'iPhone OS') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iPad') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iPhone') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iOS') 	THEN ""iOS""
		WHEN INSTR(userAgent,'Mac') 		THEN ""Mac""
		WHEN INSTR(userAgent,'crOS ') 		THEN ""Chrome OS"" 
		ELSE ""Other OS""
	END;
RETURN browserOS;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_COUNTRYNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_COUNTRYNAME`(countryCode VARCHAR(25)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE countryName VARCHAR(50);
SET countryName = 
  CASE countryCode
	WHEN 'AF' THEN 'Afghanistan'
	WHEN 'Afghanistan' THEN 'Afghanistan'
	WHEN 'AX' THEN 'Aland Islands'
	WHEN 'AL' THEN 'Albania'
	WHEN 'DZ' THEN 'Algeria'
	WHEN 'AS' THEN 'American Samoa'
	WHEN 'AD' THEN 'Andorra'
	WHEN 'AO' THEN 'Angola'
	WHEN 'AI' THEN 'Anguilla'
	WHEN 'AQ' THEN 'Antarctica'
	WHEN 'AG' THEN 'Antigua and Barbuda'
	WHEN 'AR' THEN 'Argentina'
	WHEN 'AM' THEN 'Armenia'
	WHEN 'AW' THEN 'Aruba'
	WHEN 'AU' THEN 'Australia'
	WHEN 'AUST' THEN 'Australia'
	WHEN 'AUSTRALIA' THEN 'Australia'
	WHEN 'AT' THEN 'Austria'
	WHEN 'Osterreich' THEN 'Austria'
	WHEN 'AZ' THEN 'Azerbaidjan'
	WHEN 'BS' THEN 'Bahamas'
	WHEN 'BH' THEN 'Bahrain'
	WHEN 'BD' THEN 'Bangladesh'
	WHEN 'BB' THEN 'Barbados'
	WHEN 'BY' THEN 'Belarus'
	WHEN 'BE' THEN 'Belgium'
	WHEN 'Belgium' THEN 'Belgium'
	WHEN 'BZ' THEN 'Belize'
	WHEN 'BJ' THEN 'Benin'
	WHEN 'BM' THEN 'Bermuda'
	WHEN 'BT' THEN 'Bhutan'
	WHEN 'BO' THEN 'Bolivia'
	WHEN 'BQ' THEN 'Bonaire'
	WHEN 'BA' THEN 'Bosnia-Herzegovina'
	WHEN 'BW' THEN 'Botswana'
	WHEN 'Botswana' THEN 'Botswana'
	WHEN 'BV' THEN 'Bouvet Island'
	WHEN 'BR' THEN 'Brazil'
	WHEN 'Brasil' THEN 'Brazil'
	WHEN 'Brazil' THEN 'Brazil'
	WHEN 'IO' THEN 'British Indian Ocean Territory'
	WHEN 'BN' THEN 'Brunei Darussalam'
	WHEN 'BG' THEN 'Bulgaria'
	WHEN 'Bulgaria' THEN 'Bulgaria'
	WHEN 'BF' THEN 'Burkina Faso'
	WHEN 'BI' THEN 'Burundi'
	WHEN 'KH' THEN 'Cambodia'
	WHEN 'CM' THEN 'Cameroon'
	WHEN 'CA' THEN 'Canada'
	WHEN 'Canada' THEN 'Canada'
	WHEN 'Newfoundland' THEN 'Canada'
	WHEN 'CV' THEN 'Cape Verde'
	WHEN 'KY' THEN 'Cayman Islands'
	WHEN 'Cayman Islands' THEN 'Cayman Islands'
	WHEN 'CF' THEN 'Central African Republic'
	WHEN 'TD' THEN 'Chad'
	WHEN 'CL' THEN 'Chile'
	WHEN 'Chile' THEN 'Chile'
	WHEN 'CN' THEN 'China'
	WHEN 'China' THEN 'China'
	WHEN 'CX' THEN 'Christmas Island'
	WHEN 'CC' THEN 'Cocos Islands'
	WHEN 'CO' THEN 'Colombia'
	WHEN 'Colombia' THEN 'Colombia'
	WHEN 'KM' THEN 'Comoros'
	WHEN 'CD' THEN 'Congo'
	WHEN 'CG' THEN 'Congo'
	WHEN 'CK' THEN 'Cook Islands'
	WHEN 'CR' THEN 'Costa Rica'
	WHEN 'Costa Rica' THEN 'Costa Rica'
	WHEN 'CI' THEN ""Cote D'Ivoire""
	WHEN 'HR' THEN 'Croatia'
	WHEN 'CU' THEN 'Cuba'
	WHEN 'CW' THEN 'Curacao'
	WHEN 'CY' THEN 'Cyprus'
	WHEN 'CZ' THEN 'Czech Republic'
	WHEN 'Czech Republic' THEN 'Czech Republic'
	WHEN 'DK' THEN 'Denmark'
	WHEN 'Denmark' THEN 'Denmark'
	WHEN 'DJ' THEN 'Djibouti'
	WHEN 'DM' THEN 'Dominica'
	WHEN 'DO' THEN 'Dominican Republic'
	WHEN 'Republica Dominicana' THEN 'Dominican Republic'
	WHEN 'EC' THEN 'Ecuador'
	WHEN 'Ecuador' THEN 'Ecuador'
	WHEN 'EG' THEN 'Egypt'
	WHEN 'SV' THEN 'El Salvador'
	WHEN 'GQ' THEN 'Equatorial Guinea'
	WHEN 'ER' THEN 'Eritrea'
	WHEN 'EE' THEN 'Estonia'
	WHEN 'Estonia' THEN 'Estonia'
	WHEN 'ET' THEN 'Ethiopia'
	WHEN 'FK' THEN 'Falkland Islands'
	WHEN 'FO' THEN 'Faroe Islands'
	WHEN 'FJ' THEN 'Fiji'
	WHEN 'Fiji' THEN 'Fiji'
	WHEN 'FI' THEN 'Finland'
	WHEN 'FR' THEN 'France'
	WHEN 'FRANCE' THEN 'France'
	WHEN 'GF' THEN 'French Guyana'
	WHEN 'PF' THEN 'French Polynesia'
	WHEN 'TF' THEN 'French Southern Territories'
	WHEN 'GA' THEN 'Gabon'
	WHEN 'GM' THEN 'Gambia'
	WHEN 'GE' THEN 'Georgia'
	WHEN 'DE' THEN 'Germany'
	WHEN 'Deutschland' THEN 'Germany'
	WHEN 'Germany' THEN 'Germany'
	WHEN 'GH' THEN 'Ghana'
	WHEN 'GI' THEN 'Gibraltar'
	WHEN 'GR' THEN 'Greece'
	WHEN 'GREECE' THEN 'Greece'
	WHEN 'GL' THEN 'Greenland'
	WHEN 'GD' THEN 'Grenada'
	WHEN 'GP' THEN 'Guadeloupe'
	WHEN 'GU' THEN 'Guam'
	WHEN 'GT' THEN 'Guatemala'
	WHEN 'GUATEMALA' THEN 'Guatemala'
	WHEN 'GG' THEN 'Guernsey'
	WHEN 'GN' THEN 'Guinea'
	WHEN 'GW' THEN 'Guinea-Bissau'
	WHEN 'GY' THEN 'Guyana'
	WHEN 'HT' THEN 'Haiti'
	WHEN 'HM' THEN 'Heard and McDonald Islands'
	WHEN 'HN' THEN 'Honduras'
	WHEN 'HK' THEN 'Hong Kong'
	WHEN 'HU' THEN 'Hungary'
	WHEN 'Hungary' THEN 'Hungary'
	WHEN 'IS' THEN 'Iceland'
	WHEN 'IN' THEN 'India'
	WHEN 'India' THEN 'India'
	WHEN 'ID' THEN 'Indonesia'
	WHEN 'INDONESIA' THEN 'Indonesia'
	WHEN 'IR' THEN 'Iran'
	WHEN 'IQ' THEN 'Iraq'
	WHEN 'IE' THEN 'Ireland'
	WHEN 'Ireland' THEN 'Ireland'
	WHEN 'IM' THEN 'Isle of Man'
	WHEN 'IL' THEN 'Israel'
	WHEN 'Israel' THEN 'Israel'
	WHEN 'IT' THEN 'Italy'
	WHEN 'Italia' THEN 'Italy'
	WHEN 'ITALY' THEN 'Italy'
	WHEN 'JM' THEN 'Jamaica'
	WHEN 'JP' THEN 'Japan'
	WHEN 'Japan' THEN 'Japan'
	WHEN 'JE' THEN 'Jersey'
	WHEN 'JO' THEN 'Jordan'
	WHEN 'KZ' THEN 'Kazakhstan'
	WHEN 'KE' THEN 'Kenya'
	WHEN 'KI' THEN 'Kiribati'
	WHEN 'KP' THEN 'Korea'
	WHEN 'KW' THEN 'Kuwait'
	WHEN 'KG' THEN 'Kyrgyzstan'
	WHEN 'LA' THEN 'Laos'
	WHEN 'LV' THEN 'Latvia'
	WHEN 'Latvia' THEN 'Latvia'
	WHEN 'LB' THEN 'Lebanon'
	WHEN 'Lebanon' THEN 'Lebanon'
	WHEN 'LS' THEN 'Lesotho'
	WHEN 'LR' THEN 'Liberia'
	WHEN 'LY' THEN 'Libya'
	WHEN 'Libya' THEN 'Libyan Arab Jamahiriya'
	WHEN 'LI' THEN 'Liechtenstein'
	WHEN 'LT' THEN 'Lithuania'
	WHEN 'Lithuania' THEN 'Lithuania'
	WHEN 'LU' THEN 'Luxembourg'
	WHEN 'MO' THEN 'Macau'
	WHEN 'MK' THEN 'Macedonia'
	WHEN 'MG' THEN 'Madagascar'
	WHEN 'MW' THEN 'Malawi'
	WHEN 'MY' THEN 'Malaysia'
	WHEN 'Malaysia' THEN 'Malaysia'
	WHEN 'MV' THEN 'Maldives'
	WHEN 'ML' THEN 'Mali'
	WHEN 'MT' THEN 'Malta'
	WHEN 'MH' THEN 'Marshall Islands'
	WHEN 'MQ' THEN 'Martinique'
	WHEN 'MR' THEN 'Mauritania'
	WHEN 'MU' THEN 'Mauritius'
	WHEN 'YT' THEN 'Mayotte'
	WHEN 'MX' THEN 'Mexico'
	WHEN '77710' THEN 'Mexico'
	WHEN 'Mexico' THEN 'Mexico'
	WHEN 'Mexico D.F (Mexico)' THEN 'Mexico'
	WHEN 'FM' THEN 'Micronesia'
	WHEN 'MD' THEN 'Moldavia'
	WHEN 'MC' THEN 'Monaco'
	WHEN 'MN' THEN 'Mongolia'
	WHEN 'ME' THEN 'Montenegro'
	WHEN 'MS' THEN 'Montserrat'
	WHEN 'MA' THEN 'Morocco'
	WHEN 'Morocco' THEN 'Morocco'
	WHEN 'MZ' THEN 'Mozambique'
	WHEN 'MM' THEN 'Myanmar'
	WHEN 'NA' THEN 'Namibia'
	WHEN 'NR' THEN 'Nauru'
	WHEN 'NP' THEN 'Nepal'
	WHEN 'NL' THEN 'Netherlands'
	WHEN 'Netherlands' THEN 'Netherlands'
	WHEN 'The Netherlands' THEN 'Netherlands'
	WHEN 'NC' THEN 'New Caledonia'
	WHEN 'NZ' THEN 'New Zealand'
	WHEN 'New Zealand' THEN 'New Zealand'
	WHEN 'NI' THEN 'Nicaragua'
	WHEN 'NE' THEN 'Niger'
	WHEN 'NG' THEN 'Nigeria'
	WHEN 'NU' THEN 'Niue'
	WHEN 'NF' THEN 'Norfolk Island'
	WHEN 'MP' THEN 'Northern Mariana Islands'
	WHEN 'NO' THEN 'Norway'
	WHEN 'Norway' THEN 'Norway'
	WHEN 'OM' THEN 'Oman'
	WHEN 'ZZ' THEN 'Other'
	WHEN 'PK' THEN 'Pakistan'
	WHEN 'PW' THEN 'Palau'
	WHEN 'PS' THEN 'Palestine'
	WHEN 'PA' THEN 'Panama'
	WHEN 'Panama' THEN 'Panama'
	WHEN 'PG' THEN 'Papua New Guinea'
	WHEN 'PY' THEN 'Paraguay'
	WHEN 'Paraguay' THEN 'Paraguay'
	WHEN 'PE' THEN 'Peru'
	WHEN 'Peru' THEN 'Peru'
	WHEN 'PH' THEN 'Philippines'
	WHEN 'PN' THEN 'Pitcairn Islands'
	WHEN 'PL' THEN 'Poland'
	WHEN 'Capgemini' THEN 'Poland'
	WHEN 'Krakow' THEN 'Poland'
	WHEN 'Poland' THEN 'Poland'
	WHEN 'Polska' THEN 'Poland'
	WHEN 'PT' THEN 'Portugal'
	WHEN 'Portugal' THEN 'Portugal'
	WHEN 'PR' THEN 'Puerto Rico'
	WHEN 'QA' THEN 'Qatar'
	WHEN 'RE' THEN 'Reunion'
	WHEN 'RO' THEN 'Romania'
	WHEN 'Romania' THEN 'Romania'
	WHEN 'RU' THEN 'Russia'
	WHEN 'Russia' THEN 'Russia'
	WHEN 'Russian Federation' THEN 'Russia'
	WHEN 'RW' THEN 'Rwanda'
	WHEN 'BL' THEN 'Saint Barthelemy'
	WHEN 'SH' THEN 'Saint Helena'
	WHEN 'KN' THEN 'Saint Kitts and Nevis Anguilla'
	WHEN 'LC' THEN 'Saint Lucia'
	WHEN 'MF' THEN 'Saint Martin'
	WHEN 'SX' THEN 'Saint Martin'
	WHEN 'VC' THEN 'Saint Vincent and Grenadines'
	WHEN 'WS' THEN 'Samoa'
	WHEN 'SM' THEN 'San Marino'
	WHEN 'ST' THEN 'Sao Tome and Principe'
	WHEN 'SA' THEN 'Saudi Arabia'
	WHEN 'SN' THEN 'Senegal'
	WHEN 'RS' THEN 'Serbia'
	WHEN 'SC' THEN 'Seychelles'
	WHEN 'SL' THEN 'Sierra Leone'
	WHEN 'SG' THEN 'Singapore'
	WHEN 'SK' THEN 'Slovakia'
	WHEN 'Slovakia' THEN 'Slovakia'
	WHEN 'SI' THEN 'Slovenia'
	WHEN 'Slovenia' THEN 'Slovenia'
	WHEN 'SB' THEN 'Solomon Islands'
	WHEN 'SO' THEN 'Somalia'
	WHEN 'ZA' THEN 'South Africa'
	WHEN 'RSA' THEN 'South Africa'
	WHEN 'South Africa' THEN 'South Africa'
	WHEN 'GS' THEN 'South Georgia and the South Sandwich Islands'
	WHEN 'KR' THEN 'South Korea'
	WHEN 'SS' THEN 'South Sudan'
	WHEN 'ES' THEN 'Spain'
	WHEN 'Espana' THEN 'Spain'
	WHEN 'Spain' THEN 'Spain'
	WHEN 'LK' THEN 'Sri Lanka'
	WHEN 'PM' THEN 'St. Pierre and Miquelon'
	WHEN 'SD' THEN 'Sudan'
	WHEN 'SR' THEN 'Suriname'
	WHEN 'SJ' THEN 'Svalbard and Jan Mayen Islands'
	WHEN 'SZ' THEN 'Swaziland'
	WHEN 'SE' THEN 'Sweden'
	WHEN 'Sweden' THEN 'Sweden'
	WHEN 'CH' THEN 'Switzerland'
	WHEN 'Switzerland' THEN 'Switzerland'
	WHEN 'SY' THEN 'Syrian Arab Republic'
	WHEN 'TW' THEN 'Taiwan'
	WHEN 'Taiwan' THEN 'Taiwan'
	WHEN 'TJ' THEN 'Tajikistan'
	WHEN 'TZ' THEN 'Tanzania'
	WHEN 'Tanzania' THEN 'Tanzania'
	WHEN 'TH' THEN 'Thailand'
	WHEN 'Thailand' THEN 'Thailand'
	WHEN 'TL' THEN 'Timor-Leste'
	WHEN 'TG' THEN 'Togo'
	WHEN 'TK' THEN 'Tokelau'
	WHEN 'TO' THEN 'Tonga'
	WHEN 'TT' THEN 'Trinidad and Tobago'
	WHEN 'TN' THEN 'Tunisia'
	WHEN 'TR' THEN 'Turkey'
	WHEN 'Turkey' THEN 'Turkey'
	WHEN 'TM' THEN 'Turkmenistan'
	WHEN 'TC' THEN 'Turks and Caicos Islands'
	WHEN 'TV' THEN 'Tuvalu'
	WHEN 'UG' THEN 'Uganda'
	WHEN 'UA' THEN 'Ukraine'
	WHEN 'AE' THEN 'United Arab Emirates'
	WHEN 'UAE' THEN 'United Arab Emirates'
	WHEN 'GB' THEN 'United Kingdom'
	WHEN 'England' THEN 'United Kingdom'
	WHEN 'United Kingdom' THEN 'United Kingdom'
	WHEN 'UK' THEN 'United Kingdom'
	WHEN 'US' THEN 'United States'
	WHEN 'United States' THEN 'United States'
	WHEN 'United States of America' THEN 'United States'
	WHEN 'USA' THEN 'United States'
	WHEN 'UM' THEN 'United States Minor Outlying Islands'
	WHEN 'UY' THEN 'Uruguay'
	WHEN 'Uruguay' THEN 'Uruguay'
	WHEN 'UZ' THEN 'Uzbekistan'
	WHEN 'VU' THEN 'Vanuatu'
	WHEN 'VA' THEN 'Vatican City'
	WHEN 'VE' THEN 'Venezuela'
	WHEN 'VN' THEN 'Vietnam'
	WHEN 'VG' THEN 'Virgin Islands'
	WHEN 'VI' THEN 'Virgin Islands'
	WHEN 'WF' THEN 'Wallis and Futuna'
	WHEN 'EH' THEN 'Western Sahara'
	WHEN 'YE' THEN 'Yemen'
	WHEN 'ZM' THEN 'Zambia'
	WHEN 'ZW' THEN 'Zimbabwe'
     ELSE CONCAT('Country ', countryCode)
  END;
RETURN countryName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_BUCKET","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_BUCKET`(source NVARCHAR(255)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE GET_BUCKET VARCHAR(20);
  SET GET_BUCKET = 
 	CASE
		
		WHEN source IN (""Sharing"", ""Referrals"", ""Application"") 	
			THEN ""Viral""
			
		
		WHEN source IN (""Affiliate"", ""Campaign"", ""Email Campaigns"", ""General Awareness"", ""Free Directory"", ""SEO"", ""Social"", ""Website Links"",""Blog Posse"")  	
			THEN ""Other""		
			
		
		WHEN source IN (""Partner"", ""App Store"")  	
			THEN ""Partner""
			
		
		WHEN source IN (""Paid Placement"", ""PPC - Foreign Language"", ""PPC - English - International"", ""PPC"",""Paid - Social"",""Paid - Email"")
		THEN ""Paid""
		ELSE ""--unknown bucket--""
	END;
RETURN GET_BUCKET;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_QUERY_PARAMETER","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_QUERY_PARAMETER`(url NVARCHAR(500), parameterName NVARCHAR(50)) RETURNS varchar(500) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE parameterValue VARCHAR(500);
DECLARE parameterNameLength BIGINT;
DECLARE startPosition BIGINT;
DECLARE endPosition BIGINT;
  SET parameterValue = NULL;
  
  
  SET startPosition = LOCATE(CONCAT(""?"", parameterName, ""=""), url);
  
 IF startPosition = 0 THEN
	SET startPosition = LOCATE(CONCAT(""&"", parameterName, ""=""), url);
  END IF;
  
  
  IF startPosition > 0 THEN
  
	  SET parameterNameLength = LENGTH(parameterName) + 2;  
		
	  SET endPosition = LOCATE(""&"" , url, startPosition + 1);
	  	
	  IF endPosition > 0 THEN
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength, endPosition - (startPosition + parameterNameLength));
	  ELSE
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength);
	  END IF;
  END IF;
  
RETURN parameterValue;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_SOURCE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_SOURCE`(subSource NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE GET_SOURCE VARCHAR(50);
  SET GET_SOURCE = 
 	CASE
		
		WHEN subSource IN (""Signup with Sharing Tracking Codes"", ""Signup Inserted by Smartsheet User"") 	
			THEN ""Sharing""
		WHEN subSource IN (""Web Forms - Powered BY Smartsheet"", ""Published Sheet - Powered by Smartsheet"")  	
			THEN ""Application""	
		WHEN subSource IN (""Mail Link"", ""My Smartsheet Referral"", ""Referral Rewards"")  	
			THEN ""Referrals""	
			
		
		WHEN subSource IN (""Amazon Web Services"", ""AWS Marketplace"", ""Brad Egeland"", ""Crowdsourcing.org"", ""Sitepoint"", ""Sage Non-Profit"", ""Office Arrow"", ""VA Network"", ""Veronica Conway"",
							""Jott"", ""Success Connections"", ""smallbiztrends.com"", ""A Clayton's Secretary"", ""Officebundle.com"", 
							""Caroline Melville Society of Virtual Assistants"", ""Caroline Melville Virtually Sorted"",
							""Baird Consulting"", ""Biz Recipes"", ""OnlineBizU"", ""Assistant Match"", ""Ki-Work"", ""Tradeshow Coach"", ""Regina Minger"",""Kindle"",
							""Stack Overflow"")  	
			THEN ""Affiliate""		
		WHEN subSource IN (""TJ McCue"", ""NAPS"")  	
			THEN ""Campaign""	
		WHEN subSource IN (""Email"")  	
			THEN ""Email Campaigns""	
		WHEN subSource IN (""Smartsheet Search"", ""Smartsheet Search (Not Provided)"" , 
							""Smartsheet Paid Google Search"", ""Smartsheet Paid Bing Search"" , 
							""Direct Navigation"", ""Distributed Container"")  	
			THEN ""General Awareness""
		WHEN subSource IN (""Google Templates"", ""thesmallbusinessweb.com"")  	
			THEN ""Free Directory""	
		WHEN subSource IN (""SEO"", ""SEO (Not Provided)"")  	
			THEN ""SEO""	
		WHEN subSource IN (""YouTube (unpaid)"", ""Twitter (unpaid)"", ""Social Media (generic)"", ""Facebook (unpaid)"", ""LinkedIn (unpaid)"", ""Google+ (unpaid)"", ""Social Media Coordinator - Keri"",
		""Slideshare.net"")  	
			THEN ""Social""		
		WHEN subSource IN (""External Source Links"")  	
			THEN ""Website Links""	
		
		WHEN subSource IN (""Apple App Store"", ""Android App Store"", ""Google Play Store"")  	
			THEN ""App Store""	
		WHEN subSource IN ( ""Elizabeth Harrin (blog posse)"", ""Robert Kelly (blog posse)"", ""Lindsay Scott (blog posse)"")  	
			THEN ""Blog Posse""	
		
		WHEN subSource IN (""Google App. Marketplace"", ""Chrome Web Store"", ""Intuit"", ""Zimbra"", ""Salesforce.com"", ""Box"", ""Cloud Alliance for Google Apps"", 
							""Centrify"", ""Google Drive - New File"", ""Google Drive - Import"",""Zapier"",""Dropbox"",""123 Contact Form"",""Marketo Launchpoint"",""Docusign"",
							""MailChimp"",""Harvest"",""Evernote"",""Amazon Mechanical Turk"",""AppGuru"",""Backupify"",""Bitium"",""Easy Insight"",
							""OneLogin"",""PingOne"",""Klipfolio"",""Tools4ever"",""Okta"",""Third Party Authorization Flow"",""BetterCloud"",
							""Smartsheet Merge (Google Docs Add-on)"",""Smartsheet Forms (Google Forms Add-on)"",""Microsoft"",""Wave"")  	
			THEN ""Partner""
		
		
		WHEN subSource IN (""Serchen"", ""The Deck"", ""PM Sherpa"", ""GetApp.com"", ""Geekwire"", ""USA Today"", ""Pac NW Soccer"",""Spiceworks"")
			THEN ""Paid Placement""
			
		WHEN subSource IN ( ""Spanish - Google Search Test"", ""Spanish - Google Display Network Test"",
							""Spanish (US) - Google Display"", ""Spanish (US) - Google Search"",
							""Spanish (Mexico) - Google Display"", ""Spanish (Mexico) - Google Search"",
							""Spanish (Spain) - Google Display"", ""Spanish (Spain) - Google Search"",
							""Spanish (Other) - Google Display"", ""Spanish (Other) - Google Search"",
							""Spanish (Argentina)  Google Display"", ""Spanish (Argentina)  Google Search"",
							""Spanish (Peru)  Google Display"", ""Spanish (Peru)  Google Search"",
							""Spanish (Venezuela)  Google Display"", ""Spanish (Venezuela)  Google Search"",
							""Spanish (Chile)  Google Display"", ""Spanish (Chile)  Google Search"",
							""Spanish (Guatemala)  Google Display"", ""Spanish (Guatemala)  Google Search"",
							""Spanish (Ecuador)  Google Display"", ""Spanish (Ecuador)  Google Search"",
							
							""French (Tier 1) - Google Display"", ""French (Tier 1) - Google Search"",
							""French (Tier 2) - Google Display"", ""French (Tier 2) - Google Search"",
							
							""Portuguese (Brazil) - Google Display"", ""Portuguese (Brazil) - Google Search"",
							""Portuguese (Portugal) - Google Display"", ""Portuguese (Portugal) - Google Search"",
											
							""German - Google Display"", ""German - Google Search"",
							
							""Italian - Google Display"", ""Italian - Google Search"",
							""Bing Search - French"",
							""Bing Search - German"",
							""Bing Search - Portuguese (Brazil)"",
							""Bing Search - Portuguese (Portugal)"",
							""Bing Search - Spanish"",
							""Bing Search - Italian"",
							""Google Search - Russian"",
							""Yandex (paid)"",
							""Google Search - Japanese"",
							 ""Yahoo Japan"")
			THEN ""PPC - Foreign Language""
			
		WHEN subSource IN ( ""Bing Search (Canada)"", ""Bing Search (Singapore)"", ""Bing Search (UK)"",
		
							""South Africa - Google Display"", ""South Africa - Google Search"", 
							""Israel - Google Display"", ""Israel - Google Search"",
							""Saudi Arabia - Google Display"", ""Saudi Arabia - Google Search"",
				
							""Belgium - Google Display"", ""Belgium - Google Search"",
							""Finland - Google Display"", ""Finland - Google Search"",
							""Denmark - Google Display"", ""Denmark - Google Search"",
							""Netherlands - Google Display"", ""Netherlands - Google Search"",
							""Norway - Google Display"", ""Norway - Google Search"",
							""Sweden - Google Display"", ""Sweden - Google Search"",
							""Germany - Google Display"", ""Germany - Google Search"",
							""France - Google Display"", ""France - Google Search"", 
							""Spain - Google Display"", ""Spain - Google Search"",
							""Italy - Google Display"", ""Italy - Google Search"",
							
							""Turkey - Google Display"", ""Turkey - Google Search"",
							""Russia - Google Display"", ""Russia - Google Search"",
							
							""Hong Kong - Google Display"", ""Hong Kong - Google Search"",
							""Singapore - Google Display"", ""Singapore - Google Search"",
							""Japan - Google Display"", ""Japan - Google Search"",
							""South Korea - Google Display"", ""South Korea - Google Search"",
							""China - Google Display"", ""China - Google Search"",
							
							""Mexico - Google Display"", ""Mexico - Google Search"",
							
							""Brazil - Google Display"", ""Brazil - Google Search"",
							""Columbia - Google Display"", ""Columbia - Google Search"",
							""Argentina - Google Display"", ""Argentina - Google Search"",
							
							""India - Google Display"", ""India - Google Search"",
							""Indonesia - Google Display"", ""Indonesia - Google Search"",
							""Malaysia - Google Display"", ""Malaysia - Google Search"",
							""Philippines - Google Display"", ""Philippines - Google Search"",
							
							""_Display - Managed Placements - Tier 1 International"", ""_Display - Managed Placements - Tier 2 International"",
							""_Google Search - International - Tier 1"", ""_Google Search - International - Tier 2"",
							""Google Display International - Text Ads"", ""Google Display International - Image Ads"",
							""Bing Search - International - Tier 1"",
							""Google Search Companion Marketing (International)"")
			THEN ""PPC - English - International""
			
		WHEN subSource IN ( 
				""_Google Search"", 
				""_Google Display Network"",	
				 ""Yahoo"",
				 ""Ask.com"",
				 ""_Google Search"",
				 ""Go2Web20.net"",
				""_Bing Search"",
				""_Bing Content Network"",
				""Ad Ready Network"",
				""Facebook"",
				""LinkedIn"",
				""LinkedIn InMail"",
				""LinkedIn International (paid)"",
				""_Google Display (iPad only)"",
				""_Google Search (iPad only)"",									
				""Google Remarketing (Paid Visitors)"", ""Google Remarketing (Non-paid Visitors)"", ""Google Remarketing (Nurture Signups)"",			
				""Bing Search (French - Canada)"", ""Bing Search (French - France)"",
				""Youtube (promoted videos)"",
				""_Display - Managed Placements"",
				""Google Adwords Sitelinks"",
				""Google Mobile Search (iphone)"", ""Google Mobile Search (non-iphone)"",
				""Enterprise Display Test - Spreadsheet Hell - Desktop"", ""Enterprise Display Test - Spreadsheet Hell - Mobile"",
				""BlueKai - (Google)"", ""Similar Audiences - (Google)"",
				""Gmail Ads"",
				""Gmail Ads - International"",
				""Google Display - Interest Targeted"",
				""Video for Adwords"",
 				""Google Business Category Display"",
 				""Seattle GEO Target (Google Search)"",
				""Seattle GEO Target (Bing Search)"",
				""Seattle GEO Target (Google Display Image)"",
				""Seattle GEO Target (Bing Content)"",
				""Seattle GEO Target (Google Text Display)"",
				""Google Display - Image Ads"",
				""Google Display - Text Ads"",
				""Google Search Companion Marketing"",
				""Similar Audiences (Google) - International"",
				""Google Display - Interest Targeted (International)"",
				""Bing Display - Text Ads (USA)"",
				""Bing Display - Text Ads (English Not USA)"",
				""Bing Sitelinks"",
				""Display - Select Keyword"",
				""Display - Select Keyword (International)""
				 )
		THEN ""PPC""
		WHEN subsource IN (""Twitter (paid)"") THEN ""Paid - Social""
		WHEN subsource IN (""DemandMetric.com"",""ProjectManagers.net"",""ProjectsAtWork.com"",""ProjectManagement.com"") THEN ""Paid - Email""
		ELSE ""--unknown source--""
	END;
RETURN GET_SOURCE;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_LOGINTYPENAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_LOGINTYPENAME`(loginType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE loginTypeName VARCHAR(50);
SET loginTypeName = 
	CASE loginType
		WHEN 1 THEN ""Drupal Login (deprecated)""
		WHEN 2 THEN ""Login Form""
		WHEN 3 THEN ""Request Digest (deprecated)""
		WHEN 4 THEN ""Login Ticket Drupal (deprecated)""
		WHEN 5 THEN ""OPS Monitor (deprecated)""
		WHEN 6 THEN ""OPS Console (deprecated)""
		WHEN 7 THEN ""Login Ticket Auto Signin""
		WHEN 8 THEN ""Login Ticket Remember Me""
		WHEN 9 THEN ""API""
		WHEN 10 THEN ""Login Ticket Password Reset""
		WHEN 11 THEN ""Update Request""
		WHEN 12 THEN ""Quick Add""
		WHEN 13 THEN ""Editable Publish""
		WHEN 14 THEN ""OpenID""
		WHEN 15 THEN ""Read-only Publish""
		WHEN 16 THEN ""Intuit Workplace (deprecated)""
		WHEN 17 THEN ""Ops Console OpenID (deprecated)""
		WHEN 18 THEN ""Gadget Session Exchange""
		WHEN 19 THEN ""SSO Salesforce""
		WHEN 20 THEN ""SSO SAML""
		WHEN 21 THEN ""Rest User Credentials""
		WHEN 22 THEN ""Rest Access Token""
		WHEN 23 THEN ""Login Ticket Remember Me Mobile""
		WHEN 24 THEN ""API""
		WHEN 25 THEN ""Rest Auth Code""
		WHEN 26 THEN ""Rest Refresh Token""
		WHEN 27 THEN ""Rest Unauthenticated""
		WHEN 28 THEN ""Rest Google Token Android""
		WHEN 29 THEN ""Google OAuth2""
		ELSE CONCAT ('login ', loginType)
	END;
return loginTypeName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_NEXTPAYMENTDATE","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_NEXTPAYMENTDATE`(currentDateTime                DATETIME,
                                                                     iNextPaymentDate              DATETIME,
                                                                     pNextPaymentDate              DATETIME,
                                                                     paymentTerm                   TINYINT,
                                                                     iActualLastPaymentDate        DATETIME,
                                                                     pActualLastPaymentDate        DATETIME,
                                                                     accountType                   TINYINT,
                                                                     iPaymentStartDateTime         DATETIME,
                                                                     pPaymentStartDateTime         DATETIME,
                                                                     iPromoCode                    VARCHAR(50),
                                                                     pPromoCode                    VARCHAR(50),
                                                                     iPaymentProfileInsertDateTime DATETIME,
                                                                     pPaymentProfileInsertDateTime DATETIME) RETURNS datetime
    DETERMINISTIC
BEGIN
        DECLARE newNextPaymentDate DATETIME;
        declare nextPaymentDate datetime;
        declare actualLastPaymentDate datetime;
        DECLARE paymentStartDateTime DATETIME;
        DECLARE paymentStartDateTimeClean DATETIME;
        declare promoCode varchar(50);
        declare paymentProfileInsertDateTime datetime;

        
        SET nextPaymentDate = CASE WHEN accountType = 2 THEN pNextPaymentDate ELSE iNextPaymentDate END;
        SET actualLastPaymentDate = CASE WHEN accountType = 2 THEN pActualLastPaymentDate ELSE iActualLastPaymentDate END;
        SET paymentStartDateTime = CASE WHEN accountType = 2 THEN pPaymentStartDateTime ELSE ipaymentStartDateTime END;
        SET promoCode = CASE WHEN accountType = 2 THEN pPromoCode ELSE iPromoCode END;
        SET paymentProfileInsertDateTime = CASE WHEN accountType = 2 THEN pPaymentProfileInsertDateTime ELSE iPaymentProfileInsertDateTime END;

        
        SET paymentStartDateTimeClean =
            CASE paymentStartDateTime > '2008-09-30'
                WHEN 1
                    THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
                ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
            END;

        
        SET newNextPaymentDate =
            CASE
                WHEN nextPaymentDate > currentDateTime
                    THEN nextPaymentDate
                ELSE
                    CASE
                        WHEN paymentTerm = 12
                            THEN
                                CASE
                                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN 
                                            IF(STR_TO_DATE(CONCAT(YEAR(currentDateTime), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s') > currentDateTime,
                                               STR_TO_DATE(CONCAT(YEAR(currentDateTime), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s'),
                                               STR_TO_DATE(CONCAT(YEAR(currentDateTime) + 1, '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d %h:%i:%s'))
                                    WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                                         > currentDateTime
                                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
                                END
                        WHEN paymentTerm IN (1, 6)
                            THEN
                                CASE
                                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                        rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
                                    WHEN paymentTerm = 1
                                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                            rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
                                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
                                END
                        ELSE NULL
                    END
            END;
        RETURN newNextPaymentDate;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_NEXTPAYMENTDATETEST","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_NEXTPAYMENTDATETEST`(currentDateTime                DATETIME,
                                                                          iNextPaymentDate              DATETIME,
                                                                          pNextPaymentDate              DATETIME,
                                                                          paymentTerm                   TINYINT,
                                                                          iActualLastPaymentDate        DATETIME,
                                                                          pActualLastPaymentDate        DATETIME,
                                                                          accountType                   TINYINT,
                                                                          iPaymentStartDateTime         DATETIME,
                                                                          pPaymentStartDateTime         DATETIME,
                                                                          iPromoCode                    VARCHAR(50),
                                                                          pPromoCode                    VARCHAR(50),
                                                                          iPaymentProfileInsertDateTime DATETIME,
                                                                          pPaymentProfileInsertDateTime DATETIME) RETURNS datetime
    DETERMINISTIC
BEGIN
        DECLARE newNextPaymentDate DATETIME;
        declare nextPaymentDate datetime;
        declare actualLastPaymentDate datetime;
        DECLARE paymentStartDateTime DATETIME;
        DECLARE paymentStartDateTimeClean DATETIME;
        declare promoCode varchar(50);
        declare paymentProfileInsertDateTime datetime;

        
        SET nextPaymentDate = CASE WHEN accountType = 2 THEN pNextPaymentDate ELSE iNextPaymentDate END;
        SET actualLastPaymentDate = CASE WHEN accountType = 2 THEN pActualLastPaymentDate ELSE iActualLastPaymentDate END;
        SET paymentStartDateTime = CASE WHEN accountType = 2 THEN pPaymentStartDateTime ELSE ipaymentStartDateTime END;
        SET promoCode = CASE WHEN accountType = 2 THEN pPromoCode ELSE iPromoCode END;
        SET paymentProfileInsertDateTime = CASE WHEN accountType = 2 THEN pPaymentProfileInsertDateTime ELSE iPaymentProfileInsertDateTime END;

        
        SET paymentStartDateTimeClean =
            CASE paymentStartDateTime > '2008-09-30'
                WHEN 1
                    THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
                ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
            END;

        
        SET newNextPaymentDate =
            CASE
                WHEN nextPaymentDate > currentDateTime
                    THEN nextPaymentDate
                ELSE
                    CASE
                        WHEN paymentTerm = 12
                            THEN
                                CASE
                                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_FORMAT(
                                            CONCAT(YEAR(currentDateTime + 1), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)),
                                            '%Y-%m-%d 00:00:00')
                                    WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                                         > currentDateTime
                                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
                                END
                        WHEN paymentTerm IN (1, 6)
                            THEN
                                CASE
                                    WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                    WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                        THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                        rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
                                    WHEN paymentTerm = 1
                                        THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                            rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
                                    ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
                                END
                        ELSE NULL
                    END
            END;
        RETURN newNextPaymentDate;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTSTARTDATETIME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTSTARTDATETIME`(accountType                TINYINT,
                                                  productID                  INT,
                                                  paymentStartDateTime       DATETIME,
                                                  parentPaymentStartDateTime DATETIME) RETURNS datetime
    DETERMINISTIC
BEGIN
        DECLARE newPaymentStartDateTime DATETIME;
        SET newPaymentStartDateTime =
            CASE
                WHEN
                    accountType = 2 AND
                    productID = 7 AND
                    paymentStartDateTime < COALESCE(parentPaymentStartDateTime, """")
                    THEN parentPaymentStartDateTime
                ELSE paymentStartDateTime
            END;
        RETURN newPaymentStartDateTime;
    END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTTERM","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTTERM`(paymentTerm TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE paymentTermName VARCHAR(50);
SET paymentTermName = 
  CASE paymentTerm
     WHEN 1 THEN ""Monthly""
     WHEN 6 THEN ""Semi-Annual""
     WHEN 12 THEN ""Annual""
     ELSE CONCAT('Payment Term ', paymentTerm)
  END;
RETURN paymentTermName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTTYPE","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTTYPE`(paymentType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE paymentTypeName VARCHAR(50);
SET paymentTypeName = 
  CASE paymentType
     WHEN 0 THEN ""None""
     WHEN 1 THEN ""Credit Card""
     WHEN 2 THEN ""Bill To""
     WHEN 3 THEN ""Custom""
     WHEN 4 THEN ""Promo""
     WHEN 5 THEN ""Paid by Other""
     WHEN 6 THEN ""Third Party""
     WHEN 7 THEN ""Third Party - By Other""
     WHEN 8 THEN ""PayPal""
     WHEN 9 THEN ""Developer""
     WHEN 10 THEN ""Bill To App""
     ELSE CONCAT('Payment Type ', paymentType)
  END;
return paymentTypeName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTNAME","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTNAME`(productID INT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE productName VARCHAR(50);
SET productName = 
  CASE productID
     WHEN -1 THEN NULL
     WHEN 0 THEN ""Cancelled""
     WHEN 1 THEN ""Trial""
     WHEN 2 THEN ""Free""
     WHEN 3 THEN ""Basic""
     WHEN 4 THEN ""Advanced""
     WHEN 5 THEN ""Premium""
     WHEN 7 THEN ""Team""
     WHEN 8 THEN ""Team Plus""
     WHEN 6 THEN ""Enterprise_Legacy""
     WHEN 9 THEN ""Student""
     WHEN 10 THEN ""Business""
     WHEN 11 THEN ""Enterprise""
     ELSE CONCAT('Product ', productID)
  END;
RETURN productName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTNAMERANK","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTNAMERANK`(productName varchar(50)) RETURNS tinyint(4)
    DETERMINISTIC
BEGIN
DECLARE productRank TINYINT;
SET productRank = 
  CASE productName
     WHEN ""Cancelled""   THEN 1  
     WHEN ""Trial""       THEN 2  
     WHEN ""Free""        THEN 3  
     WHEN ""Student""     THEN 4  
     WHEN ""Basic""       THEN 5  
     WHEN ""Advanced""    THEN 6  
     WHEN ""Premium""     THEN 7  
     WHEN ""Team""        THEN 8  
     WHEN ""Team Plus""   THEN 9  
     WHEN ""Business""    THEN 10 
     WHEN ""Enterprise""  THEN 11 
     ELSE -1
  END;
RETURN productRank;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTRANK","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTRANK`(productID INT) RETURNS tinyint(4)
    DETERMINISTIC
BEGIN
DECLARE productRank TINYINT;
SET productRank = 
  CASE productID
     WHEN 0 THEN 1 
     WHEN 1 THEN 2 
     WHEN 2 THEN 3 
     WHEN 9 THEN 4 
     WHEN 3 THEN 5 
     WHEN 4 THEN 6 
     WHEN 5 THEN 7 
     WHEN 7 THEN 8 
     WHEN 8 THEN 9 
     WHEN 10 THEN 10 
     WHEN 6 THEN 11 
     ELSE -1
  END;
RETURN productRank;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_SFDCNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SFDCNAME`(sfdcName VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE DBName VARCHAR(200);
SET DBName = 
	CASE sfdcName
		WHEN '00540000002I1xUAAS' THEN 'Annika'
		WHEN '00540000002r9VrAAI' THEN 'Brian'
		WHEN '00540000002HJjdAAG' THEN 'Chad'
		WHEN '00540000002n53kAAA' THEN 'Colton'
		WHEN '00540000003TBobAAG' THEN 'Dan'	
		WHEN '00533000003ftWzAAI' THEN 'Daniel' 	
		WHEN '00540000001V66HAAS' THEN 'Darren'
		WHEN '00540000002nyKdAAI' THEN 'David'
		WHEN '00540000002pgcUAAQ' THEN 'Diana'
		WHEN '00533000003Tx3EAAS' THEN 'DrewJ'
		WHEN '00540000002qo7CAAQ' THEN 'Drew'	
		WHEN '00540000002pPx6AAE' THEN 'Evan'		
		WHEN '00540000002pD6KAAU' THEN 'Gary'		
		WHEN '00540000002qWBaAAM' THEN 'Jeana'	
		WHEN '00540000001V65sAAC' THEN 'Jennifer'
		WHEN '00533000003UqHGAA0' THEN 'Joel'	
		WHEN '00540000002HFLrAAO' THEN 'Kara'	
		WHEN '00540000002IYVtAAO' THEN 'Ken'
		WHEN '00540000002qXdzAAE' THEN 'Kevin'	
		WHEN '00533000003ftXEAAY' THEN 'Lee'
		WHEN '00540000002n544AAA' THEN 'Liz'
		WHEN '00540000002pPwrAAE' THEN 'Maddie'		
		WHEN '00540000002oaOPAAY' THEN 'Matthew'
		WHEN '00540000001TpXDAA0' THEN 'Max'
		WHEN '00533000003X6qpAAC' THEN 'Nate'
		WHEN '00540000002q7KrAAI' THEN 'Nick'
		WHEN '00540000002qXeiAAE' THEN 'NickN'		
		WHEN '00533000003UqHLAA0' THEN 'PaulC'		
		WHEN '00540000002orVSAAY' THEN 'Roman'		
		WHEN '00540000002HLLxAAO' THEN 'Ryaire'		
		WHEN '00540000002pgcPAAQ' THEN 'Ryan'	
		WHEN '00533000003ftX4AAI' THEN 'SamH'	
		WHEN '00533000003U473AAC' THEN 'SarahB'
		WHEN '00540000002FcZIAA0' THEN 'Sarah'
		WHEN '00540000002Fm0cAAC' THEN 'Sean'
		WHEN '00540000002J7pjAAC' THEN 'Steve'
		WHEN '00540000001UFtyAAG' THEN 'Tyler'
		WHEN '00540000002qf8LAAQ' THEN 'Tom'
		WHEN '00540000001U30SAAS' THEN 'Taryn'
		WHEN '00540000001U6hoAAC' THEN 'Desk Integration'
		WHEN '00540000002nu18AAA' THEN 'Andrew Imhoff'
		WHEN '00540000001UHNaAAO' THEN 'Leads Uploader'
		WHEN '00540000002HoCGAA0' THEN 'Marketo Integration'
		
		WHEN '00533000003Tx39AAC' THEN 'Sam'
		WHEN '00533000003UaPiAAK' THEN 'NickC'
		WHEN '00540000001U30XAAS' THEN 'Tim'
		WHEN '00540000001UcZXAA0' THEN 'AJ' 
		WHEN '00540000001UFlfAAG' THEN 'Taylor'
		WHEN '00540000001UFlVAAW' THEN 'Ben'
		WHEN '00540000001UiO2AAK' THEN 'Eric'
		WHEN '00540000002Fqe3AAC' THEN 'Joe'
		WHEN '00540000002GeyBAAS' THEN 'Jeff'
		WHEN '00540000002GeyGAAS' THEN 'Chris'
		WHEN '00540000002HJwXAAW' THEN 'ChrisK'
		WHEN '00540000002I1xKAAS' THEN 'Karrin'
		WHEN '00540000002IocCAAS' THEN 'Michael'
		WHEN '00540000002Iuo4AAC' THEN 'JeffD'
		WHEN '00540000002JDUTAA4' THEN 'Anthony'
		WHEN '00540000002nfpCAAQ' THEN 'Alex'
		WHEN '00540000002nyKnAAI' THEN 'Paul'
		WHEN '00540000002pPwwAAE' THEN 'Alex'
		WHEN '00540000002r9XiAAI' THEN 'Sebrina'
		WHEN '00540000002IJzPAAW' THEN 'Platform'
		WHEN '00533000003X6quAAC' THEN 'BenL'
		WHEN '00533000003X6qzAAC' THEN 'MattS'
		WHEN '00533000003X6r4AAC' THEN 'MarkL'
		WHEN '00533000003UqH6AAK' THEN 'Lauren'
		WHEN '00540000002r9WkAAI' THEN 'SeanM'
		when '00533000003U0iyAAC' THEN 'Jana'
		WHEN '00533000003ft2kAAA' THEN 'Mason'
		WHEN '00533000003gDpNAAU' then 'Cassie'
		when '00533000003qkhHAAQ' THEN 'JeffDy' 
		when '00533000003g3CLAAY' then 'Glenn'	
		when '00533000003rC4mAAE' THEN 'JeffB'
		when '00533000003uQZ1AAM' then 'MikeBo'	
		when '00533000003w7shAAA' then 'Kari'
		when '00533000003w7swAAA' then 'Rich'	
		WHEN '00533000003y0SRAAY' THEN 'Julie'
		when '00533000003wglgAAA' then 'MattSu'
		WHEN '00533000003zZSYAA2' then 'Bill'
		when '00533000003zZSsAAM' THEN 'Keith'
		WHEN '00533000003zZSiAAM' THEN 'DavidS'
		WHEN '00533000003OTJPAA4' THEN 'RobR'
		WHEN '00533000003OTfaAAG' THEN 'AbbieA'
		WHEN '00533000003OTn0AAG' THEN 'PaulHa'
		WHEN '00533000003OTohAAG' THEN 'ChristineA'
		WHEN '00533000003OTp6AAG' THEN 'DanM'
		WHEN '00533000003OTcqAAG' THEN 'CourtniK'
	ELSE sfdcName
	END;
RETURN DBName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_SFDCNAMECONVERT","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SFDCNAMECONVERT`(sfdcName VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE DBName VARCHAR(200);
SET DBName = 
	CASE sfdcName
		WHEN 'Annika' THEN  '00540000002I1xUAAS' 
WHEN 'Brian' THEN '00540000002r9VrAAI'
WHEN 'Chad' THEN '00540000002HJjdAAG'
WHEN 'Colton' THEN '00540000002n53kAAA'
WHEN 'Dan' THEN '00540000003TBobAAG'
WHEN 'Daniel' THEN '00533000003ftWzAAI'
WHEN 'Darren' THEN '00540000001V66HAAS'
WHEN 'David' THEN '00540000002nyKdAAI'
WHEN 'Diana' THEN '00540000002pgcUAAQ'
WHEN 'DrewJ' THEN '00533000003Tx3EAAS'
WHEN 'Drew' THEN '00540000002qo7CAAQ'
WHEN 'Evan' THEN '00540000002pPx6AAE'
WHEN 'Gary' THEN '00540000002pD6KAAU'
WHEN 'Jeana' THEN '00540000002qWBaAAM'
WHEN 'Jennifer' THEN '00540000001V65sAAC'
WHEN 'Joel' THEN '00533000003UqHGAA0'
WHEN 'Kara' THEN '00540000002HFLrAAO'
WHEN 'Ken' THEN '00540000002IYVtAAO'
WHEN 'Kevin' THEN '00540000002qXdzAAE'
WHEN 'Lee' THEN '00533000003ftXEAAY'
WHEN 'Liz' THEN '00540000002n544AAA'
WHEN 'Maddie' THEN '00540000002pPwrAAE'
WHEN 'Matthew' THEN '00540000002oaOPAAY'
WHEN 'Max' THEN '00540000001TpXDAA0'
WHEN 'Nate' THEN '00533000003X6qpAAC'
WHEN 'Nick' THEN '00540000002q7KrAAI'
WHEN 'NickN' THEN '00540000002qXeiAAE'
WHEN 'PaulC' THEN '00533000003UqHLAA0'
WHEN 'Roman' THEN '00540000002orVSAAY'
WHEN 'Ryaire' THEN '00540000002HLLxAAO'
WHEN 'Ryan' THEN '00540000002pgcPAAQ'
WHEN 'SamH' THEN '00533000003ftX4AAI'
WHEN 'SarahB' THEN '00533000003U473AAC'
WHEN 'Sarah' THEN '00540000002FcZIAA0'
WHEN 'Sean' THEN '00540000002Fm0cAAC'
WHEN 'Steve' THEN '00540000002J7pjAAC'
WHEN 'Tyler' THEN '00540000001UFtyAAG'
WHEN 'Tom' THEN '00540000002qf8LAAQ'
WHEN 'Taryn' THEN '00540000001U30SAAS'
WHEN 'Desk' THEN '00540000001U6hoAAC'
WHEN 'Andrew Imhoff' THEN '00540000002nu18AAA'
WHEN 'Leads Uploader' THEN '00540000001UHNaAAO'
WHEN 'Marketo Integration' THEN '00540000002HoCGAA0'
WHEN 'Sam' THEN '00533000003Tx39AAC'
WHEN 'NickC' THEN '00533000003UaPiAAK'
WHEN 'Tim' THEN '00540000001U30XAAS'
WHEN 'AJ' THEN '00540000001UcZXAA0'
WHEN 'Taylor' THEN '00540000001UFlfAAG'
WHEN 'Ben' THEN '00540000001UFlVAAW'
WHEN 'Eric' THEN '00540000001UiO2AAK'
WHEN 'Joe' THEN '00540000002Fqe3AAC'
WHEN 'Jeff' THEN '00540000002GeyBAAS'
WHEN 'Chris' THEN '00540000002GeyGAAS'
WHEN 'ChrisK' THEN '00540000002HJwXAAW'
WHEN 'Karrin' THEN '00540000002I1xKAAS'
WHEN 'Michael' THEN '00540000002IocCAAS'
WHEN 'JeffD' THEN '00540000002Iuo4AAC'
WHEN 'Anthony' THEN '00540000002JDUTAA4'
WHEN 'Alex' THEN '00540000002nfpCAAQ'
WHEN 'Paul' THEN '00540000002nyKnAAI'
WHEN 'Alex' THEN '00540000002pPwwAAE'
WHEN 'Sebrina' THEN '00540000002r9XiAAI'
WHEN 'Platform' THEN '00540000002IJzPAAW'
WHEN 'BenL' THEN '00533000003X6quAAC'
WHEN 'MattS' THEN '00533000003X6qzAAC'
WHEN 'MarkL' THEN '00533000003X6r4AAC'
WHEN 'Lauren' THEN '00533000003UqH6AAK'
WHEN 'SeanM' THEN '00540000002r9WkAAI'
WHEN 'Jana' THEN '00533000003U0iyAAC'
WHEN 'Mason' THEN '00533000003ft2kAAA'
WHEN 'Cassie' THEN '00533000003gDpNAAU'
WHEN 'JeffDy' THEN '00533000003qkhHAAQ'
WHEN 'Glenn' THEN '00533000003g3CLAAY'
WHEN 'JeffB' THEN '00533000003rC4mAAE'
WHEN 'MikeBo' THEN '00533000003uQZ1AAM'	
WHEN 'Kari' THEN '00533000003w7shAAA'
WHEN 'Rich' THEN '00533000003w7swAAA'
WHEN 'Julie' THEN '00533000003y0SRAAY'
WHEN 'MattSu' THEN '00533000003wglgAAA'
WHEN 'Bill' THEN '00533000003zZSYAA2'
WHEN 'Keith' THEN '00533000003zZSsAAM'
WHEN 'DavidS' THEN '00533000003zZSiAAM'
WHEN 'RobR' THEN '00533000003OTJPAA4'
WHEN 'AbbieA' THEN '00533000003OTfaAAG'
WHEN 'PaulHa' THEN '00533000003OTn0AAG'
WHEN 'ChristineA' THEN '00533000003OTohAAG'
WHEN 'DanM' THEN '00533000003OTp6AAG'
WHEN 'CourtniK' THEN '00533000003OTcqAAG'
		
	ELSE sfdcName
	END;
RETURN DBName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"FitScoreV1","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `FitScoreV1`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code INT, wasShared INT) RETURNS tinyint(3)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;
SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X2 = CONCAT(X2a, ""_"", X2b);

SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X4 = wasShared;
IF dm = '0' THEN SET aP = '.001';

ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';

ELSEIF dm = '1'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'Intercept'),
	beta1 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'locale' AND  c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'sc_code' AND c.Variable = X2), 
	beta3 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'wasSharedToPriorToTrial'), 
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4))+1);
	
	SET aP = (CASE WHEN P > .1 THEN .1
				   WHEN P <.001 THEN .001
				   WHEN P IS NULL THEN .015 
				   ELSE P 
			  END); 
END IF;
SET fP = aP;
RETURN fP;
END","utf8","utf8_general_ci","utf8_general_ci"
"getAppBehaviorScoreV1","","CREATE DEFINER=`toddj`@`%` FUNCTION `getAppBehaviorScoreV1`(loginCount INT, eventLogCount INT, sheetCount INT, sharingCount INT,  reportCount INT, workspaceCount INT,
				isTeamTrial INT, accountRole varchar(100)) RETURNS int(11)
    DETERMINISTIC
BEGIN
DECLARE getBehaviorScore INT;
SET getBehaviorScore = 
	COALESCE(loginCount, 0) + 										
	COALESCE(eventLogCount / 100, 0)  +								
	(COALESCE(sheetCount, 0) * 5) +  								
	(COALESCE(sharingCount, 0) * 5)	+								
	(LEAST(COALESCE(sharingCount, 0), 1) * 15) +					
	(COALESCE(reportCount, 0) * 5)	+								
	(LEAST(COALESCE(reportCount, 0), 1) * 15) +						
	(greatest(COALESCE(workspaceCount - 1, 0), 0) * 5)	+			
	(greatest(LEAST(COALESCE(workspaceCount - 1, 0), 1), 0) * 15);	
	
IF isTeamTrial = 1 
	THEN SET getBehaviorScore = getBehaviorScore + 10;  
end if;  
IF isTeamTrial = 1 AND accountRole = ""Owner""  
	THEN SET getBehaviorScore = getBehaviorScore + 10;
END IF;
RETURN getBehaviorScore;
END","utf8","utf8_general_ci","utf8_general_ci"
"getFitScoreV2","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `getFitScoreV2`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code VARCHAR(50), wasShared INT, inserteduser tinyint, googleDrive tinyint, sharingCodes tinyint) RETURNS decimal(10,6)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE beta5 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;
DECLARE X5 INT;
DECLARE X6 INT;
DECLARE X7 INT;
SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X2 = CONCAT(X2a, ""_"", X2b);

SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X4 = wasShared;
SET X5 = inserteduser;
SET X6 = googleDrive;
SET X7 = sharingCodes;

IF (dm = 0 OR (dm = 1 AND (X6 = '1' OR X7 = '1'))) THEN SET aP = '.001';

ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';

ELSEIF dm = '1'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'Intercept'),
	beta1 = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'locale' AND  c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'sc_code' AND c.Variable = X2),
	beta3 = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'wasSharedToPriorToTrial'), 
	beta5 = (SELECT Coefficient FROM rpt_main_02.rpt_fitScoreModelV2 c WHERE c.Category = 'insertedByUser'), 
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))+1);
	 
	SET aP = (CASE WHEN P > .1 THEN .1
				   WHEN P <.001 THEN .001
				   WHEN P IS NULL THEN .015 
				   ELSE P 
			  END);
END IF;
SET fP = ROUND(aP*1000);
RETURN fP;
END","utf8","utf8_general_ci","utf8_general_ci"
"getFitScoreV21","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `getFitScoreV21`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code VARCHAR(50), wasShared INT, inserteduser tinyint, itemValue varchar(25)) RETURNS tinyint(3)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE beta5 DECIMAL (20,5);
DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);
DECLARE dm INT;
DECLARE X1 VARCHAR(50);
DECLARE X2a VARCHAR(50);
DECLARE X2b VARCHAR (50);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 INT;
DECLARE X5 INT;
DECLARE X6 INT;
SET dm = isOrgDomain;
SET X1 = 	(CASE 
				WHEN locale IS NULL THEN 'None' 
				ELSE locale
			END);
SET X2a = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X2b = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X2 = CONCAT(X2a, ""_"", X2b);

SET X3 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X4 = wasShared;
SET X5 = inserteduser;
SET X6 = itemValue;
IF (dm = 0 OR (X6 IN ('2','6','10','11') AND (X2a = 'None' or X2a = 'Blank'))) THEN SET aP = '.001';

ELSEIF dm = '1' AND (
(X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
)
THEN SET aP = '.001';

ELSEIF dm = '1'
THEN SET 
	betaZero = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'Intercept'),
	beta1 = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'locale' AND  c.Variable = X1),
	beta2 = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'sc_code' AND c.Variable = X2),
	beta3 = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
	beta4 = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'wasSharedToPriorToTrial'), 
	beta5 = (SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'insertedByUser'), 
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))+1);
	 
	SET aP = (CASE WHEN P > .1 THEN .1
				   WHEN P <.001 THEN .001
				   WHEN P IS NULL THEN .015 
				   ELSE P 
			  END);
END IF;
SET fP = ROUND(aP*1000);
RETURN fP;
END","utf8","utf8_general_ci","utf8_general_ci"
"MARKETO_ACCOUNT_ROLE","","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_ACCOUNT_ROLE`(paymentProfileID BIGINT, parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE accountRole VARCHAR(50);
SET accountRole = 
	CASE 
		WHEN paymentProfileID IS NOT NULL AND parentPaymentProfileID IS NULL THEN ""Individual""
        WHEN paymentProfileID IS NULL AND parentPaymentProfileID IS NULL THEN NULL
		WHEN orgMainContactUserID = userID THEN ""Owner""
		ELSE ""Member""
	END;
RETURN accountRole;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_BILLING_ADDRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_BILLING_ADDRESS`(address1 VARCHAR(50), address2 VARCHAR(50)) RETURNS varchar(101) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE billingAddress VARCHAR(101);
	SET billingAddress = TRIM(CONCAT(COALESCE(address1,"""") ,"" "", COALESCE(address2,"""")));  
RETURN billingAddress;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_CLEAN_IPADDRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_CLEAN_IPADDRESS`(ipAddress VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN
DECLARE cleanIpAddress VARCHAR(50);
	SET cleanIpAddress = 
		CASE WHEN INSTR (ipAddress, "","" ) > 0
			THEN SUBSTRING_INDEX(ipAddress, "","", 1) 
			ELSE ipAddress
		END;
RETURN cleanIpAddress;
END","utf8","utf8_general_ci","utf8_general_ci"
"MARKETO_EXTRACT_DOMAIN","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_EXTRACT_DOMAIN`(emailAddress VARCHAR(100)) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE domain VARCHAR(100);
	SET domain = SUBSTR(emailAddress, INSTR(emailAddress,'@') + 1);
RETURN domain;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_LAST_NAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LAST_NAME`(lastName VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE processedLastName VARCHAR(50);
SET processedLastName = 
	CASE WHEN lastName IS NULL 	THEN NULL 
		WHEN lastName = """" 		THEN NULL 
		WHEN lastName = "" "" 	THEN NULL 
		ELSE lastName
  END;
RETURN processedLastName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"MARKETO_RECURRING_BILLING_CANCELLED","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_RECURRING_BILLING_CANCELLED`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT, usersPaymentFlags tinyint, parentPaymentFlags tinyint) RETURNS tinyint(1)
    DETERMINISTIC
BEGIN
DECLARE isBillingCancelled TINYINT(1);
DECLARE paymentFlags TINYINT(1);
SET paymentFlags = 
	CASE 
		WHEN  parentPaymentProfileID IS NULL THEN usersPaymentFlags  	
		WHEN orgMainContactUserID = userID THEN parentPaymentFlags  	
		ELSE usersPaymentFlags								
	END;
	
set isBillingCancelled = 
	case 
		when paymentFlags & 16 = 16 then 1
		else 0
	end;
		
RETURN isBillingCancelled;
END","utf8","utf8_general_ci","utf8_general_ci"
"MARKETO_UPGRADE_WIZARD_PROGRESS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_UPGRADE_WIZARD_PROGRESS`(ViewedConfirmPage TINYINT, PayPalComplete TINYINT, PayPalStart TINYINT, ViewedStep3 TINYINT, ViewedStep2 TINYINT, ViewedStep1 TINYINT) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN
DECLARE friendlyProgressValue VARCHAR(100);
SET friendlyProgressValue = 
	CASE 
		WHEN ViewedConfirmPage > 0 THEN ""Complete""
		WHEN PayPalComplete > 0 THEN ""PayPalComplete""
		WHEN PayPalStart > 0 THEN ""PayPalStart""
		WHEN ViewedStep3 > 0 THEN ""Step3""
		WHEN ViewedStep2 > 0 THEN ""Step2""
		WHEN ViewedStep1 > 0 THEN ""Step1""
		ELSE """" 
	END;
RETURN friendlyProgressValue;
END","utf8","utf8_general_ci","utf8_general_ci"
"regex_replace","","CREATE DEFINER=`toddj`@`%` FUNCTION `regex_replace`(pattern VARCHAR(1000),replacement VARCHAR(1000),original VARCHAR(1000)) RETURNS varchar(1000) CHARSET utf8
    DETERMINISTIC
BEGIN 
 DECLARE temp VARCHAR(1000); 
 DECLARE ch VARCHAR(1); 
 DECLARE i INT;
 SET i = 1;
 SET temp = '';
 IF original REGEXP pattern THEN 
  loop_label: LOOP 
   IF i>CHAR_LENGTH(original) THEN
    LEAVE loop_label;  
   END IF;
   SET ch = SUBSTRING(original,i,1);
   IF NOT ch REGEXP pattern THEN
    SET temp = CONCAT(temp,ch);
   ELSE
    SET temp = CONCAT(temp,replacement);
   END IF;
   SET i=i+1;
  END LOOP;
 ELSE
  SET temp = original;
 END IF;
 RETURN temp;
END","utf8","utf8_general_ci","utf8_general_ci"
"SMARTSHEET_ACCOUNTTYPE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_ACCOUNTTYPE`(accountType TINYINT) RETURNS varchar(50) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE accountTypeName VARCHAR(50);
SET accountTypeName = 
  CASE accountType
     WHEN 1 THEN ""Standard""
     WHEN 2 THEN ""Multi-user""
     WHEN 3 THEN ""Organization""
     ELSE CONCAT('Account Type ', accountType)
  END;
return accountTypeName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_AUTHRESULT","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_AUTHRESULT`(AuthType SMALLINT) RETURNS varchar(50) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE AuthResultName VARCHAR(50);
SET AuthResultName = 
	CASE AuthType
		WHEN 1 THEN ""SUCCESS""
		WHEN 0 THEN ""No error""
		WHEN -1 THEN ""INVALID_USER_OR_PASSWORD""
		WHEN -2 THEN ""LOGIN_TICKET_DOES_NOT_EXIST""
		WHEN -3 THEN ""DUPLICATE_LOGIN_TICKETS""
		WHEN -4 THEN ""LOGIN_TICKET_CORRUPT""
		WHEN -5 THEN ""LOGIN_TICKET_NOT_VALID""
		WHEN -6 THEN ""ACCOUNT_LOCKEDOUT""
		WHEN -7 THEN ""REUSED_REQUEST_DIGEST""
		WHEN -8 THEN ""INVALID_REQUEST_DIGEST""
		WHEN -9 THEN ""NO_MATCHING_USER""
		WHEN -10 THEN ""INVALID_EMAIL_FORMAT""
		WHEN -11 THEN ""USER_NOT_CONFIRMED""
		WHEN -12 THEN ""ACCOUNT_BLOCKED""
		WHEN -13 THEN ""INVALID_UPDATE_TICKET""
		WHEN -14 THEN ""ACCOUNT_LOCKEDOUT_MAX""
		WHEN -15 THEN ""BLOCKED_IP_ADDRESS""
		WHEN -16 THEN ""SAML_REQUIRED_FOR_AUTH""
		WHEN -17 THEN ""ACCESS_TOKEN_REQUIRED""
		WHEN -18 THEN ""ACCESS_TOKEN_EXPIRED""
		WHEN -19 THEN ""Rest User Credentials""
		WHEN -20 THEN ""INVALID_ASSUME_USER""
		WHEN -21 THEN ""ASSUME_USER_REQUIRED""
		WHEN -22 THEN ""LEGACY_PASSWORD_FORMAT""
		ELSE CONCAT ('AuthResult ', AuthType)
	END;
return AuthResultName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSERBUCKET","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_BROWSERBUCKET`(userAgent NVARCHAR(255)) RETURNS varchar(20) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE browserBucket VARCHAR(20);
  SET browserBucket = 
 	CASE
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Firefox') 	THEN ""Firefox""
		WHEN INSTR(userAgent,'MSIE') 	THEN ""IE""
		WHEN INSTR(userAgent,'Trident') THEN ""IE""
		WHEN INSTR(userAgent,'Chrome') 	THEN ""Chrome""
		WHEN INSTR(userAgent,'Safari') 	THEN ""Safari""
		WHEN INSTR(userAgent,'Opera') 	THEN ""Opera""
		WHEN INSTR(userAgent,'Camino') 	THEN ""Camino""
		WHEN userAgent LIKE ('%Mac OS%Smartsheet%') THEN ""Native iOS App""
		WHEN userAgent LIKE ('%Android%Smartsheet%') THEN ""Native Android App""
		ELSE ""Other Browser""
	END;
RETURN browserBucket;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSERDEVICE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_BROWSERDEVICE`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE browserDevice VARCHAR(50);
  SET browserDevice = 
	CASE  
		WHEN INSTR(userAgent,'myTouch') 	THEN ""myTouch""
		WHEN INSTR(userAgent,'Nexus') 		THEN ""Nexus""
		WHEN INSTR(userAgent,'LG') 			THEN ""LG""
		WHEN INSTR(userAgent,'SGH') 		THEN ""SAMSUNG-SGH""
		WHEN INSTR(userAgent,'APA9292KT') 	THEN ""HTC-EVO (APA9292KT)""
		WHEN INSTR(userAgent,'ADR6300') 	THEN ""HTC-Incredible (ADR6300)""
		WHEN INSTR(userAgent,'HTC') 		THEN ""HTC""
		WHEN INSTR(userAgent,'Treo') 		THEN ""Treo""
		WHEN INSTR(userAgent,'Droid2') 		THEN ""Droid2""
		WHEN INSTR(userAgent,'DroidX') 		THEN ""DroidX""
		WHEN INSTR(userAgent,' Droid') 		THEN ""Droid""
		WHEN INSTR(userAgent,'Xoom') 		THEN ""Xoom""
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Nokia') 		THEN ""Nokia""
		WHEN INSTR(userAgent,'PlayBook') 	THEN ""Playbook""
		WHEN INSTR(userAgent,'iPod') 		THEN ""iPod""			
		WHEN INSTR(userAgent,'iPhone') 		THEN ""iPhone""
		WHEN INSTR(userAgent,'iPad') 		THEN ""iPad""
		WHEN INSTR(userAgent,'Mobile') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Mini') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Fennec') 		THEN ""Mobile Device""
		WHEN INSTR(userAgent,'Android') 	THEN ""Mobile Device""
		WHEN INSTR(userAgent,'pixi') 		THEN ""pixi""
		ELSE ""Computer""
	END;
return browserDevice;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_BROWSERNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_BROWSERNAME`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE browserName VARCHAR(50);
  SET browserName = 
	CASE
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0.1%') THEN ""iOS App 1.0.1"" 
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0%') THEN ""iOS App 1.0""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.1%') THEN ""iOS App 1.1""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.2%') THEN ""iOS App 1.2""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.3%') THEN ""iOS App 1.3""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.4%') THEN ""iOS App 1.4""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.5%') THEN ""iOS App 1.5""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 2.0%') THEN ""iOS App 2.0""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 2.1%') THEN ""iOS App 2.1""
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet%') THEN ""iOS App v?""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.0%') THEN ""Android App 1.0""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.1%') THEN ""Android App 1.1""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.2%') THEN ""Android App 1.2""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.3%') THEN ""Android App 1.3""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.4%') THEN ""Android App 1.4""
		WHEN userAgent LIKE ('%Android%Smartsheet 1.5%') THEN ""Android App 1.5""
		WHEN userAgent LIKE ('%Android%Smartsheet 2.0%') THEN ""Android App 2.0""
		WHEN userAgent LIKE ('%Android%Smartsheet%') THEN ""Android App v?""			
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Firefox/10') 	THEN ""Firefox 10""
		WHEN INSTR(userAgent,'Firefox/11') 	THEN ""Firefox 11""
		WHEN INSTR(userAgent,'Firefox/12') 	THEN ""Firefox 12""
		WHEN INSTR(userAgent,'Firefox/13') 	THEN ""Firefox 13""
		WHEN INSTR(userAgent,'Firefox/14') 	THEN ""Firefox 14""
		WHEN INSTR(userAgent,'Firefox/15') 	THEN ""Firefox 15""
		WHEN INSTR(userAgent,'Firefox/16') 	THEN ""Firefox 16""
		WHEN INSTR(userAgent,'Firefox/17') 	THEN ""Firefox 17""
		WHEN INSTR(userAgent,'Firefox/18') 	THEN ""Firefox 18""
		WHEN INSTR(userAgent,'Firefox/19') 	THEN ""Firefox 19""
		WHEN INSTR(userAgent,'Firefox/20') 	THEN ""Firefox 20""
		WHEN INSTR(userAgent,'Firefox/21') 	THEN ""Firefox 21""
		WHEN INSTR(userAgent,'Firefox/22') 	THEN ""Firefox 22""
		WHEN INSTR(userAgent,'Firefox/23') 	THEN ""Firefox 23""
		WHEN INSTR(userAgent,'Firefox/24') 	THEN ""Firefox 24""
		WHEN INSTR(userAgent,'Firefox/25') 	THEN ""Firefox 25""
		WHEN INSTR(userAgent,'Firefox/26') 	THEN ""Firefox 26""
		WHEN INSTR(userAgent,'Firefox/27') 	THEN ""Firefox 27""
		WHEN INSTR(userAgent,'Firefox/28') 	THEN ""Firefox 28""
		WHEN INSTR(userAgent,'Firefox/29') 	THEN ""Firefox 29""
		WHEN INSTR(userAgent,'Firefox/30') 	THEN ""Firefox 30""
		WHEN INSTR(userAgent,'Firefox/31') 	THEN ""Firefox 31""
		WHEN INSTR(userAgent,'Firefox/32') 	THEN ""Firefox 32""
		WHEN INSTR(userAgent,'Firefox/33') 	THEN ""Firefox 33""
		WHEN INSTR(userAgent,'Firefox/34') 	THEN ""Firefox 34""
		WHEN INSTR(userAgent,'Firefox/35') 	THEN ""Firefox 35""
		WHEN INSTR(userAgent,'Firefox/36') 	THEN ""Firefox 36""
		WHEN INSTR(userAgent,'Firefox/37') 	THEN ""Firefox 37""
		WHEN INSTR(userAgent,'Firefox/38') 	THEN ""Firefox 38""
		WHEN INSTR(userAgent,'Firefox/39') 	THEN ""Firefox 39""
		WHEN INSTR(userAgent,'Firefox/40') 	THEN ""Firefox 40""
		WHEN INSTR(userAgent,'Firefox/41') 	THEN ""Firefox 41""
		WHEN INSTR(userAgent,'Firefox/42') 	THEN ""Firefox 42""
		WHEN INSTR(userAgent,'Firefox/43') 	THEN ""Firefox 43""
		WHEN INSTR(userAgent,'Firefox/44') 	THEN ""Firefox 44""
		WHEN INSTR(userAgent,'Firefox/45') 	THEN ""Firefox 45""
		WHEN INSTR(userAgent,'Firefox/46') 	THEN ""Firefox 46""
		WHEN INSTR(userAgent,'Firefox/47') 	THEN ""Firefox 47""
		WHEN INSTR(userAgent,'Firefox/48') 	THEN ""Firefox 48""
		WHEN INSTR(userAgent,'Firefox/49') 	THEN ""Firefox 40""
		WHEN INSTR(userAgent,'Firefox/50') 	THEN ""Firefox 50""
		WHEN INSTR(userAgent,'Firefox/1') 	THEN ""Firefox 1""
		WHEN INSTR(userAgent,'Firefox/2') 	THEN ""Firefox 2""
		WHEN INSTR(userAgent,'Firefox/3') 	THEN ""Firefox 3""
		WHEN INSTR(userAgent,'Firefox/4') 	THEN ""Firefox 4""
		WHEN INSTR(userAgent,'Firefox/5') 	THEN ""Firefox 5""
		WHEN INSTR(userAgent,'Firefox/6') 	THEN ""Firefox 6""
		WHEN INSTR(userAgent,'Firefox/7') 	THEN ""Firefox 7""
		WHEN INSTR(userAgent,'Firefox/8') 	THEN ""Firefox 8""
		WHEN INSTR(userAgent,'Firefox/9') 	THEN ""Firefox 9""
		WHEN INSTR(userAgent,'Firefox') 	THEN ""Firefox v?""
		WHEN INSTR(userAgent,'MSIE 4.') 	THEN ""IE 4""
		WHEN INSTR(userAgent,'MSIE 5.') 	THEN ""IE 5""
		WHEN INSTR(userAgent,'MSIE 6.') 	THEN ""IE 6""
		WHEN INSTR(userAgent,'MSIE 7.') 	THEN ""IE 7""
		WHEN INSTR(userAgent,'MSIE 8.') 	THEN ""IE 8""
		WHEN INSTR(userAgent,'MSIE 9.') 	THEN ""IE 9""
		WHEN INSTR(userAgent,'MSIE 10.')  THEN ""IE 10""
		WHEN userAgent LIKE '%Trident%rv:11%' THEN ""IE 11""
		WHEN userAgent LIKE '%Trident%rv:12%' THEN ""IE 12""
		WHEN userAgent LIKE '%Trident%rv:13%' THEN ""IE 13""
		WHEN userAgent LIKE '%Trident%rv:14%' THEN ""IE 14""
		WHEN userAgent LIKE '%Trident%rv:15%' THEN ""IE 15""
		WHEN INSTR(userAgent,'Chrome/10') 	THEN ""Chrome 10""
		WHEN INSTR(userAgent,'Chrome/11') 	THEN ""Chrome 11""
		WHEN INSTR(userAgent,'Chrome/12') 	THEN ""Chrome 12""
		WHEN INSTR(userAgent,'Chrome/13') 	THEN ""Chrome 13""
		WHEN INSTR(userAgent,'Chrome/14') 	THEN ""Chrome 14""
		WHEN INSTR(userAgent,'Chrome/15') 	THEN ""Chrome 15""
		WHEN INSTR(userAgent,'Chrome/16') 	THEN ""Chrome 16""
		WHEN INSTR(userAgent,'Chrome/17') 	THEN ""Chrome 17""
		WHEN INSTR(userAgent,'Chrome/18') 	THEN ""Chrome 18""
		WHEN INSTR(userAgent,'Chrome/19') 	THEN ""Chrome 19""
		WHEN INSTR(userAgent,'Chrome/20') 	THEN ""Chrome 20""
		WHEN INSTR(userAgent,'Chrome/21') 	THEN ""Chrome 21""
		WHEN INSTR(userAgent,'Chrome/22') 	THEN ""Chrome 22""
		WHEN INSTR(userAgent,'Chrome/23') 	THEN ""Chrome 23""
		WHEN INSTR(userAgent,'Chrome/24') 	THEN ""Chrome 24""
		WHEN INSTR(userAgent,'Chrome/25') 	THEN ""Chrome 25""
		WHEN INSTR(userAgent,'Chrome/26') 	THEN ""Chrome 26""
		WHEN INSTR(userAgent,'Chrome/27') 	THEN ""Chrome 27""
		WHEN INSTR(userAgent,'Chrome/28') 	THEN ""Chrome 28""
		WHEN INSTR(userAgent,'Chrome/29') 	THEN ""Chrome 29""
		WHEN INSTR(userAgent,'Chrome/30') 	THEN ""Chrome 30""
		WHEN INSTR(userAgent,'Chrome/31') 	THEN ""Chrome 31""
		WHEN INSTR(userAgent,'Chrome/32') 	THEN ""Chrome 32""
		WHEN INSTR(userAgent,'Chrome/33') 	THEN ""Chrome 33""
		WHEN INSTR(userAgent,'Chrome/34') 	THEN ""Chrome 34""
		WHEN INSTR(userAgent,'Chrome/35') 	THEN ""Chrome 35""
		WHEN INSTR(userAgent,'Chrome/36') 	THEN ""Chrome 36""
		WHEN INSTR(userAgent,'Chrome/37') 	THEN ""Chrome 37""
		WHEN INSTR(userAgent,'Chrome/38') 	THEN ""Chrome 38""
		WHEN INSTR(userAgent,'Chrome/39') 	THEN ""Chrome 39""
		WHEN INSTR(userAgent,'Chrome/40') 	THEN ""Chrome 40""
		WHEN INSTR(userAgent,'Chrome/41') 	THEN ""Chrome 41""
		WHEN INSTR(userAgent,'Chrome/42') 	THEN ""Chrome 42""
		WHEN INSTR(userAgent,'Chrome/43') 	THEN ""Chrome 43""
		WHEN INSTR(userAgent,'Chrome/44') 	THEN ""Chrome 44""
		WHEN INSTR(userAgent,'Chrome/45') 	THEN ""Chrome 45""
		WHEN INSTR(userAgent,'Chrome/46') 	THEN ""Chrome 46""
		WHEN INSTR(userAgent,'Chrome/47') 	THEN ""Chrome 47""
		WHEN INSTR(userAgent,'Chrome/48') 	THEN ""Chrome 48""
		WHEN INSTR(userAgent,'Chrome/49') 	THEN ""Chrome 49""
		WHEN INSTR(userAgent,'Chrome/50') 	THEN ""Chrome 50""
		WHEN INSTR(userAgent,'Chrome/1') 	THEN ""Chrome 1""  
		WHEN INSTR(userAgent,'Chrome/2') 	THEN ""Chrome 2""
		WHEN INSTR(userAgent,'Chrome/3') 	THEN ""Chrome 3""
		WHEN INSTR(userAgent,'Chrome/4') 	THEN ""Chrome 4""
		WHEN INSTR(userAgent,'Chrome/5') 	THEN ""Chrome 5""
		WHEN INSTR(userAgent,'Chrome/6') 	THEN ""Chrome 6""
		WHEN INSTR(userAgent,'Chrome/7') 	THEN ""Chrome 7""
		WHEN INSTR(userAgent,'Chrome/8') 	THEN ""Chrome 8""
		WHEN INSTR(userAgent,'Chrome/9') 	THEN ""Chrome 9""
		WHEN INSTR(userAgent,'Chrome') 	THEN ""Chrome v?""
		WHEN userAgent LIKE ('%3._ Mobile%Safari%') THEN ""Mobile Safari 3"" 
		WHEN userAgent LIKE ('%3._._ Mobile%Safari%') THEN ""Mobile Safari 3"" 
		WHEN userAgent LIKE ('%4._ Mobile%Safari%')  THEN ""Mobile Safari 4"" 
		WHEN userAgent LIKE ('%4._._ Mobile%Safari%') THEN ""Mobile Safari 4"" 
		WHEN userAgent LIKE ('%5._ Mobile%Safari%') THEN ""Mobile Safari 5"" 
		WHEN userAgent LIKE ('%5._._ Mobile%Safari%') THEN ""Mobile Safari 5"" 
		WHEN userAgent LIKE ('%6._ Mobile%Safari%') THEN ""Mobile Safari 6"" 
		WHEN userAgent LIKE ('%6.___ Mobile%Safari%') THEN ""Mobile Safari 6"" 
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 7"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 7"" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 8"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 8"" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN ""Mobile Safari 9"" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN ""Mobile Safari 9"" 	
		WHEN userAgent LIKE ('%Mobile%Safari%') THEN ""Mobile Safari v?"" 
		WHEN userAgent LIKE ('%3._ Safari%') 	THEN ""Safari 3"" 
		WHEN userAgent LIKE ('%3._._ Safari%') 	THEN ""Safari 3"" 
		WHEN userAgent LIKE ('%4._ Safari%') 	THEN ""Safari 4"" 
		WHEN userAgent LIKE ('%4._._ Safari%') 	THEN ""Safari 4"" 
		WHEN userAgent LIKE ('%5._ Safari%') 	THEN ""Safari 5"" 
		WHEN userAgent LIKE ('%5._._ Safari%') 	THEN ""Safari 5"" 
		WHEN userAgent LIKE ('%6._ Safari%') 	THEN ""Safari 6"" 
		WHEN userAgent LIKE ('%6._._ Safari%') 	THEN ""Safari 6"" 
		WHEN userAgent LIKE ('%6._._.____ Safari%') 	THEN ""Safari 6"" 	
		WHEN userAgent LIKE ('%7._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%7._._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%7._._._ Safari%') 	THEN ""Safari 7"" 
		WHEN userAgent LIKE ('%8._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%8._._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%8._._._ Safari%') 	THEN ""Safari 8"" 
		WHEN userAgent LIKE ('%9._ Safari%') 	THEN ""Safari 9"" 
		WHEN userAgent LIKE ('%9._._ Safari%') 	THEN ""Safari 9"" 
		WHEN userAgent LIKE ('%9._._._ Safari%') 	THEN ""Safari 9"" 
		WHEN INSTR(userAgent,'Safari/7534.48.3') 	THEN ""Safari 5""
		WHEN INSTR(userAgent,'Safari/8536.25') 	THEN ""Safari 6""
		WHEN userAgent LIKE ('%Safari%') 	THEN ""Safari v?"" 
		WHEN INSTR(userAgent,'Opera/8') 	THEN ""Opera 8""
		WHEN INSTR(userAgent,'Opera 8') 	THEN ""Opera 8""
		WHEN INSTR(userAgent,'Opera/9') 	THEN ""Opera 9""
		WHEN INSTR(userAgent,'Opera 9') 	THEN ""Opera 9""
		WHEN INSTR(userAgent,'Opera/10') 	THEN ""Opera 10""
		WHEN INSTR(userAgent,'Opera 10') 	THEN ""Opera 10""
		WHEN INSTR(userAgent,'Opera/11') 	THEN ""Opera 11""
		WHEN INSTR(userAgent,'Opera 11') 	THEN ""Opera 11""
		WHEN INSTR(userAgent,'Opera/12') 	THEN ""Opera 12""
		WHEN INSTR(userAgent,'Opera 12') 	THEN ""Opera 12""
		WHEN INSTR(userAgent,'Opera') 	THEN ""Opera v?""
		WHEN INSTR(userAgent,'Camino') 	THEN ""Camino""
		WHEN INSTR(userAgent,'Mobile') THEN ""Other Mobile Browser""
		ELSE ""Other Browser""
	END;
RETURN browserName;
END","utf8","utf8_general_ci","utf8_general_ci"
"SMARTSHEET_BROWSEROS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_BROWSEROS`(userAgent NVARCHAR(255)) RETURNS varchar(20) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE browserOS VARCHAR(20);
  SET browserOS = 
	CASE
		WHEN INSTR(userAgent,'sunOS') 		THEN ""sunOS""
		WHEN INSTR(userAgent,'FreeBSD') 	THEN ""FreeBSD""
		WHEN INSTR(userAgent,'openBSD') 	THEN ""openBSD""
		WHEN INSTR(userAgent,'SymbianOS') 	THEN ""SymbianOS""
		WHEN INSTR(userAgent,'Symbian') 	THEN ""SymbianOS""
		WHEN INSTR(userAgent,'webOS') 		THEN ""webOS""
		WHEN INSTR(userAgent,'BlackBerry') 	THEN ""BlackBerry""
		WHEN INSTR(userAgent,'Android') 	THEN ""Android""
		WHEN INSTR(userAgent,'Linux') 		THEN ""Linux""
		WHEN INSTR(userAgent,'Windows CE') 	THEN ""Windows CE""
		WHEN INSTR(userAgent,'Windows Phone OS') 	THEN ""Windows Phone OS""
		WHEN INSTR(userAgent,'Windows') 	THEN ""Windows""
		WHEN INSTR(userAgent,'OS 3') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 4') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 5') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 6') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 7') 		THEN ""iOS""
		WHEN INSTR(userAgent,'OS 8') 		THEN ""iOS""
		WHEN INSTR(userAgent,'iPhone OS') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iPad') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iPhone') 	THEN ""iOS""
		WHEN INSTR(userAgent,'iOS') 	THEN ""iOS""
		WHEN INSTR(userAgent,'Mac') 		THEN ""Mac""
		WHEN INSTR(userAgent,'crOS ') 		THEN ""Chrome OS"" 
		ELSE ""Other OS""
	END;
RETURN browserOS;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_CHURN_SCORE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_CHURN_SCORE`(paymentTerm varchar(50), product varchar(50), weekNum INT, teamSize INT, FACTOR1 INT, FACTOR2 INT, FACTOR3 INT ) RETURNS int(11)
BEGIN

DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE P DECIMAL(20,10);

DECLARE X1 INT;
DECLARE X2 INT;
DECLARE X3 INT;


DECLARE willChurn INT;

DECLARE pT varchar(50);
DECLARE prod varchar(50);
DECLARE wN INT;
DECLARE tS INT;
DECLARE wC INT;

SET pT = paymentTerm, prod = product, wN=weekNum, ts=teamSize;



IF pT = 'Monthly' AND prod = 'Basic' AND wN = 5
THEN
SET betaZero = 1.5276, beta1 = -0.42473, beta2 = -0.95765, beta3 = -0.13272, X1 = FACTOR1, X2=FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;




ELSEIF
pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS > 10
THEN
SET X1 = FACTOR1;
SET P = CASE WHEN X1 = 0 THEN .70 ELSE 0 END;
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;


ELSEIF
pT = 'Annual' AND prod = 'Team' AND wN = 8 AND tS > 10
THEN
SET X1 = FACTOR1;
SET P = CASE WHEN X1 = 0 THEN .70 ELSE 0 END;
SET wC = CASE WHEN P >= .70 THEN 1 ELSE 0 END;





ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 1 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 2.529, beta1 = -1.969, beta2 = -1.773, beta3 = -0.882, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;


ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 3.056, beta1 = -1.67, beta2 = -2.242, beta3 = -1.008, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;


ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 20 AND tS BETWEEN 3 AND 5
THEN
SET betaZero = 3.1146, beta1 = -2.7529, beta2 = -1.5029, beta3 = -0.0507, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;





ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 4 AND tS BETWEEN 6 AND 10
THEN 
SET betaZero = 2.8936, beta1 = -0.00239, beta2 = -1.7831, beta3 = -1.7043, X1 = FACTOR1, X2 = FACTOR2, X3 = FACTOR3,
P=EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;


ELSEIF pT = 'Monthly' AND prod = 'Team' AND wN = 20 AND tS BETWEEN 6 AND 10
THEN 
SET betaZero = 4.7011, beta1 = -3.4382, beta2 = -0.00083, beta3= -2.1459, X1 = FACTOR1, X2 = FACTOR2,
P=EXP(betaZero+(beta1*X1)+(beta2*X2))/(EXP(betaZero+(beta1*X1)+(beta2*X2)+(beta3*X3))+1);
SET wC = CASE WHEN P >= .575 THEN 1 ELSE 0 END;


ELSE
SET betaZero = 0, beta1 = 0, beta2 = 0, beta3 = 0, X1 = 0, X2 = 0, X3 = 0, P = 0, wC = 0;
END IF;

SET willChurn = wC;


RETURN willChurn;


END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_COUNTRYNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_COUNTRYNAME`(countryCode VARCHAR(25)) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE countryName VARCHAR(50);
SET countryName = 
  CASE countryCode
	WHEN 'AF' THEN 'Afghanistan'
	WHEN 'Afghanistan' THEN 'Afghanistan'
	WHEN 'AX' THEN 'Aland Islands'
	WHEN 'AL' THEN 'Albania'
	WHEN 'DZ' THEN 'Algeria'
	WHEN 'AS' THEN 'American Samoa'
	WHEN 'AD' THEN 'Andorra'
	WHEN 'AO' THEN 'Angola'
	WHEN 'AI' THEN 'Anguilla'
	WHEN 'AQ' THEN 'Antarctica'
	WHEN 'AG' THEN 'Antigua and Barbuda'
	WHEN 'AR' THEN 'Argentina'
	WHEN 'AM' THEN 'Armenia'
	WHEN 'AW' THEN 'Aruba'
	WHEN 'AU' THEN 'Australia'
	WHEN 'AUST' THEN 'Australia'
	WHEN 'AUSTRALIA' THEN 'Australia'
	WHEN 'AT' THEN 'Austria'
	WHEN 'Osterreich' THEN 'Austria'
	WHEN 'AZ' THEN 'Azerbaidjan'
	WHEN 'BS' THEN 'Bahamas'
	WHEN 'BH' THEN 'Bahrain'
	WHEN 'BD' THEN 'Bangladesh'
	WHEN 'BB' THEN 'Barbados'
	WHEN 'BY' THEN 'Belarus'
	WHEN 'BE' THEN 'Belgium'
	WHEN 'Belgium' THEN 'Belgium'
	WHEN 'BZ' THEN 'Belize'
	WHEN 'BJ' THEN 'Benin'
	WHEN 'BM' THEN 'Bermuda'
	WHEN 'BT' THEN 'Bhutan'
	WHEN 'BO' THEN 'Bolivia'
	WHEN 'BQ' THEN 'Bonaire'
	WHEN 'BA' THEN 'Bosnia-Herzegovina'
	WHEN 'BW' THEN 'Botswana'
	WHEN 'Botswana' THEN 'Botswana'
	WHEN 'BV' THEN 'Bouvet Island'
	WHEN 'BR' THEN 'Brazil'
	WHEN 'Brasil' THEN 'Brazil'
	WHEN 'Brazil' THEN 'Brazil'
	WHEN 'IO' THEN 'British Indian Ocean Territory'
	WHEN 'BN' THEN 'Brunei Darussalam'
	WHEN 'BG' THEN 'Bulgaria'
	WHEN 'Bulgaria' THEN 'Bulgaria'
	WHEN 'BF' THEN 'Burkina Faso'
	WHEN 'BI' THEN 'Burundi'
	WHEN 'KH' THEN 'Cambodia'
	WHEN 'CM' THEN 'Cameroon'
	WHEN 'CA' THEN 'Canada'
	WHEN 'Canada' THEN 'Canada'
	WHEN 'Newfoundland' THEN 'Canada'
	WHEN 'CV' THEN 'Cape Verde'
	WHEN 'KY' THEN 'Cayman Islands'
	WHEN 'Cayman Islands' THEN 'Cayman Islands'
	WHEN 'CF' THEN 'Central African Republic'
	WHEN 'TD' THEN 'Chad'
	WHEN 'CL' THEN 'Chile'
	WHEN 'Chile' THEN 'Chile'
	WHEN 'CN' THEN 'China'
	WHEN 'China' THEN 'China'
	WHEN 'CX' THEN 'Christmas Island'
	WHEN 'CC' THEN 'Cocos Islands'
	WHEN 'CO' THEN 'Colombia'
	WHEN 'Colombia' THEN 'Colombia'
	WHEN 'KM' THEN 'Comoros'
	WHEN 'CD' THEN 'Congo'
	WHEN 'CG' THEN 'Congo'
	WHEN 'CK' THEN 'Cook Islands'
	WHEN 'CR' THEN 'Costa Rica'
	WHEN 'Costa Rica' THEN 'Costa Rica'
	WHEN 'CI' THEN ""Cote D'Ivoire""
	WHEN 'HR' THEN 'Croatia'
	WHEN 'CU' THEN 'Cuba'
	WHEN 'CW' THEN 'Curacao'
	WHEN 'CY' THEN 'Cyprus'
	WHEN 'CZ' THEN 'Czech Republic'
	WHEN 'Czech Republic' THEN 'Czech Republic'
	WHEN 'DK' THEN 'Denmark'
	WHEN 'Denmark' THEN 'Denmark'
	WHEN 'DJ' THEN 'Djibouti'
	WHEN 'DM' THEN 'Dominica'
	WHEN 'DO' THEN 'Dominican Republic'
	WHEN 'Republica Dominicana' THEN 'Dominican Republic'
	WHEN 'EC' THEN 'Ecuador'
	WHEN 'Ecuador' THEN 'Ecuador'
	WHEN 'EG' THEN 'Egypt'
	WHEN 'SV' THEN 'El Salvador'
	WHEN 'GQ' THEN 'Equatorial Guinea'
	WHEN 'ER' THEN 'Eritrea'
	WHEN 'EE' THEN 'Estonia'
	WHEN 'Estonia' THEN 'Estonia'
	WHEN 'ET' THEN 'Ethiopia'
	WHEN 'FK' THEN 'Falkland Islands'
	WHEN 'FO' THEN 'Faroe Islands'
	WHEN 'FJ' THEN 'Fiji'
	WHEN 'Fiji' THEN 'Fiji'
	WHEN 'FI' THEN 'Finland'
	WHEN 'FR' THEN 'France'
	WHEN 'FRANCE' THEN 'France'
	WHEN 'GF' THEN 'French Guyana'
	WHEN 'PF' THEN 'French Polynesia'
	WHEN 'TF' THEN 'French Southern Territories'
	WHEN 'GA' THEN 'Gabon'
	WHEN 'GM' THEN 'Gambia'
	WHEN 'GE' THEN 'Georgia'
	WHEN 'DE' THEN 'Germany'
	WHEN 'Deutschland' THEN 'Germany'
	WHEN 'Germany' THEN 'Germany'
	WHEN 'GH' THEN 'Ghana'
	WHEN 'GI' THEN 'Gibraltar'
	WHEN 'GR' THEN 'Greece'
	WHEN 'GREECE' THEN 'Greece'
	WHEN 'GL' THEN 'Greenland'
	WHEN 'GD' THEN 'Grenada'
	WHEN 'GP' THEN 'Guadeloupe'
	WHEN 'GU' THEN 'Guam'
	WHEN 'GT' THEN 'Guatemala'
	WHEN 'GUATEMALA' THEN 'Guatemala'
	WHEN 'GG' THEN 'Guernsey'
	WHEN 'GN' THEN 'Guinea'
	WHEN 'GW' THEN 'Guinea-Bissau'
	WHEN 'GY' THEN 'Guyana'
	WHEN 'HT' THEN 'Haiti'
	WHEN 'HM' THEN 'Heard and McDonald Islands'
	WHEN 'HN' THEN 'Honduras'
	WHEN 'HK' THEN 'Hong Kong'
	WHEN 'HU' THEN 'Hungary'
	WHEN 'Hungary' THEN 'Hungary'
	WHEN 'IS' THEN 'Iceland'
	WHEN 'IN' THEN 'India'
	WHEN 'India' THEN 'India'
	WHEN 'ID' THEN 'Indonesia'
	WHEN 'INDONESIA' THEN 'Indonesia'
	WHEN 'IR' THEN 'Iran'
	WHEN 'IQ' THEN 'Iraq'
	WHEN 'IE' THEN 'Ireland'
	WHEN 'Ireland' THEN 'Ireland'
	WHEN 'IM' THEN 'Isle of Man'
	WHEN 'IL' THEN 'Israel'
	WHEN 'Israel' THEN 'Israel'
	WHEN 'IT' THEN 'Italy'
	WHEN 'Italia' THEN 'Italy'
	WHEN 'ITALY' THEN 'Italy'
	WHEN 'JM' THEN 'Jamaica'
	WHEN 'JP' THEN 'Japan'
	WHEN 'Japan' THEN 'Japan'
	WHEN 'JE' THEN 'Jersey'
	WHEN 'JO' THEN 'Jordan'
	WHEN 'KZ' THEN 'Kazakhstan'
	WHEN 'KE' THEN 'Kenya'
	WHEN 'KI' THEN 'Kiribati'
	WHEN 'KP' THEN 'Korea'
	WHEN 'KW' THEN 'Kuwait'
	WHEN 'KG' THEN 'Kyrgyzstan'
	WHEN 'LA' THEN 'Laos'
	WHEN 'LV' THEN 'Latvia'
	WHEN 'Latvia' THEN 'Latvia'
	WHEN 'LB' THEN 'Lebanon'
	WHEN 'Lebanon' THEN 'Lebanon'
	WHEN 'LS' THEN 'Lesotho'
	WHEN 'LR' THEN 'Liberia'
	WHEN 'LY' THEN 'Libya'
	WHEN 'Libya' THEN 'Libyan Arab Jamahiriya'
	WHEN 'LI' THEN 'Liechtenstein'
	WHEN 'LT' THEN 'Lithuania'
	WHEN 'Lithuania' THEN 'Lithuania'
	WHEN 'LU' THEN 'Luxembourg'
	WHEN 'MO' THEN 'Macau'
	WHEN 'MK' THEN 'Macedonia'
	WHEN 'MG' THEN 'Madagascar'
	WHEN 'MW' THEN 'Malawi'
	WHEN 'MY' THEN 'Malaysia'
	WHEN 'Malaysia' THEN 'Malaysia'
	WHEN 'MV' THEN 'Maldives'
	WHEN 'ML' THEN 'Mali'
	WHEN 'MT' THEN 'Malta'
	WHEN 'MH' THEN 'Marshall Islands'
	WHEN 'MQ' THEN 'Martinique'
	WHEN 'MR' THEN 'Mauritania'
	WHEN 'MU' THEN 'Mauritius'
	WHEN 'YT' THEN 'Mayotte'
	WHEN 'MX' THEN 'Mexico'
	WHEN '77710' THEN 'Mexico'
	WHEN 'Mexico' THEN 'Mexico'
	WHEN 'Mexico D.F (Mexico)' THEN 'Mexico'
	WHEN 'FM' THEN 'Micronesia'
	WHEN 'MD' THEN 'Moldavia'
	WHEN 'MC' THEN 'Monaco'
	WHEN 'MN' THEN 'Mongolia'
	WHEN 'ME' THEN 'Montenegro'
	WHEN 'MS' THEN 'Montserrat'
	WHEN 'MA' THEN 'Morocco'
	WHEN 'Morocco' THEN 'Morocco'
	WHEN 'MZ' THEN 'Mozambique'
	WHEN 'MM' THEN 'Myanmar'
	WHEN 'NA' THEN 'Namibia'
	WHEN 'NR' THEN 'Nauru'
	WHEN 'NP' THEN 'Nepal'
	WHEN 'NL' THEN 'Netherlands'
	WHEN 'Netherlands' THEN 'Netherlands'
	WHEN 'The Netherlands' THEN 'Netherlands'
	WHEN 'NC' THEN 'New Caledonia'
	WHEN 'NZ' THEN 'New Zealand'
	WHEN 'New Zealand' THEN 'New Zealand'
	WHEN 'NI' THEN 'Nicaragua'
	WHEN 'NE' THEN 'Niger'
	WHEN 'NG' THEN 'Nigeria'
	WHEN 'NU' THEN 'Niue'
	WHEN 'NF' THEN 'Norfolk Island'
	WHEN 'MP' THEN 'Northern Mariana Islands'
	WHEN 'NO' THEN 'Norway'
	WHEN 'Norway' THEN 'Norway'
	WHEN 'OM' THEN 'Oman'
	WHEN 'ZZ' THEN 'Other'
	WHEN 'PK' THEN 'Pakistan'
	WHEN 'PW' THEN 'Palau'
	WHEN 'PS' THEN 'Palestine'
	WHEN 'PA' THEN 'Panama'
	WHEN 'Panama' THEN 'Panama'
	WHEN 'PG' THEN 'Papua New Guinea'
	WHEN 'PY' THEN 'Paraguay'
	WHEN 'Paraguay' THEN 'Paraguay'
	WHEN 'PE' THEN 'Peru'
	WHEN 'Peru' THEN 'Peru'
	WHEN 'PH' THEN 'Philippines'
	WHEN 'PN' THEN 'Pitcairn Islands'
	WHEN 'PL' THEN 'Poland'
	WHEN 'Capgemini' THEN 'Poland'
	WHEN 'Krakow' THEN 'Poland'
	WHEN 'Poland' THEN 'Poland'
	WHEN 'Polska' THEN 'Poland'
	WHEN 'PT' THEN 'Portugal'
	WHEN 'Portugal' THEN 'Portugal'
	WHEN 'PR' THEN 'Puerto Rico'
	WHEN 'QA' THEN 'Qatar'
	WHEN 'RE' THEN 'Reunion'
	WHEN 'RO' THEN 'Romania'
	WHEN 'Romania' THEN 'Romania'
	WHEN 'RU' THEN 'Russia'
	WHEN 'Russia' THEN 'Russia'
	WHEN 'Russian Federation' THEN 'Russia'
	WHEN 'RW' THEN 'Rwanda'
	WHEN 'BL' THEN 'Saint Barthelemy'
	WHEN 'SH' THEN 'Saint Helena'
	WHEN 'KN' THEN 'Saint Kitts and Nevis Anguilla'
	WHEN 'LC' THEN 'Saint Lucia'
	WHEN 'MF' THEN 'Saint Martin'
	WHEN 'SX' THEN 'Saint Martin'
	WHEN 'VC' THEN 'Saint Vincent and Grenadines'
	WHEN 'WS' THEN 'Samoa'
	WHEN 'SM' THEN 'San Marino'
	WHEN 'ST' THEN 'Sao Tome and Principe'
	WHEN 'SA' THEN 'Saudi Arabia'
	WHEN 'SN' THEN 'Senegal'
	WHEN 'RS' THEN 'Serbia'
	WHEN 'SC' THEN 'Seychelles'
	WHEN 'SL' THEN 'Sierra Leone'
	WHEN 'SG' THEN 'Singapore'
	WHEN 'SK' THEN 'Slovakia'
	WHEN 'Slovakia' THEN 'Slovakia'
	WHEN 'SI' THEN 'Slovenia'
	WHEN 'Slovenia' THEN 'Slovenia'
	WHEN 'SB' THEN 'Solomon Islands'
	WHEN 'SO' THEN 'Somalia'
	WHEN 'ZA' THEN 'South Africa'
	WHEN 'RSA' THEN 'South Africa'
	WHEN 'South Africa' THEN 'South Africa'
	WHEN 'GS' THEN 'South Georgia and the South Sandwich Islands'
	WHEN 'KR' THEN 'South Korea'
	WHEN 'SS' THEN 'South Sudan'
	WHEN 'ES' THEN 'Spain'
	WHEN 'Espana' THEN 'Spain'
	WHEN 'Spain' THEN 'Spain'
	WHEN 'LK' THEN 'Sri Lanka'
	WHEN 'PM' THEN 'St. Pierre and Miquelon'
	WHEN 'SD' THEN 'Sudan'
	WHEN 'SR' THEN 'Suriname'
	WHEN 'SJ' THEN 'Svalbard and Jan Mayen Islands'
	WHEN 'SZ' THEN 'Swaziland'
	WHEN 'SE' THEN 'Sweden'
	WHEN 'Sweden' THEN 'Sweden'
	WHEN 'CH' THEN 'Switzerland'
	WHEN 'Switzerland' THEN 'Switzerland'
	WHEN 'SY' THEN 'Syrian Arab Republic'
	WHEN 'TW' THEN 'Taiwan'
	WHEN 'Taiwan' THEN 'Taiwan'
	WHEN 'TJ' THEN 'Tajikistan'
	WHEN 'TZ' THEN 'Tanzania'
	WHEN 'Tanzania' THEN 'Tanzania'
	WHEN 'TH' THEN 'Thailand'
	WHEN 'Thailand' THEN 'Thailand'
	WHEN 'TL' THEN 'Timor-Leste'
	WHEN 'TG' THEN 'Togo'
	WHEN 'TK' THEN 'Tokelau'
	WHEN 'TO' THEN 'Tonga'
	WHEN 'TT' THEN 'Trinidad and Tobago'
	WHEN 'TN' THEN 'Tunisia'
	WHEN 'TR' THEN 'Turkey'
	WHEN 'Turkey' THEN 'Turkey'
	WHEN 'TM' THEN 'Turkmenistan'
	WHEN 'TC' THEN 'Turks and Caicos Islands'
	WHEN 'TV' THEN 'Tuvalu'
	WHEN 'UG' THEN 'Uganda'
	WHEN 'UA' THEN 'Ukraine'
	WHEN 'AE' THEN 'United Arab Emirates'
	WHEN 'UAE' THEN 'United Arab Emirates'
	WHEN 'GB' THEN 'United Kingdom'
	WHEN 'England' THEN 'United Kingdom'
	WHEN 'United Kingdom' THEN 'United Kingdom'
	WHEN 'UK' THEN 'United Kingdom'
	WHEN 'US' THEN 'United States'
	WHEN 'United States' THEN 'United States'
	WHEN 'United States of America' THEN 'United States'
	WHEN 'USA' THEN 'United States'
	WHEN 'UM' THEN 'United States Minor Outlying Islands'
	WHEN 'UY' THEN 'Uruguay'
	WHEN 'Uruguay' THEN 'Uruguay'
	WHEN 'UZ' THEN 'Uzbekistan'
	WHEN 'VU' THEN 'Vanuatu'
	WHEN 'VA' THEN 'Vatican City'
	WHEN 'VE' THEN 'Venezuela'
	WHEN 'VN' THEN 'Vietnam'
	WHEN 'VG' THEN 'Virgin Islands'
	WHEN 'VI' THEN 'Virgin Islands'
	WHEN 'WF' THEN 'Wallis and Futuna'
	WHEN 'EH' THEN 'Western Sahara'
	WHEN 'YE' THEN 'Yemen'
	WHEN 'ZM' THEN 'Zambia'
	WHEN 'ZW' THEN 'Zimbabwe'
     ELSE CONCAT('Country ', countryCode)
  END;
RETURN countryName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_BUCKET","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_GET_BUCKET`(source NVARCHAR(255)) RETURNS varchar(20) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE GET_BUCKET VARCHAR(20);
  SET GET_BUCKET = 
 	CASE
		
		WHEN source IN (""Sharing"", ""Referrals"", ""Application"") 	
			THEN ""Viral""
			
		
		WHEN source IN (""Affiliate"", ""Campaign"", ""Email Campaigns"", ""General Awareness"", ""Free Directory"", ""SEO"", ""Social"", ""Website Links"",""Blog Posse"", ""Website"")  	
			THEN ""Other""		
			
		
		WHEN source IN (""Partner"", ""App Store"",""Reseller"")  	
			THEN ""Partner""
			
		
		WHEN source IN (""Paid Placement"", ""PPC - Foreign Language"", ""PPC - English - International"", ""PPC"",""Paid - Social"",""Paid - Email"")
		THEN ""Paid""
		ELSE ""--unknown bucket--""
	END;
RETURN GET_BUCKET;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_QUERY_PARAMETER","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_GET_QUERY_PARAMETER`(url NVARCHAR(500), parameterName NVARCHAR(50)) RETURNS varchar(500) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE parameterValue VARCHAR(500);
DECLARE parameterNameLength BIGINT;
DECLARE startPosition BIGINT;
DECLARE endPosition BIGINT;

  SET parameterValue = NULL;
  
  
  SET startPosition = LOCATE(CONCAT(""?"", parameterName, ""=""), url);

  
 IF startPosition = 0 THEN
	SET startPosition = LOCATE(CONCAT(""&"", parameterName, ""=""), url);
  END IF;
  
  
  IF startPosition > 0 THEN
  
	  SET parameterNameLength = LENGTH(parameterName) + 2;  
		
	  SET endPosition = LOCATE(""&"" , url, startPosition + 1);
	  	
	  IF endPosition > 0 THEN
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength, endPosition - (startPosition + parameterNameLength));
	  ELSE
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength);
	  END IF;
  END IF;
  
RETURN parameterValue;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_GET_SOURCE","NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_GET_SOURCE`(subSource NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE GET_SOURCE VARCHAR(50);
  SET GET_SOURCE = 
 	CASE
		
		WHEN subSource IN (""Signup with Sharing Tracking Codes"", ""Signup Inserted by Smartsheet User"") 	
			THEN ""Sharing""
		WHEN subSource IN (""Web Forms - Powered BY Smartsheet"", ""Published Sheet - Powered by Smartsheet"")  	
			THEN ""Application""	
		WHEN subSource IN (""Mail Link"", ""My Smartsheet Referral"", ""Referral Rewards"")  	
			THEN ""Referrals""	
			
		
		WHEN subSource IN (""Amazon Web Services"", ""AWS Marketplace"", ""Brad Egeland"", ""Crowdsourcing.org"", ""Sitepoint"", ""Sage Non-Profit"", ""Office Arrow"", ""VA Network"", ""Veronica Conway"",
							""Jott"", ""Success Connections"", ""smallbiztrends.com"", ""A Clayton's Secretary"", ""Officebundle.com"", 
							""Caroline Melville Society of Virtual Assistants"", ""Caroline Melville Virtually Sorted"",
							""Baird Consulting"", ""Biz Recipes"", ""OnlineBizU"", ""Assistant Match"", ""Ki-Work"", ""Tradeshow Coach"", ""Regina Minger"",""Kindle"",
							""Stack Overflow"", ""VANetworking.com"")  	
			THEN ""Affiliate""		
		WHEN subSource IN (""TJ McCue"", ""NAPS"")  	
			THEN ""Campaign""	
		WHEN subSource IN (""Puget Sound PMI"", ""Solution Center Brochure"", ""Solution Center"")
			THEN ""General Awareness""
		WHEN subSource IN (""Email"")  	
			THEN ""Email Campaigns""	
		WHEN subSource IN (""Smartsheet Search"", ""Smartsheet Search (Not Provided)"" , ""Organic Search"",
							""Branded PPC (Google)"", ""Branded PPC (Bing)"" , 
							""Direct Navigation"", ""Distributed Container"", ""SEO"", ""SEO (Not Provided)"", ""Integrated Content Pages"")  	
			THEN ""Website""
		WHEN subSource IN (""Google Templates"", ""thesmallbusinessweb.com"")  	
			THEN ""Free Directory""		
		WHEN subSource IN (""YouTube (unpaid)"", ""Twitter (unpaid)"", ""Social Media (generic)"", ""Facebook (unpaid)"", ""LinkedIn (unpaid)"", ""Google+ (unpaid)"", ""Social Media Coordinator - Keri"",
		""Slideshare.net"", ""LinkedIn remarketing platform"")  	
			THEN ""Social""		
		WHEN subSource IN (""External Source Links"")  	
			THEN ""Website Links""	
		
		WHEN subSource IN (""Apple App Store"", ""Android App Store"", ""Google Play Store"")  	
			THEN ""App Store""	
		WHEN subSource IN ( ""Elizabeth Harrin (blog posse)"", ""Robert Kelly (blog posse)"", ""Lindsay Scott (blog posse)"")  	
			THEN ""Blog Posse""	
		
		WHEN subSource IN (""Google App. Marketplace"", ""Chrome Web Store"", ""Intuit"", ""Zimbra"", ""Salesforce.com"", ""Box"", ""Cloud Alliance for Google Apps"", 
							""Centrify"", ""Google Drive - New File"", ""Google Drive - Import"",""Zapier"",""Dropbox"",""123 Contact Form"",""Marketo Launchpoint"",""Docusign"",
							""MailChimp"",""Harvest"",""Evernote"",""Amazon Mechanical Turk"",""AppGuru"",""Backupify"",""Bitium"",""Easy Insight"",
							""OneLogin"",""PingOne"",""Klipfolio"",""Tools4ever"",""Okta"",""Third Party Authorization Flow"",""BetterCloud"",
							""Smartsheet Merge (Google Docs Add-on)"",""Smartsheet Forms (Google Forms Add-on)"",""Microsoft"",
							""Microsoft Office 365/Azure Marketplace"",""Google general"",""Microsoft Office Store"", ""Box"", ""Microsoft Referral"", ""Microsoft Referral 0365 Launcher"",
							""Evernote Integration"",""OutlookApp Integration"", ""School of Bookkeeping"",""Microsoft Teams signup"",""Project Vision Dynamics USA"",
                            ""SoftwareONE Chile"", ""SoftwareONE Brazil"", ""SoftwareONE Argentina"", ""eSource Mexico"", ""Comparex Germany"", ""Searce India"", 
                            ""Softline Malaysia"", ""Softline Thailand"", ""Softline Vietnam"", ""Softline Korea"", ""SoftwareONE USA"", ""Mbizer Singapore"", ""Six Step Australia"", 
                            ""Cardinal Consulting Australia"", ""SoftwareONE Uruguay"", ""SoftwareOne UK"", ""SoftwareOne France"", ""SoftwareONE Japan"", ""Gmail AddOn Integration"",
                            ""Quip Integration"", ""Comparex India"", ""Softline India"", ""Outlook Add-In""
					)  	
			THEN ""Partner""
		WHEN subSource IN (""Cloud Sherpa"",""gPartner"",""Business Cloud"",""Ciruseo"",""Softline India"",""Cyberco Procore Connector"") 
			THEN ""Reseller""
		
		
		WHEN subSource IN (""Serchen"", ""The Deck"", ""PM Sherpa"", ""GetApp.com"", ""Geekwire"", ""USA Today"", ""Pac NW Soccer"",""Spiceworks"",
		 ""Wave"", ""Capterra"", ""FindtheBest Paid"", ""Project-Management.com"", ""Projects At Work"")
			THEN ""Paid Placement""
			
		WHEN subSource IN ( ""Spanish - Google Search Test"", ""Spanish - Google Display Network Test"",
							""Spanish (US) - Google Display"", ""Spanish (US) - Google Search"",
							""Spanish (Mexico) - Google Display"", ""Spanish (Mexico) - Google Search"",
							""Spanish (Spain) - Google Display"", ""Spanish (Spain) - Google Search"",
							""Spanish (Other) - Google Display"", ""Spanish (Other) - Google Search"",
							""Spanish (Argentina)  Google Display"", ""Spanish (Argentina)  Google Search"",
							""Spanish (Peru)  Google Display"", ""Spanish (Peru)  Google Search"",
							""Spanish (Venezuela)  Google Display"", ""Spanish (Venezuela)  Google Search"",
							""Spanish (Chile)  Google Display"", ""Spanish (Chile)  Google Search"",
							""Spanish (Guatemala)  Google Display"", ""Spanish (Guatemala)  Google Search"",
							""Spanish (Ecuador)  Google Display"", ""Spanish (Ecuador)  Google Search"",
							
							""French (Tier 1) - Google Display"", ""French (Tier 1) - Google Search"",
							""French (Tier 2) - Google Display"", ""French (Tier 2) - Google Search"",
							
							""Portuguese (Brazil) - Google Display"", ""Portuguese (Brazil) - Google Search"",
							""Portuguese (Portugal) - Google Display"", ""Portuguese (Portugal) - Google Search"",
											
							""German - Google Display"", ""German - Google Search"",
							
							""Italian - Google Display"", ""Italian - Google Search"",
							""Bing Search - French"",
							""Bing Search - German"",
							""Bing Search - Portuguese (Brazil)"",
							""Bing Search - Portuguese (Portugal)"",
							""Bing Search - Spanish"",
							""Bing Search - Italian"",
							""Google Search - Russian"",
							""Yandex (paid)"",
							""Google Search - Japanese"",				 
							""Yahoo Japan"",
							""French - Display - Interest Targeted"",
							""Japanese - Display - Interest Targeted"",
							""Google Display Japan"",
							""Russian - Display - Interest Targeted"",
							""Russian - Display"",
							""German - Display - Interest Targeted"",
							""Italian - Display - Interest Targeted"",
							""Portuguese (Brazil) - Display - Interest Targeted"",
							""Portuguese (Portugal) - Display - Interest Targeted"",
							""Spanish - Display - Interest Targeted"")
			THEN ""PPC - Foreign Language""
			
		WHEN subSource IN ( ""Bing Search (Canada)"", ""Bing Search (Singapore)"", ""Bing Search (UK)"",
		
							""South Africa - Google Display"", ""South Africa - Google Search"", 
							""Israel - Google Display"", ""Israel - Google Search"",
							""Saudi Arabia - Google Display"", ""Saudi Arabia - Google Search"",
				
							""Belgium - Google Display"", ""Belgium - Google Search"",
							""Finland - Google Display"", ""Finland - Google Search"",
							""Denmark - Google Display"", ""Denmark - Google Search"",
							""Netherlands - Google Display"", ""Netherlands - Google Search"",
							""Norway - Google Display"", ""Norway - Google Search"",
							""Sweden - Google Display"", ""Sweden - Google Search"",
							""Germany - Google Display"", ""Germany - Google Search"",
							""France - Google Display"", ""France - Google Search"", 
							""Spain - Google Display"", ""Spain - Google Search"",
							""Italy - Google Display"", ""Italy - Google Search"",
							
							""Turkey - Google Display"", ""Turkey - Google Search"",
							""Russia - Google Display"", ""Russia - Google Search"",
							
							""Hong Kong - Google Display"", ""Hong Kong - Google Search"",
							""Singapore - Google Display"", ""Singapore - Google Search"",
							""Japan - Google Display"", ""Japan - Google Search"",
							""South Korea - Google Display"", ""South Korea - Google Search"",
							""China - Google Display"", ""China - Google Search"",
							
							""Mexico - Google Display"", ""Mexico - Google Search"",
							
							""Brazil - Google Display"", ""Brazil - Google Search"",
							""Columbia - Google Display"", ""Columbia - Google Search"",
							""Argentina - Google Display"", ""Argentina - Google Search"",
							
							""India - Google Display"", ""India - Google Search"",
							""Indonesia - Google Display"", ""Indonesia - Google Search"",
							""Malaysia - Google Display"", ""Malaysia - Google Search"",
							""Philippines - Google Display"", ""Philippines - Google Search"",
							
							""_Display - Managed Placements - Tier 1 International"", ""_Display - Managed Placements - Tier 2 International"",
							""_Google Search - International - Tier 1"", ""_Google Search - International - Tier 2"",
							""Google Display International - Text Ads"", ""Google Display International - Image Ads"",
							""Bing Search - International - Tier 1"",
							""Google Search Companion Marketing (International)"",
							""Yahoo Search INT"",
                            ""YouTube Promoted Videos (INT)"",
                            ""Google Display - In-Market Audience (INT)"")
			THEN ""PPC - English - International""
			
		WHEN subSource IN ( 
				""_Google Search"", 
				""_Google Display Network"",	
				 ""Yahoo"",
				 ""Ask.com"",
				 ""_Google Search"",
				 ""Go2Web20.net"",
				""_Bing Search"",
				""_Bing Content Network"",
				""Ad Ready Network"",
				""Facebook"",
				""LinkedIn"",
				""LinkedIn InMail"",
				""LinkedIn International (paid)"",
				""_Google Display (iPad only)"",
				""_Google Search (iPad only)"",									
				""Google Remarketing (Paid Visitors)"", ""Google Remarketing (Non-paid Visitors)"", ""Google Remarketing (Nurture Signups)"",			
				""Bing Search (French - Canada)"", ""Bing Search (French - France)"",
				""Youtube (promoted videos)"",
				""_Display - Managed Placements"",
				""Google Adwords Sitelinks"",
				""Google Mobile Search (iphone)"", ""Google Mobile Search (non-iphone)"",
				""Enterprise Display Test - Spreadsheet Hell - Desktop"", ""Enterprise Display Test - Spreadsheet Hell - Mobile"",
				""BlueKai - (Google)"", ""Similar Audiences - (Google)"",
				""Gmail Ads"",
				""Gmail Ads - International"",
				""Google Display - Interest Targeted"",
				""Video for Adwords"",
 				""Google Business Category Display"",
 				""Seattle GEO Target (Google Search)"",
				""Seattle GEO Target (Bing Search)"",
				""Seattle GEO Target (Google Display Image)"",
				""Seattle GEO Target (Bing Content)"",
				""Seattle GEO Target (Google Text Display)"",
				""Google Display - Image Ads"",
				""Google Display - Text Ads"",
				""Google Search Companion Marketing"",
				""Similar Audiences (Google) - International"",
				""Google Display - Interest Targeted (International)"",
				""Bing Display - Text Ads (USA)"",
				""Bing Display - Text Ads (English Not USA)"",
				""Bing Sitelinks"",
				""Display - Select Keyword"",
				""Display - Select Keyword (International)"",
				""Yahoo Display - Native Ads"",
				""GetApp Paid"",
				""Yahoo Search"",
				""DoubleClick Campaign Manager"",
				""DoubleClick Interest Targeted"",
				""DoubleClick Context Matched"",
				""DoubleClick Manual Placement"",
                ""Google Display - In-Market Audience"",
                ""StackOverflow"",
                ""Instagram(Paid)"",
                ""Techcrunch"",
                ""G2 Crowd (paid)"",
                ""Google Product Listing Ads"",
                ""Google Adwords US FL"",
                ""Google Adwords UK""
				 )
		THEN ""PPC""
		WHEN subsource IN (""Twitter (paid)"",""Facebook (paid) - International EN"") THEN ""Paid - Social""
		WHEN subsource IN (""DemandMetric.com"",""ProjectManagers.net"",""ProjectsAtWork.com"",""ProjectManagement.com"") THEN ""Paid - Email""
		ELSE ""--unknown source--""
	END;
RETURN GET_SOURCE;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_LOGINSTATUS","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_LOGINSTATUS`(loginStatus TINYINT) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE LoginStatusName VARCHAR(20);
SET LoginStatusName = 
	CASE loginStatus
		WHEN 2 THEN ""Authenticated""
		WHEN 0 THEN ""Unresolved""
		ELSE CONCAT ('LoginStatus ', loginStatus)
	END;
return LoginStatusName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_LOGINTYPENAME","NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_LOGINTYPENAME`(loginType TINYINT) RETURNS varchar(50) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE loginTypeName VARCHAR(50);
SET loginTypeName = 
	CASE loginType
		WHEN 1 THEN ""Drupal Login (deprecated)""
		WHEN 2 THEN ""Login Form""
		WHEN 3 THEN ""Request Digest (deprecated)""
		WHEN 4 THEN ""Login Ticket Drupal (deprecated)""
		WHEN 5 THEN ""OPS Monitor (deprecated)""
		WHEN 6 THEN ""OPS Console (deprecated)""
		WHEN 7 THEN ""Login Ticket Auto Signin""
		WHEN 8 THEN ""Login Ticket Remember Me""
		WHEN 9 THEN ""API""
		WHEN 10 THEN ""Login Ticket Password Reset""
		WHEN 11 THEN ""Update Request""
		WHEN 12 THEN ""Quick Add""
		WHEN 13 THEN ""Editable Publish""
		WHEN 14 THEN ""OpenID""
		WHEN 15 THEN ""Read-only Publish""
		WHEN 16 THEN ""Intuit Workplace (deprecated)""
		WHEN 17 THEN ""Ops Console OpenID (deprecated)""
		WHEN 18 THEN ""Gadget Session Exchange""
		WHEN 19 THEN ""SSO Salesforce""
		WHEN 20 THEN ""SSO SAML""
		WHEN 21 THEN ""Rest User Credentials""
		WHEN 22 THEN ""Rest Access Token""
		WHEN 23 THEN ""Login Ticket Remember Me Mobile""
		WHEN 24 THEN ""API""
		WHEN 25 THEN ""Rest Auth Code""
		WHEN 26 THEN ""Rest Refresh Token""
		WHEN 27 THEN ""Rest Unauthenticated""
		WHEN 28 THEN ""Rest Google Auth""
		WHEN 29 THEN ""Google OAuth2""
		WHEN 30 THEN ""Google OAuth2""
        WHEN 31 THEN ""Signup""
		WHEN 32 THEN ""MS Azure AD""
		WHEN 33 THEN ""Rest Google JWT Auth""
		when 34 THEN ""Web Form""
        WHEN 35 THEN ""Download Ticket""
        WHEN 36 THEN ""Rest Azure JWT Auth""
        WHEN 37 THEN ""Rest Azure Ticket Auth""
        WHEN 38 THEN ""Approval Request""
		ELSE CONCAT ('login ', loginType)
	END;
return loginTypeName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_MONTH","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_MONTH`(startDateTime DATETIME) RETURNS int(11)
    DETERMINISTIC
BEGIN
DECLARE A INT;
SET A = 
(SELECT monthSequence FROM rpt_main_02.ref_months WHERE startDateTime >= startMonth AND startDateTime <= endMonth);
RETURN A;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTSTARTDATETIME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`tstohs`@`%` FUNCTION `SMARTSHEET_PAYMENTSTARTDATETIME`(
                                             nextPaymentDate              DATETIME,
                                             paymentTerm                  TINYINT,
                                             actualLastPaymentDate        DATETIME,
											 haveClean                    BOOLEAN,
                                             paymentStartDateTime         DATETIME,
                                             promoCode                    VARCHAR(50),
                                             paymentProfileInsertDateTime DATETIME) RETURNS datetime
    DETERMINISTIC
BEGIN
		DECLARE currentDateTime DATETIME;
		DECLARE newNextPaymentDate DATETIME;
        DECLARE paymentStartDateTimeClean DATETIME;
        SET currentDateTime = NOW();
        IF haveClean THEN 
			SET paymentStartDateTimeClean = paymentStartDateTime;
        ELSE
			SET paymentStartDateTimeClean =
				CASE paymentStartDateTime > '2008-09-30'
					WHEN 1 THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
					ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
				END;
		END IF;

        SET newNextPaymentDate =
            CASE
                WHEN nextPaymentDate > currentDateTime THEN nextPaymentDate
                ELSE
                    CASE
                        WHEN paymentTerm = 12 THEN
                            CASE
                                WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_FORMAT(CONCAT(year(currentDateTime)+1, '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)), '%Y-%m-%d 00:00:00')
                                WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR) > currentDateTime
                                    THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
                                ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
                            END
                        WHEN paymentTerm IN (1, 6) THEN
                            CASE
                                WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
                                WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
                                WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
                                    THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                    rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
                                WHEN paymentTerm = 1
                                    THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                                   rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
                                ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
                            END
                        ELSE null
                    END
            END;
        RETURN newNextPaymentDate;
        END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTTERM","NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PAYMENTTERM`(paymentTerm TINYINT) RETURNS varchar(50) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE paymentTermName VARCHAR(50);
SET paymentTermName = 
  CASE paymentTerm
     WHEN 1 THEN ""Monthly""
     WHEN 6 THEN ""Semi-Annual""
     WHEN 12 THEN ""Annual""
     WHEN 24 THEN ""Two Year""
     WHEN 36 THEN ""Three Year""
     ELSE CONCAT('Payment Term ', paymentTerm)
  END;
RETURN paymentTermName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PAYMENTTYPE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTTYPE`(paymentType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN
DECLARE paymentTypeName VARCHAR(50);
SET paymentTypeName = 
  CASE paymentType
     WHEN 0 THEN ""None""
     WHEN 1 THEN ""Credit Card""
     WHEN 2 THEN ""Bill To""
     WHEN 3 THEN ""Custom""
     WHEN 4 THEN ""Promo""
     WHEN 5 THEN ""Paid by Other""
     WHEN 6 THEN ""Third Party""
     WHEN 7 THEN ""Third Party - By Other""
     WHEN 8 THEN ""Paypal""
     WHEN 9 THEN ""Developer""
     WHEN 10 THEN ""Bill To App""
     ELSE CONCAT('Payment Type ', paymentType)
  END;
return paymentTypeName;
END","utf8","utf8_general_ci","utf8_general_ci"
"SMARTSHEET_PRODUCTNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTNAME`(productID INT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE productName VARCHAR(50);
SET productName = 
  CASE productID
     WHEN -1 THEN NULL
     WHEN 0 THEN ""Cancelled""
     WHEN 1 THEN ""Trial""
     WHEN 2 THEN ""Free""
     WHEN 3 THEN ""Basic""
     WHEN 4 THEN ""Advanced""
     WHEN 5 THEN ""Premium""
     WHEN 7 THEN ""Team""
     WHEN 8 THEN ""Team Plus""
     WHEN 6 THEN ""Enterprise_Legacy""
     WHEN 9 THEN ""Student""
     WHEN 10 THEN ""Business""
     WHEN 11 THEN ""Enterprise""
     ELSE CONCAT('Product ', productID)
  END;
RETURN productName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTNAMECONVERT","","CREATE DEFINER=`tstohs`@`%` FUNCTION `SMARTSHEET_PRODUCTNAMECONVERT`(productName varchar(30)) RETURNS int(11)
BEGIN
DECLARE productID INT;
SET productID =
	CASE productName
	 WHEN NULL THEN -1
     WHEN '' THEN -1
     WHEN ""Cancelled"" THEN 0
     WHEN ""Trial"" THEN 1
     WHEN ""Free"" THEN 2
     WHEN ""Basic"" THEN 3
     WHEN ""Advanced"" THEN 4
     WHEN ""Premium"" THEN 5
     WHEN ""Team"" THEN 7
     WHEN ""Team Plus"" THEN 8
     WHEN ""Enterprise_Legacy"" THEN 6
     WHEN ""Student"" THEN 9
     WHEN ""Business"" THEN 10
     WHEN ""Enterprise"" THEN 11
     ELSE -1
	END;
RETURN productID;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTRANK","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTRANK`(productID INT) RETURNS tinyint(4)
    DETERMINISTIC
BEGIN
DECLARE productRank TINYINT;
SET productRank = 
  CASE productID
     WHEN 0 THEN 1 
     WHEN 1 THEN 2 
     WHEN 2 THEN 3 
     WHEN 9 THEN 4 
     WHEN 3 THEN 5 
     WHEN 4 THEN 6 
     WHEN 5 THEN 7 
     WHEN 7 THEN 8 
     WHEN 8 THEN 9 
     WHEN 10 THEN 10 
     WHEN 6 THEN 11 
     WHEN 11 THEN 12 
     ELSE -1
  END;
RETURN productRank;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_PRODUCTRANKCONVERT","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTRANKCONVERT`(productRank TINYINT) RETURNS tinyint(4)
    DETERMINISTIC
BEGIN
DECLARE productRankConvert TINYINT;
SET productRank = 
  CASE productRank
     WHEN 1 THEN 0
     WHEN 2 THEN 1
     WHEN 3 THEN 2
     WHEN 4 THEN 9 
     WHEN 5 THEN 3
     WHEN 6 THEN 4
     WHEN 7 THEN 5
     WHEN 8 THEN 7
     WHEN 9 THEN 8
     WHEN 10 THEN 10
     WHEN 11 THEN 6 
     WHEN 12 THEN 11 
     ELSE -1
  END;
RETURN productRank;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_SFDCNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_SFDCNAME`(sfdcName VARCHAR(50)) RETURNS varchar(25) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE databaseName VARCHAR(25);
SET databaseName = 
  CASE sfdcName
     WHEN ""Adam Smith"" THen ""Adam""
     WHEN ""Ajay Jindal"" THEN ""Ajay""
     WHEN ""Andrew Imhoff"" THEN ""Andrew""
     WHEN ""Annika van Dam"" THEN ""Annika""
     WHEN ""Anthony Bucknam"" THEN ""Anthony""
     WHEN ""Austen Mitchell"" THEN ""Austen""
     WHEN ""Brian VandenHeuvel"" THEN ""Brain""
     WHEN ""Chad Johnson"" THEN ""Chad""
     WHEN ""Chris Albrecht"" THEN ""Chris""
     WHEN ""Colton Bielaski"" THEN ""Colton""
     WHEN ""Dan Thomas"" THEN ""Dan""
     WHEN ""Darren Brown"" THEN ""Darren""
     WHEN ""David Gatto"" THEN ""David""
     WHEN ""Diana Katz"" THEN ""Diana""
     WHEN ""Dillon Brady"" THEN ""Dillon""
     WHEN ""Drew Schultz"" THEN ""Drew""
     WHEN ""Erin Harlan"" THEN ""Erin""
     WHEN ""Evan Williams"" THEN ""Evan""
     WHEN ""Gary Miraku"" THEN ""Gary""
     WHEN ""Jason Paul"" THEN ""Jason""
     WHEN ""Jeana DeNardo"" THEN ""Jeana""
     WHEN ""Jeff Hawk"" THEN ""Jeff""
     WHEN ""Jennifer Buhrmann"" THEN ""Jennifer""
     WHEN ""Kara Lumley"" THEN ""Kara""
     WHEN ""Ken Asher"" THEN ""Ken""
     WHEN ""Kevin Ahern"" THEN ""Kevin""
     WHEN ""Kim Brandl"" THEN ""Kim""
     WHEN ""Liz Tanonis"" THEN ""Liz""
     WHEN ""Maddie Moyer"" THEN ""Maddie""
     WHEN ""Mary Springer"" THEN ""Mary""
     WHEN ""Matthew Neckes"" THEN ""Matthew""
     WHEN ""Max Zulauf"" THEN ""Max""
     WHEN ""Minh Cao"" THEN ""Minh""
     WHEN ""Nick DAgostino"" THEN ""Nick""
     WHEN ""Nick Nordal"" THEN ""NickN""
     WHEN ""Paul Hammann"" THEN ""Paul""
     WHEN ""Roman Castilleja"" THEN ""Roman""
     WHEN ""Ryaire Richardson"" THEN ""Ryaire""
     WHEN ""Ryan Hamilton"" THEN ""Ryan""
     WHEN ""Sarah Richardson"" THEN ""Sarah""
     WHEN ""Sean Jackson"" THEN ""Sean""
     WHEN ""Sean MacKelvie"" THEN ""SeanM""
     WHEN ""Sebrina Truong"" THEN ""Sabrina""
     WHEN ""Shane Whitehurst"" THEN ""Shane""
     WHEN ""Steve Woodworth"" THEN ""Steve""
     WHEN ""Taryn Feenstra"" THEN ""Taryn""
     WHEN ""Ted Cochran"" THEN ""Ted""
     WHEN ""Tom Zylstra"" THEN ""Tom""
     WHEN ""Tyler Colton"" THEN ""Tyler""
     ELSE sfdcName
  END;
RETURN databaseName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_SOLUTIONDEPT","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SOLUTIONDEPT`(department VARCHAR(19)) RETURNS varchar(4) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE solutionDept VARCHAR(4);
SET solutionDept =
    CASE department
        WHEN 'Human Resources' THEN 'HR'
        WHEN 'IT & Operations' THEN 'IT'
        WHEN 'Marketing' THEN 'MA'
        WHEN 'Product Development' THEN 'PD'
        WHEN 'Project Management' THEN 'PM'
        WHEN 'Sales' THEN 'SA'
END;
RETURN solutionDept;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_START_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_START_LOG`(tableName varchar(300) ) RETURNS varchar(1000) CHARSET utf8
BEGIN

DECLARE bN INT;
DECLARE pS INT;
DECLARE startTime datetime;



SELECT MAX(prepSequence) INTO pS FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, ""%Y-%m-%d"") = CURRENT_DATE();


IF pS IS NULL 
THEN SET pS = 0;
ELSE SET pS = (SELECT MAX(prepSequence) FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;

SELECT MAX(buildNumber) INTO bN FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, ""%Y-%m-%d"") = CURRENT_DATE();


IF bN IS NULL
THEN SET bN = (SELECT MAX(buildNumber)+1 FROM rpt_main_02.arc_prepV2QueryHistory);
ELSE SET bN = (SELECT MAX(buildNumber) FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;


SET pS = pS+1;
SET startTime = NOW();

INSERT INTO rpt_main_02.arc_prepV2QueryHistory (buildNumber, prepSequence, tableName, startTime)
SELECT bN, pS, tableName, startTime;

 RETURN CONCAT('Logging began for ', tableName, ' at ', startTime);

END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_STATE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_STATE`(state VARCHAR(20)) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE stateName VARCHAR(50);
SET stateName = 
  CASE state
WHEN 'Alabama' THEN 'AL'
WHEN 'Alaska' THEN 'AK'
WHEN 'Arizona' THEN 'AZ'
WHEN 'Arkansas' THEN 'AR'
WHEN 'California' THEN 'CA'
WHEN 'Colorado' THEN 'CO'
WHEN 'Connecticut' THEN 'CT'
WHEN 'Delaware' THEN 'DE'
WHEN 'District of Columbia' THEN 'DC'
WHEN 'Florida' THEN 'FL'
WHEN 'Georgia' THEN 'GA'
WHEN 'Hawaii' THEN 'HI'
WHEN 'Idaho' THEN 'ID'
WHEN 'Illinois' THEN 'IL'
WHEN 'Indiana' THEN 'IN'
WHEN 'Iowa' THEN 'IA'
WHEN 'Kansas' THEN 'KS'
WHEN 'Kentucky' THEN 'KY'
WHEN 'Louisiana' THEN 'LA'
WHEN 'Maine' THEN 'ME'
WHEN 'Maryland' THEN 'MD'
WHEN 'Massachusetts' THEN 'MA'
WHEN 'Michigan' THEN 'MI'
WHEN 'Minnesota' THEN 'MN'
WHEN 'Mississippi' THEN 'MS'
WHEN 'Missouri' THEN 'MO'
WHEN 'Montana' THEN 'MT'
WHEN 'Nebraska' THEN 'NE'
WHEN 'Nevada' THEN 'NV'
WHEN 'New Hampshire' THEN 'NH'
WHEN 'New Jersey' THEN 'NJ'
WHEN 'New Mexico' THEN 'NM'
WHEN 'New York' THEN 'NY'
WHEN 'North Carolina' THEN 'NC'
WHEN 'North Dakota' THEN 'ND'
WHEN 'Ohio' THEN 'OH'
WHEN 'Oklahoma' THEN 'OK'
WHEN 'Oregon' THEN 'OR'
WHEN 'Pennsylvania' THEN 'PA'
WHEN 'Rhode Island' THEN 'RI'
WHEN 'South Carolina' THEN 'SC'
WHEN 'South Dakota' THEN 'SD'
WHEN 'Tennessee' THEN 'TN'
WHEN 'Texas' THEN 'TX'
WHEN 'Utah' THEN 'UT'
WHEN 'Vermont' THEN 'VT'
WHEN 'Virginia' THEN 'VA'
WHEN 'Washington' THEN 'WA'
WHEN 'West Virginia' THEN 'WV'
WHEN 'Wisconsin' THEN 'WI'
WHEN 'Wyoming' THEN 'WY'
     ELSE state
  END;
return stateName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_STATEABBREV","","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_STATEABBREV`(stateAbbrev VARCHAR(20)) RETURNS varchar(50) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE stateName VARCHAR(50);
SET stateName = 
  CASE stateAbbrev
 WHEN 'AL'  THEN  'Alabama'
 WHEN 'AK'  THEN  'Alaska'
 WHEN 'AZ'  THEN  'Arizona'
 WHEN 'AR'  THEN  'Arkansas'
 WHEN 'CA'  THEN  'California'
 WHEN 'CO'  THEN  'Colorado'
 WHEN  'CT'  THEN  'Connecticut'
 WHEN  'DE'  THEN  'Delaware'
 WHEN  'DC'  THEN  'District of Columbia'
 WHEN 'FL'  THEN  'Florida'
 WHEN  'GA'  THEN  'Georgia'
 WHEN 'HI'  THEN  'Hawaii'
 WHEN 'ID'  THEN  'Idaho'
 WHEN 'IL'  THEN  'Illinois'
 WHEN 'IN'  THEN  'Indiana'
 WHEN 'IA'  THEN  'Iowa'
 WHEN  'KS'  THEN  'Kansas'
 WHEN  'KY'  THEN  'Kentucky'
 WHEN 'LA'  THEN  'Louisiana'
 WHEN 'ME'  THEN  'Maine'
 WHEN 'MD'  THEN  'Maryland'
 WHEN  'MA'  THEN  'Massachusetts'
 WHEN  'MI'  THEN  'Michigan'
 WHEN 'MN'  THEN  'Minnesota'
 WHEN  'MS'  THEN  'Mississippi'
 WHEN  'MO'  THEN  'Missouri'
 WHEN 'MT'  THEN  'Montana'
 WHEN 'NE'  THEN  'Nebraska'
 WHEN 'NV'  THEN  'Nevada'
 WHEN 'NH'  THEN  'New Hampshire'
 WHEN 'NJ'  THEN  'New Jersey'
 WHEN 'NM'  THEN  'New Mexico'
 WHEN  'NY'  THEN  'New York'
 WHEN  'NC'  THEN  'North Carolina'
 WHEN  'ND'  THEN  'North Dakota'
 WHEN  'OH'  THEN  'Ohio'
 WHEN 'OK'  THEN  'Oklahoma'
 WHEN  'OR'  THEN  'Oregon'
 WHEN  'PA'  THEN  'Pennsylvania'
 WHEN  'RI'  THEN  'Rhode Island'
 WHEN  'SC'  THEN  'South Carolina'
 WHEN  'SD'  THEN  'South Dakota'
 WHEN  'TN'  THEN  'Tennessee'
 WHEN  'TX'  THEN  'Texas'
 WHEN  'UT'  THEN  'Utah'
 WHEN  'VT'  THEN  'Vermont'
 WHEN  'VA'  THEN  'Virginia'
 WHEN  'WA'  THEN  'Washington'
 WHEN  'WV'  THEN  'West Virginia'
 WHEN  'WI'  THEN  'Wisconsin'
 WHEN 'WY'  THEN  'Wyoming'
 
 when 'BC' then 'British Columbia'
 when 'ON' then 'Ontario'
 when 'AB' then 'Alberta'
 when 'QC' then 'Quebec'
     ELSE stateAbbrev
  END;
return stateName;
END","utf8","utf8_general_ci","utf8_general_ci"
"SMARTSHEET_STOP_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_STOP_LOG`(tableName varchar(300) ) RETURNS varchar(1000) CHARSET utf8
BEGIN

DECLARE endTime datetime;

SET endTime = NOW();


UPDATE rpt_main_02.arc_prepV2QueryHistory arc
SET timeElapsed = TIME_TO_SEC(TIMEDIFF(endTime,startTime))
WHERE arc.tableName = tableName
AND DATE_FORMAT(arc.startTime, ""%Y-%m-%d"") = CURRENT_DATE()
;


 RETURN CONCAT('Logging stopped for ', tableName, ' at ', endTime);


END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_TRANTYPE","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_TRANTYPE`(transactionType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE transactionName VARCHAR(50);
SET transactionName =
  CASE transactionType
     WHEN 0 THEN ""Unknown""
     WHEN 1 THEN ""Initial Signup""
     WHEN 2 THEN ""Subscription Payment""
     WHEN 3 THEN ""Upgrade Fee""
     WHEN 4 THEN ""Smartsourcing""
     WHEN 5 THEN ""Training""
     ELSE CONCAT('Type ', transactionType)
  END;
return transactionName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_TRPITEMNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_TRPITEMNAME`(itemValue VARCHAR(10)) RETURNS varchar(100) CHARSET utf8
    DETERMINISTIC
BEGIN
DECLARE itemNameFriendly VARCHAR(100);
SET itemNameFriendly = 
 CONCAT(itemValue,"" - "" ,
(CASE WHEN itemValue = ""12sua"" THEN ""Signup Button - Top""
	WHEN itemValue = ""12sub"" THEN ""Signup Button - Middle""
	WHEN itemValue = ""12suc"" THEN ""Signup Button - Bottom1""
	WHEN itemValue = ""12sud"" THEN ""Signup Button - Bottom2""
	WHEN itemValue = ""17a"" THEN ""Top Sign-up button on the updated pricing page""
	WHEN itemValue = ""17b"" THEN ""Bottom Sign-up button on the updated pricing page""
	ELSE (CASE itemValue
		WHEN 5 THEN ""Web Template Gallery Use Template links""
		WHEN 6 THEN ""SIGN up button ON NEW Product Tour pages, July 2012""
		WHEN 7 THEN ""Blog post ON reskin project tracking, 11-OCT-12""
		WHEN 8 THEN ""SESSION Timeout Page secondary items""
		WHEN 9 THEN ""HR Solutions Page""
		WHEN 10 THEN ""Holiday Dinner Planner - link FROM template preview 11/6/12""
		WHEN 11 THEN ""Holiday Dinner Planner - link FROM blog post 11/21""
		WHEN 12 THEN ""Home Page template links (NEW home page 2-DEC-12)""
		WHEN 13 THEN ""explore-the-possibilities links""
		WHEN 14 THEN ""SIMPLE Sales Pipeline video page""
		WHEN 15 THEN ""Multi-Event SCHEDULE FOR SPAC '5 Tips' blog post, 30-Jan-13""
		WHEN 16 THEN ""Signup buttons on Template Tutorial page ('301' pages), Jan 2013""
		WHEN 17 THEN ""New 'single, 3-in-1' sign-up button on the updated pricing page""
		WHEN 18 THEN ""Product Tour Web Forms Page""
		WHEN 19 THEN ""Product Tour Web Forms 'solutions' SEO drilldown page""
		WHEN 20 THEN ""Form a Day in the Month of May Distribution Links""
		WHEN 21 THEN ""http://www.smartsheet.com/blog/gantt-chart-excel""
		WHEN 22 THEN ""Solutions Center v1 'Use Template' button (replacement for How It's Used)""
		WHEN 23 THEN ""Solution Center v2 'Use Template' button"" 
		WHEN 44 THEN ""New Video Center signups""
		WHEN 60 THEN 'Coordinate Anything 3'
		WHEN 61 THEN 'Coordinate Anything 4'
		When 750 THEN 'https://www.smartsheet.com/product-tour'
		When 751 THEN 'https://www.smartsheet.com/product-tour/file-sharing'
		WHEN 1001 THEN '123ContactForm'
		WHEN 1002 THEN '1track'
		WHEN 1003 THEN 'Admin Tools'
		WHEN 1004 THEN 'Amazon Mechanical Turk'
		WHEN 1005 THEN 'Android'
		WHEN 1006 THEN 'Azuqua'
		WHEN 1007 THEN 'Backup'
		WHEN 1008 THEN 'Backupify'
		WHEN 1009 THEN 'Bitium'
		WHEN 1010 THEN 'Box'
		WHEN 1011 THEN 'Centrify'
		WHEN 1012 THEN 'Charts (labs)'
		WHEN 1013 THEN 'Clicdata'
		WHEN 1014 THEN 'Data Tracker'
		WHEN 1015 THEN 'Docusign'
		WHEN 1016 THEN 'DPC'
		WHEN 1017 THEN 'Dropbox'
		WHEN 1018 THEN 'Easy Insight'
		WHEN 1019 THEN 'Evernote'
		WHEN 1020 THEN 'Gmail'
		WHEN 1021 THEN 'Google Apps'
		WHEN 1022 THEN 'Google Calendar'
		WHEN 1023 THEN 'Google Chrome'
		WHEN 1024 THEN 'Google Drive'
		WHEN 1025 THEN 'Harvest'
		WHEN 1026 THEN 'iCal'
		WHEN 1027 THEN 'itDuzzit'
		WHEN 1028 THEN 'iOS'
		WHEN 1029 THEN 'JIRA'
		WHEN 1030 THEN 'Klipfolio'
		WHEN 1031 THEN 'LogmeIn App Guru'
		WHEN 1032 THEN 'MailChimp'
		WHEN 1033 THEN 'Maps (labs)'
		WHEN 1034 THEN 'Marketo'
		WHEN 1035 THEN 'Meldium'
		WHEN 1036 THEN 'Okta'
		WHEN 1037 THEN 'OneLogin'
		WHEN 1038 THEN 'PingOne'
		WHEN 1039 THEN 'Salesforce'
		WHEN 1040 THEN 'SugarCRM'
		WHEN 1041 THEN 'Tableau'
		WHEN 1042 THEN 'Tools4Ever'
		WHEN 1043 THEN 'VMWare Horizon'
		WHEN 1044 THEN 'Zapier'
		WHEN 1045 THEN 'Google Hangouts'
		WHEN 1046 THEN 'App Gallery main page'
		When 2100 THEN 'Solutions Center - Marketing'
		When 4000 THEN 'https://www.smartsheet.com/videos/smartsheet-overview'
		When 4001 THEN 'https://www.smartsheet.com/videos/additional-features'
		When 4002 THEN 'https://www.smartsheet.com/videos/administering-your-smartsheet-team-account'
		When 4003 THEN 'https://www.smartsheet.com/videos/working-smartsheet'
		When 4004 THEN 'https://www.smartsheet.com/videos/how-set-sheet'
		When 4005 THEN 'https://www.smartsheet.com/videos/smartsheet-101-tutorial'
		When 4006 THEN 'https://www.smartsheet.com/videos/smartsheet-101-webinar'
		When 4007 THEN 'https://www.smartsheet.com/videos/201-webinar-gantt-reporting-and-forms'
		When 4008 THEN 'https://www.smartsheet.com/videos/overview-new-collaborators'
		When 4009 THEN 'https://www.smartsheet.com/videos/collaborating-sheets'
		When 4010 THEN 'https://www.smartsheet.com/videos/discussions-smartsheet'
		When 4011 THEN 'https://www.smartsheet.com/videos/groups-smartsheet'
		When 4012 THEN 'https://www.smartsheet.com/videos/sharing-your-sheet'
		When 4013 THEN 'https://www.smartsheet.com/videos/tracking-changes'
		When 4014 THEN 'https://www.smartsheet.com/videos/contacts-smartsheet'
		When 4015 THEN 'https://www.smartsheet.com/videos/attachments-file-sharing'
		When 4016 THEN 'https://www.smartsheet.com/videos/alerts-reminders'
		When 4017 THEN 'https://www.smartsheet.com/videos/send-row-and-update-requests'
		When 4018 THEN 'https://www.smartsheet.com/videos/project-management-smartsheet'
		When 4019 THEN 'https://www.smartsheet.com/videos/resource-management'
		When 4020 THEN 'https://www.smartsheet.com/videos/gantt-chart-dependencies'
		When 4021 THEN 'https://www.smartsheet.com/videos/gantt-chart-view'
		When 4022 THEN 'https://www.smartsheet.com/videos/resource-management-overview'
		When 4023 THEN 'https://www.smartsheet.com/videos/project-management-gantt-template-tutorial'
		When 4024 THEN 'https://www.smartsheet.com/videos/build-sales-pipeline'
		When 4025 THEN 'https://www.smartsheet.com/videos/autofill-formulas'
		When 4026 THEN 'https://www.smartsheet.com/videos/smarter-easier-web-forms'
		When 4027 THEN 'https://www.smartsheet.com/videos/using-web-forms'
		When 4028 THEN 'https://www.smartsheet.com/videos/reporting-smartsheet'
		When 4029 THEN 'https://www.smartsheet.com/videos/cell-linking'
		When 4030 THEN 'https://www.smartsheet.com/videos/rows-hierarchy'
		When 4031 THEN 'https://www.smartsheet.com/videos/columns-smartsheet'
		When 4032 THEN 'https://www.smartsheet.com/videos/conditional-formatting'
		When 4033 THEN 'https://www.smartsheet.com/videos/calendar-view'
		When 4034 THEN 'https://www.smartsheet.com/videos/custom-branding'
		When 4035 THEN 'https://www.smartsheet.com/videos/formulas'
		When 4036 THEN 'https://www.smartsheet.com/videos/smartsourcing'
		When 4200 THEN 'https://www.smartsheet.com/videos/revolutionizing-deep-sea-exploration'
		When 4201 THEN 'https://www.smartsheet.com/videos/real-estate-success'
		When 4202 THEN 'https://www.smartsheet.com/videos/architects-collaborate-efficiently'
		When 4203 THEN 'https://www.smartsheet.com/videos/cypress-grove-chevre'
		When 4204 THEN 'https://www.smartsheet.com/videos/smartsheet-mobile'
		When 4205 THEN 'https://www.smartsheet.com/videos/manage-operations'
		When 4206 THEN 'https://www.smartsheet.com/videos/property-management'
		When 4207 THEN 'https://www.smartsheet.com/videos/agency-aces-project-management'
		When 4208 THEN 'https://www.smartsheet.com/videos/manage-franchise-growth'
		When 4209 THEN 'https://www.smartsheet.com/videos/teaching-next-generation'
		When 4210 THEN 'https://www.smartsheet.com/videos/coordinate-races-athletes'
		When 4211 THEN 'https://www.smartsheet.com/videos/smartsheet-workmap'
		When 4212 THEN 'https://www.smartsheet.com/videos/viral-adoption-groupon'
		When 4400 THEN 'https://www.smartsheet.com/videos/evernote-and-smartsheet'
		When 4401 THEN 'https://www.smartsheet.com/videos/file-sharing-dropbox'
		When 4402 THEN 'https://www.smartsheet.com/videos/smartsheet-app-gallery'
		When 4403 THEN 'https://www.smartsheet.com/videos/google-hangouts-smartsheet'
		When 4404 THEN 'https://www.smartsheet.com/videos/work-google-apps'
		When 4405 THEN 'https://www.smartsheet.com/videos/smartsheet-and-box'
		When 4406 THEN 'https://www.smartsheet.com/videos/smartsheet-and-mail-chimp'
		When 4407 THEN 'https://www.smartsheet.com/videos/smartsheet-and-salesforce'
		When 4408 THEN 'https://www.smartsheet.com/videos/smartsheet-and-docusign'
		When 4409 THEN 'https://www.smartsheet.com/videos/smartsheet-and-evernote'
		When 4410 THEN 'https://www.smartsheet.com/videos/smartsheet-and-harvest'
		When 4411 THEN 'https://www.smartsheet.com/videos/smartsheet-jira'
		When 4412 THEN 'https://www.smartsheet.com/videos/jira-smartsheet'
		When 4600 THEN 'https://www.smartsheet.com/videos/smartsheets-growth-and-market-opportunity'
		When 5707 THEN 'https://www.smartsheet.com/blog/evernote-business-award'
		When 6406 THEN 'https://www.smartsheet.com/blog/sharpening-saw-simple-goal-tracker'
		When 7000 THEN 'http://www.smartsheet.com/announcement/ipad'
		When 7001 THEN 'http://www.smartsheet.com/announcement/event-management'
		When 7002 THEN 'http://www.smartsheet.com/announcement/top-colleges-use-smartsheet'
		When 7003 THEN 'http://www.smartsheet.com/announcement/smartsheet-previews-new-enterprise-features-at-GoogleIO'
		When 7004 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Wins-THINKstrategies-Best-of-SaaS-Showplace-Award%20'
		When 7005 THEN 'http://www.smartsheet.com/announcement/Government-Agencies-Select-Smartsheet-Online-Project-Management'
		When 7006 THEN 'http://www.smartsheet.com/announcement/red-cross-salvation-army-girl-scouts-greenpeace-use-smartsheet'
		When 7007 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Launches-On-Salesforce-AppExchange'
		When 7008 THEN 'http://www.smartsheet.com/announcement/energy-and-utility-companies-power-projects-smartsheet'
		When 7009 THEN 'http://www.smartsheet.com/announcement/smartsheet-online-project-management-app-now-available-spanish'
		When 7010 THEN 'http://www.smartsheet.com/announcement/Cloud-Alliance-For-Google-Apps-Launches'
		When 7011 THEN 'http://www.smartsheet.com/announcement/School-Districts-Reform-Collaboration-Efforts-Smartsheet'
		When 7012 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Launches-Worldwide-Reseller-Program'
		When 7013 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Integrates-with-Box-File-Sharing-for-Projects'
		When 7014 THEN 'http://www.smartsheet.com/announcement/Berklee-College-Music-Utilizes-Smartsheet-for-Project-Management-Course'
		When 7015 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Business-App-Integrates-with-Google-Drive'
		When 7016 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Introduces-Enterprise-Platform'
		When 7017 THEN 'http://www.smartsheet.com/announcement/Credit-Unions-More-Collaborative-With-Smartsheet'
		When 7018 THEN 'http://www.smartsheet.com/announcement/smartsheet-welcomes-geoffrey-barker-to-board-of-directors'
		When 7019 THEN 'http://www.smartsheet.com/announcement/New-HIPAA-SmartAudit-App-Available'
		When 7020 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Raises-26-Million-in-Funding-from-Insight-Venture-Partners-and-Madrona-Venture-Group'
		When 7021 THEN 'http://www.smartsheet.com/announcement/Southern-Illinois-University-Edwardsville-Uses-Smartsheet-to-Teach-Project-Management'
		When 7022 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Implementation-Wins-Enterasys-2013-Manufacturing-Leadership-100-Award'
		When 7023 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Unveils-New-Web-Form-Capabilities'
		When 7024 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Recognizes-Inspirational-High-School-Teachers'
		When 7025 THEN 'http://www.smartsheet.com/announcement/Smartsheet-To-Host-First-Ever-Startup-Weekend-in-Bellevue'
		When 7026 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Sponsors-Pacific-Northwest-Soccer-Club'
		When 7027 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Adds-Seamless-Access-to-Dropbox-Zapier'
		When 7028 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Launches-Android-App-Enhances-iPhone-iPad-App'
		When 7029 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Wins-2013-Tech-Impact-Award'
		When 7030 THEN 'http://www.smartsheet.com/announcement/Survey-Finds-Marketers-Fiercely-Loyal-to-Smartsheet-Collaboration-Tool'
		When 7031 THEN 'http://www.smartsheet.com/announcement/Google-Launches-Easier-Discovery-of-Third-Party-Apps-for-Google-Apps-Customers'
		When 7032 THEN 'http://www.smartsheet.com/announcement/Smartsheet-and-Google-Apps-Make-Businesses-More-Efficient-and-Collaborative'
		When 7033 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Offers-Chrome-App-in-Chrome-Web-Store'
		When 7034 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Rolls-Out-Resource-Management-Capabilities'
		When 7035 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Extends-Work-Management-Platform-With-Enhanced-API-Smartsheet-Labs-SDKs'
		When 7036 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Raises-35-Million-Rapid-Viral-Growth-in-Enterprise-Work-Management'
		When 7037 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Launches-App-Gallery-Extends-Work-Management-Platform'
		When 7038 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Selected-One-of-First-Google-Apps-Premier-Technology-Partners'
		When 7039 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Wins-Seattle-Business-Magazine-100-Best-Companies-to-Work-For-2014'
		When 7040 THEN 'http://www.smartsheet.com/announcement/GSA-Approves-and-Enables-Smartsheet-for-Online-Work-Collaboration-and-Project-Management'
		When 7041 THEN 'http://www.smartsheet.com/announcement/Colliers-Wisconsin-Replaces-Spreadsheets-with-Smartsheet-Gains-Competitive-Advantage'
		When 7042 THEN 'http://www.smartsheet.com/announcement/Smartsheet-Launches-Version-2-of-iPad-iPhone-App'
		When 7043 THEN 'https://www.smartsheet.com/announcement/Smartsheet-Integrates-with-Evernote-and-Wins-Best-Business-App-Award'
		When 7070 THEN 'http://www.smartsheet.com/news'
		WHEN 7301 THEN 'www.smartsheet.com/evernote'
		When 7302 THEN 'partners/box'
		When 7303 THEN 'smartsheet-salesforce-appexchange'
		When 7304 THEN 'crowdsourcing'
		When 7305 THEN 'product/google-apps-integration'
		When 7306 THEN 'partners/dropbox'		
		When 7500 THEN 'http://www.smartsheet.com/customers'
		When 7501 THEN 'http://www.smartsheet.com/customers/behr'
		When 7502 THEN 'http://www.smartsheet.com/customers/unisource'
		When 7503 THEN 'http://www.smartsheet.com/customers/extreme'
		When 7504 THEN 'http://www.smartsheet.com/customers/colliers-international-wisconsin'
		When 7505 THEN 'http://www.smartsheet.com/customers/populous'
		When 7506 THEN 'http://www.smartsheet.com/customers/us-holocaust-memorial-museum'
		When 7507 THEN 'http://www.smartsheet.com/customers/northeast-georgia-medical-center'
		When 7508 THEN 'http://www.smartsheet.com/customers/wested'
		When 7509 THEN 'http://www.smartsheet.com/customers/massage-envy'
		When 7510 THEN 'http://www.smartsheet.com/customers/loyola-university'
		When 7511 THEN 'http://www.smartsheet.com/customers/port-of-san-diego'
		When 7512 THEN 'http://www.smartsheet.com/customers/alpine-pacific-capital'
		When 7513 THEN 'http://www.smartsheet.com/customers/bettercloud'
		When 7514 THEN 'http://www.smartsheet.com/customers/new-england-college-of-business'
		When 7515 THEN 'http://www.smartsheet.com/customers/pacific-west-land'
		When 7516 THEN 'http://www.smartsheet.com/customers/how-to-break-a-world-record'
		When 7517 THEN 'http://www.smartsheet.com/customers/magnolia-bakery'
		When 7518 THEN 'http://www.smartsheet.com/customers/cypress-grove-chevre'
		When 7519 THEN 'http://www.smartsheet.com/customers/government-contractors-association'
		When 7520 THEN 'http://www.smartsheet.com/customers/veg-packer'
		When 7521 THEN 'http://www.smartsheet.com/customers/animation-mentor'
		When 7522 THEN 'http://www.smartsheet.com/customers/spac-ski-racing-club'
		When 7523 THEN 'http://www.smartsheet.com/customers/southern-illinois-university-edwardsville'
		When 7524 THEN 'http://www.smartsheet.com/testimonial/motion-federal-credit-union'
		When 7525 THEN 'http://www.smartsheet.com/customers/visceral'
		When 7526 THEN 'http://www.smartsheet.com/customers/precise-biometrics'
		When 7527 THEN 'http://www.smartsheet.com/customers/sitwayen-development-group-LEVE-foundation'
		When 7528 THEN 'http://www.smartsheet.com/customers/ITWWA'
		When 7529 THEN 'http://www.smartsheet.com/customers/emyth'
		When 7530 THEN 'http://www.smartsheet.com/customers/bbnradio'
		When 7531 THEN 'http://www.smartsheet.com/testimonial/sera-architects'
		When 7532 THEN 'http://www.smartsheet.com/testimonial/habitat-humanity'
		When 7533 THEN 'http://www.smartsheet.com/testimonial/brightside-academy'
		When 7534 THEN 'http://www.smartsheet.com/customers/imaddu'
		When 7535 THEN 'http://www.smartsheet.com/testimonial/center-cartoon-studies'
		When 7536 THEN 'http://www.smartsheet.com/testimonial/inventure-management'
		When 7537 THEN 'http://www.smartsheet.com/testimonial/timeraiser'
		When 7538 THEN 'http://www.smartsheet.com/testimonial/industrial-outsource'
		When 7539 THEN 'http://www.smartsheet.com/testimonial/crown-college'
		When 7540 THEN 'http://www.smartsheet.com/testimonial/encore-realty'
		when 8001 tHEN 'Enterprise'
ELSE ""Other"" END)
END));
return itemNameFriendly;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_WEEK","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_WEEK`(startDateTime DATETIME) RETURNS varchar(20) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE weekFriendly VARCHAR(20);
SET weekFriendly = 
  CONCAT((CASE WHEN LEFt(YEARWEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3),4) = YEAR(startDateTime) Then YEAR(startDateTime)  else YEAR(startDateTime) + 1 End),""*"" , 
	CASE WHEN WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) < 10 THEN CONCAT(""0"", WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3)) 
	ELSE WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) END);
RETURN weekFriendly;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_WEEK2","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SMARTSHEET_WEEK2`(startDateTime DATETIME) RETURNS varchar(20) CHARSET latin1
    DETERMINISTIC
BEGIN
DECLARE weekFriendly VARCHAR(20);
SET weekFriendly = 
  CONCAT((CASE WHEN LEFt(YEARWEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3),4) = YEAR(startDateTime) Then YEAR(startDateTime)  else YEAR(startDateTime) + 1 End),""*"" , 
	CASE WHEN WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) < 10 THEN CONCAT(""0"", WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3)) 
	ELSE WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) END);
RETURN weekFriendly;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SMARTSHEET_WIDGETNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_WIDGETNAME`(widgetType INT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE widgetName VARCHAR(50);
SET widgetName = 
  CASE widgetType
     WHEN 0 THEN ""Cell Link""
     WHEN 1 THEN ""Sheet Summary""
     WHEN 2 THEN ""Shortcut List""
     WHEN 3 THEN ""Shortcut Icon""
     WHEN 4 THEN ""Image""
     WHEN 5 THEN ""Rich Text""
     WHEN 6 THEN ""Grid-Gantt""
     WHEN 7 THEN ""Sheet Data""
     WHEN 8 THEN ""Shortcut""
     ELSE CONCAT('Widget ', widgetType)
  END;
RETURN widgetName;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"SPLIT_STR","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `SPLIT_STR`(
string varchar(255),
delim varchar(12),
pos int) RETURNS varchar(255) CHARSET utf8
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(string, delim, pos),
       LENGTH(SUBSTRING_INDEX(string, delim, pos -1)) + 1),
       delim, '')","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
"Test","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` FUNCTION `Test`(ipCountry varchar(100), s_code VARCHAR(50), c_code VARCHAR(50), m_code VARCHAR(50), bucket varchar(50), subSourceFriendly varchar(50),
			isOrgDomain INT,logCount int, sheetCount int, shareCount int, teamtrial int, isTrialRestart int, wasShared int) RETURNS decimal(20,10)
    DETERMINISTIC
BEGIN
	
DECLARE betaZero DECIMAL(20,5);
DECLARE beta1 DECIMAL(20,5);
DECLARE beta2 DECIMAL(20,5);
DECLARE beta3 DECIMAL(20,5);
DECLARE beta4 DECIMAL (20,5);
DECLARE beta5 DECIMAL (20,5);
DECLARE beta6 DECIMAL (20,5);
DECLARE beta7 DECIMAL (20,5);
DECLARE beta8 DECIMAL (20,5);
DECLARE beta9 DECIMAL (20,5);
DECLARE beta10 DECIMAL (20,5);
DECLARE beta11 DECIMAL (20,5);
DECLARE beta12 DECIMAL (20,5);
DECLARE beta13 DECIMAL (20,5);
DECLARE beta14 DECIMAL (20,5);

DECLARE P DECIMAL(20,10);
DECLARE aP DECIMAL(20,10);
DECLARE fP DECIMAL (10,6);


DECLARE X1 VARCHAR(100);
DECLARE X2 VARCHAR(50);
DECLARE X3 VARCHAR(50);
DECLARE X4 VARCHAR(50);
DECLARE X5 VARCHAR(50);
DECLARE X6 VARCHAR(100);
DECLARE X7 INT;
DECLARE X8 INT;
DECLARE X9 INT;
DECLARE X10 INT;
DECLARE X11 INT;
DECLARE X12 INT;
DECLARE X13 INT;


SET X1 = 	(CASE 
				WHEN ipCountry IS NULL THEN 'None' 
				ELSE ipCountry
			END);

SET X2 = 	(CASE 
				WHEN s_code IS NULL THEN 'None'
 		 		WHEN s_code = '' 	THEN 'Blank' 
 		 		ELSE s_code 
 		 	END);
SET X3 = (CASE 
				WHEN c_code IS NULL THEN 'None'
		 		WHEN c_code = '' 	THEN 'Blank' 
		 		ELSE c_code 
		 	END);
SET X4 = 	(CASE 
				WHEN m_code IS NULL THEN 'None' 
   		 		WHEN m_code = '' 	THEN 'Blank' 
   		 		ELSE m_code 
   		 	END);
SET X5 = bucket;
SET X6 = 	(CASE
				WHEN subSourceFriendly IS NULL THEN 'None' 
				ELSE subSourceFriendly 
			END );
SET X7 = isOrgDomain;
SET X8 = logCount;
SET X9 = sheetCount;
SET X10 = shareCount;
SET X11 = teamTrial;
SET X12 = isTrialRestart;
SET X13 = wasShared;


IF X1 = 'Australia'
THEN SET
 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = X1), 
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = X1), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount'  AND c.Country = X1),
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = X1),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	P=EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X8)+(beta9*X10))/(EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X8)+(beta9*X10))+1);
	 

ELSEIF X1 = 'United States'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = X1), 
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = X1), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount'  AND c.Country = X1),
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = X1),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart'  AND c.Country = X1),
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'wasSharedToPriorToTrial'  AND c.Country = X1),
	beta10 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta11 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta12 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta13 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	P=EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X12)+(beta9*X13)+(beta10*X8)+(beta11*X10)+(beta12*X9)+(beta13*X12))/(EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X12)+(beta9*X13)+(beta10*X8)+(beta11*X10)+(beta12*X9)+(beta13*X12))+1);


ELSEIF X1 = 'United Kingdom'
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 's_code' AND c.Country = X1 AND c.Variable = X2),
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'c_code' AND c.Country = X1 AND c.Variable = X3),
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'm_code' AND c.Country = X1 AND c.Variable = X4),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = X1),
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1),
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = X1), 
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount'  AND c.Country = X1),
	beta10 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = X1),
	beta11 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart'  AND c.Country = X1),
	beta12 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta13 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta14 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount:sourceBucket' AND c.Variable = X5 AND c.Country = X1),

	P=EXP(betaZero+beta1+beta2+beta3+beta4+beta5+(beta6*X7)+(beta7*X8)+(beta8*X9)+(beta9*X10)+(beta10*X11)+(beta11*X12)+(beta12*X8)+(beta13*X10)+(beta14*X9))/(EXP(betaZero+beta1+beta2+beta3+beta4+beta5+(beta6*X7)+(beta7*X8)+(beta8*X9)+(beta9*X10)+(beta10*X11)+(beta11*X12)+(beta12*X8)+(beta13*X10)+(beta14*X9))+1);


ELSEIF X1 = 'Canada'
THEN SET
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = X1), 
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = X1), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount'  AND c.Country = X1),
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = X1),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart' AND c.Country = X1), 
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial:sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	P=EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X12)+(beta9*X11))/(EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X9)+(beta6*X10)+(beta7*X11)+(beta8*X12)+(beta9*X11))+1);



ELSEIF X1 IN ('South Africa','Brazil','None')
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = X1),
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1), 
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount' AND c.Country = X1), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial' AND c.Country = X1),  
	P=EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X10)+(beta6*X11))/(EXP(betaZero+beta1+beta2+(beta3*X7)+(beta4*X8)+(beta5*X10)+(beta6*X11))+1);


ELSEIF X1 IN ('Mexico','France')
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = X1),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 's_code' AND c.Country = X1 AND c.Variable = X2),
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'c_code' AND c.Country = X1 AND c.Variable = X3),
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'm_code' AND c.Country = X1 AND c.Variable = X4),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = X1), 
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = X1),
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = X1), 
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'shareCount'  AND c.Country = X1),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = X1),
	P=EXP(betaZero+beta1+beta2+beta3+beta4+(beta5*X7)+(beta6*X8)+(beta7*X10)+(beta8*X11))/(EXP(betaZero+beta1+beta2+beta3+beta4+(beta5*X7)+(beta6*X8)+(beta7*X10)+(beta8*X11))+1);



ELSEIF X1 IN ('Austria','Belgium','Denmark','Finland','Germany','Hong Kong','Iceland','Ireland','Israel','Italy','Japan','Luxembourg','Netherlands','New Zealand','Norway','Portugal',
'Singapore','South Korea','Spain','Sweden','Switzerland')
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = 'Developed'),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'IpCountry' AND c.Country = 'Developed' AND c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 's_code' AND c.Country = 'Developed' AND c.Variable = X2),
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'c_code' AND c.Country = 'Developed' AND c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'm_code' AND c.Country = 'Developed' AND c.Variable = X4),
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = 'Developed'), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = 'Developed'),
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = 'Developed'), 
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = 'Developed'), 
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = 'Developed'),
	beta10 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart'  AND c.Country = 'Developed'),
	beta11 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount:sourceBucket' AND c.Variable = X5 AND c.Country = 'Developed'), 
	beta12 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount:sourceBucket' AND c.Variable = X5 AND c.Country = 'Developed'),

	P=EXP(betaZero+beta1+beta2+beta3+beta4+beta5+(beta6*X7)+(beta7*X8)+(beta8*X9)+(beta9*X11)+(beta10*X12)+(beta11*X8)+(beta12*X9))/(EXP(betaZero+beta1+beta2+beta3+beta4+beta5+(beta6*X7)+(beta7*X8)+(beta8*X9)+(beta9*X11)+(beta10*X12)+(beta11*X8)+(beta12*X9))+1);


ELSEIF X1 IN ('Argentina','Bangladesh','Chile','China','Colombia','Czech Republic','Egypt','Estonia','Greece','Hungary','India','Indonesia','Iran- Islamic Republic of',""Lao People's Democratic Republic"",
'Lithuania','Malaysia','Mauritius','Morocco','Nigeria','Oman','Pakistan','Peru','Philippines','Poland','Qatar','Romania','Russia','Slovenia','Taiwan','Thailand','Turkey',
'Ukraine','United Arab Emirates','Venezuela','Vietnam')
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = 'Emerging'),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'IpCountry' AND c.Country = 'Emerging' AND c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = 'Emerging'), 
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = 'Emerging'),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = 'Emerging'),
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = 'Emerging'), 
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = 'Emerging'), 
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = 'Emerging'),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart'  AND c.Country = 'Emerging'),
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount:sourceBucket' AND c.Variable = X5 AND c.Country = 'Emerging'), 
	beta10 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isTrialRestart:sourceBucket' AND c.Variable = X5 AND c.Country = 'Emerging'),
	
	P=EXP(betaZero+beta1+beta2+beta3+(beta4*X7)+(beta5*X8)+(beta6*X9)+(beta7*X11)+(beta8*X12)+(beta9*X8)+(beta10*X12))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X7)+(beta5*X8)+(beta6*X9)+(beta7*X11)+(beta8*X12)+(beta9*X8)+(beta10*X12))+1);


ELSEIF X1 NOT IN ('Argentina','Bangladesh','Chile','China','Colombia','Czech Republic','Egypt','Estonia','Greece','Hungary','India','Indonesia','Iran- Islamic Republic of',""Lao People's Democratic Republic"",
'Lithuania','Malaysia','Mauritius','Morocco','Nigeria','Oman','Pakistan','Peru','Philippines','Poland','Qatar','Romania','Russia','Slovenia','Taiwan','Thailand','Turkey',
'Ukraine','United Arab Emirates','Venezuela','Vietnam','Austria','Belgium','Denmark','Finland','Germany','Hong Kong','Iceland','Ireland','Israel','Italy','Japan','Luxembourg','Netherlands','New Zealand','Norway','Portugal',
'Singapore','South Korea','Spain','Sweden','Switzerland', 'United States','United Kingdom','Australia','Canada','Mexico','South Africa','France','Brazil', 'None')
THEN SET 
	betaZero = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'Intercept' AND c.Country = 'Remaining'),
	beta1 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'IpCountry' AND c.Country = 'Remaining' AND c.Variable = X1),
	beta2 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 's_code' AND c.Country = 'Remaining' AND c.Variable = X2),
	beta3 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'c_code' AND c.Country = 'Remaining' AND c.Variable = X3),
	beta4 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'm_code' AND c.Country = 'Remaining' AND c.Variable = X4),
	beta5 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sourceBucket' AND c.Variable = X5 AND c.Country = 'Remaining'),
	beta6 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'subSourceFriendly' AND c.Variable = X6 AND c.Country = 'Remaining'), 
	beta7 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'isOrgDomain' AND c.Country = 'Remaining'),
	beta8 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'logCount' AND c.Country = 'Remaining'), 
	beta9 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'sheetCount' AND c.Country = 'Remaining'), 
	beta10 = (SELECT Coefficient FROM rpt_workspace.pj_strongLeadCoefficients c WHERE c.Category = 'teamTrial'  AND c.Country = 'Remaining'),

	P=EXP(betaZero+beta1+beta2+beta3+beta4+beta5+beta6+(beta7*X7)+(beta8*X8)+(beta9*X9)+(beta10*X11))/(EXP(betaZero+beta1+beta2+beta3+beta4+beta5+beta6+(beta7*X7)+(beta8*X8)+(beta9*X9)+(beta10*X11))+1);

END IF;
RETURN P;
END","utf8","utf8_general_ci","utf8_general_ci"
"TEST_SMARTSHEET_PRODUCTNAME","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` FUNCTION `TEST_SMARTSHEET_PRODUCTNAME`(productID INT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN
DECLARE productName VARCHAR(50);
SET productName = 
  CASE productID
     WHEN -1 THEN NULL
     WHEN 0 THEN ""Cancelled""
     WHEN 1 THEN ""Trial""
     WHEN 2 THEN ""Free""
     WHEN 3 THEN ""Basic""
     WHEN 4 THEN ""Advanced""
     WHEN 5 THEN ""Premium""
     WHEN 7 THEN ""Team""
     WHEN 8 THEN ""Team Plus""
     WHEN 6 THEN ""Enterprise""
     WHEN 9 THEN ""Student""
     ELSE CONCAT('Product ', productID)
  END;
return productName;
END","utf8","utf8_general_ci","utf8_general_ci"
