import re
import json
import os
import argparse
import snowflake.connector
from json import JSONEncoder
from bson import json_util
import json

class MyEncoder(json.JSONEncoder):

    def default(self, obj):
        if isinstance(obj, bool):
            print('got bool')
            return 1 if obj else 0
        if isinstance(obj, Foo):
            print('got Foo')
            return {'__Foo__': id(obj)}
        print('got unknown')
        return super().default(obj)

class Foo: pass

EOL = '\n'

###########################################################

def get_snowflake_conn():
  sf_cfg_account = 'SMARTSHEET'
  sf_cfg_user = 'AUTO_PORT'
  sf_cfg_password = 'trop!8102.20-ekan$oTlemaC'[::-1]
  sf_cfg_role = 'SYSADMIN'
  sf_cfg_warehouse = 'DECISIVEDATA_WH'
  sf_cfg_database = 'MAIN'
  sf_cfg_schema = 'PUBLIC'
  try:
    sf_conn = snowflake.connector.connect(
      account = sf_cfg_account
     ,user = sf_cfg_user
     ,password = sf_cfg_password
     ,role = sf_cfg_role
     ,warehouse = sf_cfg_warehouse
     ,database = sf_cfg_database
     ,schema = sf_cfg_schema
    )
  except:
    print('Attempt to connect to Snowflake FAILED using [account,user,role,warehouse,database,schema]=[{},{},{},{},{},{}]!'.format(sf_cfg_account,sf_cfg_user,sf_cfg_role,sf_cfg_warehouse,sf_cfg_database,sf_cfg_schema))
    raise

  return sf_conn

###########################################################

def exec_sql_cmd(sf_conn, sql_cmd, debug_fh):
  try:
    curs_cmd = sf_conn.cursor().execute(sql_cmd)
    for result_row_tuple in curs_cmd:
      result_row_dict = { col_struct[0] : result_row_tuple[col_offset] for col_offset, col_struct in enumerate(curs_cmd.description) }
      debug_fh.write('Execution success; Results:\n{}'.format(json.dumps(result_row_dict, default=json_util.default)))
  except (snowflake.connector.errors.ProgrammingError) as pe:
    if pe.errno != 900:  # 900 = empty SQL statement, which can be ignored
      errmsg = '\nExecution FAILURE (ProgrammingError:{}):\n{}\n'.format(pe.errno, sql_cmd)
      debug_fh.write(errmsg)
      print(errmsg)
      raise
  except:
    errmsg = '\nExecution FAILURE (Non-ProgrammingError):\n{}\n'.format(sql_cmd)
    debug_fh.write(errmsg)
    print(errmsg)
    raise

###########################################################

def exec_sf_sql_file_cmds(sf_conn, sf_sql_file_name_fq, debug_filename_fq, doExec=False):


  sf_sql_file_name_fq = re.sub("\\\\", "/", sf_sql_file_name_fq)
  print('Executing snowflake file [{}]...'.format(sf_sql_file_name_fq))
  with open(debug_filename_fq, 'w') as debug_fh:
    with open(sf_sql_file_name_fq, 'r') as sf_sql_fh:
      sf_sql_file_contents = sf_sql_fh.read()
      
      sf_sql_file_contents = re.sub(r"""/[*](?:(?<![*]/).)*?[*]/""", r"""""", sf_sql_file_contents, flags=re.DOTALL)  # Strip out all /* ... */ comments
      sf_sql_file_contents = re.sub(r"""--.*$""", r"""""", sf_sql_file_contents, flags=re.MULTILINE)  # Strip out all -- comments

      sf_sql_commands = []
      raw_seq = 0
      for sf_sql_command in sf_sql_file_contents.split(';'):  # We cannot use "\n" here because there are many places with "blah blah; -- comment afterwards"
        raw_seq += 1
        sf_sql_command_tmp = sf_sql_command
        sf_sql_command = re.sub(r"""/[*](?:(?<![*]/).)*$""", r"""""", sf_sql_command, flags=re.DOTALL|re.MULTILINE)
        if sf_sql_command != sf_sql_command_tmp:
          print('Stripped unclosed comment at bottom of command after [raw_seq]=[{}]...'.format(raw_seq))
          print('\nOLD:\n{}\nNEW:\n{}\n'.format(sf_sql_command_tmp, sf_sql_command))

        sf_sql_command_tmp = sf_sql_command
        sf_sql_command = re.sub(r"""^(?:(?<!/[*]).)*[*]/""", r"""""", sf_sql_command, flags=re.DOTALL|re.MULTILINE)
        if sf_sql_command != sf_sql_command_tmp:
          print('Stripped unopened comment at top of command after [raw_seq]=[{}]...'.format(raw_seq))
          print('\nOLD:\n{}\nNEW:\n{}\n'.format(sf_sql_command_tmp, sf_sql_command))

        sf_sql_command = sf_sql_command.strip()
        if sf_sql_command:
          sf_sql_commands.append(sf_sql_command)

      print('Processing [{}] commands...'.format(len(sf_sql_commands)))
      cmd_seq = 0
      for sf_sql_command in sf_sql_commands:
        cmd_seq += 1
        if doExec:
          debug_fh.write('\n[{}]: Executing:\n{}\n'.format(cmd_seq, sf_sql_command))
          print('Executing [cmd_seq]=[{}]...'.format(cmd_seq))
          try:
            exec_sql_cmd(sf_conn, sf_sql_command, debug_fh)
          except:
            print('\nFailed to execute command number [{}]!\n'.format(cmd_seq))
            raise
        else:
          debug_fh.write('\nSkipping execution of:\n{}\n'.format(sf_sql_command))

###########################################################

def exec_sf_sql_files(file_list_file_name, snowflake_file_path_root, doExec=False):

  print('Executing snowflake files in list...')

  sf_conn = get_snowflake_conn()

  with open(file_list_file_name, 'r') as file_list_fh:
    for file_name in file_list_fh:

      file_name = file_name.rstrip(EOL)
      if file_name.endswith('.sql'): 

        snowflake_file_name_fq = os.path.join(snowflake_file_path_root, file_name)

        debug_filename_fq = os.path.join(snowflake_file_path_root, '{}.debug.exec.txt'.format(file_name))

        exec_sf_sql_file_cmds(sf_conn, snowflake_file_name_fq, debug_filename_fq, doExec)

  sf_conn.close()

###########################################################
# MAIN
###########################################################

if __name__ == "__main__":

  parser = argparse.ArgumentParser(description = 'Convert MySQL SQL to Snowflake SQL')

  parser.add_argument(
    'file_list_file_name', 
    help = 'The configuration file containing the specific list of Snowflake SQL file names (relative to snowflake_file_path_root) that are to be executed'
  )
  parser.add_argument(
    'snowflake_file_path_root', 
    help = 'The root file path for the Snowflake SQL files'
  )

  args = parser.parse_args()

  file_list_file_name = args.file_list_file_name

  snowflake_file_path_root = args.snowflake_file_path_root

  #############################

  exec_sf_sql_files(file_list_file_name, snowflake_file_path_root, doExec=True)  # If this is False, then it simply reports the SQL (with comments removed) that WOULD be executed

