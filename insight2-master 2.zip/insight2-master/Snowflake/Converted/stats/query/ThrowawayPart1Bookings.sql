select '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
select '******** Throwaway Part 1: Bookings - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

--SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

--SET $@sql_mode = '';

SET log_Level = '5'; -- DEBUG:5, INFO:4, WARN:3, ERROR:2, FATAL:1, OFF:0:  Determines the granularity of logging this process in the database.
SET process_Id = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL); -- 0 is the default process_Id, this will be overwritten with each utl_logStart call.

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('Throwaway Part 1: Bookings'));
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('Throwaway Part 1: Bookings',NULL::INTEGER,'','INFO',$log_Level, $process_Id));

INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('Max record IDs'));


/*Determine max values for tables in PrepV2DataCorePull*/
CREATE TABLE IF NOT EXISTS MAIN.arc.max_Record_IDs
(variable_Name VARCHAR,
maximum_Value VARCHAR,
primary key (variable_Name));

TRUNCATE TABLE MAIN.arc.max_Record_IDs;

INSERT INTO MAIN.arc.max_Record_IDs
SELECT 'NewMaxaccess_Token_ID', IFNULL(MAX(access_Token_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.access_Token UNION
SELECT 'NewMaxaccess_Token_Session_ID', IFNULL(MAX(access_Token_Session_ID)::VARCHAR,'0') 	FROM CORE.PUBLIC.access_Token_Session UNION
SELECT 'NewMaxbrand_ID', IFNULL(MAX(brand_ID)::VARCHAR,'0') 				FROM CORE.PUBLIC.brand UNION
SELECT 'NewMaxContainer_IDInsert', IFNULL(MAX(container_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.container UNION
SELECT 'NewMaxContainer_IDModify', IFNULL(MAX(container_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.container UNION
SELECT 'NewMaxgoogle_Apps_Domain_ID', IFNULL(MAX(google_Apps_Domain_ID)::VARCHAR,'0') 		FROM CORE.PUBLIC.google_Apps_Domain  UNION
SELECT 'NewMaxHPPmodify_Date_Time', MAX(modify_Date_Time)::VARCHAR 			FROM CORE.hist.payment_Profile  UNION
SELECT 'NewMaxmail_Distribution_ID', IFNULL(MAX(mail_Distribution_ID)::VARCHAR,'0') 		FROM CORE.PUBLIC.mail_Distribution  UNION
SELECT 'NewMaxopedIDIdentifierID', IFNULL(MAX(open_IDIdentifier_ID)::VARCHAR,'0') 		FROM CORE.PUBLIC.open_IDIdentifier  UNION
SELECT 'NewMaxorganization_ID', IFNULL(MAX(organization_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.organization  UNION
SELECT 'NewMaxorganization_User_Role_ID', IFNULL(MAX(organization_User_Role_ID)::VARCHAR,'0') 	FROM CORE.PUBLIC.organization_User_Role  UNION
SELECT 'NEWmax_Payment_Profile_ID', IFNULL(MAX(payment_Profile_ID)::VARCHAR,'0') 		FROM CORE.PUBLIC.payment_Profile 	 UNION
SELECT 'NewMaxreminder_ID', IFNULL(MAX(reminder_ID)::VARCHAR,'0') 				FROM CORE.PUBLIC.reminder  UNION
SELECT 'NewMaxRequestLogID', IFNULL(MAX(request_Log_ID)::VARCHAR,'0') 			FROM LOG.PUBLIC.request_Log UNION
SELECT 'NewMaxsession_Log_ID', IFNULL(MAX(session_Log_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.session_Log UNION
SELECT 'NewMaxsheet_Link_IDInsert', IFNULL(MAX(sheet_Link_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.sheet_Link UNION
SELECT 'NewMaxsheet_Link_IDModify', IFNULL(MAX(sheet_Link_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.sheet_Link UNION
SELECT 'NewMaxsignup_Request_ID', IFNULL(MAX(signup_Request_ID)::VARCHAR,'0') 		FROM ACCOUNT.PUBLIC.signup_Request 	 UNION
SELECT 'NewMaxsignup_Request_Tracking_Item_ID', IFNULL(MAX(signup_Request_Tracking_Item_ID)::VARCHAR,'0') FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item  UNION
SELECT 'NewMaxsite_Setting_Element_Value_ID', IFNULL(MAX(site_Setting_Element_Value_ID)::VARCHAR,'0') FROM ACCOUNT.PUBLIC.site_Setting_Element_Value  UNION
SELECT 'NewMaxTemplateIDInsert', IFNULL(MAX(template_ID)::VARCHAR,'0') 				FROM CORE.PUBLIC.template  UNION
SELECT 'NewMaxTemplateIDModify', IFNULL(MAX(template_ID)::VARCHAR,'0') 				FROM CORE.PUBLIC.template UNION
SELECT 'NewMaxuser_ID', IFNULL(MAX(user_ID)::VARCHAR,'0') 					FROM CORE.PUBLIC.user_Account  UNION
SELECT 'NewMaxworkspace_ID', IFNULL(MAX(workspace_ID)::VARCHAR,'0') 			FROM CORE.PUBLIC.workspace  UNION
SELECT 'NewMaxuserData_ID', IFNULL(MAX(sales_Marketing_User_Data_ID)::VARCHAR,'0') FROM CORE.PUBLIC.sales_Marketing_User_Data UNION
SELECT 'NewMaxorgUserModify_Date', MAX(modify_Date_Time)::VARCHAR 			FROM CORE.PUBLIC.organization_User_Role;

SET NewMaxaccess_Token_ID = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxaccess_Token_ID' );
SET NewMaxaccess_Token_Session_ID = (SELECT  maximum_Value 	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxaccess_Token_Session_ID' );
SET NewMaxbrand_ID = (SELECT  maximum_Value  	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxbrand_ID' );
SET NewMaxContainer_IDInsert = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxContainer_IDInsert' );
SET NewMaxContainer_IDModify = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxContainer_IDModify' );
SET NewMaxgoogle_Apps_Domain_ID = (SELECT  maximum_Value 		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxgoogle_Apps_Domain_ID'  );
SET NewMaxHPPmodify_Date_Time = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxHPPmodify_Date_Time'  );
SET NewMaxmail_Distribution_ID = (SELECT  maximum_Value 		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxmail_Distribution_ID'  );
SET NewMaxopedIDIdentifierID = (SELECT  maximum_Value 		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxopedIDIdentifierID'  );
SET NewMaxorganization_ID = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxorganization_ID'  );
SET NewMaxorganization_User_Role_ID = (SELECT  maximum_Value 	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxorganization_User_Role_ID'  );
SET NEWmax_Payment_Profile_ID = (SELECT  maximum_Value 		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NEWmax_Payment_Profile_ID' 	 );
SET NewMaxreminder_ID = (SELECT  maximum_Value  	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxreminder_ID'  );
SET NewMaxRequestLogID = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxRequestLogID' );
SET NewMaxsession_Log_ID = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsession_Log_ID' );
SET NewMaxsheet_Link_IDInsert = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsheet_Link_IDInsert' );
SET NewMaxsheet_Link_IDModify = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsheet_Link_IDModify' );
SET NewMaxsignup_Request_ID = (SELECT  maximum_Value 		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsignup_Request_ID' 	 );
SET NewMaxsignup_Request_Tracking_Item_ID = (SELECT  maximum_Value FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsignup_Request_Tracking_Item_ID'  );
SET NewMaxsite_Setting_Element_Value_ID = (SELECT  maximum_Value FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxsite_Setting_Element_Value_ID'  );
SET NewMaxTemplateIDInsert = (SELECT  maximum_Value  	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxTemplateIDInsert'  );
SET NewMaxTemplateIDModify = (SELECT  maximum_Value  	FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxTemplateIDModify' );
SET NewMaxuser_ID = (SELECT  maximum_Value  		FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxuser_ID'  );
SET NewMaxworkspace_ID = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxworkspace_ID'  );
SET NewMaxuserData_ID = (SELECT  maximum_Value FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxuserData_ID' );
SET NewMaxorgUserModify_Date = (SELECT  maximum_Value  FROM MAIN.arc.max_Record_IDs where variable_Name = 'NewMaxorgUserModify_Date' );

UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('Max record IDs')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** userAccount table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.PUBLIC.user_Account insert'));


SET process_Id_Sub = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_userAccount',$process_Id::INTEGER,'','INFO',$log_Level,$process_Id_Sub))
;
MERGE INTO MAIN.PUBLIC.USER_ACCOUNT T
  USING (
    WITH X1 AS (
      SELECT MAX(MUA.USER_ID) AS USER_ID_MAX
        FROM MAIN.PUBLIC.USER_ACCOUNT MUA
    )
   ,X2 AS (
      SELECT ANY_VALUE(X1.USER_ID_MAX) AS USER_ID_MAX
            ,MAX(MUA.MODIFY_DATE_TIME) AS MODIFY_DATE_TIME_MAX
        FROM X1
             JOIN MAIN.PUBLIC.USER_ACCOUNT MUA
               ON MUA.USER_ID = X1.USER_ID_MAX
    )
    SELECT CUA.USER_ID
          ,CUA.FIRST_NAME
          ,CUA.LAST_NAME
          ,CUA.NICK_NAME
          ,CUA.ACCOUNT_TYPE
          ,CUA.EMAIL_ADDRESS
          ,CUA.LOGIN_PASSWORD
          ,CUA.LOCALE
          ,CUA.TIME_ZONE
          ,CUA.NEWS_FLAGS
          ,CUA.STATUS_FLAGS
          ,CUA.INSERT_BY_USER_ID
          ,CUA.INSERT_DATE_TIME
          ,CUA.MODIFY_BY_USER_ID
          ,CUA.MODIFY_DATE_TIME
          ,CUA.SESSION_LOG_ID
          ,RLCL.LOCALE_NAME
          ,RLCL.LANGUAGE_NAME
          ,RLCL.COUNTRY_NAME
          ,SPLIT_PART(CUA.EMAIL_ADDRESS, '@', 2) AS DOMAIN
          ,CUA.PROFILE_IMAGE
      FROM X2
           JOIN CORE.PUBLIC.USER_ACCOUNT CUA
             ON (CUA.USER_ID > X2.USER_ID_MAX OR CUA.MODIFY_DATE_TIME > X2.MODIFY_DATE_TIME_MAX)
           LEFT OUTER JOIN MAIN.REF.LOCALE_COUNTRY_LANGUAGE RLCL
             ON RLCL.LOCALE_CODE = CUA.LOCALE
     WHERE USER_ID <= $NewMaxuser_ID::INTEGER
  ) S
    ON S.USER_ID = T.USER_ID
  WHEN NOT MATCHED THEN INSERT
    VALUES (S.USER_ID,S.FIRST_NAME,S.LAST_NAME,S.NICK_NAME,S.ACCOUNT_TYPE,S.EMAIL_ADDRESS,S.LOGIN_PASSWORD,S.LOCALE,S.TIME_ZONE,S.NEWS_FLAGS,S.STATUS_FLAGS,S.INSERT_BY_USER_ID,S.INSERT_DATE_TIME,S.MODIFY_BY_USER_ID,S.MODIFY_DATE_TIME,S.SESSION_LOG_ID,S.PROFILE_IMAGE,S.LOCALE_NAME,S.LANGUAGE_NAME,S.COUNTRY_NAME,S.DOMAIN)
  WHEN MATCHED THEN UPDATE
    SET USER_ID = S.USER_ID
       ,FIRST_NAME = S.FIRST_NAME
       ,LAST_NAME = S.LAST_NAME
       ,NICK_NAME = S.NICK_NAME
       ,ACCOUNT_TYPE = S.ACCOUNT_TYPE
       ,EMAIL_ADDRESS = S.EMAIL_ADDRESS
       ,LOGIN_PASSWORD = S.LOGIN_PASSWORD
       ,LOCALE = S.LOCALE
       ,TIME_ZONE = S.TIME_ZONE
       ,NEWS_FLAGS = S.NEWS_FLAGS
       ,STATUS_FLAGS = S.STATUS_FLAGS
       ,INSERT_BY_USER_ID = S.INSERT_BY_USER_ID
       ,INSERT_DATE_TIME = S.INSERT_DATE_TIME
       ,MODIFY_BY_USER_ID = S.MODIFY_BY_USER_ID
       ,MODIFY_DATE_TIME = S.MODIFY_DATE_TIME
       ,SESSION_LOG_ID = S.SESSION_LOG_ID
       ,PROFILE_IMAGE = S.PROFILE_IMAGE
       ,LOCALE_FRIENDLY = S.LOCALE_NAME
       ,LANGUAGE_FRIENDLY = S.LANGUAGE_NAME
       ,COUNTRY_FRIENDLY = S.COUNTRY_NAME
       ,DOMAIN = S.DOMAIN
;
UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id_Sub
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.PUBLIC.user_Account insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** currencyExchange tables ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.PUBLIC.currency_Exchange'));

DROP TABLE MAIN.PUBLIC.currency_Exchange;
DROP TABLE MAIN.hist.currency_Exchange;

CREATE TABLE IF NOT EXISTS MAIN.PUBLIC.currency_Exchange LIKE CORE.PUBLIC.currency_Exchange;
CREATE TABLE IF NOT EXISTS MAIN.hist.currency_Exchange LIKE CORE.hist.currency_Exchange;

INSERT INTO MAIN.PUBLIC.currency_Exchange SELECT * FROM CORE.PUBLIC.currency_Exchange;
INSERT INTO MAIN.hist.currency_Exchange SELECT * FROM CORE.hist.currency_Exchange;
/*Add USD values set to always be 1*/
INSERT INTO MAIN.hist.currency_Exchange VALUES (0, 'USD', 1, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, '2000-01-01 00:00:00', 1, '2000-01-01 00:00:00', 1, 0, 0, '9999-12-31 08:00:00');

--CREATE UNIQUE INDEX currency ON MAIN.hist.currency_Exchange (currency_Code, modify_Date_Time);

/* Manually insert June 2016 exchange rates */
UPDATE MAIN.hist.currency_Exchange 
SET hist_effective_Thru_Date_Time = '2016-06-01 00:00:00'
WHERE TO_VARCHAR(modify_Date_Time, 'YYYY-MM') = '2016-05';

INSERT INTO MAIN.hist.currency_Exchange  
SELECT * FROM WORKSPACE.PUBLIC.pj_june2016_Currency_Exchange_Rates;

--ALTER TABLE MAIN.hist.currency_Exchange /***CONVERT TO CHARACTER SET `utf8mb4`***/ /***COLLATE `utf8mb4_unicode_520_ci`***/;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.PUBLIC.currency_Exchange')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.PUBLIC.organization - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.PUBLIC.organization'));


DROP TABLE IF EXISTS MAIN.PUBLIC.organization;
CREATE TABLE IF NOT EXISTS MAIN.PUBLIC.organization LIKE CORE.PUBLIC.organization;
INSERT INTO MAIN.PUBLIC.organization  
SELECT *  
FROM CORE.PUBLIC.organization
where organization_ID <= $NewMaxorganization_ID
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.PUBLIC.organization')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** rpt_payment_ProfileContact table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.payment_Profile_Contact*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile_Contact insert'));


DROP TABLE IF EXISTS MAIN.rpt.payment_Profile_Contact;

/******* create rpt_payment_ProfileContact table - start *******/
CREATE TABLE IF NOT EXISTS MAIN.rpt.payment_Profile_Contact(
payment_Profile_ID BIGINT, 
user_ID BIGINT, 
payment_Profile_Insert_Date_Time DATETIME, 
account_Type TINYINT, 
has_Org_Profile BOOLEAN,
parent_Payment_Profile_ID BIGINT, /*included parentPayment_Profile in order to use it for update joins in the rpt_payment_Profile*/
PRIMARY KEY(payment_Profile_ID))
;

--CREATE INDEX idx_rpt_payment_ProfileContactUser_ID ON MAIN.rpt.payment_Profile_Contact (user_ID);
--CREATE INDEX idx_rpt_payment_Profileparent_Payment_Profile_ID ON MAIN.rpt.payment_Profile_Contact (parent_Payment_Profile_ID);


/* Insert the payment_Profiles associated with users */
INSERT INTO MAIN.rpt.payment_Profile_Contact 
SELECT payment_Profile_ID, owner_ID, insert_Date_Time, account_Type, FALSE, parent_Payment_Profile_ID
FROM CORE.PUBLIC.payment_Profile p 
WHERE p.account_Type != 3 and payment_Profile_ID <= $NEWmax_Payment_Profile_ID
;

/* Insert the payment_Profiles associated with organizations. */
/* Pulling through insert_By_User_ID from original user to allow calculations of days_To_Buy.  */
/* Using GROUP BY and MIN since sometimes there can be multiples profiles inserted by the
   the same person and that causes duplicate key issues, so just take the first one.     */

INSERT INTO MAIN.rpt.payment_Profile_Contact 
SELECT p.payment_Profile_ID, 
org.insert_By_User_ID, 
MIN(p2.insert_Date_Time), 
ANY_VALUE(p.account_Type), 
FALSE,
ANY_VALUE(p.parent_Payment_Profile_ID)
FROM CORE.PUBLIC.payment_Profile p
JOIN CORE.PUBLIC.organization org ON org.organization_ID = p.owner_ID
JOIN CORE.PUBLIC.payment_Profile p2 ON p2.owner_ID = org.insert_By_User_ID AND p2.account_Type != 3
WHERE p.account_Type = 3 
	and p.payment_Profile_ID <= $NEWmax_Payment_Profile_ID
	and org.organization_ID <= $NewMaxorganization_ID
	and p2.payment_Profile_ID <= $NEWmax_Payment_Profile_ID
GROUP BY 1, 2
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile_Contact insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/* Update after indexes created  */
/* Update profiles that are dupes of organization profiles (the user has a profile for themselves and one for the organization they created. */
/******* Update brand usage counts on each record *******/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile_Contact update'));

UPDATE MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact 
SET has_Org_Profile = TRUE
FROM MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact2 
WHERE rpt_payment_ProfileContact2.user_ID = rpt_payment_ProfileContact.user_ID
AND rpt_payment_ProfileContact2.account_Type = 3 AND rpt_payment_ProfileContact.account_Type !=3
; 

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile_Contact update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** rpt_payment_ProfileMaster table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.payment_Profile_Master*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile_Master insert'));

DROP TABLE IF EXISTS MAIN.rpt.payment_Profile_Master;
CREATE TABLE IF NOT EXISTS MAIN.rpt.payment_Profile_Master
	(master_Payment_Profile_ID BIGINT, 
	payment_Profile_ID BIGINT, 
	profile_Count INT, 
	sheet_Count INT, 
	gantt_Count INT, 
	has_Custom_Brand BOOLEAN,
	PRIMARY KEY (master_Payment_Profile_ID,payment_Profile_ID));
	
--CREATE INDEX idx_payment_ProfileMasterPayment_Profile_ID ON MAIN.rpt.payment_Profile_Master (payment_Profile_ID);


/* Insert all child payment_Profiles */
INSERT /*IGNORE*/ INTO MAIN.rpt.payment_Profile_Master (master_Payment_Profile_ID, payment_Profile_ID, profile_Count)
SELECT parent_Payment_Profile_ID, payment_Profile_ID, 1
FROM CORE.PUBLIC.payment_Profile p 
WHERE p.parent_Payment_Profile_ID IS NOT NULL and payment_Profile_ID <= $NEWmax_Payment_Profile_ID
;


/* Insert put in the child profiles again so their counts will get rolled up, but don't incease the profile_Count*/
INSERT /*IGNORE*/ INTO MAIN.rpt.payment_Profile_Master (master_Payment_Profile_ID, payment_Profile_ID, profile_Count)
SELECT payment_Profile_ID, payment_Profile_ID, 0
FROM CORE.PUBLIC.payment_Profile p 
WHERE p.parent_Payment_Profile_ID IS NOT NULL and payment_Profile_ID <= $NEWmax_Payment_Profile_ID
;


/* Insert the parent profiles  */
/* Put in 0 for profile count so they are not counted in the profile count rollup  */
INSERT /*IGNORE*/ INTO MAIN.rpt.payment_Profile_Master (master_Payment_Profile_ID, payment_Profile_ID, profile_Count)
SELECT DISTINCT payment_Profile_ID, payment_Profile_ID, 0 
FROM CORE.PUBLIC.payment_Profile p
WHERE p.parent_Payment_Profile_ID IS NULL and payment_Profile_ID <= $NEWmax_Payment_Profile_ID
AND product_ID IN (6,7,8,10,11);


/* Insert the individual (non-team) profiles as well */
INSERT /*IGNORE*/ INTO MAIN.rpt.payment_Profile_Master (master_Payment_Profile_ID, payment_Profile_ID, profile_Count)
SELECT DISTINCT payment_Profile_ID, payment_Profile_ID, 1 
FROM CORE.PUBLIC.payment_Profile p
WHERE p.parent_Payment_Profile_ID IS NULL and payment_Profile_ID <= $NEWmax_Payment_Profile_ID
AND product_ID NOT IN (6,7,8,10,11);

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile_Master insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile_Master update'));

/* Update sheet counts on each record */
UPDATE MAIN.rpt.payment_Profile_Master ppp 
SET ppp.sheet_Count = 
	(SELECT COUNT(*) FROM MAIN.PUBLIC.container c /***FORCE INDEX (container_idx2)***/
	WHERE c.payment_Profile_ID = ppp.payment_Profile_ID 
	AND c.container_Type = 2 
	AND c.delete_Status = 0 
	AND IFNULL(c.template_Status,0) = 0 
	AND c.payment_Profile_ID IS NOT NULL
	AND c.container_ID <= $NewMaxContainer_IDModify)
; 

/* 
UPDATE MAIN.rpt.payment_Profile_Master ppp 
SET ppp.gantt_Count = 
	(SELECT COUNT(*) FROM MAIN.PUBLIC.container c 
	JOIN MAIN.PUBLIC.grid g ON grid_ID = c.display_Object_ID AND g.gantt_State = 1
	WHERE c.payment_Profile_ID = ppp.payment_Profile_ID 
	AND c.container_Type = 2 
	AND c.delete_Status = 0 
	AND IFNULL(c.template_Status,0) = 0 
	AND c.payment_Profile_ID IS NOT NULL
	AND c.container_ID <= $NewMaxContainer_IDModify)
; 


UPDATE MAIN.rpt.payment_Profile_Master ppp 
SET ppp.has_Custom_Brand = 
	(SELECT MAX(b.is_Custom) FROM MAIN.PUBLIC.container c 
	JOIN MAIN.PUBLIC.workspace w ON w.workspace_ID = c.workspace_ID
	JOIN MAIN.PUBLIC.brand b ON b.brand_ID = w.brand_ID
	WHERE c.payment_Profile_ID = ppp.payment_Profile_ID 
	AND c.container_Type = 2 
	AND c.delete_Status = 0 
	AND IFNULL(c.template_Status,0) = 0 
	AND c.payment_Profile_ID IS NOT NULL
	AND c.container_ID <= $NewMaxContainer_IDModify
	AND b.brand_ID <= $NewMaxbrand_ID
	AND w.workspace_ID <= $NewMaxworkspace_ID
)
; */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile_Master update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


	
SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.rpt.payment_Profile_Sheet_Count table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.payment_Profile_Sheet_Count*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile_Sheet_Count'));


/* Sum the sheet counts */
DROP TABLE IF EXISTS MAIN.rpt.payment_Profile_Sheet_Count;
CREATE TABLE IF NOT EXISTS MAIN.rpt.payment_Profile_Sheet_Count
(payment_Profile_ID BIGINT, sheet_Count INT, gantt_Count INT, profile_Count INT, has_Custom_Brand BOOLEAN, PRIMARY KEY(payment_Profile_ID))
;

INSERT INTO MAIN.rpt.payment_Profile_Sheet_Count (payment_Profile_ID, sheet_Count, gantt_Count, profile_Count, has_Custom_Brand)
SELECT master_Payment_Profile_ID, SUM(sheet_Count), SUM(gantt_Count), SUM(profile_Count), MAX(has_Custom_Brand)
FROM MAIN.rpt.payment_Profile_Master 
GROUP BY 1
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile_Sheet_Count')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;




SELECT '******** MAIN.hist.payment_Profile table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.hist.payment_Profile*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.hist.payment_Profile insert'));


/*If reloading hist_payment_Profile, make sure to set the currency_Code = USD for any record where currency_Code is missing*/
/*This will be used to calculate the USD equivalent for all plan_Rates*/
/*Be sure to also scrub rpt_trials if fixes are being made to MAIN.hist.payment_Profile*/

-- TRUNCATE TABLE MAIN.hist.payment_Profile;
-- INSERT INTO MAIN.hist.payment_Profile  
-- SELECT MIN(pp.payment_Profile_ID),
-- pp.owner_ID,pp.account_Type,pp.payment_Type,pp.payment_Flags,pp.parent_Payment_Profile_ID,pp.payment_Start_Date_Time,pp.payment_End_Date_Time,
-- pp.estimated_Last_Payment_Date,pp.actual_Last_Payment_Date,pp.next_Payment_Date,pp.product_ID,pp.product_Price_ID,pp.promo_Code,
-- pp.user_Limit,pp.bonus_Sheet_Count,pp.bonus_User_Count,pp.bonus_Storage_Kb,pp.loyalty_Bonus_Sheet_Count,pp.loyalty_Bonus_Storage_Kb,pp.loyalty_Next_Bonus_Date_Time,
-- pp.loyalty_Next_Bonus_Sheet_Count,pp.loyalty_Next_Bonus_Storage_Kb,pp.payment_Term,pp.currency_Code,pp.plan_Rate,pp.plan_Tax_Rate,pp.tax_Calculated_Rate,
-- pp.tax_Last_Calc_Date_Time,pp.primary_Contact_Phone,pp.referral_Email_Address,pp.reporting_Seat_Count,pp.bill_To_Recurring_Billing_ID,pp.bill_To_CCNumber,
-- pp.bill_To_CCExp_Month,pp.bill_To_CCExp_Year,pp.bill_To_CCName,pp.bill_To_First_Name,pp.bill_To_Last_Name,pp.bill_To_Email_Address,pp.bill_To_Company,
-- pp.bill_To_PO,pp.bill_To_Address1,pp.bill_To_Address2,pp.bill_To_City,pp.bill_To_Region_Code,pp.bill_To_Post_Code,pp.bill_To_Country_Code,pp.bill_To_PPPayer_ID,
-- pp.bill_To_PPAgreement_ID,pp.insert_Date_Time,pp.insert_By_User_ID,pp.modify_Date_Time,pp.modify_By_User_ID,pp.session_Log_ID,pp.data_Timestamp,pp.hist_effective_Thru_Date_Time,
-- pp.plan_Rate/hce.exchange_Rate
-- FROM CORE.hist.payment_Profile pp
-- LEFT OUTER JOIN MAIN.hist.currency_Exchange hce ON pp.currency_Code = hce.currency_Code
--	AND pp.modify_Date_Time BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time
-- GROUP BY pp.owner_ID, pp.account_Type, pp.modify_Date_Time, pp.hist_effective_Thru_Date_Time;
-- UPDATE MAIN.hist.payment_Profile SET currency_Code = 'USD' WHERE currency_Code = '';
-- UPDATE MAIN.hist.payment_Profile SET plan_Rate_USD = plan_Rate WHERE currency_Code = 'USD';
-- UPDATE MAIN.hist.payment_Profile SET plan_Rate_USD = 0 WHERE plan_Rate = 0 AND currency_Code != 'USD';


SET max_Modify_Date = (SELECT  max(modify_Date_Time)::VARCHAR  FROM MAIN.hist.payment_Profile);


INSERT INTO MAIN.hist.payment_Profile  
SELECT MIN(pp.payment_Profile_ID),
pp.owner_ID,
pp.account_Type,
ANY_VALUE(pp.payment_Type),
ANY_VALUE(pp.payment_Flags),
ANY_VALUE(pp.parent_Payment_Profile_ID),
ANY_VALUE(pp.payment_Start_Date_Time),
ANY_VALUE(pp.payment_End_Date_Time),
ANY_VALUE(pp.estimated_Last_Payment_Date),
ANY_VALUE(pp.actual_Last_Payment_Date),
ANY_VALUE(pp.next_Payment_Date),
ANY_VALUE(pp.product_ID),
ANY_VALUE(pp.product_Price_ID),
ANY_VALUE(pp.promo_Code),
ANY_VALUE(pp.user_Limit),
ANY_VALUE(pp.bonus_Sheet_Count),
ANY_VALUE(pp.bonus_User_Count),
ANY_VALUE(pp.bonus_Storage_Kb),
ANY_VALUE(pp.loyalty_Bonus_Sheet_Count),
ANY_VALUE(pp.loyalty_Bonus_Storage_Kb),
ANY_VALUE(pp.loyalty_Next_Bonus_Date_Time),
ANY_VALUE(pp.loyalty_Next_Bonus_Sheet_Count),
ANY_VALUE(pp.loyalty_Next_Bonus_Storage_Kb),
ANY_VALUE(pp.payment_Term),
ANY_VALUE(pp.currency_Code),
ANY_VALUE(pp.plan_Rate),
ANY_VALUE(pp.plan_Tax_Rate),
ANY_VALUE(pp.tax_Calculated_Rate),
ANY_VALUE(pp.tax_Last_Calc_Date_Time),
ANY_VALUE(pp.primary_Contact_Phone),
ANY_VALUE(pp.referral_Email_Address),
ANY_VALUE(pp.reporting_Seat_Count),
ANY_VALUE(pp.bill_To_Recurring_Billing_ID),
ANY_VALUE(pp.bill_To_CCNumber),
ANY_VALUE(pp.bill_To_CCExp_Month),
ANY_VALUE(pp.bill_To_CCExp_Year),
ANY_VALUE(pp.bill_To_CCName),
ANY_VALUE(pp.bill_To_First_Name),
ANY_VALUE(pp.bill_To_Last_Name),
ANY_VALUE(pp.bill_To_Email_Address),
ANY_VALUE(pp.bill_To_Company),
ANY_VALUE(pp.bill_To_PO),
ANY_VALUE(pp.bill_To_Address1),
ANY_VALUE(pp.bill_To_Address2),
ANY_VALUE(pp.bill_To_City),
ANY_VALUE(pp.bill_To_Region_Code),
ANY_VALUE(pp.bill_To_Post_Code),
ANY_VALUE(pp.bill_To_Country_Code),
ANY_VALUE(pp.bill_To_PPPayer_ID),
ANY_VALUE(pp.bill_To_PPAgreement_ID),
ANY_VALUE(pp.insert_Date_Time),
ANY_VALUE(pp.insert_By_User_ID),
pp.modify_Date_Time,
ANY_VALUE(pp.modify_By_User_ID),
ANY_VALUE(pp.session_Log_ID),
ANY_VALUE(pp.data_Timestamp),
pp.hist_effective_Thru_Date_Time,
ANY_VALUE(pp.plan_Rate/hce.exchange_Rate)
	
FROM CORE.hist.payment_Profile pp
LEFT OUTER JOIN MAIN.hist.payment_Profile hpp on
	pp.owner_ID=hpp.owner_ID AND
	pp.account_Type=hpp.account_Type AND
	pp.modify_Date_Time=hpp.modify_Date_Time AND
	pp.hist_effective_Thru_Date_Time=hpp.hist_effective_Thru_Date_Time
LEFT OUTER JOIN MAIN.hist.currency_Exchange hce ON pp.currency_Code /***COLLATE utf8mb4_unicode_520_ci***/ = hce.currency_Code
	AND pp.modify_Date_Time BETWEEN hce.modify_Date_Time AND hce.hist_effective_Thru_Date_Time
WHERE pp.modify_Date_Time >= $max_Modify_Date and pp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time
AND hpp.owner_ID IS NULL
GROUP BY pp.owner_ID, pp.account_Type, pp.modify_Date_Time, pp.hist_effective_Thru_Date_Time
;


/*Fixing specific known errors in the hist_payment_Profile record that affect revenue reporting*/
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 3760270 AND modify_Date_Time = '2014-04-02 23:25:27';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 1368812 AND modify_Date_Time = '2014-04-03 19:05:45';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 3714520 AND modify_Date_Time = '2014-02-13 20:33:30';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 3458050 AND modify_Date_Time = '2013-12-19 16:25:50';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 3538150 AND modify_Date_Time = '2013-10-08 18:11:39';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 3538150 AND modify_Date_Time = '2013-10-10 16:45:24';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 2548653 AND modify_Date_Time = '2013-08-19 14:22:09';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 1274492 AND modify_Date_Time = '2012-12-19 23:06:18';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12, payment_Type = 2  WHERE payment_Profile_ID = 4023198 AND modify_Date_Time = '2014-05-30 16:48:34';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12, payment_Type = 2 WHERE payment_Profile_ID = 4315485 AND modify_Date_Time = '2014-05-30 19:41:53';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12, payment_Type = 2 WHERE payment_Profile_ID = 4337591 AND modify_Date_Time = '2014-05-21 22:38:46';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 12 WHERE payment_Profile_ID = 4304888 AND modify_Date_Time = '2014-05-30 16:56:47';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 0, plan_Rate = 0, plan_Rate_USD = 0, payment_Type = 5  WHERE payment_Profile_ID = 3986365 AND modify_Date_Time = '2014-05-30 16:49:04';
UPDATE MAIN.hist.payment_Profile SET payment_Term = 0, plan_Rate = 0, plan_Rate_USD = 0, payment_Type = 0, product_ID = 0, user_Limit = 1
WHERE payment_Profile_ID = 4296627 AND modify_Date_Time = '2014-05-15 22:52:10';
UPDATE MAIN.hist.payment_Profile SET plan_Rate =  29735, plan_Rate_USD = 29735 WHERE payment_Profile_ID = 1278937 AND modify_Date_Time = '2014-05-02 20:24:25';
UPDATE MAIN.hist.payment_Profile SET plan_Rate = 10492, plan_Rate_USD = 10492  WHERE payment_Profile_ID = 2869082 AND modify_Date_Time = '2014-06-17 15:37:06';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2014-07-31 14:00:00' WHERE payment_Profile_ID = 4665379 AND modify_Date_Time = '2014-07-31 20:36:36';
UPDATE MAIN.hist.payment_Profile SET plan_Rate = 2949, user_Limit = 85 WHERE payment_Profile_ID = 1689270 AND modify_Date_Time = '2014-12-13 00:55:04';
UPDATE MAIN.hist.payment_Profile SET plan_Rate = 10000, user_Limit = 500 WHERE payment_Profile_ID = 1898997 AND modify_Date_Time = '2014-12-13 00:55:04';
UPDATE MAIN.hist.payment_Profile SET plan_Rate = 32427, user_Limit = 442 WHERE payment_Profile_ID = 2464779 AND modify_Date_Time = '2014-12-13 00:55:04';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-01-06 21:54:00' WHERE payment_Profile_ID = 5345500 AND modify_Date_Time = '2015-01-06 21:55:17';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-01-06 22:23:00' WHERE payment_Profile_ID = 5345623 AND modify_Date_Time = '2015-01-06 22:18:03';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-01-06 22:23:00' WHERE payment_Profile_ID = 5345815 AND modify_Date_Time = '2015-01-06 23:03:20';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-01-06 22:23:00' WHERE payment_Profile_ID = 5345968 AND modify_Date_Time IN ('2015-01-06 23:44:44','2015-01-14 18:11:45');
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-01-07 21:27:00' WHERE payment_Profile_ID = 5350758 AND modify_Date_Time = '2015-01-07 21:30:50';
UPDATE MAIN.hist.payment_Profile SET plan_Rate = 792, plan_Tax_Rate = 0 WHERE payment_Profile_ID = 5285658 AND modify_Date_Time = '2015-01-09 22:50:15';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-07-31 23:38:34' WHERE payment_Profile_ID = 6022912 AND modify_Date_Time BETWEEN '2015-07-31 23:38:34' AND '2015-09-02 15:21:46';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-08-11 17:07:00' WHERE payment_Profile_ID = 6132207 AND modify_Date_Time  IN ('2015-08-11 17:07:00','2015-08-11 20:23:56');
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-08-31 19:53:42' WHERE payment_Profile_ID = 5652255 AND modify_Date_Time BETWEEN '2015-08-31 19:53:42' AND '2015-09-01 19:29:32';

/* Fixes related to incorrect payment start date changes made between 9/18 and 9/30 */

UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-03-17 13:23:11' WHERE payment_Profile_ID = 5672442 AND modify_Date_Time = '2015-09-30 21:16:16';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2011-01-31 17:30:52' WHERE payment_Profile_ID = 1561747 AND modify_Date_Time = '2015-09-30 23:18:22';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2014-02-17 17:16:00' WHERE payment_Profile_ID = 4003756 AND modify_Date_Time = '2015-09-21 16:42:29';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2014-08-18 15:21:00' WHERE payment_Profile_ID = 4731588 AND modify_Date_Time = '2015-09-22 21:21:14';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2014-10-13 20:03:41' WHERE payment_Profile_ID = 4998595 AND modify_Date_Time = '2015-09-29 23:40:29';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2014-12-01 17:30:00' WHERE payment_Profile_ID = 5226235 AND modify_Date_Time = '2015-09-30 22:20:33';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-05-07 22:00:10' WHERE payment_Profile_ID = 5902877 AND modify_Date_Time IN('2015-09-22 17:16:04','2015-10-01 15:43:54','2015-10-01 15:50:58');
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-07-06 14:21:54' WHERE payment_Profile_ID = 6132107 AND modify_Date_Time BETWEEN '2015-09-30 23:13:05' AND '2015-10-01 22:37:50';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-07-14 16:55:27' WHERE payment_Profile_ID = 6163313 AND modify_Date_Time BETWEEN '2015-09-21 21:29:53' AND '2015-10-01 20:34:42';

UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-11-30 23:50:00' WHERE payment_Profile_ID = 6745056 AND modify_Date_Time = '2015-12-01 19:01:59';
UPDATE MAIN.hist.payment_Profile SET payment_Start_Date_Time = '2015-11-30 23:50:00' WHERE payment_Profile_ID = 6745056 AND modify_Date_Time = '2015-12-01 19:04:34';

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.hist.payment_Profile insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.hist.payment_Profile update'));

/*Set plan_Rate_USD to plan_Rate for all USD based transactions*/
UPDATE MAIN.hist.payment_Profile SET plan_Rate_USD = plan_Rate WHERE currency_Code = 'USD';
UPDATE MAIN.hist.payment_Profile SET plan_Rate_USD = 0 WHERE plan_Rate = 0 AND currency_Code != 'USD';

-- Create staging table to identify previously exisiting records that need to be updated
DROP TABLE IF EXISTS MAIN.stg.histpayment_Profile_update;

CREATE TABLE IF NOT EXISTS MAIN.stg.histpayment_Profile_update 
(
	payment_Profile_ID bigint,
	modify_Date_Time datetime,
	hist_effective_Thru_Date_Time datetime
)
;

INSERT INTO MAIN.stg.histpayment_Profile_update
SELECT payment_Profile_ID, modify_Date_Time, hist_effective_Thru_Date_Time
FROM CORE.hist.payment_Profile
WHERE modify_Date_Time >= $max_Modify_Date and payment_Profile.modify_Date_Time <= $NewMaxHPPmodify_Date_Time
;

--CREATE INDEX ix_pp_ID ON MAIN.stg.histpayment_Profile_update (payment_Profile_ID);
--CREATE INDEX ix_modify_Date_Time ON MAIN.stg.histpayment_Profile_update (modify_Date_Time);


-- Update hist_effective_Thru_Date_Time of previous payment_Profile_IDs

UPDATE MAIN.hist.payment_Profile hpp /***FORCE INDEX(hist_payment_Profile_idxPK)***/
SET  hpp.hist_effective_Thru_Date_Time = coreHPP.hist_effective_Thru_Date_Time
FROM CORE.hist.payment_Profile coreHPP /***FORCE INDEX(hist_payment_Profile_idxPK)***/
JOIN MAIN.stg.histpayment_Profile_update stg ON coreHPP.payment_Profile_ID = stg.payment_Profile_ID 
	AND stg.modify_Date_Time = coreHPP.hist_effective_Thru_Date_Time

WHERE hpp.modify_Date_Time != hpp.hist_effective_Thru_Date_Time AND hpp.modify_Date_Time < $max_Modify_Date

AND  hpp.payment_Profile_ID = coreHPP.payment_Profile_ID
	AND hpp.modify_Date_Time = coreHPP.modify_Date_Time
;


/*Eliminating Promo-period for Proof of Concept promo accounts*/

UPDATE MAIN.hist.payment_Profile
SET  payment_Profile.hist_effective_Thru_Date_Time = payment_Profile_Adjustments.hist_effective_Thru_Date_Time
FROM MAIN.arc.payment_Profile_Adjustments

WHERE payment_Profile.hist_effective_Thru_Date_Time = DATEADD(SECOND, -1, payment_Profile_Adjustments.modify_Date_Time) 
AND  payment_Profile.payment_Profile_ID = payment_Profile_Adjustments.payment_Profile_ID;

DELETE FROM MAIN.hist.payment_Profile WHERE payment_Profile_ID IN (SELECT payment_Profile_ID FROM MAIN.arc.payment_Profile_Adjustments) 
AND modify_Date_Time IN (SELECT modify_Date_Time FROM MAIN.arc.payment_Profile_Adjustments);

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.hist.payment_Profile update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

	
SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.rpt.payment_Profile table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.payment_Profile*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile insert'));

DROP TABLE MAIN.stg.organization_Paid_User;
CREATE TABLE MAIN.stg.organization_Paid_User(
payment_Profile_ID BIGINT,
organization_ID BIGINT,
seat_Count INT,
PRIMARY KEY(payment_Profile_ID)
);

INSERT INTO MAIN.stg.organization_Paid_User
SELECT organization.payment_Profile_ID, organization.organization_ID, COUNT(CORE.PUBLIC.organization_User_Role.organization_User_Role_ID) AS seat_Count
FROM CORE.PUBLIC.organization
JOIN CORE.PUBLIC.organization_User_Role ON CORE.PUBLIC.organization.organization_ID = CORE.PUBLIC.organization_User_Role.organization_ID
WHERE role = 'LICENSE_USER'
GROUP BY 1, 2
;

SET maxppModify = (SELECT  DATEADD(DAY, -3, MAX(modify_Date_Time)::VARCHAR) FROM MAIN.rpt.payment_Profile );
SET maxpp_ID = (SELECT  MAX(payment_Profile_ID) FROM MAIN.rpt.payment_Profile );

DROP TABLE IF EXISTS WORKSPACE.stg.c_Dunn_pp_Updates;
CREATE TABLE IF NOT EXISTS WORKSPACE.stg.c_Dunn_pp_Updates LIKE MAIN.rpt.payment_Profile;

INSERT INTO WORKSPACE.stg.c_Dunn_pp_Updates(
	payment_Profile_ID,
	owner_ID, 
	source_User_ID,
	has_Org_Profile,
	company_Name,
	account_Type,
	account_Type_Friendly,
	payment_Type,
	payment_Type_Friendly,
	payment_Flags,
	parent_Payment_Profile_ID,
	
	payment_Insert_Date,
	payment_Insert_Month,
	payment_Insert_Week,
	payment_Insert_Day,
	
	payment_Start_Date_Raw,
	payment_Start_Date_Clean,
	payment_End_Date_Time,
	payment_Start_Month, 
	payment_Start_Week, 
	payment_Start_Day,
	
	product_ID,
	product_Name,
	user_Limit,
	product_Price_ID,
	promo_Code,
	bonus_Sheet_Count,
	bonus_User_Count,
	payment_Term,
	payment_Term_Friendly,
	payment_Total,
	plan_Rate_USD,
	currency_Code,
	
	primary_Contact_Phone,
	referral_Email_Address,
	reporting_Seat_Count,
	bill_To_Recurring_Billing_ID,
	bill_To_Country_Friendly,
	
	cancel_Payment_Date, 
	actual_Last_Payment_Date,
	next_Payment_Date,
	modify_Date_Time,
	seat_Count,
	count_As_Paid,
	recurring_Monthly_Revenue,
	annual_Revenue,
	days_To_Buy,
	sheet_Count,
	active_Profile_Count,
	has_Paid) 

SELECT 	pp.payment_Profile_ID, 
	pp.owner_ID,	
	ppc.user_ID,
	CASE WHEN ppc.has_Org_Profile THEN 1 ELSE 0 END,
	/* default company_Name to the non-profit name if we have one - overwritten with org name later if it is an org*/
	pp.bill_To_Company, 
	pp.account_Type,
	MAIN.PUBLIC.SMARTSHEET_ACCOUNTTYPE(pp.account_Type) AS Account_TypeFriendly,
	pp.payment_Type AS Payment_Type,
	MAIN.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type) AS Payment_Type_Friendly,
	pp.payment_Flags,
	pp.parent_Payment_Profile_ID,
	
	/*payment_Insert_Date*/
	ppc.payment_Profile_Insert_Date_Time,
	TO_VARCHAR(ppc.payment_Profile_Insert_Date_Time, 'YYYY*MM(mon)'),
	
	MAIN.PUBLIC.SMARTSHEET_WEEK(ppc.payment_Profile_Insert_Date_Time), 

	DATE_PART(DAYOFYEAR, ppc.payment_Profile_Insert_Date_Time::DATE),

	/*payment_Start_Date_Raw*/
	pp.payment_Start_Date_Time,
	/*payment_Start_Date_Clean*/
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF(pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', '2008-09-30', pp.payment_Start_Date_Time) 
		ELSE IFF(ppc.payment_Profile_Insert_Date_Time > '2008-09-30', ppc.payment_Profile_Insert_Date_Time, '2008-09-29')
	END,
	pp.payment_End_Date_Time,
	
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', '2008*09(Sep)', TO_VARCHAR(pp.payment_Start_Date_Time, 'YYYY*MM(mon)')) 
		ELSE IFF(ppc.payment_Profile_Insert_Date_Time > '2008-09-30', TO_VARCHAR(ppc.payment_Profile_Insert_Date_Time, 'YYYY*MM(mon)'), '2008*09(Sep)')
	END,
	
	/*payment_Start_Week*/
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', MAIN.PUBLIC.SMARTSHEET_WEEK('2008-09-30 00:00:00'), 
			 MAIN.PUBLIC.SMARTSHEET_WEEK(pp.payment_Start_Date_Time))
		ELSE IFF (ppc.payment_Profile_Insert_Date_Time > '2008-09-30', MAIN.PUBLIC.SMARTSHEET_WEEK(ppc.payment_Profile_Insert_Date_Time), MAIN.PUBLIC.SMARTSHEET_WEEK('2008-09-30 00:00:00'))
	END,

	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', DATE_PART(DAYOFYEAR, '2008-09-30'::DATE), DATE_PART(DAYOFYEAR, pp.payment_Start_Date_Time::DATE)) 
		ELSE IFF (ppc.payment_Profile_Insert_Date_Time > '2008-09-30', DATE_PART(DAYOFYEAR, ppc.payment_Profile_Insert_Date_Time::DATE), DATE_PART(DAYOFYEAR, '2008-09-30'::DATE))
	END,
	
	/*product_ID*/
	pp.product_ID,
	MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(pp.product_ID) AS Product_Name,
	pp.user_Limit,
	pp.product_Price_ID,
	pp.promo_Code,
	pp.bonus_Sheet_Count,
	IFNULL(pp.bonus_User_Count,0),
	pp.payment_Term,
	MAIN.PUBLIC.SMARTSHEET_PAYMENTTERM(pp.payment_Term) AS payment_Term_Friendly,
	pp.plan_Rate,
	pp.plan_Rate/hce.exchange_Rate,
	pp.currency_Code,
	
	/*primary_Contact_Phone*/
	pp.primary_Contact_Phone,
	pp.referral_Email_Address,
	pp.reporting_Seat_Count,
	pp.bill_To_Recurring_Billing_ID,
	MAIN.PUBLIC.SMARTSHEET_COUNTRYNAME(pp.bill_To_Country_Code),
	
	CASE pp.product_ID
		WHEN 0 THEN pp.payment_Start_Date_Time
		ELSE NULL END AS cancel_Payment_Date,
	pp.actual_Last_Payment_Date,
	pp.next_Payment_Date,
	pp.modify_Date_Time,
/*Seat Count*/
	CASE pp.account_Type
		WHEN 3 THEN	/* organization */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise account_Type */  
				ELSE organization_Paid_User.seat_Count
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IFF(pp.plan_Rate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IFF(pp.plan_Rate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END,

	CASE (pp.Promo_Code = 'HAYEMPL' OR pp.Promo_Code = 'EXECMBA09' OR pp.Promo_Code = 'TESTPAY')
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE CASE pp.product_ID
			WHEN 0 THEN  0 /* 'Cancelled' */
			WHEN 1 THEN  0 /* 'Trial' */
			WHEN 2 THEN  0 /* 'Free' */
			ELSE
				CASE pp.payment_Type
					WHEN 0 THEN 0	/* none */
					WHEN 1 THEN     /* cc */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 2 THEN 	/* bill to */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
						IFF(pp.plan_Rate > 0, 1, 0)
					WHEN 4 THEN 0	/* promo */
					WHEN 5 THEN 0	/* paid by other */						
					WHEN 6 THEN 	/* THIRD_PARTY */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 7 THEN 0	/* THIRD_PARTY_BY_OTHER */		
					WHEN 8 THEN 	/* PAYPAL */
						IFF(pp.plan_Rate > 0, 1, 0)
					WHEN 10 THEN /* Bill to In-App */
						IFF(pp.plan_Rate > 0 , 1, 0) 
					ELSE 0 END
					
				END
	END,

	CASE pp.payment_Term
		WHEN 1 THEN (pp.plan_Rate/hce.exchange_Rate) / pp.payment_Term
		ELSE '0' END,
		
	CASE pp.payment_Term
		WHEN 12 THEN (pp.plan_Rate/hce.exchange_Rate)
		ELSE '0' END,
		
	CASE DATEDIFF(MINUTE, MIN(hpp.payment_Start_Date_Time), ppc.payment_Profile_Insert_Date_Time) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(MINUTE, MIN(hpp.payment_Start_Date_Time), ppc.payment_Profile_Insert_Date_Time) END,
		
	ppsc.sheet_Count,
	ppsc.profile_Count,
	0/* default has_Paid to 0 and we will update later based on history */
	
FROM CORE.PUBLIC.payment_Profile pp
LEFT OUTER JOIN MAIN.hist.payment_Profile hpp ON hpp.payment_Profile_ID = pp.payment_Profile_ID 
	AND hpp.product_ID > 2 AND hpp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time 
LEFT OUTER JOIN MAIN.hist.currency_Exchange hce ON pp.currency_Code /***COLLATE utf8mb4_unicode_520_ci***/ = hce.currency_Code
	AND pp.modify_Date_Time BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time
JOIN MAIN.rpt.payment_Profile_Sheet_Count ppsc ON ppsc.payment_Profile_ID = pp.payment_Profile_ID
JOIN MAIN.rpt.payment_Profile_Contact ppc ON ppc.payment_Profile_ID = pp.payment_Profile_ID
LEFT OUTER JOIN MAIN.stg.organization_Paid_User ON organization_Paid_User.payment_Profile_ID = pp.payment_Profile_ID

WHERE pp.payment_Profile_ID <= $maxpp_ID AND pp.modify_Date_Time >= $maxppModify

GROUP BY 1,2,3,4,5,6,7,8,9,
   10,11,12,13,14,15,16,17,18,19,
   20,21,22,23,24,25,26,27,28,29,
   30,31,32,33,34,35,36,37,38,39,
   40,41,42,43,44,45,46,   48,49,50
;

UPDATE MAIN.rpt.payment_Profile A
SET owner_ID = B.owner_ID,
	source_User_ID = B.source_User_ID,
	has_Org_Profile = B.has_Org_Profile,
	company_Name = B.company_Name,
	account_Type = B.account_Type,
	account_Type_Friendly = B.account_Type_Friendly,
	payment_Type = B.payment_Type,
	payment_Type_Friendly = B.payment_Type_Friendly,
	payment_Flags = B.payment_Flags,
	parent_Payment_Profile_ID = B.parent_Payment_Profile_ID,
	payment_Insert_Date = B.payment_Insert_Date,
	payment_Insert_Month = B.payment_Insert_Month,
	payment_Insert_Week = B.payment_Insert_Week,
	payment_Insert_Day = B.payment_Insert_Day,
	payment_Start_Date_Raw = B.payment_Start_Date_Raw,
	payment_Start_Date_Clean = B.payment_Start_Date_Clean,
	payment_End_Date_Time = B.payment_End_Date_Time,
	payment_Start_Month = B.payment_Start_Month,
	payment_Start_Week = B.payment_Start_Week,
	payment_Start_Day = B.payment_Start_Day,
	product_ID = B.product_ID,
	product_Name = B.product_Name,
	user_Limit = B.user_Limit,
	product_Price_ID = B.product_Price_ID,
	promo_Code = B.promo_Code,
	bonus_Sheet_Count = B.bonus_Sheet_Count,
	bonus_User_Count = B.bonus_User_Count,
	payment_Term = B.payment_Term,
	payment_Term_Friendly = B.payment_Term_Friendly,
	payment_Total = B.payment_Total,
	plan_Rate_USD = B.plan_Rate_USD,
	currency_Code = B.currency_Code,
	primary_Contact_Phone = B.primary_Contact_Phone,
	referral_Email_Address = B.referral_Email_Address,
	reporting_Seat_Count = B.reporting_Seat_Count,
	bill_To_Recurring_Billing_ID = B.bill_To_Recurring_Billing_ID,
	bill_To_Country_Friendly = B.bill_To_Country_Friendly,
	cancel_Payment_Date = B.cancel_Payment_Date,
	actual_Last_Payment_Date = B.actual_Last_Payment_Date,
	next_Payment_Date = B.next_Payment_Date,
	modify_Date_Time = B.modify_Date_Time,
	seat_Count = B.seat_Count,
	count_As_Paid = B.count_As_Paid,
	recurring_Monthly_Revenue = B.recurring_Monthly_Revenue,
	annual_Revenue = B.annual_Revenue,
	days_To_Buy = B.days_To_Buy,
	sheet_Count = B.sheet_Count,
	active_Profile_Count = B.active_Profile_Count,
	has_Paid = B.has_Paid
FROM WORKSPACE.stg.c_Dunn_pp_Updates B
WHERE A.payment_Profile_ID = B.payment_Profile_ID
;
	
INSERT /*IGNORE*/ INTO MAIN.rpt.payment_Profile(
	payment_Profile_ID,
	owner_ID, 
	source_User_ID,
	has_Org_Profile,
	company_Name,
	account_Type,
	account_Type_Friendly,
	payment_Type,
	payment_Type_Friendly,
	payment_Flags,
	parent_Payment_Profile_ID,
	
	payment_Insert_Date,
	payment_Insert_Month,
	payment_Insert_Week,
	payment_Insert_Day,
	
	payment_Start_Date_Raw,
	payment_Start_Date_Clean,
	payment_End_Date_Time,
	payment_Start_Month, 
	payment_Start_Week, 
	payment_Start_Day,
	
	product_ID,
	product_Name,
	user_Limit,
	product_Price_ID,
	promo_Code,
	bonus_Sheet_Count,
	bonus_User_Count,
	payment_Term,
	payment_Term_Friendly,
	payment_Total,
	plan_Rate_USD,
	currency_Code,
	
	primary_Contact_Phone,
	referral_Email_Address,
	reporting_Seat_Count,
	bill_To_Recurring_Billing_ID,
	bill_To_Country_Friendly,
	
	cancel_Payment_Date, 
	actual_Last_Payment_Date,
	next_Payment_Date,
	modify_Date_Time,
	seat_Count,
	count_As_Paid,
	recurring_Monthly_Revenue,
	annual_Revenue,
	days_To_Buy,
	sheet_Count,
	active_Profile_Count,
	has_Paid) 

SELECT 	pp.payment_Profile_ID, 
	pp.owner_ID,	
	ppc.user_ID,
	CASE WHEN ppc.has_Org_Profile THEN 1 ELSE 0 END,
	/* default company_Name to the non-profit name if we have one - overwritten with org name later if it is an org*/
	pp.bill_To_Company, 
	pp.account_Type,
	MAIN.PUBLIC.SMARTSHEET_ACCOUNTTYPE(pp.account_Type) AS Account_TypeFriendly,
	pp.payment_Type AS Payment_Type,
	MAIN.PUBLIC.SMARTSHEET_PAYMENTTYPE(pp.payment_Type) AS Payment_Type_Friendly,
	pp.payment_Flags,
	pp.parent_Payment_Profile_ID,
	
	/*payment_Insert_Date*/
	ppc.payment_Profile_Insert_Date_Time,
	TO_VARCHAR(ppc.payment_Profile_Insert_Date_Time, 'YYYY*MM(mon)'),
	
	MAIN.PUBLIC.SMARTSHEET_WEEK(ppc.payment_Profile_Insert_Date_Time), 

	DATE_PART(DAYOFYEAR, ppc.payment_Profile_Insert_Date_Time::DATE),

	/*payment_Start_Date_Raw*/
	pp.payment_Start_Date_Time,
	/*payment_Start_Date_Clean*/
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF(pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', '2008-09-30', pp.payment_Start_Date_Time) 
		ELSE IFF(ppc.payment_Profile_Insert_Date_Time > '2008-09-30', ppc.payment_Profile_Insert_Date_Time, '2008-09-29')
	END,
	pp.payment_End_Date_Time,
	
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', '2008*09(Sep)', TO_VARCHAR(pp.payment_Start_Date_Time, 'YYYY*MM(mon)')) 
		ELSE IFF(ppc.payment_Profile_Insert_Date_Time > '2008-09-30', TO_VARCHAR(ppc.payment_Profile_Insert_Date_Time, 'YYYY*MM(mon)'), '2008*09(Sep)')
	END,
	
	/*payment_Start_Week*/
	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', MAIN.PUBLIC.SMARTSHEET_WEEK('2008-09-30 00:00:00'), 
			 MAIN.PUBLIC.SMARTSHEET_WEEK(pp.payment_Start_Date_Time))
		ELSE IFF (ppc.payment_Profile_Insert_Date_Time > '2008-09-30', MAIN.PUBLIC.SMARTSHEET_WEEK(ppc.payment_Profile_Insert_Date_Time), MAIN.PUBLIC.SMARTSHEET_WEEK('2008-09-30 00:00:00'))
	END,

	CASE pp.payment_Start_Date_Time > '2008-09-30' 
		WHEN 1 THEN IFF (pp.promo_Code = 'BETALOCKIN' AND ppc.payment_Profile_Insert_Date_Time < '2008-10-01', DATE_PART(DAYOFYEAR, '2008-09-30'::DATE), DATE_PART(DAYOFYEAR, pp.payment_Start_Date_Time::DATE)) 
		ELSE IFF (ppc.payment_Profile_Insert_Date_Time > '2008-09-30', DATE_PART(DAYOFYEAR, ppc.payment_Profile_Insert_Date_Time::DATE), DATE_PART(DAYOFYEAR, '2008-09-30'::DATE))
	END,
	
	/*product_ID*/
	pp.product_ID,
	MAIN.PUBLIC.SMARTSHEET_PRODUCTNAME(pp.product_ID) AS Product_Name,
	pp.user_Limit,
	pp.product_Price_ID,
	pp.promo_Code,
	pp.bonus_Sheet_Count,
	IFNULL(pp.bonus_User_Count,0),
	pp.payment_Term,
	MAIN.PUBLIC.SMARTSHEET_PAYMENTTERM(pp.payment_Term) AS payment_Term_Friendly,
	pp.plan_Rate,
	pp.plan_Rate/hce.exchange_Rate,
	pp.currency_Code,
	
	/*primary_Contact_Phone*/
	pp.primary_Contact_Phone,
	pp.referral_Email_Address,
	pp.reporting_Seat_Count,
	pp.bill_To_Recurring_Billing_ID,
	MAIN.PUBLIC.SMARTSHEET_COUNTRYNAME(pp.bill_To_Country_Code),
	
	CASE pp.product_ID
		WHEN 0 THEN pp.payment_Start_Date_Time
		ELSE NULL END AS cancel_Payment_Date,
	pp.actual_Last_Payment_Date,
	pp.next_Payment_Date,
	pp.modify_Date_Time,
/*Seat Count*/
	CASE pp.account_Type
		WHEN 3 THEN	/* organization */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise account_Type */  
				ELSE organization_Paid_User.seat_Count
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IFF(pp.plan_Rate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IFF(pp.plan_Rate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END,

	CASE (pp.Promo_Code = 'HAYEMPL' OR pp.Promo_Code = 'EXECMBA09' OR pp.Promo_Code = 'TESTPAY')
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE CASE pp.product_ID
			WHEN 0 THEN  0 /* 'Cancelled' */
			WHEN 1 THEN  0 /* 'Trial' */
			WHEN 2 THEN  0 /* 'Free' */
			ELSE
				CASE pp.payment_Type
					WHEN 0 THEN 0	/* none */
					WHEN 1 THEN     /* cc */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 2 THEN 	/* bill to */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
						IFF(pp.plan_Rate > 0, 1, 0)
					WHEN 4 THEN 0	/* promo */
					WHEN 5 THEN 0	/* paid by other */						
					WHEN 6 THEN 	/* THIRD_PARTY */
						IFF(pp.plan_Rate > 0, 1, 0)		
					WHEN 7 THEN 0	/* THIRD_PARTY_BY_OTHER */		
					WHEN 8 THEN 	/* PAYPAL */
						IFF(pp.plan_Rate > 0, 1, 0)
					WHEN 10 THEN /* Bill to In-App */
						IFF(pp.plan_Rate > 0 , 1, 0) 
					ELSE 0 END
					
				END
	END,

	CASE pp.payment_Term
		WHEN 1 THEN (pp.plan_Rate/hce.exchange_Rate) / pp.payment_Term
		ELSE '0' END,
		
	CASE pp.payment_Term
		WHEN 12 THEN (pp.plan_Rate/hce.exchange_Rate)
		ELSE '0' END,
		
	CASE DATEDIFF(MINUTE, MIN(hpp.payment_Start_Date_Time), ppc.payment_Profile_Insert_Date_Time) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(MINUTE, MIN(hpp.payment_Start_Date_Time), ppc.payment_Profile_Insert_Date_Time) END,
		
	ppsc.sheet_Count,
	ppsc.profile_Count,
	0/* default has_Paid to 0 and we will update later based on history */
	
FROM CORE.PUBLIC.payment_Profile pp
LEFT OUTER JOIN MAIN.hist.payment_Profile hpp ON hpp.payment_Profile_ID = pp.payment_Profile_ID 
	AND hpp.product_ID > 2 AND hpp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time 
LEFT OUTER JOIN MAIN.hist.currency_Exchange hce ON pp.currency_Code /***COLLATE utf8mb4_unicode_520_ci***/ = hce.currency_Code
	AND pp.modify_Date_Time BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time
JOIN MAIN.rpt.payment_Profile_Sheet_Count ppsc ON ppsc.payment_Profile_ID = pp.payment_Profile_ID
JOIN MAIN.rpt.payment_Profile_Contact ppc ON ppc.payment_Profile_ID = pp.payment_Profile_ID
LEFT OUTER JOIN MAIN.stg.organization_Paid_User ON organization_Paid_User.payment_Profile_ID = pp.payment_Profile_ID

WHERE pp.payment_Profile_ID > $maxpp_ID AND pp.payment_Profile_ID <= $NEWmax_Payment_Profile_ID

GROUP BY 1,2,3,4,5,6,7,8,9,
   10,11,12,13,14,15,16,17,18,19,
   20,21,22,23,24,25,26,27,28,29,
   30,31,32,33,34,35,36,37,38,39,
   40,41,42,43,44,45,46,   48,49,50
;


UPDATE MAIN.rpt.payment_Profile pp
SET pp.active_Profile_Count = ppsc.profile_Count
FROM MAIN.rpt.payment_Profile_Sheet_Count ppsc

WHERE  ppsc.payment_Profile_ID = pp.payment_Profile_ID
;



UPDATE MAIN.rpt.payment_Profile rpp
SET rpp.seat_Count =
	CASE pp.account_Type
		WHEN 3 THEN	/* organization */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise account_Type */  
				ELSE organization_Paid_User.seat_Count
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.payment_Type
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IFF(pp.plan_Rate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IFF(pp.plan_Rate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IFF(pp.plan_Rate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END
FROM CORE.PUBLIC.payment_Profile pp
LEFT OUTER JOIN MAIN.stg.organization_Paid_User ON organization_Paid_User.payment_Profile_ID = pp.payment_Profile_ID

WHERE  pp.payment_Profile_ID = rpp.payment_Profile_ID
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

-- UPDATE rpt_payment_Profile 
-- SET payment_Profile.seat_Count = (SELECT COUNT(CORE.PUBLIC.organization_User_Role.organization_User_Role_ID) 
-- 					FROM CORE.PUBLIC.organization_User_Role JOIN CORE.PUBLIC.organization ON CORE.PUBLIC.organization.organization_ID = CORE.PUBLIC.organization_User_Role.organization_ID
-- 					WHERE organization.payment_Profile_ID = payment_Profile.payment_Profile_ID AND role = 'LICENSE_USER')
-- WHERE payment_Profile.account_Type = 3 AND payment_Profile.payment_Type NOT IN (0,4,5)
-- ;

INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.payment_Profile update'));

/*Set plan_Rate_USD to payment_Total for all USD transactions*/
/* UPDATE MAIN.rpt.payment_Profile SET plan_Rate_USD = payment_Total WHERE currency_Code = 'USD';

UPDATE MAIN.rpt.payment_Profile SET plan_Rate_USD = 0 WHERE payment_Total = 0 AND currency_Code != 'USD';
UPDATE MAIN.rpt.payment_Profile SET Annual_Revenue = 0 WHERE payment_Total = 0 AND payment_Term = 12 AND currency_Code != 'USD'; */

/* Set main contact based on account type - pull user_ID from source_User_ID for standard acccounts and from org main contact for orgs */
UPDATE MAIN.rpt.payment_Profile SET main_Contact_User_ID = source_User_ID WHERE account_Type != 3;

/* Also overwrite the company name with the Org_Name for Organizations */

UPDATE MAIN.rpt.payment_Profile rp
SET  rp.main_Contact_User_ID = o.main_Contact_User_ID,
     rp.company_Name = o.name
FROM MAIN.PUBLIC.organization o

WHERE rp.account_Type = 3 

AND  rp.owner_ID = o.organization_ID and o.organization_ID <= $NewMaxorganization_ID;


UPDATE MAIN.rpt.payment_Profile rp
SET rp.main_Contact_Email_Address = u.email_Address,
     rp.main_Contact_Domain = u.domain

FROM MAIN.PUBLIC.user_Account u

WHERE  rp.main_Contact_User_ID = u.user_ID AND u.user_ID <= $NewMaxuser_ID
;

DROP TABLE IF EXISTS MAIN.stg.min_Max_Paid;
CREATE TABLE IF NOT EXISTS MAIN.stg.min_Max_Paid
(payment_Profile_ID BIGINT,
first_Payment_Date DATETIME,
max_Paid_Date DATETIME,
last_Paid_Product_ID INT,
PRIMARY KEY (payment_Profile_ID),
UNIQUE /*max_Paid_Date*/ (max_Paid_Date));

INSERT INTO MAIN.stg.min_Max_Paid (payment_Profile_ID, first_Payment_Date, max_Paid_Date)
SELECT payment_Profile_ID, MIN(payment_Start_Date_Time), MAX(modify_Date_Time)::VARCHAR
FROM MAIN.hist.payment_Profile
WHERE product_ID > 2 AND payment_Type IN(1,2,3,6,8,10) AND plan_Rate > 0
GROUP BY 1;


UPDATE MAIN.stg.min_Max_Paid A
SET last_Paid_Product_ID = hpp.product_ID
FROM MAIN.hist.payment_Profile hpp /***FORCE INDEX (hist_payment_Profile_idxPK)***/

WHERE  hpp.payment_Profile_ID = A.payment_Profile_ID AND hpp.modify_Date_Time = A.max_Paid_Date
;

/* Set Has paid flag */


UPDATE MAIN.rpt.payment_Profile pp
SET has_Paid = 1
FROM MAIN.stg.min_Max_Paid B

WHERE  pp.payment_Profile_ID = B.payment_Profile_ID
;

/* Set first payment max payment and last paid product ID */

UPDATE MAIN.rpt.payment_Profile pp
SET pp.first_Payment_Date = B.first_Payment_Date,
	pp.max_Paid_Date = B.max_Paid_Date,
	pp.last_Paid_Product_ID = B.last_Paid_Product_ID
FROM MAIN.stg.min_Max_Paid B

WHERE  pp.payment_Profile_ID = B.payment_Profile_ID
;

/* 
UPDATE MAIN.rpt.payment_Profile rp
SET  rp.has_Paid = 1
FROM MAIN.hist.payment_Profile hp

WHERE hp.product_ID > 2 AND hp.payment_Type IN (1,2,3,6,8,10) AND hp.plan_Rate > 0

AND  rp.payment_Profile_ID = hp.payment_Profile_ID AND hp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time; */

/* Get the first hist_payment_Profile date where the user was paid */

/* UPDATE MAIN.rpt.payment_Profile rp
SET rp.first_Payment_Date = (SELECT MIN(hp.payment_Start_Date_Time) 
FROM MAIN.hist.payment_Profile hp 
WHERE rp.payment_Profile_ID = hp.payment_Profile_ID 
AND hp.product_ID >= 3 
AND hp.payment_Type IN (1,2,3,6,8,10)
AND hp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time)
; */


/* Get the last hist_payment_Profile record that is paid */
/* 
UPDATE MAIN.rpt.payment_Profile rp
SET rp.max_Paid_Date = (SELECT MAX(hp.modify_Date_Time) 
FROM MAIN.hist.payment_Profile hp 
WHERE rp.payment_Profile_ID = hp.payment_Profile_ID 
AND hp.product_ID >= 3 
AND hp.payment_Type IN (1,2,3,6,8,10)
AND hp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time)
; */

/* Get the product_ID of the last paid product - we want to know what product they were on when they cancelled */
/* 
UPDATE MAIN.rpt.payment_Profile rp
SET  rp.last_Paid_Product_ID = hp.product_ID
FROM MAIN.hist.payment_Profile hp

WHERE rp.max_Paid_Date IS NOT NULL 

AND  rp.payment_Profile_ID = hp.payment_Profile_ID 
  	AND rp.max_Paid_Date = hp.modify_Date_Time 
  	AND hp.modify_Date_Time <= $NewMaxHPPmodify_Date_Time; */

/* For the current edge case of  */
/* 
UPDATE MAIN.rpt.payment_Profile rp
SET  plan_Rate_USD =	rp.payment_Total/hce.exchange_Rate
FROM MAIN.hist.currency_Exchange hce

WHERE plan_Rate_USD IS NULL
AND  rp.currency_Code = hce.currency_Code
	AND rp.max_Paid_Date BETWEEN hce.insert_Date_Time AND hce.hist_effective_Thru_Date_Time; */


/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.payment_Profile update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** arc_requestLog table ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.arc.request_Log'));


SET process_Id_Sub = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_requestLog',$process_Id::INTEGER,'','INFO',$log_Level,$process_Id_Sub))
;
SET max_Request_Log_Id = (SELECT MAX(request_Log_ID) FROM MAIN.ARC.REQUEST_LOG)
;
SET process_Id_Sub2 = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_requestLog',$process_Id_Sub,'arc_serverActionLookup','DEBUG',$log_Level,$process_Id_Sub2))
;
INSERT INTO MAIN.ARC.SERVER_ACTION_LOOKUP (
  URL_ACTION_ID
 ,FORM_NAME
 ,FORM_ACTION
)
SELECT RL.URL_ACTION_ID
      ,RL.FORM_NAME
      ,RL.FORM_ACTION
  FROM (
         SELECT DISTINCT
                R.URL_ACTION_ID
               ,R.FORM_NAME
               ,R.FORM_ACTION
           FROM LOG.PUBLIC.REQUEST_LOG R
          WHERE R.REQUEST_LOG_ID > $NewMaxRequestLogID
       ) RL
       LEFT OUTER JOIN MAIN.ARC.SERVER_ACTION_LOOKUP L
         ON L.URL_ACTION_ID = RL.URL_ACTION_ID
        AND L.FORM_NAME = RL.FORM_NAME
        AND L.FORM_ACTION = RL.FORM_ACTION
 WHERE L.URL_ACTION_ID IS NULL
;
INSERT INTO MAIN.ARC.REQUEST_LOG
SELECT * 
  FROM LOG.PUBLIC.REQUEST_LOG
 WHERE REQUEST_LOG_ID > $NewMaxRequestLogID
;
UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id_Sub
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.arc.request_Log')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;



/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.arc.session_Log'));

CREATE TABLE IF NOT EXISTS MAIN.arc.session_Log LIKE CORE.PUBLIC.session_Log;

SET max_Session_Log_ID = (SELECT  MAX(session_Log_ID) FROM MAIN.arc.session_Log  );

INSERT INTO MAIN.arc.session_Log 
SELECT session_Log_ID, email_Address, login_Type, login_Status, login_Auth_Result, user_ID, source_IP, browser, 
VERSION, platform, user_Agent, screen_Width, screen_Height, insert_Date_Time, sign_Out_Date_Time
FROM CORE.PUBLIC.session_Log 
WHERE session_Log_ID > $max_Session_Log_ID AND session_Log_ID <= $NewMaxsession_Log_ID
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.arc.session_Log')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.rpt.signup_Request_Tracking_Item ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.signup_Request_Tracking_Item*/


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item data pull'));


/* When the logic changes and we want to reprocess everything, drop the table with the line below. */
/* DROP TABLE IF EXISTS MAIN.rpt.signup_Request_Tracking_Item; */

CREATE TABLE IF NOT EXISTS MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID BIGINT, 
	signup_Request_ID BIGINT, 
	item_Type TINYINT, 
	item_Name NVARCHAR, 
	item_Value NVARCHAR, 
	extra_Info NVARCHAR/***, 
	INDEX(signup_Request_Tracking_Item_ID)***//***,
	INDEX(signup_Request_ID)***/);

/* find out where we left off */
/******* SET start_Date = (SELECT  MAX(log_Date)   - start )*******/
SET signup_Request_Tracking_Item_ID = (SELECT  MAX(signup_Request_Tracking_Item_ID)  		
FROM MAIN.rpt.signup_Request_Tracking_Item);

/* for startup case, if null seed with date earlier than any user data */
SET signup_Request_Tracking_Item_ID = (SELECT  IFF($signup_Request_Tracking_Item_ID  IS NULL, 0, $signup_Request_Tracking_Item_ID) );

/* for monitoring... */
SELECT $signup_Request_Tracking_Item_ID;

/* copy over the tracking items we care about and decode them at the same time */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	core_TrackingItem.signup_Request_Tracking_Item_ID, 
	core_TrackingItem.signup_Request_ID, 
	core_TrackingItem.item_Type, 
	core_TrackingItem.item_Name, 
			
	CASE core_TrackingItem.item_Value REGEXP '\\%'
		WHEN 1 THEN 
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(core_TrackingItem.item_Value, 
						'%25'	, '%'), 
						'%25'	, '%'), /* may be double encoded */
						'%25'	, '%'), /* may be triple encoded */
						'%20'	, ' '), 
						'%26'	, '&'), 
						'%27'	, ''''),
						'%2B'	, '+'), 
						'%2c'	, ','), 
						'%2C'	, ','), 
						'%2D'	, '-'), 
						'%2F'	, '/'), 
						'%3A'	, ':'),
						'%3D'	, '='),
						'%3F'	, '?'),
						'%7B'	, '{'),
						'%7D'	, '}'),
						'%C3%A1', '��'),
						'%C3%A2', '��'),
						'%C3%A3', '��'),
						'%C3%A7', '��'),
						'%C3%A8', '��'),
						'%C3%A9', '��'),
						'%C3%AA', '��'),
						'%C3%AD', '��'),
						'%C3%B1', '��'), 
						'%C3%B3', '��') 
						
						
		ELSE core_TrackingItem.item_Value  /* nothing to decode */
	END 
												
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item core_TrackingItem
WHERE core_TrackingItem.item_Name IN ('c', 's', 'm',    	/* high level tracking codes */
	'cv', 'lpv', 'sbs', 'sxt', 'lpa',							/* landing page codes */
	'q', 'p', 'wd', 'terms', 'query', 					/* search term parameters */
	'k', 'a', 'plc', 'adp', 'mtp', 'net',				/* PPC codes */
	'Type',	'u', 'Parm1', 'IP',							/* Smartsheet system codes */
	'r', 'utm_referrer', 'url', 'src',					/* referrer information, src for pm-sherpa */
	'dev', 'devm', 'mkwid', 'gclid',					/* more PPC codes */
	'utm_expid', 'ket',									/* AB testing codes */
	'wsca', 											/* web site chat */
	'rems', 'rema', 'remm', 'remc',						/* remarketing codes */
	'lgt',												/*login type*/
	'trp',												/* trial path */
	'SAML',												/* SAML Setting*/
	'_mkto_trk',										/* marketo tracking code*/
	'ad','phrase','campaign','key','pos','block','added','source','type', /* more tracking codes for international (i.e. Yandex)*/
	'slk','slp',												/*source link*/	
	'client_id', 'optimizely_Buckets', 'optimizelySegments', 'state','lang',
	'su_fname','su_lname','su_phone','su_company','su_title','su_role','exp') /*3rd Party Apps, Optimizely info*/		
	
AND core_TrackingItem.item_Name NOT IN ( 'R',  'U')		/*Remove 'R' values which are different from 'r'*/
AND core_TrackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID  /* not already done */
and core_TrackingItem.signup_Request_Tracking_Item_ID <= $NewMaxsignup_Request_Tracking_Item_ID;	/* through the end of the day */		


/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item data pull')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*cleanse records that had the item name and value incorrectly combined into the item name field*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item data cleansing'));


/* Create table to stage data to be inserted */
CREATE TABLE IF NOT EXISTS MAIN.stg.signup_Request_Tracking_Item
(
signup_Request_Tracking_Item_ID bigint,
signup_Request_ID bigint,
item_Type tinyint,
item_Name VARCHAR,
item_Value VARCHAR,
extra_Info VARCHAR
)
;

/* Clean out staging table */
TRUNCATE TABLE MAIN.stg.signup_Request_Tracking_Item;

/* Create data to hold bad records for cleansing*/ 
CREATE TABLE IF NOT EXISTS MAIN.stg.signup_Tracking_Data
(
signup_Request_ID bigint,
item_Name VARCHAR,
combo1 VARCHAR,
combo2 VARCHAR,
combo3 VARCHAR
)
;

TRUNCATE TABLE MAIN.stg.signup_Tracking_Data;


INSERT INTO MAIN.stg.signup_Tracking_Data
SELECT signup_Request_ID, item_Name, 
NULL as combo1, /* identifies 1st name and value pair */
NULL as combo2, /* identifies 2nd name and value pair */
NULL as combo3  /* identifies 3rd name and value pair*/
FROM 
(
/*Identify records that had their item_Name incorrectly populated*/
	SELECT signup_Request.signup_Request_ID, TO_DATE(signup_Request.insert_Date_Time), signup_Request.insert_Date_Time, signup_Request.result_Status, 
	signup_Request_Tracking_Item.item_Name, signup_Request_Tracking_Item.item_Value
	/*signup_Source.bucket, signup_Source.source_Friendly, signup_Source.sub_Source_Friendly*/
	FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item
	JOIN ACCOUNT.PUBLIC.signup_Request ON signup_Request.signup_Request_ID = signup_Request_Tracking_Item.signup_Request_ID
	/*JOIN MAIN.rpt.signup_Source ON signup_Source.signup_Request_ID = signup_Request.signup_Request_ID */
	WHERE item_Name LIKE 's\%3D%' 
	AND signup_Request.signup_Request_ID >= 3907323
	AND signup_Request.signup_Request_ID <= $NewMaxsignup_Request_ID
	AND signup_Request_Tracking_Item.signup_Request_Tracking_Item_ID >= $signup_Request_Tracking_Item_ID
	and signup_Request_Tracking_Item.signup_Request_Tracking_Item_ID <= $NewMaxsignup_Request_Tracking_Item_ID
) A  /*Alias required to run subquery*/
;


/* Grab last negative value for signup_Request_Tracking_Item_ID to use as starting point for new values to be inserted*/
SET rownum = (SELECT  min(signup_Request_Tracking_Item_ID)  FROM MAIN.rpt.signup_Request_Tracking_Item WHERE signup_Request_Tracking_Item_ID < 0);
-- SELECT $rownum;

/* If $rownum is null then start at -1 */
SET rownum = (SELECT  CASE WHEN $rownum IS NULL THEN -1 ELSE $rownum END );


CREATE OR REPLACE SEQUENCE MAIN.PUBLIC.SEQ_ROW_NUM;
-- First Pass
INSERT INTO MAIN.stg.signup_Request_Tracking_Item 

SELECT ($rownum - MAIN.PUBLIC.SEQ_ROW_NUM.NEXTVAL) AS signup_Request_Tracking_Item_ID, signup_Request_ID, 1 AS item_Type,
SPLIT_PART(combo1, '%3D', 1) AS item_Name1,
SPLIT_PART(combo1, '%3D', -1) AS item_Value1, 
NULL AS extra_Info

FROM MAIN.stg.signup_Tracking_Data
WHERE combo1 IS NOT NULL
AND combo1 != ''
;

-- Second Pass

INSERT INTO MAIN.stg.signup_Request_Tracking_Item 

SELECT ($rownum - MAIN.PUBLIC.SEQ_ROW_NUM.NEXTVAL) AS signup_Request_Tracking_Item_ID, signup_Request_ID, 1 AS item_Type,
SPLIT_PART(combo2, '%3D', 1) AS item_Name2,
SPLIT_PART(combo2, '%3D', -1) AS item_Value2, 
NULL AS extra_Info

FROM MAIN.stg.signup_Tracking_Data
WHERE combo2 IS NOT NULL
AND combo2 != ''
;


-- Third Pass
INSERT INTO MAIN.stg.signup_Request_Tracking_Item 

SELECT ($rownum - MAIN.PUBLIC.SEQ_ROW_NUM.NEXTVAL) AS signup_Request_Tracking_Item_ID, signup_Request_ID, 1 AS item_Type,
SPLIT_PART(combo3, '%3D', 1) AS item_Name3,
SPLIT_PART(combo3, '%3D', -1) AS item_Value3, 
NULL AS extra_Info

FROM MAIN.stg.signup_Tracking_Data
WHERE combo3 IS NOT NULL
AND combo3 != ''
;


-- Final Insert
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item 
SELECT stg.signup_Request_Tracking_Item_ID, stg.signup_Request_ID, stg.item_Type, stg.item_Name, stg.item_Value, stg.extra_Info
FROM MAIN.stg.signup_Request_Tracking_Item stg
LEFT JOIN MAIN.rpt.signup_Request_Tracking_Item srti ON srti.signup_Request_ID=stg.signup_Request_ID
	AND srti.item_Name=stg.item_Name
WHERE srti.signup_Request_Tracking_Item_ID IS NULL
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item data cleansing')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item q parameter extract'));

/* extract out the q parameter embeded in the referrer information */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type, 
	'query_Value', /* < -- but it is going into query_Value parameter */
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(item_Value, 'q') 
		
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?q=%' OR  main_trackingItem.item_Value LIKE '%&q=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID    /* not already done */
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item q parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item p parameter extract'));

/* extract out the p parameter embeded in the referrer information -- but it is going into query_Value parameter */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type, 
	'p', /* < -- going into p parameter, needs more processing before going into query_Value */
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(main_trackingItem.item_Value, 'p') 	
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?p=%' OR  main_trackingItem.item_Value LIKE '%&p=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item p parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item p parameter processing'));


/* now process p search parameters into query_Value */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type,
	'query_Value', 
	main_trackingItem.item_Value
		
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
JOIN MAIN.rpt.signup_Request_Tracking_Item main_trackingItem2 ON main_trackingItem.signup_Request_ID = main_trackingItem2.signup_Request_ID 
	/* there are lots of p parameters that are not search queries, so clean it up */
	AND main_trackingItem2.item_Name = 'r' AND main_trackingItem2.item_Value LIKE '%yahoo%' AND main_trackingItem.item_Value NOT LIKE 'ht%' 
WHERE main_trackingItem.item_Name IN ('p') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item p parameter processing')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item query parameter extract'));

/* extract out the 'query' parameter embeded in the referrer information -- but it is going into query_Value parameter */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type, 
	'query_Value', /* < -- but it is going into query_Value parameter */
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(item_Value, 'query') 
		
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?query=%' OR  main_trackingItem.item_Value LIKE '%&query=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item query parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item wd parameter extract'));

/* extract out the 'wd' parameter embeded in the referrer information -- but it is going into query_Valueparameter */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type,  
	'query_Value', /* < -- but it is going into query_Value parameter */
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(item_Value, 'wd') 
		
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?wd=%' OR  main_trackingItem.item_Value LIKE '%&wd=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item wd parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item terms parameter extract'));

/* extract out the 'terms' parameter embeded in the referrer information -- but it is going into query_Value parameter */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type, 
	'query_Value', /* < -- but it is going into q parameter */
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(item_Value, 'terms') 
		
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?terms=%' OR  main_trackingItem.item_Value LIKE '%&terms=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item terms parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;



/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item query_Value combination'));

/* combine all the new locations for search query information into one parameter: query_Value */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	item_Type,
	'query_Value', 
	item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('q', 'wd', 'terms', 'query')  /* already did 'p' earlier since it needed to be cleaned more */
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item query_Value combination')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item url parameter extract'));

/* extract out the url parameter embeded in the referrer information */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	item_Type, 
	'url', 
	MAIN.PUBLIC.SMARTSHEET_GET_QUERY_PARAMETER(item_Value, 'url') 
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name IN ('r', 'utm_referrer') AND (main_trackingItem.item_Value LIKE '%?url=%' OR  main_trackingItem.item_Value LIKE '%&url=%') 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item url parameter extract')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/* combine all the referrer locations for search query information into one parameter: referrerValue */
/* this first step processes the r value which takes priority */

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item referrerValue combination'));

INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	item_Type,
	'referrerValue', 
	SPLIT_PART(REGEXP_REPLACE(item_Value, '^http://'), '?', 1)
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
WHERE main_trackingItem.item_Name =  'r' 
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/* this second step uses the utm_referrer value if we have one already */
INSERT INTO MAIN.rpt.signup_Request_Tracking_Item(
	signup_Request_Tracking_Item_ID, 
	signup_Request_ID, 
	item_Type, 
	item_Name, 
	item_Value)
SELECT 
	main_trackingItem.signup_Request_Tracking_Item_ID, 
	main_trackingItem.signup_Request_ID, 
	main_trackingItem.item_Type,
	'referrerValue', 
	SPLIT_PART(REGEXP_REPLACE(main_trackingItem.item_Value, '^http://'), '?', 1)
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
JOIN MAIN.rpt.signup_Request_Tracking_Item main_trackingItemReferrerValue 
	ON main_trackingItem.signup_Request_ID = main_trackingItemReferrerValue.signup_Request_ID AND main_trackingItemReferrerValue.item_Name = 'referrerValue'
WHERE main_trackingItem.item_Name = 'utm_referrer' AND main_trackingItemReferrerValue.item_Value IS NULL
	AND main_trackingItem.item_Value NOT LIKE '%www.smartsheet.%' AND main_trackingItem.item_Value NOT LIKE '%.smartsheet.com%' /* don't count referrals from our site */
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item referrerValue combination')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;



/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Request_Tracking_Item update'));


/* update the query_Values if it looks like they were a smartsheet search */
UPDATE MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
SET extra_Info = 'SmartsheetSearch'
WHERE main_trackingItem.item_Name = 'query_Value'  AND   /* try not to false match on spreadsheet or sample sheet */
   (main_trackingItem.item_Value LIKE '%smar_sh%' OR				/* plus or space between words */
	main_trackingItem.item_Value LIKE '%smar__sh%' OR			/* one extra letter between two words or smart(space)sheet */
	main_trackingItem.item_Value LIKE '%smar___sh%' OR			/* two letters between two words */
	main_trackingItem.item_Value LIKE '%samr_sh%' OR				/* transposed m,a */
	main_trackingItem.item_Value LIKE '%samr__sh%' OR			/* transposed m,a */
	main_trackingItem.item_Value LIKE '%samr___sh%' OR			/* transposed m,a */
	main_trackingItem.item_Value LIKE '%smaartsh%' OR			/* extra a */
	main_trackingItem.item_Value LIKE '%smarsh%' OR				/* dropped the t */
	main_trackingItem.item_Value LIKE '%smar_sh%' OR				/* dropped the t, extra letter  */
	main_trackingItem.item_Value LIKE '%smatsh%' OR				/* dropped the r */
	main_trackingItem.item_Value LIKE '%smat_sh%' OR				/* dropped the r, extra letter */
	main_trackingItem.item_Value LIKE '%smartse%' OR				/* dropped the h */
	main_trackingItem.item_Value LIKE '%sartsh%'				/* dropped the m */
	)
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/* update the query_Values if it looks like they were a smartsheet search */

UPDATE MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
SET  main_trackingItem.extra_Info =  'DeepLink-NotProvided' 	/* query_Valueis blank, but the URL indicates the landing page was not the main page, so likely not a smartsheet search */
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItemURL

WHERE main_trackingItem.item_Name = 'query_Value'  AND (main_trackingItem.item_Value = '' OR main_trackingItem.item_Value = 'null') 
/* find where they landed - if they went beyond the home page, they were likely to be a not smartsheet search, unless they went to pricing or signup page */
AND (main_trackingItemURL.item_Value LIKE '%www.smartsheet.%/_%')  AND (main_trackingItemURL.item_Value NOT LIKE '%www.smartsheet.%/pricing%') AND (main_trackingItemURL.item_Value NOT LIKE '%www.smartsheet.%/signup%')  
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID
AND  main_trackingItem.signup_Request_ID = main_trackingItemURL.signup_Request_ID AND main_trackingItemURL.item_Name = 'url';    /* not already done */

/* clean up s=web that stomped on the PPC tracking codes */

UPDATE MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
/* validate it has at least two other PPC tracking codes */
SET  main_trackingItem.item_Value = '1'   /* google search*/
FROM MAIN.rpt.signup_Request_Tracking_Item main_trackingItemC
JOIN MAIN.rpt.signup_Request_Tracking_Item main_trackingItemM ON main_trackingItemC.signup_Request_ID = main_trackingItemM.signup_Request_ID AND main_trackingItemM.item_Name = 'm'

WHERE main_trackingItem.item_Name = 's'  AND main_trackingItem.item_Value = 'web'
AND main_trackingItem.signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID
AND  main_trackingItem.signup_Request_ID = main_trackingItemC.signup_Request_ID AND main_trackingItemC.item_Name = 'c'
;    /* not already done */

/*clean up 'state' value*/
UPDATE MAIN.rpt.signup_Request_Tracking_Item main_trackingItem
SET main_trackingItem.item_Value = CASE WHEN item_Value LIKE '%|/%' THEN SPLIT_PART(item_Value, '|/', -1) ELSE NULL END 
WHERE main_trackingItem.item_Name = 'state'
AND signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;

/* Now process spaces encoded as + in keywords.
   This is needed to try to match the keywords being fed back into the Marin system */

/* fix the keywords without the broad mod+ where spaces are encoded as +*/
UPDATE MAIN.rpt.signup_Request_Tracking_Item 
SET item_Value = REPLACE(item_Value,'+', ' ')
WHERE item_Name = 'k' AND item_Value REGEXP '.\\+'  AND NOT item_Value REGEXP '['' '']' AND NOT item_Value REGEXP '\\+\\+'   /* contains + but not space or ++ */
AND signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

/* fix issue with bing keywords where + in broad mod is coming through as space */
/* change the spaces into pluses here, then the next update statement will fix the ones that should be spaces  */
UPDATE MAIN.rpt.signup_Request_Tracking_Item 
SET item_Value = REPLACE(item_Value,' ', '+')
WHERE item_Name = 'k' AND (item_Value LIKE ' %' OR item_Value LIKE ''' %') 	/* start with space or single quote then space*/
AND signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    		/* not already done */

/* fix the keywords that have broad mod+, turn the first + into space but keep the second+ */
UPDATE MAIN.rpt.signup_Request_Tracking_Item 
SET item_Value = REPLACE(item_Value,'++', ' +')
WHERE item_Name = 'k' AND item_Value REGEXP '\\+\\+'    /* contains ++ */
AND signup_Request_Tracking_Item_ID > $signup_Request_Tracking_Item_ID;    /* not already done */

SET maxLxCode = (SELECT  MAX(signup_Request_ID) FROM MAIN.rpt.lx_Codes );

INSERT INTO MAIN.rpt.lx_Codes
SELECT srti.signup_Request_Tracking_Item_ID, srti.signup_Request_ID, srti.item_Name, srti.item_Value, srti.insert_Date_Time
FROM ACCOUNT.PUBLIC.signup_Request_Tracking_Item srti
WHERE item_Name = 'lx' AND srti.signup_Request_ID > $maxLxCode
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Request_Tracking_Item update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;



SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** rpt_signup_Source table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.signup_Source*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Source insert'));


/* When the logic changes and we want to reprocess everything, drop the table with the line below. */
/* DROP TABLE IF EXISTS MAIN.rpt.signup_Source;  */
SET WEEKFORMAT = '%Y*%U';

CREATE TABLE IF NOT EXISTS MAIN.rpt.signup_Source(
	user_ID BIGINT, 
	email NVARCHAR, 
	signup_Request_ID BIGINT, 
	signup_Insert_Date_Time DATETIME, 
	signup_Insert_Date_Time_PT DATETIME, 
	signup_Month NVARCHAR, 
	signup_Week NVARCHAR, 
	signup_Day NVARCHAR, 
	source NVARCHAR, 
	bucket NVARCHAR, 
	source_Friendly NVARCHAR, 
	sub_Source_Friendly NVARCHAR, 
	campaign NVARCHAR, 
	segment NVARCHAR, 
	ad_Version NVARCHAR, 
	captcha NVARCHAR,
	landing_Page_Version NVARCHAR,
	submit_Button_Style NVARCHAR,
	signup_Extra_Text NVARCHAR,
	keyword NVARCHAR, 
	referrer NVARCHAR, 
	app_Launch_Type NVARCHAR, 
	app_Launch_Parm1 NVARCHAR, 
	app_Launch_Parm1_Friendly NVARCHAR, 
	query_Value NVARCHAR, 
	my_Smartsheet_Referral_Link NVARCHAR,  
	my_Smartsheet_Referral_Link_Friendly NVARCHAR,  
	ip_Address NVARCHAR,  
	url NVARCHAR,  
	web_Page NVARCHAR,  
	web_Site NVARCHAR,
	placement NVARCHAR,
	ad_Position NVARCHAR,
	match_Type NVARCHAR,
	network NVARCHAR,
	dev NVARCHAR,
	devm NVARCHAR,
	mkwid NVARCHAR,
	gclid NVARCHAR,
	IP_Country VARCHAR,
	IP_Region VARCHAR,
	IP_City VARCHAR/***,
	INDEX(email)***//***, 
	INDEX(signup_Insert_Date_Time)***/,
	PRIMARY KEY(user_ID));
	

/* find out where we left off */
/******* SET start_Date = (SELECT  MAX(log_Date)   - start )*******/
	
DELETE FROM MAIN.rpt.signup_Source WHERE signup_Insert_Date_Time >= DATEADD(DAY, -3, CURRENT_DATE);

SET signup_Request_ID = (SELECT  MAX(signup_Request_ID)  		
FROM MAIN.rpt.signup_Source);

/* for startup case, if null seed with date earlier than any user data */
SET signup_Request_ID = (SELECT  IFF($signup_Request_ID  IS NULL, 0, $signup_Request_ID) );

/* for monitoring... */
SELECT 'Picking up where we left off at: ', $signup_Request_ID;

INSERT INTO MAIN.rpt.signup_Source(
	user_ID, 
	email, 
	signup_Request_ID, 
	signup_Insert_Date_Time, 
	signup_Insert_Date_Time_PT, 
	signup_Month, 
	signup_Week, 
	signup_Day, 
	source, 
	bucket, 
	source_Friendly, 
	sub_Source_Friendly, 
	campaign, 
	segment, 
	ad_Version, 
	captcha, 
	landing_Page_Version, 
	submit_Button_Style, 
	signup_Extra_Text,  
	keyword, 
	referrer, 
	app_Launch_Type, 
	app_Launch_Parm1, 
	app_Launch_Parm1_Friendly, 
	query_Value, 
	my_Smartsheet_Referral_Link, 
	my_Smartsheet_Referral_Link_Friendly, 
	ip_Address, 
	url, 
	web_Page, 
	web_Site,
	placement,
	ad_Position,
	match_Type,
	network)
SELECT 
	r.user_ID,
	r.email_Address,
	r.signup_Request_ID,
	r.insert_Date_Time,
	DATEADD(HOUR, -7, r.insert_Date_Time),
	TO_VARCHAR(r.insert_Date_Time, 'YYYY*MM(mon)'), 
	MAIN.PUBLIC.SMARTSHEET_WEEK(r.insert_Date_Time), 
	TO_VARCHAR(r.insert_Date_Time, 'YYYY*MM*DD'), 
    source.item_Value AS Source, 
	
	NULL AS Bucket,  			/* this is now set later using the function SMARTSHEET_GET_BUCKET */
	NULL SourceFriendly,		/* this is now set later using the function SMARTSHEET_GET_SOURCE */
	
	CASE user_Account.insert_By_User_ID = 0 
		WHEN 0 THEN 'Signup Inserted by Smartsheet User'
		ELSE CASE myreferralValue.item_Value 
			WHEN 'HS1018297' THEN 'Office Arrow' 
			WHEN 'RI1018541' THEN 'A Clayton''s Secretary'  
			ELSE CASE TRY_TO_NUMBER(source.item_Value)
				WHEN 1 THEN '_Google Search'
				WHEN 2 THEN				/* put office arrow signups with bad tracking info into right bucket */
					
					CASE (r.insert_Date_Time > '2009-10-12' AND r.insert_Date_Time < '2009-10-17' AND referrerValue.item_Value LIKE '%officeArrow%')
						WHEN 1 THEN 'Office Arrow'
						ELSE '_Google Display Network'		/* Google Content Network */
					END
				WHEN 3 THEN 'Yahoo'
				WHEN 4 THEN 'YouTube (unpaid)'  /* 'Youtube' */
				WHEN 5 THEN 'Referral Rewards'
				WHEN 6 THEN 'Ask.com'
				WHEN 7 THEN 'Email'
				WHEN 8 THEN '_Google Search'
				WHEN 9 THEN 'VANetworking.com'
				WHEN 10 THEN 'Twitter (unpaid)'  /* 'Twitter' */
				WHEN 11 THEN 'Social Media (generic)'  /* 'Social Media' */
				WHEN 12 THEN 'Facebook (unpaid)'
				WHEN 13 THEN 'LinkedIn (unpaid)'
				WHEN 14 THEN 'Google+ (unpaid)'
				WHEN 15 THEN 'Go2Web20.net'
				WHEN 16 THEN '_Bing Search'
				WHEN 17 THEN 'smallbiztrends.com'
				WHEN 18 THEN 'Public template gallery'
				WHEN 19 THEN 'Google App. Marketplace'
				WHEN 20 THEN 'Google App. Marketplace'
				WHEN 21 THEN 'Intuit'
				WHEN 22 THEN '_Bing Content Network'
				WHEN 23 THEN 'Ad Ready Network'
				WHEN 24 THEN 'Zimbra'
				WHEN 25 THEN 'Facebook'
				WHEN 26 THEN 'LinkedIn'
				WHEN 27 THEN 'TJ McCue'
				WHEN 28 THEN 'Salesforce.com'
				WHEN 29 THEN 'Sage Non-Profit'
				WHEN 30 THEN 'Spanish - Google Search Test'
				WHEN 31 THEN 'Spanish - Google Display Network Test'
				WHEN 32 THEN 'Chrome Web Store'
				WHEN 33 THEN 'Serchen'
				WHEN 34 THEN 'The Deck'
				WHEN 35 THEN 'South Africa - Google Display'
				WHEN 36 THEN '_Google Display (iPad only)'
				WHEN 37 THEN '_Google Search (iPad only)'
				WHEN 38 THEN 'Germany - Google Display'
				WHEN 39 THEN 'Germany - Google Search'
				WHEN 40 THEN 'France - Google Display'
				WHEN 41 THEN 'France - Google Search'
				WHEN 42 THEN 'Brazil - Google Display'
				WHEN 43 THEN 'Brazil - Google Search'
				WHEN 44 THEN 'India - Google Display'
				WHEN 45 THEN 'India - Google Search'
				WHEN 46 THEN 'South Africa - Google Search'
				WHEN 47 THEN 'Hong Kong - Google Search'
				WHEN 48 THEN 'Hong Kong - Google Display'
				WHEN 49 THEN 'Denmark - Google Display'
				WHEN 50 THEN 'Denmark - Google Search'
				WHEN 51 THEN 'Finland - Google Display'
				WHEN 52 THEN 'Finland - Google Search'
				WHEN 53 THEN 'Netherlands - Google Display'
				WHEN 54 THEN 'Netherlands - Google Search'
				WHEN 55 THEN 'Branded PPC (Google)'		
				WHEN 56 THEN 'Google Templates'
				WHEN 57 THEN 'Google Remarketing (Paid Visitors)'
				WHEN 58 THEN 'Google Remarketing (Non-paid Visitors)'
				WHEN 59 THEN 'Google Remarketing (Nurture Signups)'
				WHEN 60 THEN 'Bing Search (Canada)'
				WHEN 61 THEN 'Bing Search (Singapore)'
				WHEN 62 THEN 'Bing Search (UK)'
				WHEN 63 THEN 'Bing Search (French - Canada)'
				WHEN 64 THEN 'Bing Search (French - France)'
				WHEN 65 THEN 'Singapore - Google Display'
				WHEN 66 THEN 'Singapore - Google Search'
				WHEN 67 THEN 'Norway - Google Display'
				WHEN 68 THEN 'Norway - Google Search'
				WHEN 69 THEN 'Sweden - Google Display'
				WHEN 70 THEN 'Sweden - Google Search'
				WHEN 71 THEN 'Indonesia - Google Display'
				WHEN 72 THEN 'Indonesia - Google Search'
				WHEN 73 THEN 'Mexico - Google Display'
				WHEN 74 THEN 'Mexico - Google Search'
				WHEN 75 THEN 'Japan - Google Display'
				WHEN 76 THEN 'Japan - Google Search'
				WHEN 77 THEN 'Israel - Google Display'
				WHEN 78 THEN 'Israel - Google Search'
				WHEN 79 THEN 'Malaysia - Google Display'
				WHEN 80 THEN 'Malaysia - Google Search'
				WHEN 81 THEN 'Philippines - Google Display'
				WHEN 82 THEN 'Philippines - Google Search'
				WHEN 83 THEN 'Spain - Google Display'
				WHEN 84 THEN 'Spain - Google Search'
				WHEN 85 THEN 'Belgium - Google Display'
				WHEN 86 THEN 'Belgium - Google Search'
				WHEN 87 THEN 'Youtube (promoted videos)'
				WHEN 88 THEN 'Italy - Google Display'
				WHEN 89 THEN 'Italy - Google Search'
				WHEN 90 THEN 'Turkey - Google Display'
				WHEN 91 THEN 'Turkey - Google Search'
				WHEN 92 THEN 'South Korea - Google Display'
				WHEN 93 THEN 'South Korea - Google Search'
				WHEN 94 THEN 'Columbia - Google Display'
				WHEN 95 THEN 'Columbia - Google Search'
				WHEN 96 THEN 'Argentina - Google Display'
				WHEN 97 THEN 'Argentina - Google Search'
				WHEN 98 THEN 'Saudi Arabia - Google Display'
				WHEN 99 THEN 'Saudi Arabia - Google Search'
				WHEN 100 THEN 'Spanish (US) - Google Display'
				WHEN 101 THEN 'Spanish (US) - Google Search'
				WHEN 102 THEN 'Spanish (Mexico) - Google Display'
				WHEN 103 THEN 'Spanish (Mexico) - Google Search'
				WHEN 104 THEN 'Spanish (Spain) - Google Display'
				WHEN 105 THEN 'Spanish (Spain) - Google Search'
				WHEN 106 THEN 'Spanish (Other) - Google Display'
				WHEN 107 THEN 'Spanish (Other) - Google Search'
				WHEN 108 THEN 'Spanish (Argentina)  Google Display'
				WHEN 109 THEN 'Spanish (Argentina)  Google Search'
				WHEN 110 THEN 'Spanish (Peru)  Google Display'
				WHEN 111 THEN 'Spanish (Peru)  Google Search'
				WHEN 112 THEN 'Spanish (Venezuela)  Google Display'
				WHEN 113 THEN 'Spanish (Venezuela)  Google Search'
				WHEN 114 THEN 'Spanish (Chile)  Google Display'
				WHEN 115 THEN 'Spanish (Chile)  Google Search'
				WHEN 116 THEN 'Spanish (Guatemala)  Google Display'
				WHEN 117 THEN 'Spanish (Guatemala)  Google Search'
				WHEN 118 THEN 'Spanish (Ecuador)  Google Display'
				WHEN 119 THEN 'Spanish (Ecuador)  Google Search'
				WHEN 120 THEN 'GetApp.com'
				WHEN 121 THEN 'Cloud Alliance for Google Apps'			
				WHEN 122 THEN 'China - Google Display'
				WHEN 123 THEN 'China - Google Search'
				WHEN 124 THEN 'Russia - Google Display'
				WHEN 125 THEN 'Russia - Google Search'
				WHEN 126 THEN 'French (Tier 1) - Google Display'
				WHEN 127 THEN 'French (Tier 1) - Google Search'
				WHEN 128 THEN 'French (Tier 2) - Google Display'
				WHEN 129 THEN 'French (Tier 2) - Google Search'
				WHEN 130 THEN 'Portuguese (Brazil) - Google Display'
				WHEN 131 THEN 'Portuguese (Brazil) - Google Search'
				WHEN 132 THEN 'Portuguese (Portugal) - Google Display'
				WHEN 133 THEN 'Portuguese (Portugal) - Google Search'
				WHEN 134 THEN 'Box'
				WHEN 135 THEN '_Display - Managed Placements'
				WHEN 136 THEN 'Sitepoint'
				WHEN 137 THEN 'Brad Egeland'
				WHEN 138 THEN 'Google Drive'
				WHEN 139 THEN 'Crowdsourcing.org'
				WHEN 140 THEN 'Berklee School of Music'
				WHEN 141 THEN 'Google Adwords Sitelinks'
				WHEN 142 THEN 'AWS Marketplace'
				WHEN 143 THEN 'Google Mobile Search (iphone)'
				WHEN 144 THEN 'Google Mobile Search (non-iphone)'
				WHEN 145 THEN 'German - Google Display'
				WHEN 146 THEN 'German - Google Search'
				WHEN 147 THEN 'Italian - Google Display'
				WHEN 148 THEN 'Italian - Google Search'
				WHEN 149 THEN 'Enterprise Display Test - Spreadsheet Hell - Desktop'
				WHEN 150 THEN 'Enterprise Display Test - Spreadsheet Hell - Mobile'
				WHEN 151 THEN '_Display - Managed Placements - Tier 1 International'
				WHEN 152 THEN '_Display - Managed Placements - Tier 2 International'
				WHEN 153 THEN 'Google Display - Interest Targeted'
				WHEN 154 THEN 'Web Forms - Powered by Smartsheet'
				WHEN 155 THEN 'Published Sheet - Powered by Smartsheet'
				WHEN 156 THEN '_Google Search - International - Tier 1'
				WHEN 157 THEN '_Google Search - International - Tier 2'
				WHEN 158 THEN 'Apple App Store'
				WHEN 159 THEN 'Android App Store'
				WHEN 160 THEN 'BlueKai - (Google)'
				WHEN 161 THEN 'Similar Audiences - (Google)'	
				WHEN 162 THEN 'Gmail Ads'	
				WHEN 163 THEN 'Branded PPC (Bing)'	
				WHEN 164 THEN 'Google Business Category Display'
				WHEN 165 THEN 'Elizabeth Harrin (blog posse)'
				WHEN 166 THEN 'Video for Adwords'
				WHEN 167 THEN 'Robert Kelly (blog posse)'
				WHEN 168 THEN 'Lindsay Scott (blog posse)'
				WHEN 169 THEN 'Seattle GEO Target (Google Search)'
				WHEN 170 THEN 'Seattle GEO Target (Bing Search)'
				WHEN 171 THEN 'Seattle GEO Target (Google Display Image)'
				WHEN 172 THEN 'Seattle GEO Target (Bing Content)'
				WHEN 173 THEN 'Seattle GEO Target (Google Text Display)'
				WHEN 174 THEN 'Google Display - Image Ads'
				WHEN 175 THEN 'Google Display - Text Ads'
				WHEN 176 THEN 'Google Display International - Text Ads'
				WHEN 177 THEN 'Google Display International - Image Ads'
				WHEN 178 THEN 'thesmallbusinessweb.com'
				WHEN 179 THEN 'Centrify'
				WHEN 180 THEN 'Social Media Coordinator - Keri'
				WHEN 181 THEN 'Geekwire'
				WHEN 182 THEN 'USA Today'
				WHEN 183 THEN 'Pac NW Soccer'
				WHEN 184 THEN 'LinkedIn InMail'
				WHEN 185 THEN 'NAPS'
				WHEN 186 THEN 'Google Search Companion Marketing'
				WHEN 187 THEN 'Google Search Companion Marketing (International)'
				WHEN 188 THEN 'Kindle'
				WHEN 189 THEN 'Google Play Store'
				WHEN 190 THEN 'Zapier'
				WHEN 191 THEN 'Dropbox'
				WHEN 192 THEN '123 Contact Form'
				WHEN 193 THEN 'Twitter (paid)'
				WHEN 194 THEN 'Stack Overflow'
				WHEN 195 THEN 'DemandMetric.com'
				WHEN 196 THEN 'Similar Audiences (Google) - International'
				WHEN 197 THEN 'Google Display - Interest Targeted (International)'
				WHEN 198 THEN 'ProjectManagers.net'
				WHEN 199 THEN 'ProjectsAtWork.com'
				WHEN 200 THEN 'ProjectManagement.com'
				WHEN 201 THEN 'Slideshare.net'
				WHEN 202 THEN 'LinkedIn International (paid)'
				WHEN 203 THEN 'Bing Search - International - Tier 1'
				WHEN 204 THEN 'Bing Search - French'
				WHEN 205 THEN 'Bing Search - German'
				WHEN 206 THEN 'Bing Search - Portuguese (Brazil)'
				WHEN 207 THEN 'Bing Search - Portuguese (Portugal)'
				WHEN 208 THEN 'Bing Search - Spanish'
				WHEN 209 THEN 'Bing Search - Italian'
				WHEN 210 THEN 'Google Search - Russian'
				WHEN 211 THEN 'Marketo Launchpoint'
				WHEN 212 THEN 'Gmail Ads - International'
				WHEN 213 THEN 'Bing Display - Text Ads (USA)'
				WHEN 214 THEN 'Bing Display - Text Ads (English Not USA)'
				WHEN 215 THEN 'Bing Sitelinks'
				WHEN 216 THEN 'Docusign'
				WHEN 217 THEN 'Yandex (paid)'
				WHEN 218 THEN 'MailChimp'
				WHEN 219 THEN 'Harvest'
				WHEN 220 THEN 'Evernote'
				WHEN 221 THEN 'Amazon Mechanical Turk'
				WHEN 222 THEN 'AppGuru'
				WHEN 223 THEN 'Backupify'
				WHEN 224 THEN 'Bitium'
				WHEN 225 THEN 'Easy Insight'
				WHEN 226 THEN 'OneLogin'
				WHEN 227 THEN 'PingOne'
				WHEN 228 THEN 'Klipfolio'
				WHEN 229 THEN 'Tools4ever'
				WHEN 230 THEN 'Okta'
				WHEN 231 THEN 'Spiceworks'
				WHEN 232 THEN 'Third Party Authorization Flow'
				WHEN 233 THEN 'BetterCloud'
				WHEN 234 THEN 'Smartsheet Merge (Google Docs Add-on)'
				WHEN 235 THEN 'Smartsheet Forms (Google Forms Add-on)'
				WHEN 236 THEN 'Display - Select Keyword'
				WHEN 237 THEN 'Display - Select Keyword (International)'
				WHEN 238 THEN 'Google Search - Japanese'
				WHEN 239 THEN 'Microsoft'
				WHEN 240 THEN 'Yahoo Japan'
				WHEN 241 THEN 'Wave'
				WHEN 242 THEN 'Microsoft Office 365/Azure Marketplace'
				WHEN 243 THEN 'French - Display - Interest Targeted'
				WHEN 244 THEN 'Facebook (paid) - International EN'
				WHEN 245 THEN 'Google Display Japan'
				WHEN 246 THEN 'Japanese - Display - Interest Targeted'
				WHEN 247 THEN 'Russian - Display - Interest Targeted'
				WHEN 248 THEN 'Russian - Display'
				WHEN 249 THEN 'German - Display - Interest Targeted'
				WHEN 250 THEN 'Italian - Display - Interest Targeted'
				WHEN 251 THEN 'Portuguese (Brazil) - Display - Interest Targeted'
				WHEN 252 THEN 'Portuguese (Portugal) - Display - Interest Targeted'
				WHEN 253 THEN 'Spanish - Display - Interest Targeted'
				WHEN 254 THEN 'Cloud Sherpas'
				WHEN 255 THEN 'gPartner'
				WHEN 256 THEN 'Business Cloud'
				WHEN 257 THEN 'Cirruseo'
				WHEN 258 THEN 'Google general'
				WHEN 259 THEN 'Microsoft Office Store'
				WHEN 260 THEN 'Yahoo Display - Native Ads'
				WHEN 261 THEN 'Capterra'
				WHEN 262 THEN 'School of Bookkeeping'
				WHEN 263 THEN 'Box'
				WHEN 264 THEN 'Microsoft Referral'
				WHEN 265 THEN 'Microsoft Referral 0365 Launcher'
				WHEN 266 THEN 'GetApp Paid'
				WHEN 267 THEN 'Puget Sound PMI'
				WHEN 268 THEN 'Project-Management.com'
				WHEN 269 THEN 'Solution Center Brochure'
				WHEN 270 THEN 'FindtheBest Paid'
				WHEN 271 THEN 'Yahoo Search'
				WHEN 272 THEN 'Yahoo Search INT'
				WHEN 273 THEN 'Integrated Content Pages'
				WHEN 274 THEN 'Solution Center'
				WHEN 275 THEN 'Softline India'
				WHEN 276 THEN 'DoubleClick Campaign Manager'
				WHEN 277 THEN 'DoubleClick Interest Targeted'
				WHEN 278 THEN 'DoubleClick Context Matched'
				WHEN 279 THEN 'DoubleClick Manual Placement'
				WHEN 280 THEN 'Projects At Work'
				WHEN 281 THEN 'LinkedIn remarketing platform'
				WHEN 282 THEN 'Google Display - In-Market Audience'
				WHEN 283 THEN 'Google Display - In-Market Audience (INT)'
				WHEN 284 THEN 'StackOverflow'
				WHEN 285 THEN 'Instagram(Paid)'
				WHEN 286 THEN 'YouTube Promoted Videos (INT)'
				WHEN 287 THEN 'Techcrunch'
				WHEN 288 THEN 'Cyberco Procore Connector'
				WHEN 289 THEN 'Rolex Sydney Yacht Race'
				WHEN 290 THEN 'G2 Crowd (paid)'
				WHEN 291 THEN 'Google Product Listing Ads'
				WHEN 292 THEN 'Microsoft Teams signup'
				WHEN 293 THEN 'SalesForce AppExchange signups'
				WHEN 294 THEN 'Project Vision Dynamics USA'
				WHEN 295 THEN 'SoftwareONE Chile'
				WHEN 296 THEN 'SoftwareONE Brazil'
				WHEN 297 THEN 'SoftwareONE Argentina'
				WHEN 298 THEN 'eSource Mexico'
				WHEN 299 THEN 'Comparex Germany'
				WHEN 300 THEN 'Searce India'
				WHEN 301 THEN 'Softline Malaysia'
				WHEN 302 THEN 'Softline Thailand'
				WHEN 303 THEN 'Softline Vietnam'
				WHEN 304 THEN 'Softline Korea'
				WHEN 305 THEN 'SoftwareONE USA'
				WHEN 306 THEN 'Mbizer Singapore'
				WHEN 307 THEN 'Six Step Australia'
				WHEN 308 THEN 'Cardinal Consulting Australia'
				WHEN 309 THEN 'SoftwareONE Uruguay'
				WHEN 310 THEN 'SoftwareOne UK'
				WHEN 311 THEN 'SoftwareOne France'
				WHEN 312 THEN 'SoftwareONE Japan'
				WHEN 313 THEN 'Softline Philippines'
				WHEN 314 THEN 'Smartsheet Channel Partners'
				WHEN 315 THEN '57network'
				WHEN 316 THEN 'Insight'
				WHEN 317 THEN 'Seam Labs'
				WHEN 318 THEN 'Gmail AddOn Integration'
				WHEN 319 THEN 'Quip Integration'
				WHEN 320 THEN 'Google Adwords US FL'
				WHEN 321 THEN 'Comparex India'
				WHEN 322 THEN 'Softline India'
				WHEN 323 THEN 'Google Adwords UK'
				WHEN 324 THEN 'Outlook Add-In'
				ELSE CASE (src.item_Value = 'pm-sherpa')
					WHEN 1 THEN 'PM Sherpa'
					ELSE CASE TRY_TO_NUMBER(app_Launch_Parm1.item_Value)
						/* Distributed container IDs for affiliates only*/
						WHEN 1007049 THEN 'VA Network'
						WHEN 1003002 THEN 'VA Network'
						WHEN 1004022 THEN 'Veronica Conway'
						WHEN 1043072 THEN 'Veronica Conway'
						WHEN 1002982 THEN 'Officebundle.com'
						WHEN 1018093 THEN 'Regina Minger'
						WHEN 1024411 THEN 'Tradeshow Coach'
						WHEN 1034796 THEN 'Ki-Work'
						WHEN 1034806 THEN 'OnlineBizU'
						WHEN 1040910 THEN 'Success Connections'
						WHEN 1041452 THEN 'Baird Consulting'
						WHEN 1045303 THEN 'Biz Recipes'
						WHEN 1051958 THEN 'Assistant Match'
						WHEN 1053162 THEN 'Caroline Melville Society of Virtual Assistants'
						WHEN 1053163 THEN 'Caroline Melville Virtually Sorted'
					ELSE CASE myreferralValue.item_Value  IS NOT NULL  /* somebodys My Smartsheet Referral Link */
							WHEN 1 THEN 'My Smartsheet Referral'																					
						ELSE CASE WHEN state.item_Value LIKE '%outlookapp%' THEN 'OutlookApp Integration'
							WHEN state.item_Value LIKE '%evernote%'  THEN 'Evernote Integration'
							ELSE CASE referrerValue.item_Value LIKE '%aws.%'		/* considering amazon web services links as affiliate */
								WHEN 1 THEN 'Amazon Web Services'					
								ELSE CASE referrerValue.item_Value LIKE '%jott%'		/* considering jott links as affiliate */
									WHEN 1 THEN 'Jott'					
									ELSE CASE referrerValue.item_Value LIKE '%search%' OR referrerValue.item_Value LIKE '%www.google%' OR referrerValue.item_Value LIKE '%www.yahoo%' 
										OR referrerValue.item_Value LIKE '%www.bing%' OR referrerValue.item_Value LIKE '%yandex.ru%' OR referrerValue.item_Value LIKE '%duckduckgo%' OR query_Value.item_Value IS NOT NULL 		/* link opened from natural search */
										WHEN 1 THEN 'Organic Search'		
										ELSE CASE TRY_TO_NUMBER(app_Launch_Type.item_Value)
											WHEN 2 THEN 'Signup with Sharing Tracking Codes' 		/* grid - the user was shared a sheet, but the auto-login did not work so user signed up */
											/* WHEN 5 THEN 'Direct Navigation' 	- distributed container - let referral and search logic below apply */
											WHEN 6 THEN 'Signup with Sharing Tracking Codes'		/* workspace - the user was shared a workspace, but the auto-login did not work so user signed up */
											WHEN 10 THEN 'Google Drive - Import'		/* IMPORT_GOOGLE_DRIVE_FILE */
											WHEN 11 THEN 'Google Drive - New File'		/* NEW_GOOGLE_DRIVE_FILE */													ELSE CASE referrerValue.item_Value LIKE '%mail%'	 AND referrerValue.item_Value NOT LIKE '%-email%'	/* link opened from web mail client - not an article about email, someone sent them the link without other source info on link */
												WHEN 1 THEN 'Mail Link'			
												ELSE CASE referrerValue.item_Value IS NOT NULL AND referrerValue.item_Value != '' AND referrerValue.item_Value NOT LIKE '%smartsheet%'
													WHEN 1 THEN 'External Source Links' 
													/* ELSE CASE TRY_TO_NUMBER(app_Launch_Type.item_Value) 
													  WHEN 5 THEN 'Distributed Container' */		
													  ELSE 'Direct Navigation'
													/* END */																								
												END
											END
										END
									END
								END
							END
						END
					END
				END
			END
		END
	END
	END AS SubSourceFriendly,

   campaign.item_Value || ' - ' || IFF(campaignLookup.campaign_Description IS NULL, 'not found', campaignLookup.campaign_Description) AS Campaign, 
   segment.item_Value || ' - ' || IFF(segmentLookup.segment_Description IS NULL, 'not found', segmentLookup.segment_Description) AS Segment, 
   ad_Version.item_Value AS ad_Version, 
   NULL, /* toddj - not really used anymore - captcha.item_Value AS captcha, */
   landing_Page_Version.item_Value AS landing_Page_Version, 
   NULL, /* toddj - not really used anymore - submit_Button_Style.item_Value AS submit_Button_Style, */
   NULL, /* toddj - not really used anymore - signup_Extra_Text.item_Value AS signup_Extra_Text, */
   NULL AS Keyword,  /* process keyword in later UPDATE */
   referrerValue.item_Value AS Referrer, 
   app_Launch_Type.item_Value AS TYPE,
   app_Launch_Parm1.item_Value AS Parm1,
   container.name AS Parm1Friendly,
	
	SUBSTRING(query_Value.item_Value, 1, 150)  AS "QUERY",

	myreferralValue.item_Value AS my_Smartsheet_Referral_Link,
	x.email_Address AS my_Smartsheet_Referral_Link_Friendly,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
       
FROM ACCOUNT.PUBLIC.signup_Request r 
	LEFT OUTER JOIN MAIN.rpt.signup_Source 								ON signup_Source.user_ID = r.user_ID
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	source 				ON r.signup_Request_ID = source.signup_Request_ID AND source.item_Type = 1 AND source.item_Name = 's'
	JOIN MAIN.rpt.signup_Request_Tracking_Item	referrerValue 		ON referrerValue.signup_Request_ID = r.signup_Request_ID AND referrerValue.item_Type = 1 AND referrerValue.item_Name = 'referrerValue'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	query_Value 			ON query_Value.signup_Request_ID 		= r.signup_Request_ID AND query_Value.item_Type = 1 AND query_Value.item_Name = 'query_Value'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	myreferralValue 	ON myreferralValue.signup_Request_ID 	= r.signup_Request_ID AND myreferralValue.item_Type = 1 AND myreferralValue.item_Name = 'u'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	src 				ON src.signup_Request_ID 	= r.signup_Request_ID AND src.item_Type = 1 AND src.item_Name = 'src'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	app_Launch_Type 		ON app_Launch_Type.signup_Request_ID = r.signup_Request_ID AND app_Launch_Type.item_Type = 2 AND app_Launch_Type.item_Name = 'Type'
	LEFT OUTER JOIN MAIN.PUBLIC.user_Account					 	user_Account 		ON user_Account.user_ID = r.user_ID

	/* remaining joins are not needed for the bucketing process, they just provide extra info that could be done after this big query */
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	campaign 			ON r.signup_Request_ID = campaign.signup_Request_ID AND campaign.item_Type = 1 AND campaign.item_Name = 'c'
		LEFT OUTER JOIN MAIN.ref.campaign_Lookup 			campaignLookup 		ON TRY_TO_NUMBER(campaign.item_Value) = campaignLookup.campaign_ID
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	app_Launch_Parm1 		ON r.signup_Request_ID = app_Launch_Parm1.signup_Request_ID AND app_Launch_Parm1.item_Type = 2 AND app_Launch_Parm1.item_Name = 'Parm1'
		LEFT OUTER JOIN CORE.PUBLIC.container 					container 			ON TRY_TO_NUMBER(app_Launch_Parm1.item_Value) = container.container_ID AND container.container_ID <= $NewMaxContainer_IDModify
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	segment 			ON r.signup_Request_ID = segment.signup_Request_ID	AND segment.item_Type = 1 AND segment.item_Name = 'm'
		LEFT OUTER JOIN MAIN.ref.campaign_Segment_Lookup 	segmentLookup 		ON TRY_TO_NUMBER(segment.item_Value) = segmentLookup.segment_ID
		
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	landing_Page_Version 	ON landing_Page_Version.signup_Request_ID = r.signup_Request_ID AND landing_Page_Version.item_Type = 1 AND landing_Page_Version.item_Name = 'lpv'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	ad_Version 			ON r.signup_Request_ID = ad_Version.signup_Request_ID AND ad_Version.item_Type = 1 AND ad_Version.item_Name = 'a'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	state 				ON r.signup_Request_ID = state.signup_Request_ID AND state.item_Type = 1 AND state.item_Name = 'state'

	/* toddj - not really used anymore, commented out for now */
/*	JOIN MAIN.rpt.signup_Request_Tracking_Item 	captcha 			ON captcha.signup_Request_ID = r.signup_Request_ID AND captcha.item_Type = 1 AND captcha.item_Name = 'cv'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	submit_Button_Style 	ON submit_Button_Style.signup_Request_ID = r.signup_Request_ID AND submit_Button_Style.item_Type = 1 AND submit_Button_Style.item_Name = 'sbs'
	JOIN MAIN.rpt.signup_Request_Tracking_Item 	signup_Extra_Text 	ON signup_Extra_Text.signup_Request_ID = r.signup_Request_ID AND signup_Extra_Text.item_Type = 1 AND signup_Extra_Text.item_Name = 'sxt'
*/
LEFT OUTER JOIN MAIN.PUBLIC.user_Account x ON x.user_ID = TRY_TO_NUMBER(SUBSTR(myreferralValue.item_Value, 3))
WHERE r.result_Status = 1 AND  r.user_ID IS NOT NULL 	/* only process good records */
	AND r.signup_Request_ID > $signup_Request_ID		/* only process those that have not yet been processed */
	AND r.signup_Request_ID <= $NewMaxsignup_Request_ID 
	AND signup_Source.user_ID IS NULL			/* if one only exists for the user, don't process another, it will error out */
GROUP BY r.user_ID,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Source insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/************** finished inserts, now processing updates **************************/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Source update'));

/* fix sub-source for these outliers before looking up the source, buckt */

UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.sub_Source_Friendly = 'Chrome Web Store'
FROM MAIN.rpt.signup_Request_Tracking_Item 	app_Launch_Type

WHERE signup_Source.sub_Source_Friendly = 'Direct Navigation' 
AND signup_Source.signup_Insert_Date_Time < TO_DATE('2013-03-01')   /* don't assume all going forward are from Chrome Web Store, but all from past are. */
AND app_Launch_Type.item_Value = 12  /* GETTING_STARTED_SHEET */
AND signup_Source.signup_Request_ID > $signup_Request_ID
AND  app_Launch_Type.signup_Request_ID = signup_Source.signup_Request_ID AND app_Launch_Type.item_Type = 2 AND app_Launch_Type.item_Name = 'Type';		/* only process those that have not yet been processed */


/* Set the source based on the subsource */
UPDATE MAIN.rpt.signup_Source signup_Source
SET signup_Source.source_Friendly = MAIN.PUBLIC.SMARTSHEET_GET_SOURCE(signup_Source.sub_Source_Friendly)
WHERE signup_Source.signup_Request_ID > $signup_Request_ID;		/* only process those that have not yet been processed */

/* Now set the bucket based on the source */
UPDATE MAIN.rpt.signup_Source signup_Source
SET signup_Source.bucket = MAIN.PUBLIC.SMARTSHEET_GET_BUCKET(signup_Source.source_Friendly)
WHERE signup_Source.signup_Request_ID > $signup_Request_ID;		/* only process those that have not yet been processed */

/* Code for new viral sourcing 5-5-16 */ 
DROP TABLE IF EXISTS MAIN.stg.viral_Sourcing_Signups;
CREATE TABLE IF NOT EXISTS MAIN.stg.viral_Sourcing_Signups
(user_ID BIGINT,
insert_By_User_ID BIGINT,
domain VARCHAR,
insert_By_User_Domain VARCHAR,
is_ISP BOOLEAN,
insert_By_User_Is_ISP BOOLEAN,
source_Friendly VARCHAR,
PRIMARY KEY (user_ID));

INSERT INTO MAIN.stg.viral_Sourcing_Signups
SELECT ss.user_ID, u.insert_By_User_ID, u.domain, uu.domain AS inserterDomain, 
CASE WHEN isp1.domain IS NOT NULL THEN 1 ELSE 0 END AS is_ISP,
CASE WHEN isp2.domain IS NOT NULL THEN 1 ELSE 0 END AS sharerIs_ISP,
CASE WHEN isp1.domain IS NOT NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to ISP)'
	WHEN isp1.domain IS NOT NULL AND isp2.domain IS NULL THEN 'Sharing (Org to ISP)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to Org)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain = uu.domain THEN 'Sharing (Org to Org In Domain)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain != uu.domain THEN 'Sharing (Org to Org Out Domain)'
		END AS source_Friendly
FROM MAIN.rpt.signup_Source ss
JOIN MAIN.PUBLIC.user_Account u ON ss.user_ID = u.user_ID
JOIN MAIN.PUBLIC.user_Account uu ON uu.user_ID = u.insert_By_User_ID
LEFT JOIN MAIN.arc.ISPDomains isp1 ON isp1.domain = u.domain
LEFT JOIN MAIN.arc.ISPDomains isp2 ON isp2.domain = uu.domain
WHERE ss.sub_Source_Friendly = 'Signup Inserted by Smartsheet User'
AND ss.signup_Request_ID > $signup_Request_ID
; 


UPDATE MAIN.rpt.signup_Source ss
SET ss.source_Friendly = vss.source_Friendly
FROM MAIN.stg.viral_Sourcing_Signups vss

WHERE  vss.user_ID = ss.user_ID
;


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.ip_Address = 
	CASE WHEN POSITION (ip_Address.item_Value, ',' ) > 0
		THEN SPLIT_PART(ip_Address.item_Value, ',', 1) 
		ELSE ip_Address.item_Value
	END
FROM MAIN.rpt.signup_Request_Tracking_Item ip_Address

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = ip_Address.signup_Request_ID AND ip_Address.item_Type = 3 AND ip_Address.item_Name = 'ip';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.url = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Type = 1 AND srti.item_Name = 'url';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.placement =  REGEXP_REPLACE(srti.item_Value, '^www.')
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Type = 1 AND srti.item_Name = 'plc';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.ad_Position = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Type = 1 AND srti.item_Name = 'adp';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.match_type = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Type = 1 AND srti.item_Name = 'mtp';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.network = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Type = 1 AND srti.item_Name = 'net';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.dev = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'dev';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.devm = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'devm';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.mkwid = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'mkwid';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.gclid = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'gclid';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.keyword = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'k';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.slk = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'slk';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.ad_id = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'ad';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.phrase_id = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'phrase';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.campaign_id = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'campaign';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.key = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'key';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.position = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'pos';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.position_type = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'block';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.addphrases = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'added';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.source_type = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'type';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.trp_Value = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'trp';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.api_Client_ID = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'client_ID';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.optimizely_Exp_ID = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'optimizely_Buckets';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.slp = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'slp';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.lpa = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'lpa';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.lang = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'lang';		/* only process those that have not yet been processed */

UPDATE MAIN.rpt.signup_Source signup_Source
SET signup_Source.web_Page = 
	CASE signup_Source.url IS NULL
		WHEN 1 THEN REGEXP_REPLACE(REGEXP_REPLACE(signup_Source.referrer, '^https://'), '^http://')
		ELSE  REGEXP_REPLACE(REGEXP_REPLACE(signup_Source.url, '^https://'), '^http://')
	END
WHERE signup_Source.signup_Request_ID > $signup_Request_ID;		/* only process those that have not yet been processed */

UPDATE MAIN.rpt.signup_Source signup_Source
SET signup_Source.web_Site = SPLIT_PART(web_Page, '/', 1)
WHERE signup_Source.signup_Request_ID > $signup_Request_ID;		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.first_Name = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_fname';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.last_Name = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_lname';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.phone = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_phone';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.company = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_company';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.title = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_title';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.role = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'su_role';		/* only process those that have not yet been processed */


UPDATE MAIN.rpt.signup_Source signup_Source
SET  signup_Source.exp = srti.item_Value
FROM MAIN.rpt.signup_Request_Tracking_Item srti

WHERE signup_Source.signup_Request_ID > $signup_Request_ID 
AND  signup_Source.signup_Request_ID = srti.signup_Request_ID AND srti.item_Name = 'exp';		/* only process those that have not yet been processed */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Source update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** ref_ip_AddressInfo table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/* Start MAIN.ref.ip_Address_Info */

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.ref.ip_Address_Info insert'));

SET maxSessionId = (SELECT  MAX(session_Log_ID) FROM MAIN.rpt.session_Log );

/* push the new ip_Addresses into the info table */
INSERT INTO MAIN.ref.ip_Address_Info(
  ip_Address)
SELECT DISTINCT
/* cleanse ip_Address that have multiple inline before inserting*/
CASE WHEN  POSITION(signup_Source.ip_Address, ',' ) > 0
		THEN SPLIT_PART(signup_Source.ip_Address, ',', 1) 
		ELSE signup_Source.ip_Address
	END
FROM MAIN.rpt.signup_Source       
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ip_Address_Info ON ip_Address_Info.ip_Address = CASE WHEN POSITION(signup_Source.ip_Address, ',' ) > 0
		THEN SPLIT_PART(signup_Source.ip_Address, ',', 1) 
		ELSE signup_Source.ip_Address
	END
WHERE signup_Source.ip_Address IS NOT NULL AND ip_Address_Info.ip_Address IS NULL /* only do ip_Addresses we have not looked up already */
AND signup_Source.signup_Request_ID > $signup_Request_ID;		/* only process those that have not yet been processed */



INSERT /*IGNORE*/ INTO MAIN.ref.ip_Address_Info (ip_Address)
SELECT DISTINCT 
CASE WHEN POSITION(user_IPLocation.ip_Number, ',') > 0
	THEN SPLIT_PART(user_IPLocation.ip_Number, ',', 1)
	ELSE user_IPLocation.ip_Number
	END
FROM MAIN.rpt.user_IPLocation
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ip_Address_Info ON ip_Address_Info.ip_Address = CASE WHEN POSITION(user_IPLocation.ip_Number, ',') > 0
	THEN SPLIT_PART(user_IPLocation.ip_Number, ',', 1)
	ELSE user_IPLocation.ip_Number
	END
WHERE ip_Address_Info.ip_Address IS NULL
;

INSERT /*IGNORE*/ INTO MAIN.ref.ip_Address_Info(
  ip_Address)
SELECT DISTINCT
CASE WHEN  POSITION(session_Log.source_IP, ',' ) > 0
		THEN SPLIT_PART(session_Log.source_IP, ',', 1) 
		ELSE session_Log.source_IP
	END
FROM MAIN.rpt.session_Log      
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ip_Address_Info ON ip_Address_Info.ip_Address = CASE WHEN POSITION(session_Log.source_IP, ',' ) > 0
		THEN SPLIT_PART(session_Log.source_IP, ',', 1) 
		ELSE session_Log.source_IP
	END
WHERE session_Log.source_IP IS NOT NULL AND ip_Address_Info.ip_Address IS NULL /* only do ip_Addresses we have not looked up already */
AND session_Log.session_Log_ID > $maxSessionId;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.ref.ip_Address_Info insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.ref.ip_Address_Info update'));

/* update the batch that was marked, we do this in two steps because you cannot put a LIMIT clause on an UPDATE that has a JOIN */

UPDATE MAIN.ref.ip_Address_Info ip_Address_Info
SET  
  ip_Address_Info.country_Name = country.country_Name,
  ip_Address_Info.region_Name = region.region_Name,
  ip_Address_Info.city = ip_Location.city
FROM MAIN.ref.ip_Number ip_Number
LEFT OUTER JOIN MAIN.ref.ip_Location ip_Location ON ip_Number.loc_Id = ip_Location.loc_Id
LEFT OUTER JOIN MAIN.ref.country country ON ip_Location.country = country.country_Code
LEFT OUTER JOIN MAIN.ref.region region ON ip_Location.country = region.country_Code AND ip_Location.region = region.region_Code
  
WHERE ip_Address_Info.country_Name IS NULL
AND  MAIN.PUBLIC.INET_ATON(ip_Address_Info.ip_Address) = ip_Number.ip_Number
;  /* only do ip_Addresses we have not looked up already */

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.ref.ip_Address_Info update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


/* update rpt_signup_Source to include ip locations*/
/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.signup_Source ip location update'));


UPDATE MAIN.rpt.signup_Source ss
SET  ss.IP_Country=ref.country_Name
FROM MAIN.ref.ip_Address_Info ref

WHERE ss.IP_Country IS NULL

AND  ss.ip_Address=ref.ip_Address;


UPDATE MAIN.rpt.signup_Source ss
SET  ss.IP_Region=ref.region_Name
FROM MAIN.ref.ip_Address_Info ref

WHERE ss.IP_Region IS NULL

AND  ss.ip_Address=ref.ip_Address;


UPDATE MAIN.rpt.signup_Source ss
SET  ss.IP_City=ref.city
FROM MAIN.ref.ip_Address_Info ref

WHERE ss.IP_City IS NULL

AND  ss.ip_Address=ref.ip_Address;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.signup_Source ip location update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** rpt_session_Log table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.session_Log*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.session_Log'));


/*DROP TABLE IF EXISTS MAIN.rpt.session_Log;*/
 CREATE TABLE IF NOT EXISTS 
  MAIN.rpt.session_Log(
	 /* these fields are straight from the session_Log table */
 	session_Log_ID BIGINT, 
	 user_ID BIGINT, 
	 email_Address VARCHAR, 
	 login_Type VARCHAR (50),
 	login_Auth_Result VARCHAR (50),
	 source_IP VARCHAR,
	 insert_Date_Time DATETIME, 
	 signout_Date_Time DATETIME, 
	 
 	/* these fields are calculated */
	 insert_Date_Time_PT DATETIME, 
	 signout_Date_Time_PT DATETIME, 
	 session_Length INTEGER, 
	 session_Action_Count INT,
	 session_Error_Count INT,
	 browser VARCHAR,
	 browser_Bucket VARCHAR,
	 operating_System VARCHAR,
	 device VARCHAR,
	 user_Agent VARCHAR/***,
	 index (user_ID)***//***,
	 INDEX (insert_Date_Time)***/,
	 PRIMARY KEY(session_Log_ID));

/*When adding new terms to BrowserName, BroswerBucket or BrowserDevice fucntions, TRUNCATE TABLE and so that it will fill with all new data from arc_session_Log*/

/* find starting point for new users */
 SET max_Session_Log_ID = (SELECT  MAX(session_Log_ID) FROM MAIN.rpt.session_Log  );  /*Appends rpt_session_Log with new data from arc_session_Log, a longer repository than CORE.PUBLIC.session_Log*/
 
 /* for startup case, if null convert to 0 */
 SET max_Session_Log_ID = (SELECT  IFF($max_Session_Log_ID IS NULL, 0, $max_Session_Log_ID) );
 
 ALTER SESSION SET AUTOCOMMIT = FALSE;
 INSERT INTO MAIN.rpt.session_Log(
	 session_Log_ID, 
	 user_ID, 
	 email_Address, 
	 login_Type, 
 	login_Auth_Result, 
	 source_IP, 
	 insert_Date_Time, 
	 signout_Date_Time, 
	 insert_Date_Time_PT, 
	 signout_Date_Time_PT, 
	 session_Length, 
	 session_Action_Count, 
	 session_Error_Count, 
	 browser, 
	 browser_Bucket, 
	 operating_System, 
	 device, 
	 user_Agent)
 SELECT session_Log.session_Log_ID,
	 session_Log.user_ID,
	 session_Log.email_Address,
	 MAIN.PUBLIC.SMARTSHEET_LOGINTYPENAME(session_Log.login_Type) AS "login_Type",
	 MAIN.PUBLIC.SMARTSHEET_AUTHRESULT(session_Log.login_Auth_Result) AS "login_Auth_Result",
	 session_Log.source_IP,
	 session_Log.insert_Date_Time,
	 session_Log.sign_out_Date_Time,
 
	 DATEADD(HOUR, -7, session_Log.insert_Date_Time),
	 DATEADD(HOUR, -7, session_Log.sign_Out_Date_Time),
	 CASE session_Log.sign_Out_Date_Time IS NULL
	 	WHEN 0 THEN DATE_PART(EPOCH_SECOND, session_Log.sign_Out_Date_Time) - DATE_PART(EPOCH_SECOND, session_Log.insert_Date_Time)
	 	ELSE NULL
	 END,
	 0, /*(select count(*) from LOG.PUBLIC.request_Log rl where form_Action = 'gl' and rl.session_Log_ID = session_Log.session_Log_ID), */
	 0, /*(select count(*) from LOG.PUBLIC.request_Log rl where form_Action = 'gl' and rl.session_Log_ID = session_Log.session_Log_ID
														and rl.parm3 like 'js_stack_trace%'),  */
   MAIN.PUBLIC.SMARTSHEET_BROWSERNAME(session_Log.user_Agent) AS "Browser",
   MAIN.PUBLIC.SMARTSHEET_BROWSERBUCKET(session_Log.user_Agent) AS "Browser Bucket",
   MAIN.PUBLIC.SMARTSHEET_BROWSEROS(session_Log.user_Agent) AS "Operating System",
   MAIN.PUBLIC.SMARTSHEET_BROWSERDEVICE(session_Log.user_Agent) AS "Device",
	 user_Agent
        
 FROM MAIN.arc.session_Log session_Log
 WHERE session_Log_ID > $max_Session_Log_ID
 ;
 COMMIT;
 ALTER SESSION SET AUTOCOMMIT = TRUE;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.session_Log')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** rpt_login_Count_Total table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start MAIN.rpt.login_Count_Total*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.login_Count_Total insert'));

SET maxMobile = (SELECT  MAX(session_Log_ID) FROM MAIN.rpt.native_App_Sessions );

INSERT /*IGNORE*/ INTO MAIN.rpt.native_App_Sessions
SELECT * FROM MAIN.rpt.session_Log
WHERE browser_Bucket IN('Native iOS App', 'Native Android App') AND login_Auth_Result = 'SUCCESS'
AND session_Log_ID > $maxMobile;


SET max_Modify_Date_Time = (SELECT  MAX(modify_Date_Time)::VARCHAR FROM MAIN.PUBLIC.user_Account );

DROP TABLE IF EXISTS MAIN.rpt.login_Count_Total;
CREATE TABLE IF NOT EXISTS MAIN.rpt.login_Count_Total(
	user_ID 	BIGINT, 
	first_Session_Log_ID INT, 
	first_Login DATETIME, 
	first_Login_Year INT, 
	first_Login_Month VARCHAR, 
	first_Login_Week VARCHAR, 	
	first_Login_Day VARCHAR, 
	last_Session_Log_ID INT,
	last_Login DATETIME, 	
	last_Login_Year INT, 
	last_Login_Month VARCHAR, 
	last_Login_Week VARCHAR, 	
	last_Login_Day VARCHAR, 
	days_Since_First_Login INT, 
	days_Since_Last_Login INT, 
	days_Active INT, 
	login_Count INT, 
	login_Strength NUMERIC(38,18), 
	user_Logged_In_At_Least_Once BOOLEAN, 
	user_Logged_In_At_Least_Twice BOOLEAN, 
	user_Logged_In_At_Least4times BOOLEAN, 
	user_Logged_In_At_Least8times BOOLEAN,
	last_Mobile_Login DATETIME,
	native_Ios_Session_Count INT,
	native_Android_Session_Count INT,
	PRIMARY KEY(user_ID));

INSERT INTO MAIN.rpt.login_Count_Total(
	user_ID, 
	first_Session_Log_ID, 
	first_Login, 
	first_Login_Year,
	first_Login_Month, 
	first_Login_Week, 
	first_Login_Day,
	last_Session_Log_ID,
	last_Login, 
	last_Login_Year,
	last_Login_Month, 
	last_Login_Week, 
	last_Login_Day,	
	days_Since_First_Login, 
	days_Since_Last_Login, 
	days_Active,
	login_Count, 
	login_Strength,
	user_Logged_In_At_Least_Once,
	user_Logged_In_At_Least_Twice,
	user_Logged_In_At_Least4times,
	user_Logged_In_At_Least8times)

SELECT 
	usa.user_ID, 
	usa.first_Session_ID, 
	
	usa.first_Session_Date_Time, 
	TO_VARCHAR(usa.first_Session_Date_Time, 'YYYY'), 
	TO_VARCHAR(usa.first_Session_Date_Time, 'YYYY*MM(mon)'),
	MAIN.PUBLIC.SMARTSHEET_WEEK(usa.first_Session_Date_Time), 
	TO_VARCHAR(usa.first_Session_Date_Time , 'YYYY') || '*' || LPAD(MONTH(usa.first_Session_Date_Time),2,'0') || '*' || LPAD(DAYOFMONTH(usa.first_Session_Date_Time),2,'0'), 
	
	usa.last_Session_ID,	       
	usa.last_Session_Date_Time,
	TO_VARCHAR(usa.last_Session_Date_Time, 'YYYY'), 
	TO_VARCHAR(usa.last_Session_Date_Time, 'YYYY*MM(mon)'),
	MAIN.PUBLIC.SMARTSHEET_WEEK(usa.last_Session_Date_Time), 
	TO_VARCHAR(usa.last_Session_Date_Time , 'YYYY') || '*' || LPAD(MONTH(usa.last_Session_Date_Time),2,'0') || '*' || LPAD(DAYOFMONTH(usa.last_Session_Date_Time),2,'0'), 
	       	
	DATEDIFF(MINUTE, CURRENT_DATE(), usa.first_Session_Date_Time),
	DATEDIFF(MINUTE, CURRENT_DATE(), usa.last_Session_Date_Time),
	DATEDIFF(MINUTE, usa.last_Session_Date_Time, usa.first_Session_Date_Time),
	
	usa.session_Count, 
	usa.session_Count / (DATEDIFF(MINUTE, $max_Modify_Date_Time, usa.last_Session_Date_Time) + 3),

	CASE usa.session_Count >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.session_Count >= 2 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.session_Count >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.session_Count >= 8 
		WHEN 1 THEN 1
		ELSE 0
	END

FROM MAIN.arc.user_Session_Activity usa
;


DROP TABLE IF EXISTS MAIN.STG.MOBILE_APP_LOGIN_COUNTS;
CREATE TABLE IF NOT EXISTS MAIN.STG.MOBILE_APP_LOGIN_COUNTS
(user_ID BIGINT,
browser_Bucket VARCHAR,
last_Login DATETIME,
session_Count INT,
PRIMARY KEY (user_ID, browser_Bucket),
UNIQUE /*user_ID*/ (user_ID),
UNIQUE /*last_Login*/ (last_Login));


INSERT INTO MAIN.STG.MOBILE_APP_LOGIN_COUNTS
SELECT user_ID, browser_Bucket, MAX(sl.insert_Date_Time) AS "last_Mobile_Login", COUNT(sl.session_Log_ID) AS "Session_Count"
FROM MAIN.rpt.native_App_Sessions sl
GROUP BY 1,2
;

DROP TABLE IF EXISTS MAIN.STG.MOBILE_APP_MAX_DATES;
CREATE TABLE IF NOT EXISTS MAIN.STG.MOBILE_APP_MAX_DATES
(user_ID BIGINT,
maxMobileLogin DATETIME,
PRIMARY KEY (user_ID));

INSERT INTO MAIN.STG.MOBILE_APP_MAX_DATES
SELECT user_ID, MAX(last_Login)
FROM MAIN.STG.MOBILE_APP_LOGIN_COUNTS
GROUP BY 1;



UPDATE MAIN.rpt.login_Count_Total A
SET A.native_Ios_Session_Count = B.session_Count
FROM MAIN.STG.MOBILE_APP_LOGIN_COUNTS B

WHERE  A.user_ID = B.user_ID AND B.browser_Bucket = 'Native iOS App'
;


UPDATE MAIN.rpt.login_Count_Total A
SET A.native_Android_Session_Count = B.session_Count
FROM MAIN.STG.MOBILE_APP_LOGIN_COUNTS B

WHERE  A.user_ID = B.user_ID AND B.browser_Bucket = 'Native Android App'
;



UPDATE MAIN.rpt.login_Count_Total A
SET A.last_Mobile_Login = B.maxMobileLogin
FROM MAIN.STG.MOBILE_APP_MAX_DATES B

WHERE  A.user_ID = B.user_ID
;

DROP TABLE IF EXISTS MAIN.STG.MOBILE_APP_LOGIN_COUNTS;
DROP TABLE IF EXISTS MAIN.STG.MOBILE_APP_MAX_DATES;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.login_Count_Total insert')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.login_Count_Total update'));

/* Update last_LoginUserDate for a payment profile - we use the user's last login for standard accounts and the last login for all users in an org */
/* Update last_LoginUserDate for a payment profile - we use the user's last login for standard accounts and the last login for all users in an org */
ALTER SESSION SET AUTOCOMMIT = FALSE;

UPDATE MAIN.rpt.payment_Profile rp
SET  last_User_Login_Date = lc.last_Login
FROM MAIN.rpt.login_Count_Total lc

WHERE rp.account_Type != 3

AND  rp.source_User_ID = lc.user_ID;
COMMIT;


UPDATE MAIN.rpt.payment_Profile rp
SET rp.last_User_Login_Date =
 (SELECT MAX(lc.last_Login) 
	FROM MAIN.rpt.login_Count_Total lc
	  JOIN MAIN.rpt.payment_Profile_Contact cp ON lc.user_ID = cp.user_ID
	WHERE rp.payment_Profile_ID = cp.parent_Payment_Profile_ID)
WHERE rp.account_Type = 3
;
COMMIT;
ALTER SESSION SET AUTOCOMMIT = TRUE;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.login_Count_Total update')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

select '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
select '******** arc_ISPDomains table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.arc.ISPDomains'));

ALTER SESSION SET AUTOCOMMIT = FALSE;
INSERT /*IGNORE*/ INTO MAIN.arc.ISPDomains(domain, user_Count)
SELECT domain, COUNT(user_ID)
FROM MAIN.PUBLIC.user_Account

/*Continue regular check of domains in userAccount to see if new domains need to be added*/
WHERE user_Account.domain LIKE '%yahoo.%'
OR user_Account.domain LIKE '%yahoogroup%'
OR user_Account.domain LIKE '%yahoogrupos%'
OR user_Account.domain LIKE '%gmail.com%'
OR user_Account.domain LIKE '%yahoomail.%'
OR user_Account.domain LIKE 'live.%'
OR user_Account.domain LIKE 'hotmail.%'
OR user_Account.domain LIKE 'aol.co%'
OR user_Account.domain LIKE '%.rr.com'
OR user_Account.domain LIKE '%.net.il'
OR user_Account.domain LIKE '%comcast.net%'
OR user_Account.domain LIKE 'outlook.__'  
OR domain LIKE 'outlook.___'
OR domain LIKE 'outlook.__.__' 
OR domain LIKE 'outlook.___.__'
OR domain like 'dodo.com%'
OR user_Account.domain IN (
'10gen.com',
'123.com',
'126.com',
'139.com',
'163.com',
'aim.com',
'abv.bg',
'adinet.com.uy',
'alice.it',
'Aol.com', 
'absamail.co.za',
'att.net',
'bellsouth.net',
'bell.net',
'bex.net',
'bigpond.com',
'bigpond.net.au',
'bigpond.com.au',
'bluewin.ch',
'bk.ru',
'blueyonder.co.uk',
'bol.com.br',
'btconnect.com',
'btinternet.com',
'btopenworld.com',
'charter.net',
'comcast.net', 
'cox.net',
'earthlink.net',
'eircom.net',
'embarqmail.com',
'free.fr',
'globo.com',
'gmail.com',
'gmail.co',
'gamil.com',
'gmial.com',
'gmai.com',
'gmx.de',
'googlemail.com', 
'hanmail.net',
'hotmail.co.uk', 
'hotmail.com', 
'hotmail.es', 
'hotmail.fr', 
'hotmai.com',
'homail.com',
'hotmil.com',
'hotmal.com',
'hushmail.com',
'iafrica.com',
'ibest.com.br',
'icloud.com',
'ig.com.br',
'iinet.net.au',
'inbox.ru',
'juno.com',
'juno.com',
'laposte.net',
'libero.it',
'live.co.uk',
'live.com', 
'mac.com',
'mail.com',
'mail.ru',
'me.com',
'me.com',
'msn.com', 
'mweb.co.za',
'mymts.net',
'naver.com',
'northrock.bm',
'ntlworld.com',
'oi.com.br',
'optonline.net',
'optusnet.com.au',
'orange.fr',
'outlook.com',
'pobox.com',
'prodigy.net.mx',
'qq.com',
'reagan.com',
'rediffmail.com',
'roadrunner.com',
'rocketmail.com',
'rogers.com',
'sapo.pt',
'sbcglobal.net', 
'sfr.fr',
'shaw.ca',
'sky.com',
'sympatico.ca',
'talktalk.net',
'teksavvy.com',
'telus.net',
'terra.com.br',
'tiscali.co.uk',
'toast.net',
'uol.com.br',
'verizon.net', 
'videotron.ca',
'wanadoo.fr',
'web.de',
'westnet.com.au',
'xtra.co.nz',
'yandex.ru',
'ymail.com',
'zippy-uk.com',
'zippy-au.com',
'zippy-nz.com',
'cableone.net',
'cantv.net',
'centurylink.net',
'centurytel.net',
'clear.net.nz',
'cogeco.ca',
'csas.cz',
'eastlink.ca',
'email.com',
'etherstorm.net', 
'excite.com',
'fastmail.fm',
'foxmail.com',
'freemail.hu',
'freenet.de',
'frontier.com',
'frontiernet.net',
'fsmail.net',
'globomail.com',
'gmx.com',
'gmx.net',
'in.com',
'inbox.com',
'inbox.lv',
'insightbb.com',
'internode.on.net',
'iol.pt',
'iprimus.com.au',
'klarna.com',
'latinmail.com',
'mailinator.com',
'mindspring.com',
'nate.com',
'netscape.net',
'netspace.net.au',
'netzero.com',
'netzero.net',
'ziggo.nl',
'o2.co.uk',
'o2.pl',
'outlook.es',
'ozemail.com.au',
'pacbell.net',
'prodigy.net',
'q.com',
'r7.com',
'rambler.ru',
'rmqkr.net',
'sasktel.net',
'seznam.cz',
'sharklasers.com',
'suddenlink.net',
'talk21.com',
'tds.net',
'telefonica.net',
'telenet.be',
'telkomsa.net',
'tiscali.it',
'tpg.com.au',
'trbvm.com',
'usa.net',
'virgin.net',
'virginmedia.com',
'vodamail.co.za',
'voila.fr',
'vtr.net',
'walla.com',
'webmail.co.za',
'windowslive.com',
'windstream.net',
'wp.pl',
'y7mail.com',
'ya.ru',
'yopmail.com',
'mynet.com',
'consultant.com',
'yandex.com',
'qualityservice.com',
'pisem.net',
'mail333.com',
'photofile.ru',
'consultan',
'financier.com',
'europe.com',
'yeah.net',
'gmx.co.uk',
'vp.pl',
'myway.com',
'krovatka.su',
'post.cz',
'mail15.com',
'nightmail.ru',
'diplomats.com',
'op.pl',
'post.com',
'spoko.pl',
'memori.ru',
'pochtamt.ru',
'engineer.com',
'hafnet.dk',
'stofanet.dk',
'qip.ru',
'dcemail.com',
'tutanota.com',
'ziza.ru',
'counsellor.com',
'barid.com',
'fotoplenka.ru',
'secretary.net',
'kimo.com',
'accountant.com',
'e-mile.co.uk',
'rbcmail.ru',
'fromru.com',
'africamail.com',
'numericable.fr',
'lycos.com',
'consult',
'pochta.com',
'usa.com',
'mail2usa.com',
'uymail.com',
'fastservice.com',
'walla.co.il',
'planetmail.com',
'legislator.com',
'insurer.com',
'sina.cn',
'sina.com',
'sina.com.cn')

GROUP BY 1;
COMMIT;
ALTER SESSION SET AUTOCOMMIT = TRUE;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.arc.ISPDomains')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

select '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
select '******** rpt_userIPLocation table - start ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.user_IPLocation'));


CREATE TABLE IF NOT EXISTS MAIN.rpt.user_IPLocation
(
	user_ID INT,
	ip_Type VARCHAR,
	ip_Number VARCHAR,
	ip_Country VARCHAR,
	ip_Region VARCHAR,
	ip_City VARCHAR,
	PRIMARY KEY (user_ID),
	UNIQUE /*ix_ip_Country*/ (ip_Country),
	UNIQUE /*ix_ip_Region*/ (ip_Region),
	UNIQUE /*ix_ip_City*/ (ip_City),
	UNIQUE /*ix_ip_Type*/ (ip_Type)
)
;


-- Add users to IP table

SET maxUser_ID = (SELECT  MAX(user_ID)  FROM MAIN.rpt.user_IPLocation);

ALTER SESSION SET AUTOCOMMIT = FALSE;
INSERT INTO MAIN.rpt.user_IPLocation (user_ID)
SELECT DISTINCT ua.user_ID
FROM MAIN.PUBLIC.user_Account ua
LEFT OUTER JOIN MAIN.rpt.user_IPLocation ins ON ua.user_ID=ins.user_ID
WHERE ins.user_ID IS NULL
AND ua.user_ID >= $maxUser_ID
ORDER BY user_ID
;
COMMIT;


-- Add userIP addresses from signup source

UPDATE MAIN.rpt.user_IPLocation uic
SET  
	uic.ip_Type = 'Signup Source',
	uic.ip_Number  = ss.ip_Address,
	uic.ip_Country = ss.IP_Country,
	uic.ip_Region = ss.IP_Region,
	uic.ip_City = ss.IP_City
FROM MAIN.rpt.signup_Source ss

WHERE uic.ip_Country IS NULL

AND  uic.user_ID=ss.user_ID;
COMMIT;


-- Add userIP addresses from first sessions


UPDATE MAIN.rpt.user_IPLocation uic2
SET  
	uic2.ip_Type = 'First Session',
	uic2.ip_Number = sl.source_IP,
	uic2.ip_Country = ref.country_Name,
	uic2.ip_Region = ref.region_Name,
	uic2.ip_City = ref.city
FROM MAIN.rpt.login_Count_Total lct
JOIN MAIN.rpt.user_IPLocation uic ON lct.user_ID=uic.user_ID AND uic.ip_Country IS NULL
JOIN MAIN.arc.session_Log sl ON lct.first_Session_Log_ID=sl.session_Log_ID AND sl.source_IP IS NOT NULL
JOIN MAIN.ref.ip_Address_Info ref ON sl.source_IP=ref.ip_Address

WHERE uic2.ip_Country IS NULL

AND  uic2.user_ID = lct.user_ID
;
COMMIT;
ALTER SESSION SET AUTOCOMMIT = TRUE;


-- Add userIP addresses from last sessions
DROP TABLE IF EXISTS MAIN.stg.users_no_ip_country;

CREATE TABLE MAIN.stg.users_no_ip_country LIKE MAIN.rpt.user_IPLocation;

INSERT INTO MAIN.stg.users_no_ip_country
SELECT *
FROM MAIN.rpt.user_IPLocation
WHERE ip_Country IS NULL
;

-- ALTER TABLE MAIN.stg.users_no_ip_country ADD PRIMARY KEY (user_ID);

DROP TABLE IF EXISTS MAIN.stg.users_no_IP_last_Session;

CREATE TABLE MAIN.stg.users_no_IP_last_Session (user_ID bigint, max_Session_Log_ID bigint);

INSERT INTO MAIN.stg.users_no_IP_last_Session (user_ID, max_Session_Log_ID)
SELECT np.user_ID, ANY_VALUE(lct.last_Session_Log_ID) max_Session_Log_ID
FROM MAIN.stg.users_no_ip_country np
JOIN MAIN.rpt.login_Count_Total lct ON np.user_ID=lct.user_ID
GROUP BY 1
;

ALTER TABLE MAIN.stg.users_no_IP_last_Session ADD PRIMARY KEY (user_ID);

ALTER SESSION SET AUTOCOMMIT = FALSE;

UPDATE MAIN.rpt.user_IPLocation uic2
SET  
	uic2.ip_Type = 'Last Session',
	uic2.ip_Number = asl.source_IP,
	uic2.ip_Country = ref.country_Name,
	uic2.ip_Region = ref.region_Name,
	uic2.ip_City = ref.city
FROM MAIN.stg.users_no_IP_last_Session ms
JOIN MAIN.arc.session_Log asl ON asl.user_ID=ms.user_ID AND asl.session_Log_ID=ms.max_Session_Log_ID
JOIN MAIN.ref.ip_Address_Info ref ON asl.source_IP=ref.ip_Address

WHERE uic2.ip_Country IS NULL

AND  ms.user_ID = uic2.user_ID
;
COMMIT;

-- Remove users with no IP type or no IP number
DELETE FROM MAIN.rpt.user_IPLocation WHERE ip_Type IS NULL;
COMMIT;
DELETE FROM MAIN.rpt.user_IPLocation WHERE ip_Number IS NULL;
COMMIT;
ALTER SESSION SET AUTOCOMMIT = TRUE;

INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.rpt.user_IPLocation UPDATE'));

/*Create Table of NULL IP_Country users*/
CREATE TABLE MAIN.STG.USER_IP_LOCATION_UPDATE (user_ID bigint);
INSERT INTO MAIN.STG.USER_IP_LOCATION_UPDATE (user_ID)
SELECT user_Account.user_ID
FROM MAIN.PUBLIC.user_Account
LEFT OUTER JOIN MAIN.rpt.user_IPLocation ON user_Account.user_ID = user_IPLocation.user_ID
WHERE ip_Number IS NULL; 

/*Insert those with a signup*/
INSERT INTO MAIN.rpt.user_IPLocation
(user_ID, ip_Type, ip_Number, ip_Country, ip_Region, ip_City)
SELECT 
signup_Source.user_ID, 
'Signup Source',
ip_Address, 
IP_Country, 
IP_Region, 
IP_City
FROM MAIN.rpt.signup_Source
JOIN MAIN.STG.USER_IP_LOCATION_UPDATE ON signup_Source.user_ID = USER_IP_LOCATION_UPDATE.user_ID
WHERE ip_Country IS NOT NULL;

/*Insert those with a first_Session*/
INSERT INTO MAIN.rpt.user_IPLocation
(user_ID, ip_Type, ip_Number, ip_Country, ip_Region, ip_City)
SELECT 
USER_IP_LOCATION_UPDATE.user_ID, 'First Session', sl.source_IP, ref.country_Name, ref.region_Name, ref.city
FROM MAIN.rpt.login_Count_Total lct 
JOIN MAIN.STG.USER_IP_LOCATION_UPDATE ON lct.user_ID = USER_IP_LOCATION_UPDATE.user_ID
LEFT OUTER JOIN MAIN.arc.session_Log sl ON lct.first_Session_Log_ID = sl.session_Log_ID
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ref ON sl.source_IP = ref.ip_Address
LEFT OUTER JOIN MAIN.rpt.user_IPLocation uic ON USER_IP_LOCATION_UPDATE.user_ID = uic.user_ID

WHERE uic.ip_Number IS NULL
AND sl.source_IP IS NOT NULL
AND ref.country_Name IS NOT NULL;

/*Insert those with a lastSession*/
INSERT INTO MAIN.rpt.user_IPLocation
(user_ID, ip_Type, ip_Number, ip_Country, ip_Region, ip_City)
SELECT 
USER_IP_LOCATION_UPDATE.user_ID, 'Last Session', sl.source_IP, ref.country_Name, ref.region_Name, ref.city
FROM MAIN.rpt.login_Count_Total lct 
JOIN MAIN.STG.USER_IP_LOCATION_UPDATE ON lct.user_ID = USER_IP_LOCATION_UPDATE.user_ID
LEFT OUTER JOIN MAIN.arc.session_Log sl ON lct.last_Session_Log_ID = sl.session_Log_ID
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ref ON sl.source_IP = ref.ip_Address
LEFT OUTER JOIN MAIN.rpt.user_IPLocation uic ON USER_IP_LOCATION_UPDATE.user_ID = uic.user_ID

WHERE uic.ip_Number IS NULL
AND sl.source_IP IS NOT NULL
AND ref.country_Name IS NOT NULL;

DROP TABLE MAIN.STG.USER_IP_LOCATION_UPDATE;


/*Fix values for users that signed up during the Jan-Mar 2015 IP Outage Window*/

UPDATE MAIN.rpt.user_IPLocation ip
SET  
	ip.ip_Number = sl.source_IP, 
	ip.ip_Country = ref.country_Name, 
	ip.ip_Region = ref.region_Name, 
	ip.ip_City = ref.city
FROM MAIN.rpt.login_Count_Total lct
LEFT OUTER JOIN MAIN.arc.session_Log sl ON lct.last_Session_Log_ID=sl.session_Log_ID
LEFT OUTER JOIN MAIN.ref.ip_Address_Info ref ON sl.source_IP=ref.ip_Address

WHERE ip_Type = 'January IP Outage'
AND ip.ip_Country IS NULL

AND  ip.user_ID=lct.user_ID
;


UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.user_IPLocation UPDATE')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.rpt.user_IPLocation')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.arc.paid_Account_Transfers ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.arc.paid_Account_Transfers'));

CREATE TABLE IF NOT EXISTS MAIN.arc.paid_Account_Transfers
(
	request_Log_ID bigint,
	transfer_Date datetime,
	transfer_Status VARCHAR,
	transfer_From_User_ID bigint,
	transfer_To_User_ID bigint,
	transfer_Type VARCHAR,
	insert_by_user_ID INTEGER,
	session_Log_ID bigint,
	PRIMARY KEY /*ix_request_Log_ID*/ (request_Log_ID),
	UNIQUE /*ix_transfer_Date*/ (transfer_Date),
	UNIQUE /*ix_user_ID*/ (transfer_From_User_ID),
	UNIQUE /*ix_TransferTo_User_ID*/ (transfer_To_User_ID)
)
;


SET maxTransferID = (SELECT  MAX(request_Log_ID) FROM MAIN.arc.paid_Account_Transfers );

INSERT INTO MAIN.arc.paid_Account_Transfers (request_Log_ID, transfer_Date, transfer_Status, transfer_From_User_ID, transfer_To_User_ID, transfer_Type, insert_By_User_ID, session_Log_ID)
SELECT 
request_Log.request_Log_ID,
request_Log.insert_Date_Time AS Transfer_Date,
request_Log.parm4 AS Transfer_Status,
FROMUSER.user_ID AS From_User_ID,
TOUSER.user_ID AS To_User_ID,
request_Log.parm3 AS Transfer_Type,
request_Log.insert_By_User_ID,
request_Log.session_log_ID
FROM MAIN.arc.request_Log request_Log
LEFT OUTER JOIN MAIN.PUBLIC.user_Account FROMUSER ON FROMUSER.user_ID = request_Log.parm1
LEFT OUTER JOIN MAIN.PUBLIC.user_Account TOUSER ON TOUSER.user_ID = request_Log.parm2
WHERE request_Log.parm3 LIKE 'TRANSFER_PAID_ACCOUNT:%' 
-- and request_Log.parm4 = 'true' currently including both successful and failed attempts. This line would only take Successful attempts
AND request_Log.request_Log_ID > $maxTransferID
;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.arc.paid_Account_Transfers')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** MAIN.arc.payment_Profile_first_Win_Product ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
/*This table contains the product_ID, payment_Term, and payment_Type of payment_Profiles for the 1st time they become a Win*/

/*Start Logging*/
INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('MAIN.arc.payment_Profile_first_Win_Product'));

DROP TABLE IF EXISTS MAIN.arc.payment_Profile_first_Win_Product;

CREATE TABLE IF NOT EXISTS MAIN.arc.payment_Profile_first_Win_Product
(
	payment_Profile_ID BIGINT,
	source_User_ID BIGINT,
	product_ID INT,
	payment_Term INT,
	payment_Type INT,
	plan_Rate_USD DECIMAL (38,10),
	currency_Code VARCHAR,
	exchange_Rate DECIMAL (38,10),
	win_Date DATETIME,
	user_Limit INT,
	PRIMARY KEY (payment_Profile_ID),
	UNIQUE /*ix_source_User_ID*/ (source_User_ID)
)
;

DROP TABLE IF EXISTS MAIN.STG.MIN_WIN_PRODUCT;

CREATE TABLE IF NOT EXISTS MAIN.STG.MIN_WIN_PRODUCT
(
	payment_Profile_ID BIGINT,
	source_User_ID BIGINT,
	min_Modify_Date_Time DATETIME,
	PRIMARY KEY (payment_Profile_ID),
		UNIQUE /*ix_sourceUser*/ (source_User_ID),
        UNIQUE /*ix_mdt*/ (min_Modify_Date_Time)
)
;

INSERT INTO MAIN.STG.MIN_WIN_PRODUCT (payment_Profile_Id, source_User_ID, min_Modify_Date_Time)
SELECT hpp.payment_Profile_ID, pp.source_User_ID, MIN(hpp.modify_Date_Time) AS min_Modify_Date_Time
FROM MAIN.hist.payment_Profile hpp
LEFT JOIN MAIN.rpt.payment_Profile pp ON hpp.payment_Profile_ID=pp.payment_Profile_ID
WHERE hpp.product_ID >=3
AND hpp.payment_Type IN(1,2,3,6,8,10)
AND hpp.plan_Rate > 0
GROUP BY 1,2
;


INSERT /*IGNORE*/ INTO MAIN.arc.payment_Profile_first_Win_Product
SELECT 
hpp.payment_Profile_ID, 
mwp.source_User_ID, 
hpp.product_ID, 
hpp.payment_Term, 
hpp.payment_Type, 
hpp.plan_Rate_USD, 
hpp.currency_Code, 
hce.exchange_Rate, 
mwp.min_Modify_Date_Time,
hpp.user_Limit
FROM MAIN.hist.payment_Profile hpp
JOIN MAIN.STG.MIN_WIN_PRODUCT mwp ON hpp.payment_Profile_ID=mwp.payment_Profile_ID 
	AND hpp.modify_Date_Time=mwp.min_Modify_Date_Time
LEFT OUTER JOIN MAIN.hist.currency_Exchange hce ON hpp.currency_Code=hce.currency_Code /***COLLATE utf8mb4_unicode_520_ci***/
	AND hpp.modify_Date_Time BETWEEN hce.modify_Date_Time AND hce.hist_effective_Thru_Date_Time
WHERE hpp.product_ID >= 3
AND hpp.plan_Rate > 0
AND hpp.payment_Type IN(1,2,3,6,8,10)
AND hpp.hist_effective_Thru_Date_Time <= '9999-12-31 23:59:59'
;



DROP TABLE IF EXISTS MAIN.STG.MIN_WIN_PRODUCT;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('MAIN.arc.payment_Profile_first_Win_Product')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;


SELECT '******************************************************************************************************************************', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
SELECT '******** End of Throwaway Part 1: Bookings ******** ', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
--set session transaction isolation level repeatable read;

/*Stop Logging*/
UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('Throwaway Part 1: Bookings')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE;

UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id
;