import re
import os
import argparse
import csv
from collections import namedtuple
import json
from datetime import datetime, date

EOL = '\n'

def json_serial(obj):
  """JSON serializer for objects not serializable by default json code"""
  if isinstance(obj, (datetime, date)):
    return obj.isoformat()
  raise TypeError ("Type %s not serializable" % type(obj))

def load_column_map(map_file_name_fq):

  mysql_db_table_map = {}
  mysql_table_column_map = {}
  mysql_column_map = {}
  mysql_table_map = {}
  mysql_db_map = {}

#  rev_mysql_db_map = {}
#  schema_table_map = {}
#  rev_table_map = {}
#  rev_column_map = {}

  with open(map_file_name_fq, 'r') as map_fh:
    reader = csv.reader(map_fh, quotechar='"', escapechar='\\')
    MapEntry = namedtuple("MapEntry", next(reader))  # get names from column headers
    i = 0
    try:
      for map_entry in map(MapEntry._make, reader):
        i += 1

        mysql_db_table_str = '{}.{}'.format(map_entry.old_mysql_database_name, map_entry.old_mysql_table_name)
        snowflake_db_schema_table_str = '{}.{}.{}'.format(map_entry.snowflake_database, map_entry.snowflake_schema, map_entry.snowflake_table_without_schema)

        snowflake_db_schema_tables = mysql_db_table_map.get(mysql_db_table_str)
        if not snowflake_db_schema_tables:
          snowflake_db_schema_tables = mysql_db_table_map[mysql_db_table_str] = {}
        snowflake_db_schema_table = snowflake_db_schema_tables.get(snowflake_db_schema_table_str)
        if not snowflake_db_schema_table:
          snowflake_db_schema_table = snowflake_db_schema_tables[snowflake_db_schema_table_str] = { 'MAP_ENTRY_ATTRS': [] }
        snowflake_db_schema_table['MAP_ENTRY_ATTRS'].append({'old_mysql_field_name':map_entry.old_mysql_field_name, 'snowflake_field':map_entry.snowflake_field})

        mysql_table_column_str = '{}.{}'.format(map_entry.old_mysql_table_name, map_entry.old_mysql_field_name)
        snowflake_table_column_str = '{}.{}'.format(map_entry.snowflake_table_without_schema, map_entry.snowflake_field)

        snowflake_table_columns = mysql_table_column_map.get(mysql_table_column_str)
        if not snowflake_table_columns:
          snowflake_table_columns = mysql_table_column_map[mysql_table_column_str] = {}
        snowflake_table_column = snowflake_table_columns.get(snowflake_table_column_str)
        if not snowflake_table_column:
          snowflake_table_column = snowflake_table_columns[snowflake_table_column_str] = { 'MAP_ENTRY_ATTRS': [] }
        snowflake_table_column['MAP_ENTRY_ATTRS'].append({'old_mysql_database_name':map_entry.old_mysql_database_name, 'snowflake_database':map_entry.snowflake_database})

        mysql_column_str = map_entry.old_mysql_field_name
        snowflake_column_str = map_entry.snowflake_field

        snowflake_columns = mysql_column_map.get(mysql_column_str)
        if not snowflake_columns:
          snowflake_columns = mysql_column_map[mysql_column_str] = {}
        snowflake_column = snowflake_columns.get(snowflake_column_str)
        if not snowflake_column:
          snowflake_column = snowflake_columns[snowflake_column_str] = { 'MAP_ENTRY_ATTRS': [] }
        snowflake_column['MAP_ENTRY_ATTRS'].append({'old_mysql_database_name':map_entry.old_mysql_database_name, 'snowflake_database':map_entry.snowflake_database, 'old_mysql_table_name':map_entry.old_mysql_table_name, 'snowflake_schema':map_entry.snowflake_schema, 'snowflake_table_without_schema':map_entry.snowflake_table_without_schema})

        mysql_table_str = map_entry.old_mysql_table_name
        snowflake_schema_table_str = '{}.{}'.format(map_entry.snowflake_schema, map_entry.snowflake_table_without_schema)

        snowflake_schema_tables = mysql_table_map.get(mysql_table_str)
        if not snowflake_schema_tables:
          snowflake_schema_tables = mysql_table_map[mysql_table_str] = {}
        snowflake_schema_table = snowflake_schema_tables.get(snowflake_schema_table_str)
        if not snowflake_schema_table:
          snowflake_schema_table = snowflake_schema_tables[snowflake_schema_table_str] = { 'MAP_ENTRY_ATTRS': [] }
        snowflake_schema_table['MAP_ENTRY_ATTRS'].append({'old_mysql_database_name':map_entry.old_mysql_database_name, 'snowflake_database':map_entry.snowflake_database, 'old_mysql_field_name':map_entry.old_mysql_field_name, 'snowflake_field':map_entry.snowflake_field})

        mysql_db_str = map_entry.old_mysql_database_name
        snowflake_db_str = map_entry.snowflake_database

        snowflake_dbs = mysql_db_map.get(mysql_db_str)
        if not snowflake_dbs:
          snowflake_dbs = mysql_db_map[mysql_db_str] = {}
        snowflake_db = snowflake_dbs.get(snowflake_db_str)
        if not snowflake_db:
          snowflake_db = snowflake_dbs[snowflake_db_str] = { 'MAP_ENTRY_ATTRS': [] }
        snowflake_db['MAP_ENTRY_ATTRS'].append({'snowflake_schema':map_entry.snowflake_schema, 'old_mysql_table_name':map_entry.old_mysql_table_name, 'snowflake_table_without_schema':map_entry.snowflake_table_without_schema, 'old_mysql_field_name':map_entry.old_mysql_field_name, 'snowflake_field':map_entry.snowflake_field})

#        mysql_dbs = rev_database_map.get(map_entry.snowflake_database)
#        if not mysql_dbs:
#          mysql_dbs = rev_database_map[map_entry.snowflake_database] = {}
#        mysql_db = mysql_dbs.get(map_entry.old_mysql_database_name)
#        if not mysql_db:
#          mysql_db = mysql_dbs[map_entry.old_mysql_database_name] = {}
#        mysql_table = mysql_db.get(map_entry.old_mysql_table_name)
#        if not mysql_table:
#          mysql_table = mysql_db[map_entry.old_mysql_table_name] = {}
#        mysql_column = mysql_table.get(map_entry.old_mysql_field_name)
#        if not mysql_column:
#          mysql_column = mysql_table[map_entry.old_mysql_field_name] = []
#        mysql_column.append({'snowflake_schema':map_entry.snowflake_schema,'snowflake_table_without_schema':map_entry.snowflake_table_without_schema,'snowflake_field':map_entry.snowflake_field})
   
#        mysql_columns = rev_column_map.get(map_entry.snowflake_field)
#        if not mysql_columns:
#          mysql_columns = rev_column_map[map_entry.snowflake_field] = {}
#        mysql_column = mysql_columns.get(map_entry.old_mysql_field_name)
#        if not mysql_column:
#          mysql_column = mysql_columns[map_entry.old_mysql_field_name] = {}
#        mysql_db = mysql_column.get(map_entry.old_mysql_database_name)
#        if not mysql_db:
#          mysql_db = mysql_column[map_entry.old_mysql_database_name] = {}
#        mysql_table = mysql_db.get(map_entry.old_mysql_table_name)
#        if not mysql_table:
#          mysql_table = mysql_db[map_entry.old_mysql_table_name] = []
#        mysql_table.append({'snowflake_database':map_entry.snowflake_database,'snowflake_schema':map_entry.snowflake_schema,'snowflake_table_without_schema':map_entry.snowflake_table_without_schema})

    except:
      print('Failed on line [{}] of map entry file [{}]!'.format(i, map_file_name_fq))
      raise
    print('Processed [{}] lines in file [{}].'.format(i, map_file_name_fq))

  for mysql_db_table_str, snowflake_db_schema_tables in mysql_db_table_map.items():
    if len(snowflake_db_schema_tables.keys()) > 1:
      print('[mysql_db_table_str]=[{}] maps to multiple snowflake_database/schema/table values [{}]!'.format(mysql_db_table_str, ','.join(snowflake_db_schema_tables.keys())))

  for mysql_table_column_str, snowflake_table_columns in mysql_table_column_map.items():
    if len(snowflake_table_columns.keys()) > 1:
      print('[mysql_table_column_str]=[{}] maps to multiple snowflake table/column values [{}]!'.format(mysql_table_column_str, ','.join(snowflake_table_columns.keys())))

  for mysql_column_str, snowflake_columns in mysql_column_map.items():
    if len(snowflake_columns.keys()) > 1:
      print('[mysql_column_str]=[{}] maps to multiple snowflake column values [{}]!'.format(mysql_column_str, ','.join(snowflake_columns.keys())))

  for mysql_table_str, snowflake_schema_tables in mysql_table_map.items():
    if len(snowflake_schema_tables.keys()) > 1:
      print('[mysql_table_str]=[{}] maps to multiple snowflake schema/table values [{}]!'.format(mysql_table_str, ','.join(snowflake_schema_tables.keys())))

  for mysql_db_str, snowflake_dbs in mysql_db_map.items():
    if len(snowflake_dbs.keys()) > 1:
      print('[mysql_db_str]=[{}] maps to multiple snowflake database values [{}]!'.format(mysql_db_str, ','.join(snowflake_dbs.keys())))

#  for snowflake_field, mysql_columns in rev_column_map.items():
#    if len(mysql_columns.keys()) > 1:
#      print('[snowflake_field]=[{}] maps to multiple old_mysql_field_name values!'.format(snowflake_field))
#      for old_mysql_field_name, mysql_databases in mysql_columns.items():
#        print('  -->[old_mysql_field_name]=[{}]'.format(old_mysql_field_name))
#        for old_mysql_database_name, mysql_tables in mysql_databases.items():
#          print('    -->[old_mysql_database_name]=[{}] with UP TO 3 [old_mysql_table_names]=[{}]'.format(old_mysql_database_name, ','.join(list(mysql_tables.keys())[:3])))
#      print()
##      print('[snowflake_field]=[{}] maps to multiple old_mysql_field_name values [{}]!'.format(snowflake_field, ';'.join([ '{}:{}:{}'.format(mysql_column, mysql_database, 'TABLE') for mysql_column, mysql_database in mysql_columns.items()])))

  return {
    'DB_TABLE_MAP' : mysql_db_table_map
   ,'TABLE_COLUMN_MAP' : mysql_table_column_map
   ,'COLUMN_MAP' : mysql_column_map
   ,'TABLE_MAP' : mysql_table_map
   ,'DB_MAP' : mysql_db_map
  }

###########################################################

def my_re_sub (debug_fh, pattern, repl, str, **kwargs):
  label = kwargs.pop('label', 'no_label_provided')
  new_str = re.sub(pattern, repl, str, **kwargs)
  if new_str != str:
    debug_fh.write('===>{}\nOLD->[{}]\n<-OLD\nNEW->[{}]\n<-NEW\n'.format(label, str, new_str))
  return new_str
  
###########################################################

def convert_file_to_snowflake(maps, source_file_name_fq, snowflake_filename_fq, debug_filename_fq):

  print('Processing source file [{}]...'.format(source_file_name_fq))

  with open(debug_filename_fq, 'w') as debug_fh:

    with open(snowflake_filename_fq, 'w') as target_fh:

      with open(source_file_name_fq, 'r') as source_fh:

        file_contents = source_fh.read()

        file_contents = file_contents.replace(r"""REGEXP "[' ']""", r"""REGEXP "['' '']""")  # Not sure if this will have unintended side effects...?
        file_contents = file_contents.replace("\"", "'")  # Not sure if this will have unintended side effects...?

        # Apply identifier transformations

        mysql_db_table_map = maps['DB_TABLE_MAP']
        print('  Applying DB_TABLE_MAP (keycount=[{}]) transformations...'.format(len(mysql_db_table_map)))
        for mysql_db_table_str in sorted(mysql_db_table_map, key=len, reverse=True):
          if mysql_db_table_str in file_contents:
            mysql_db_table = mysql_db_table_map[mysql_db_table_str]
            snowflake_db_schema_table_str = list(mysql_db_table.keys())[0] # We KNOW that there can only be a single mapping for each source value
            file_contents = file_contents.replace(mysql_db_table_str, snowflake_db_schema_table_str)

        mysql_table_column_map = maps['TABLE_COLUMN_MAP']
        print('  Applying TABLE_COLUMN_MAP (keycount=[{}]) transformations...'.format(len(mysql_table_column_map)))
        for mysql_table_column_str in sorted(mysql_table_column_map, key=len, reverse=True):
          if mysql_table_column_str in file_contents:
            mysql_table_column = mysql_table_column_map[mysql_table_column_str]
            snowflake_table_column_str = list(mysql_table_column.keys())[0] # We KNOW that there can only be a single mapping for each source value
            file_contents = file_contents.replace(mysql_table_column_str, snowflake_table_column_str)

        mysql_column_map = maps['COLUMN_MAP']
        print('  Applying COLUMN_MAP (keycount=[{}]) transformations...'.format(len(mysql_column_map)))
        for mysql_column_str in sorted(mysql_column_map, key=len, reverse=True):
          if mysql_column_str in file_contents:
            mysql_column = mysql_column_map[mysql_column_str]
            snowflake_column_str = list(mysql_column.keys())[0] # We KNOW that there can only be a single mapping for each source value
            file_contents = file_contents.replace(mysql_column_str, snowflake_column_str)

  #            mysql_table_map = maps['TABLE_MAP']
  #            print('  Applying TABLE_MAP (keycount=[{}]) transformations...'.format(len(mysql_table_map)))
  #            for mysql_table_str in sorted(mysql_table_map, key=len, reverse=True):
  #              if mysql_table_str in file_contents:
  #                mysql_table = mysql_table_map[mysql_table_str]
  #                snowflake_schema_table_str = list(mysql_table.keys())[0] # We KNOW that there can only be a single mapping for each source value
  #                file_contents = file_contents.replace(mysql_table_str, snowflake_schema_table_str)

        mysql_db_map = maps['DB_MAP']
        print('  Applying DB_MAP (keycount=[{}]) transformations...'.format(len(mysql_db_map)))
        for mysql_db_str in sorted(mysql_db_map, key=len, reverse=True):
          if mysql_db_str in file_contents:
            mysql_db = mysql_db_map[mysql_db_str]
            snowflake_db_str = list(mysql_db.keys())[0] # We KNOW that there can only be a single mapping for each source value
            file_contents = file_contents.replace(mysql_db_str, snowflake_db_str)

        print('Applying logical transformations...')
        i = 0

#        max_passes = 10
#        j = 0
#        while True:
#          file_contents_new = my_re_sub(debug_fh, r"""(/[*](?:(?!(;|[*]/)).)*);""", r"""\1""", file_contents, flags=re.DOTALL, label='Strip semi-colons from multi-line comments')
#          if file_contents_new == file_contents:
#            break
#          file_contents = file_contents_new
#          j += 1
#          debug_fh.write('Stripped semi-colon from multi-line comment (pass #{})...'.format(j))
#          if (j == max_passes):
#            debug_fh.write('Exceeded MAX number of passes [{}] for a single file!)...'.format(max_passes))
#            print('Stopping script... something seems off.')
#            exit(1)

        for sql_command in file_contents.split(';'):  # We cannot use "\n" here because there are many places with "blah blah; -- comment afterwards"

          i += 1

          # Apply transformations

#          sql_command = my_re_sub(debug_fh, r"""(?:(?!/[*]).)*/[*]$""", r"""""", sql_command, flags=re.DOTALL, label='Strip unopened multi-line quote')
#          sql_command = my_re_sub(debug_fh, r"""/[*](?:(?![*]/).)*$""", r"""""", sql_command, flags=re.DOTALL, label='Strip unclosed multi-line quote')

          sql_command = my_re_sub(debug_fh, """(SET \@\@sql_mode = '')""", r"""--\1""", sql_command, flags=re.IGNORECASE, label='Comment out sql mode setting')
          sql_command = my_re_sub(debug_fh, """\@(log_Level|process_Id|rownum)""", r"""$\1""", sql_command, label='Convert @ to $ (targeted)')
          sql_command = my_re_sub(debug_fh, """([ (])[@]""", r"""\1$""", sql_command, label='Convert @ to $ (generic)')  # Watch for email addresses!
          sql_command = my_re_sub(debug_fh, r"""SELECT ([1-9]+) INTO \$log_Level""", r"""SET log_Level = '\1'""", sql_command, flags=re.IGNORECASE, label='Set log level')
          sql_command = my_re_sub(debug_fh, r"""SELECT 0 INTO \$process_Id""", r"""SET process_Id = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)""", sql_command, flags=re.IGNORECASE, label='Set next process ID')
          sql_command = my_re_sub(debug_fh, r"""CALL MAIN.utl_logProcessStart\(([^,]+),([^,]+),([^,]+),([^,]+),([^,]+),([^)]+)\)""", r"""INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START(\1,\2::INTEGER,\3,\4,\5,\6))""", sql_command, label='CALL MAIN.utl_logProcessStart')
          sql_command = my_re_sub(debug_fh, r"""CALL MAIN.utl_logProcessEnd\(\$process_Id\)""", r"""
UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id
""", sql_command, label='CALL MAIN.utl_logProcessEnd')

          sql_command = my_re_sub(debug_fh, r"""CALL MAIN\.SMARTSHEET_START_LOG\s*\('([^']+)'\)""", r"""INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('\1'))""", sql_command, flags=re.IGNORECASE, label='CALL MAIN.SMARTSHEET_START_LOG')
          sql_command = my_re_sub(debug_fh, r"""CALL MAIN\.SMARTSHEET_STOP_LOG\s*\('([^']+)'\)""", r"""UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY QH SET TIME_ELAPSED = X.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('\1')) X WHERE QH.BUILD_NUMBER = X.BUILD_NUMBER AND QH.PREP_SEQUENCE = X.PREP_SEQUENCE""", sql_command, flags=re.IGNORECASE, label='CALL MAIN.SMARTSHEET_STOP_LOG')
          sql_command = my_re_sub(debug_fh, r"""CALL MAIN\.ETL_USERACCOUNT\s*\(([^,]+),([^,]+),([^)]+)\)""", r"""
SET process_Id_Sub = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_userAccount',\2::INTEGER,'','INFO',\3,$process_Id_Sub))
;
MERGE INTO MAIN.PUBLIC.USER_ACCOUNT T
  USING (
    WITH X1 AS (
      SELECT MAX(MUA.USER_ID) AS USER_ID_MAX
        FROM MAIN.PUBLIC.USER_ACCOUNT MUA
    )
   ,X2 AS (
      SELECT ANY_VALUE(X1.USER_ID_MAX) AS USER_ID_MAX
            ,MAX(MUA.MODIFY_DATE_TIME) AS MODIFY_DATE_TIME_MAX
        FROM X1
             JOIN MAIN.PUBLIC.USER_ACCOUNT MUA
               ON MUA.USER_ID = X1.USER_ID_MAX
    )
    SELECT CUA.USER_ID
          ,CUA.FIRST_NAME
          ,CUA.LAST_NAME
          ,CUA.NICK_NAME
          ,CUA.ACCOUNT_TYPE
          ,CUA.EMAIL_ADDRESS
          ,CUA.LOGIN_PASSWORD
          ,CUA.LOCALE
          ,CUA.TIME_ZONE
          ,CUA.NEWS_FLAGS
          ,CUA.STATUS_FLAGS
          ,CUA.INSERT_BY_USER_ID
          ,CUA.INSERT_DATE_TIME
          ,CUA.MODIFY_BY_USER_ID
          ,CUA.MODIFY_DATE_TIME
          ,CUA.SESSION_LOG_ID
          ,RLCL.LOCALE_NAME
          ,RLCL.LANGUAGE_NAME
          ,RLCL.COUNTRY_NAME
          ,SPLIT_PART(CUA.EMAIL_ADDRESS, '@', 2) AS DOMAIN
          ,CUA.PROFILE_IMAGE
      FROM X2
           JOIN CORE.PUBLIC.USER_ACCOUNT CUA
             ON (CUA.USER_ID > X2.USER_ID_MAX OR CUA.MODIFY_DATE_TIME > X2.MODIFY_DATE_TIME_MAX)
           LEFT OUTER JOIN MAIN.REF.LOCALE_COUNTRY_LANGUAGE RLCL
             ON RLCL.LOCALE_CODE = CUA.LOCALE
     WHERE USER_ID <= \1::INTEGER
  ) S
    ON S.USER_ID = T.USER_ID
  WHEN NOT MATCHED THEN INSERT
    VALUES (S.USER_ID,S.FIRST_NAME,S.LAST_NAME,S.NICK_NAME,S.ACCOUNT_TYPE,S.EMAIL_ADDRESS,S.LOGIN_PASSWORD,S.LOCALE,S.TIME_ZONE,S.NEWS_FLAGS,S.STATUS_FLAGS,S.INSERT_BY_USER_ID,S.INSERT_DATE_TIME,S.MODIFY_BY_USER_ID,S.MODIFY_DATE_TIME,S.SESSION_LOG_ID,S.PROFILE_IMAGE,S.LOCALE_NAME,S.LANGUAGE_NAME,S.COUNTRY_NAME,S.DOMAIN)
  WHEN MATCHED THEN UPDATE
    SET USER_ID = S.USER_ID
       ,FIRST_NAME = S.FIRST_NAME
       ,LAST_NAME = S.LAST_NAME
       ,NICK_NAME = S.NICK_NAME
       ,ACCOUNT_TYPE = S.ACCOUNT_TYPE
       ,EMAIL_ADDRESS = S.EMAIL_ADDRESS
       ,LOGIN_PASSWORD = S.LOGIN_PASSWORD
       ,LOCALE = S.LOCALE
       ,TIME_ZONE = S.TIME_ZONE
       ,NEWS_FLAGS = S.NEWS_FLAGS
       ,STATUS_FLAGS = S.STATUS_FLAGS
       ,INSERT_BY_USER_ID = S.INSERT_BY_USER_ID
       ,INSERT_DATE_TIME = S.INSERT_DATE_TIME
       ,MODIFY_BY_USER_ID = S.MODIFY_BY_USER_ID
       ,MODIFY_DATE_TIME = S.MODIFY_DATE_TIME
       ,SESSION_LOG_ID = S.SESSION_LOG_ID
       ,PROFILE_IMAGE = S.PROFILE_IMAGE
       ,LOCALE_FRIENDLY = S.LOCALE_NAME
       ,LANGUAGE_FRIENDLY = S.LANGUAGE_NAME
       ,COUNTRY_FRIENDLY = S.COUNTRY_NAME
       ,DOMAIN = S.DOMAIN
;
UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id_Sub
""", sql_command, flags=re.IGNORECASE, label='CALL MAIN.ETL_USERACCOUNT')

          sql_command = my_re_sub(debug_fh, r"""CALL MAIN\.ETL_REQUESTLOG\s*\(([^,]+),([^)]+)\)""", r"""
SET process_Id_Sub = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_requestLog',\1::INTEGER,'','INFO',\2,$process_Id_Sub))
;
SET max_Request_Log_Id = (SELECT MAX(request_Log_ID) FROM MAIN.ARC.REQUEST_LOG)
;
SET process_Id_Sub2 = (SELECT MAIN.PUBLIC.SEQ_PROCESS_ID.NEXTVAL)
;
INSERT INTO MAIN.PUBLIC.UTL_PROCESS_LOG SELECT * FROM TABLE(MAIN.PUBLIC.UTL_LOG_PROCESS_START('etl_requestLog',$process_Id_Sub,'arc_serverActionLookup','DEBUG',\2,$process_Id_Sub2))
;
INSERT INTO MAIN.ARC.SERVER_ACTION_LOOKUP (
  URL_ACTION_ID
 ,FORM_NAME
 ,FORM_ACTION
)
SELECT RL.URL_ACTION_ID
      ,RL.FORM_NAME
      ,RL.FORM_ACTION
  FROM (
         SELECT DISTINCT
                R.URL_ACTION_ID
               ,R.FORM_NAME
               ,R.FORM_ACTION
           FROM LOG.PUBLIC.REQUEST_LOG R
          WHERE R.REQUEST_LOG_ID > $NewMaxRequestLogID
       ) RL
       LEFT OUTER JOIN MAIN.ARC.SERVER_ACTION_LOOKUP L
         ON L.URL_ACTION_ID = RL.URL_ACTION_ID
        AND L.FORM_NAME = RL.FORM_NAME
        AND L.FORM_ACTION = RL.FORM_ACTION
 WHERE L.URL_ACTION_ID IS NULL
;
INSERT INTO MAIN.ARC.REQUEST_LOG
SELECT * 
  FROM LOG.PUBLIC.REQUEST_LOG
 WHERE REQUEST_LOG_ID > $NewMaxRequestLogID
;
UPDATE MAIN.PUBLIC.UTL_PROCESS_LOG
   SET END_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
      ,DURATION_SEC = DATEDIFF(SECOND, START_TIME, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ)
 WHERE PROCESS_ID = $process_Id_Sub
""", sql_command, flags=re.IGNORECASE, label='CALL MAIN.ETL_REQUESTLOG')

#          sql_command = my_re_sub(debug_fh, r"""(CALL\s+(MAIN\.ETL_REQUESTLOG))""", r"""--\1""", sql_command, flags=re.IGNORECASE)  # Skip CALL statements that cannot automatically be converted into SQL function calls

          sql_command = my_re_sub(debug_fh, """SELECT(.+?(?=INTO))INTO\s+\$([^ ]+)((\s*FROM\s*)?([^*]*))""", r"""SET \2 = (SELECT \1\3)""", sql_command, flags=re.IGNORECASE, label='SELECT INTO VAR')



          sql_command = my_re_sub(debug_fh, r"""MAIN\.stg_mobileAppLogin_Counts""", r"""MAIN.STG.MOBILE_APP_LOGIN_COUNTS""", sql_command, flags=re.IGNORECASE, label='Rename unmapped table MAIN.stg_mobileAppLogin_Counts')
          sql_command = my_re_sub(debug_fh, r"""MAIN\.stg_mobileAppMax_Dates""", r"""MAIN.STG.MOBILE_APP_MAX_DATES""", sql_command, flags=re.IGNORECASE, label='Rename unmapped table MAIN.stg_mobileAppMax_Dates')
          sql_command = my_re_sub(debug_fh, r"""MAIN\.stg_userIPLocationUpdate""", r"""MAIN.STG.USER_IP_LOCATION_UPDATE""", sql_command, flags=re.IGNORECASE, label='Rename unmapped table MAIN.stg_userIPLocationUpdate')
          sql_command = my_re_sub(debug_fh, r"""stg_userIPLocationUpdate""", r"""USER_IP_LOCATION_UPDATE""", sql_command, flags=re.IGNORECASE, label='Rename alias stg_userIPLocationUpdate to USER_IP_LOCATION_UPDATE')
          sql_command = my_re_sub(debug_fh, r"""MAIN\.stg_minWinProduct""", r"""MAIN.STG.MIN_WIN_PRODUCT""", sql_command, flags=re.IGNORECASE, label='Rename unmapped table MAIN.stg_minWinProduct')
          sql_command = my_re_sub(debug_fh, r"""LEFT OUTER (JOIN MAIN\.RPT\.SIGNUP_REQUEST_TRACKING_ITEM)""", r"""\1""", sql_command, flags=re.IGNORECASE, label='Change outer join to inner join')
          
          sql_command = my_re_sub(debug_fh, r"""(?<!_Type)\s+TINYINT""", r""" BOOLEAN""", sql_command, label='DDL TINYINT to BOOLEAN (except after "_Type")')

          # Need to get a map of table to primary key!!!
          sql_command = my_re_sub(debug_fh, r"""AS\s+'([^']+)'""", r'AS "\1"', sql_command, flags=re.IGNORECASE, label='ALIASED COLUMN USE DBL QUOTES')

          sql_command = my_re_sub(debug_fh, r"""SET\s+AUTOCOMMIT\s*=\s*0""", r"""ALTER SESSION SET AUTOCOMMIT = FALSE""", sql_command, flags=re.IGNORECASE, label='AutoCommit False')
          sql_command = my_re_sub(debug_fh, r"""SET\s+AUTOCOMMIT\s*=\s*1""", r"""ALTER SESSION SET AUTOCOMMIT = TRUE""", sql_command, flags=re.IGNORECASE, label='AutoCommit True')
          sql_command = my_re_sub(debug_fh, r"""SET \$weekformat""", r"""SET WEEKFORMAT""", sql_command, flags=re.IGNORECASE, label='Set Weekformat variable')

          sql_command = my_re_sub(debug_fh, r"""A Clayton's Secretary""", r"""A Clayton''s Secretary""", sql_command, flags=re.IGNORECASE, label='Single quote clayton secretary')
          sql_command = my_re_sub(debug_fh, r"""(LEFT OUTER JOIN MAIN.PUBLIC.user_Account\s+)userAccount""", r"""\1user_Account""", sql_command, flags=re.IGNORECASE, label='Single quote clayton secretary')

  #              sql_command = my_re_sub(debug_fh, r"""INSERT IGNORE (INTO MAIN.rpt.payment_Profile_Master.*)$""", r"""INSERT \1 AND NOT EXISTS (SELECT 1 FROM MAIN.rpt.payment_Profile_Master x WHERE x.master_Payment_Profile_ID = p.parent_Payment_Profile_ID AND x.payment_Profile_ID = p.payment_Profile_ID)""", sql_command, flags=re.DOTALL)
          sql_command = my_re_sub(debug_fh, """INSERT[ \t]+IGNORE[ \t]+((?!(INTO))[^\s]+)""", r"""INSERT IGNORE INTO \1""", sql_command, label='INSERT WITHOUT INTO')
          sql_command = my_re_sub(debug_fh, """INSERT[ \t]+((?!(INTO|IGNORE))[^\s]+)""", r"""INSERT INTO \1""", sql_command, label='INSERT WITHOUT INTO')
          sql_command = my_re_sub(debug_fh, r"""INSERT IGNORE INTO""", r"""INSERT /*IGNORE*/ INTO""", sql_command)  # Comment out IGNORE in INSERT IGNORE INTO
          sql_command = my_re_sub(debug_fh, r"""session_Length TIME,""", r"""session_Length INTEGER,""", sql_command)  # This *should* only alter the data type for a single column (MAIN.rpt.session_Log.session_Length)

          sql_command = my_re_sub(debug_fh, """\n\s*--\s*JOIN[^\n]+""", r"""\n""", sql_command, flags=re.IGNORECASE)
          
          sql_command = my_re_sub(debug_fh, """(SET SESSION TRANSACTION ISOLATION LEVEL)""", r"""--\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(SHOW VARIABLES )""", r"""--\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """INSTR""", r"""POSITION""", sql_command, flags=re.IGNORECASE)
#          sql_command = my_re_sub(debug_fh, """SUBSTRING_INDEX\s*\(\s*([^,]+)\s*,\s*'([^']+)'\s*,\s*1\s*\)""", r"""SPLIT(\1,'\2')[0]::VARCHAR""", sql_command, flags=re.IGNORECASE)
#          sql_command = my_re_sub(debug_fh, """SUBSTRING_INDEX\s*\(\s*([^,]+)\s*,\s*'([^']+)'\s*,\s*-1\s*\)""", r"""REVERSE(SPLIT(REVERSE(\1),'\2')[0])::VARCHAR""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """SUBSTRING_INDEX\s*\(\s*([^,]+)\s*,\s*'([^']+)'\s*,\s*([-0-9]+)\s*\)""", r"""SPLIT_PART(\1, '\2', \3)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(FORCE INDEX *\([^)]+\))""", r"""/***\1***/""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(CREATE UNIQUE INDEX)""", r"""--\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(CREATE INDEX)""", r"""--\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(,\s*INDEX\s*\([^)]+\))""", r"""/***\1***/""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(,\s*)KEY\s+([^\s]+)\s+(\([^)]+\))""", r"""\1UNIQUE /*\2*/ \3""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """PRIMARY\s+KEY\s+([^\s]+)\s+(\([^)]+\))""", r"""PRIMARY KEY /*\1*/ \2""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(ALTER TABLE .* CONVERT TO CHARACTER SET)""", r"""--\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(CONVERT TO CHARACTER SET [^ ]+)""", r"""/***\1***/""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(COLLATE\s+[^\s]+)""", r"""/***\1***/""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """IF *(\([^,)]+,[^,)]+,[^,)]+\))""", r"""IFF\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """IF *(\(pp)""", r"""IFF \1""", sql_command, flags=re.IGNORECASE)
#          sql_command = my_re_sub(debug_fh, r"""TRIM\(LEADING\s+('[^']+')\s+FROM\s+([^)]+)\)""", r"""IFF(STARTSWITH(\2, \1), SUBSTR(\2, 1+LENGTH(\1)), \2)""", sql_command, flags=re.IGNORECASE, label='TRIM LEADING FROM')
          sql_command = my_re_sub(debug_fh, r"""TRIM\(LEADING\s+'([^']+)'\s+FROM\s+TRIM\(LEADING\s+'([^']+)'\s+FROM\s+([^)]+)\)\)""", r"""REGEXP_REPLACE(REGEXP_REPLACE(\3, '^\1'), '^\2')""", sql_command, flags=re.IGNORECASE, label='TRIM LEADING FROM')
          sql_command = my_re_sub(debug_fh, r"""TRIM\(LEADING\s+'([^']+)'\s+FROM\s+([^)]+)\)""", r"""REGEXP_REPLACE(\2, '^\1')""", sql_command, flags=re.IGNORECASE, label='TRIM LEADING FROM')

          sql_command = my_re_sub(debug_fh, r"""\(SELECT email_Address FROM MAIN\.PUBLIC\.user_Account WHERE user_ID = SUBSTR\(myreferralValue\.item_Value, 3\)\) AS my_Smartsheet_Referral_Link_Friendly""", r"""x.email_Address AS my_Smartsheet_Referral_Link_Friendly""", sql_command, label='Replace inline select with LEFT JOIN (1)')
          sql_command = my_re_sub(debug_fh, r"""(WHERE r\.result_Status = 1 AND  r\.user_ID IS NOT NULL)""", r"""LEFT OUTER JOIN MAIN.PUBLIC.user_Account x ON x.user_ID = TRY_TO_NUMBER(SUBSTR(myreferralValue.item_Value, 3))\n\1""", sql_command, label='Replace inline select with LEFT JOIN (2)')
          sql_command = my_re_sub(debug_fh, r"""ELSE CASE source\.item_Value""", r"""ELSE CASE TRY_TO_NUMBER(source.item_Value)""", sql_command, label='Fix data type cast in CASE (1)')
          sql_command = my_re_sub(debug_fh, r"""ELSE CASE source\.item_Value""", r"""ELSE CASE TRY_TO_NUMBER(source.item_Value)""", sql_command, label='Fix data type cast in CASE (1)')
          sql_command = my_re_sub(debug_fh, r"""ELSE CASE app_Launch_Parm1\.item_Value""", r"""ELSE CASE TRY_TO_NUMBER(app_Launch_Parm1.item_Value)""", sql_command, label='Fix data type cast in CASE (2)')
          sql_command = my_re_sub(debug_fh, r"""ELSE CASE app_Launch_Type\.item_Value""", r"""ELSE CASE TRY_TO_NUMBER(app_Launch_Type.item_Value)""", sql_command, label='Fix data type cast in CASE (2)')
          sql_command = my_re_sub(debug_fh, r"""ON app_Launch_Parm1\.item_Value""", r"""ON TRY_TO_NUMBER(app_Launch_Parm1.item_Value)""", sql_command, label='Fix data type cast in JOIN (1)')
          sql_command = my_re_sub(debug_fh, r"""ON segment\.item_Value""", r"""ON TRY_TO_NUMBER(segment.item_Value)""", sql_command, label='Fix data type cast in JOIN (2)')
          sql_command = my_re_sub(debug_fh, r"""ON campaign\.item_Value""", r"""ON TRY_TO_NUMBER(campaign.item_Value)""", sql_command, label='Fix data type cast in JOIN (3)')



  #              sql_command = my_re_sub(debug_fh, """INSERT IGNORE INTO (.*)""", r"""INSERT INTO \1 WHERE NOT EXISTS (SELECT 1 FROM """, sql_command)

          sql_command = my_re_sub(debug_fh, """(\n| )[#]""", """--""", sql_command)  # Deal with # at start of line, or in middle
          sql_command = my_re_sub(debug_fh, r"""DAYOFYEAR\(([^)]+)\)""", r"""DATE_PART(DAYOFYEAR, \1::DATE)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATEDIFF\(([^,]+),\s*([^,)]+)\)""", r"""DATEDIFF(MINUTE, \1, \2)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_ADD\(([^,]+), *INTERVAL ([-0-9]+) +([^)]+)\)""", r"""DATEADD(\3, \2, \1)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_SUB\(([^,]+), *INTERVAL ([-0-9]+) +([^)]+)\)""", r"""DATEADD(\3, -\2, \1)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_FORMAT\(([^,]+), *('\%Y-\%m')\)""", r"""TO_VARCHAR(\1, 'YYYY-MM')""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_FORMAT\(([^,]+), *('\%Y\*\%m\(\%b\)')\)""", r"""TO_VARCHAR(\1, 'YYYY*MM(mon)')""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_FORMAT\(([^,]+), *('\%Y\*\%m\*\%d')\)""", r"""TO_VARCHAR(\1, 'YYYY*MM*DD')""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""DATE_FORMAT\(([^,]+), *('\%Y')\)""", r"""TO_VARCHAR(\1, 'YYYY')""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """NOW\(\)""", """CURRENT_TIMESTAMP()::TIMESTAMP_NTZ""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """ADDTIME\(\s*([^,]+),\s*'([-0-9]+)\:00\:00'\)""", r"""DATEADD(HOUR, \2, \1)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """(DATE\([^)]+\))""", r"""TO_\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""UNIX_TIMESTAMP\(([^)]+)\)""", r"""DATE_PART(EPOCH_SECOND, \1)""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""SEC_TO_TIME\((.+)\)""", r"""\1""", sql_command, flags=re.IGNORECASE, label='Remove SEC_TO_TIME() function')
          sql_command = my_re_sub(debug_fh, r"""SEC_TO_TIME\((.+)\)""", r"""\1""", sql_command, flags=re.IGNORECASE, label='Remove SEC_TO_TIME() function')

          sql_command = my_re_sub(debug_fh, """SELECT DATABASE\(\)""", """SELECT CURRENT_DATABASE()""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, """SELECT +"([*]+[^"\n]+)",""", r"""SELECT '\1',""", sql_command, flags=re.IGNORECASE)
  #              sql_command = my_re_sub(debug_fh, r"""CALL MAIN.SMARTSHEET_START_LOG *\(["']([^"']+)["']\)""", r"""INSERT INTO MAIN.ARC.PREP_V2_QUERY_HISTORY SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('\1'))""", sql_command, flags=re.IGNORECASE)
  #              sql_command = my_re_sub(debug_fh, r"""CALL MAIN.SMARTSHEET_STOP_LOG *\(["']([^"]+)["']\)""", r"""UPDATE MAIN.ARC.PREP_V2_QUERY_HISTORY T SET T.TIME_ELAPSED = S.TIME_ELAPSED FROM TABLE(MAIN.PUBLIC.SMARTSHEET_STOP_LOG('\1')) S WHERE S.BUILD_NUMBER = T.BUILD_NUMBER AND S.PREP_SEQUENCE = T.PREP_SEQUENCE""", sql_command, flags=re.IGNORECASE)
  #              sql_command = my_re_sub(debug_fh, r"""CALL LEADFLOW.SMARTSHEET_START_LOG *\("([^"]+)", *"([^"]+)"\)""", r"""INSERT INTO LEADFLOW.ARC.MARKETO_QUERY_HISTORY SELECT * FROM TABLE(LEADFLOW.PUBLIC.SMARTSHEET_START_LOG('\1','\2'))""", sql_command, flags=re.IGNORECASE)
  #              sql_command = my_re_sub(debug_fh, r"""CALL MAIN.utl_logProcessStart *\(["']([^"']+)["']\)""", r"""INSERT INTO MAIN.UTL_LOGPROCESSSTARTxxx SELECT * FROM TABLE(MAIN.PUBLIC.SMARTSHEET_START_LOG('\1'))""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""varchar\(\d+\)""", r"""VARCHAR""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""int\(\d+\)""", r"""INTEGER""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""MAIN.SPLIT_STR\([^)]+\)""", r"""NULL""", sql_command, flags=re.IGNORECASE)  # Short term hack
          sql_command = my_re_sub(debug_fh, r""", '''\),""", r""", ''''),""", sql_command, flags=re.IGNORECASE)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""BINARY""", r"""""", sql_command, flags=re.IGNORECASE)  # Short term hack (MAYBE)

          sql_command = my_re_sub(debug_fh, r"""-- First Pass""", r"""CREATE OR REPLACE SEQUENCE MAIN.PUBLIC.SEQ_ROW_NUM;\n-- First Pass""", sql_command, label='Create rownum sequence')
          sql_command = my_re_sub(debug_fh, r"""\$rownum:=\$rownum-1""", r"""SELECT ($rownum - MAIN.PUBLIC.SEQ_ROW_NUM.NEXTVAL) AS""", sql_command, flags=re.IGNORECASE, label='Use rownum sequence')

#          sql_command = my_re_sub(debug_fh, r"""\:\=\$rownum-1""", r"""""", sql_command, flags=re.IGNORECASE)  # Short term hack -- USE UDF?
          sql_command = my_re_sub(debug_fh, r"""main_trackingItemM ON main_trackingItem""", r"""main_trackingItemM ON main_trackingItemC""", sql_command, flags=re.IGNORECASE, label='SNOWFLAKE UPDATE ALIAS JOIN BUG')  # Short term hack (Snowflake bug)

          sql_command = my_re_sub(debug_fh, r"""session_Log\.signout_Date_Time""", r"""session_Log.sign_out_Date_Time""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""FROM MAIN\.arc\.request_Log requestLog""", r"""FROM MAIN.arc.request_Log request_Log""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""requestLog\.sessionlog_ID""", r"""request_Log.session_log_ID""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""LIKE '' %'""", r"""LIKE ''' %'""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""MAIN.rpt.signup_Source rpt_signup_Source""", r"""MAIN.rpt.signup_Source signup_Source""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""rpt_signup_Source\.matchtype""", r"""signup_Source.match_type""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""rpt_signup_Source\.`([^`]+)`""", r"""signup_Source.\1""", sql_command)  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""(MAIN\.ref\.([^\s]+))\s+ref_\2""", r"""\1 \2""", sql_command, label='Hack generic ref_')  # Short term hack
          sql_command = my_re_sub(debug_fh, r"""MAIN\.ref\.ip_Address_Info (AS )?ref_ip_AddressInfo""", r"""MAIN.ref.ip_Address_Info ip_Address_Info""", sql_command, label='Hack ref_ip_AddressInfo')  # Short term hack

          sql_command = my_re_sub(debug_fh, r"""(MAIN\.)(SMARTSHEET_(ACCOUNTTYPE|AUTHRESULT|BROWSERBUCKET|BROWSERDEVICE|BROWSERNAME|BROWSEROS|COUNTRYNAME|GET_BUCKET|GET_QUERY_PARAMETER|GET_SOURCE|LOGINTYPENAME|PAYMENTTERM|PAYMENTTYPE|PRODUCTNAME|WEEK)\s*\()""", r"""\1PUBLIC.\2""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""INET_ATON""", r"""MAIN.PUBLIC.INET_ATON""", sql_command, flags=re.IGNORECASE)

          # One off hacks
          sql_command = my_re_sub(debug_fh, r"""CONCAT\((TO_VARCHAR\(usa\.first_Session_Date_Time , 'YYYY'\)), ('\*'), \n	       (LPAD\(MONTH\(usa.first_Session_Date_Time\),2,'0'\)), ('\*'), \n	       (LPAD\(DAYOFMONTH\(usa.first_Session_Date_Time\),2,'0'\))\)""",r"""\1 || \2 || \3 || \4 || \5""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""CONCAT\((TO_VARCHAR\(usa\.last_Session_Date_Time , 'YYYY'\)), ('\*'), \n	       (LPAD\(MONTH\(usa.last_Session_Date_Time\),2,'0'\)), ('\*'), \n	       (LPAD\(DAYOFMONTH\(usa.last_Session_Date_Time\),2,'0'\))\)""",r"""\1 || \2 || \3 || \4 || \5""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""CONCAT\((campaign.item_Value), (' - '), (IFF\(campaignLookup.campaign_Description IS NULL, 'not found', campaignLookup.campaign_Description\))\)""",r"""\1 || \2 || \3""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""CONCAT\((segment.item_Value), (' - '), (IFF\(segmentLookup.segment_Description IS NULL, 'not found', segmentLookup.segment_Description\))\)""",r"""\1 || \2 || \3""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""(GROUP BY r.user_ID)""",r"""\1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35""", sql_command, flags=re.IGNORECASE)

          sql_command = my_re_sub(debug_fh, r"""IP(Country|Region|City)""",r"""IP_\1""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""insertbyuser_ID INTEGER""",r"""insert_by_user_ID INTEGER""", sql_command, flags=re.IGNORECASE)


          sql_command = my_re_sub(debug_fh, r"""(MAX\(modify_Date_Time\))""", r"""\1::VARCHAR""", sql_command, flags=re.IGNORECASE)
          sql_command = my_re_sub(debug_fh, r"""
p.account_Type, 
FALSE,
p.parent_Payment_Profile_ID
""", r"""
ANY_VALUE(p.account_Type), 
FALSE,
ANY_VALUE(p.parent_Payment_Profile_ID)
""", sql_command)

          x = 'WORKSPACE.stg.c_Dunn_pp_Updates B ON A.payment_Profile_ID = B.payment_Profile_ID\n'
          if 'JOIN ' + x in sql_command:
            sql_command = sql_command.replace('JOIN ' + x, '').replace('A.','') + '\nFROM ' + x.replace(' ON ', '\nWHERE ')

          # Unable to automate due to ALIAS
          sql_command = my_re_sub(debug_fh, r"""
UPDATE MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact 
JOIN MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact2 
SET payment_Profile_Contact.has_Org_Profile = TRUE
WHERE rpt_payment_ProfileContact2.user_ID = payment_Profile_Contact.user_ID
AND rpt_payment_ProfileContact2.account_Type = 3 AND payment_Profile_Contact.account_Type !=3
""", r"""
UPDATE MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact 
SET has_Org_Profile = TRUE
FROM MAIN.rpt.payment_Profile_Contact rpt_payment_ProfileContact2 
WHERE rpt_payment_ProfileContact2.user_ID = rpt_payment_ProfileContact.user_ID
AND rpt_payment_ProfileContact2.account_Type = 3 AND rpt_payment_ProfileContact.account_Type !=3
""", sql_command)

#              # Unable to automate due to multiple columns in SET
#              q = re.sub(r"""
#UPDATE MAIN.rpt.payment_Profile rp
#  -- JOIN CORE.PUBLIC.payment_Profile pp ON rp.payment_Profile_ID = pp.payment_Profile_ID and pp.payment_Profile_ID <= \$NEWmax_Payment_Profile_ID
#  JOIN MAIN.PUBLIC.organization o ON rp.owner_ID = o.organization_ID and o.organization_ID <= \$NewMaxorganization_ID
#SET rp.main_Contact_User_ID = o.main_Contact_User_ID,
#     rp.company_Name = o.name
#WHERE rp.account_Type = 3""", r"""
#UPDATE MAIN.rpt.payment_Profile rp
#SET main_Contact_User_ID = o.main_Contact_User_ID,
#     company_Name = o.name
# FROM MAIN.PUBLIC.organization o
#WHERE rp.account_Type = 3
#AND rp.owner_ID = o.organization_ID and o.organization_ID <= $NewMaxorganization_ID
#""", sql_command)
#              if q != sql_command:
#                print('{}\n[{}]\n[{}]'.format('UPDATE MAIN.rpt.payment_Profile rp (#1)', sql_command, q))
#                sql_command = q

#              # Unable to automate due to multiple columns in SET
#              q = re.sub(r"""
#UPDATE MAIN.rpt.payment_Profile rp
#  JOIN MAIN.PUBLIC.user_Account u ON rp.main_Contact_User_ID = u.user_ID AND u.user_ID <= \$NewMaxuser_ID
#SET  rp.main_Contact_Email_Address = u.email_Address,
#     rp.main_Contact_Domain = u.domain""", r"""
#UPDATE MAIN.rpt.payment_Profile rp
# SET main_Contact_Email_Address = u.email_Address,
#     main_Contact_Domain = u.domain
# FROM MAIN.PUBLIC.user_Account u
#WHERE rp.main_Contact_User_ID = u.user_ID AND u.user_ID <= $NewMaxuser_ID
#""", sql_command)
#              if q != sql_command:
#                print('{}\n[{}]\n[{}]'.format('UPDATE MAIN.rpt.payment_Profile rp (#2)', sql_command, q))
#                sql_command = q

#              # Not yet implemented 2 JOIN clauses in UPDATE
#              sql_command = my_re_sub(debug_fh, r"""
#UPDATE MAIN.hist.payment_Profile hpp /\*FORCE INDEX\(hist_payment_Profile_idxPK\)\*/
#JOIN CORE.hist.payment_Profile coreHPP /\*FORCE INDEX\(hist_payment_Profile_idxPK\)\*/ ON hpp.payment_Profile_ID = coreHPP.payment_Profile_ID
#	AND hpp.modify_Date_Time = coreHPP.modify_Date_Time
#JOIN MAIN.stg.histpayment_Profile_update stg ON coreHPP.payment_Profile_ID = stg.payment_Profile_ID 
#	AND stg.modify_Date_Time = coreHPP.hist_effective_Thru_Date_Time
#SET hpp.hist_effective_Thru_Date_Time = coreHPP.hist_effective_Thru_Date_Time
#WHERE hpp.modify_Date_Time != hpp.hist_effective_Thru_Date_Time AND hpp.modify_Date_Time < \$max_Modify_Date
#""", r"""
#UPDATE MAIN.hist.payment_Profile hpp /***FORCE INDEX(hist_payment_Profile_idxPK)***/
#SET hist_effective_Thru_Date_Time = coreHPP.hist_effective_Thru_Date_Time
#FROM CORE.hist.payment_Profile coreHPP /***FORCE INDEX(hist_payment_Profile_idxPK)***/
#JOIN MAIN.stg.histpayment_Profile_update stg ON coreHPP.payment_Profile_ID = stg.payment_Profile_ID 
# AND stg.modify_Date_Time = coreHPP.hist_effective_Thru_Date_Time
#WHERE hpp.modify_Date_Time != hpp.hist_effective_Thru_Date_Time AND hpp.modify_Date_Time < $max_Modify_Date
# AND hpp.payment_Profile_ID = coreHPP.payment_Profile_ID
# AND hpp.modify_Date_Time = coreHPP.modify_Date_Time
#""", sql_command)

          # Generic UPDATE/(JOIN|LEFT OUTER JOIN)/ON/(JOIN|LEFT OUTER JOIN).../SET/WHERE
          sql_command = my_re_sub(debug_fh, r"""UPDATE\s*((?:(?!\s+(UPDATE|JOIN|LEFT|ON|SET|WHERE)\s+).)+)\s*(?:(?:LEFT\s+OUTER\s+)?JOIN\s*)((?:(?!\s+(UPDATE|JOIN|ON|SET|WHERE)\s+).)+)\s*ON((?:(?!\s+(JOIN|LEFT|SET|WHERE)\s+).)+)\s*((?:LEFT\s+OUTER\s+)?JOIN\s+(?:(?:(?!\s+(SET|WHERE)\s+).)+)\s*)SET((?:(?!\s+(WHERE)\s+).)+)\s*WHERE\s+(.*)""", r"""
UPDATE \1\nSET \9\nFROM \3\n\7\nWHERE \11\nAND \5\n""", sql_command, flags=re.DOTALL, label='UPDATE/(JOIN|LEFT OUTER JOIN)/ON/(JOIN|LEFT OUTER JOIN)/SET/WHERE')

          # Generic UPDATE/(JOIN|LEFT OUTER JOIN)/ON/(JOIN|LEFT OUTER JOIN).../SET
          sql_command = my_re_sub(debug_fh, r"""UPDATE\s*((?:(?!\s+(UPDATE|JOIN|LEFT|ON|SET|WHERE)\s+).)+)\s*(?:(?:LEFT\s+OUTER\s+)?JOIN\s*)((?:(?!\s+(UPDATE|JOIN|ON|SET|WHERE)\s+).)+)\s*ON((?:(?!\s+(JOIN|LEFT|SET|WHERE)\s+).)+)\s*((?:LEFT\s+OUTER\s+)?JOIN\s+(?:(?:(?!\s+(SET|WHERE)\s+).)+)\s*)SET\s+(.*)""", r"""
UPDATE \1\nSET \9\nFROM \3\n\7\nWHERE \5\n""", sql_command, flags=re.DOTALL, label='UPDATE/(JOIN|LEFT OUTER JOIN)/ON/(JOIN|LEFT OUTER JOIN)/SET')

          # Generic UPDATE/(JOIN|LEFT OUTER JOIN)/ON/SET/WHERE
          sql_command = my_re_sub(debug_fh, r"""UPDATE\s*((?:(?!\s+(UPDATE|JOIN|LEFT|ON|SET|WHERE)\s+).)+)\s*(?:(?:LEFT\s+OUTER\s+)?JOIN\s*)((?:(?!\s+(UPDATE|JOIN|ON|SET|WHERE)\s+).)+)\s*ON((?:(?!\s+(JOIN|LEFT|SET|WHERE)\s+).)+)\s*SET((?:(?!\s+(WHERE)\s+).)+)\s*WHERE\s+(.*)""", r"""
UPDATE \1\nSET \7\nFROM \3\n\nWHERE \9\nAND \5""", sql_command, flags=re.DOTALL, label='UPDATE/(JOIN|LEFT OUTER JOIN)/ON/SET/WHERE')

          # Generic UPDATE/(JOIN|LEFT OUTER JOIN)/ON/SET
          sql_command = my_re_sub(debug_fh, r"""UPDATE\s*((?:(?!\s+(UPDATE|JOIN|LEFT|ON|SET|WHERE)\s+).)+)\s*(?:(?:LEFT\s+OUTER\s+)?JOIN\s*)((?:(?!\s+(UPDATE|JOIN|ON|SET|WHERE)\s+).)+)\s*ON((?:(?!\s+(JOIN|LEFT|SET|WHERE)\s+).)+)\s*SET\s+(.*)""", r"""
UPDATE \1\nSET \7\nFROM \3\n\nWHERE \5\n""", sql_command, flags=re.DOTALL, label='UPDATE/(JOIN|LEFT OUTER JOIN)/ON/SET')

          # Custom hack for UNION data type casting issue
          sql_command = my_re_sub(debug_fh, r"""(SELECT '[^']+'\s*,\s*)(MAX\([^)]+\)(?!::VARCHAR))(\s+FROM\s+[^\s]+\s+UNION\s*)""", r"""\1IFNULL(\2::VARCHAR,'0')\3""", sql_command, label='UNION data type VARCHAR hack')


#              sql_command = my_re_sub(debug_fh, r"""
#JOIN (CORE.PUBLIC.payment_Profile pp) ON (pp.payment_Profile_ID = rpp.payment_Profile_ID)
#(LEFT OUTER JOIN MAIN.stg.organization_Paid_User ON organization_Paid_User.payment_Profile_ID = pp.payment_Profile_ID)
#SET rpp\.(.*)""", r"""
#SET \4
#FROM \1
#\3
#WHERE \2
#""", sql_command, flags=re.DOTALL)

#              if 'JOIN CORE.PUBLIC.payment_Profile pp ON pp.payment_Profile_ID = rpp.payment_Profile_ID' in sql_command:
#                sql_command = my_re_sub(debug_fh, r"""JOIN WORKSPACE.stg.c_Dunn_pp_Updates B ON A.payment_Profile_ID = B.payment_Profile_ID\n""", '', sql_command)
#                sql_command = sql_command.replace('A.','') + '\nFROM CORE.PUBLIC.payment_Profile pp ON pp.payment_Profile_ID = rpp.payment_Profile_ID'

#              sql_command = my_re_sub(debug_fh, r"""(UPDATE\s+.+?(?=JOIN))JOIN\s+(.+?(?=ON))ON\s+(.+?(?=SET))SET\s+(.+?(?=WHERE))WHERE\s+.*""", r"""
#\1
#SET \4
#FROM \2
#\5
#AND \3
#""", sql_command, flags=re.DOTALL)

#              sql_command = my_re_sub(debug_fh, r"""
#UPDATE MAIN.hist.payment_Profile 
#JOIN MAIN.arc.payment_Profile_Adjustments ON payment_Profile.payment_Profile_ID = payment_Profile_Adjustments.payment_Profile_ID
#SET payment_Profile.hist_effective_Thru_Date_Time = payment_Profile_Adjustments.hist_effective_Thru_Date_Time
#WHERE payment_Profile.hist_effective_Thru_Date_Time = DATEADD\(SECOND, -1, payment_Profile_Adjustments.modify_Date_Time\) """, r"""
#UPDATE MAIN.hist.payment_Profile 
#SET hist_effective_Thru_Date_Time = payment_Profile_Adjustments.hist_effective_Thru_Date_Time
#FROM MAIN.arc.payment_Profile_Adjustments
#WHERE payment_Profile.hist_effective_Thru_Date_Time = DATEADD(SECOND, -1, payment_Profile_Adjustments.modify_Date_Time)
#AND payment_Profile.payment_Profile_ID = payment_Profile_Adjustments.payment_Profile_ID
#""", sql_command)

          sql_command = my_re_sub(debug_fh, r"""( /\* 7 team, 8 team plus, 6 enterprise \*/)
""", r"""""", sql_command)

          sql_command = my_re_sub(debug_fh, r"""(SELECT np\.user_ID, )(lct.last_Session_Log_ID)( max_Session_Log_ID)""", r"""\1ANY_VALUE(\2)\3""", sql_command)  # Short term hack

          sql_command = my_re_sub(debug_fh, r"""
SELECT MIN\(pp.payment_Profile_ID\),
pp.owner_ID,
pp.account_Type,
pp.payment_Type,
pp.payment_Flags,
pp.parent_Payment_Profile_ID,
pp.payment_Start_Date_Time,
pp.payment_End_Date_Time,
pp.estimated_Last_Payment_Date,
pp.actual_Last_Payment_Date,
pp.next_Payment_Date,
pp.product_ID,
pp.product_Price_ID,
pp.promo_Code,
pp.user_Limit,
pp.bonus_Sheet_Count,
pp.bonus_User_Count,
pp.bonus_Storage_Kb,
pp.loyalty_Bonus_Sheet_Count,
pp.loyalty_Bonus_Storage_Kb,
pp.loyalty_Next_Bonus_Date_Time,
pp.loyalty_Next_Bonus_Sheet_Count,
pp.loyalty_Next_Bonus_Storage_Kb,
pp.payment_Term,
pp.currency_Code,
pp.plan_Rate,
pp.plan_Tax_Rate,
pp.tax_Calculated_Rate,
pp.tax_Last_Calc_Date_Time,
pp.primary_Contact_Phone,
pp.referral_Email_Address,
pp.reporting_Seat_Count,
pp.bill_To_Recurring_Billing_ID,
pp.bill_To_CCNumber,
pp.bill_To_CCExp_Month,
pp.bill_To_CCExp_Year,
pp.bill_To_CCName,
pp.bill_To_First_Name,
pp.bill_To_Last_Name,
pp.bill_To_Email_Address,
pp.bill_To_Company,
pp.bill_To_PO,
pp.bill_To_Address1,
pp.bill_To_Address2,
pp.bill_To_City,
pp.bill_To_Region_Code,
pp.bill_To_Post_Code,
pp.bill_To_Country_Code,
pp.bill_To_PPPayer_ID,
pp.bill_To_PPAgreement_ID,
pp.insert_Date_Time,
pp.insert_By_User_ID,
pp.modify_Date_Time,
pp.modify_By_User_ID,
pp.session_Log_ID,
pp.data_Timestamp,
pp.hist_effective_Thru_Date_Time,
pp.plan_Rate/hce.exchange_Rate
""", r"""
SELECT MIN(pp.payment_Profile_ID),
pp.owner_ID,
pp.account_Type,
ANY_VALUE(pp.payment_Type),
ANY_VALUE(pp.payment_Flags),
ANY_VALUE(pp.parent_Payment_Profile_ID),
ANY_VALUE(pp.payment_Start_Date_Time),
ANY_VALUE(pp.payment_End_Date_Time),
ANY_VALUE(pp.estimated_Last_Payment_Date),
ANY_VALUE(pp.actual_Last_Payment_Date),
ANY_VALUE(pp.next_Payment_Date),
ANY_VALUE(pp.product_ID),
ANY_VALUE(pp.product_Price_ID),
ANY_VALUE(pp.promo_Code),
ANY_VALUE(pp.user_Limit),
ANY_VALUE(pp.bonus_Sheet_Count),
ANY_VALUE(pp.bonus_User_Count),
ANY_VALUE(pp.bonus_Storage_Kb),
ANY_VALUE(pp.loyalty_Bonus_Sheet_Count),
ANY_VALUE(pp.loyalty_Bonus_Storage_Kb),
ANY_VALUE(pp.loyalty_Next_Bonus_Date_Time),
ANY_VALUE(pp.loyalty_Next_Bonus_Sheet_Count),
ANY_VALUE(pp.loyalty_Next_Bonus_Storage_Kb),
ANY_VALUE(pp.payment_Term),
ANY_VALUE(pp.currency_Code),
ANY_VALUE(pp.plan_Rate),
ANY_VALUE(pp.plan_Tax_Rate),
ANY_VALUE(pp.tax_Calculated_Rate),
ANY_VALUE(pp.tax_Last_Calc_Date_Time),
ANY_VALUE(pp.primary_Contact_Phone),
ANY_VALUE(pp.referral_Email_Address),
ANY_VALUE(pp.reporting_Seat_Count),
ANY_VALUE(pp.bill_To_Recurring_Billing_ID),
ANY_VALUE(pp.bill_To_CCNumber),
ANY_VALUE(pp.bill_To_CCExp_Month),
ANY_VALUE(pp.bill_To_CCExp_Year),
ANY_VALUE(pp.bill_To_CCName),
ANY_VALUE(pp.bill_To_First_Name),
ANY_VALUE(pp.bill_To_Last_Name),
ANY_VALUE(pp.bill_To_Email_Address),
ANY_VALUE(pp.bill_To_Company),
ANY_VALUE(pp.bill_To_PO),
ANY_VALUE(pp.bill_To_Address1),
ANY_VALUE(pp.bill_To_Address2),
ANY_VALUE(pp.bill_To_City),
ANY_VALUE(pp.bill_To_Region_Code),
ANY_VALUE(pp.bill_To_Post_Code),
ANY_VALUE(pp.bill_To_Country_Code),
ANY_VALUE(pp.bill_To_PPPayer_ID),
ANY_VALUE(pp.bill_To_PPAgreement_ID),
ANY_VALUE(pp.insert_Date_Time),
ANY_VALUE(pp.insert_By_User_ID),
pp.modify_Date_Time,
ANY_VALUE(pp.modify_By_User_ID),
ANY_VALUE(pp.session_Log_ID),
ANY_VALUE(pp.data_Timestamp),
pp.hist_effective_Thru_Date_Time,
ANY_VALUE(pp.plan_Rate/hce.exchange_Rate)
""", sql_command)

          sql_command = my_re_sub(debug_fh, r"""
WHERE pp.payment_Profile_ID <= \$maxpp_ID AND pp.modify_Date_Time >= \$maxppModify

GROUP BY 1
""", r"""
WHERE pp.payment_Profile_ID <= $maxpp_ID AND pp.modify_Date_Time >= $maxppModify

GROUP BY 1,2,3,4,5,6,7,8,9,
   10,11,12,13,14,15,16,17,18,19,
   20,21,22,23,24,25,26,27,28,29,
   30,31,32,33,34,35,36,37,38,39,
   40,41,42,43,44,45,46,   48,49,50
""", sql_command)

          sql_command = my_re_sub(debug_fh, r"""
(WHERE pp.payment_Profile_ID [<>].*)

GROUP BY 1
""", r"""
\1

GROUP BY 1,2,3,4,5,6,7,8,9,
   10,11,12,13,14,15,16,17,18,19,
   20,21,22,23,24,25,26,27,28,29,
   30,31,32,33,34,35,36,37,38,39,
   40,41,42,43,44,45,46,   48,49,50
""", sql_command)

          sql_command = my_re_sub(debug_fh, r"""(ppc.has_Org_Profile)""", r"""CASE WHEN \1 THEN 1 ELSE 0 END""", sql_command)

#              if 'CALL ' in sql_command \
#                and 'CALL LEADFLOW.SMARTSHEET_START_LOG' not in sql_command \
#                and 'CALL LEADFLOW.SMARTSHEET_STOP_LOG' not in sql_command \
#                and 'CALL MAIN.SMARTSHEET_START_LOG' not in sql_command \
#                and 'CALL MAIN.SMARTSHEET_STOP_LOG' not in sql_command \
#                and 'CALL MAIN.SEGMENTED_START_LOG' not in sql_command \
#                and 'CALL MAIN.SEGMENTED_STOP_LOG' not in sql_command \
#                and 'CALL WORKSPACE.ch_distinctWordsInColumn' not in sql_command \
#                and 'CALL MAIN.etl_request_Log' not in sql_command \
#                and 'CALL MAIN.etl_client_Event' not in sql_command \
#                and 'CALL MAIN.utl_logProcessStart' not in sql_command \
#                and 'CALL MAIN.utl_logProcessEnd' not in sql_command:
#                print(sql_command.strip())

#        def conv_tbl_name(orig_table_name, rename_table_name):
#          return (orig_table_name[-1::-1].split('.',1)[1][-1::-1] + '.' + rename_table_name) if '.' not in rename_table_name else rename_table_name
#        def rename_sub(matchobj):
#          return ('ALTER TABLE {} RENAME TO {}'.format(matchobj.group(1), conv_tbl_name(matchobj.group(1), matchobj.group(2))))
#
#        target_snowflake_file_contents = re.sub(r'ALTER TABLE +([^;,]+)RENAME TO +([^;,]+)', rename_sub, target_snowflake_file_contents)

          if sql_command.strip():
#                target_fh.write('{}{}'.format(sql_command, ';' if not sql_command.endswith(EOL) else ''))
            target_fh.write('{}{}'.format(sql_command, ';'))

###########################################################

def convert_files_to_snowflake(file_list_file_name, map_file_name_fq, source_file_path_root, snowflake_file_path_root):

  maps = load_column_map(map_file_name_fq)

  with open(file_list_file_name, 'r') as file_list_fh:
    for file_name in file_list_fh:

      file_name = file_name.rstrip(EOL)
      if file_name.endswith('.sql'): 

        file_name_fq = os.path.join(source_file_path_root, file_name)

        file_name_fq = re.sub("\\\\", "/", file_name_fq)

        snowflake_filename_fq = os.path.join(snowflake_file_path_root, file_name)
        os.makedirs(os.path.dirname(snowflake_filename_fq), exist_ok=True)

        debug_filename_fq = os.path.join(snowflake_file_path_root, '{}.debug.convert.txt'.format(file_name))

        convert_file_to_snowflake(maps, file_name_fq, snowflake_filename_fq, debug_filename_fq)

###########################################################
# MAIN
###########################################################

if __name__ == "__main__":

  parser = argparse.ArgumentParser(description = 'Convert MySQL SQL to Snowflake SQL')
  parser.add_argument(
    'source_file_path_root', 
    help = 'The root file_path containing the .sql files to be converted from MySQL to Snowflake'
  )
  parser.add_argument(
    'file_list', 
    help = 'The configuration file containing the specific list of .sql file names (relative to source_file_path_root) that are to be converted from MySQL to Snowflake'
  )
  parser.add_argument(
    'snowflake_file_path_root', 
    help = 'The root file path for the target converted .sql files'
  )
  args = parser.parse_args()

  file_list_file_name = args.file_list

  #map_file_name_fq = r'.\new_snowflake_dictionary_with_schema.csv'

  map_file_name_fq = '/Users/snaqvi/Downloads/insight2-master/snowflake/new_snowflake_dictionary_with_schema.csv'
  source_file_path_root = args.source_file_path_root

  snowflake_file_path_root = args.snowflake_file_path_root

  #####################
  print(source_file_path_root)
  print(snowflake_file_path_root)
  convert_files_to_snowflake(file_list_file_name, map_file_name_fq, source_file_path_root, snowflake_file_path_root)

