import re
import os
import argparse

EOL = '\n'

def convert_files(source_file_path_root, source_file_list, target_snowflake_file_path):

  with open(source_file_list, 'r') as src_list_fh:
    for source_file_name in src_list_fh:

      source_file_name = source_file_name.rstrip(EOL)
      if source_file_name.endswith('.sql'): 

        source_file_name_fq = os.path.join(source_file_path_root, source_file_name)

        print('Processing source file [{}]...'.format(source_file_name_fq))
        target_snowflake_filename_fq = os.path.join(target_snowflake_file_path, source_file_name)
        os.makedirs(os.path.dirname(target_snowflake_filename_fq), exist_ok=True)
        with open(source_file_name_fq, 'r') as source_fh:
          with open(target_snowflake_filename_fq, 'w') as target_fh:

            source_file_contents = source_fh.read()
            i = 0
            for source_command in source_file_contents.split(';'):  # We cannot use "\n" here because there are many places with "blah blah; -- comment afterwards"

              i += 1
              source_command = source_command
#              print('[{}]: [{}]'.format(i, source_command))

              target_command = source_command

              # Determine which commands to transform
              target_command = re.sub("""SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED""", '', target_command)
              target_command = re.sub("""SET @@sql_mode = ''""", '', target_command)
              target_command = re.sub("""SHOW VARIABLES LIKE '[^^']*'""", '', target_command)
              target_command = re.sub("""NOW\(\)""", """CURRENT_TIMESTAMP()""", target_command)
              target_command = re.sub("""SELECT DATABASE\(\)""", """SELECT CURRENT_DATABASE()""", target_command)
              target_command = re.sub("""SELECT ([^ ]+) INTO @([^ ]+)""", 'SET \2 = \1', target_command)  # !!! This appears to be broken
              target_command = re.sub("""(,\r\n)?index *\([^;\n)]+\)""", """""", target_command)

#        def conv_tbl_name(orig_table_name, rename_table_name):
#          return (orig_table_name[-1::-1].split('.',1)[1][-1::-1] + '.' + rename_table_name) if '.' not in rename_table_name else rename_table_name
#        def rename_sub(matchobj):
#          return ('ALTER TABLE {} RENAME TO {}'.format(matchobj.group(1), conv_tbl_name(matchobj.group(1), matchobj.group(2))))
#
#        target_snowflake_file_contents = re.sub(r'ALTER TABLE +([^;,]+)RENAME TO +([^;,]+)', rename_sub, target_snowflake_file_contents)

#              if (target_command != source_command):
#                print('[{}]: [{}]'.format(i, source_command))
#                print('[{}]: [{}]'.format(i, target_command))
 
              if target_command.strip():
                target_fh.write('{};{}'.format(target_command, EOL))
        
###########################################################
# MAIN
###########################################################

if __name__ == "__main__":

  parser = argparse.ArgumentParser(description = 'Convert MySQL SQL to Snowflake SQL')
  parser.add_argument(
    'source_file_path_root', 
    help = 'The root file_path containing the .sql files to be converted from MySQL to Snowflake'
  )
  parser.add_argument(
    'source_file_list', 
    help = 'The configuration file containing the specific list of .sql file names (relative to source_file_path_root) that are to be converted from MySQL to Snowflake'
  )
  parser.add_argument(
    'target_snowflake_file_path', 
    help = 'The root file path for the target converted .sql files'
  )
  args = parser.parse_args()

  source_file_path_root = args.source_file_path_root

  source_file_list = args.source_file_list

  target_snowflake_file_path = args.target_snowflake_file_path
 # if not os.path.isdir(target_snowflake_file_path):
 #   os.makedirs(target_snowflake_file_path)

  convert_files(source_file_path_root, source_file_list, target_snowflake_file_path)

