Basic README for MySQL -> Snowflake SQL conversion scripts...

To generate Snowflake SQL files from MySQL files:
  (1) Ensure that the MySQL files are available locally (or through a network share) from the host that is executing the Python scripts
      - Recommended approach is to simply clone the GitHub repo to the host
  (2) Place the ConvMysqlToSnowflake.py file into a convenient directory; I chose to create a "Snowflake" directory just inside of the "insight2" directory that I cloned from GitHub
  (3) Construct a configuration file that contains the list of MySQL files that are to be converted. Entries are relative to the MySQL root directory.
      - Sample subset of entries might look like this (based on a root of "insight2":

marketo-importer\marketoLeadsUploadCondeep.sql
marketo-importer\marketo_nightly_update.sql
salesforce-importer\sfdc_contactLeadUpload.sql
salesforce-importer\sfdc_domainUpload.sql
salesforce-importer\sfdc_opportunityUpload.sql
stats\marketo-tableau\daily-marketo-leadActivities.sql
stats\marketo-tableau\daily-marketo-leadflowScoringAndSalesAssignment.sql
stats\marketo-tableau\daily-marketo-leadLatencyList.sql
stats\marketo-tableau\daily-marketo-netPromoterScoreData.sql
...
stats\query\tableau-trialReportUpdateV2.sql
stats\query\tableau-unlicensedOrgMembersV2.sql
stats\query\TemplateUsageConversionV2.sql
stats\query\ThrowawayPart1Bookings.sql
stats\query\ThrowawayPart2Trials.sql
stats\query\ThrowawayPart3SalesReports.sql
stats\query\ThrowawayPart4MarketoPushData.sql
stats\query\ThrowawayPart5Misc.sql
stats\query\ToothbrushCSscatterDailyVersionV2.sql

  (4) Open a command shell, and "cd" to the directory that contains the Python script (in my case, it was "c:\GitRepos\Clients\Smartsheet\insight2\Snowflake")
  (5) Execute the Python script:

Template:

python .\ConvMysqlToSnowflake.py <MySQL root directory> <fully qualified cfg file name> <Snowflake root directory>

Note: if <Snowflake root directory> (or any sub-directories) that need to be created (mirrored) from MySQL directory structure do not exist, they will be created automatically

Actual (sample) execution:

python .\ConvMysqlToSnowflake.py ..\ .\source_mysql_file_list.cfgx.txt .\Converted

Here is my sample output:

c:\GitRepos\Clients\Smartsheet\insight2\Snowflake>python .\ConvMysqlToSnowflake.py ..\ .\source_mysql_file_list.cfgx.txt .\Converted
Processed [62322] lines in file [.\new_snowflake_dictionary_with_schema.csv].
Processing source file [..\stats\query\ThrowawayPart1Bookings.sql]...
  Applying DB_TABLE_MAP (keycount=[5087]) transformations...
  Applying TABLE_COLUMN_MAP (keycount=[60808]) transformations...
  Applying COLUMN_MAP (keycount=[10527]) transformations...
  Applying DB_MAP (keycount=[7]) transformations...
Applying logical transformations...

For each Snowflake file that is generated, a there is a corresponding "debug" file (with a "debug.convert.txt" suffix) that is automatically created, which contains every transformation that has been applied to the MySQL script, in order. Feel free to ignore these, if they are not useful to you.

*** Note: during my R&D of this script, it also had functionality to execute the generated SQL against Snowflake. But I removed that, to prevent anyone from erroneously applying generated SQL. This allows for manual intervention (optimization or any other manual code transformations) before it is actually executed.



At this point, the code can be adjusted or whatever.


Then, in order to actually execute the SQL scripts against Snowflake, you would need to:
  (1) Ensure that the Snowflake files are available locally (or through a network share) from the host that is executing the Python scripts
      - This step only makes sense if you did NOT just generate the files (as described above).
  (2) Place the ExecSnowflakeSQLScripts.py file into a convenient directory; I chose to create a "Snowflake" directory just inside of the "insight2" directory that I cloned from GitHub
  (3) Construct a configuration file that contains the list of MySQL files that are to be executed. Entries are relative to the Snowflake root directory.
      - Format of entries is identical to what was shared above (for the ConvMysqlToSnowflake.py Python script).
      - If you are NOT doing any manual editing of auto-generated SQL files (from MySQL to Snowflake), you can use the exact same cfg file as you used above.
      - If you ARE doing any manual editing, and if you save the edited files with a different name as the auto-generated file it originated from, then make sure you provide the NEW file names here.
  (4) Open a command shell, and "cd" to the directory that contains the Python script (in my case, it was "c:\GitRepos\Clients\Smartsheet\insight2\Snowflake")
  (5) Execute the Python script:

Template:

python .\ExecSnowflakeSQLScripts.py <fully qualified cfg file name> <Snowflake root directory>

Actual (sample) execution:

python .\ExecSnowflakeSQLScripts.py .\source_mysql_file_list.cfgx.txt .\Converted

Here is my sample output:

c:\GitRepos\Clients\Smartsheet\insight2\Snowflake>python .\ExecSnowflakeSQLScripts.py .\source_mysql_file_list.cfgx.txt .\Converted
Executing snowflake files in list...
Executing snowflake file [.\Converted\stats\query\ThrowawayPart1Bookings.sql]...
Processing [436] commands...

NOTE: At the end of the script, there is a line that sets a parameter as "doExec=True"; setting this to False will generate a debug log of SQL commands (after comments are stripped out), but not actually execute any SQL.

For each Snowflake file that is executed, a there is a corresponding "debug" file (with a "debug.exec.txt" suffix) that is automatically created, which contains the "final" SQL file that was processed, after comments were stripped out.
