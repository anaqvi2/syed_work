
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-eduPlansV2.csv");

SET @@sql_mode = '';


/*Be sure to adjust ref_holidays table for holidays that fall on Weekends*/
DROP TABLE IF EXISTS rpt_workspace.jlatta_edustdents;
CREATE TEMPORARY TABLE rpt_workspace.jlatta_edustdents

SELECT
u.userID,
u.firstName,
u.lastName,
u.emailAddress,
u.domain,
IF (s.bucket IS NULL, "Viral", s.bucket) AS bucket,
IF(s.bucket IS NULL, "Sharing",s.sourceFriendly) AS sourceFriendly,-- if statement
IF(s.bucket IS NULL, "Sharing",s.subSourceFriendly) AS subSourceFriendly,
s.campaign,
l.firstDayLogCount,
s.signupInsertDateTime
FROM rpt_main_02.userAccount u
LEFT JOIN rpt_main_02.rpt_signupSource s
ON s.userID=u.userID 
JOIN rpt_main_02.hist_paymentProfile h
ON h.ownerID=u.userID 
AND h.productID=9 
JOIN rpt_main_02.rpt_clientLogCountsByUserArchived l
ON l.userID=u.userID
WHERE u.domain IN ("Uconn.edu",
"VT.edu",
"Buffalo.edu",
"Bc.edu",
"Illinois.edu",
"Vanderbilt.edu",
"Duke.edu",
"Uw.edu",
"Dartmouth.edu",
"Clemson.edu");


-- cumulative numbers 
DROP TABLE IF EXISTS rpt_workspace.jlatta_edustdentsrollup;
CREATE TEMPORARY TABLE rpt_workspace.jlatta_edustdentsrollup

SELECT 
u.domain,
COUNT(DISTINCT h. paymentProfileID) AS NumberofStudentplans,
COUNT(DISTINCT r.paymentProfileID) AS NumberofTrial,
COUNT(DISTINCT s.userID) AS NumberofCollabsPaidplans,
IF(SUM(l2.firstDayLogCount) IS NULL, 0, SUM(l2.firstDayLogCount)) AS totalfirstDayLogCount_student,
IF(SUM(l1.firstDayLogCount) IS NULL, 0, SUM(l1.firstDayLogCount)) AS totalfirstDayLogCount_collabs,
IF(SUM(l.firstDayLogCount) IS NULL, 0, SUM(l.firstDayLogCount)) AS totalfirstDayLogCount_Trial 
FROM rpt_main_02.userAccount u
LEFT JOIN rpt_main_02.hist_paymentProfile h
ON u.userID=h.ownerID
AND h.productID=9 
LEFT JOIN rpt_main_02.rpt_paymentProfile r
ON r.mainContactUserID=u.userID
AND r.productID=1
LEFT JOIN rpt_main_02.rpt_paidPlanSheetAccess s
ON u.userID=s.userID
AND s.loginCount >0
AND s.userPlanID IS NULL
LEFT JOIN rpt_main_02.rpt_clientLogCountsByUserArchived l FORCE INDEX (PRIMARY) 
ON l.userID=r.mainContactUserID
AND r.productID=1
LEFT JOIN rpt_main_02.rpt_clientLogCountsByUserArchived l1 FORCE INDEX (PRIMARY) 
ON l1.userID=s.userID
AND s.loginCount >0
AND s.userPlanID IS NULL
LEFT JOIN rpt_main_02.rpt_clientLogCountsByUserArchived l2 FORCE INDEX (PRIMARY) 
ON l2.userID=h.ownerID
AND h.productID=9 
WHERE u.domain IN ("Uconn.edu",
"VT.edu",
"Buffalo.edu",
"Bc.edu",
"Illinois.edu",
"Vanderbilt.edu",
"Duke.edu",
"Uw.edu",
"Dartmouth.edu",
"Clemson.edu")
GROUP BY 1;

SELECT 
j.userID,
j.firstName,
j.lastName,
j.emailAddress,
j.bucket,
j.sourceFriendly,
j.subSourceFriendly,
j.campaign,
j.firstDayLogCount,
j.signupInsertDateTime,
j1.* 
FROM rpt_workspace.jlatta_edustdentsrollup j1
LEFT JOIN rpt_workspace.jlatta_edustdents j
ON j.domain=j1.domain;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-eduPlansV2.csv");