SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("payingCustomersV2.csv");

/*Generating payingCustomersV2.csv*/
SELECT  
  rp.accountTypeFriendly,
  rp.productName,
  rp.userLimit,
  rp.mainContactUserID, 
	rp.mainContactEmailAddress, 
	userAccount.firstName, 
	userAccount.lastName,
	userAccount.languageFriendly, 
	userAccount.countryFriendly,
	rp.paymentProfileID, 
	rp.planRate_USD AS planRate, 
	(rp.planRate_USD/rp.paymentTerm)*12 AS ACV,
	rp.paymentTypeFriendly, 
	rp.paymentTermFriendly, 
	rp.paymentStartDateClean,
	rp.actualLastPaymentDate, 
	GREATEST(
	    DATE_ADD(IFNULL(rp.actualLastPaymentDate,rp.paymentStartDateClean), INTERVAL rp.paymentTerm MONTH),
	    IFNULL(rp.nextPaymentDate, rp.paymentStartDateClean)
	  ) AS CalculatedNextPaymentDateOld,
	rp.billToRecurringBillingID, 
	rp.lastUserLoginDate,
	rp.paymentTotal AS localPlanRate,
	(rp.paymentTotal/rp.paymentTerm)*12 AS localACV,
	rp.currencyCode,
	rp.paymentEndDateTime,
	
CASE WHEN rp.nextPaymentDate > NOW() THEN rp.nextPaymentDate 
	ELSE CASE WHEN rp.paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_ADD(rp.nextPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN rp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN rp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(rp.actualLastPaymentDate), "-",DAY(rp.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(rp.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(rp.paymentStartDateClean)) + 1) YEAR) END
		WHEN rp.paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rp.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.nextPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN rp.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL rp.paymentTerm MONTH)
			/*If there's no recent actual last payment, add arpropriate number of terms*/
			WHEN rp.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rp.paymentTerm MONTH) 
			THEN DATE_ADD(rp.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rp.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN rp.paymentTerm = 1 
			THEN DATE_ADD(rp.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rp.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(rp.paymentStartDateClean, INTERVAL +(rp.paymentTerm) MONTH) END
		ELSE "Other" END END AS CalculatedNextPaymentDateNew,
		
	rp.bonusUserCount,
	
	rp.billToCountryFriendly AS 'BillingCountry',
	
	cp.billToRegionCode,
	cp.planTaxRate AS 'TaxRate',
	rp.bonusUserCount,
	CASE WHEN (cp.paymentFlags & 32 = 32) THEN 1 ELSE 0 END AS taxExempt,
	cp.taxLastCalcDateTime
	
FROM rpt_main_02.rpt_paymentProfile rp 
JOIN rpt_main_02.userAccount ON rp.mainContactUserID = userAccount.userID AND rp.accountType != 2
JOIN ss_core_02.paymentProfile cp ON cp.paymentProfileID = rp.paymentProfileID
WHERE rp.paymentType > 0 
ORDER BY 3
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("payingCustomersV2.csv");
