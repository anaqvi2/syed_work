set session transaction isolation level read uncommitted;

DROP TABLE IF EXISTS rpt_main_02.arc_templateAncestor;
CREATE TABLE rpt_main_02.arc_templateAncestor(
	templateID BIGINT,
	containerID BIGINT, 
	sourceContainerID BIGINT,
	sourceContainerType TINYINT,
	sourceContainerName VARCHAR(50),
	insertByUserID BIGINT,
	insertDateTime DATETIME,
	ancestorlevel TINYINT,
	INDEX (sourceContainerID),
	KEY containerID (containerID))
;
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("TemplateUsageConversion.csv insert");
	
INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
template.templateID,
template.containerID,
container.containerID,
container.containerType,
container.name,
container.insertByUserID,
container.insertDateTime,
0
FROM rpt_main_02.template
STRAIGHT_JOIN rpt_main_02.container ON template.containerID = container.containerID AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
WHERE isPublic = 1
;


	
INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
1
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 0
AND container.sourceID IS NOT NULL
;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
2
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000

WHERE ancestorlevel = 1
AND container.sourceID IS NOT NULL
;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
3
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 2
AND container.sourceID IS NOT NULL
;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
4
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 3
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
5
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 4
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
6
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 5
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
7
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 6
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
8
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 7
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
9
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 8
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
10
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 9
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
11
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 10
AND container.sourceID IS NOT NULL;


INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
12
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 11
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
13
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 12
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
14
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 13
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
15
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 14
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
16
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 15
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
17
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 16
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
18
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 17
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
19
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 18
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
20
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 19
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
21
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 20
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
22
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 21
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
23
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 22
AND container.sourceID IS NOT NULL;

INSERT rpt_main_02.arc_templateAncestor (templateID, containerID, sourceContainerID, sourceContainerType, sourceContainerName, insertByUserID, insertDateTime, ancestorlevel)
SELECT 
rpt_main_02.arc_templateAncestor.templateID,
rpt_main_02.arc_templateAncestor.containerID,
container.sourceID,
containerAncestor.containerType,
containerAncestor.name,
containerAncestor.insertByUserID,
containerAncestor.insertDateTime,
24
FROM rpt_main_02.arc_templateAncestor
JOIN rpt_main_02.container ON rpt_main_02.arc_templateAncestor.sourceContainerID = container.containerID 
	AND container.containerType IN (2,3,6,7) AND container.containerID > 1000000
JOIN rpt_main_02.container containerAncestor ON container.sourceID = containerAncestor.containerID 
	AND containerAncestor.containerType IN (2,3,6,7) AND containerAncestor.containerID > 1000000
WHERE ancestorlevel = 23
AND container.sourceID IS NOT NULL;

DELETE FROM rpt_main_02.arc_templateAncestor WHERE sourceContainerID < 1000000;
DELETE FROM rpt_main_02.arc_templateAncestor WHERE sourceContainerType = 6;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("TemplateUsageConversion.csv insert");

