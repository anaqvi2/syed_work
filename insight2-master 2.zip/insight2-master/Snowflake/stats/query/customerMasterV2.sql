SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
-- CALL rpt_main_02.SMARTSHEET_START_LOG ("customerMasterV2.csv");
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_workspace.bbosworth_CustomerMaster");

SET @@sql_mode = '';


DROP TABLE IF EXISTS rpt_workspace.bbosworth_AccountCustomer;
CREATE TABLE rpt_workspace.bbosworth_AccountCustomer (
AccountID VARCHAR(25),
AccountName VARCHAR(255),
AccountDomain VARCHAR(100),
paymentProfileID INT(11),
ISPFlag VARCHAR(1),
ACV DECIMAL(10,2),
productName VARCHAR(25),
ProductSort INT(4),
userLimit INT(11),
bonusUsers INT(11),
licensedUsers INT(11),
pendingUsers INT(11),
assignedUsers INT(11),
totalCollabs INT(11),
internalCollabs INT(11),
Territory VARCHAR(50),
NumberOfEmployees INT(11),
PaymentStartDate DATETIME,
RegionCode VARCHAR(50),
AcctToBeAssigned VARCHAR(35),
PRIMARY KEY (AccountID, AccountName, AccountDomain, paymentProfileID));

-- CREATE ORGANIZATION OBJECT
DROP TABLE IF EXISTS rpt_workspace.bbosworth_OrgISPCustomer;
CREATE TABLE rpt_workspace.bbosworth_OrgISPCustomer (
MainContactUserId INT(11),
Domain VARCHAR(100),
paymentProfileID INT(11),
ISPFlag VARCHAR(1),
ACV DECIMAL(10,2),
productName VARCHAR(25),
ProductSort INT(4),
userLimit INT(11),
bonusUsers INT(11),
licensedUsers INT(11),
pendingUsers INT(11),
assignedUsers INT(11),
totalCollabs INT(11),
internalCollabs INT(11),
Territory VARCHAR(50),
NumberOfEmployees INT(11),
PaymentStartDate DATETIME,
RegionCode VARCHAR(50),
PRIMARY KEY (paymentProfileID));

-- CREATE MASTER CUSTOMER OBJECT
DROP TABLE IF EXISTS rpt_workspace.bbosworth_CustomerMaster;
CREATE TABLE rpt_workspace.bbosworth_CustomerMaster (
MasterID VARCHAR(35),
MasterName VARCHAR(255),
MasterType VARCHAR(35),
ISPFlag INT(11),
ACV DECIMAL(10,2),
productName VARCHAR(25),
userLimit INT(11),
bonusUsers INT(11),
licensedUsers INT(11),
pendingUsers INT(11),
assignedUsers INT(11),
totalCollabs INT(11),
internalCollabs INT(11),
Territory VARCHAR(50),
NumberOfEmployees INT(11),
PaymentStartDate DATETIME,
RegionCode VARCHAR(50),
AcctToBeAssigned VARCHAR(35),
PRIMARY KEY (MasterID));

/***************************************/

-- ACCOUNT OBJECT
INSERT rpt_workspace.bbosworth_AccountCustomer (AccountID, AccountName, AccountDomain, paymentProfileID, ACV, productName, userLimit, bonusUsers
,licensedUsers, pendingUsers, assignedUsers, totalCollabs, internalCollabs, PaymentStartDate, RegionCode)
SELECT a.Id, a.Name, ppi.Domain, ppi.paymentProfileID, ppi.ACV, ppi.productName, ppi.userLimit, ppi.bonusUsers,ppi.licensedUsers, 
ppi.pendingUsers, ppi.assignedUsers, ppcc.TotalCollaborators, ppcc.internalCollabs, MIN(ppi.PaymentStartDate), hpp.billToRegionCode
FROM rpt_main_02.rpt_paidPlanInfo ppi 
JOIN ss_sfdc_02.domain d ON ppi.domain = d.Domain_Name_URL__c
JOIN ss_sfdc_02.account a ON a.Id = d.Account__c
LEFT JOIN rpt_main_02.hist_paymentProfile hpp ON ppi.paymentProfileID = hpp.paymentProfileID
LEFT JOIN rpt_main_02.rpt_paidPlanCollabCount ppcc ON ppi.paymentProfileID = ppcc.paymentProfileID
WHERE ppi.Domain NOT IN (
						SELECT DOMAIN FROM rpt_main_02.arc_ISPDomains
						)
GROUP BY a.Id, a.Name, ppi.Domain, ppi.paymentProfileID
ORDER BY 1
LIMIT 1234567;

UPDATE rpt_workspace.bbosworth_AccountCustomer
SET ProductSort = CASE
	WHEN productName = 'Enterprise' THEN 1
	WHEN productName = 'Enterprise_Legacy' THEN 2
	WHEN productName = 'Business' THEN 3
    WHEN productName = 'Team' THEN 4
	WHEN productName = 'Advanced' THEN 5
	WHEN productName = 'Basic' THEN 6
    WHEN productName = 'Premium' THEN 7
END;

UPDATE rpt_workspace.bbosworth_AccountCustomer a
JOIN ss_sfdc_02.account b ON a.AccountId = b.Id
SET a.AcctToBeAssigned = b.Account_To_Be_Assigned__c
WHERE b.Account_To_Be_Assigned__c LIKE 'Control%';

-- OrgISPCustomer OBJECT
INSERT rpt_workspace.bbosworth_OrgISPCustomer (MainContactUserId, Domain, paymentProfileID, ACV, productName, userLimit, bonusUsers,
licensedUsers, pendingUsers, assignedUsers, totalCollabs, internalCollabs, PaymentStartDate, RegionCode)
SELECT ppi.MainContactUserId, ppi.Domain, ppi.paymentProfileID, ppi.ACV, ppi.productName, ppi.userLimit, ppi.bonusUsers, ppi.licensedUsers, 
ppi.pendingUsers, ppi.assignedUsers,  ppcc.TotalCollaborators, ppcc.internalCollabs, MIN(ppi.PaymentStartDate), hpp.billToRegionCode
FROM rpt_main_02.rpt_paidPlanInfo ppi 
LEFT JOIN rpt_main_02.hist_paymentProfile hpp ON ppi.paymentProfileID = hpp.paymentProfileID
LEFT JOIN rpt_main_02.rpt_paidPlanCollabCount ppcc ON ppi.paymentProfileID = ppcc.paymentProfileID
WHERE ppi.paymentProfileID NOT IN (
								SELECT paymentProfileID FROM rpt_workspace.bbosworth_AccountCustomer
								)
GROUP BY ppi.MainContactUserId, ppi.Domain, ppi.paymentProfileID
ORDER BY 2,1;

UPDATE rpt_workspace.bbosworth_OrgISPCustomer
SET ProductSort = CASE
	WHEN productName = 'Enterprise' THEN 1
	WHEN productName = 'Enterprise_Legacy' THEN 2
	WHEN productName = 'Business' THEN 3
    WHEN productName = 'Team' THEN 4
	WHEN productName = 'Advanced' THEN 5
	WHEN productName = 'Basic' THEN 6
    WHEN productName = 'Premium' THEN 7
END;

-- ISP OBJECT
UPDATE rpt_workspace.bbosworth_OrgISPCustomer a 
	JOIN rpt_main_02.arc_ISPDomains b ON a.Domain = b.Domain
SET ISPFlag = 1 WHERE 1=1;

UPDATE rpt_workspace.bbosworth_OrgISPCustomer a 
SET ISPFlag = 0 WHERE ISPFlag IS NULL;

-- Customer Master OBJECT
INSERT rpt_workspace.bbosworth_CustomerMaster (MasterID, MasterName, MasterType, ISPFlag, ACV, productName, userLimit, bonusUsers,
licensedUsers, pendingUsers, assignedUsers, PaymentStartDate, RegionCode, TotalCollabs, InternalCollabs, AcctToBeAssigned)
SELECT AccountID, AccountName, 'Managed Customer', ISPFlag, SUM(ACV), MIN(productSort), SUM(userLimit), SUM(bonusUsers),
SUM(licensedUsers), SUM(pendingUsers), SUM(assignedUsers), MIN(PaymentStartDate), RegionCode, SUM(TotalCollabs), SUM(InternalCollabs), AcctToBeAssigned 
FROM rpt_workspace.bbosworth_AccountCustomer
GROUP BY AccountID, AccountName;

INSERT rpt_workspace.bbosworth_CustomerMaster (MasterID, MasterName, MasterType, ISPFlag, ACV, productName, userLimit, bonusUsers,
licensedUsers, pendingUsers, assignedUsers, PaymentStartDate, RegionCode, TotalCollabs, InternalCollabs)
SELECT MainContactUserId, Domain, 'Unmanaged Customer', ISPFlag, SUM(ACV), MIN(productSort), SUM(userLimit), SUM(bonusUsers),
SUM(licensedUsers), SUM(pendingUsers), SUM(assignedUsers), MIN(PaymentStartDate), RegionCode, SUM(TotalCollabs), SUM(InternalCollabs)
FROM rpt_workspace.bbosworth_OrgISPCustomer
GROUP BY MainContactUserId, Domain;UPDATE rpt_workspace.bbosworth_CustomerMaster
SET MasterType = 'ISP Customer'
WHERE ISPFlag = 1
AND MasterType = 'Unmanaged Customer';

UPDATE rpt_workspace.bbosworth_CustomerMaster
SET ISPFlag = 0
WHERE ISPFlag IS NULL 
AND MasterType = 'Managed Customer';

UPDATE rpt_workspace.bbosworth_CustomerMaster
SET ISPFlag = 1
WHERE MasterName LIKE 'ISP Account%'
AND MasterType = 'Managed Customer' AND ISPFlag = 0;

UPDATE rpt_workspace.bbosworth_CustomerMaster
SET MasterType = 'ISP Customer'
WHERE MasterType = 'Managed Customer' AND ISPFlag = 1;

UPDATE rpt_workspace.bbosworth_CustomerMaster
SET ProductName = CASE
	WHEN productName = '1' THEN 'Enterprise'
	WHEN productName = '2' THEN 'Enterprise_Legacy'
	WHEN productName = '3' THEN 'Business'
    WHEN productName = '4' THEN 'Team'
	WHEN productName = '5' THEN 'Advanced'
	WHEN productName = '6' THEN 'Basic'
    WHEN productName = '7' THEN 'Premium'
END;

UPDATE rpt_workspace.bbosworth_CustomerMaster a
JOIN ss_sfdc_02.account b ON a.MasterId = b.ID
SET a.Territory = b.Territory__c;

UPDATE rpt_workspace.bbosworth_CustomerMaster a
JOIN ss_sfdc_02.account b ON a.MasterId = b.ID
SET a.NumberOfEmployees = b.NumberOfEmployees;


SELECT * FROM rpt_workspace.bbosworth_CustomerMaster 
ORDER BY 9 DESC 
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_workspace.bbosworth_CustomerMaster");
-- CALL rpt_main_02.SMARTSHEET_STOP_LOG ("customerMasterV2.csv");


