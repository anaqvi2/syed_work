SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("integratedContentTrackingV2.sql");

UPDATE rpt_workspace.js_integratedContentStaging
SET slp = RIGHT(slp,((LENGTH(slp)-1)))
WHERE LOCATE("/",slp) = 1;

INSERT IGNORE INTO rpt_workspace.js_integratedContent(userID, signupDateTime, slp, liveDate, writer, externalTemplate, signupBucket, signupSource, signupSubSource, signupCampaign, category, subCategory, EnglishOrForeign, TRPCategory)
SELECT A.userID,A.signupInsertDateTime, A.slp, B.liveDate, B.writer, B.externalTemplate, A.bucket, A.sourceFriendly, A.subSourceFriendly, A.campaign, B.category, B.subCategory, B.EnglishOrForeign, C.trpCategory FROM rpt_main_02.rpt_signupSource A
JOIN rpt_workspace.js_integratedContentStaging B
ON A.slp=B.slp
LEFT JOIN rpt_main_02.ref_trpValues C
ON A.trpValue=C.trpValue;

INSERT IGNORE INTO rpt_workspace.js_integratedContent(userID, signupDateTime, slp, signupBucket, signupSource, signupSubSource, signupCampaign, EnglishOrForeign, PageLanguage, TRPCategory)
SELECT A.userID,A.signupInsertDateTime, A.slp, A.bucket, A.sourceFriendly, A.subSourceFriendly, A.campaign, 'FL', A.lang, B.trpCategory FROM rpt_main_02.rpt_signupSource A
JOIN rpt_main_02.ref_trpValues B
ON A.trpValue=B.trpValue
WHERE B.trpCategory IN ('SEO Pages FL - File Downl','SEO Pages - FL');

DELETE FROM rpt_workspace.js_integratedContent
WHERE slp IS NULL OR slp='';

UPDATE rpt_workspace.js_integratedContent
SET signupCampaign='NULL'
WHERE signupCampaign IS NULL;

UPDATE rpt_workspace.js_integratedContent
SET worm=CONCAT(signupBucket,', ',signupSource,', ',signupSubSource,', ',signupCampaign);

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.userAccount B
ON A.userID=B.userID
SET A.emailAddress=B.emailAddress, A.domain=B.domain, A.country=B.countryFriendly, A.language=B.languageFriendly;

DELETE FROM rpt_workspace.js_integratedContent
WHERE domain LIKE '%smartsheet%';

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.arc_ISPDomains B
ON A.domain=B.domain
SET ISP=1;

UPDATE rpt_workspace.js_integratedContent A
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = A.domain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c AND acc.Fortune_1000_Rank__c > 0
SET A.F1000domain=1;

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.stg_tableauTrialReport B
ON A.userID=B.userID
SET A.trial=1, A.wsl=B.IsStrongLeadAdjusted*B.weightedStrongLeadFactor, A.winDateTime=B.winDate, A.winARR=B.MRR*12, A.winProductName=B.firstWinProduct;

UPDATE rpt_workspace.js_integratedContent
SET win=1
WHERE winDateTime IS NOT NULL;

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.arc_paymentProfile_firstWinProduct B
ON A.userID=B.sourceUserID
JOIN ss_sfdc_02.opportunity C
ON B.paymentProfileID=C.Parent_Payment_Profile_ID__c
SET A.salesAssisted=1
WHERE A.win=1 AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,B.winDate),'%Y-%m-01')=DATE_FORMAT(C.CloseDate,'%Y-%m-01') 
AND C.StageName='Closed Won' AND C.ARR_Variance__c>0 AND C.Product__c!='SERVICES';

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.hist_paymentProfile B
ON A.userID=B.ownerID
SET A.becameLicensed=1
WHERE B.accountType!=3 AND B.productID > 2;

UPDATE rpt_workspace.js_integratedContent
SET liveSignupDateDiff=DATEDIFF(signupDateTime, liveDate);

UPDATE rpt_workspace.js_integratedContent
SET signupWinDateDiff=DATEDIFF(winDateTime,signupDateTime);

/*
alter table rpt_workspace.js_integratedContent
add newLogo int;
*/

UPDATE rpt_workspace.js_integratedContent A
LEFT JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.domain = B.domain AND DATE_FORMAT(A.signupDateTime, '%Y-%m-01 00:00:00') = B.startMonth
SET A.newLogo = CASE WHEN A.ISP=1 THEN 0
WHEN B.domain IS NULL THEN 1 ELSE 0 END;

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_main_02.arc_integratedContentCategory B ON A.slp = B.slpURL
SET A.integratedContentCategory = B.category;

UPDATE rpt_workspace.js_integratedContent A
JOIN rpt_workspace.pj_domainDataCoverage B ON A.domain = B.domain
SET A.companySize = B.companySize;

SELECT * FROM rpt_workspace.js_integratedContent
WHERE liveSignupDateDiff >= 0;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("integratedContentTrackingV2.sql");

