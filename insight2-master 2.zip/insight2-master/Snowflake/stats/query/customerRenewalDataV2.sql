SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("customerRenewalDataV2.csv");

/*Generating customerRenewalDataV2.csv*/
DROP TABLE IF EXISTS rpt_main_02.output_customerRenewalDashboard;

CREATE TABLE IF NOT EXISTS rpt_main_02.output_customerRenewalDashboard(
paymentProfileID BIGINT,
mainContactUserID  BIGINT,
sourceUserID BIGINT, 
mainContactEmailAddress VARCHAR(100),
mainContactDomain VARCHAR(100),
companyName VARCHAR(100),
accountTypeFriendly VARCHAR(50),
paymentTypeFriendly VARCHAR(50),
paymentStartDateClean DATETIME,
productName VARCHAR(50),
MRR DECIMAL(38,10),
ACV DECIMAL(38,10),
paymentTerm TINYINT,
currencyCode  VARCHAR(10),
billToCountryFriendly VARCHAR(100),
DaysFromStartDate INT,
MonthsFromPaymentStartDate INT,
paymentStartDateTime DATETIME,
OldCalculatedNextPaymentDate DATETIME,
NewCalcNextPaymentDate DATETIME,
IsISP BOOL,
FirstPaymentDate DATETIME,
StartingACV DECIMAL(38,10),
userLimit INT,
activeProfileCount INT,
futureLoss BOOL,
salesRep VARCHAR(100),
customerSuccessRep VARCHAR(100),
LoggedIn10Day INT,
LoggedIn30Day INT,
LoggedIn90Day INT,
accountHealth VARCHAR(25),
healthScore INT,
PRIMARY KEY (paymentProfileID),
KEY(sourceUserID))
;


INSERT IGNORE INTO rpt_main_02.output_customerRenewalDashboard
(paymentProfileID,
mainContactUserID,
sourceUserID, 
mainContactEmailAddress,
mainContactDomain,
companyName,
accountTypeFriendly,
paymentTypeFriendly,
paymentStartDateClean,
productName,
MRR,
ACV,
paymentTerm,
currencyCode,
billToCountryFriendly,
DaysFromStartDate,
MonthsFromPaymentStartDate,
paymentStartDateTime,
OldCalculatedNextPaymentDate,
NewCalcNextPaymentDate,
IsISP,
userLimit,
activeProfileCount,
futureLoss,
customerSuccessRep)
SELECT rpt_paymentProfile.paymentProfileID, rpt_paymentProfile.mainContactUserID, rpt_paymentProfile.sourceUserID, rpt_paymentProfile.mainContactEmailAddress, rpt_paymentProfile.mainContactDomain, 
REPLACE(REPLACE(REPLACE(companyName,'"',""),"'",""),",","") AS companyName, 
accountTypeFriendly, paymentTypeFriendly, paymentStartDateClean, productName, 
rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm AS MRR, (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm)*12 AS ACV,
rpt_paymentProfile.paymentTerm, rpt_paymentProfile.currencyCode, rpt_paymentProfile.billToCountryFriendly, 
DATEDIFF(NOW(), rpt_paymentProfile.paymentStartDateClean) AS DaysFromStartDate,
PERIOD_DIFF(DATE_FORMAT(NOW(),'%Y%m'), DATE_FORMAT(rpt_paymentProfile.paymentStartDateClean,'%Y%m')) AS MonthsFromPaymentStartDate,
rpt_paymentProfile.paymentStartDateClean,
GREATEST(
	    DATE_ADD(IFNULL(rpt_paymentProfile.actualLastPaymentDate,rpt_paymentProfile.paymentStartDateClean), INTERVAL rpt_paymentProfile.paymentTerm MONTH),
	    IFNULL(rpt_paymentProfile.nextPaymentDate, rpt_paymentProfile.paymentStartDateClean)
	  ) AS OldCalculatedNextPaymentDate,
CASE WHEN rpt_paymentProfile.nextPaymentDate > NOW() THEN rpt_paymentProfile.nextPaymentDate 
	ELSE CASE WHEN paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(rpt_paymentProfile.actualLastPaymentDate), "-",DAY(rpt_paymentProfile.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) + 1) YEAR) END
		WHEN paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN rpt_paymentProfile.paymentTerm = 1 
			THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(rpt_paymentProfile.paymentTerm) MONTH) END
		ELSE "Other" END
	END
AS NewCalcNextPaymentDate,
CASE WHEN arc_ISPDomains.domain IS NULL THEN 0 ELSE 1 END AS IsISP,
rpt_paymentProfile.userLimit,
rpt_paymentProfile.activeProfileCount,
CASE WHEN rpt_paymentProfile.paymentFlags & 16  = 16 THEN 1 ELSE 0 END AS futureLoss,
domain.Customer_Success__c

FROM rpt_main_02.rpt_paymentProfile 
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON rpt_paymentProfile.mainContactDomain = arc_ISPDomains.domain
LEFT OUTER JOIN ss_sfdc_02.domain FORCE INDEX (domain) ON rpt_paymentProfile.mainContactDomain = domain.Domain_Name_URL__c

WHERE countAsPaid = 1
;

UPDATE rpt_main_02.output_customerRenewalDashboard m1
LEFT OUTER JOIN
(
	SELECT o.*, CONCAT(u.firstName,' ',u.lastName) AS SalesRep, ur.name AS userRole
	FROM ss_sfdc_02.opportunity o
	LEFT JOIN ss_sfdc_02.user u ON o.ownerID=u.Id
	LEFT JOIN ss_sfdc_02.user_role ur ON u.userRoleId=ur.Id
	WHERE o.StageName = 'Closed Won'
	AND o.parent_payment_profile_ID__c IS NOT NULL 
	AND o.product__c != 'Services'
) opp ON m1.paymentProfileID=opp.parent_payment_profile_ID__c
	AND DATE_FORMAT(m1.paymentStartDateTime, '%Y-%m-01') =DATE_FORMAT(opp.CloseDate,'%Y-%m-01')
SET 
	m1.SalesRep = opp.SalesRep
;

UPDATE rpt_main_02.output_customerRenewalDashboard
SET output_customerRenewalDashboard.firstPaymentDate = (SELECT MIN(paymentStartDateTime) FROM rpt_main_02.rpt_monthEndCustomerProductByUser
WHERE output_customerRenewalDashboard.sourceUserID = rpt_monthEndCustomerProductByUser.sourceUserID)
;

UPDATE rpt_main_02.output_customerRenewalDashboard
JOIN rpt_main_02.rpt_monthEndCustomerProductByUser ON output_customerRenewalDashboard.sourceUserID=rpt_monthEndCustomerProductByUser.sourceUserID
	AND output_customerRenewalDashboard.firstPaymentDate = rpt_monthEndCustomerProductByUser.paymentStartDateTime
SET output_customerRenewalDashboard.StartingACV = (rpt_monthEndCustomerProductByUser.paymentTotal/rpt_monthEndCustomerProductByUser.paymentTerm)*12
;

UPDATE rpt_main_02.output_customerRenewalDashboard A
SET LoggedIn10Day = (SELECT COUNT(DISTINCT ppcu.mainContactUserID)
	FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
		JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID AND lct.daysSinceLastLogin <= 10
	WHERE ppcu.planID = A.paymentProfileID);
	
	
UPDATE rpt_main_02.output_customerRenewalDashboard A
SET LoggedIn30Day = (SELECT COUNT(DISTINCT ppcu.mainContactUserID)
	FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
		JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID AND lct.daysSinceLastLogin <= 30
	WHERE ppcu.planID = A.paymentProfileID);
	
UPDATE rpt_main_02.output_customerRenewalDashboard A
SET LoggedIn90Day = (SELECT COUNT(DISTINCT ppcu.mainContactUserID)
	FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
		JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID AND lct.daysSinceLastLogin <= 90
	WHERE ppcu.planID = A.paymentProfileID);

UPDATE rpt_main_02.output_customerRenewalDashboard A
JOIN rpt_main_02.rpt_csPlanReport B ON A.paymentProfileID = B.paymentProfileID
SET 	A.accountHealth = B.accountHealth,
	A.healthScore = B.healthScore;

SELECT * FROM rpt_main_02.output_customerRenewalDashboard;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("customerRenewalDataV2.csv");
