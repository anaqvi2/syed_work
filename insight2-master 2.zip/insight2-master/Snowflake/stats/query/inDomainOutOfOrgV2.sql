SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("inDomainOutOfOrgV2.csv");

DROP TABLE IF EXISTS rpt_main_02.rpt_registeredDomains;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_registeredDomains
(organizationID BIGINT,
domainID BIGINT,
NAME VARCHAR(100),
KEY (domainID),
UNIQUE KEY NAME (NAME),
KEY organizationID (organizationID));

INSERT INTO rpt_main_02.rpt_registeredDomains
SELECT o.organizationID, d.domainID, d.name
FROM rpt_main_02.organization o
JOIN ss_core_02.domain d ON d.organizationID = o.organizationID;

INSERT IGNORE INTO rpt_main_02.rpt_registeredDomains
SELECT o.organizationID, NULL, ppi.domain
FROM rpt_main_02.rpt_paidPlanInfo ppi 
JOIN rpt_main_02.organization o ON o.paymentProfileID = ppi.paymentProfileID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = ppi.domain
WHERE ppi.productName IN('Enterprise','Enterprise_Legacy') AND isp.domain IS NULL;

SELECT u.userID, u.emailAddress, CONCAT(u.firstName," ",u.lastName) AS fullName, u.domain, d.organizationID AS domainOrg, oo.name AS organizationName, 
org.organizationID AS userOrg, o.name AS userOrgName,
CASE WHEN pp.productID IN(0,2) OR pp.productID IS NULL THEN 'Collab'
	ELSE pp.productName END AS currentPlanType,
lct.lastLogin AS lastLoginDate

FROM rpt_main_02.userAccount u
JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_registeredDomains d ON d.name = u.domain
LEFT OUTER JOIN rpt_main_02.organization oo ON oo.organizationID = d.organizationID
LEFT OUTER JOIN rpt_main_02.organizationUserRole org ON org.userID = u.userID AND org.role = 'MEMBER' AND org.state = 1
LEFT OUTER JOIN rpt_main_02.organization o ON o.organizationID = org.organizationID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile pp ON pp.mainContactUserID = u.userID AND pp.accountType != 3
WHERE u.domain = d.name AND (org.organizationID != d.organizationID OR org.organizationID IS NULL)
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("inDomainOutOfOrgV2.csv");
