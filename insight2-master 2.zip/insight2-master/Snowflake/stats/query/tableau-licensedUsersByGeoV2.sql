SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-licensedUsersByGeoV2.sql");

SELECT ppcu.mainContactUserID, ppcu.mainContactEmailAddress, ppcu.mainContactDomain, ppcu.planID, ppcu.planDomain, ppi.salesforceAccountName, ppcu.productName, ppi.userLimit,
ppi.licensedUsers, ppi.ACV, ip.ipCountry, ip.ipRegion, ip.ipCity, CASE WHEN ppcu.persona IN('Tom','Sally') THEN ppcu.persona ELSE 'Other' END AS persona,
IFNULL(ppcu.sysAdmin,0) AS sysAdmin, lct.daysSinceLastLogin, ppcu.paymentStartDate
FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.paymentProfileID = ppcu.planID
LEFT JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = ppcu.mainContactUserID
LEFT JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = ppcu.mainContactUserID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-licensedUsersByGeoV2.sql");

