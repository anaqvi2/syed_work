SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marketo_combinedAPIDeveloperListV2.csv");

DROP TABLE IF EXISTS rpt_main_02.marketo_combinedAPIDeveloperList;
CREATE TABLE IF NOT EXISTS rpt_main_02.marketo_combinedAPIDeveloperList
(  	emailAddress VARCHAR(200),
	firstName VARCHAR(100),
	lastName VARCHAR(100),
	userID BIGINT,
	PRIMARY KEY (userID)

);

INSERT INTO rpt_main_02.marketo_combinedAPIDeveloperList
SELECT 
userAccount.emailAddress,
REPLACE(REPLACE(REPLACE(REPLACE(userAccount.firstName,'"',""),"'",""),",",""),'-',""),
REPLACE(REPLACE(REPLACE(REPLACE(userAccount.lastName,'"',""),"'",""),",",""),'-',""),
userAccount.userID


FROM ss_core_02.apiDeveloper
JOIN rpt_main_02.userAccount ON apiDeveloper.userID = userAccount.userID
JOIN ss_account_02.userConfigSetting ON userAccount.userID = userConfigSetting.userID AND configPropertyID = 1107
LEFT OUTER JOIN ss_core_02.apiClient ON apiClient.apiDeveloperID = apiDeveloper.apiDeveloperID
GROUP BY 1;

INSERT IGNORE INTO rpt_main_02.marketo_combinedAPIDeveloperList
SELECT 
userAccount.emailAddress,
REPLACE(REPLACE(REPLACE(REPLACE(userAccount.firstName,'"',""),"'",""),",",""),'-',""),
REPLACE(REPLACE(REPLACE(REPLACE(userAccount.lastName,'"',""),"'",""),",",""),'-',""),
userAccount.userID

FROM ss_core_02.accessToken accessToken
JOIN rpt_main_02.userAccount ON userAccount.userID = accessToken.userID
WHERE accessToken.type = 2 
GROUP BY userAccount.emailAddress
;

SELECT * FROM rpt_main_02.marketo_combinedAPIDeveloperList;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marketo_combinedAPIDeveloperListV2.csv");