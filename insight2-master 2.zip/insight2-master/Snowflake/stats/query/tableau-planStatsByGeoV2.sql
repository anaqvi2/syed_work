SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-planStatsByGeoV2.sql");

SELECT ppi.mainContactUserID, ppi.domain, ppi.paymentProfileID, ppi.salesforceAccountName, ppi.productName, ppi.userLimit,
ppi.licensedUsers, ppi.ACV, ip.ipCountry, ip.ipRegion, ip.ipCity, IFNULL(ppcc.totalCollaborators,0) AS collaborators,
ppi.paymentStartDate
FROM rpt_main_02.rpt_paidPlanInfo ppi
LEFT JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = ppi.mainContactUserID
LEFT JOIN rpt_main_02.rpt_paidPlanCollabCount ppcc ON ppcc.paymentProfileID = ppi.paymentProfileID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-planStatsByGeoV2.sql");

