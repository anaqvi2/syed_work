SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("OrgConfigSettingsSummaryV2.sql");

drop table if exists rpt_workspace.js_orgConfigSummary;
create table if not exists rpt_workspace.js_orgConfigSummary
select organizationID, configPropertyID, valueString, valueLong, valueDouble, valueBoolean, isFinal as isOverride from ss_account_02.orgConfigSetting;

alter table rpt_workspace.js_orgConfigSummary
add organizationName varchar(50),
add paymentProfileID int,
add productName varchar(50),
add ARR int,
add licensedUsers int,
add configPropertyName varchar(50),
add csRep varchar(50),
add index (organizationID);

update rpt_workspace.js_orgConfigSummary A
join rpt_workspace.js_orgConfigSettingsMapping B
on A.configPropertyID=B.configPropertyID
set A.configPropertyName=B.configPropertyName;

update rpt_workspace.js_orgConfigSummary A
join rpt_main_02.organization B
on A.organizationID=B.organizationID
set A.organizationName=B.name, A.paymentProfileID=B.paymentProfileID;

delete from rpt_workspace.js_orgConfigSummary
where organizationName is null;

update rpt_workspace.js_orgConfigSummary A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.productName=B.productName
where B.accountType=3;

update rpt_workspace.js_orgConfigSummary A
join rpt_main_02.rpt_paidPlanInfo B
on A.paymentProfileID=B.paymentProfileID
set A.ARR=B.ACV, A.licensedUsers=B.licensedUsers;

update rpt_workspace.js_orgConfigSummary
set ARR=0
where productName in ('Team','Enterprise','Business') and ARR is null;

update rpt_workspace.js_orgConfigSummary
set productName='Cancelled'
where paymentProfileID=6098606;

update rpt_workspace.js_orgConfigSummary
set productName='Cancelled'
where productName='Free';

delete from rpt_workspace.js_orgConfigSummary
where configPropertyID=9003;

update rpt_workspace.js_orgConfigSummary
set configPropertyName='SHARING_EMAIL_WHITELIST (Depreciated)'
where configPropertyID=1098;

update rpt_workspace.js_orgConfigSummary
set configPropertyName='REPORT_SEARCH_MONGO (Depreciated)'
where configPropertyID=1080;

update rpt_workspace.js_orgConfigSummary A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
join ss_sfdc_02.domain C
on B.mainContactDomain=C.Domain_Name_URL__c
join ss_sfdc_02.account D
on C.Account__c=D.Id 
join ss_sfdc_02.user E
on D.Customer_Success__c=E.Id
set A.csRep=concat(E.FirstName,' ',E.LastName);

select * from rpt_workspace.js_orgConfigSummary;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("OrgConfigSettingsSummaryV2.sql");

