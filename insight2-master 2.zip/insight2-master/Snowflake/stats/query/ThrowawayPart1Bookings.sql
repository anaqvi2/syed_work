select "******************************************************************************************************************************", NOW();
select "******** Throwaway Part 1: Bookings - start ******** ", NOW();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

SELECT 5 INTO @logLevel;  # DEBUG:5, INFO:4, WARN:3, ERROR:2, FATAL:1, OFF:0:  Determines the granularity of logging this process in the database.
SELECT 0 INTO @processId;  # 0 is the default processId, this will be overwritten with each utl_logStart call.

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("Throwaway Part 1: Bookings");
CALL rpt_main_02.utl_logProcessStart('Throwaway Part 1: Bookings',NULL,'','INFO',@logLevel, @processId);

CALL rpt_main_02.SMARTSHEET_START_LOG ("Max record IDs");


/*Determine max values for tables in PrepV2DataCorePull*/
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_maxRecordIDs
(variableName varchar(100),
maximumValue varchar(100),
primary key (variableName));

TRUNCATE TABLE rpt_main_02.arc_maxRecordIDs;

INSERT INTO rpt_main_02.arc_maxRecordIDs
SELECT "NewMaxaccessTokenID", MAX(accessTokenID) 			FROM ss_core_02.accessToken UNION
SELECT "NewMaxaccessTokenSessionID", MAX(accessTokenSessionID) 	FROM ss_core_02.accessTokenSession UNION
SELECT "NewMaxbrandID", MAX(brandID) 				FROM ss_core_02.brand UNION
SELECT "NewMaxContainerIDInsert", MAX(containerID) 			FROM ss_core_02.container UNION
SELECT "NewMaxContainerIDModify", MAX(containerID) 			FROM ss_core_02.container UNION
SELECT "NewMaxgoogleAppsDomainID", MAX(googleAppsDomainID) 		FROM ss_core_02.googleAppsDomain  UNION
SELECT "NewMaxHPPmodifyDateTime", MAX(modifyDateTime) 			FROM ss_core_02.hist_paymentProfile  UNION
SELECT "NewMaxmailDistributionID", MAX(mailDistributionID) 		FROM ss_core_02.mailDistribution  UNION
SELECT "NewMaxopedIDIdentifierID", MAX(openIDIdentifierID) 		FROM ss_core_02.openIDIdentifier  UNION
SELECT "NewMaxorganizationID", MAX(organizationID) 			FROM ss_core_02.organization  UNION
SELECT "NewMaxorganizationUserRoleID", MAX(organizationUserRoleID) 	FROM ss_core_02.organizationUserRole  UNION
SELECT "NEWmaxPaymentProfileID", MAX(paymentProfileID) 		FROM ss_core_02.paymentProfile 	 UNION
SELECT "NewMaxreminderID", MAX(reminderID) 				FROM ss_core_02.reminder  UNION
SELECT "NewMaxRequestLogID", MAX(requestLogID) 			FROM ss_log_02.requestLog UNION
SELECT "NewMaxsessionLogID", MAX(sessionLogID) 			FROM ss_core_02.sessionLog UNION
SELECT "NewMaxsheetLinkIDInsert", MAX(sheetLinkID) 			FROM ss_core_02.sheetLink UNION
SELECT "NewMaxsheetLinkIDModify", MAX(sheetLinkID) 			FROM ss_core_02.sheetLink UNION
SELECT "NewMaxsignupRequestID", MAX(signupRequestID) 		FROM ss_account_02.signupRequest 	 UNION
SELECT "NewMaxsignupRequestTrackingItemID", MAX(signupRequestTrackingItemID) FROM ss_account_02.signupRequestTrackingItem  UNION
SELECT "NewMaxsiteSettingElementValueID", MAX(siteSettingElementValueID) FROM ss_account_02.siteSettingElementValue  UNION
SELECT "NewMaxTemplateIDInsert", MAX(templateID) 				FROM ss_core_02.template  UNION
SELECT "NewMaxTemplateIDModify", MAX(templateID) 				FROM ss_core_02.template UNION
SELECT "NewMaxuserID", MAX(userID) 					FROM ss_core_02.userAccount  UNION
SELECT "NewMaxworkspaceID", MAX(workspaceID) 			FROM ss_core_02.workspace  UNION
SELECT "NewMaxuserDataID", MAX(salesMarketingUserDataID) FROM ss_core_02.salesMarketingUserData UNION
SELECT "NewMaxorgUserModifyDate", MAX(modifyDateTime) 			FROM ss_core_02.organizationUserRole;

SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenID" INTO @NewMaxaccessTokenID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenSessionID" INTO @NewMaxaccessTokenSessionID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxbrandID" INTO @NewMaxbrandID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDInsert" INTO @NewMaxContainerIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDModify" INTO @NewMaxContainerIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxgoogleAppsDomainID"  INTO @NewMaxgoogleAppsDomainID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxHPPmodifyDateTime"  INTO @NewMaxHPPmodifyDateTime;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxmailDistributionID"  INTO @NewMaxmailDistributionID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxopedIDIdentifierID"  INTO @NewMaxopedIDIdentifierID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationID"  INTO @NewMaxorganizationID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationUserRoleID"  INTO @NewMaxorganizationUserRoleID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NEWmaxPaymentProfileID" 	 INTO @NEWmaxPaymentProfileID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxreminderID"  INTO @NewMaxreminderID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxRequestLogID" INTO @NewMaxRequestLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsessionLogID" INTO @NewMaxsessionLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDInsert" INTO @NewMaxsheetLinkIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDModify" INTO @NewMaxsheetLinkIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestID" 	 INTO @NewMaxsignupRequestID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestTrackingItemID"  INTO @NewMaxsignupRequestTrackingItemID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsiteSettingElementValueID"  INTO @NewMaxsiteSettingElementValueID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDInsert"  INTO @NewMaxTemplateIDInsert;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDModify" INTO @NewMaxTemplateIDModify;
SELECT maximumValue  		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserID"  INTO @NewMaxuserID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxworkspaceID"  INTO @NewMaxworkspaceID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserDataID" INTO @NewMaxuserDataID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorgUserModifyDate" INTO @NewMaxorgUserModifyDate;

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Max record IDs");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** userAccount table - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.userAccount insert");

call rpt_main_02.etl_userAccount(@NewMaxuserID,@processId,@logLevel);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.userAccount insert");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** currencyExchange tables ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.currencyExchange");

DROP TABLE rpt_main_02.currencyExchange;
DROP TABLE rpt_main_02.hist_currencyExchange;

CREATE TABLE IF NOT EXISTS rpt_main_02.currencyExchange LIKE ss_core_02.currencyExchange;
CREATE TABLE IF NOT EXISTS rpt_main_02.hist_currencyExchange LIKE ss_core_02.hist_currencyExchange;

INSERT INTO rpt_main_02.currencyExchange SELECT * FROM ss_core_02.currencyExchange;
INSERT INTO rpt_main_02.hist_currencyExchange SELECT * FROM ss_core_02.hist_currencyExchange;
/*Add USD values set to always be 1*/
INSERT INTO rpt_main_02.hist_currencyExchange VALUES (0, "USD", 1, NOW(), "2000-01-01 00:00:00", 1, "2000-01-01 00:00:00", 1, 0, 0, "9999-12-31 08:00:00");

CREATE UNIQUE INDEX currency ON rpt_main_02.hist_currencyExchange (currencyCode, modifyDateTime);

/* Manually insert June 2016 exchange rates */
UPDATE rpt_main_02.hist_currencyExchange 
SET hist_effectiveThruDateTime = '2016-06-01 00:00:00'
WHERE DATE_FORMAT(modifyDateTime, '%Y-%m') = '2016-05';

INSERT INTO rpt_main_02.hist_currencyExchange  
SELECT * FROM rpt_workspace.pj_june2016CurrencyExchangeRates;

ALTER TABLE rpt_main_02.hist_currencyExchange CONVERT TO CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_520_ci`;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.currencyExchange");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.organization - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.organization");


DROP TABLE IF EXISTS rpt_main_02.organization;
CREATE TABLE IF NOT EXISTS rpt_main_02.organization LIKE ss_core_02.organization;
INSERT rpt_main_02.organization  
SELECT *  
FROM ss_core_02.organization
where organizationID <= @NewMaxorganizationID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.organization");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_paymentProfileContact table - start ******** ", NOW();

/*Start rpt_main_02.rpt_paymentProfileContact*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfileContact insert");


DROP TABLE IF EXISTS rpt_main_02.rpt_paymentProfileContact;

/******* create rpt_paymentProfileContact table - start *******/
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_paymentProfileContact(
paymentProfileID BIGINT, 
userID BIGINT, 
paymentProfileInsertDateTime DATETIME, 
accountType TINYINT, 
hasOrgProfile BOOLEAN,
parentPaymentProfileID BIGINT, /*included parentPaymentProfile in order to use it for update joins in the rpt_paymentProfile*/
PRIMARY KEY(paymentProfileID))
;

CREATE INDEX idx_rpt_paymentProfileContactUserID ON rpt_main_02.rpt_paymentProfileContact (userID);
CREATE INDEX idx_rpt_paymentProfileparentPaymentProfileID ON rpt_main_02.rpt_paymentProfileContact (parentPaymentProfileID);


/* Insert the paymentProfiles associated with users */
INSERT rpt_main_02.rpt_paymentProfileContact 
SELECT paymentProfileID, ownerID, insertDateTime, accountType, FALSE, parentPaymentProfileID
FROM ss_core_02.paymentProfile p 
WHERE p.accountType != 3 and paymentProfileID <= @NEWmaxPaymentProfileID
;

/* Insert the paymentProfiles associated with organizations. */
/* Pulling through insertByUserID from original user to allow calculations of daysToBuy.  */
/* Using GROUP BY and MIN since sometimes there can be multiples profiles inserted by the
   the same person and that causes duplicate key issues, so just take the first one.     */

INSERT rpt_main_02.rpt_paymentProfileContact 
SELECT p.paymentProfileID, 
org.insertByUserID, 
MIN(p2.insertDateTime), 
p.accountType, 
FALSE,
p.parentPaymentProfileID
FROM ss_core_02.paymentProfile p
JOIN ss_core_02.organization org ON org.organizationID = p.ownerID
JOIN ss_core_02.paymentProfile p2 ON p2.ownerID = org.insertByUserID AND p2.accountType != 3
WHERE p.accountType = 3 
	and p.paymentProfileID <= @NEWmaxPaymentProfileID
	and org.organizationID <= @NewMaxorganizationID
	and p2.paymentProfileID <= @NEWmaxPaymentProfileID
GROUP BY 1, 2
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfileContact insert");


/* Update after indexes created  */
/* Update profiles that are dupes of organization profiles (the user has a profile for themselves and one for the organization they created. */
/******* Update brand usage counts on each record *******/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfileContact update");

UPDATE rpt_main_02.rpt_paymentProfileContact rpt_paymentProfileContact 
JOIN rpt_main_02.rpt_paymentProfileContact rpt_paymentProfileContact2 
SET rpt_paymentProfileContact.hasOrgProfile = TRUE
WHERE rpt_paymentProfileContact2.userID = rpt_paymentProfileContact.userID
AND rpt_paymentProfileContact2.accountType = 3 AND rpt_paymentProfileContact.accountType !=3
; 

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfileContact update");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_paymentProfileMaster table - start ******** ", NOW();

/*Start rpt_main_02.rpt_paymentProfileMaster*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfileMaster insert");

DROP TABLE IF EXISTS rpt_main_02.rpt_paymentProfileMaster;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_paymentProfileMaster
	(masterPaymentProfileID BIGINT, 
	paymentProfileID BIGINT, 
	profileCount INT, 
	sheetCount INT, 
	ganttCount INT, 
	hasCustomBrand TINYINT,
	PRIMARY KEY (masterPaymentProfileID,paymentProfileID));
	
CREATE INDEX idx_paymentProfileMasterPaymentProfileID ON rpt_main_02.rpt_paymentProfileMaster (paymentProfileID);


/* Insert all child paymentProfiles */
INSERT IGNORE INTO rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT parentPaymentProfileID, paymentProfileID, 1
FROM ss_core_02.paymentProfile p 
WHERE p.parentPaymentProfileID IS NOT NULL and paymentProfileID <= @NEWmaxPaymentProfileID
;


/* Insert put in the child profiles again so their counts will get rolled up, but don't incease the profileCount*/
INSERT IGNORE INTO rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT paymentProfileID, paymentProfileID, 0
FROM ss_core_02.paymentProfile p 
WHERE p.parentPaymentProfileID IS NOT NULL and paymentProfileID <= @NEWmaxPaymentProfileID
;


/* Insert the parent profiles  */
/* Put in 0 for profile count so they are not counted in the profile count rollup  */
INSERT IGNORE INTO rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT DISTINCT paymentProfileID, paymentProfileID, 0 
FROM ss_core_02.paymentProfile p
WHERE p.parentPaymentProfileID IS NULL and paymentProfileID <= @NEWmaxPaymentProfileID
AND productID IN (6,7,8,10,11); /* 7 team, 8 team plus, 6 enterprise */
;


/* Insert the individual (non-team) profiles as well */
INSERT IGNORE INTO rpt_main_02.rpt_paymentProfileMaster (masterPaymentProfileID, paymentProfileID, profileCount)
SELECT DISTINCT paymentProfileID, paymentProfileID, 1 
FROM ss_core_02.paymentProfile p
WHERE p.parentPaymentProfileID IS NULL and paymentProfileID <= @NEWmaxPaymentProfileID
AND productID NOT IN (6,7,8,10,11); /* 7 team, 8 team plus, 6 enterprise */
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfileMaster insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfileMaster update");

/* Update sheet counts on each record */
UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.sheetCount = 
	(SELECT COUNT(*) FROM rpt_main_02.container c FORCE INDEX (container_idx2)
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= @NewMaxContainerIDModify)
; 

/* 
UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.ganttCount = 
	(SELECT COUNT(*) FROM rpt_main_02.container c 
	JOIN rpt_main_02.grid g ON gridID = c.displayObjectID AND g.ganttState = 1
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= @NewMaxContainerIDModify)
; 


UPDATE rpt_main_02.rpt_paymentProfileMaster ppp 
SET ppp.hasCustomBrand = 
	(SELECT MAX(b.isCustom) FROM rpt_main_02.container c 
	JOIN rpt_main_02.workspace w ON w.workspaceID = c.workspaceID
	JOIN rpt_main_02.brand b ON b.brandID = w.brandID
	WHERE c.paymentProfileID = ppp.paymentProfileID 
	AND c.containerType = 2 
	AND c.deleteStatus = 0 
	AND IFNULL(c.templateStatus,0) = 0 
	AND c.paymentProfileID IS NOT NULL
	AND c.containerID <= @NewMaxContainerIDModify
	AND b.brandID <= @NewMaxbrandID
	AND w.workspaceID <= @NewMaxworkspaceID
)
; */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfileMaster update");


	
SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_paymentProfileSheetCount table - start ******** ", NOW();

/*Start rpt_main_02.rpt_paymentProfileSheetCount*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfileSheetCount");


/* Sum the sheet counts */
DROP TABLE IF EXISTS rpt_main_02.rpt_paymentProfileSheetCount;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_paymentProfileSheetCount
(paymentProfileID BIGINT, sheetCount INT, ganttCount INT, profileCount INT, hasCustomBrand TINYINT, PRIMARY KEY(paymentProfileID))
;

INSERT rpt_main_02.rpt_paymentProfileSheetCount (paymentProfileID, sheetCount, ganttCount, profileCount, hasCustomBrand)
SELECT masterPaymentProfileID, SUM(sheetCount), SUM(ganttCount), SUM(profileCount), MAX(hasCustomBrand)
FROM rpt_main_02.rpt_paymentProfileMaster 
GROUP BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfileSheetCount");




SELECT "******** rpt_main_02.hist_paymentProfile table - start ******** ", NOW();

/*Start rpt_main_02.hist_paymentProfile*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.hist_paymentProfile insert");


/*If reloading hist_paymentProfile, make sure to set the currencyCode = USD for any record where currencyCode is missing*/
/*This will be used to calculate the USD equivalent for all planRates*/
/*Be sure to also scrub rpt_trials if fixes are being made to rpt_main_02.hist_paymentProfile*/

-- TRUNCATE TABLE rpt_main_02.hist_paymentProfile;
-- INSERT rpt_main_02.hist_paymentProfile  
-- SELECT MIN(pp.paymentProfileID),
-- pp.ownerID,pp.accountType,pp.paymentType,pp.paymentFlags,pp.parentPaymentProfileID,pp.paymentStartDateTime,pp.paymentEndDateTime,
-- pp.estimatedLastPaymentDate,pp.actualLastPaymentDate,pp.nextPaymentDate,pp.productID,pp.productPriceID,pp.promoCode,
-- pp.userLimit,pp.bonusSheetCount,pp.bonusUserCount,pp.bonusStorageKb,pp.loyaltyBonusSheetCount,pp.loyaltyBonusStorageKb,pp.loyaltyNextBonusDateTime,
-- pp.loyaltyNextBonusSheetCount,pp.loyaltyNextBonusStorageKb,pp.paymentTerm,pp.currencyCode,pp.planRate,pp.planTaxRate,pp.taxCalculatedRate,
-- pp.taxLastCalcDateTime,pp.primaryContactPhone,pp.referralEmailAddress,pp.reportingSeatCount,pp.billToRecurringBillingID,pp.billToCCNumber,
-- pp.billToCCExpMonth,pp.billToCCExpYear,pp.billToCCName,pp.billToFirstName,pp.billToLastName,pp.billToEmailAddress,pp.billToCompany,
-- pp.billToPO,pp.billToAddress1,pp.billToAddress2,pp.billToCity,pp.billToRegionCode,pp.billToPostCode,pp.billToCountryCode,pp.billToPPPayerID,
-- pp.billToPPAgreementID,pp.insertDateTime,pp.insertByUserID,pp.modifyDateTime,pp.modifyByUserID,pp.sessionLogID,pp.dataTimestamp,pp.hist_effectiveThruDateTime,
-- pp.planRate/hce.exchangeRate
-- FROM ss_core_02.hist_paymentProfile pp
-- LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON pp.currencyCode = hce.currencyCode
--	AND pp.modifyDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
-- GROUP BY pp.ownerID, pp.accountType, pp.modifyDateTime, pp.hist_effectiveThruDateTime;
-- UPDATE rpt_main_02.hist_paymentProfile SET currencyCode = "USD" WHERE currencyCode = "";
-- UPDATE rpt_main_02.hist_paymentProfile SET planRate_USD = planRate WHERE currencyCode = 'USD';
-- UPDATE rpt_main_02.hist_paymentProfile SET planRate_USD = 0 WHERE planRate = 0 AND currencyCode != 'USD';


SELECT max(modifyDateTime) INTO @maxModifyDate FROM rpt_main_02.hist_paymentProfile;


INSERT rpt_main_02.hist_paymentProfile  
SELECT MIN(pp.paymentProfileID),
pp.ownerID,
pp.accountType,
pp.paymentType,
pp.paymentFlags,
pp.parentPaymentProfileID,
pp.paymentStartDateTime,
pp.paymentEndDateTime,
pp.estimatedLastPaymentDate,
pp.actualLastPaymentDate,
pp.nextPaymentDate,
pp.productID,
pp.productPriceID,
pp.promoCode,
pp.userLimit,
pp.bonusSheetCount,
pp.bonusUserCount,
pp.bonusStorageKb,
pp.loyaltyBonusSheetCount,
pp.loyaltyBonusStorageKb,
pp.loyaltyNextBonusDateTime,
pp.loyaltyNextBonusSheetCount,
pp.loyaltyNextBonusStorageKb,
pp.paymentTerm,
pp.currencyCode,
pp.planRate,
pp.planTaxRate,
pp.taxCalculatedRate,
pp.taxLastCalcDateTime,
pp.primaryContactPhone,
pp.referralEmailAddress,
pp.reportingSeatCount,
pp.billToRecurringBillingID,
pp.billToCCNumber,
pp.billToCCExpMonth,
pp.billToCCExpYear,
pp.billToCCName,
pp.billToFirstName,
pp.billToLastName,
pp.billToEmailAddress,
pp.billToCompany,
pp.billToPO,
pp.billToAddress1,
pp.billToAddress2,
pp.billToCity,
pp.billToRegionCode,
pp.billToPostCode,
pp.billToCountryCode,
pp.billToPPPayerID,
pp.billToPPAgreementID,
pp.insertDateTime,
pp.insertByUserID,
pp.modifyDateTime,
pp.modifyByUserID,
pp.sessionLogID,
pp.dataTimestamp,
pp.hist_effectiveThruDateTime,
pp.planRate/hce.exchangeRate
	
FROM ss_core_02.hist_paymentProfile pp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hpp on
	pp.ownerID=hpp.ownerID AND
	pp.accountType=hpp.accountType AND
	pp.modifyDateTime=hpp.modifyDateTime AND
	pp.hist_effectiveThruDateTime=hpp.hist_effectiveThruDateTime
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON pp.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode
	AND pp.modifyDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE pp.modifyDateTime >= @maxModifyDate and pp.modifyDateTime <= @NewMaxHPPmodifyDateTime
AND hpp.ownerID IS NULL
GROUP BY pp.ownerID, pp.accountType, pp.modifyDateTime, pp.hist_effectiveThruDateTime
;


/*Fixing specific known errors in the hist_paymentProfile record that affect revenue reporting*/
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 3760270 AND modifyDateTime = "2014-04-02 23:25:27";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 1368812 AND modifyDateTime = "2014-04-03 19:05:45";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 3714520 AND modifyDateTime = "2014-02-13 20:33:30";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 3458050 AND modifyDateTime = "2013-12-19 16:25:50";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 3538150 AND modifyDateTime = "2013-10-08 18:11:39";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 3538150 AND modifyDateTime = "2013-10-10 16:45:24";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 2548653 AND modifyDateTime = "2013-08-19 14:22:09";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 1274492 AND modifyDateTime = "2012-12-19 23:06:18";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12, paymentType = 2  WHERE paymentProfileID = 4023198 AND modifyDateTime = "2014-05-30 16:48:34";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12, paymentType = 2 WHERE paymentProfileID = 4315485 AND modifyDateTime = "2014-05-30 19:41:53";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12, paymentType = 2 WHERE paymentProfileID = 4337591 AND modifyDateTime = "2014-05-21 22:38:46";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 12 WHERE paymentProfileID = 4304888 AND modifyDateTime = "2014-05-30 16:56:47";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 0, planRate = 0, planRate_USD = 0, paymentType = 5  WHERE paymentProfileID = 3986365 AND modifyDateTime = "2014-05-30 16:49:04";
UPDATE rpt_main_02.hist_paymentProfile SET paymentTerm = 0, planRate = 0, planRate_USD = 0, paymentType = 0, productID = 0, userLimit = 1
WHERE paymentProfileID = 4296627 AND modifyDateTime = "2014-05-15 22:52:10";
UPDATE rpt_main_02.hist_paymentProfile SET planRate =  29735, planRate_USD = 29735 WHERE paymentProfileID = 1278937 AND modifyDateTime = "2014-05-02 20:24:25";
UPDATE rpt_main_02.hist_paymentProfile SET planRate = 10492, planRate_USD = 10492  WHERE paymentProfileID = 2869082 AND modifyDateTime = "2014-06-17 15:37:06";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2014-07-31 14:00:00" WHERE paymentProfileID = 4665379 AND modifyDateTime = "2014-07-31 20:36:36";
UPDATE rpt_main_02.hist_paymentProfile SET planRate = 2949, userLimit = 85 WHERE paymentProfileID = 1689270 AND modifyDateTime = "2014-12-13 00:55:04";
UPDATE rpt_main_02.hist_paymentProfile SET planRate = 10000, userLimit = 500 WHERE paymentProfileID = 1898997 AND modifyDateTime = "2014-12-13 00:55:04";
UPDATE rpt_main_02.hist_paymentProfile SET planRate = 32427, userLimit = 442 WHERE paymentProfileID = 2464779 AND modifyDateTime = "2014-12-13 00:55:04";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-01-06 21:54:00" WHERE paymentProfileID = 5345500 AND modifyDateTime = "2015-01-06 21:55:17";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-01-06 22:23:00" WHERE paymentProfileID = 5345623 AND modifyDateTime = "2015-01-06 22:18:03";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-01-06 22:23:00" WHERE paymentProfileID = 5345815 AND modifyDateTime = "2015-01-06 23:03:20";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-01-06 22:23:00" WHERE paymentProfileID = 5345968 AND modifyDateTime IN ("2015-01-06 23:44:44","2015-01-14 18:11:45");
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-01-07 21:27:00" WHERE paymentProfileID = 5350758 AND modifyDateTime = "2015-01-07 21:30:50";
UPDATE rpt_main_02.hist_paymentProfile SET planRate = 792, planTaxRate = 0 WHERE paymentProfileID = 5285658 AND modifyDateTime = "2015-01-09 22:50:15";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-07-31 23:38:34" WHERE paymentProfileID = 6022912 AND modifyDateTime BETWEEN "2015-07-31 23:38:34" AND "2015-09-02 15:21:46";
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-08-11 17:07:00" WHERE paymentProfileID = 6132207 AND modifyDateTime  IN ("2015-08-11 17:07:00","2015-08-11 20:23:56");
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-08-31 19:53:42" WHERE paymentProfileID = 5652255 AND modifyDateTime BETWEEN "2015-08-31 19:53:42" AND "2015-09-01 19:29:32";

/* Fixes related to incorrect payment start date changes made between 9/18 and 9/30 */

UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-03-17 13:23:11" WHERE paymentProfileID = 5672442 AND modifyDateTime = '2015-09-30 21:16:16';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2011-01-31 17:30:52" WHERE paymentProfileID = 1561747 AND modifyDateTime = '2015-09-30 23:18:22';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2014-02-17 17:16:00" WHERE paymentProfileID = 4003756 AND modifyDateTime = '2015-09-21 16:42:29';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2014-08-18 15:21:00" WHERE paymentProfileID = 4731588 AND modifyDateTime = '2015-09-22 21:21:14';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2014-10-13 20:03:41" WHERE paymentProfileID = 4998595 AND modifyDateTime = '2015-09-29 23:40:29';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2014-12-01 17:30:00" WHERE paymentProfileID = 5226235 AND modifyDateTime = '2015-09-30 22:20:33';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-05-07 22:00:10" WHERE paymentProfileID = 5902877 AND modifyDateTime IN('2015-09-22 17:16:04','2015-10-01 15:43:54','2015-10-01 15:50:58');
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-07-06 14:21:54" WHERE paymentProfileID = 6132107 AND modifyDateTime BETWEEN '2015-09-30 23:13:05' AND '2015-10-01 22:37:50';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-07-14 16:55:27" WHERE paymentProfileID = 6163313 AND modifyDateTime BETWEEN '2015-09-21 21:29:53' AND '2015-10-01 20:34:42';

UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-11-30 23:50:00" WHERE paymentProfileID = 6745056 AND modifyDateTime = '2015-12-01 19:01:59';
UPDATE rpt_main_02.hist_paymentProfile SET paymentStartDateTime = "2015-11-30 23:50:00" WHERE paymentProfileID = 6745056 AND modifyDateTime = '2015-12-01 19:04:34';

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.hist_paymentProfile insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.hist_paymentProfile update");

/*Set planRate_USD to planRate for all USD based transactions*/
UPDATE rpt_main_02.hist_paymentProfile SET planRate_USD = planRate WHERE currencyCode = 'USD';
UPDATE rpt_main_02.hist_paymentProfile SET planRate_USD = 0 WHERE planRate = 0 AND currencyCode != 'USD';

-- Create staging table to identify previously exisiting records that need to be updated
DROP TABLE IF EXISTS rpt_main_02.stg_histpaymentProfile_update;

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_histpaymentProfile_update 
(
	paymentProfileID bigint,
	modifyDateTime datetime,
	hist_effectiveThruDateTime datetime
)
;

INSERT INTO rpt_main_02.stg_histpaymentProfile_update
SELECT paymentProfileID, modifyDateTime, hist_effectiveThruDateTime
FROM ss_core_02.hist_paymentProfile
WHERE modifyDateTime >= @maxModifyDate and hist_paymentProfile.modifyDateTime <= @NewMaxHPPmodifyDateTime
;

CREATE INDEX ix_ppID ON rpt_main_02.stg_histpaymentProfile_update (paymentProfileID);
CREATE INDEX ix_modifyDateTime ON rpt_main_02.stg_histpaymentProfile_update (modifyDateTime);


-- Update hist_effectiveThruDateTime of previous paymentProfileIDs
UPDATE rpt_main_02.hist_paymentProfile hpp FORCE INDEX(hist_paymentProfile_idxPK)
JOIN ss_core_02.hist_paymentProfile coreHPP FORCE INDEX(hist_paymentProfile_idxPK) ON hpp.paymentProfileID = coreHPP.paymentProfileID
	AND hpp.modifyDateTime = coreHPP.modifyDateTime
JOIN rpt_main_02.stg_histpaymentProfile_update stg ON coreHPP.paymentProfileID = stg.paymentProfileID 
	AND stg.modifyDateTime = coreHPP.hist_effectiveThruDateTime
SET hpp.hist_effectiveThruDateTime = coreHPP.hist_effectiveThruDateTime
WHERE hpp.modifyDateTime != hpp.hist_effectiveThruDateTime AND hpp.modifyDateTime < @maxModifyDate
;


/*Eliminating Promo-period for Proof of Concept promo accounts*/
UPDATE rpt_main_02.hist_paymentProfile 
JOIN rpt_main_02.arc_hist_paymentProfileAdjustments ON hist_paymentProfile.paymentProfileID = arc_hist_paymentProfileAdjustments.paymentProfileID
SET hist_paymentProfile.hist_effectiveThruDateTime = arc_hist_paymentProfileAdjustments.hist_effectiveThruDateTime
WHERE hist_paymentProfile.hist_effectiveThruDateTime = DATE_ADD(arc_hist_paymentProfileAdjustments.modifyDateTime, INTERVAL -1 SECOND) ;

DELETE FROM rpt_main_02.hist_paymentProfile WHERE paymentProfileID IN (SELECT paymentProfileID FROM rpt_main_02.arc_hist_paymentProfileAdjustments) 
AND modifyDateTime IN (SELECT modifyDateTime FROM rpt_main_02.arc_hist_paymentProfileAdjustments);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.hist_paymentProfile update");

	
SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_paymentProfile table - start ******** ", NOW();

/*Start rpt_main_02.rpt_paymentProfile*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfile insert");

DROP TABLE rpt_main_02.stg_organizationPaidUser;
CREATE TABLE rpt_main_02.stg_organizationPaidUser(
paymentProfileID BIGINT,
organizationID BIGINT,
seatCount INT,
PRIMARY KEY(paymentProfileID)
);

INSERT rpt_main_02.stg_organizationPaidUser
SELECT organization.paymentProfileID, organization.organizationID, COUNT(ss_core_02.organizationUserRole.organizationUserRoleID) AS seatCount
FROM ss_core_02.organization
JOIN ss_core_02.organizationUserRole ON ss_core_02.organization.organizationID = ss_core_02.organizationUserRole.organizationID
WHERE role = "LICENSE_USER"
GROUP BY 1, 2
;

SELECT DATE_SUB(MAX(modifyDateTime), INTERVAL 3 DAY) FROM rpt_main_02.rpt_paymentProfile INTO @maxppModify;
SELECT MAX(paymentProfileID) FROM rpt_main_02.rpt_paymentProfile INTO @maxppID;

DROP TABLE IF EXISTS rpt_workspace.cDunn_stg_ppUpdates;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_stg_ppUpdates LIKE rpt_main_02.rpt_paymentProfile;

INSERT rpt_workspace.cDunn_stg_ppUpdates(
	paymentProfileID,
	ownerID, 
	sourceUserID,
	hasOrgProfile,
	companyName,
	accountType,
	accountTypeFriendly,
	paymentType,
	paymentTypeFriendly,
	paymentFlags,
	parentPaymentProfileID,
	
	paymentInsertDate,
	paymentInsertMonth,
	paymentInsertWeek,
	paymentInsertDay,
	
	paymentStartDateRaw,
	paymentStartDateClean,
	paymentEndDateTime,
	paymentStartMonth, 
	paymentStartWeek, 
	paymentStartDay,
	
	productID,
	productName,
	userLimit,
	productPriceID,
	promoCode,
	bonusSheetCount,
	bonusUserCount,
	paymentTerm,
	paymentTermFriendly,
	paymentTotal,
	planRate_USD,
	currencyCode,
	
	primaryContactPhone,
	referralEmailAddress,
	reportingSeatCount,
	billToRecurringBillingID,
	billToCountryFriendly,
	
	cancelPaymentDate, 
	actualLastPaymentDate,
	nextPaymentDate,
	modifyDateTime,
	seatCount,
	countAsPaid,
	recurringMonthlyRevenue,
	annualRevenue,
	daysToBuy,
	sheetCount,
	activeProfileCount,
	hasPaid) 

SELECT 	pp.paymentProfileID, 
	pp.ownerID,	
	ppc.userID,
	ppc.hasOrgProfile,
	/* default companyName to the non-profit name if we have one - overwritten with org name later if it is an org*/
	pp.billToCompany, 
	pp.accountType,
	rpt_main_02.SMARTSHEET_ACCOUNTTYPE(pp.accountType) AS AccountTypeFriendly,
	pp.paymentType AS PaymentType,
	rpt_main_02.SMARTSHEET_PAYMENTTYPE(pp.paymentType) AS PaymentTypeFriendly,
	pp.paymentFlags,
	pp.parentPaymentProfileID,
	
	/*paymentInsertDate*/
	ppc.paymentProfileInsertDateTime,
	DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'),
	
	rpt_main_02.SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), 

	DAYOFYEAR(ppc.paymentProfileInsertDateTime),

	/*paymentStartDateRaw*/
	pp.paymentStartDateTime,
	/*paymentStartDateClean*/
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', pp.paymentStartDateTime) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', ppc.paymentProfileInsertDateTime, '2008-09-29')
	END,
	pp.paymentEndDateTime,
	
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008*09(Sep)', DATE_FORMAT(pp.paymentStartDateTime, '%Y*%m(%b)')) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'), '2008*09(Sep)')
	END,
	
	/*paymentStartWeek*/
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', rpt_main_02.SMARTSHEET_WEEK('2008-09-30 00:00:00'), 
			 rpt_main_02.SMARTSHEET_WEEK(pp.paymentStartDateTime))
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', rpt_main_02.SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), rpt_main_02.SMARTSHEET_WEEK('2008-09-30 00:00:00'))
	END,

	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', DAYOFYEAR('2008-09-30'), DAYOFYEAR(pp.paymentStartDateTime)) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DAYOFYEAR(ppc.paymentProfileInsertDateTime), DAYOFYEAR('2008-09-30'))
	END,
	
	/*productID*/
	pp.productID,
	rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) AS ProductName,
	pp.userLimit,
	pp.productPriceID,
	pp.promoCode,
	pp.bonusSheetCount,
	IFNULL(pp.bonusUserCount,0),
	pp.paymentTerm,
	rpt_main_02.SMARTSHEET_PAYMENTTERM(pp.paymentTerm) AS paymentTermFriendly,
	pp.planRate,
	pp.planRate/hce.exchangeRate,
	pp.currencyCode,
	
	/*primaryContactPhone*/
	pp.primaryContactPhone,
	pp.referralEmailAddress,
	pp.reportingSeatCount,
	pp.billToRecurringBillingID,
	rpt_main_02.SMARTSHEET_COUNTRYNAME(pp.billToCountryCode),
	
	CASE pp.productID
		WHEN 0 THEN pp.paymentStartDateTime
		ELSE NULL END AS cancelPaymentDate,
	pp.actualLastPaymentDate,
	pp.nextPaymentDate,
	pp.modifyDateTime,
/*Seat Count*/
	CASE pp.accountType
		WHEN 3 THEN	/* organization */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise accountType */  
				ELSE stg_organizationPaidUser.seatCount
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IF (pp.planRate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IF (pp.planRate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IF (pp.planRate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IF (pp.planRate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IF (pp.planRate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END,

	CASE (pp.PromoCode = 'HAYEMPL' OR pp.PromoCode = 'EXECMBA09' OR pp.PromoCode = 'TESTPAY')
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE CASE pp.productID
			WHEN 0 THEN  0 /* "Cancelled" */
			WHEN 1 THEN  0 /* "Trial" */
			WHEN 2 THEN  0 /* "Free" */
			ELSE
				CASE pp.paymentType
					WHEN 0 THEN 0	/* none */
					WHEN 1 THEN     /* cc */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 2 THEN 	/* bill to */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
						IF (pp.planRate > 0, 1, 0)
					WHEN 4 THEN 0	/* promo */
					WHEN 5 THEN 0	/* paid by other */						
					WHEN 6 THEN 	/* THIRD_PARTY */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 7 THEN 0	/* THIRD_PARTY_BY_OTHER */		
					WHEN 8 THEN 	/* PAYPAL */
						IF (pp.planRate > 0, 1, 0)
					WHEN 10 THEN /* Bill to In-App */
						IF (pp.planRate > 0 , 1, 0) 
					ELSE 0 END
					
				END
	END,

	CASE pp.paymentTerm
		WHEN 1 THEN (pp.planRate/hce.exchangeRate) / pp.paymentTerm
		ELSE "0" END,
		
	CASE pp.paymentTerm
		WHEN 12 THEN (pp.planRate/hce.exchangeRate)
		ELSE "0" END,
		
	CASE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) END,
		
	ppsc.sheetCount,
	ppsc.profileCount,
	0/* default hasPaid to 0 and we will update later based on history */
	
FROM ss_core_02.paymentProfile pp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.paymentProfileID = pp.paymentProfileID 
	AND hpp.productID > 2 AND hpp.modifyDateTime <= @NewMaxHPPmodifyDateTime 
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON pp.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode
	AND pp.modifyDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
JOIN rpt_main_02.rpt_paymentProfileSheetCount ppsc ON ppsc.paymentProfileID = pp.paymentProfileID
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.stg_organizationPaidUser ON stg_organizationPaidUser.paymentProfileID = pp.paymentProfileID

WHERE pp.paymentProfileID <= @maxppID AND pp.modifyDateTime >= @maxppModify

GROUP BY 1
;

UPDATE rpt_main_02.rpt_paymentProfile A
JOIN rpt_workspace.cDunn_stg_ppUpdates B ON A.paymentProfileID = B.paymentProfileID
SET A.ownerID = B.ownerID,
	A.sourceUserID = B.sourceUserID,
	A.hasOrgProfile = B.hasOrgProfile,
	A.companyName = B.companyName,
	A.accountType = B.accountType,
	A.accountTypeFriendly = B.accountTypeFriendly,
	A.paymentType = B.paymentType,
	A.paymentTypeFriendly = B.paymentTypeFriendly,
	A.paymentFlags = B.paymentFlags,
	A.parentPaymentProfileID = B.parentPaymentProfileID,
	A.paymentInsertDate = B.paymentInsertDate,
	A.paymentInsertMonth = B.paymentInsertMonth,
	A.paymentInsertWeek = B.paymentInsertWeek,
	A.paymentInsertDay = B.paymentInsertDay,
	A.paymentStartDateRaw = B.paymentStartDateRaw,
	A.paymentStartDateClean = B.paymentStartDateClean,
	A.paymentEndDateTime = B.paymentEndDateTime,
	A.paymentStartMonth = B.paymentStartMonth,
	A.paymentStartWeek = B.paymentStartWeek,
	A.paymentStartDay = B.paymentStartDay,
	A.productID = B.productID,
	A.productName = B.productName,
	A.userLimit = B.userLimit,
	A.productPriceID = B.productPriceID,
	A.promoCode = B.promoCode,
	A.bonusSheetCount = B.bonusSheetCount,
	A.bonusUserCount = B.bonusUserCount,
	A.paymentTerm = B.paymentTerm,
	A.paymentTermFriendly = B.paymentTermFriendly,
	A.paymentTotal = B.paymentTotal,
	A.planRate_USD = B.planRate_USD,
	A.currencyCode = B.currencyCode,
	A.primaryContactPhone = B.primaryContactPhone,
	A.referralEmailAddress = B.referralEmailAddress,
	A.reportingSeatCount = B.reportingSeatCount,
	A.billToRecurringBillingID = B.billToRecurringBillingID,
	A.billToCountryFriendly = B.billToCountryFriendly,
	A.cancelPaymentDate = B.cancelPaymentDate,
	A.actualLastPaymentDate = B.actualLastPaymentDate,
	A.nextPaymentDate = B.nextPaymentDate,
	A.modifyDateTime = B.modifyDateTime,
	A.seatCount = B.seatCount,
	A.countAsPaid = B.countAsPaid,
	A.recurringMonthlyRevenue = B.recurringMonthlyRevenue,
	A.annualRevenue = B.annualRevenue,
	A.daysToBuy = B.daysToBuy,
	A.sheetCount = B.sheetCount,
	A.activeProfileCount = B.activeProfileCount,
	A.hasPaid = B.hasPaid;
	
INSERT IGNORE INTO rpt_main_02.rpt_paymentProfile(
	paymentProfileID,
	ownerID, 
	sourceUserID,
	hasOrgProfile,
	companyName,
	accountType,
	accountTypeFriendly,
	paymentType,
	paymentTypeFriendly,
	paymentFlags,
	parentPaymentProfileID,
	
	paymentInsertDate,
	paymentInsertMonth,
	paymentInsertWeek,
	paymentInsertDay,
	
	paymentStartDateRaw,
	paymentStartDateClean,
	paymentEndDateTime,
	paymentStartMonth, 
	paymentStartWeek, 
	paymentStartDay,
	
	productID,
	productName,
	userLimit,
	productPriceID,
	promoCode,
	bonusSheetCount,
	bonusUserCount,
	paymentTerm,
	paymentTermFriendly,
	paymentTotal,
	planRate_USD,
	currencyCode,
	
	primaryContactPhone,
	referralEmailAddress,
	reportingSeatCount,
	billToRecurringBillingID,
	billToCountryFriendly,
	
	cancelPaymentDate, 
	actualLastPaymentDate,
	nextPaymentDate,
	modifyDateTime,
	seatCount,
	countAsPaid,
	recurringMonthlyRevenue,
	annualRevenue,
	daysToBuy,
	sheetCount,
	activeProfileCount,
	hasPaid) 

SELECT 	pp.paymentProfileID, 
	pp.ownerID,	
	ppc.userID,
	ppc.hasOrgProfile,
	/* default companyName to the non-profit name if we have one - overwritten with org name later if it is an org*/
	pp.billToCompany, 
	pp.accountType,
	rpt_main_02.SMARTSHEET_ACCOUNTTYPE(pp.accountType) AS AccountTypeFriendly,
	pp.paymentType AS PaymentType,
	rpt_main_02.SMARTSHEET_PAYMENTTYPE(pp.paymentType) AS PaymentTypeFriendly,
	pp.paymentFlags,
	pp.parentPaymentProfileID,
	
	/*paymentInsertDate*/
	ppc.paymentProfileInsertDateTime,
	DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'),
	
	rpt_main_02.SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), 

	DAYOFYEAR(ppc.paymentProfileInsertDateTime),

	/*paymentStartDateRaw*/
	pp.paymentStartDateTime,
	/*paymentStartDateClean*/
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', pp.paymentStartDateTime) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', ppc.paymentProfileInsertDateTime, '2008-09-29')
	END,
	pp.paymentEndDateTime,
	
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', '2008*09(Sep)', DATE_FORMAT(pp.paymentStartDateTime, '%Y*%m(%b)')) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DATE_FORMAT(ppc.paymentProfileInsertDateTime, '%Y*%m(%b)'), '2008*09(Sep)')
	END,
	
	/*paymentStartWeek*/
	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', rpt_main_02.SMARTSHEET_WEEK('2008-09-30 00:00:00'), 
			 rpt_main_02.SMARTSHEET_WEEK(pp.paymentStartDateTime))
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', rpt_main_02.SMARTSHEET_WEEK(ppc.paymentProfileInsertDateTime), rpt_main_02.SMARTSHEET_WEEK('2008-09-30 00:00:00'))
	END,

	CASE pp.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (pp.promoCode = 'BETALOCKIN' AND ppc.paymentProfileInsertDateTime < '2008-10-01', DAYOFYEAR('2008-09-30'), DAYOFYEAR(pp.paymentStartDateTime)) 
		ELSE IF (ppc.paymentProfileInsertDateTime > '2008-09-30', DAYOFYEAR(ppc.paymentProfileInsertDateTime), DAYOFYEAR('2008-09-30'))
	END,
	
	/*productID*/
	pp.productID,
	rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) AS ProductName,
	pp.userLimit,
	pp.productPriceID,
	pp.promoCode,
	pp.bonusSheetCount,
	IFNULL(pp.bonusUserCount,0),
	pp.paymentTerm,
	rpt_main_02.SMARTSHEET_PAYMENTTERM(pp.paymentTerm) AS paymentTermFriendly,
	pp.planRate,
	pp.planRate/hce.exchangeRate,
	pp.currencyCode,
	
	/*primaryContactPhone*/
	pp.primaryContactPhone,
	pp.referralEmailAddress,
	pp.reportingSeatCount,
	pp.billToRecurringBillingID,
	rpt_main_02.SMARTSHEET_COUNTRYNAME(pp.billToCountryCode),
	
	CASE pp.productID
		WHEN 0 THEN pp.paymentStartDateTime
		ELSE NULL END AS cancelPaymentDate,
	pp.actualLastPaymentDate,
	pp.nextPaymentDate,
	pp.modifyDateTime,
/*Seat Count*/
	CASE pp.accountType
		WHEN 3 THEN	/* organization */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise accountType */  
				ELSE stg_organizationPaidUser.seatCount
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IF (pp.planRate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IF (pp.planRate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IF (pp.planRate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IF (pp.planRate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IF (pp.planRate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END,

	CASE (pp.PromoCode = 'HAYEMPL' OR pp.PromoCode = 'EXECMBA09' OR pp.PromoCode = 'TESTPAY')
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE CASE pp.productID
			WHEN 0 THEN  0 /* "Cancelled" */
			WHEN 1 THEN  0 /* "Trial" */
			WHEN 2 THEN  0 /* "Free" */
			ELSE
				CASE pp.paymentType
					WHEN 0 THEN 0	/* none */
					WHEN 1 THEN     /* cc */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 2 THEN 	/* bill to */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
						IF (pp.planRate > 0, 1, 0)
					WHEN 4 THEN 0	/* promo */
					WHEN 5 THEN 0	/* paid by other */						
					WHEN 6 THEN 	/* THIRD_PARTY */
						IF (pp.planRate > 0, 1, 0)		
					WHEN 7 THEN 0	/* THIRD_PARTY_BY_OTHER */		
					WHEN 8 THEN 	/* PAYPAL */
						IF (pp.planRate > 0, 1, 0)
					WHEN 10 THEN /* Bill to In-App */
						IF (pp.planRate > 0 , 1, 0) 
					ELSE 0 END
					
				END
	END,

	CASE pp.paymentTerm
		WHEN 1 THEN (pp.planRate/hce.exchangeRate) / pp.paymentTerm
		ELSE "0" END,
		
	CASE pp.paymentTerm
		WHEN 12 THEN (pp.planRate/hce.exchangeRate)
		ELSE "0" END,
		
	CASE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(MIN(hpp.paymentStartDateTime), ppc.paymentProfileInsertDateTime) END,
		
	ppsc.sheetCount,
	ppsc.profileCount,
	0/* default hasPaid to 0 and we will update later based on history */
	
FROM ss_core_02.paymentProfile pp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.paymentProfileID = pp.paymentProfileID 
	AND hpp.productID > 2 AND hpp.modifyDateTime <= @NewMaxHPPmodifyDateTime 
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON pp.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode
	AND pp.modifyDateTime BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
JOIN rpt_main_02.rpt_paymentProfileSheetCount ppsc ON ppsc.paymentProfileID = pp.paymentProfileID
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.stg_organizationPaidUser ON stg_organizationPaidUser.paymentProfileID = pp.paymentProfileID

WHERE pp.paymentProfileID > @maxppID AND pp.paymentProfileID <= @NEWmaxPaymentProfileID

GROUP BY 1
;

UPDATE rpt_main_02.rpt_paymentProfile pp
JOIN rpt_main_02.rpt_paymentProfileSheetCount ppsc ON ppsc.paymentProfileID = pp.paymentProfileID
SET pp.activeProfileCount = ppsc.profileCount;


UPDATE rpt_main_02.rpt_paymentProfile rpp
JOIN ss_core_02.paymentProfile pp ON pp.paymentProfileID = rpp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.stg_organizationPaidUser ON stg_organizationPaidUser.paymentProfileID = pp.paymentProfileID
SET rpp.seatCount =
	CASE pp.accountType
		WHEN 3 THEN	/* organization */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 0 	/* add account  - don't count when part of enterprise accountType */  
				ELSE stg_organizationPaidUser.seatCount
			END	
		WHEN 2 THEN	0 /* multi-user */	
		WHEN 1 THEN	/* regular */
			CASE pp.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN IF (pp.planRate > 0 , 1, 0)   /* cc */
				WHEN 2 THEN IF (pp.planRate > 0 , 1, 0)	/* bill to */
				WHEN 3 THEN 0	/* custom */
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN IF (pp.planRate > 0 , 1, 0)	/* add account */
				WHEN 6 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY */
				WHEN 7 THEN IF (pp.planRate > 0 , 1, 0)	/* THIRD_PARTY_BY_OTHER */
				WHEN 8 THEN IF (pp.planRate > 0 , 1, 0)	/* PAYPAL */
				WHEN 10 THEN IF (pp.planRate > 0 , 1, 0) /* Bill to In-App */
				ELSE 0 END
			END;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfile insert");

-- UPDATE rpt_paymentProfile 
-- SET rpt_paymentProfile.seatCount = (SELECT COUNT(ss_core_02.organizationUserRole.organizationUserRoleID) 
-- 					FROM ss_core_02.organizationUserRole JOIN ss_core_02.organization ON ss_core_02.organization.organizationID = ss_core_02.organizationUserRole.organizationID
-- 					WHERE organization.paymentProfileID = rpt_paymentProfile.paymentProfileID AND role = "LICENSE_USER")
-- WHERE rpt_paymentProfile.accountType = 3 AND rpt_paymentProfile.paymentType NOT IN (0,4,5)
-- ;

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_paymentProfile update");

/*Set planRate_USD to paymentTotal for all USD transactions*/
/* UPDATE rpt_main_02.rpt_paymentProfile SET planRate_USD = paymentTotal WHERE currencyCode = 'USD';

UPDATE rpt_main_02.rpt_paymentProfile SET planRate_USD = 0 WHERE paymentTotal = 0 AND currencyCode != 'USD';
UPDATE rpt_main_02.rpt_paymentProfile SET AnnualRevenue = 0 WHERE paymentTotal = 0 AND paymentTerm = 12 AND currencyCode != 'USD'; */

/* Set main contact based on account type - pull userID from sourceUserID for standard acccounts and from org main contact for orgs */
UPDATE rpt_main_02.rpt_paymentProfile SET mainContactUserID = sourceUserID WHERE accountType != 3;

/* Also overwrite the company name with the OrgName for Organizations */
UPDATE rpt_main_02.rpt_paymentProfile rp
  -- JOIN ss_core_02.paymentProfile pp ON rp.paymentProfileID = pp.paymentProfileID and pp.paymentProfileID <= @NEWmaxPaymentProfileID
  JOIN rpt_main_02.organization o ON rp.ownerID = o.organizationID and o.organizationID <= @NewMaxorganizationID
SET rp.mainContactUserID = o.mainContactUserID,
     rp.companyName = o.name
WHERE rp.accountType = 3 
;

UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.userAccount u ON rp.mainContactUserID = u.userID AND u.userID <= @NewMaxuserID
SET  rp.mainContactEmailAddress = u.emailAddress,
     rp.mainContactDomain = u.domain
;

DROP TABLE IF EXISTS rpt_main_02.stg_minMaxPaid;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_minMaxPaid
(paymentProfileID BIGINT,
firstPaymentDate DATETIME,
maxPaidDate DATETIME,
lastPaidProductID INT,
PRIMARY KEY (paymentProfileID),
KEY maxPaidDate (maxPaidDate));

INSERT INTO rpt_main_02.stg_minMaxPaid (paymentProfileID, firstPaymentDate, maxPaidDate)
SELECT paymentProfileID, MIN(paymentStartDateTime), MAX(modifyDateTime)
FROM rpt_main_02.hist_paymentProfile
WHERE productID > 2 AND paymentType IN(1,2,3,6,8,10) AND planRate > 0
GROUP BY 1;

UPDATE rpt_main_02.stg_minMaxPaid A
JOIN rpt_main_02.hist_paymentProfile hpp FORCE INDEX (hist_paymentProfile_idxPK) ON hpp.paymentProfileID = A.paymentProfileID AND hpp.modifyDateTime = A.maxPaidDate
SET lastPaidProductID = hpp.productID;

/* Set Has paid flag */

UPDATE rpt_main_02.rpt_paymentProfile pp
JOIN rpt_main_02.stg_minMaxPaid B ON pp.paymentProfileID = B.paymentProfileID
SET hasPaid = 1;

/* Set first payment max payment and last paid product ID */
UPDATE rpt_main_02.rpt_paymentProfile pp
JOIN rpt_main_02.stg_minMaxPaid B ON pp.paymentProfileID = B.paymentProfileID
SET pp.firstPaymentDate = B.firstPaymentDate,
	pp.maxPaidDate = B.maxPaidDate,
	pp.lastPaidProductID = B.lastPaidProductID;

/* UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.hist_paymentProfile hp ON rp.paymentProfileID = hp.paymentProfileID AND hp.modifyDateTime <= @NewMaxHPPmodifyDateTime
SET rp.hasPaid = 1
WHERE hp.productID > 2 AND hp.paymentType IN (1,2,3,6,8,10) AND hp.planRate > 0
; */

/* Get the first hist_paymentProfile date where the user was paid */

/* UPDATE rpt_main_02.rpt_paymentProfile rp
SET rp.firstPaymentDate = (SELECT MIN(hp.paymentStartDateTime) 
FROM rpt_main_02.hist_paymentProfile hp 
WHERE rp.paymentProfileID = hp.paymentProfileID 
AND hp.productID >= 3 
AND hp.paymentType IN (1,2,3,6,8,10)
AND hp.modifyDateTime <= @NewMaxHPPmodifyDateTime)
; */


/* Get the last hist_paymentProfile record that is paid */
/* 
UPDATE rpt_main_02.rpt_paymentProfile rp
SET rp.maxPaidDate = (SELECT MAX(hp.modifyDateTime) 
FROM rpt_main_02.hist_paymentProfile hp 
WHERE rp.paymentProfileID = hp.paymentProfileID 
AND hp.productID >= 3 
AND hp.paymentType IN (1,2,3,6,8,10)
AND hp.modifyDateTime <= @NewMaxHPPmodifyDateTime)
; */

/* Get the productID of the last paid product - we want to know what product they were on when they cancelled */
/* UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.hist_paymentProfile hp ON rp.paymentProfileID = hp.paymentProfileID 
  	AND rp.maxPaidDate = hp.modifyDateTime 
  	AND hp.modifyDateTime <= @NewMaxHPPmodifyDateTime
SET rp.lastPaidProductID = hp.productID
WHERE rp.maxPaidDate IS NOT NULL 
; */

/* For the current edge case of  */
/* UPDATE rpt_main_02.rpt_paymentProfile rp
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON rp.currencyCode = hce.currencyCode
	AND rp.maxPaidDate BETWEEN hce.insertDateTime AND hce.hist_effectiveThruDateTime
SET planRate_USD =	rp.paymentTotal/hce.exchangeRate
WHERE planRate_USD IS NULL; */


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_paymentProfile update");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_requestLog table ******** ", NOW();


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_requestLog");

CALL rpt_main_02.etl_requestLog(@processId,@logLevel);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_requestLog");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_sessionLog");

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_sessionLog LIKE ss_core_02.sessionLog;

SELECT MAX(sessionLogID) FROM rpt_main_02.arc_sessionLog  INTO @maxSessionLogID;

INSERT rpt_main_02.arc_sessionLog 
SELECT sessionLogID, emailAddress, loginType, loginStatus, loginAuthResult, userID, sourceIP, browser, 
VERSION, platform, userAgent, screenWidth, screenHeight, insertDateTime, signOutDateTime
FROM ss_core_02.sessionLog 
WHERE sessionLogID > @maxSessionLogID AND sessionLogID <= @NewMaxsessionLogID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_sessionLog");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_signupRequestTrackingItem ******** ", NOW();

/*Start rpt_main_02.rpt_signupRequestTrackingItem*/


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem data pull");


/* When the logic changes and we want to reprocess everything, drop the table with the line below. */
/* DROP TABLE IF EXISTS rpt_main_02.rpt_signupRequestTrackingItem; */

CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID BIGINT, 
	signupRequestID BIGINT, 
	itemType TINYINT, 
	itemName NVARCHAR(100), 
	itemValue NVARCHAR(500), 
	extraInfo NVARCHAR(50), 
	INDEX(signupRequestTrackingItemID),
	INDEX(signupRequestID));

/* find out where we left off */
/******* SELECT MAX(logDate) INTO @startDate  - start *******/
SELECT MAX(signupRequestTrackingItemID) INTO @signupRequestTrackingItemID 		
FROM rpt_main_02.rpt_signupRequestTrackingItem;

/* for startup case, if null seed with date earlier than any user data */
SELECT IF (@signupRequestTrackingItemID  IS NULL, 0, @signupRequestTrackingItemID) INTO @signupRequestTrackingItemID;

/* for monitoring... */
SELECT @signupRequestTrackingItemID;

/* copy over the tracking items we care about and decode them at the same time */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	core_TrackingItem.signupRequestTrackingItemID, 
	core_TrackingItem.signupRequestID, 
	core_TrackingItem.itemType, 
	core_TrackingItem.itemName, 
			
	CASE core_TrackingItem.itemValue REGEXP "\\%"
		WHEN 1 THEN 
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(core_TrackingItem.itemValue, 
						"%25"	, "%"), 
						"%25"	, "%"), /* may be double encoded */
						"%25"	, "%"), /* may be triple encoded */
						"%20"	, " "), 
						"%26"	, "&"), 
						"%27"	, "'"),
						"%2B"	, "+"), 
						"%2c"	, ","), 
						"%2C"	, ","), 
						"%2D"	, "-"), 
						"%2F"	, "/"), 
						"%3A"	, ":"),
						"%3D"	, "="),
						"%3F"	, "?"),
						"%7B"	, "{"),
						"%7D"	, "}"),
						"%C3%A1", "��"),
						"%C3%A2", "��"),
						"%C3%A3", "��"),
						"%C3%A7", "��"),
						"%C3%A8", "��"),
						"%C3%A9", "��"),
						"%C3%AA", "��"),
						"%C3%AD", "��"),
						"%C3%B1", "��"), 
						"%C3%B3", "��") 
						
						
		ELSE core_TrackingItem.itemValue  /* nothing to decode */
	END 
												
FROM ss_account_02.signupRequestTrackingItem core_TrackingItem
WHERE core_TrackingItem.itemName IN ("c", "s", "m",    	/* high level tracking codes */
	"cv", "lpv", "sbs", "sxt", "lpa",							/* landing page codes */
	"q", "p", "wd", "terms", "query", 					/* search term parameters */
	"k", "a", "plc", "adp", "mtp", "net",				/* PPC codes */
	"Type",	"u", "Parm1", "IP",							/* Smartsheet system codes */
	"r", "utm_referrer", "url", "src",					/* referrer information, src for pm-sherpa */
	"dev", "devm", "mkwid", "gclid",					/* more PPC codes */
	"utm_expid", "ket",									/* AB testing codes */
	"wsca", 											/* web site chat */
	"rems", "rema", "remm", "remc",						/* remarketing codes */
	"lgt",												/*login type*/
	"trp",												/* trial path */
	"SAML",												/* SAML Setting*/
	"_mkto_trk",										/* marketo tracking code*/
	"ad","phrase","campaign","key","pos","block","added","source","type", /* more tracking codes for international (i.e. Yandex)*/
	"slk","slp",												/*source link*/	
	"client_id", "optimizelyBuckets", "optimizelySegments", "state","lang",
	"su_fname","su_lname","su_phone","su_company","su_title","su_role","exp") /*3rd Party Apps, Optimizely info*/		
	
AND core_TrackingItem.itemName NOT IN (BINARY "R", BINARY "U")		/*Remove "R" values which are different from "r"*/
AND core_TrackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID  /* not already done */
and core_TrackingItem.signupRequestTrackingItemID <= @NewMaxsignupRequestTrackingItemID;	/* through the end of the day */		


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem data pull");


/*cleanse records that had the item name and value incorrectly combined into the item name field*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem data cleansing");


/* Create table to stage data to be inserted */
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_signupRequestTrackingItem
(
signupRequestTrackingItemID bigint,
signupRequestID bigint,
itemType tinyint,
itemName varchar(100),
itemValue varchar(500),
extraInfo varchar(50)
)
;

/* Clean out staging table */
TRUNCATE TABLE rpt_main_02.stg_signupRequestTrackingItem;

/* Create data to hold bad records for cleansing*/ 
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_signupTrackingData
(
signupRequestID bigint,
itemName varchar(1000),
combo1 varchar(500),
combo2 varchar(500),
combo3 varchar(500)
)
;

TRUNCATE TABLE rpt_main_02.stg_signupTrackingData;


INSERT INTO rpt_main_02.stg_signupTrackingData
SELECT signupRequestID, itemName, 
rpt_main_02.SPLIT_STR(itemName,"%26",1) as combo1, /* identifies 1st name and value pair */
rpt_main_02.SPLIT_STR(itemName,"%26",2) as combo2, /* identifies 2nd name and value pair */
rpt_main_02.SPLIT_STR(itemName,"%26",3) as combo3  /* identifies 3rd name and value pair*/
FROM 
(
/*Identify records that had their itemName incorrectly populated*/
	SELECT signupRequest.signupRequestID, DATE(signupRequest.insertDateTime), signupRequest.insertDateTime, signupRequest.resultStatus, 
	signupRequestTrackingItem.itemName, signupRequestTrackingItem.itemValue
	/*rpt_signupSource.bucket, rpt_signupSource.sourceFriendly, rpt_signupSource.subSourceFriendly*/
	FROM ss_account_02.signupRequestTrackingItem
	JOIN ss_account_02.signupRequest ON signupRequest.signupRequestID = signupRequestTrackingItem.signupRequestID
	/*JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.signupRequestID = signupRequest.signupRequestID */
	WHERE itemName LIKE "s\%3D%" 
	AND signupRequest.signupRequestID >= 3907323
	AND signupRequest.signupRequestID <= @NewMaxsignupRequestID
	AND signupRequestTrackingItem.signupRequestTrackingItemID >= @signupRequestTrackingItemID
	and signupRequestTrackingItem.signupRequestTrackingItemID <= @NewMaxsignupRequestTrackingItemID
) A  /*Alias required to run subquery*/
;


/* Grab last negative value for signupRequestTrackingItemID to use as starting point for new values to be inserted*/
SELECT min(signupRequestTrackingItemID) INTO @rownum FROM rpt_main_02.rpt_signupRequestTrackingItem WHERE signupRequestTrackingItemID < 0;
-- SELECT @rownum;

/* If @rownum is null then start at -1 */
SELECT CASE WHEN @rownum IS NULL THEN -1 ELSE @rownum END INTO @rownum;


-- First Pass
INSERT INTO rpt_main_02.stg_signupRequestTrackingItem 

SELECT @rownum:=@rownum-1 AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo1,'%3D',1) AS itemName1,
substring_index(combo1,'%3D',-1) AS itemValue1, 
NULL AS extraInfo

FROM rpt_main_02.stg_signupTrackingData
WHERE combo1 IS NOT NULL
AND combo1 != ''
;

-- Second Pass

INSERT INTO rpt_main_02.stg_signupRequestTrackingItem 

SELECT @rownum:=@rownum-1 AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo2,'%3D',1) AS itemName2,
substring_index(combo2,'%3D',-1) AS itemValue2, 
NULL AS extraInfo

FROM rpt_main_02.stg_signupTrackingData
WHERE combo2 IS NOT NULL
AND combo2 != ''
;


-- Third Pass
INSERT INTO rpt_main_02.stg_signupRequestTrackingItem 

SELECT @rownum:=@rownum-1 AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo3,'%3D',1) AS itemName3,
substring_index(combo3,'%3D',-1) AS itemValue3, 
NULL AS extraInfo

FROM rpt_main_02.stg_signupTrackingData
WHERE combo3 IS NOT NULL
AND combo3 != ''
;


-- Final Insert
INSERT INTO rpt_main_02.rpt_signupRequestTrackingItem 
SELECT stg.signupRequestTrackingItemID, stg.signupRequestID, stg.itemType, stg.itemName, stg.itemValue, stg.extraInfo
FROM rpt_main_02.stg_signupRequestTrackingItem stg
LEFT JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON srti.signupRequestID=stg.signupRequestID
	AND srti.itemName=stg.itemName
WHERE srti.signupRequestTrackingItemID IS NULL
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem data cleansing");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem q parameter extract");

/* extract out the q parameter embeded in the referrer information */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into queryValue parameter */
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "q") 
		
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?q=%' OR  main_trackingItem.itemValue LIKE '%&q=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID    /* not already done */
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem q parameter extract");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem p parameter extract");

/* extract out the p parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"p", /* < -- going into p parameter, needs more processing before going into queryValue */
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(main_trackingItem.itemValue, "p") 	
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?p=%' OR  main_trackingItem.itemValue LIKE '%&p=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem p parameter extract");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem p parameter processing");


/* now process p search parameters into queryValue */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,
	"queryValue", 
	main_trackingItem.itemValue
		
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
JOIN rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem2 ON main_trackingItem.signupRequestID = main_trackingItem2.signupRequestID 
	/* there are lots of p parameters that are not search queries, so clean it up */
	AND main_trackingItem2.itemName = 'r' AND main_trackingItem2.itemValue LIKE "%yahoo%" AND main_trackingItem.itemValue NOT LIKE "ht%" 
WHERE main_trackingItem.itemName IN ("p") 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem p parameter processing");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem query parameter extract");

/* extract out the 'query' parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into queryValue parameter */
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "query") 
		
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?query=%' OR  main_trackingItem.itemValue LIKE '%&query=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem query parameter extract");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem wd parameter extract");

/* extract out the 'wd' parameter embeded in the referrer information -- but it is going into queryValueparameter */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,  
	"queryValue", /* < -- but it is going into queryValue parameter */
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "wd") 
		
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?wd=%' OR  main_trackingItem.itemValue LIKE '%&wd=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem wd parameter extract");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem terms parameter extract");

/* extract out the 'terms' parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into q parameter */
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "terms") 
		
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?terms=%' OR  main_trackingItem.itemValue LIKE '%&terms=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem terms parameter extract");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem queryValue combination");

/* combine all the new locations for search query information into one parameter: queryValue */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType,
	"queryValue", 
	itemValue
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("q", "wd", "terms", "query")  /* already did "p" earlier since it needed to be cleaned more */
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem queryValue combination");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem url parameter extract");

/* extract out the url parameter embeded in the referrer information */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType, 
	"url", 
	rpt_main_02.SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "url") 
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?url=%' OR  main_trackingItem.itemValue LIKE '%&url=%') 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem url parameter extract");


/* combine all the referrer locations for search query information into one parameter: referrerValue */
/* this first step processes the r value which takes priority */

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem referrerValue combination");

INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType,
	"referrerValue", 
	SUBSTRING_INDEX(TRIM(LEADING 'http://' FROM itemValue), "?", 1)
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName = BINARY 'r' 
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/* this second step uses the utm_referrer value if we have one already */
INSERT rpt_main_02.rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,
	"referrerValue", 
	SUBSTRING_INDEX(TRIM(LEADING 'http://' FROM main_trackingItem.itemValue), "?", 1)
FROM rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem main_trackingItemReferrerValue 
	ON main_trackingItem.signupRequestID = main_trackingItemReferrerValue.signupRequestID AND main_trackingItemReferrerValue.itemName = 'referrerValue'
WHERE main_trackingItem.itemName = 'utm_referrer' AND main_trackingItemReferrerValue.itemValue IS NULL
	AND main_trackingItem.itemValue NOT LIKE '%www.smartsheet.%' AND main_trackingItem.itemValue NOT LIKE '%.smartsheet.com%' /* don't count referrals from our site */
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem referrerValue combination");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupRequestTrackingItem update");


/* update the queryValues if it looks like they were a smartsheet search */
UPDATE rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
SET extraInfo = 'SmartsheetSearch'
WHERE main_trackingItem.itemName = 'queryValue'  AND   /* try not to false match on spreadsheet or sample sheet */
   (main_trackingItem.itemValue LIKE '%smar_sh%' OR				/* plus or space between words */
	main_trackingItem.itemValue LIKE '%smar__sh%' OR			/* one extra letter between two words or smart(space)sheet */
	main_trackingItem.itemValue LIKE '%smar___sh%' OR			/* two letters between two words */
	main_trackingItem.itemValue LIKE '%samr_sh%' OR				/* transposed m,a */
	main_trackingItem.itemValue LIKE '%samr__sh%' OR			/* transposed m,a */
	main_trackingItem.itemValue LIKE '%samr___sh%' OR			/* transposed m,a */
	main_trackingItem.itemValue LIKE '%smaartsh%' OR			/* extra a */
	main_trackingItem.itemValue LIKE '%smarsh%' OR				/* dropped the t */
	main_trackingItem.itemValue LIKE '%smar_sh%' OR				/* dropped the t, extra letter  */
	main_trackingItem.itemValue LIKE '%smatsh%' OR				/* dropped the r */
	main_trackingItem.itemValue LIKE '%smat_sh%' OR				/* dropped the r, extra letter */
	main_trackingItem.itemValue LIKE '%smartse%' OR				/* dropped the h */
	main_trackingItem.itemValue LIKE '%sartsh%'				/* dropped the m */
	)
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/* update the queryValues if it looks like they were a smartsheet search */
UPDATE rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
JOIN rpt_main_02.rpt_signupRequestTrackingItem main_trackingItemURL ON main_trackingItem.signupRequestID = main_trackingItemURL.signupRequestID AND main_trackingItemURL.itemName = 'url'
SET main_trackingItem.extraInfo =  "DeepLink-NotProvided" 	/* queryValueis blank, but the URL indicates the landing page was not the main page, so likely not a smartsheet search */
WHERE main_trackingItem.itemName = 'queryValue'  AND (main_trackingItem.itemValue = '' OR main_trackingItem.itemValue = 'null') 
/* find where they landed - if they went beyond the home page, they were likely to be a not smartsheet search, unless they went to pricing or signup page */
AND (main_trackingItemURL.itemValue LIKE '%www.smartsheet.%/_%')  AND (main_trackingItemURL.itemValue NOT LIKE '%www.smartsheet.%/pricing%') AND (main_trackingItemURL.itemValue NOT LIKE '%www.smartsheet.%/signup%')  
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/* clean up s=web that stomped on the PPC tracking codes */
UPDATE rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
/* validate it has at least two other PPC tracking codes */
JOIN rpt_main_02.rpt_signupRequestTrackingItem main_trackingItemC ON main_trackingItem.signupRequestID = main_trackingItemC.signupRequestID AND main_trackingItemC.itemName = 'c'
JOIN rpt_main_02.rpt_signupRequestTrackingItem main_trackingItemM ON main_trackingItem.signupRequestID = main_trackingItemM.signupRequestID AND main_trackingItemM.itemName = 'm'
SET main_trackingItem.itemValue = "1"   /* google search*/
WHERE main_trackingItem.itemName = 's'  AND main_trackingItem.itemValue = 'web'
AND main_trackingItem.signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/*clean up "state" value*/
UPDATE rpt_main_02.rpt_signupRequestTrackingItem main_trackingItem
SET main_trackingItem.itemValue = CASE WHEN itemValue LIKE "%|/%" THEN SUBSTRING_INDEX(itemValue,"|/",-1) ELSE NULL END 
WHERE main_trackingItem.itemName = 'state'
AND signupRequestTrackingItemID > @signupRequestTrackingItemID;

/* Now process spaces encoded as + in keywords.
   This is needed to try to match the keywords being fed back into the Marin system */

/* fix the keywords without the broad mod+ where spaces are encoded as +*/
UPDATE rpt_main_02.rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue,"+", " ")
WHERE itemName = 'k' AND itemValue REGEXP ".\\+"  AND NOT itemValue REGEXP "[' ']" AND NOT itemValue REGEXP "\\+\\+"   /* contains + but not space or ++ */
AND signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

/* fix issue with bing keywords where + in broad mod is coming through as space */
/* change the spaces into pluses here, then the next update statement will fix the ones that should be spaces  */
UPDATE rpt_main_02.rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue," ", "+")
WHERE itemName = 'k' AND (itemValue LIKE " %" OR itemValue LIKE "' %") 	/* start with space or single quote then space*/
AND signupRequestTrackingItemID > @signupRequestTrackingItemID;    		/* not already done */

/* fix the keywords that have broad mod+, turn the first + into space but keep the second+ */
UPDATE rpt_main_02.rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue,"++", " +")
WHERE itemName = 'k' AND itemValue REGEXP "\\+\\+"    /* contains ++ */
AND signupRequestTrackingItemID > @signupRequestTrackingItemID;    /* not already done */

SELECT MAX(signupRequestID) FROM rpt_main_02.rpt_lxCodes INTO @maxLxCode;

INSERT INTO rpt_main_02.rpt_lxCodes
SELECT srti.signupRequestTrackingItemID, srti.signupRequestID, srti.itemName, srti.itemValue, srti.insertDateTime
FROM ss_account_02.signupRequestTrackingItem srti
WHERE itemName = 'lx' AND srti.signupRequestID > @maxLxCode
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupRequestTrackingItem update");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_signupSource table - start ******** ", NOW();

/*Start rpt_main_02.rpt_signupSource*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupSource insert");


/* When the logic changes and we want to reprocess everything, drop the table with the line below. */
/* DROP TABLE IF EXISTS rpt_main_02.rpt_signupSource;  */
SET @weekFormat = "%Y*%U";

CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_signupSource(
	userID BIGINT, 
	email NVARCHAR(100), 
	signupRequestID BIGINT, 
	signupInsertDateTime DATETIME, 
	signupInsertDateTimePT DATETIME, 
	signupMonth NVARCHAR(20), 
	signupWeek NVARCHAR(20), 
	signupDay NVARCHAR(20), 
	source NVARCHAR(50), 
	bucket NVARCHAR(50), 
	sourceFriendly NVARCHAR(100), 
	subSourceFriendly NVARCHAR(100), 
	campaign NVARCHAR(50), 
	segment NVARCHAR(50), 
	adVersion NVARCHAR(50), 
	captcha NVARCHAR(50),
	landingPageVersion NVARCHAR(50),
	submitButtonStyle NVARCHAR(50),
	signupExtraText NVARCHAR(50),
	keyword NVARCHAR(100), 
	referrer NVARCHAR(150), 
	appLaunchType NVARCHAR(50), 
	appLaunchParm1 NVARCHAR(50), 
	appLaunchParm1Friendly NVARCHAR(100), 
	queryValue NVARCHAR(100), 
	mySmartsheetReferralLink NVARCHAR(50),  
	mySmartsheetReferralLinkFriendly NVARCHAR(100),  
	ipAddress NVARCHAR(20),  
	url NVARCHAR(150),  
	webPage NVARCHAR(100),  
	webSite NVARCHAR(75),
	placement NVARCHAR(75),
	adPosition NVARCHAR(25),
	matchType NVARCHAR(25),
	network NVARCHAR(50),
	dev NVARCHAR(20),
	devm NVARCHAR(20),
	mkwid NVARCHAR(50),
	gclid NVARCHAR(50),
	IPCountry VARCHAR(200),
	IPRegion VARCHAR(200),
	IPCity VARCHAR(200),
	INDEX(email), 
	INDEX(signupInsertDateTime),
	PRIMARY KEY(userID));
	

/* find out where we left off */
/******* SELECT MAX(logDate) INTO @startDate  - start *******/
	
DELETE FROM rpt_main_02.rpt_signupSource WHERE signupInsertDateTime >= DATE_SUB(CURRENT_DATE, INTERVAL 3 DAY);

SELECT MAX(signupRequestID) INTO @signupRequestID 		
FROM rpt_main_02.rpt_signupSource;

/* for startup case, if null seed with date earlier than any user data */
SELECT IF (@signupRequestID  IS NULL, 0, @signupRequestID) INTO @signupRequestID;

/* for monitoring... */
SELECT "Picking up where we left off at: ", @signupRequestID;

INSERT rpt_main_02.rpt_signupSource(
	userID, 
	email, 
	signupRequestID, 
	signupInsertDateTime, 
	signupInsertDateTimePT, 
	signupMonth, 
	signupWeek, 
	signupDay, 
	source, 
	bucket, 
	sourceFriendly, 
	subSourceFriendly, 
	campaign, 
	segment, 
	adVersion, 
	captcha, 
	landingPageVersion, 
	submitButtonStyle, 
	signupExtraText,  
	keyword, 
	referrer, 
	appLaunchType, 
	appLaunchParm1, 
	appLaunchParm1Friendly, 
	queryValue, 
	mySmartsheetReferralLink, 
	mySmartsheetReferralLinkFriendly, 
	ipAddress, 
	url, 
	webPage, 
	webSite,
	placement,
	adPosition,
	matchType,
	network)
SELECT 
	r.userID,
	r.emailAddress,
	r.signupRequestID,
	r.insertDateTime,
	ADDTIME(r.insertDateTime, '-7:00:00'),
	DATE_FORMAT(r.insertDateTime, '%Y*%m(%b)'), 
	rpt_main_02.SMARTSHEET_WEEK(r.insertDateTime), 
	DATE_FORMAT(r.insertDateTime, '%Y*%m*%d'), 
    source.itemValue AS Source, 
	
	NULL AS Bucket,  			/* this is now set later using the function SMARTSHEET_GET_BUCKET */
	NULL SourceFriendly,		/* this is now set later using the function SMARTSHEET_GET_SOURCE */
	
	CASE userAccount.insertByUserID = 0 
		WHEN 0 THEN "Signup Inserted by Smartsheet User"
		ELSE CASE myreferralValue.itemValue 
			WHEN "HS1018297" THEN "Office Arrow" 
			WHEN "RI1018541" THEN "A Clayton's Secretary"  
			ELSE CASE source.itemValue
				WHEN 1 THEN "_Google Search"
				WHEN 2 THEN				/* put office arrow signups with bad tracking info into right bucket */
					
					CASE (r.insertDateTime > "2009-10-12" AND r.insertDateTime < "2009-10-17" AND referrerValue.itemValue LIKE "%officeArrow%")
						WHEN 1 THEN "Office Arrow"
						ELSE "_Google Display Network"		/* Google Content Network */
					END
				WHEN 3 THEN "Yahoo"
				WHEN 4 THEN "YouTube (unpaid)"  /* "Youtube" */
				WHEN 5 THEN "Referral Rewards"
				WHEN 6 THEN "Ask.com"
				WHEN 7 THEN "Email"
				WHEN 8 THEN "_Google Search"
				WHEN 9 THEN "VANetworking.com"
				WHEN 10 THEN "Twitter (unpaid)"  /* "Twitter" */
				WHEN 11 THEN "Social Media (generic)"  /* "Social Media" */
				WHEN 12 THEN "Facebook (unpaid)"
				WHEN 13 THEN "LinkedIn (unpaid)"
				WHEN 14 THEN "Google+ (unpaid)"
				WHEN 15 THEN "Go2Web20.net"
				WHEN 16 THEN "_Bing Search"
				WHEN 17 THEN "smallbiztrends.com"
				WHEN 18 THEN "Public template gallery"
				WHEN 19 THEN "Google App. Marketplace"
				WHEN 20 THEN "Google App. Marketplace"
				WHEN 21 THEN "Intuit"
				WHEN 22 THEN "_Bing Content Network"
				WHEN 23 THEN "Ad Ready Network"
				WHEN 24 THEN "Zimbra"
				WHEN 25 THEN "Facebook"
				WHEN 26 THEN "LinkedIn"
				WHEN 27 THEN "TJ McCue"
				WHEN 28 THEN "Salesforce.com"
				WHEN 29 THEN "Sage Non-Profit"
				WHEN 30 THEN "Spanish - Google Search Test"
				WHEN 31 THEN "Spanish - Google Display Network Test"
				WHEN 32 THEN "Chrome Web Store"
				WHEN 33 THEN "Serchen"
				WHEN 34 THEN "The Deck"
				WHEN 35 THEN "South Africa - Google Display"
				WHEN 36 THEN "_Google Display (iPad only)"
				WHEN 37 THEN "_Google Search (iPad only)"
				WHEN 38 THEN "Germany - Google Display"
				WHEN 39 THEN "Germany - Google Search"
				WHEN 40 THEN "France - Google Display"
				WHEN 41 THEN "France - Google Search"
				WHEN 42 THEN "Brazil - Google Display"
				WHEN 43 THEN "Brazil - Google Search"
				WHEN 44 THEN "India - Google Display"
				WHEN 45 THEN "India - Google Search"
				WHEN 46 THEN "South Africa - Google Search"
				WHEN 47 THEN "Hong Kong - Google Search"
				WHEN 48 THEN "Hong Kong - Google Display"
				WHEN 49 THEN "Denmark - Google Display"
				WHEN 50 THEN "Denmark - Google Search"
				WHEN 51 THEN "Finland - Google Display"
				WHEN 52 THEN "Finland - Google Search"
				WHEN 53 THEN "Netherlands - Google Display"
				WHEN 54 THEN "Netherlands - Google Search"
				WHEN 55 THEN "Branded PPC (Google)"		
				WHEN 56 THEN "Google Templates"
				WHEN 57 THEN "Google Remarketing (Paid Visitors)"
				WHEN 58 THEN "Google Remarketing (Non-paid Visitors)"
				WHEN 59 THEN "Google Remarketing (Nurture Signups)"
				WHEN 60 THEN "Bing Search (Canada)"
				WHEN 61 THEN "Bing Search (Singapore)"
				WHEN 62 THEN "Bing Search (UK)"
				WHEN 63 THEN "Bing Search (French - Canada)"
				WHEN 64 THEN "Bing Search (French - France)"
				WHEN 65 THEN "Singapore - Google Display"
				WHEN 66 THEN "Singapore - Google Search"
				WHEN 67 THEN "Norway - Google Display"
				WHEN 68 THEN "Norway - Google Search"
				WHEN 69 THEN "Sweden - Google Display"
				WHEN 70 THEN "Sweden - Google Search"
				WHEN 71 THEN "Indonesia - Google Display"
				WHEN 72 THEN "Indonesia - Google Search"
				WHEN 73 THEN "Mexico - Google Display"
				WHEN 74 THEN "Mexico - Google Search"
				WHEN 75 THEN "Japan - Google Display"
				WHEN 76 THEN "Japan - Google Search"
				WHEN 77 THEN "Israel - Google Display"
				WHEN 78 THEN "Israel - Google Search"
				WHEN 79 THEN "Malaysia - Google Display"
				WHEN 80 THEN "Malaysia - Google Search"
				WHEN 81 THEN "Philippines - Google Display"
				WHEN 82 THEN "Philippines - Google Search"
				WHEN 83 THEN "Spain - Google Display"
				WHEN 84 THEN "Spain - Google Search"
				WHEN 85 THEN "Belgium - Google Display"
				WHEN 86 THEN "Belgium - Google Search"
				WHEN 87 THEN "Youtube (promoted videos)"
				WHEN 88 THEN "Italy - Google Display"
				WHEN 89 THEN "Italy - Google Search"
				WHEN 90 THEN "Turkey - Google Display"
				WHEN 91 THEN "Turkey - Google Search"
				WHEN 92 THEN "South Korea - Google Display"
				WHEN 93 THEN "South Korea - Google Search"
				WHEN 94 THEN "Columbia - Google Display"
				WHEN 95 THEN "Columbia - Google Search"
				WHEN 96 THEN "Argentina - Google Display"
				WHEN 97 THEN "Argentina - Google Search"
				WHEN 98 THEN "Saudi Arabia - Google Display"
				WHEN 99 THEN "Saudi Arabia - Google Search"
				WHEN 100 THEN "Spanish (US) - Google Display"
				WHEN 101 THEN "Spanish (US) - Google Search"
				WHEN 102 THEN "Spanish (Mexico) - Google Display"
				WHEN 103 THEN "Spanish (Mexico) - Google Search"
				WHEN 104 THEN "Spanish (Spain) - Google Display"
				WHEN 105 THEN "Spanish (Spain) - Google Search"
				WHEN 106 THEN "Spanish (Other) - Google Display"
				WHEN 107 THEN "Spanish (Other) - Google Search"
				WHEN 108 THEN "Spanish (Argentina)  Google Display"
				WHEN 109 THEN "Spanish (Argentina)  Google Search"
				WHEN 110 THEN "Spanish (Peru)  Google Display"
				WHEN 111 THEN "Spanish (Peru)  Google Search"
				WHEN 112 THEN "Spanish (Venezuela)  Google Display"
				WHEN 113 THEN "Spanish (Venezuela)  Google Search"
				WHEN 114 THEN "Spanish (Chile)  Google Display"
				WHEN 115 THEN "Spanish (Chile)  Google Search"
				WHEN 116 THEN "Spanish (Guatemala)  Google Display"
				WHEN 117 THEN "Spanish (Guatemala)  Google Search"
				WHEN 118 THEN "Spanish (Ecuador)  Google Display"
				WHEN 119 THEN "Spanish (Ecuador)  Google Search"
				WHEN 120 THEN "GetApp.com"
				WHEN 121 THEN "Cloud Alliance for Google Apps"			
				WHEN 122 THEN "China - Google Display"
				WHEN 123 THEN "China - Google Search"
				WHEN 124 THEN "Russia - Google Display"
				WHEN 125 THEN "Russia - Google Search"
				WHEN 126 THEN "French (Tier 1) - Google Display"
				WHEN 127 THEN "French (Tier 1) - Google Search"
				WHEN 128 THEN "French (Tier 2) - Google Display"
				WHEN 129 THEN "French (Tier 2) - Google Search"
				WHEN 130 THEN "Portuguese (Brazil) - Google Display"
				WHEN 131 THEN "Portuguese (Brazil) - Google Search"
				WHEN 132 THEN "Portuguese (Portugal) - Google Display"
				WHEN 133 THEN "Portuguese (Portugal) - Google Search"
				WHEN 134 THEN "Box"
				WHEN 135 THEN "_Display - Managed Placements"
				WHEN 136 THEN "Sitepoint"
				WHEN 137 THEN "Brad Egeland"
				WHEN 138 THEN "Google Drive"
				WHEN 139 THEN "Crowdsourcing.org"
				WHEN 140 THEN "Berklee School of Music"
				WHEN 141 THEN "Google Adwords Sitelinks"
				WHEN 142 THEN "AWS Marketplace"
				WHEN 143 THEN "Google Mobile Search (iphone)"
				WHEN 144 THEN "Google Mobile Search (non-iphone)"
				WHEN 145 THEN "German - Google Display"
				WHEN 146 THEN "German - Google Search"
				WHEN 147 THEN "Italian - Google Display"
				WHEN 148 THEN "Italian - Google Search"
				WHEN 149 THEN "Enterprise Display Test - Spreadsheet Hell - Desktop"
				WHEN 150 THEN "Enterprise Display Test - Spreadsheet Hell - Mobile"
				WHEN 151 THEN "_Display - Managed Placements - Tier 1 International"
				WHEN 152 THEN "_Display - Managed Placements - Tier 2 International"
				WHEN 153 THEN "Google Display - Interest Targeted"
				WHEN 154 THEN "Web Forms - Powered by Smartsheet"
				WHEN 155 THEN "Published Sheet - Powered by Smartsheet"
				WHEN 156 THEN "_Google Search - International - Tier 1"
				WHEN 157 THEN "_Google Search - International - Tier 2"
				WHEN 158 THEN "Apple App Store"
				WHEN 159 THEN "Android App Store"
				WHEN 160 THEN "BlueKai - (Google)"
				WHEN 161 THEN "Similar Audiences - (Google)"	
				WHEN 162 THEN "Gmail Ads"	
				WHEN 163 THEN "Branded PPC (Bing)"	
				WHEN 164 THEN "Google Business Category Display"
				WHEN 165 THEN "Elizabeth Harrin (blog posse)"
				WHEN 166 THEN "Video for Adwords"
				WHEN 167 THEN "Robert Kelly (blog posse)"
				WHEN 168 THEN "Lindsay Scott (blog posse)"
				WHEN 169 THEN "Seattle GEO Target (Google Search)"
				WHEN 170 THEN "Seattle GEO Target (Bing Search)"
				WHEN 171 THEN "Seattle GEO Target (Google Display Image)"
				WHEN 172 THEN "Seattle GEO Target (Bing Content)"
				WHEN 173 THEN "Seattle GEO Target (Google Text Display)"
				WHEN 174 THEN "Google Display - Image Ads"
				WHEN 175 THEN "Google Display - Text Ads"
				WHEN 176 THEN "Google Display International - Text Ads"
				WHEN 177 THEN "Google Display International - Image Ads"
				WHEN 178 THEN "thesmallbusinessweb.com"
				WHEN 179 THEN "Centrify"
				WHEN 180 THEN "Social Media Coordinator - Keri"
				WHEN 181 THEN "Geekwire"
				WHEN 182 THEN "USA Today"
				WHEN 183 THEN "Pac NW Soccer"
				WHEN 184 THEN "LinkedIn InMail"
				WHEN 185 THEN "NAPS"
				WHEN 186 THEN "Google Search Companion Marketing"
				WHEN 187 THEN "Google Search Companion Marketing (International)"
				WHEN 188 THEN "Kindle"
				WHEN 189 THEN "Google Play Store"
				WHEN 190 THEN "Zapier"
				WHEN 191 THEN "Dropbox"
				WHEN 192 THEN "123 Contact Form"
				WHEN 193 THEN "Twitter (paid)"
				WHEN 194 THEN "Stack Overflow"
				WHEN 195 THEN "DemandMetric.com"
				WHEN 196 THEN "Similar Audiences (Google) - International"
				WHEN 197 THEN "Google Display - Interest Targeted (International)"
				WHEN 198 THEN "ProjectManagers.net"
				WHEN 199 THEN "ProjectsAtWork.com"
				WHEN 200 THEN "ProjectManagement.com"
				WHEN 201 THEN "Slideshare.net"
				WHEN 202 THEN "LinkedIn International (paid)"
				WHEN 203 THEN "Bing Search - International - Tier 1"
				WHEN 204 THEN "Bing Search - French"
				WHEN 205 THEN "Bing Search - German"
				WHEN 206 THEN "Bing Search - Portuguese (Brazil)"
				WHEN 207 THEN "Bing Search - Portuguese (Portugal)"
				WHEN 208 THEN "Bing Search - Spanish"
				WHEN 209 THEN "Bing Search - Italian"
				WHEN 210 THEN "Google Search - Russian"
				WHEN 211 THEN "Marketo Launchpoint"
				WHEN 212 THEN "Gmail Ads - International"
				WHEN 213 THEN "Bing Display - Text Ads (USA)"
				WHEN 214 THEN "Bing Display - Text Ads (English Not USA)"
				WHEN 215 THEN "Bing Sitelinks"
				WHEN 216 THEN "Docusign"
				WHEN 217 THEN "Yandex (paid)"
				WHEN 218 THEN "MailChimp"
				WHEN 219 THEN "Harvest"
				WHEN 220 THEN "Evernote"
				WHEN 221 THEN "Amazon Mechanical Turk"
				WHEN 222 THEN "AppGuru"
				WHEN 223 THEN "Backupify"
				WHEN 224 THEN "Bitium"
				WHEN 225 THEN "Easy Insight"
				WHEN 226 THEN "OneLogin"
				WHEN 227 THEN "PingOne"
				WHEN 228 THEN "Klipfolio"
				WHEN 229 THEN "Tools4ever"
				WHEN 230 THEN "Okta"
				WHEN 231 THEN "Spiceworks"
				WHEN 232 THEN "Third Party Authorization Flow"
				WHEN 233 THEN "BetterCloud"
				WHEN 234 THEN "Smartsheet Merge (Google Docs Add-on)"
				WHEN 235 THEN "Smartsheet Forms (Google Forms Add-on)"
				WHEN 236 THEN "Display - Select Keyword"
				WHEN 237 THEN "Display - Select Keyword (International)"
				WHEN 238 THEN "Google Search - Japanese"
				WHEN 239 THEN "Microsoft"
				WHEN 240 THEN "Yahoo Japan"
				WHEN 241 THEN "Wave"
				WHEN 242 THEN "Microsoft Office 365/Azure Marketplace"
				WHEN 243 THEN "French - Display - Interest Targeted"
				WHEN 244 THEN "Facebook (paid) - International EN"
				WHEN 245 THEN "Google Display Japan"
				WHEN 246 THEN "Japanese - Display - Interest Targeted"
				WHEN 247 THEN "Russian - Display - Interest Targeted"
				WHEN 248 THEN "Russian - Display"
				WHEN 249 THEN "German - Display - Interest Targeted"
				WHEN 250 THEN "Italian - Display - Interest Targeted"
				WHEN 251 THEN "Portuguese (Brazil) - Display - Interest Targeted"
				WHEN 252 THEN "Portuguese (Portugal) - Display - Interest Targeted"
				WHEN 253 THEN "Spanish - Display - Interest Targeted"
				WHEN 254 THEN "Cloud Sherpas"
				WHEN 255 THEN "gPartner"
				WHEN 256 THEN "Business Cloud"
				WHEN 257 THEN "Cirruseo"
				WHEN 258 THEN "Google general"
				WHEN 259 THEN "Microsoft Office Store"
				WHEN 260 THEN "Yahoo Display - Native Ads"
				WHEN 261 THEN "Capterra"
				WHEN 262 THEN "School of Bookkeeping"
				WHEN 263 THEN "Box"
				WHEN 264 THEN "Microsoft Referral"
				WHEN 265 THEN "Microsoft Referral 0365 Launcher"
				WHEN 266 THEN "GetApp Paid"
				WHEN 267 THEN "Puget Sound PMI"
				WHEN 268 THEN "Project-Management.com"
				WHEN 269 THEN "Solution Center Brochure"
				WHEN 270 THEN "FindtheBest Paid"
				WHEN 271 THEN "Yahoo Search"
				WHEN 272 THEN "Yahoo Search INT"
				WHEN 273 THEN "Integrated Content Pages"
				WHEN 274 THEN "Solution Center"
				WHEN 275 THEN "Softline India"
				WHEN 276 THEN "DoubleClick Campaign Manager"
				WHEN 277 THEN "DoubleClick Interest Targeted"
				WHEN 278 THEN "DoubleClick Context Matched"
				WHEN 279 THEN "DoubleClick Manual Placement"
				WHEN 280 THEN "Projects At Work"
				WHEN 281 THEN "LinkedIn remarketing platform"
				WHEN 282 THEN "Google Display - In-Market Audience"
				WHEN 283 THEN "Google Display - In-Market Audience (INT)"
				WHEN 284 THEN "StackOverflow"
				WHEN 285 THEN "Instagram(Paid)"
				WHEN 286 THEN "YouTube Promoted Videos (INT)"
				WHEN 287 THEN "Techcrunch"
				WHEN 288 THEN "Cyberco Procore Connector"
				WHEN 289 THEN "Rolex Sydney Yacht Race"
				WHEN 290 THEN "G2 Crowd (paid)"
				WHEN 291 THEN "Google Product Listing Ads"
				WHEN 292 THEN "Microsoft Teams signup"
				WHEN 293 THEN "SalesForce AppExchange signups"
				WHEN 294 THEN "Project Vision Dynamics USA"
				WHEN 295 THEN "SoftwareONE Chile"
				WHEN 296 THEN "SoftwareONE Brazil"
				WHEN 297 THEN "SoftwareONE Argentina"
				WHEN 298 THEN "eSource Mexico"
				WHEN 299 THEN "Comparex Germany"
				WHEN 300 THEN "Searce India"
				WHEN 301 THEN "Softline Malaysia"
				WHEN 302 THEN "Softline Thailand"
				WHEN 303 THEN "Softline Vietnam"
				WHEN 304 THEN "Softline Korea"
				WHEN 305 THEN "SoftwareONE USA"
				WHEN 306 THEN "Mbizer Singapore"
				WHEN 307 THEN "Six Step Australia"
				WHEN 308 THEN "Cardinal Consulting Australia"
				WHEN 309 THEN "SoftwareONE Uruguay"
				WHEN 310 THEN "SoftwareOne UK"
				WHEN 311 THEN "SoftwareOne France"
				WHEN 312 THEN "SoftwareONE Japan"
				WHEN 313 THEN "Softline Philippines"
				WHEN 314 THEN "Smartsheet Channel Partners"
				WHEN 315 THEN "57network"
				WHEN 316 THEN "Insight"
				WHEN 317 THEN "Seam Labs"
				WHEN 318 THEN "Gmail AddOn Integration"
				WHEN 319 THEN "Quip Integration"
				WHEN 320 THEN "Google Adwords US FL"
				WHEN 321 THEN "Comparex India"
				WHEN 322 THEN "Softline India"
				WHEN 323 THEN "Google Adwords UK"
				WHEN 324 THEN "Outlook Add-In"
				ELSE CASE (src.itemValue = "pm-sherpa")
					WHEN 1 THEN "PM Sherpa"
					ELSE CASE appLaunchParm1.itemValue
						/* Distributed container IDs for affiliates only*/
						WHEN 1007049 THEN "VA Network"
						WHEN 1003002 THEN "VA Network"
						WHEN 1004022 THEN "Veronica Conway"
						WHEN 1043072 THEN "Veronica Conway"
						WHEN 1002982 THEN "Officebundle.com"
						WHEN 1018093 THEN "Regina Minger"
						WHEN 1024411 THEN "Tradeshow Coach"
						WHEN 1034796 THEN "Ki-Work"
						WHEN 1034806 THEN "OnlineBizU"
						WHEN 1040910 THEN "Success Connections"
						WHEN 1041452 THEN "Baird Consulting"
						WHEN 1045303 THEN "Biz Recipes"
						WHEN 1051958 THEN "Assistant Match"
						WHEN 1053162 THEN "Caroline Melville Society of Virtual Assistants"
						WHEN 1053163 THEN "Caroline Melville Virtually Sorted"
					ELSE CASE myreferralValue.itemValue  IS NOT NULL  /* somebodys My Smartsheet Referral Link */
							WHEN 1 THEN "My Smartsheet Referral"																					
						ELSE CASE WHEN state.itemValue LIKE "%outlookapp%" THEN "OutlookApp Integration"
							WHEN state.itemValue LIKE "%evernote%"  THEN "Evernote Integration"
							ELSE CASE referrerValue.itemValue LIKE "%aws.%"		/* considering amazon web services links as affiliate */
								WHEN 1 THEN "Amazon Web Services"					
								ELSE CASE referrerValue.itemValue LIKE "%jott%"		/* considering jott links as affiliate */
									WHEN 1 THEN "Jott"					
									ELSE CASE referrerValue.itemValue LIKE "%search%" OR referrerValue.itemValue LIKE "%www.google%" OR referrerValue.itemValue LIKE "%www.yahoo%" 
										OR referrerValue.itemValue LIKE "%www.bing%" OR referrerValue.itemValue LIKE "%yandex.ru%" OR referrerValue.itemValue LIKE "%duckduckgo%" OR queryValue.itemValue IS NOT NULL 		/* link opened from natural search */
										WHEN 1 THEN "Organic Search"		
										ELSE CASE appLaunchType.itemValue
											WHEN 2 THEN "Signup with Sharing Tracking Codes" 		/* grid - the user was shared a sheet, but the auto-login did not work so user signed up */
											/* WHEN 5 THEN "Direct Navigation" 	- distributed container - let referral and search logic below apply */
											WHEN 6 THEN "Signup with Sharing Tracking Codes"		/* workspace - the user was shared a workspace, but the auto-login did not work so user signed up */
											WHEN 10 THEN "Google Drive - Import"		/* IMPORT_GOOGLE_DRIVE_FILE */
											WHEN 11 THEN "Google Drive - New File"		/* NEW_GOOGLE_DRIVE_FILE */													ELSE CASE referrerValue.itemValue LIKE "%mail%"	 AND referrerValue.itemValue NOT LIKE "%-email%"	/* link opened from web mail client - not an article about email, someone sent them the link without other source info on link */
												WHEN 1 THEN "Mail Link"			
												ELSE CASE referrerValue.itemValue IS NOT NULL AND referrerValue.itemValue != '' AND referrerValue.itemValue NOT LIKE "%smartsheet%"
													WHEN 1 THEN "External Source Links" 
													/* ELSE CASE appLaunchType.itemValue 
													  WHEN 5 THEN "Distributed Container" */		
													  ELSE "Direct Navigation"
													/* END */																								
												END
											END
										END
									END
								END
							END
						END
					END
				END
			END
		END
	END
	END AS SubSourceFriendly,

   CONCAT(campaign.itemValue, " - ", IF(campaignLookup.campaignDescription IS NULL, "not found", campaignLookup.campaignDescription)) AS Campaign, 
   CONCAT(segment.itemValue, " - ", IF(segmentLookup.segmentDescription IS NULL, "not found", segmentLookup.segmentDescription)) AS Segment, 
   adVersion.itemValue AS adVersion, 
   NULL, /* toddj - not really used anymore - captcha.itemValue AS captcha, */
   landingPageVersion.itemValue AS landingPageVersion, 
   NULL, /* toddj - not really used anymore - submitButtonStyle.itemValue AS submitButtonStyle, */
   NULL, /* toddj - not really used anymore - signupExtraText.itemValue AS signupExtraText, */
   NULL AS Keyword,  /* process keyword in later UPDATE */
   referrerValue.itemValue AS Referrer, 
   appLaunchType.itemValue AS TYPE,
   appLaunchParm1.itemValue AS Parm1,
   container.name AS Parm1Friendly,
	
	SUBSTRING(queryValue.itemValue, 1, 150)  AS "QUERY",

	myreferralValue.itemValue AS mySmartsheetReferralLink,
	(SELECT emailAddress FROM rpt_main_02.userAccount WHERE userID = SUBSTR(myreferralValue.itemValue, 3)) AS mySmartsheetReferralLinkFriendly,
	0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL
       
FROM ss_account_02.signupRequest r 
	LEFT OUTER JOIN rpt_main_02.rpt_signupSource 								ON rpt_signupSource.userID = r.userID
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	source 				ON r.signupRequestID = source.signupRequestID AND source.itemType = 1 AND source.itemName = "s"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem	referrerValue 		ON referrerValue.signupRequestID = r.signupRequestID AND referrerValue.itemType = 1 AND referrerValue.itemName = "referrerValue"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	queryValue 			ON queryValue.signupRequestID 		= r.signupRequestID AND queryValue.itemType = 1 AND queryValue.itemName = "queryValue"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	myreferralValue 	ON myreferralValue.signupRequestID 	= r.signupRequestID AND myreferralValue.itemType = 1 AND myreferralValue.itemName = "u"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	src 				ON src.signupRequestID 	= r.signupRequestID AND src.itemType = 1 AND src.itemName = "src"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	appLaunchType 		ON appLaunchType.signupRequestID = r.signupRequestID AND appLaunchType.itemType = 2 AND appLaunchType.itemName = "Type"
	LEFT OUTER JOIN rpt_main_02.userAccount					 	userAccount 		ON userAccount.userID = r.userID

	/* remaining joins are not needed for the bucketing process, they just provide extra info that could be done after this big query */
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	campaign 			ON r.signupRequestID = campaign.signupRequestID AND campaign.itemType = 1 AND campaign.itemName = "c"
		LEFT OUTER JOIN rpt_main_02.ref_campaignLookup 			campaignLookup 		ON campaign.itemValue = campaignLookup.campaignID
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	appLaunchParm1 		ON r.signupRequestID = appLaunchParm1.signupRequestID AND appLaunchParm1.itemType = 2 AND appLaunchParm1.itemName = "Parm1"
		LEFT OUTER JOIN ss_core_02.container 					container 			ON appLaunchParm1.itemValue = container.containerID AND container.containerID <= @NewMaxContainerIDModify
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	segment 			ON r.signupRequestID = segment.signupRequestID	AND segment.itemType = 1 AND segment.itemName = "m"
		LEFT OUTER JOIN rpt_main_02.ref_campaignSegmentLookup 	segmentLookup 		ON segment.itemValue = segmentLookup.segmentID
		
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	landingPageVersion 	ON landingPageVersion.signupRequestID = r.signupRequestID AND landingPageVersion.itemType = 1 AND landingPageVersion.itemName = "lpv"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	adVersion 			ON r.signupRequestID = adVersion.signupRequestID AND adVersion.itemType = 1 AND adVersion.itemName = "a"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	state 				ON r.signupRequestID = state.signupRequestID AND state.itemType = 1 AND state.itemName = "state"

	/* toddj - not really used anymore, commented out for now */
/*	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	captcha 			ON captcha.signupRequestID = r.signupRequestID AND captcha.itemType = 1 AND captcha.itemName = "cv"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	submitButtonStyle 	ON submitButtonStyle.signupRequestID = r.signupRequestID AND submitButtonStyle.itemType = 1 AND submitButtonStyle.itemName = "sbs"
	LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	signupExtraText 	ON signupExtraText.signupRequestID = r.signupRequestID AND signupExtraText.itemType = 1 AND signupExtraText.itemName = "sxt"
*/
WHERE r.resultStatus = 1 AND  r.userID IS NOT NULL 	/* only process good records */
	AND r.signupRequestID > @signupRequestID		/* only process those that have not yet been processed */
	AND r.signupRequestID <= @NewMaxsignupRequestID 
	AND rpt_signupSource.userID IS NULL			/* if one only exists for the user, don't process another, it will error out */
GROUP BY r.userID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupSource insert");


/************** finished inserts, now processing updates **************************/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupSource update");

/* fix sub-source for these outliers before looking up the source, buckt */
UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem 	appLaunchType 		ON appLaunchType.signupRequestID = rpt_signupSource.signupRequestID AND appLaunchType.itemType = 2 AND appLaunchType.itemName = 'Type'
SET rpt_signupSource.subSourceFriendly = "Chrome Web Store"
WHERE rpt_signupSource.subSourceFriendly = "Direct Navigation" 
AND rpt_signupSource.signupInsertDateTime < DATE("2013-03-01")   /* don't assume all going forward are from Chrome Web Store, but all from past are. */
AND appLaunchType.itemValue = 12  /* GETTING_STARTED_SHEET */
AND rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */


/* Set the source based on the subsource */
UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
SET rpt_signupSource.sourceFriendly = rpt_main_02.SMARTSHEET_GET_SOURCE(rpt_signupSource.subSourceFriendly)
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

/* Now set the bucket based on the source */
UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
SET rpt_signupSource.bucket = rpt_main_02.SMARTSHEET_GET_BUCKET(rpt_signupSource.sourceFriendly)
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

/* Code for new viral sourcing 5-5-16 */ 
DROP TABLE IF EXISTS rpt_main_02.stg_viralSourcingSignups;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_viralSourcingSignups
(userID BIGINT,
insertByUserID BIGINT,
domain VARCHAR(100),
insertByUserDomain VARCHAR(100),
isISP TINYINT,
insertByUserIsISP TINYINT,
sourceFriendly VARCHAR(100),
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_viralSourcingSignups
SELECT ss.userID, u.insertByUserID, u.domain, uu.domain AS inserterDomain, 
CASE WHEN isp1.domain IS NOT NULL THEN 1 ELSE 0 END AS isISP,
CASE WHEN isp2.domain IS NOT NULL THEN 1 ELSE 0 END AS sharerIsISP,
CASE WHEN isp1.domain IS NOT NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to ISP)'
	WHEN isp1.domain IS NOT NULL AND isp2.domain IS NULL THEN 'Sharing (Org to ISP)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to Org)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain = uu.domain THEN 'Sharing (Org to Org In Domain)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain != uu.domain THEN 'Sharing (Org to Org Out Domain)'
		END AS sourceFriendly
FROM rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.userAccount u ON ss.userID = u.userID
JOIN rpt_main_02.userAccount uu ON uu.userID = u.insertByUserID
LEFT JOIN rpt_main_02.arc_ISPDomains isp1 ON isp1.domain = u.domain
LEFT JOIN rpt_main_02.arc_ISPDomains isp2 ON isp2.domain = uu.domain
WHERE ss.subSourceFriendly = 'Signup Inserted by Smartsheet User'
AND ss.signupRequestID > @signupRequestID
; 

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.stg_viralSourcingSignups vss ON vss.userID = ss.userID
SET ss.sourceFriendly = vss.sourceFriendly;

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem ipAddress ON rpt_signupSource.signupRequestID = ipAddress.signupRequestID AND ipAddress.itemType = 3 AND ipAddress.itemName = 'ip'
SET rpt_signupSource.ipAddress = 
	CASE WHEN INSTR (ipAddress.itemValue, "," ) > 0
		THEN SUBSTRING_INDEX(ipAddress.itemValue, ",", 1) 
		ELSE ipAddress.itemValue
	END
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'url'
SET rpt_signupSource.url = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'plc'
SET rpt_signupSource.placement =  TRIM(LEADING 'www.' FROM srti.itemValue)
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'adp'
SET rpt_signupSource.adPosition = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'mtp'
SET rpt_signupSource.matchtype = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemType = 1 AND srti.itemName = 'net'
SET rpt_signupSource.network = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'dev'
SET rpt_signupSource.dev = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'devm'
SET rpt_signupSource.devm = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'mkwid'
SET rpt_signupSource.mkwid = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'gclid'
SET rpt_signupSource.gclid = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'k'
SET rpt_signupSource.keyword = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'slk'
SET rpt_signupSource.slk = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'ad'
SET rpt_signupSource.ad_id = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'phrase'
SET rpt_signupSource.phrase_id = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'campaign'
SET rpt_signupSource.campaign_id = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'key'
SET rpt_signupSource.`key` = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'pos'
SET rpt_signupSource.position = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'block'
SET rpt_signupSource.position_type = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'added'
SET rpt_signupSource.addphrases = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'type'
SET rpt_signupSource.source_type = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'trp'
SET rpt_signupSource.trpValue = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'client_ID'
SET rpt_signupSource.apiClientID = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'optimizelyBuckets'
SET rpt_signupSource.optimizelyExpID = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'slp'
SET rpt_signupSource.slp = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'lpa'
SET rpt_signupSource.lpa = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'lang'
SET rpt_signupSource.lang = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
SET rpt_signupSource.webPage = 
	CASE rpt_signupSource.url IS NULL
		WHEN 1 THEN TRIM(LEADING 'https://' FROM TRIM(LEADING 'http://' FROM rpt_signupSource.referrer))
		ELSE  TRIM(LEADING 'https://' FROM TRIM(LEADING 'http://' FROM rpt_signupSource.url))
	END
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
SET rpt_signupSource.webSite = SUBSTRING_INDEX(webPage, '/', 1)
WHERE rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_fname'
SET rpt_signupSource.firstName = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_lname'
SET rpt_signupSource.lastName = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_phone'
SET rpt_signupSource.phone = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_company'
SET rpt_signupSource.company = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_title'
SET rpt_signupSource.title = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'su_role'
SET rpt_signupSource.role = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

UPDATE rpt_main_02.rpt_signupSource rpt_signupSource
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem srti ON rpt_signupSource.signupRequestID = srti.signupRequestID AND srti.itemName = 'exp'
SET rpt_signupSource.exp = srti.itemValue
WHERE rpt_signupSource.signupRequestID > @signupRequestID ;		/* only process those that have not yet been processed */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupSource update");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** ref_ipAddressInfo table - start ******** ", NOW();

/* Start rpt_main_02.ref_ipAddressInfo */

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.ref_ipAddressInfo insert");

SELECT MAX(sessionLogID) FROM rpt_main_02.rpt_sessionLog INTO @maxSessionId;

/* push the new ipAddresses into the info table */
INSERT rpt_main_02.ref_ipAddressInfo(
  ipAddress)
SELECT DISTINCT
/* cleanse ipAddress that have multiple inline before inserting*/
CASE WHEN  instr(rpt_signupSource.ipAddress, "," ) > 0
		THEN SUBSTRING_INDEX(rpt_signupSource.ipAddress, ",", 1) 
		ELSE rpt_signupSource.ipAddress
	END
FROM rpt_main_02.rpt_signupSource       
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = CASE WHEN instr(rpt_signupSource.ipAddress, "," ) > 0
		THEN SUBSTRING_INDEX(rpt_signupSource.ipAddress, ",", 1) 
		ELSE rpt_signupSource.ipAddress
	END
WHERE rpt_signupSource.ipAddress IS NOT NULL AND ref_ipAddressInfo.ipAddress IS NULL /* only do ipAddresses we have not looked up already */
AND rpt_signupSource.signupRequestID > @signupRequestID;		/* only process those that have not yet been processed */



INSERT IGNORE rpt_main_02.ref_ipAddressInfo (ipAddress)
SELECT DISTINCT 
CASE WHEN instr(rpt_userIPLocation.ipNumber, ",") > 0
	THEN SUBSTRING_INDEX(rpt_userIPLocation.ipNumber, ",", 1)
	ELSE rpt_userIPLocation.ipNumber
	END
FROM rpt_main_02.rpt_userIPLocation
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = CASE WHEN instr(rpt_userIPLocation.ipNumber, ",") > 0
	THEN SUBSTRING_INDEX(rpt_userIPLocation.ipNumber, ",", 1)
	ELSE rpt_userIPLocation.ipNumber
	END
WHERE ref_ipAddressInfo.ipAddress IS NULL
;

INSERT IGNORE INTO rpt_main_02.ref_ipAddressInfo(
  ipAddress)
SELECT DISTINCT
CASE WHEN  INSTR(rpt_sessionLog.sourceIP, "," ) > 0
		THEN SUBSTRING_INDEX(rpt_sessionLog.sourceIP, ",", 1) 
		ELSE rpt_sessionLog.sourceIP
	END
FROM rpt_main_02.rpt_sessionLog      
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = CASE WHEN INSTR(rpt_sessionLog.sourceIP, "," ) > 0
		THEN SUBSTRING_INDEX(rpt_sessionLog.sourceIP, ",", 1) 
		ELSE rpt_sessionLog.sourceIP
	END
WHERE rpt_sessionLog.sourceIP IS NOT NULL AND ref_ipAddressInfo.ipAddress IS NULL /* only do ipAddresses we have not looked up already */
AND rpt_sessionLog.sessionLogID > @maxSessionId;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.ref_ipAddressInfo insert");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.ref_ipAddressInfo update");

/* update the batch that was marked, we do this in two steps because you cannot put a LIMIT clause on an UPDATE that has a JOIN */
UPDATE rpt_main_02.ref_ipAddressInfo AS ref_ipAddressInfo
LEFT OUTER JOIN rpt_main_02.ref_ipNumber ref_ipNumber ON INET_ATON(ref_ipAddressInfo.ipAddress) = ref_ipNumber.ipNumber 
LEFT OUTER JOIN rpt_main_02.ref_ipLocation ref_ipLocation ON ref_ipNumber.locId = ref_ipLocation.locId
LEFT OUTER JOIN rpt_main_02.ref_country ref_country ON ref_ipLocation.country = ref_country.countryCode
LEFT OUTER JOIN rpt_main_02.ref_region ref_region ON ref_ipLocation.country = ref_region.countryCode AND ref_ipLocation.region = ref_region.regionCode
  SET 
  ref_ipAddressInfo.countryName = ref_country.countryName,
  ref_ipAddressInfo.regionName = ref_region.regionName,
  ref_ipAddressInfo.city = ref_ipLocation.city
WHERE ref_ipAddressInfo.countryName IS NULL;  /* only do ipAddresses we have not looked up already */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.ref_ipAddressInfo update");


/* update rpt_signupSource to include ip locations*/
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_signupSource ip location update");

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPCountry=ref.countryName
WHERE ss.IPCountry IS NULL
;

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPRegion=ref.regionName
WHERE ss.IPRegion IS NULL
;

UPDATE rpt_main_02.rpt_signupSource ss
JOIN rpt_main_02.ref_ipAddressInfo ref ON ss.ipAddress=ref.ipAddress
SET ss.IPCity=ref.city
WHERE ss.IPCity IS NULL
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_signupSource ip location update");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_sessionLog table - start ******** ", NOW();

/*Start rpt_main_02.rpt_sessionLog*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_sessionLog");


/*DROP TABLE IF EXISTS rpt_main_02.rpt_sessionLog;*/
 CREATE TABLE IF NOT EXISTS 
  rpt_main_02.rpt_sessionLog(
	 /* these fields are straight from the sessionLog table */
 	sessionLogID BIGINT, 
	 userID BIGINT, 
	 emailAddress VARCHAR(100), 
	 loginType VARCHAR (50),
 	loginAuthResult VARCHAR (50),
	 sourceIP VARCHAR(50),
	 insertDateTime DATETIME, 
	 signoutDateTime DATETIME, 
	 
 	/* these fields are calculated */
	 insertDateTimePT DATETIME, 
	 signoutDateTimePT DATETIME, 
	 sessionLength TIME, 
	 sessionActionCount INT,
	 sessionErrorCount INT,
	 browser VARCHAR(50),
	 browserBucket VARCHAR(50),
	 operatingSystem VARCHAR(50),
	 device VARCHAR(50),
	 userAgent VARCHAR(255),
	 index (userID),
	 INDEX (insertDateTime),
	 PRIMARY KEY(sessionLogID));

/*When adding new terms to BrowserName, BroswerBucket or BrowserDevice fucntions, TRUNCATE TABLE and so that it will fill with all new data from arc_sessionLog*/

/* find starting point for new users */
 SELECT MAX(sessionLogID) FROM rpt_main_02.rpt_sessionLog  INTO @maxSessionLogID;  /*Appends rpt_sessionLog with new data from arc_sessionLog, a longer repository than ss_core_02.sessionLog*/
 
 /* for startup case, if null convert to 0 */
 SELECT IF (@maxSessionLogID IS NULL, 0, @maxSessionLogID) INTO @maxSessionLogID;
 
 SET AUTOCOMMIT = 0;
 INSERT rpt_main_02.rpt_sessionLog(
	 sessionLogID, 
	 userID, 
	 emailAddress, 
	 loginType, 
 	loginAuthResult, 
	 sourceIP, 
	 insertDateTime, 
	 signoutDateTime, 
	 insertDateTimePT, 
	 signoutDateTimePT, 
	 sessionLength, 
	 sessionActionCount, 
	 sessionErrorCount, 
	 browser, 
	 browserBucket, 
	 operatingSystem, 
	 device, 
	 userAgent)
 SELECT sessionLog.sessionLogID,
	 sessionLog.userID,
	 sessionLog.emailAddress,
	 rpt_main_02.SMARTSHEET_LOGINTYPENAME(sessionLog.loginType) AS "loginType",
	 rpt_main_02.SMARTSHEET_AUTHRESULT(sessionLog.loginAuthResult) AS "loginAuthResult",
	 sessionLog.sourceIP,
	 sessionLog.insertDateTime,
	 sessionLog.signoutDateTime,
 
	 ADDTIME(sessionLog.insertDateTime, '-7:00:00'),
	 ADDTIME(sessionLog.signOutDateTime, '-7:00:00'),
	 CASE sessionLog.signOutDateTime IS NULL
	 	WHEN 0 THEN SEC_TO_TIME(UNIX_TIMESTAMP(sessionLog.signOutDateTime) - UNIX_TIMESTAMP(sessionLog.insertDateTime))
	 	ELSE NULL
	 END,
	 0, /*(select count(*) from ss_log_02.requestLog rl where formAction = 'gl' and rl.sessionLogID = sessionLog.sessionLogID), */
	 0, /*(select count(*) from ss_log_02.requestLog rl where formAction = 'gl' and rl.sessionLogID = sessionLog.sessionLogID
														and rl.parm3 like 'js_stack_trace%'),  */
   rpt_main_02.SMARTSHEET_BROWSERNAME(sessionLog.userAgent) AS "Browser",
   rpt_main_02.SMARTSHEET_BROWSERBUCKET(sessionLog.userAgent) AS "Browser Bucket",
   rpt_main_02.SMARTSHEET_BROWSEROS(sessionLog.userAgent) AS "Operating System",
   rpt_main_02.SMARTSHEET_BROWSERDEVICE(sessionLog.userAgent) AS "Device",
	 userAgent
        
 FROM rpt_main_02.arc_sessionLog sessionLog
 WHERE sessionLogID > @maxSessionLogID
 ;
 COMMIT;
 SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_sessionLog");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_loginCountTotal table - start ******** ", NOW();

/*Start rpt_main_02.rpt_loginCountTotal*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_loginCountTotal insert");

SELECT MAX(sessionLogID) FROM rpt_main_02.rpt_nativeAppSessions INTO @maxMobile;

INSERT IGNORE INTO rpt_main_02.rpt_nativeAppSessions
SELECT * FROM rpt_main_02.rpt_sessionLog
WHERE browserBucket IN('Native iOS App', 'Native Android App') AND loginAuthResult = 'SUCCESS'
AND sessionLogID > @maxMobile;


SELECT MAX(modifyDateTime) FROM rpt_main_02.userAccount INTO @maxModifyDateTime;

DROP TABLE IF EXISTS rpt_main_02.rpt_loginCountTotal;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_loginCountTotal(
	userID 	BIGINT, 
	firstSessionLogID INT, 
	firstLogin DATETIME, 
	firstLoginYear INT, 
	firstLoginMonth VARCHAR(12), 
	firstLoginWeek VARCHAR(10), 	
	firstLoginDay VARCHAR(10), 
	lastSessionLogID INT,
	lastLogin DATETIME, 	
	lastLoginYear INT, 
	lastLoginMonth VARCHAR(12), 
	lastLoginWeek VARCHAR(10), 	
	lastLoginDay VARCHAR(10), 
	daysSinceFirstLogin INT, 
	daysSinceLastLogin INT, 
	daysActive INT, 
	loginCount INT, 
	loginStrength NUMERIC(38,18), 
	userLoggedInAtLeastOnce TINYINT, 
	userLoggedInAtLeastTwice TINYINT, 
	userLoggedInAtLeast4times TINYINT, 
	userLoggedInAtLeast8times TINYINT,
	lastMobileLogin DATETIME,
	nativeIosSessionCount INT,
	nativeAndroidSessionCount INT,
	PRIMARY KEY(userID));

INSERT rpt_main_02.rpt_loginCountTotal(
	userID, 
	firstSessionLogID, 
	firstLogin, 
	firstLoginYear,
	firstLoginMonth, 
	firstLoginWeek, 
	firstLoginDay,
	lastSessionLogID,
	lastLogin, 
	lastLoginYear,
	lastLoginMonth, 
	lastLoginWeek, 
	lastLoginDay,	
	daysSinceFirstLogin, 
	daysSinceLastLogin, 
	daysActive,
	loginCount, 
	loginStrength,
	userLoggedInAtLeastOnce,
	userLoggedInAtLeastTwice,
	userLoggedInAtLeast4times,
	userLoggedInAtLeast8times)

SELECT 
	usa.userID, 
	usa.firstSessionID, 
	
	usa.firstSessionDateTime, 
	DATE_FORMAT(usa.firstSessionDateTime, '%Y'), 
	DATE_FORMAT(usa.firstSessionDateTime, '%Y*%m(%b)'),
	rpt_main_02.SMARTSHEET_WEEK(usa.firstSessionDateTime), 
	CONCAT(DATE_FORMAT(usa.firstSessionDateTime , '%Y'), "*", 
	       LPAD(MONTH(usa.firstSessionDateTime),2,"0"), "*", 
	       LPAD(DAYOFMONTH(usa.firstSessionDateTime),2,"0")), 
	
	usa.lastSessionID,	       
	usa.lastSessionDateTime,
	DATE_FORMAT(usa.lastSessionDateTime, '%Y'), 
	DATE_FORMAT(usa.lastSessionDateTime, '%Y*%m(%b)'),
	rpt_main_02.SMARTSHEET_WEEK(usa.lastSessionDateTime), 
	CONCAT(DATE_FORMAT(usa.lastSessionDateTime , '%Y'), "*", 
	       LPAD(MONTH(usa.lastSessionDateTime),2,"0"), "*", 
	       LPAD(DAYOFMONTH(usa.lastSessionDateTime),2,"0")), 
	       	
	DATEDIFF(CURRENT_DATE(), usa.firstSessionDateTime),
	DATEDIFF(CURRENT_DATE(), usa.lastSessionDateTime),
	DATEDIFF(usa.lastSessionDateTime, usa.firstSessionDateTime),
	
	usa.sessionCount, 
	usa.sessionCount / (DATEDIFF(@maxModifyDateTime, usa.lastSessionDateTime) + 3),

	CASE usa.sessionCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 2 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END,

	CASE usa.sessionCount >= 8 
		WHEN 1 THEN 1
		ELSE 0
	END

FROM rpt_main_02.arc_userSessionActivity usa
;


DROP TABLE IF EXISTS rpt_main_02.stg_mobileAppLoginCounts;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_mobileAppLoginCounts
(userID BIGINT,
browserBucket VARCHAR(50),
lastLogin DATETIME,
sessionCount INT,
PRIMARY KEY (userID, browserBucket),
KEY userID (userID),
KEY lastLogin (lastLogin));


INSERT INTO rpt_main_02.stg_mobileAppLoginCounts
SELECT userID, browserBucket, MAX(sl.insertDateTime) AS 'lastMobileLogin', COUNT(sl.sessionLogID) AS 'SessionCount'
FROM rpt_main_02.rpt_nativeAppSessions sl
GROUP BY 1,2
;

DROP TABLE IF EXISTS rpt_main_02.stg_mobileAppMaxDates;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_mobileAppMaxDates
(userID BIGINT,
maxMobileLogin DATETIME,
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_mobileAppMaxDates
SELECT userID, MAX(lastLogin)
FROM rpt_main_02.stg_mobileAppLoginCounts
GROUP BY 1;


UPDATE rpt_main_02.rpt_loginCountTotal A
JOIN rpt_main_02.stg_mobileAppLoginCounts B ON A.userID = B.userID AND B.browserBucket = 'Native iOS App'
SET A.nativeIosSessionCount = B.sessionCount;

UPDATE rpt_main_02.rpt_loginCountTotal A
JOIN rpt_main_02.stg_mobileAppLoginCounts B ON A.userID = B.userID AND B.browserBucket = 'Native Android App'
SET A.nativeAndroidSessionCount = B.sessionCount;


UPDATE rpt_main_02.rpt_loginCountTotal A
JOIN rpt_main_02.stg_mobileAppMaxDates B ON A.userID = B.userID
SET A.lastMobileLogin = B.maxMobileLogin;

DROP TABLE IF EXISTS rpt_main_02.stg_mobileAppLoginCounts;
DROP TABLE IF EXISTS rpt_main_02.stg_mobileAppMaxDates;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_loginCountTotal insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_loginCountTotal update");

/* Update lastLoginUserDate for a payment profile - we use the user's last login for standard accounts and the last login for all users in an org */
/* Update lastLoginUserDate for a payment profile - we use the user's last login for standard accounts and the last login for all users in an org */
SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.rpt_loginCountTotal lc ON rp.sourceUserID = lc.userID
SET lastUserLoginDate = lc.lastLogin WHERE rp.accountType != 3
;
COMMIT;


UPDATE rpt_main_02.rpt_paymentProfile rp
SET rp.lastUserLoginDate =
 (SELECT MAX(lc.lastLogin) 
	FROM rpt_main_02.rpt_loginCountTotal lc
	  JOIN rpt_main_02.rpt_paymentProfileContact cp ON lc.userID = cp.userID
	WHERE rp.paymentProfileID = cp.parentPaymentProfileID)
WHERE rp.accountType = 3
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_loginCountTotal update");

select "******************************************************************************************************************************", NOW();
select "******** arc_ISPDomains table - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_ISPDomains");

SET AUTOCOMMIT = 0;
INSERT IGNORE rpt_main_02.arc_ISPDomains(domain, userCount)
SELECT domain, COUNT(userID)
FROM rpt_main_02.userAccount

/*Continue regular check of domains in userAccount to see if new domains need to be added*/
WHERE userAccount.domain LIKE '%yahoo.%'
OR userAccount.domain LIKE '%yahoogroup%'
OR userAccount.domain LIKE '%yahoogrupos%'
OR userAccount.domain LIKE '%gmail.com%'
OR userAccount.domain LIKE '%yahoomail.%'
OR userAccount.domain LIKE 'live.%'
OR userAccount.domain LIKE 'hotmail.%'
OR userAccount.domain LIKE 'aol.co%'
OR userAccount.domain LIKE '%.rr.com'
OR userAccount.domain LIKE '%.net.il'
OR userAccount.domain LIKE '%comcast.net%'
OR userAccount.domain LIKE 'outlook.__'  
OR domain LIKE 'outlook.___'
OR domain LIKE 'outlook.__.__' 
OR domain LIKE 'outlook.___.__'
OR domain like 'dodo.com%'
OR userAccount.domain IN (
'10gen.com',
'123.com',
'126.com',
'139.com',
'163.com',
'aim.com',
'abv.bg',
'adinet.com.uy',
'alice.it',
'Aol.com', 
'absamail.co.za',
'att.net',
'bellsouth.net',
'bell.net',
'bex.net',
'bigpond.com',
'bigpond.net.au',
'bigpond.com.au',
'bluewin.ch',
'bk.ru',
'blueyonder.co.uk',
'bol.com.br',
'btconnect.com',
'btinternet.com',
'btopenworld.com',
'charter.net',
'comcast.net', 
'cox.net',
'earthlink.net',
'eircom.net',
'embarqmail.com',
'free.fr',
'globo.com',
'gmail.com',
'gmail.co',
'gamil.com',
'gmial.com',
'gmai.com',
'gmx.de',
'googlemail.com', 
'hanmail.net',
'hotmail.co.uk', 
'hotmail.com', 
'hotmail.es', 
'hotmail.fr', 
'hotmai.com',
'homail.com',
'hotmil.com',
'hotmal.com',
'hushmail.com',
'iafrica.com',
'ibest.com.br',
'icloud.com',
'ig.com.br',
'iinet.net.au',
'inbox.ru',
'juno.com',
'juno.com',
'laposte.net',
'libero.it',
'live.co.uk',
'live.com', 
'mac.com',
'mail.com',
'mail.ru',
'me.com',
'me.com',
'msn.com', 
'mweb.co.za',
'mymts.net',
'naver.com',
'northrock.bm',
'ntlworld.com',
'oi.com.br',
'optonline.net',
'optusnet.com.au',
'orange.fr',
'outlook.com',
'pobox.com',
'prodigy.net.mx',
'qq.com',
'reagan.com',
'rediffmail.com',
'roadrunner.com',
'rocketmail.com',
'rogers.com',
'sapo.pt',
'sbcglobal.net', 
'sfr.fr',
'shaw.ca',
'sky.com',
'sympatico.ca',
'talktalk.net',
'teksavvy.com',
'telus.net',
'terra.com.br',
'tiscali.co.uk',
'toast.net',
'uol.com.br',
'verizon.net', 
'videotron.ca',
'wanadoo.fr',
'web.de',
'westnet.com.au',
'xtra.co.nz',
'yandex.ru',
'ymail.com',
'zippy-uk.com',
'zippy-au.com',
'zippy-nz.com',
'cableone.net',
'cantv.net',
'centurylink.net',
'centurytel.net',
'clear.net.nz',
'cogeco.ca',
'csas.cz',
'eastlink.ca',
'email.com',
'etherstorm.net', 
'excite.com',
'fastmail.fm',
'foxmail.com',
'freemail.hu',
'freenet.de',
'frontier.com',
'frontiernet.net',
'fsmail.net',
'globomail.com',
'gmx.com',
'gmx.net',
'in.com',
'inbox.com',
'inbox.lv',
'insightbb.com',
'internode.on.net',
'iol.pt',
'iprimus.com.au',
'klarna.com',
'latinmail.com',
'mailinator.com',
'mindspring.com',
'nate.com',
'netscape.net',
'netspace.net.au',
'netzero.com',
'netzero.net',
'ziggo.nl',
'o2.co.uk',
'o2.pl',
'outlook.es',
'ozemail.com.au',
'pacbell.net',
'prodigy.net',
'q.com',
'r7.com',
'rambler.ru',
'rmqkr.net',
'sasktel.net',
'seznam.cz',
'sharklasers.com',
'suddenlink.net',
'talk21.com',
'tds.net',
'telefonica.net',
'telenet.be',
'telkomsa.net',
'tiscali.it',
'tpg.com.au',
'trbvm.com',
'usa.net',
'virgin.net',
'virginmedia.com',
'vodamail.co.za',
'voila.fr',
'vtr.net',
'walla.com',
'webmail.co.za',
'windowslive.com',
'windstream.net',
'wp.pl',
'y7mail.com',
'ya.ru',
'yopmail.com',
'mynet.com',
'consultant.com',
'yandex.com',
'qualityservice.com',
'pisem.net',
'mail333.com',
'photofile.ru',
'consultan',
'financier.com',
'europe.com',
'yeah.net',
'gmx.co.uk',
'vp.pl',
'myway.com',
'krovatka.su',
'post.cz',
'mail15.com',
'nightmail.ru',
'diplomats.com',
'op.pl',
'post.com',
'spoko.pl',
'memori.ru',
'pochtamt.ru',
'engineer.com',
'hafnet.dk',
'stofanet.dk',
'qip.ru',
'dcemail.com',
'tutanota.com',
'ziza.ru',
'counsellor.com',
'barid.com',
'fotoplenka.ru',
'secretary.net',
'kimo.com',
'accountant.com',
'e-mile.co.uk',
'rbcmail.ru',
'fromru.com',
'africamail.com',
'numericable.fr',
'lycos.com',
'consult',
'pochta.com',
'usa.com',
'mail2usa.com',
'uymail.com',
'fastservice.com',
'walla.co.il',
'planetmail.com',
'legislator.com',
'insurer.com',
'sina.cn',
'sina.com',
'sina.com.cn')

GROUP BY 1;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_ISPDomains");

select "******************************************************************************************************************************", NOW();
select "******** rpt_userIPLocation table - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_userIPLocation");


CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_userIPLocation
(
	userID INT,
	ipType VARCHAR(50),
	ipNumber VARCHAR(50),
	ipCountry VARCHAR(200),
	ipRegion VARCHAR(200),
	ipCity VARCHAR(200),
	PRIMARY KEY (userID),
	KEY ix_ipCountry (ipCountry),
	KEY ix_ipRegion (ipRegion),
	KEY ix_ipCity (ipCity),
	KEY ix_ipType (ipType)
)
;


-- Add users to IP table

SELECT MAX(userID) INTO @maxUserID FROM rpt_main_02.rpt_userIPLocation;

SET AUTOCOMMIT = 0;
INSERT INTO rpt_main_02.rpt_userIPLocation (userID)
SELECT DISTINCT ua.userID
FROM rpt_main_02.userAccount ua
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ins ON ua.userID=ins.userID
WHERE ins.userID IS NULL
AND ua.userID >= @maxUserID
ORDER BY userID
;
COMMIT;


-- Add userIP addresses from signup source
UPDATE rpt_main_02.rpt_userIPLocation uic
JOIN rpt_main_02.rpt_signupSource ss ON uic.userID=ss.userID
SET 
	uic.ipType = 'Signup Source',
	uic.ipNumber  = ss.ipAddress,
	uic.ipCountry = ss.IPCountry,
	uic.ipRegion = ss.IPRegion,
	uic.ipCity = ss.IPCity
WHERE uic.ipCountry IS NULL
;
COMMIT;


-- Add userIP addresses from first sessions

UPDATE rpt_main_02.rpt_userIPLocation uic2
JOIN rpt_main_02.rpt_loginCountTotal lct ON uic2.userID = lct.userID
JOIN rpt_main_02.rpt_userIPLocation uic ON lct.userID=uic.userID AND uic.ipCountry IS NULL
JOIN rpt_main_02.arc_sessionLog sl ON lct.firstSessionLogID=sl.sessionLogID AND sl.sourceIP IS NOT NULL
JOIN rpt_main_02.ref_ipAddressInfo ref ON sl.sourceIP=ref.ipAddress
SET 
	uic2.ipType = 'First Session',
	uic2.ipNumber = sl.sourceIP,
	uic2.ipCountry = ref.countryName,
	uic2.ipRegion = ref.regionName,
	uic2.ipCity = ref.city
WHERE uic2.ipCountry IS NULL
;
COMMIT;
SET AUTOCOMMIT = 1;


-- Add userIP addresses from last sessions
DROP TABLE IF EXISTS rpt_main_02.stg_users_no_ip_country;

CREATE TABLE rpt_main_02.stg_users_no_ip_country LIKE rpt_main_02.rpt_userIPLocation;

INSERT INTO rpt_main_02.stg_users_no_ip_country
SELECT *
FROM rpt_main_02.rpt_userIPLocation
WHERE ipCountry IS NULL
;

-- ALTER TABLE rpt_main_02.stg_users_no_ip_country ADD PRIMARY KEY (userID);

DROP TABLE IF EXISTS rpt_main_02.stg_users_noIP_lastSession;

CREATE TABLE rpt_main_02.stg_users_noIP_lastSession (userID bigint, maxSessionLogID bigint);

INSERT INTO rpt_main_02.stg_users_noIP_lastSession (userID, maxSessionLogID)
SELECT np.userID, lct.lastSessionLogID maxSessionLogID
FROM rpt_main_02.stg_users_no_ip_country np
JOIN rpt_main_02.rpt_loginCountTotal lct ON np.userID=lct.userID
GROUP BY 1
;

ALTER TABLE rpt_main_02.stg_users_noIP_lastSession ADD PRIMARY KEY (userID);

SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_userIPLocation uic2
JOIN rpt_main_02.stg_users_noIP_lastSession ms ON ms.userID = uic2.userID
JOIN rpt_main_02.arc_sessionLog asl ON asl.userID=ms.userID AND asl.sessionLogID=ms.maxSessionLogID
JOIN rpt_main_02.ref_ipAddressInfo ref ON asl.sourceIP=ref.ipAddress
SET 
	uic2.ipType = 'Last Session',
	uic2.ipNumber = asl.sourceIP,
	uic2.ipCountry = ref.countryName,
	uic2.ipRegion = ref.regionName,
	uic2.ipCity = ref.city
WHERE uic2.ipCountry IS NULL
;
COMMIT;

-- Remove users with no IP type or no IP number
DELETE FROM rpt_main_02.rpt_userIPLocation WHERE ipType IS NULL;
COMMIT;
DELETE FROM rpt_main_02.rpt_userIPLocation WHERE ipNumber IS NULL;
COMMIT;
SET AUTOCOMMIT = 1;

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_userIPLocation UPDATE");

/*Create Table of NULL IPCountry users*/
CREATE TABLE rpt_main_02.stg_userIPLocationUpdate (userID bigint);
INSERT INTO rpt_main_02.stg_userIPLocationUpdate (userID)
SELECT userAccount.userID
FROM rpt_main_02.userAccount
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON userAccount.userID = rpt_userIPLocation.userID
WHERE ipNumber IS NULL; 

/*Insert those with a signup*/
INSERT rpt_main_02.rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
rpt_signupSource.userID, 
'Signup Source',
ipAddress, 
IPCountry, 
IPRegion, 
IPCity
FROM rpt_main_02.rpt_signupSource
JOIN rpt_main_02.stg_userIPLocationUpdate ON rpt_signupSource.userID = stg_userIPLocationUpdate.userID
WHERE ipCountry IS NOT NULL;

/*Insert those with a firstSession*/
INSERT rpt_main_02.rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
stg_userIPLocationUpdate.userID, 'First Session', sl.sourceIP, ref.countryName, ref.regionName, ref.city
FROM rpt_main_02.rpt_loginCountTotal lct 
JOIN rpt_main_02.stg_userIPLocationUpdate ON lct.userID = stg_userIPLocationUpdate.userID
LEFT OUTER JOIN rpt_main_02.arc_sessionLog sl ON lct.firstSessionLogID = sl.sessionLogID
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref ON sl.sourceIP = ref.ipAddress
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation uic ON stg_userIPLocationUpdate.userID = uic.userID

WHERE uic.ipNumber IS NULL
AND sl.sourceIP IS NOT NULL
AND ref.countryName IS NOT NULL;

/*Insert those with a lastSession*/
INSERT rpt_main_02.rpt_userIPLocation
(userID, ipType, ipNumber, ipCountry, ipRegion, ipCity)
SELECT 
stg_userIPLocationUpdate.userID, 'Last Session', sl.sourceIP, ref.countryName, ref.regionName, ref.city
FROM rpt_main_02.rpt_loginCountTotal lct 
JOIN rpt_main_02.stg_userIPLocationUpdate ON lct.userID = stg_userIPLocationUpdate.userID
LEFT OUTER JOIN rpt_main_02.arc_sessionLog sl ON lct.lastSessionLogID = sl.sessionLogID
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref ON sl.sourceIP = ref.ipAddress
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation uic ON stg_userIPLocationUpdate.userID = uic.userID

WHERE uic.ipNumber IS NULL
AND sl.sourceIP IS NOT NULL
AND ref.countryName IS NOT NULL;

DROP TABLE rpt_main_02.stg_userIPLocationUpdate;


/*Fix values for users that signed up during the Jan-Mar 2015 IP Outage Window*/
UPDATE rpt_main_02.rpt_userIPLocation ip
JOIN rpt_main_02.rpt_loginCountTotal lct ON ip.userID=lct.userID
LEFT OUTER JOIN rpt_main_02.arc_sessionLog sl ON lct.lastSessionLogID=sl.sessionLogID
LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref ON sl.sourceIP=ref.ipAddress
SET 
	ip.ipNumber = sl.sourceIP, 
	ip.ipCountry = ref.countryName, 
	ip.ipRegion = ref.regionName, 
	ip.ipCity = ref.city
WHERE ipType = 'January IP Outage'
AND ip.ipCountry IS NULL
;


CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_userIPLocation UPDATE");

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_userIPLocation");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.arc_paidAccountTransfers ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_paidAccountTransfers");

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_paidAccountTransfers
(
	requestLogID bigint,
	transferDate datetime,
	transferStatus varchar(100),
	transferFromUserID bigint,
	transferToUserID bigint,
	transferType varchar(100),
	insertbyuserID int(15),
	sessionLogID bigint,
	primary key ix_requestLogID (requestLogID),
	key ix_transferDate (transferDate),
	key ix_userID (transferFromUserID),
	key ix_TransferToUserID (transferToUserID)
)
;


SELECT MAX(requestLogID) FROM rpt_main_02.arc_paidAccountTransfers INTO @maxTransferID;

INSERT INTO rpt_main_02.arc_paidAccountTransfers (requestLogID, transferDate, transferStatus, transferFromUserID, transferToUserID, transferType, insertByUserID, sessionLogID)
SELECT 
requestLog.requestLogID,
requestLog.insertDateTime AS TransferDate,
requestLog.parm4 AS TransferStatus,
FROMUSER.userID AS FromUserID,
TOUSER.userID AS ToUserID,
requestLog.parm3 AS TransferType,
requestLog.insertByUserID,
requestLog.sessionlogID
FROM rpt_main_02.arc_requestLog requestLog
LEFT OUTER JOIN rpt_main_02.userAccount FROMUSER ON FROMUSER.userID = requestLog.parm1
LEFT OUTER JOIN rpt_main_02.userAccount TOUSER ON TOUSER.userID = requestLog.parm2
WHERE requestLog.parm3 LIKE 'TRANSFER_PAID_ACCOUNT:%' 
-- and requestLog.parm4 = 'true' currently including both successful and failed attempts. This line would only take Successful attempts
AND requestLog.requestLogID > @maxTransferID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_paidAccountTransfers");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.arc_paymentProfile_firstWinProduct ******** ", NOW();
/*This table contains the productID, paymentTerm, and paymentType of paymentProfiles for the 1st time they become a Win*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_paymentProfile_firstWinProduct");

DROP TABLE IF EXISTS rpt_main_02.arc_paymentProfile_firstWinProduct;

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_paymentProfile_firstWinProduct
(
	paymentProfileID BIGINT,
	sourceUserID BIGINT,
	productID INT,
	paymentTerm INT,
	paymentType INT,
	planRate_USD DECIMAL (38,10),
	currencyCode VARCHAR(5),
	exchangeRate DECIMAL (38,10),
	winDate DATETIME,
	userLimit INT,
	PRIMARY KEY (paymentProfileID),
	KEY ix_sourceUserID (sourceUserID)
)
;

DROP TABLE IF EXISTS rpt_main_02.stg_minWinProduct;

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_minWinProduct
(
	paymentProfileID BIGINT,
	sourceUserID BIGINT,
	minModifyDateTime DATETIME,
	PRIMARY KEY (paymentProfileID),
		KEY ix_sourceUser (sourceUserID),
        KEY ix_mdt (minModifyDateTime)
)
;

INSERT INTO rpt_main_02.stg_minWinProduct (paymentProfileId, sourceUserID, minModifyDateTime)
SELECT hpp.paymentProfileID, pp.sourceUserID, MIN(hpp.modifyDateTime) AS minModifyDateTime
FROM rpt_main_02.hist_paymentProfile hpp
LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON hpp.paymentProfileID=pp.paymentProfileID
WHERE hpp.productID >=3
AND hpp.paymentType IN(1,2,3,6,8,10)
AND hpp.planRate > 0
GROUP BY 1,2
;


INSERT IGNORE rpt_main_02.arc_paymentProfile_firstWinProduct
SELECT 
hpp.paymentProfileID, 
mwp.sourceUserID, 
hpp.productID, 
hpp.paymentTerm, 
hpp.paymentType, 
hpp.planRate_USD, 
hpp.currencyCode, 
hce.exchangeRate, 
mwp.minModifyDateTime,
hpp.userLimit
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.stg_minWinProduct mwp ON hpp.paymentProfileID=mwp.paymentProfileID 
	AND hpp.modifyDateTime=mwp.minModifyDateTime
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON hpp.currencyCode=hce.currencyCode COLLATE utf8mb4_unicode_520_ci
	AND hpp.modifyDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE hpp.productID >= 3
AND hpp.planRate > 0
AND hpp.paymentType IN(1,2,3,6,8,10)
AND hpp.hist_effectiveThruDateTime <= '9999-12-31 23:59:59'
;



DROP TABLE IF EXISTS rpt_main_02.stg_minWinProduct;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_paymentProfile_firstWinProduct");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** End of Throwaway Part 1: Bookings ******** ", NOW();
set session transaction isolation level repeatable read;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Throwaway Part 1: Bookings");
CALL rpt_main_02.utl_logProcessEnd(@processId);