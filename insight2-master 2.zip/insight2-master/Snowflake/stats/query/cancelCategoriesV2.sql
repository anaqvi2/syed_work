SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("cancelCategoriesV2.csv");

#Initialize
SET @@sql_mode = '';
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @ch_cancelMaxModifyDateTime = (SELECT MAX(cancelledDateTime) FROM rpt_workspace.ch_cancelCategories);


#INSERT 1 : Licensed Users who have stopped re-occuring payment
#14906 inserts
INSERT IGNORE INTO rpt_workspace.ch_cancelCategories (paymentProfileID, cancelProductName, cancelARR, planStartDate, modifyByUserID, futureLoss, cancelledDateTime, paymentTerm)
SELECT hpp.paymentProfileID, rpt_main_02.SMARTSHEET_PRODUCTNAME(old.productID), (old.planRate_USD/old.paymentTerm)*12, old.paymentStartDateTime, hpp.modifyByUserID, 
	CASE WHEN old.paymentFlags & 16 THEN 1 ELSE 0 END, CASE WHEN old.paymentFlags & 16 THEN old.modifyDateTime ELSE hpp.modifyDateTime END, old.paymentTerm
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.hist_paymentProfile old 
	ON old.hist_effectiveThruDateTime = hpp.modifyDateTime 
    AND hpp.paymentProfileID = old.paymentProfileID  
    AND old.accountType !=2
WHERE hpp.productID IN (3,4,5,6,7,8,10,11)
	AND hpp.modifyDateTime > @ch_cancelMaxModifyDateTime
	AND hpp.accountType !=2
	AND (hpp.paymentFlags & 16)
;

#INSERT 2 : Licensed Users who have cancelled
#41513 inserts
INSERT IGNORE INTO rpt_workspace.ch_cancelCategories (paymentProfileID,  cancelProductName, cancelARR, planStartDate, modifyByUserID, futureLoss, cancelledDateTime, paymentTerm)
SELECT hpp.paymentProfileID,  rpt_main_02.SMARTSHEET_PRODUCTNAME(old.productID), (old.planRate_USD/old.paymentTerm)*12, old.paymentStartDateTime, hpp.modifyByUserID, 
	CASE WHEN old.paymentFlags & 16 THEN 1 ELSE 0 END, CASE WHEN old.paymentFlags & 16 THEN old.modifyDateTime ELSE hpp.modifyDateTime END, old.paymentTerm
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.hist_paymentProfile old 
	ON old.hist_effectiveThruDateTime = hpp.modifyDateTime 
    AND hpp.paymentProfileID = old.paymentProfileID 
    AND old.productID > 2 
    AND old.accountType !=2
WHERE hpp.productID=0
    AND hpp.modifyDateTime > @ch_cancelMaxModifyDateTime
	AND hpp.accountType !=2
;

#INSERT 3 : Trials who have cancelled
#149612 inserts
INSERT IGNORE INTO rpt_workspace.ch_cancelCategories (paymentProfileID, cancelProductName, cancelARR, planStartDate, modifyByUserID, futureLoss, cancelledDateTime, paymentTerm)
SELECT hpp.paymentProfileID, rpt_main_02.SMARTSHEET_PRODUCTNAME(old.productID), (old.planRate_USD/old.paymentTerm)*12, old.paymentStartDateTime, hpp.modifyByUserID, 
	CASE WHEN old.paymentFlags & 16 THEN 1 ELSE 0 END, CASE WHEN old.paymentFlags & 16 THEN old.modifyDateTime ELSE hpp.modifyDateTime END, old.paymentTerm
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.hist_paymentProfile old 
	ON old.hist_effectiveThruDateTime = hpp.modifyDateTime 
    AND hpp.paymentProfileID = old.paymentProfileID 
    AND old.productID=1 
    AND old.accountType !=2
WHERE hpp.productID=0
	AND hpp.modifyDateTime > @ch_cancelMaxModifyDateTime
	AND hpp.accountType !=2
;

#INSERT 4 : Cancelled / Free users that have super cancelled their account
#21610 inserts
INSERT IGNORE INTO rpt_workspace.ch_cancelCategories (paymentProfileID, cancelProductName, cancelARR, planStartDate, modifyByUserID, futureLoss, cancelledDateTime, paymentTerm)
SELECT hpp.paymentProfileID, rpt_main_02.SMARTSHEET_PRODUCTNAME(old.productID), (old.planRate_USD/old.paymentTerm)*12, old.paymentStartDateTime, hpp.modifyByUserID, 
	CASE WHEN old.paymentFlags & 16 THEN 1 ELSE 0 END, CASE WHEN old.paymentFlags & 16 THEN old.modifyDateTime ELSE hpp.modifyDateTime END, old.paymentTerm
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.hist_paymentProfile old 
	ON old.hist_effectiveThruDateTime = hpp.modifyDateTime 
    AND hpp.paymentProfileID = old.paymentProfileID 
    AND old.productID IN (0,2) AND old.accountType =1
WHERE hpp.productID = 0
	AND hpp.modifyDateTime > @ch_cancelMaxModifyDateTime
	AND hpp.accountType = 1
;

#INSERT 5 : Users to never exist in payment profile that cancelled their account
#157 inserts
INSERT IGNORE INTO rpt_workspace.ch_cancelCategories (paymentProfileID, cancelProductName, cancelARR, planStartDate, modifyByUserID, futureLoss, cancelledDateTime, paymentTerm)
SELECT hpp.paymentProfileID, rpt_main_02.SMARTSHEET_PRODUCTNAME(old.productID), (old.planRate_USD/old.paymentTerm)*12, old.paymentStartDateTime, hpp.modifyByUserID, 
	CASE WHEN old.paymentFlags & 16 THEN 1 ELSE 0 END, CASE WHEN old.paymentFlags & 16 THEN old.modifyDateTime ELSE hpp.modifyDateTime END, old.paymentTerm
FROM rpt_main_02.hist_paymentProfile hpp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile old 
	ON old.hist_effectiveThruDateTime = hpp.modifyDateTime
    AND hpp.paymentProfileID = old.paymentProfileID
    AND old.accountType !=2
WHERE hpp.productID = 0
	AND hpp.modifyDateTime > @ch_cancelMaxModifyDateTime
	AND hpp.accountType !=2
	AND hpp.insertDateTime = hpp.modifyDateTime
	AND old.paymentProfileID IS NULL
;

#areas where old.cancelled date time before categories implemented (future loss cancelledDateTime prior to Aug 2016)
DELETE FROM  rpt_workspace.ch_cancelCategories WHERE cancelledDateTime <'2011-06-01 00:00:00'; 

UPDATE rpt_workspace.ch_cancelCategories ch
JOIN rpt_main_02.rpt_paymentProfile pp 
	ON pp.paymentprofileID = ch.paymentProfileID 
	AND pp.accountType !=2
SET ch.domain = pp.mainContactDomain,
ch.mainContactUserID = pp.mainContactUserID,
ch.sourceUserID = pp.sourceUserID
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories ch
JOIN rpt_main_02.rpt_paymentProfile pp 
    ON pp.paymentprofileID = ch.paymentProfileID 
    AND pp.accountType !=3
SET ch.userID = pp.mainContactUserID
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories  ch
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains d 
    ON d.domain = ch.domain
SET ch.isOrgDomain = CASE WHEN d.domain IS NULL THEN 1 ELSE 0 END
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

#worm of plan source user
UPDATE rpt_workspace.ch_cancelCategories ch
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ss 
	ON ss.userID = ch.sourceUserID
SET ch.bucket = CASE WHEN ss.bucket IS NOT NULL THEN ss.bucket ELSE "Viral" END,
ch.sourceFriendly = CASE WHEN ss.sourceFriendly IS NOT NULL THEN ss.sourceFriendly ELSE "Sharing" END,
ch.subSourceFriendly = CASE WHEN ss.subSourceFriendly IS NOT NULL THEN ss.subSourceFriendly ELSE "Sharing" END,
ch.campaign = ss.campaign
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

#First join on event timestamp
UPDATE rpt_workspace.ch_cancelCategories ch -- 53k matches
JOIN rpt_main_02.rpt_cancelComment cc 
	ON cc.userID = ch.modifyByUserID 
    AND cc.cancelCommentDate = cancelledDateTime 
    AND cc.cancelCommentDate>'2016-08-07'
SET ch.cancelCommentDate = cc.cancelCommentDate,
ch.cancelCategory = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',2),'"',-1),
ch.otherReasonComment = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',4),'"',-1),
ch.cancelComment = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',6),'"',-1);

#Now allow 3 second buffer
UPDATE rpt_workspace.ch_cancelCategories ch -- 6,256 matches
JOIN rpt_main_02.rpt_cancelComment cc 
	ON cc.userID = ch.modifyByUserID 
    AND cc.cancelCommentDate BETWEEN ch.cancelledDateTime AND DATE_ADD(ch.cancelledDateTime, INTERVAL 3 SECOND)
    AND cc.cancelCommentDate>'2016-08-07'
SET ch.cancelCommentDate = cc.cancelCommentDate,
ch.cancelCategory = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',2),'"',-1),
ch.otherReasonComment = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',4),'"',-1),
ch.cancelComment = SUBSTRING_INDEX(SUBSTRING_INDEX(cc.cancelComment,'"',6),'"',-1)
WHERE ch.cancelCommentDate IS NULL;

UPDATE rpt_workspace.ch_cancelCategories ch
JOIN rpt_main_02.rpt_userIPLocation ip 
    ON ip.userID = ch.mainContactUserID 
JOIN rpt_main_02.userAccount ua 
	ON ua.userID = ch.mainContactUserID
SET ch.Country = ip.ipCountry,
ch.languageFriendly = ua.languageFriendly
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories ch
SET minModifyDateTime = 
	(SELECT MIN(modifyDateTime)
		FROM rpt_main_02.hist_paymentProfile hpp
	WHERE hpp.paymentProfileID = ch.paymentProfileID 
	AND hpp.paymentStartDateTime = ch.planStartDate 
	AND hpp.accountType !=2 
	AND hpp.planRate_USD>0)
WHERE cancelProductName IN ('Basic','Advanced','Team','Enterprise_Legacy','Business','Enterprise')
	AND ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories ch
JOIN rpt_main_02.hist_paymentProfile hpp 
	ON hpp.paymentProfileID = ch.paymentProfileID 
	AND hpp.modifyDateTime = ch.minModifyDateTime 
    AND hpp.accountType !=2 
    AND hpp.planRate_USD > 0
SET ch.winProductName =  rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID),
ch.winARR = (hpp.planRate_USD/hpp.paymentTerm)*12
WHERE ch.cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories
SET cancelProductName = 'Collaborator'
WHERE cancelProductName IS NULL
AND cancelledDateTime>=@ch_cancelMaxModifyDateTime; -- 152 ROWs

UPDATE rpt_workspace.ch_cancelCategories
SET worm = CONCAT_WS('-',Bucket, sourceFriendly, subSourceFriendly, campaign),
customer = CASE WHEN isOrgDomain=1 THEN domain ELSE CONCAT_WS('-',domain, paymentProfileID) END,
cancelARR = CASE WHEN cancelARR IS NULL THEN 0 ELSE cancelARR END,
cancelARRBand = CASE WHEN cancelARR IS NULL OR cancelARR=0 THEN 'free'
				WHEN cancelARR<500 THEN '<.5K'
                WHEN cancelARR<1000 THEN '.5K-1K'
                WHEN cancelARR<2000 THEN '1K-2K'
                WHEN cancelARR<5000 THEN '2K-5K'
                WHEN cancelARR<1000 THEN '5K-10K'
                WHEN cancelARR<25000 THEN '10K-25K'
                WHEN cancelARR<50000 THEN '25K-50K'
                WHEN cancelARR<100000 THEN '50K-100K'
                WHEN cancelARR<500000 THEN '100K-500K'
                WHEN cancelARR>=500000 THEN '500+K'
                END
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories a
JOIN rpt_workspace.pj_domainDataCoverage b
	ON a.domain = b.domain
SET a.industry=b.industry,
a.subIndustry = b.subIndustry;

UPDATE rpt_workspace.ch_cancelCategories A
JOIN rpt_main_02.ref_geoClassification B 
	ON B.country = A.Country
SET A.A13Region = B.geoRegion;


/* ENTERPRISE SECTION */
INSERT IGNORE INTO rpt_workspace.ch_entCancels (accountName, description, closeDate, productName, productID, parentPaymentProfileID, reasonLost, Id, accountID, atRisk)
SELECT  NAME, Description, CloseDate, Product__c, CASE WHEN Product__c='Enterprise' THEN 11 ELSE 6 END, Parent_Payment_Profile_ID__c, Reason_Lost_Details__c, Id, AccountId, At_Risk__c 
FROM ss_sfdc_02.opportunity a
WHERE a.StageName='Closed Lost'
	AND a.Reason_Lost_Details__c NOT LIKE '%Duplicate%'
	AND a.Reason_Lost_Details__c NOT LIKE '%DUPLICATE%'
	AND a.Description NOT LIKE '%Not Enterprise%'
	AND a.RecordTypeId='01240000000M8rkAAC'
	AND Product__c IN ('Enterprise','Enterprise_Legacy')
	AND Parent_Payment_Profile_ID__c IS NOT NULL AND Parent_Payment_Profile_ID__c>1000
	AND closeDate>='2016-08-07 00:00:00'
	AND Description NOT LIKE "%dup.%"
	AND Description NOT LIKE "%Duplicate%"
	AND CloseDate<=NOW()
ORDER BY NAME;

UPDATE rpt_workspace.ch_entCancels ch
JOIN rpt_main_02.hist_paymentProfile ent
	ON ch.parentPaymentProfileID = ent.paymentProfileID
	AND ent.accountType=3
	AND ent.productID IN (6,11)
JOIN rpt_main_02.hist_paymentProfile newhpp
	ON ent.paymentProfileID = newhpp.paymentProfileID
	AND ent.hist_effectiveThruDateTime=newhpp.modifyDateTime
	AND newhpp.accountType=3
	AND newhpp.productID=0
SET ch.cancelledDateTime = ent.hist_effectiveThruDateTime;

UPDATE rpt_workspace.ch_cancelCategories a
JOIN rpt_workspace.ch_entCancels b
	ON a.paymentProfileID = b.parentPaymentProfileID
	AND a.cancelledDateTime = b.cancelledDateTime
SET a.cancelledDateTime = b.cancelledDateTime,
	a.atRisk = b.atRisk,
	a.cancelCategory = b.cancelCategory,
	a.cancelComment = b.reasonLost
WHERE a.cancelProductName IN ('Enterprise','Enterprise_Legacy')
AND a.cancelComment IS NULL;

/* END ENTERPRISE SECTION */

#clean up fields
UPDATE rpt_workspace.ch_cancelCategories 
SET fullCancelComment= concat_ws(' ', otherReasonComment, cancelComment)
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories 
SET cancelComment = REPLACE(cancelComment, '\n', ''), 
	otherReasonComment = REPLACE(otherReasonComment, '\n', ''),
	fullCancelComment = REPLACE(fullCancelComment, '\n', '')
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories 
SET cancelComment = REPLACE(cancelComment, '\r', ''), 
	otherReasonComment = REPLACE(otherReasonComment, '\r', ''), 
	fullCancelComment = REPLACE(fullCancelComment, '\r', '')
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;


UPDATE rpt_workspace.ch_cancelCategories 
SET cancelComment = REPLACE(cancelComment, '\r\n', ''), 
	cancelComment = REPLACE(cancelComment, '\r\n', ''),
	fullCancelComment = REPLACE(fullCancelComment, '\r\n', '')
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories 
SET otherReasonComment = REPLACE(otherReasonComment, '"', ''), 
	cancelComment = REPLACE(cancelComment, '"', ''),
	fullCancelComment = REPLACE(fullCancelComment, '"', '')
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories 
SET cancelCategory = case 
	when cancelCategory in ('noLongerNeed','littleUse', 'temporaryCancel', 'projectComplete', 'tooExpensive', 'missingFeatures', 'competitorProduct', 'differentPlan', 'otherReason', 'PreCategorization')
	then cancelCategory else null end,
otherReasonComment =  replace(otherReasonComment, '+', ' '),
cancelComment = replace(cancelComment, '+', ' '),
fullCancelComment =  replace(fullCancelComment, '+', ' ') 
WHERE fullCancelComment is not null and fullCancelComment != ' . ' and fullCancelComment !=' '
AND cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories
SET otherReasonComment = case when (otherReasonComment=' ' or otherReasonComment=']' or otherReasonComment=' . ' or otherReasonComment = ' . ]' ) THEN NULL ELSE otherReasonComment END,
cancelComment = case when (cancelComment=' ' or cancelComment=']' or cancelComment=' . ' or cancelComment = ' . ]' ) THEN NULL ELSE cancelComment END,
fullCancelComment = case when (fullCancelComment=' ' or fullCancelComment=']' or fullCancelComment=' . ' or fullCancelComment = ' . ]' ) THEN NULL ELSE fullCancelComment END
WHERE cancelledDateTime>=@ch_cancelMaxModifyDateTime;

UPDATE rpt_workspace.ch_cancelCategories
SET fullCancelComment = null
WHERE fullCancelComment in('',' . ',' . ]')
AND cancelledDateTime>=@ch_cancelMaxModifyDateTime;

DELETE FROM rpt_workspace.ch_cancelCategories
WHERE domain in ('smartsheet.com', 'smartsheet-test.com','mbfcorp.com')
AND cancelledDateTime>=@ch_cancelMaxModifyDateTime;

SELECT paymentProfileID, userID, domain, isOrgDomain, winProductName, winARR, paymentTerm, 
cancelProductName, cancelARR, cancelCategory, otherReasonComment, cancelComment, fullcancelComment, 
planStartDate, Country, languageFriendly, Bucket, sourceFriendly, subSourceFriendly, campaign, futureLoss, 
modifyByUserID, cancelCommentDate, mainContactUserID, sourceUserID, minModifyDateTime, cancelledDateTime, worm, 
customer, cancelARRBand, A13region, industry, subIndustry, atRisk 
FROM rpt_workspace.ch_cancelCategories;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("cancelCategoriesV2.csv");


