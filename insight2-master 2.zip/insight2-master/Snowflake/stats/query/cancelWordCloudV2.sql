#Initialize
SET @@sql_mode = '';
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
CALL rpt_main_02.SMARTSHEET_START_LOG ("cancelWordCloudV2.csv");

DROP TABLE IF EXISTS rpt_workspace.ch_wordsInColumn;
CREATE TABLE rpt_workspace.ch_wordsInColumn
( `ID` int(15) NOT NULL auto_increment,
  `paymentProfileID` int(15) NOT NULL,
  `cancelCategory` varchar(50),
  `word` varchar(100),
  `isStopword` bool, 
  `userID` int(15) DEFAULT NULL,
  `domain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` int(11) DEFAULT NULL,
  `winProductName` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `winARR` decimal(10,2) DEFAULT NULL,
  `cancelProductName` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cancelARR` decimal(10,2) DEFAULT NULL,
  `planStartDate` datetime DEFAULT NULL,
  `Country` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `languageFriendly` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Bucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sourceFriendly` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subSourceFriendly` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `campaign` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `modifyByUserID` int(15) DEFAULT NULL,
  `cancelCommentDate` datetime DEFAULT NULL,
  `mainContactUserID` int(15) DEFAULT NULL,
  `sourceUserID` int(15) DEFAULT NULL,
  `minModifyDateTime` datetime DEFAULT NULL,
  `cancelledDateTime` datetime NOT NULL,
  `worm` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `customer` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cancelARRBand` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `A13region` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `industry` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subIndustry` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cancelID` int(15),
  PRIMARY KEY (`ID`),
  KEY `modifyByUserID` (`modifyByUserID`),
  KEY (`word`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


CALL rpt_workspace.ch_distinctWordsInColumn();

UPDATE rpt_workspace.ch_wordsInColumn 
SET word = REPLACE(REPLACE(word, "-", ''),",",'');

UPDATE rpt_workspace.ch_wordsInColumn A
JOIN rpt_workspace.ch_stopwordsConcise B
	ON A.word = B.value
SET A.isStopword = 1;

DELETE FROM rpt_workspace.ch_wordsInColumn 
WHERE (isStopWord = 1 OR word like '%smartsheet%' OR word is null);

UPDATE rpt_workspace.ch_wordsInColumn
SET cancelCategory = CASE WHEN cancelCategory = 'competitorProduct' THEN 'Competitor Product'
							WHEN cancelCategory = 'differentPlan' THEN 'Different Plan'
                            WHEN cancelCategory = 'competitorProduct' THEN 'Competitor Product'
                            WHEN cancelCategory = 'littleUse' THEN 'Little Use'
                            WHEN cancelCategory = 'missingFeatures' THEN 'Missing Features'
                            WHEN cancelCategory = 'otherReason' THEN 'Other Reason'
                            WHEN cancelCategory = 'PreCategorization' THEN 'Pre-Categorization'
							WHEN cancelCategory = 'projectComplete' THEN 'Project Complete'
                            WHEN cancelCategory = 'temporaryCancel' THEN 'Temporary Cancel'
                            WHEN cancelCategory = 'tooExpensive' THEN 'Too Expensive' 
                            WHEN cancelCategory = 'noLongerNeed' THEN 'No Longer Need' 
                            ELSE cancelCategory END;

SELECT ID, cancelCategory, paymentProfileID, word, userID, domain, isOrgDomain, winProductName, winARR, cancelProductName, 
cancelARR, planStartDate, Country, languageFriendly, Bucket, sourceFriendly, subSourceFriendly, campaign, modifyByUserID, 
cancelCommentDate, mainContactUserID, sourceUserID, minModifyDateTime, cancelledDateTime, worm, customer, cancelARRBand, 
A13region, industry, subIndustry from rpt_workspace.ch_wordsInColumn;

#END
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("cancelWordCloudV2.csv");