SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard7V2.sql");

drop table if exists rpt_workspace.js_csRetentionCalcRepYTD;
create table if not exists rpt_workspace.js_csRetentionCalcRepYTD
(paymentProfileID int,
accountType varchar(50),
domain varchar(50),
ISP int,
customer varchar(50),
csRep varchar(50),
csRepID varchar(50),
accountName varchar(50),
accountID varchar(50),
territory varchar(50),
segment varchar(50),
currentACV dec(10,2),
YTDServicesACVbyRep dec(10,2),
YTDNewACVbyRep dec(10,2),
YTDExpansionACVbyRep dec(10,2),
YTDCancelACVbyRep dec(10,2),
YTDReductionACVbyRep dec(10,2),
YTDNewACVbyOther dec(10,2),
YTDExpansionACVbyOther dec(10,2),
YTDCancelACVbyOther dec(10,2),
YTDReductionACVbyOther dec(10,2),
maxTransactionDateOther date,
transactionInQuarter int,
primary key (paymentProfileID, csRep),
index (domain),
index (ISP),
index (customer),
index (csRepID),
index (accountName),
index (accountID));

insert into rpt_workspace.js_csRetentionCalcRepYTD(paymentProfileID, accountType, domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV)
select paymentProfileID, 'Currently Owned', domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV from rpt_workspace.js_csRetentionCalcSegmentYTD;

insert ignore into rpt_workspace.js_csRetentionCalcRepYTD(paymentProfileID, accountType, domain, ISP, csRep, territory, segment)
select paymentProfileID, 'Previously Owned', domain, ispDomain, customerSuccess, territory, segment from rpt_main_02.output_RevenueSummaryMonthly 
where recordDateTime >= '2017-02-01' and recordDateTime < '2018-02-01' and currencyChange=0 and futureLoss is null and segment is not null;

insert ignore into rpt_workspace.js_csRetentionCalcRepYTD(paymentProfileID, accountType, csRep, territory, segment)
select paymentProfileId, 'Previously Owned', csRepAtClose, territoryAtClose, segmentAtClose from rpt_workspace.js_servicesAtClose
where closeWonDate >= '2017-02-01' and closeWonDate < '2018-02-01';

delete from rpt_workspace.js_csRetentionCalcRepYTD
where csRep is null or csRep='';

update rpt_workspace.js_csRetentionCalcRepYTD A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.domain=B.mainContactDomain
where A.domain is null;

update rpt_workspace.js_csRetentionCalcRepYTD A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set ISP=1;

update rpt_workspace.js_csRetentionCalcRepYTD
set ISP=0
where ISP is null;

update rpt_workspace.js_csRetentionCalcRepYTD A
join ss_sfdc_02.domain B
on A.domain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=B.Name
where A.accountName is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set customer=domain
where ISP=0;

update rpt_workspace.js_csRetentionCalcRepYTD
set customer=concat(domain,'-',paymentProfileID)
where ISP=1;

update rpt_workspace.js_csRetentionCalcRepYTD A
join ss_sfdc_02.account B
on A.AccountName=B.Name
set A.accountID=B.Id;

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDNewACVbyRep=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.csRep=B.customerSuccess and B.domainLevelRecordTypeNew='New' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDExpansionACVbyRep=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.csRep=B.customerSuccess and B.domainLevelRecordTypeNew='Expansion' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDCancelACVbyRep=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.csRep=B.customerSuccess and B.domainLevelRecordTypeNew='Cancel' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDReductionACVbyRep=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.csRep=B.customerSuccess and B.domainLevelRecordTypeNew='Reduction' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDServicesACVbyRep=
(select sum(ARR) from rpt_workspace.js_servicesAtClose B
where A.paymentProfileID=B.paymentProfileID and A.csRep=B.csRepAtClose and B.closeWonDate >= '2017-02-01'  and B.closeWonDate < '2018-02-01');

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDNewACVbyRep=round(YTDNewACVbyRep, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDExpansionACVbyRep=round(YTDExpansionACVbyRep, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDCancelACVbyRep=round(YTDCancelACVbyRep, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDReductionACVbyRep=round(YTDReductionACVbyRep, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDServicesACVbyRep=round(YTDServicesACVbyRep, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDNewACVbyRep=0
where YTDNewACVbyRep is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDExpansionACVbyRep=0
where YTDExpansionACVbyRep is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDCancelACVbyRep=0
where YTDCancelACVbyRep is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDReductionACVbyRep=0
where YTDReductionACVbyRep is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDServicesACVbyRep=0
where YTDServicesACVbyRep is null;

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDNewACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.csRep!=B.customerSuccess or B.customerSuccess=' ' or B.customerSuccess is null) and B.domainLevelRecordTypeNew='New' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDExpansionACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.csRep!=B.customerSuccess or B.customerSuccess=' ' or B.customerSuccess is null) and B.domainLevelRecordTypeNew='Expansion' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDCancelACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.csRep!=B.customerSuccess or B.customerSuccess=' ' or B.customerSuccess is null) and B.domainLevelRecordTypeNew='Cancel' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcRepYTD A
set YTDReductionACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.csRep!=B.customerSuccess or B.customerSuccess=' ' or B.customerSuccess is null) and B.domainLevelRecordTypeNew='Reduction' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcRepYTD A
set maxTransactionDateOther=
(select max(recordDateTime) from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.csRep!=B.customerSuccess or B.customerSuccess=' ' or B.customerSuccess is null) and B.currencyChange=0 and B.futureLoss is null)
where accountType='Currently Owned';

update rpt_workspace.js_csRetentionCalcRepYTD
set transactionInQuarter=
case when maxTransactionDateOther >= '2017-02-01' then 1 else 0 end;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDNewACVbyOther=round(YTDNewACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDExpansionACVbyOther=round(YTDExpansionACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDCancelACVbyOther=round(YTDCancelACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDReductionACVbyOther=round(YTDReductionACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDNewACVbyOther=0
where YTDNewACVbyOther is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDExpansionACVbyOther=0
where YTDExpansionACVbyOther is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDCancelACVbyOther=0
where YTDCancelACVbyOther is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set YTDReductionACVbyOther=0
where YTDReductionACVbyOther is null;

delete from rpt_workspace.js_csRetentionCalcRepYTD
where accountType='Currently Owned' and transactionInQuarter=1 and YTDServicesACVbyRep=0 and YTDNewACVbyRep=0 and YTDExpansionACVbyRep=0 
and YTDCancelACVbyRep=0 and YTDReductionACVbyRep=0;

delete from rpt_workspace.js_csRetentionCalcRepYTD
where accountType='Currently Owned' and currentACV=0 and YTDServicesACVbyRep=0 and YTDNewACVbyRep=0 and YTDExpansionACVbyRep=0 
and YTDCancelACVbyRep=0 and YTDReductionACVbyRep=0;

update rpt_workspace.js_csRetentionCalcRepYTD
set ISP=0
where ISP is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set customer=domain
where ISP=0;

update rpt_workspace.js_csRetentionCalcRepYTD
set customer=concat(domain,'-',paymentProfileID)
where ISP=1;

update rpt_workspace.js_csRetentionCalcRepYTD A
join ss_sfdc_02.domain B
on A.domain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=C.Name, A.accountID=C.Id, A.territory=C.Territory__c;


update rpt_workspace.js_csRetentionCalcRepYTD
set segment=
case when territory like 'Mid-Market%' then 'Mid-Market' 
when territory like 'SMB%' then 'SMB' 
when territory like 'Major%' then 'Major'
when territory like 'Vertical Market: Retail%' then 'Retail'
when territory like 'Vertical Market: EDU%' then 'EDU'
when territory like 'Vertical Market: Healthcare%' then 'Healthcare'
when territory like 'Vertical Market: Gov%' then 'Gov'
when (territory like 'Unassigned%' or territory='Not Enough Information (ISR3)' or territory='') then 'No Territory'
else 'Strategic'
end
where territory is not null;

drop table if exists rpt_workspace.js_csRetentionCalcRepYTDStaging;
create table if not exists rpt_workspace.js_csRetentionCalcRepYTDStaging
(paymentProfileID int,
currentACV dec(10,2),
primary key (paymentProfileID));

insert into rpt_workspace.js_csRetentionCalcRepYTDStaging
select paymentProfileID, currentACV from rpt_workspace.js_csRetentionCalcRepYTD
where accountType='Currently Owned';

update rpt_workspace.js_csRetentionCalcRepYTD A
join rpt_workspace.js_csRetentionCalcRepYTDStaging B
on A.paymentProfileID=B.paymentProfileID
set A.currentACV=B.currentACV
where A.accountType='Previously Owned';

update rpt_workspace.js_csRetentionCalcRepYTD A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.currentACV=(B.planRate_USD/B.paymentTerm)*12
where A.currentACV is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set currentACV=round(currentACV, 0);

update rpt_workspace.js_csRetentionCalcRepYTD
set currentACV=0
where currentACV is null;

update rpt_workspace.js_csRetentionCalcRepYTD
set currentACV=0
where accountType='Previously Owned' and 
YTDServicesACVbyRep!=0 and YTDNewACVbyRep=0 and YTDExpansionACVbyRep=0 and YTDCancelACVbyRep=0 and YTDReductionACVbyRep=0;

select * from rpt_workspace.js_csRetentionCalcRepYTD;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard7V2.sql");

