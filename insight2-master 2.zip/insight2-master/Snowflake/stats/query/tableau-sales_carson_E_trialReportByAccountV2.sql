SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-sales_carson_E_trialReportByAccount.sql");

SELECT 
CASE WHEN acc.Id IN('0014000000mw0jpAAA','0014000000uWnvZAAS') THEN 'Salesforce+Exact Target'
	ELSE acc.Name END AS 'AccountName', 
u.domain, 
t.userID, 
u.domain, 
u.emailAddress, 
t.trialDateTime, 
t.trialEndDateTime, 
acc.Territory__c AS 'Territory'

FROM rpt_main_02.rpt_trials t
	JOIN rpt_main_02.userAccount u ON u.userID = t.userID
	JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = u.domain
	JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c AND acc.Territory__c NOT LIKE '%Unassigned%' AND acc.Territory__c != ''
LEFT JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = u.domain
	
WHERE t.trialType = 1
AND t.trialDateTime >= '2016-01-01'
AND isp.domain IS NULL
GROUP BY t.userID
;
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-sales_carson_E_trialReportByAccount.sql");

