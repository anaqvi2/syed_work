SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("salesCohortsPerformance2V2.sql");

/*
drop table if exists rpt_workspace.js_SFDCteamThreshold;
create table if not exists rpt_workspace.js_SFDCteamThreshold
(repName varchar(50),
title varchar(50),
startClass varchar(50),
startClassSize int,
startDate date,
closeDate date,
dateDiff int,
amount dec(10,2),
opportunityName varchar(100),
opportunityID varchar(50),
primary key (repName, opportunityID),
index (startClass),
index (startDate),
index (closeDate));
*/

insert ignore into rpt_workspace.js_SFDCteamThreshold(repName, title, startClass, startDate, closeDate, dateDiff, amount, opportunityName, opportunityID)
select A.repName, A.title, A.startClass, A.startDate, B.closeDate, datediff(B.closeDate, A.startDate), B.Amount, B.Name, B.Id from rpt_workspace.js_cohortPerformanceStaging A
join ss_sfdc_02.opportunity B
on A.repID=B.ownerID and A.startDate <= B.closeDate and B.closeDate < current_date and B.Amount > 0
where B.stageName='Closed Won';

delete from rpt_workspace.js_SFDCteamThreshold
where title='New Account Specialist' and amount < 2000;

delete from rpt_workspace.js_SFDCteamThreshold
where title='Client Development Manager' and amount < 3000;

delete from rpt_workspace.js_SFDCteamThreshold
where title='New Business Representative' and amount < 4000;

update rpt_workspace.js_SFDCteamThreshold A
set startClassSize=
(select count(*) from rpt_workspace.js_cohortPerformanceStaging B
where A.startClass=B.startClass and A.title=B.title);

update rpt_workspace.js_SFDCteamThreshold set opportunityName = REPLACE(opportunityName, '\n', '');
update rpt_workspace.js_SFDCteamThreshold set opportunityName = REPLACE(opportunityName, '\r', '');
update rpt_workspace.js_SFDCteamThreshold set opportunityName = REPLACE(opportunityName, '\r\n', '');

select * from rpt_workspace.js_SFDCteamThreshold;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("salesCohortsPerformance2V2.sql");

