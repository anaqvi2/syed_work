SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard4V2.sql");

drop table if exists rpt_workspace.js_csRetentionCalcSegmentYTD;
create table if not exists rpt_workspace.js_csRetentionCalcSegmentYTD
(paymentProfileID int,
domain varchar(50),
ISP int,
customer varchar(50),
csRep varchar(50),
csRepID varchar(50),
accountName varchar(50),
accountID varchar(50),
territory varchar(50),
segment varchar(50),
currentACV dec(10,2),
primary key (paymentProfileID),
index (domain),
index (ISP),
index (customer),
index (csRep),
index (csRepID),
index (accountName),
index (accountID));

insert ignore into rpt_workspace.js_csRetentionCalcSegmentYTD(paymentProfileID, domain, currentACV)
select paymentProfileID, domain, ACV from rpt_main_02.rpt_paidPlanInfo A
join ss_sfdc_02.account B
on A.accountID=B.Id
where (B.Account_to_be_Assigned__c in ('Disqualified', 'Engaged', 'Existing') or 
(B.Customer_Success__c is not null and B.Customer_Success__c!=' '));

update rpt_workspace.js_csRetentionCalcSegmentYTD A
join ss_sfdc_02.domain B
on A.domain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=C.Name, A.accountID=C.Id, A.csRepID=C.Customer_Success__c, A.territory=C.Territory__c;

update rpt_workspace.js_csRetentionCalcSegmentYTD A
set csRep=
(select concat(B.FirstName, ' ', B.LastName) from ss_sfdc_02.user B
where A.csRepID=B.Id);

update rpt_workspace.js_csRetentionCalcSegmentYTD
set csRep='CustomerSuccess@'
where csRepID is null or csRepID=' ' or csRep='Tasha Bishop';

update rpt_workspace.js_csRetentionCalcSegmentYTD
set segment=
case when territory like 'Mid-Market%' then 'Mid-Market' 
when territory like 'SMB%' then 'SMB' 
when territory like 'Major%' then 'Major'
when territory like 'Vertical Market: Retail%' then 'Retail'
when territory like 'Vertical Market: EDU%' then 'EDU'
when territory like 'Vertical Market: Healthcare%' then 'Healthcare'
when territory like 'Vertical Market: Gov%' then 'Gov'
when (territory like 'Unassigned%' or territory='Not Enough Information (ISR3)' or territory='') then 'No Territory'
else 'Strategic'
end
where territory is not null;

insert ignore into rpt_workspace.js_csRetentionCalcSegmentYTD(paymentProfileID, domain, currentACV, territory, segment, csRep, accountName, accountID)
select paymentProfileID, domain, 0, territory, segment, customerSuccess, accountName, accountID from rpt_main_02.output_RevenueSummaryMonthly A
join ss_sfdc_02.domain B
on A.domain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
where A.recordTypeNew='Cancel' and A.recordDateTime >= '2017-02-01' and A.recordDateTime < '2018-02-01' and A.currencyChange=0 and A.futureLoss is null and
(C.Account_to_be_Assigned__c in ('Disqualified', 'Engaged', 'Existing') or (C.Customer_Success__c is not null and C.Customer_Success__c!=' '));

UPDATE rpt_workspace.js_csRetentionCalcSegmentYTD
SET domain = 'incitecpivot.com.au',
customer = 'Incitec Pivot Limited',
accountId = '0013300001f6HPxAAM',
csRep = 'Andrew Rustmeyer',
territory = 'Unassigned (CDM)',
segment = 'No Territory'
WHERE paymentProfileID = 7598286;

update rpt_workspace.js_csRetentionCalcSegmentYTD A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set A.ISP=1;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set customer=domain
where ISP is null;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set customer=concat(domain,'-',paymentProfileID)
where ISP=1;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set domain='cree.com', ISP=null, customer='cree.com', accountName='Cree, Inc.', accountId='0014000000mw0SpAAI', csRep='Reid Kilwine',  
csRepID='00533000003uxWZAAY', territory='Major: East - Open (CDM)', segment='Major'
where paymentProfileID=6892090;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set domain='okq8.se', ISP=null, customer='okq8.se', accountName='OK-Q8', accountId='0013300001cH1XWAA0', csRep='Liz Tanonis',
csRepID='00540000002n544AAA', territory='Unassigned (CDM)', segment='No Territory'
where paymentProfileID=3975994;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set domain='ascension.org', ISP=null, customer='ascension.org', accountName='Ascension Health', accountId='0014000000uWnXWAA0', csRep='Johannah Brown',
csRepID='00533000003OTdUAAW', territory='Major: East3 - Jennifer Abramowitz (CDM)', segment='Major'
where paymentProfileID=8494109;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set domain='cbre.com', ISP=null, customer='cbre.com', accountName='CB Richard Ellis Group', accountId='0014000000mw0MvAAI', csRep='Dillon Brady',
csRepID='00540000002nyJaAAI', territory='Los Angeles', segment='Strategic'
where paymentProfileID=4047305;

update rpt_workspace.js_csRetentionCalcSegmentYTD
set currentACV=round(currentACV, 0);


drop table if exists rpt_workspace.js_csRetentionCalcSegmentYTDFinal;
create table if not exists rpt_workspace.js_csRetentionCalcSegmentYTDFinal
(paymentProfileID int,
accountType varchar(50),
domain varchar(50),
ISP int,
customer varchar(50),
csRep varchar(50),
csRepID varchar(50),
accountName varchar(50),
accountID varchar(50),
territory varchar(50),
segment varchar(50),
currentACV dec(10,2),
YTDServicesACVbySegment dec(10,2),
YTDNewACVbySegment dec(10,2),
YTDExpansionACVbySegment dec(10,2),
YTDCancelACVbySegment dec(10,2),
YTDReductionACVbySegment dec(10,2),
YTDNewACVbyOther dec(10,2),
YTDExpansionACVbyOther dec(10,2),
YTDCancelACVbyOther dec(10,2),
YTDReductionACVbyOther dec(10,2),
maxTransactionDateOther date,
transactionInQuarter int,
primary key (paymentProfileID, segment),
index (domain),
index (ISP),
index (customer),
index (csRepID),
index (accountName),
index (accountID),
index (territory),
index (segment));

insert into rpt_workspace.js_csRetentionCalcSegmentYTDFinal(paymentProfileID, accountType, domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV)
select paymentProfileID, 'Currently Owned', domain, ISP, customer, csRep, csRepID, accountName, accountID, territory, segment, currentACV from rpt_workspace.js_csRetentionCalcSegmentYTD;

insert ignore into rpt_workspace.js_csRetentionCalcSegmentYTDFinal(paymentProfileID, accountType, domain, ISP, csRep, accountName, territory, segment)
select paymentProfileID, 'Previously Owned', domain, ispDomain, customerSuccess, accountName, territory, segment from rpt_main_02.output_RevenueSummaryMonthly 
where recordDateTime >= '2017-02-01' and recordDateTime < '2018-02-01' and currencyChange=0 and futureLoss is null and segment is not null;

insert ignore into rpt_workspace.js_csRetentionCalcSegmentYTDFinal(paymentProfileID, accountType, csRep, territory, segment)
select paymentProfileId, 'Previously Owned', csRepAtClose, territoryAtClose, segmentAtClose from rpt_workspace.js_servicesAtClose
where closeWonDate >= '2017-02-01' and closeWonDate < '2018-02-01';

delete from rpt_workspace.js_csRetentionCalcSegmentYTDFinal
where csRep is null or csRep='';

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.domain=B.mainContactDomain
where A.domain is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set ISP=1;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set ISP=0
where ISP is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join ss_sfdc_02.domain B
on A.domain=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=B.Name
where A.accountName is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set customer=domain
where ISP=0;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set customer=concat(domain,'-',paymentProfileID)
where ISP=1;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join ss_sfdc_02.account B
on A.AccountName=B.Name
set A.accountID=B.Id;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDNewACVbySegment=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.segment=B.segment and B.domainLevelRecordTypeNew='New' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDExpansionACVbySegment=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.segment=B.segment and B.domainLevelRecordTypeNew='Expansion' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDCancelACVbySegment=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.segment=B.segment and B.domainLevelRecordTypeNew='Cancel' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDReductionACVbySegment=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and A.segment=B.segment and B.domainLevelRecordTypeNew='Reduction' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDServicesACVbySegment=
(select sum(ARR) from rpt_workspace.js_servicesAtClose B
where A.paymentProfileID=B.paymentProfileID and A.segment=B.segmentAtClose and B.closeWonDate >= '2017-02-01' and B.closeWonDate < '2018-02-01');

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDNewACVbySegment=round(YTDNewACVbySegment, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDExpansionACVbySegment=round(YTDExpansionACVbySegment, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDCancelACVbySegment=round(YTDCancelACVbySegment, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDReductionACVbySegment=round(YTDReductionACVbySegment, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDServicesACVbySegment=round(YTDServicesACVbySegment, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDNewACVbySegment=0
where YTDNewACVbySegment is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDExpansionACVbySegment=0
where YTDExpansionACVbySegment is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDCancelACVbySegment=0
where YTDCancelACVbySegment is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDReductionACVbySegment=0
where YTDReductionACVbySegment is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDServicesACVbySegment=0
where YTDServicesACVbySegment is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDNewACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.segment!=B.segment or B.segment is null) and B.domainLevelRecordTypeNew='New' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDExpansionACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.segment!=B.segment or B.segment is null) and B.domainLevelRecordTypeNew='Expansion' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDCancelACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.segment!=B.segment or B.segment is null) and B.domainLevelRecordTypeNew='Cancel' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set YTDReductionACVbyOther=
(select sum(MonthlyPaymentChange)*12 from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.segment!=B.segment or B.segment is null) and B.domainLevelRecordTypeNew='Reduction' and 
B.recordDateTime >= '2017-02-01' and B.recordDateTime < '2018-02-01' and B.currencyChange=0 and B.futureLoss is null);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
set maxTransactionDateOther=
(select max(recordDateTime) from rpt_main_02.output_RevenueSummaryMonthly B
where A.paymentProfileID=B.paymentProfileID and (A.segment!=B.segment or B.segment is null) and B.currencyChange=0 and B.futureLoss is null)
where accountType='Currently Owned';

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set transactionInQuarter=
case when maxTransactionDateOther >= '2017-02-01' then 1 else 0 end;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDNewACVbyOther=round(YTDNewACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDExpansionACVbyOther=round(YTDExpansionACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDCancelACVbyOther=round(YTDCancelACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDReductionACVbyOther=round(YTDReductionACVbyOther, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDNewACVbyOther=0
where YTDNewACVbyOther is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDExpansionACVbyOther=0
where YTDExpansionACVbyOther is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDCancelACVbyOther=0
where YTDCancelACVbyOther is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set YTDReductionACVbyOther=0
where YTDReductionACVbyOther is null;

delete from rpt_workspace.js_csRetentionCalcSegmentYTDFinal
where accountType='Currently Owned' and transactionInQuarter=1 and YTDServicesACVbySegment=0 and YTDNewACVbySegment=0 and YTDExpansionACVbySegment=0 
and YTDCancelACVbySegment=0 and YTDReductionACVbySegment=0;

delete from rpt_workspace.js_csRetentionCalcSegmentYTDFinal
where accountType='Currently Owned' and currentACV=0 and YTDServicesACVbySegment=0 and YTDNewACVbySegment=0 and YTDExpansionACVbySegment=0 
and YTDCancelACVbySegment=0 and YTDReductionACVbySegment=0;


drop table if exists rpt_workspace.js_csRetentionCalcSegmentYTDFinalStaging;
create table if not exists rpt_workspace.js_csRetentionCalcSegmentYTDFinalStaging
(paymentProfileID int,
currentACV dec(10,2),
primary key (paymentProfileID));

insert into rpt_workspace.js_csRetentionCalcSegmentYTDFinalStaging
select paymentProfileID, currentACV from rpt_workspace.js_csRetentionCalcSegmentYTDFinal
where accountType='Currently Owned';

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join rpt_workspace.js_csRetentionCalcSegmentYTDFinalStaging B
on A.paymentProfileID=B.paymentProfileID
set A.currentACV=B.currentACV
where A.accountType='Previously Owned';

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.currentACV=(B.planRate_USD/B.paymentTerm)*12
where A.currentACV is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set currentACV=round(currentACV, 0);

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set currentACV=0
where currentACV is null;

update rpt_workspace.js_csRetentionCalcSegmentYTDFinal
set currentACV=0
where accountType='Previously Owned' and 
YTDServicesACVbySegment!=0 and YTDNewACVbySegment=0 and YTDExpansionACVbySegment=0 and YTDCancelACVbySegment=0 and YTDReductionACVbySegment=0;

select * from rpt_workspace.js_csRetentionCalcSegmentYTDFinal;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard4V2.sql");