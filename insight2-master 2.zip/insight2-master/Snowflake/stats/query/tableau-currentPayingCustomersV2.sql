SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-currentPayingCustomersV2.sql");


/*Generating paymentProfileV2.csv*/
SELECT
	rpt_paymentProfile.sourceUserID,
	mainContactUserAccount.emailAddress AS Email,
	SUBSTR(mainContactUserAccount.emailAddress, INSTR(mainContactUserAccount.emailAddress,'@') + 1) AS Domain,
	"0" AS EmailExistsInClassic,
	rpt_paymentProfile.productID 	AS ProductID,
	rpt_paymentProfile.productName AS ProductName,
	rpt_paymentProfile.userLimit AS UserLimit,
	rpt_paymentProfile.paymentTerm 	AS PaymentTerm,
	rpt_paymentProfile.paymentTermFriendly,

	planRate_USD AS PaymentTotal,
	planRate_USD / paymentTerm AS MonthlyRevenue, 
	currencyCode,
	promoCode 		AS PromoCode,
	paymentType AS PaymentType,
	paymentTypeFriendly AS PaymentTypeFriendly,

	paymentStartDateRaw,
	paymentStartDateClean AS PaymentStartDateClean,
	paymentStartMonth AS PaymentStartMonth,
	paymentStartWeek AS PaymentStartWeek,
	paymentStartDay AS PaymentStartDay,

	daysToBuy  AS DaysToBuy,

	paymentInsertDate AS PaymentInsertDate,
	paymentInsertMonth AS PaymentInsertMonth,
	paymentInsertWeek AS PaymentInsertWeek,
	paymentInsertDay AS PaymentInsertDay,

	
	/* common rpt_signupSourceUser and rpt_loginCountTotal */
	rpt_signupSourceUser.signupInsertDateTime 	AS SignupDateTime,
	rpt_signupSourceUser.signupMonth AS SignupMonth,
	rpt_signupSourceUser.signupWeek AS SignupWeek,
	rpt_signupSourceUser.signupDay AS SignupDay,

	rpt_signupSourceUser.source AS SignupSource,
	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS SignupSourceFriendly,

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS SignupSubSourceFriendly,

	rpt_signupSourceUser.campaign 		AS SignupCampaign,
	rpt_signupSourceUser.segment 		AS SignupSegment,
	/* quote to prevent odd characters causing problems in Excel and so Excel won't try to interpret keywords that start with + as a formula */
	QUOTE(rpt_signupSourceUser.keyword) 		AS 'Signup Keyword',
	rpt_signupSourceUser.referrer 		AS SignupReferrer,
	rpt_signupSourceUser.queryValue		AS SignupQueryValue,
	rpt_signupSourceUser.mySmartsheetReferralLink AS SignupMySmartsheetReferralLink,
	rpt_signupSourceUser.appLaunchType 		AS SignupShortcutType,
	rpt_signupSourceUser.appLaunchParm1 	AS SignupShourcutParm1,
	rpt_signupSourceUser.appLaunchParm1Friendly	AS SignupShourcutParm1Friendly,

	rpt_loginCountTotal.firstLogin 	AS FirstLogin, 
	rpt_loginCountTotal.lastLogin 	AS LastLogin, 
	rpt_loginCountTotal.loginCount 	AS LoginCount,	

	rpt_paymentProfile.seatCount AS "Seat Count",

	countAsPaid AS "Count as Paid",
	planRate_USD / paymentTerm AS "Recurring Monthly Revenue",
	(planRate_USD / paymentTerm)*12 AS "Annual Revenue",

	rpt_paymentProfile.accountType,
	rpt_paymentProfile.accountTypeFriendly AS "Account Type Friendly",

	rpt_signupSourceAncestor.email			AS 'Ancestor Email',
	rpt_signupSourceAncestor.sourceFriendly		AS 'Ancestor Source',
	rpt_signupSourceAncestor.subSourceFriendly	AS 'Ancestor Sub Source',
	rpt_signupSourceAncestor.campaign 		AS 'Ancestor Signup Campaign',
	rpt_signupSourceAncestor.segment 		AS 'Ancestor Signup Segment',

	rpt_signupSourceUser.mySmartsheetReferralLinkFriendly AS SignupMySmartsheetReferralLinkFriendly,
	
	/* don't allow user to refer themselves */
	CASE referralEmailAddress = sourceUserAccount.emailAddress
		WHEN 1 THEN NULL
		ELSE referralEmailAddress 
	END AS 'Referral Email Address',

	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN 	
				CASE rpt_signupSourceUser.sourceFriendly IS NULL
					WHEN 1 THEN "Sharing"
					ELSE rpt_signupSourceUser.sourceFriendly
				END
		ELSE 
				CASE rpt_signupSourceUser.sourceFriendly IS NULL  		/* if we already have source info, use it */
					WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 
					ELSE
						CASE rpt_signupSourceUser.sourceFriendly != "PPC"		/* if there is an ancestor source and a user source 		*/
							WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 	/* use the anscestor source if the user source is sharing 	*/
							ELSE rpt_signupSourceUser.sourceFriendly				/* otherwise use the user source 							*/
						END
				END
	END AS 'Working Source',


	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN 	
				CASE rpt_signupSourceUser.subSourceFriendly IS NULL
					WHEN 1 THEN "Sharing"
					ELSE rpt_signupSourceUser.subSourceFriendly
				END
		ELSE 
				CASE rpt_signupSourceUser.subSourceFriendly IS NULL  		/* if we already have source info, use it */
					WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 
					ELSE 
						CASE rpt_signupSourceUser.subSourceFriendly != "PPC"		/* if there is an ancestor sub source and a user sub source 	*/
							WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 	/* use the anscestor sub source if the user source is sharing 	*/
							ELSE rpt_signupSourceUser.subSourceFriendly				/* otherwise use the user sub source 							*/
						END
				END
	END AS 'Working Sub Source',


	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN rpt_signupSourceUser.campaign
		ELSE rpt_signupSourceAncestor.campaign
	END AS 'Working Campaign',

	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN rpt_signupSourceUser.segment
		ELSE rpt_signupSourceAncestor.segment
	END AS 'Working Segment',

	CASE (mainContactUserAccount.newsFlags & 1)  
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Receive News',

	(rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) AS 'Lead Strength',
	
	rpt_paymentProfile.sheetCount AS 'Sheet Count',
	
	CASE arc_userSessionActivity.lastSessionDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -30 DAY) 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Logged in last 30 days',
	
	CASE rpt_signupSourceUser.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSourceUser.bucket
	END AS 'Bucket',
		
	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN 	
			CASE rpt_signupSourceUser.bucket IS NULL
				WHEN 1 THEN "Viral"
				ELSE rpt_signupSourceUser.bucket
			END
		ELSE rpt_signupSourceAncestor.bucket 
	END AS 'Working Bucket',
	
	rpt_paymentProfile.activeProfileCount AS 'Active Profile Count',
	
	mainContactUserAccount.localeFriendly 					AS "Locale",
	mainContactUserAccount.languageFriendly 				AS "Language",
	mainContactUserAccount.countryFriendly 					AS "Country",
	
	        
	rpt_domainRollup.googleAppsDomain AS GoogleAppInstalledDomain,
	
	rpt_paymentProfile.paymentProfileID AS 'Payment Profile ID',
	rpt_paymentProfile.parentPaymentProfileID 'Parent Payment Profile ID',
        
	rpt_paymentProfile.billToCountryFriendly AS "Billing Country",
		

	CASE WHEN rpt_userIPLocation.ipCountry IS NULL THEN rpt_paymentProfile.billToCountryFriendly
	ELSE rpt_userIPLocation.ipCountry END AS "IP Country",
	rpt_userIPLocation.ipRegion AS "IP Region",
	rpt_userIPLocation.ipCity AS "IP City",
	rpt_paymentProfile.companyName AS "Organization Name",
	
	CASE WHEN rpt_paymentProfile.nextPaymentDate > NOW() THEN rpt_paymentProfile.nextPaymentDate 
	ELSE CASE WHEN paymentTerm = 12 THEN
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
				THEN DATE_FORMAT(CONCAT("2018-",MONTH(rpt_paymentProfile.actualLastPaymentDate), "-",DAY(rpt_paymentProfile.actualLastPaymentDate)), "%Y-%m-%d 00:00:00")
			WHEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) > NOW() 
				THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) YEAR) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +((YEAR(NOW()) - YEAR(rpt_paymentProfile.paymentStartDateClean)) + 1) YEAR) END
		WHEN paymentTerm IN (1,6) THEN 
			/*If there's an out of date nextPaymentDate, add the next term*/
			CASE WHEN rpt_paymentProfile.nextPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.nextPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's a recent actual last payment, either add the next term*/
			WHEN rpt_paymentProfile.actualLastPaymentDate > DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL rpt_paymentProfile.paymentTerm MONTH)
			/*If there's no recent actual last payment, add appropriate number of terms*/
			WHEN rpt_paymentProfile.actualLastPaymentDate < DATE_ADD(NOW(), INTERVAL -rpt_paymentProfile.paymentTerm MONTH) 
			THEN DATE_ADD(rpt_paymentProfile.actualLastPaymentDate, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.actualLastPaymentDate)) MONTH)
			/*If there's no recent actual last payment, add to paymentStartDate*/
			WHEN rpt_paymentProfile.paymentTerm = 1 
			THEN DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +
				(rpt_main_02.SMARTSHEET_MONTH(NOW()) - rpt_main_02.SMARTSHEET_MONTH(rpt_paymentProfile.paymentStartDateClean)) MONTH) 
			ELSE DATE_ADD(rpt_paymentProfile.paymentStartDateClean, INTERVAL +(rpt_paymentProfile.paymentTerm) MONTH) END
		ELSE "Other" END
	END
AS NewCalcNextPaymentDate,
acc.Name AS accountName,
acc.Fortune_1000_Rank__c as 'Fortune1000Rank',
CASE WHEN acc.Fortune_1000_Rank__c > 0 THEN 1 ELSE 0 END as 'Fortune1000Domain',
IFNULL(ppcc.totalCollaborators,0) AS 'Collaborators',
u.Username AS csRep,
acc.Account_to_be_Assigned__c as sfdcAccountType,
acc.NumberOfEmployees,
gc.geoRegion AS 'A13Region'


FROM rpt_main_02.rpt_paymentProfile rpt_paymentProfile
LEFT OUTER JOIN rpt_main_02.userAccount sourceUserAccount 					ON rpt_paymentProfile.sourceUserID 			= sourceUserAccount.userID
LEFT OUTER JOIN rpt_main_02.userAccount mainContactUserAccount 				ON rpt_paymentProfile.mainContactUserID 	= mainContactUserAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceUser 			ON rpt_paymentProfile.sourceUserID 			= rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal  							ON rpt_paymentProfile.sourceUserID 			= rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_userAncestor 								ON sourceUserAccount.emailAddress 			= rpt_userAncestor.userEmailAddress
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSourceAncestor		ON rpt_userAncestor.ancestorEmailAddress 	= rpt_signupSourceAncestor.email
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY)			ON mainContactUserAccount.userID 				= rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 						ON mainContactUserAccount.userID 				= rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   					ON mainContactUserAccount.userID 				= rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_userSessionActivity							ON mainContactUserAccount.userID 				= arc_userSessionActivity.userID
LEFT OUTER JOIN rpt_main_02.rpt_domainRollup  								ON rpt_paymentProfile.mainContactDomain 	= rpt_domainRollup.domain
-- LEFT OUTER JOIN rpt_main_02.ref_ipAddressInfo ref_ipAddressInfo ON ref_ipAddressInfo.ipAddress = rpt_signupSourceUser.ipAddress 
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation FORCE INDEX (PRIMARY)								ON rpt_userIPLocation.userID				= sourceUserAccount.userID
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = rpt_paymentProfile.mainContactDomain
LEFT OUTER JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
LEFT OUTER JOIN ss_sfdc_02.user u ON acc.Customer_Success__c=u.Id
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanCollabCount ppcc ON ppcc.paymentProfileID = rpt_paymentProfile.paymentProfileID
LEFT OUTER JOIN rpt_main_02.ref_geoClassification gc on gc.country = rpt_userIPLocation.ipCountry
	
WHERE rpt_paymentProfile.countAsPaid = 1 
/* AND rpt_paymentProfile.hasOrgProfile = 0 OR rpt_paymentProfile.countAsPaid = 1   trying to remove duplicate emails for payment profiles for the individual and organization they created */
GROUP BY rpt_paymentProfile.paymentProfileID
ORDER BY sourceUserAccount.userID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-currentPayingCustomersV2.sql");



