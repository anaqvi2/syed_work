SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-forecastingResults2V2.sql");

select dayDate, monthYear, recordType, commercialActualToDate, assistedCommercialActualToDate, unassistedActualToDate, commercialForecastTotal, assistedCommercialForecastTotal, 
unassistedForecastTotal, commercialPlanTotal, assistedCommercialPlanTotal, unassistedPlanTotal from rpt_workspace.js_monthlyPerformance
where dayDate <= DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 0 MONTH)), '%Y-%m-%d');

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-forecastingResults2V2.sql");

