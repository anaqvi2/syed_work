SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("salesforceRollingPipelineV2.sql");

select * from rpt_main_02.rpt_SFDCRollingPipeline;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("salesforceRollingPipelineV2.sql");

