select "******************************************************************************************************************************", NOW();
select "******** Throwaway Part 2: Trials - start ******** ", NOW();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CALL rpt_main_02.SMARTSHEET_START_LOG ("Throwaway Part 2: Trials");
SET @@sql_mode = '';

CALL rpt_main_02.SMARTSHEET_START_LOG ("Max record IDs");

SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenID" INTO @NewMaxaccessTokenID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenSessionID" INTO @NewMaxaccessTokenSessionID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxbrandID" INTO @NewMaxbrandID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDInsert" INTO @NewMaxContainerIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDModify" INTO @NewMaxContainerIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxgoogleAppsDomainID"  INTO @NewMaxgoogleAppsDomainID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxHPPmodifyDateTime"  INTO @NewMaxHPPmodifyDateTime;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxmailDistributionID"  INTO @NewMaxmailDistributionID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxopedIDIdentifierID"  INTO @NewMaxopedIDIdentifierID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationID"  INTO @NewMaxorganizationID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationUserRoleID"  INTO @NewMaxorganizationUserRoleID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NEWmaxPaymentProfileID" 	 INTO @NEWmaxPaymentProfileID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxreminderID"  INTO @NewMaxreminderID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxRequestLogID" INTO @NewMaxRequestLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsessionLogID" INTO @NewMaxsessionLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDInsert" INTO @NewMaxsheetLinkIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDModify" INTO @NewMaxsheetLinkIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestID" 	 INTO @NewMaxsignupRequestID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestTrackingItemID"  INTO @NewMaxsignupRequestTrackingItemID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsiteSettingElementValueID"  INTO @NewMaxsiteSettingElementValueID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDInsert"  INTO @NewMaxTemplateIDInsert;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDModify" INTO @NewMaxTemplateIDModify;
SELECT maximumValue  		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserID"  INTO @NewMaxuserID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxworkspaceID"  INTO @NewMaxworkspaceID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserDataID" INTO @NewMaxuserDataID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorgUserModifyDate" INTO @NewMaxorgUserModifyDate;

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Max record IDs");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_clientEvent_clean - start ******** ", NOW();

/*Start rpt_main_02.arc_clientEvent*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_clientEvent");

CALL rpt_main_02.etl_clientEvent(@processId,@logLevel);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_clientEvent");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.rpt_clientEvent_clean - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientEvent_clean delete");

TRUNCATE TABLE rpt_main_02.rpt_clientEvent_clean;
SELECT DATE_ADD(MAX(logDate), INTERVAL 1 DAY) INTO @startDate FROM rpt_main_02.arc_clientEventRollup;


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean delete");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientEvent_clean insert");

SET AUTOCOMMIT = 0;

INSERT rpt_main_02.rpt_clientEvent_clean 
SELECT ce.*, sl.userID
FROM rpt_main_02.arc_clientEvent ce
LEFT JOIN rpt_main_02.arc_sessionLog sl ON ce.sessionLogID=sl.sessionLogID 
WHERE eventDateTime >= @startDate
;

COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean insert");

/******* clean values not needed, for more compression  - start *******/
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientEvent_clean update");


 SELECT 1 	INTO @LOG_ID_OPEN; 
 SELECT 20 	INTO @LOG_ID_MOUSE_DOWN;
 SELECT 22	INTO @LOG_ID_CLICK;
 SELECT 31 	INTO @LOG_ID_SHORTCUT_KEY;
 SELECT 60 	INTO @LOG_ID_LAUNCH_UPGRADE;
 SELECT 61 	INTO @LOG_ID_COMPLETE_UPGRADE;
 SELECT 62 	INTO @LOG_ID_CANCEL_UPGRADE;
 SELECT 99 	INTO @LOG_ID_DIAGNOSTIC;
 
 SELECT 101 	INTO @LOG_ID_DESKTOP;
 SELECT 200 	INTO @LOG_ID_MY_ACCOUNT_LINK;
 
 SELECT 500 	INTO @LOG_ID_HOMEPAGE_TREE_NODE;

 SELECT 564 	INTO @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE;
 
 SELECT 1801 	INTO @LOG_ID_HELPOVERLAY_PAGE_CONTROL;
 SELECT 1805 	INTO @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK;
 SELECT 1806 	INTO @LOG_ID_HELPOVERLAY_VIDEO_LINK;
 SELECT 2001 	INTO @LOG_ID_STANDARD_BUTTON_GENERIC;
 SELECT 5001 	INTO @LOG_ID_TOOLBAR_BUTTON_SAVE;
 SELECT 12001 	INTO @LOG_ID_GETTINGSTARTED_ABCTEST;

 SET AUTOCOMMIT = 0;
 UPDATE rpt_main_02.rpt_clientEvent_clean cec 
 SET cec.parm1String = NULL ,  cec.parm1Int = NULL
 WHERE NOT	/* we are NOT blanking out the list below... i.e. below is a list of the items where we are keeing the parameters */
 	(
	 (cec.objectID >= @LOG_ID_MY_ACCOUNT_LINK AND cec.actionID = @LOG_ID_OPEN) OR  /* want to keep everything higher than the desktop and tabs */
 	(cec.objectID = @LOG_ID_STANDARD_BUTTON_GENERIC) OR 
 	(cec.actionID = @LOG_ID_LAUNCH_UPGRADE OR cec.actionID = @LOG_ID_COMPLETE_UPGRADE OR cec.actionID = @LOG_ID_CANCEL_UPGRADE) OR 
 	(cec.objectID = @LOG_ID_HELPOVERLAY_PAGE_CONTROL OR cec.objectID = @LOG_ID_HELPOVERLAY_HELP_PAGE_LINK OR cec.objectID = @LOG_ID_HELPOVERLAY_VIDEO_LINK) OR 
 	(cec.actionID = @LOG_ID_SHORTCUT_KEY) OR 
 	(cec.objectID = @LOG_ID_GETTINGSTARTED_ABCTEST) OR 
 	(cec.objectID = @LOG_ID_HOMEPAGE_TREE_NODE) OR 
 	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_CATEGORY) OR 
 	(cec.objectID = @LOG_ID_HOMEPAGE_TEMPLATE_GALLERY_SEARCH) OR 
 	(cec.objectID = @LOG_ID_DESKTOP AND cec.actionID = @LOG_ID_DIAGNOSTIC) OR 
 	(cec.objectID >= @LOG_ID_TOOLBAR_BUTTON_SAVE AND cec.actionID = @LOG_ID_MOUSE_DOWN) OR
 	(cec.objectID = @LOG_ID_NEWSHEETTAB_GLOBALTEMPLATETYPE AND @LOG_ID_CLICK)
 	)
 ;
 COMMIT;
 SET AUTOCOMMIT = 1; 

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientEvent_clean update");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_clientEventRollup - start ******** ", NOW();
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_clientEventRollup");

SET AUTOCOMMIT = 0;

SELECT MAX(DATE(eventDateTime)) INTO @maxEventDate FROM rpt_main_02.rpt_clientEvent_clean;

SET AUTOCOMMIT = 0;
INSERT IGNORE INTO rpt_main_02.arc_clientEventRollup(insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
SELECT userID, 
	DATE(eventDateTime),
	objectID,
	actionID,
	parm1String,
	parm1Int,
	COUNT(*)
FROM rpt_main_02.rpt_clientEvent_clean cec
where date(cec.eventDateTime) < @maxEventDate
GROUP BY 1,2,3,4,5,6
;
COMMIT;
SET AUTOCOMMIT = 1;


COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_clientEventRollup");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_clientLogCountsByUserArchived table part 1 - start ******** ", NOW();


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep1");

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_dailyClientEvents LIKE rpt_main_02.arc_clientEvent;

SELECT MAX(clientEventID) INTO @maxClientEventID FROM rpt_main_02.stg_dailyClientEvents;
SELECT MAX(maxClientEvent) INTO @AlternateMaxClientEventID FROM rpt_main_02.arc_clientEventLookup;

SELECT IF(@maxClientEventID IS NULL, @AlternateMaxClientEventID, @maxClientEventID) INTO @maxClientEventID;

REPLACE INTO rpt_main_02.arc_clientEventLookup
SELECT CURRENT_DATE(), firstClientEventID, lastClientEventID, lastClientEventDateTime, (SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEvent)
FROM rpt_main_02.arc_clientEventLookup;

# Dates for Partitions
SELECT MIN(date(eventDateTime)) INTO @minInsertClientEventDate FROM rpt_main_02.arc_clientEvent where clientEventID > @maxClientEventID;
SELECT MAX(date(eventDateTime)) INTO @maxInsertClientEventDate FROM rpt_main_02.arc_clientEvent where clientEventID > @maxClientEventID;

call rpt_main_02.add_partitions('rpt_main_02.stg_dailyClientEvents',@minInsertClientEventDate,@maxInsertClientEventDate);

INSERT rpt_main_02.stg_dailyClientEvents
SELECT * FROM rpt_main_02.arc_clientEvent
WHERE clientEventID > @maxClientEventID;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep1");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep2");

SELECT MIN(date(eventDateTime)) INTO @minDeletePartitionDate FROM rpt_main_02.stg_dailyClientEvents;
SELECT Date_Sub(@minInsertClientEventDate, interval 1 day) INTO @maxDeletePartitionDate;

call rpt_main_02.drop_partitions('rpt_main_02.stg_dailyClientEvents',@minDeletePartitionDate,@maxDeletePartitionDate);

-- DELETE FROM rpt_main_02.stg_dailyClientEvents WHERE clientEventID <= @maxClientEventID;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep2");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep3");

DROP TABLE if EXISTS rpt_main_02.stg_dailyClientEventRollup;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_dailyClientEventRollup (userID BIGINT, dailyClientEvents INT, primary key (userID));

INSERT rpt_main_02.stg_dailyClientEventRollup SELECT arc_sessionLog.userID, COUNT(clientEventID) AS dailyClientEvents 
FROM rpt_main_02.stg_dailyClientEvents 
JOIN rpt_main_02.arc_sessionLog ON stg_dailyClientEvents.sessionlogID = arc_sessionLog.sessionLogID
WHERE stg_dailyClientEvents.clientEventID > @maxClientEventID
GROUP BY arc_sessionLog.userID;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep3");



/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep4");

INSERT rpt_main_02.rpt_clientLogCountsByUserArchived (userID, lifetimeLogCount)
SELECT u.userID, 0 FROM rpt_main_02.userAccount u 
LEFT JOIN rpt_main_02.rpt_clientLogCountsByUserArchived r ON u.userID=r.userID
WHERE r.userID IS NULL;

UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
JOIN rpt_main_02.stg_dailyClientEventRollup ON clcua.userID = stg_dailyClientEventRollup.userID 
SET clcua.lifetimeLogCount = clcua.lifetimeLogCount + stg_dailyClientEventRollup.dailyClientEvents;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived lifetimeLogCountStep4");


-- If logcounts are lost, recalculate for all users
-- Might want to try to find a way to do a shorter calc in the future.
-- UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
-- SET clcua.lifetimeLogCount =
-- (SELECT SUM(r.logCount) FROM rpt_main_02.arc_clientEventRollup r WHERE r.insertByUserID = clcua.userID);

/*Start rpt_main_02.rpt_clientLogCountsByUserArchived firstDayLogCount*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived firstDayLogCount");

 SET AUTOCOMMIT = 0;
 UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
 JOIN rpt_main_02.userAccount u ON clcua.userID = u.userID
 SET clcua.firstDayLogCount =
	  (SELECT SUM(r.logCount) FROM rpt_main_02.arc_clientEventRollup r
	  /* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
 	 /* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	  WHERE r.insertByUserID = u.userID AND r.logDate <= DATE_ADD(u.insertDateTime, INTERVAL 12 HOUR)
 	 )
 WHERE u.insertDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -10 DAY)  /*Try to keep this synced with TableauTrialUpdate*/
 ; 
 COMMIT;
 SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived firstDayLogCount");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived firstDayTrialLogCount");

 SET AUTOCOMMIT = 0;
 UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
 JOIN rpt_main_02.rpt_trials ON clcua.userID = rpt_trials.userID AND firstTrial = 1 AND trialType = 1
 SET clcua.firstDayTrialLogCount =
 	(SELECT SUM(r.logCount) FROM rpt_main_02.arc_clientEventRollup r
 	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
 	 /* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
 	WHERE r.insertByUserID = rpt_trials.userID AND r.logDate <= DATE_ADD(rpt_trials.trialDateTime, INTERVAL 12 HOUR)
 	)
 WHERE rpt_trials.trialDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -10 DAY)  /*Try to keep this synced with TableauTrialUpdate*/
 ;
 COMMIT;
	
UPDATE rpt_main_02.rpt_clientLogCountsByUserArchived clcua
  JOIN rpt_main_02.rpt_paymentProfile p ON clcua.userID = p.ownerID AND p.accountType IN (1,2)
SET clcua.paymentProfileID = p.paymentProfileID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByUserArchived firstDayTrialLogCount");


select "******************************************************************************************************************************", NOW();
select "******** arc_wellQualifiedLeads - start ******** ", NOW();

/*Start rpt_main_02.arc_wellQualifiedLeads*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_wellQualifiedLeads");


SELECT MAX(snapshotDate) INTO @maxSnapshotDate 		/* find lastest snapshot date, used to return a null set instead of an error if this is run twice. */
FROM rpt_main_02.arc_wellQualifiedLeads;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_wellQualifiedLeads(snapshotDate, userID, loginStrength, lifetimeLogCount, sheetCount, sharingCount, leadStrength, associatedWithPaidAccount)
SELECT 	
CURRENT_DATE(),
userAccount.userID, 
rpt_loginCountTotal.loginStrength,
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
rpt_containerCountsByUser.sheetCount,
rpt_featureCountRollupByUser.sharingCount,

(rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  
* (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) AS leadStrength,

CASE rpt_containerCountsByUser.sheetsSharedFromPaidAccount > 0
	WHEN 1 THEN 1
	ELSE 0 END 

FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  FORCE INDEX (idx_rpt_paymentProfileSourceUserID)	ON userAccount.userID = rpt_paymentProfile.sourceUserID 
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 		ON userAccount.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser FORCE INDEX (PRIMARY)	ON userAccount.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser FORCE INDEX (PRIMARY) ON userAccount.userID = rpt_featureCountRollupByUser.userID
  
WHERE (rpt_paymentProfile.productID = 1 OR 
     (rpt_paymentProfile.productID = 2 AND DATEDIFF(CURRENT_DATE(), userAccount.insertDateTime) <= 30))
	AND rpt_main_02.rpt_paymentProfile.accountType != 3
	AND @maxSnapshotDate < CURRENT_DATE()

GROUP BY 1,2

HAVING leadStrength > 0.05
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_wellQualifiedLeads");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_trials table - start ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_trials");


SELECT MAX(trialDateTime) INTO @maxTrialDate FROM rpt_main_02.rpt_trials; /*Select most recent trial to append from*/

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_trials(
	paymentProfileID,
	trialType,
	userID, 
	trialDateTime,
	trialEndDateTime,
	firstTrial,
	trialSessionID)

SELECT  
	hpp.paymentProfileID,
	hpp.accountType,
	ppc.userID,
	hpp.modifyDateTime,
	MIN(hppNext.modifyDateTime),
	CASE WHEN hppOld.productID IS NULL THEN 1 ELSE 0 END, /* First time is a trial in which the user did not previously have a payment Profile*/
	hpp.sessionLogID
	
FROM rpt_main_02.hist_paymentProfile hpp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hppOld ON hpp.paymentProfileID = hppOld.paymentProfileID 
	AND (hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND OR hpp.modifyDateTime = hppOld.hist_effectiveThruDateTime)   /*Compare to previous hist_paymentProfile entry */
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hppNext ON hppNext.paymentProfileID = hpp.paymentProfileID 
	AND hppNext.modifyDateTime > hpp.modifyDateTime AND hppNext.productID != 1 /*Compare to next non-trial hist_paymentProfile entry */
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = hpp.paymentProfileID

WHERE hpp.productID = 1
AND (hppOld.productID != 1 OR hppOld.productID IS NULL) /*Eliminates instance of trials being extended, previous hist_paymentProfile was also a trial  */
AND hpp.modifyDateTime > @maxTrialDate  

GROUP BY 1,4  /*Group to avoid the bug where a PP is not properly updated in hist_paymentProfile (example: PPid: 3054062)*/

ORDER BY hpp.modifyDateTime
;
COMMIT;

UPDATE rpt_main_02.rpt_trials
	SET trialEndDateTime = (SELECT MIN(hppNext.modifyDateTime) FROM rpt_main_02.hist_paymentProfile hppNext 
	WHERE hppNext.paymentProfileID = rpt_trials.paymentProfileID AND hppNext.modifyDateTime > rpt_trials.trialDateTime AND hppNext.productID != 1)
	WHERE trialEndDateTime IS NULL
;
COMMIT;

UPDATE rpt_main_02.rpt_trials
	SET gettingStartedOpen = (SELECT MIN(arc_clientEvent.eventDateTime) FROM rpt_main_02.arc_clientEvent 
	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 1)
	WHERE gettingStartedOpen IS NULL AND trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND trialSessionID != 0
;
COMMIT;

 UPDATE rpt_main_02.rpt_trials
 	SET gettingStartedClose = (SELECT MIN(arc_clientEvent.eventDateTime) FROM rpt_main_02.arc_clientEvent 
 	WHERE rpt_trials.trialSessionID = arc_clientEvent.sessionLogID 
 	AND arc_clientEvent.objectID IN (7014, 12017) AND arc_clientEvent.actionID = 2)
 	WHERE gettingStartedClose IS NULL AND trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND trialSessionID != 0
 ;
 COMMIT;
	
 UPDATE rpt_main_02.rpt_trials
 SET rpt_trials.restartFirstDayLogCount  =
 	(SELECT SUM(r.logCount) FROM rpt_main_02.arc_clientEventRollup r
	 /* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
 	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
 	WHERE r.insertByUserID = rpt_trials.userID 
 	AND r.logDate BETWEEN DATE_FORMAT(rpt_trials.trialDateTime, '%Y-%m-%d') AND DATE_ADD(DATE_FORMAT(rpt_trials.trialDateTime, '%Y-%m-%d'), INTERVAL 12 HOUR)) 
 WHERE rpt_trials.trialDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -5 DAY) AND firstTrial = 0
 ;
 COMMIT;
 SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_trials");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** organizationUserRole ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.organizationUserRole");

CREATE TABLE IF NOT EXISTS rpt_main_02.organizationUserRole LIKE ss_core_02.organizationUserRole;
TRUNCATE TABLE rpt_main_02.organizationUserRole;

INSERT INTO rpt_main_02.organizationUserRole 
(
	organizationUserRoleId,
	organizationID,
	userID,
	role,
	state,
	insertDateTime,
	insertByUserID,
	modifyDateTime,
	modifyByUserID,
	sessionLogID,
	dataTimestamp
)
SELECT 
	ss.organizationUserRoleId,
	ss.organizationID,
	ss.userID,
	ss.role,
	ss.state,
	ss.insertDateTime,
	ss.insertByUserID,
	ss.modifyDateTime,
	ss.modifyByUserID,
	ss.sessionLogID,
	ss.dataTimestamp
FROM ss_core_02.organizationUserRole ss

WHERE ss.modifyDateTime <= @NewMaxorgUserModifyDate
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.organizationUserRole");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.arc_sourceUser_firstWinProduct ******** ", NOW();
/*This table contains the productID, paymentTerm, and paymentType of sourceUsers for the 1st time they become a Win*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_sourceUser_firstWinProduct");

DROP TABLE IF EXISTS rpt_main_02.arc_sourceUser_firstWinProduct;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_sourceUser_firstWinProduct
(
	paymentProfileID BIGINT,
	sourceUserID BIGINT,
	productID INT,
	paymentTerm INT,
	paymentType INT,
	planRate_USD DECIMAL (38,10),
	currencyCode VARCHAR(5),
	exchangeRate DECIMAL(38,10),
	winDate DATETIME,
	userLimit INT,
	PRIMARY KEY (sourceUserID),
	KEY ix_ppID (paymentProfileID)
)
;

DROP TABLE IF EXISTS rpt_main_02.stg_minWinProduct1;

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_minWinProduct1
(
	paymentProfileID BIGINT,
	sourceUserID BIGINT,
	minModifyDateTime DATETIME,
	PRIMARY KEY (paymentProfileID),
		KEY ix_sourceUser (sourceUserID),
        KEY ix_mdt (minModifyDateTime)
)
;

INSERT INTO rpt_main_02.stg_minWinProduct1 (paymentProfileId, sourceUserID, minModifyDateTime)
SELECT hpp.paymentProfileID, pp.sourceUserID, MIN(hpp.modifyDateTime) AS minModifyDateTime
FROM rpt_main_02.hist_paymentProfile hpp
LEFT JOIN rpt_main_02.rpt_paymentProfile pp ON hpp.paymentProfileID=pp.paymentProfileID
WHERE hpp.productID >=3
AND hpp.planRate > 0
GROUP BY 1,2
;

UPDATE rpt_main_02.stg_minWinProduct1 stg
JOIN
(
	SELECT sourceUserID, MIN(minModifyDateTime) AS minModifyDateTime
	FROM rpt_main_02.stg_minWinProduct1 m
	GROUP BY sourceUserID
) s
ON stg.sourceUserID=s.sourceUserID
SET stg.minModifyDateTime = s.minModifyDateTime
;


INSERT IGNORE rpt_main_02.arc_sourceUser_firstWinProduct
SELECT 
hpp.paymentProfileID, 
mwp.sourceUserID, 
hpp.productID, 
hpp.paymentTerm, 
hpp.paymentType, 
hpp.planRate_USD, 
hpp.currencyCode,
hce.exchangeRate,
mwp.minModifyDateTime, 
hpp.userLimit
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.stg_minWinProduct1 mwp ON hpp.paymentProfileID=mwp.paymentProfileID 
	AND hpp.modifyDateTime=mwp.minModifyDateTime
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON hpp.currencyCode=hce.currencyCode COLLATE utf8mb4_unicode_520_ci
	AND hpp.modifyDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE hpp.productID >= 3
AND hpp.planRate > 0
AND hpp.paymentType IN(1,2,3,6,8,10)
AND hpp.hist_effectiveThruDateTime <= '9999-12-31 23:59:59'
;

DROP TABLE IF EXISTS rpt_main_02.stg_minWinProduct1;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_sourceUser_firstWinProduct");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_main_02.arc_cDunn_wslfOverTime ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_cDunn_wslfOverTimeUpdate");

DROP TABLE IF EXISTS rpt_main_02.arc_cDunn_wslfOverTime;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_cDunn_wslfOverTime
(userID INT,
paymentProfileID INT,
trialDateTime DATETIME,
ipCountry VARCHAR(50),
ipRegion VARCHAR(50),
ipCity VARCHAR(50),
TrialStartMonth VARCHAR(20),
IsStrongLead TINYINT,
hasPaid TINYINT,
KEY ix_userID (userID),
KEY ix_paymentProfileID (paymentProfileID));

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTime (userID, paymentProfileID, trialDateTime, ipCountry, ipRegion, ipCity, TrialStartMonth, IsStrongLead, hasPaid)

SELECT t.userID, t.paymentProfileID, t.trialDateTime, ip.ipCountry, ip.ipRegion, ip.ipCity, DATE_FORMAT(t.trialDateTime, '%Y-%m(%b)'),

	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0 END,
	
	CASE pp.hasPaid IS NULL
		WHEN 1 THEN 0
		ELSE pp.hasPaid END
	
	
FROM rpt_main_02.rpt_trials t
JOIN rpt_main_02.userAccount u ON u.userID = t.userID
JOIN rpt_main_02.rpt_paymentProfile pp ON t.paymentProfileID = pp.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON u.userID = rpt_clientLogCountsByUserArchived.userID
WHERE t.firstTrial = 1 AND t.trialType IN(1,3)
AND t.trialDateTime >= '2013-01-01 00:00:00'
AND DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY 1,2
ORDER BY 3
LIMIT 12345678;


DROP TABLE IF EXISTS rpt_main_02.arc_cDunn_wslfOverTimeGrouped;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_cDunn_wslfOverTimeGrouped
(userID INT,
paymentProfileID INT,
trialDateTime DATETIME,
ipCountry VARCHAR(50),
IsStrongLead TINYINT,
hasPaid TINYINT,
TrialStartMonth VARCHAR(20),
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTimeGrouped (userID, paymentProfileID, trialDateTime, ipCountry, IsStrongLead, hasPaid, TrialStartMonth)
SELECT A.userID, A.paymentProfileID, A.trialDateTime, A.ipCountry, MAX(A.IsStrongLead), MAX(A.hasPaid), A.TrialStartMonth
FROM rpt_main_02.arc_cDunn_wslfOverTime A
WHERE DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY 1;

DROP TABLE IF EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary (
IPCountry      VARCHAR(200),
Trials		INT,
isStrongLead   INT,
totalConversions INT,
strongLeadConversions INT,
conversionRateFromStrongLeads DECIMAL (10,5),
weightedStrongLeadFactor DECIMAL (10,5),
trialMonth VARCHAR(30),
monthSequence INT,
trialMonthStartDate DATETIME,
trialMonthEndDate DATETIME,
insertDateTime  TIMESTAMP DEFAULT  CURRENT_TIMESTAMP,
KEY ix_country (IPCountry));

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary(
IPCountry,
Trials,
isStrongLead,
totalConversions,
strongLeadConversions,
conversionRateFromStrongLeads,
trialMonth,
monthSequence,
trialMonthStartDate,
trialMonthEndDate)

SELECT A.ipCountry, COUNT(DISTINCT(A.userID)), COUNT(DISTINCT(B.userID)), SUM(A.hasPaid), SUM(B.hasPaid),
(SUM(B.hasPaid))/(COUNT(DISTINCT(B.userID))), A.TrialStartMonth, months.monthSequence, months.startMonth, months.endMonth

FROM rpt_main_02.arc_cDunn_wslfOverTimeGrouped A
LEFT OUTER JOIN rpt_main_02.arc_cDunn_wslfOverTimeGrouped B ON A.userID = B.userID AND B.IsStrongLead = 1
LEFT OUTER JOIN rpt_main_02.ref_months months ON months.monthFriendly = A.TrialStartMonth

WHERE DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY A.ipCountry, A.TrialStartMonth
LIMIT 123456789
;

/* Updates to wslf update */

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTimeUpdate
SELECT B.IPCountry, 0, 0, 0, 0, 0, 0, DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)'), m.monthSequence, m.startMonth, m.endMonth, 0 
FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary B
LEFT OUTER JOIN rpt_main_02.ref_months m ON m.monthFriendly = B.trialMonth AND DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)') = m.monthFriendly
WHERE DAYOFMONTH(CURRENT_DATE) = 1
GROUP BY B.IPCountry;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate A
SET monthSequence = (SELECT m.monthSequence FROM rpt_main_02.ref_months m WHERE m.monthFriendly = A.trialMonth),


trialMonthStartDate = (SELECT m.startMonth FROM rpt_main_02.ref_months m WHERE m.monthFriendly = A.trialMonth),


trialMonthEndDate = (SELECT m.endMonth FROM rpt_main_02.ref_months m WHERE m.monthFriendly = A.trialMonth)
WHERE DAYOFMONTH(CURRENT_DATE) = 1;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate wslf
SET Trials = (SELECT A.Trials FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary A
WHERE A.ipCountry = wslf.ipCountry AND A.trialMonth = wslf.trialMonth),

isStrongLead = (SELECT A.isStrongLead FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary A
WHERE A.ipCountry = wslf.ipCountry AND A.trialMonth = wslf.trialMonth),

totalConversions  = (SELECT A.totalConversions FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary A
WHERE A.ipCountry = wslf.ipCountry AND A.trialMonth = wslf.trialMonth),

strongLeadConversions = (SELECT A.strongLeadConversions FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary A
WHERE A.ipCountry = wslf.ipCountry AND A.trialMonth = wslf.trialMonth),

conversionRateFromStrongLeads = (SELECT A.conversionRateFromStrongLeads FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateTemporary A
WHERE A.ipCountry = wslf.ipCountry AND A.trialMonth = wslf.trialMonth)
WHERE DAYOFMONTH(CURRENT_DATE) = 1;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate
SET weightedStrongLeadFactor = 1 WHERE IPCountry = 'United States'
AND DAYOFMONTH(CURRENT_DATE) = 1;

DROP TABLE IF EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUSA;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUSA
(IPCountry      VARCHAR(200),
Trials		INT,
isStrongLead   INT,
totalConversions INT,
strongLeadConversions INT,
conversionRateFromStrongLeads DECIMAL (10,5),
trialMonth VARCHAR(30),
monthSequence INT,
trialMonthStartDate DATETIME,
trialMonthEndDate DATETIME,
KEY ix_country (IPCountry));

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTimeUSA 
(IPCountry, Trials, isStrongLead, totalConversions, strongLeadConversions, conversionRateFromStrongLeads, trialMonth, monthSequence, trialMonthStartDate, trialMonthEndDate)
SELECT A.IPCountry, A.Trials, A.isStrongLead, A.totalConversions, A.strongLeadConversions, A.conversionRateFromStrongLeads, A.trialMonth, A.monthSequence, A.trialMonthStartDate, A.trialMonthEndDate 
FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdate A WHERE A.IPCountry = 'United States'
AND DAYOFMONTH(CURRENT_DATE) = 1;

DROP TABLE IF EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUpdateCopy;
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_cDunn_wslfOverTimeUpdateCopy
(IPCountry      VARCHAR(200),
Trials		INT,
isStrongLead   INT,
totalConversions INT,
strongLeadConversions INT,
conversionRateFromStrongLeads DECIMAL (10,5),
trialMonth VARCHAR(30),
monthSequence INT,
trialMonthStartDate DATETIME,
trialMonthEndDate DATETIME,
KEY ix_country (IPCountry));

INSERT INTO rpt_main_02.arc_cDunn_wslfOverTimeUpdateCopy 
(IPCountry, Trials, isStrongLead, totalConversions, strongLeadConversions, conversionRateFromStrongLeads, trialMonth, monthSequence, trialMonthStartDate, trialMonthEndDate)
SELECT A.IPCountry, A.Trials, A.isStrongLead, A.totalConversions, A.strongLeadConversions, A.conversionRateFromStrongLeads, A.trialMonth, A.monthSequence, A.trialMonthStartDate, A.trialMonthEndDate 
FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdate A
WHERE DAYOFMONTH(CURRENT_DATE) = 1;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate A 
SET A.weightedStrongLeadFactor = (SELECT ((SUM(C.strongLeadConversions)/SUM(C.isStrongLead))/(SUM(B.strongLeadConversions)/SUM(B.isStrongLead)))
FROM rpt_main_02.arc_cDunn_wslfOverTimeUpdateCopy C 
	JOIN rpt_main_02.arc_cDunn_wslfOverTimeUSA B ON C.trialMonth = B.trialMonth
WHERE C.IPCountry = A.IPCountry AND (C.monthSequence IN((A.monthSequence-2), (A.monthSequence-3), (A.monthSequence-4), (A.monthSequence-5), (A.monthSequence-6), (A.monthSequence-7) )))
WHERE A.trialMonth = DATE_FORMAT(CURRENT_DATE, '%Y-%m(%b)')
AND DAYOFMONTH(CURRENT_DATE) = 1
;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate
SET weightedStrongLeadFactor = 1 WHERE weightedStrongLeadFactor > 1
AND DAYOFMONTH(CURRENT_DATE) = 1;

UPDATE rpt_main_02.arc_cDunn_wslfOverTimeUpdate
SET weightedStrongLeadFactor = 0 WHERE weightedStrongLeadFactor IS NULL
AND DAYOFMONTH(CURRENT_DATE) = 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_cDunn_wslfOverTimeUpdate");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_salesMarketingUserData ******** ", NOW();

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_salesMarketingUserData");


/* CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_salesMarketingUserData LIKE ss_core_02.salesMarketingUserData; */

SELECT MAX(salesMarketingUserDataID) FROM rpt_main_02.rpt_salesMarketingUserData  INTO @maxUserDataID;

INSERT rpt_main_02.rpt_salesMarketingUserData 
SELECT * FROM ss_core_02.salesMarketingUserData  
WHERE salesMarketingUserDataID > @maxUserDataID and salesMarketingUserDataID <= @NewMaxuserDataID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_salesMarketingUserData");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_optimizelyExperiments");

SELECT MAX(signupRequestID) INTO @OptimizelySignupRequestID 		
FROM rpt_main_02.rpt_optimizelyExperiments;  

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(optimizelyExpID,':',1),'"',''),'{','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID, ':',-1),',',1),'"',''),'}','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID NOT LIKE "%,%";

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-1),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-1),':',-1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%";

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-2),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-2),':',-2),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%";

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-3),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-3),':',-3),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >54;

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-4),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-4),':',-4),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >80;

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-5),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-5),':',-5),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >106;

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-6),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-6),':',-6),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >132;

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-7),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-7),':',-7),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >158;

INSERT INTO rpt_main_02.rpt_optimizelyExperiments
SELECT userID, signupRequestID,
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-8),':',1),'{',''),'"','') AS experiment, 
REPLACE(REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(optimizelyExpID,',',-8),':',-8),',',1),'}',''),'"','') AS variation 
FROM rpt_main_02.rpt_signupSource WHERE signupRequestID > @OptimizelySignupRequestID
AND optimizelyexpID IS NOT NULL AND optimizelyexpID != "{}" AND optimizelyexpID LIKE "%,%" AND CHAR_LENGTH(optimizelyexpID) >184;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_optimizelyExperiments");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_workspace.cDunn_roleFormClick");

SELECT MAX(logDate) FROM rpt_workspace.cDunn_roleFormClicks INTO @maxRoleClick;

DELETE FROM rpt_workspace.cDunn_roleFormClicks WHERE logDate >= @maxRoleClick;

INSERT INTO rpt_workspace.cDunn_roleFormClicks
SELECT insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int, logCount FROM rpt_main_02.arc_clientEventRollup WHERE objectID = 7126 AND actionID = 1 AND logDate >= @maxRoleClick;

DROP TABLE IF EXISTS rpt_workspace.cDunn_roleFormClicksRollup;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_roleFormClicksRollup
(userID BIGINT,
logDate DATETIME,
objectID INT,
actionID INT,
logCount INT,
 PRIMARY KEY (userID));

INSERT INTO rpt_workspace.cDunn_roleFormClicksRollup
SELECT insertByUserID, MIN(logDate), objectID, actionID, logCount
FROM rpt_workspace.cDunn_roleFormClicks
GROUP BY 1;
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_workspace.cDunn_roleFormClick");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** Throwaway Part 2: Trials - end ******** ", NOW();
/*End*/


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Throwaway Part 2: Trials");