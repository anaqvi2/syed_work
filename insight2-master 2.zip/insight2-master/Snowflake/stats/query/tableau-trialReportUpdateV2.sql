set session transaction isolation level read uncommitted;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-trialReportUpdateV2.sql");

/*Generating trialsBySourceRaw_V2.csv*/
DROP TABLE IF EXISTS rpt_main_02.stg_salesforceLeadSource;
CREATE TEMPORARY TABLE IF NOT EXISTS rpt_main_02.stg_salesforceLeadSource
(userID BIGINT,
insertDateTime DATETIME,
salesforceLeadSource VARCHAR(50),
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_salesforceLeadSource
SELECT userID, insertDateTime, salesforceLeadSource
FROM leadflow.arc_marketo_upload
WHERE insertDateTime >= DATE_SUB(CURRENT_DATE, INTERVAL 45 DAY);

INSERT IGNORE INTO rpt_main_02.stg_teamTrialMembers
SELECT u.userID, org.insertDateTime, org.insertByUserID, org.modifyDateTime, org.state, org.organizationID, ss.bucket, 
ss.sourceFriendly, ss.subSourceFriendly, ss.campaign, pp.paymentProfileID, ip.ipCountry, ip.ipRegion, ip.ipCity, u.languageFriendly, lct.loginCount, u.domain,
CASE WHEN isp.domain IS NOT NULL THEN 1 ELSE 0 END,
u.emailAddress
FROM rpt_main_02.userAccount u
JOIN rpt_main_02.organizationUserRole org ON org.userID = u.userID AND org.role = 'LICENSE_USER'
JOIN rpt_main_02.organization o ON o.organizationID = org.organizationID
JOIN rpt_main_02.rpt_paymentProfile pp ON o.paymentProfileID = pp.paymentProfileID AND pp.productID = 1
JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = u.userID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = u.domain
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = u.userID AND hpp.productID = 1 AND hpp.parentPaymentProfileID IS NOT NULL
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ss ON ss.userID = u.userID
WHERE org.insertDateTime >= '2016-02-28' AND org.insertDateTime = u.insertDateTime
;

UPDATE rpt_main_02.stg_teamTrialMembers A
JOIN rpt_main_02.organizationUserRole org ON org.userID = A.userID AND org.organizationID = A.organizationID AND org.state = 1
SET A.state = org.state,
A.orgModifyDate = org.modifyDateTime;

DELETE FROM rpt_main_02.stg_tableauTrialReport WHERE TrialStartDate > DATE_ADD(NOW(),INTERVAL -10 DAY);

SELECT MAX(DATE_FORMAT(TrialStartDate,'%Y-%m-%d')) FROM rpt_main_02.stg_tableauTrialReport INTO @maxTrialStartDate;

INSERT IGNORE INTO rpt_main_02.stg_tableauTrialReport
SELECT rpt_trials.paymentProfileID,
	rpt_paymentProfile.accountType,
	u.locale,
	DATE_FORMAT(rpt_trials.trialDateTime, '%Y'),
	rpt_trials.trialDateTime,
	DATE_FORMAT(rpt_trials.trialDateTime, '%Y*%m(%b)'),	
	rpt_main_02.SMARTSHEET_WEEK(rpt_trials.trialDateTime),

	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket
	END,
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END,
	
	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END,

	rpt_signupSource.segment,
	
	MAX(rpt_paymentProfile.countAsPaid),
	
	MAX(rpt_paymentProfile.hasPaid),
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN 0  
		ELSE 1 END,
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END,
	
	CASE WHEN rpt_signupSource.bucket IS NULL OR rpt_signupSource.bucket = "Viral"
		THEN CASE rpt_clientLogCountsByUserArchived.firstDayTrialLogCount  > 150 WHEN 1 THEN 1 ELSE 0 END
		ELSE CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 WHEN 1 THEN 1 ELSE 0 END
	END,
	
	COUNT(snapshotDate),
	
	CASE WHEN COUNT(snapshotDate) > 0 THEN 1 ELSE 0 END,
	
rpt_userIPLocation.ipCountry,
rpt_userIPLocation.ipRegion,
rpt_userIPLocation.ipCity,

CASE WHEN rpt_trials.trialDateTime < '2014-06-01 00:00:00' THEN ref_weightedStrongLeadFactor.weightedStrongLeadFactor
ELSE wslf.weightedStrongLeadFactor END,

u.languageFriendly,
sfdc.salesforceLeadSource,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_paymentProfile.productID) AS CurrentProduct,
CASE 
	WHEN rpt_signupSource.campaign IS NULL THEN 
	(CASE WHEN rpt_signupSource.slp = '' THEN "Homepage" ELSE rpt_signupSource.slp END)
	ELSE rpt_signupSource.campaign
END,
CASE WHEN rpt_signupSource.appLaunchType IN (2,12,5) THEN rpt_signupSource.appLaunchParm1Friendly ELSE NULL END,
rpt_trials.userID,
lct.loginCount,
rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID),
(fwp.planRate_USD/fwp.paymentTerm),
MAX(rpt_paymentProfile.daysToBuy),
rpt_trials.trialType,
role.dataValue,
fwp.winDate,
fwp.paymentTerm,
CASE WHEN team.userID IS NOT NULL THEN 1 ELSE 0 END,
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialDateTime) <= 30 THEN 1 ELSE 0 END,
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialDateTime) <= 60 THEN 1 ELSE 0 END,
rpt_paymentProfile.productName,
rpt_trials.trialEndDateTime,
u.domain,
CASE WHEN isp.domain IS NULL THEN 'Org Domain' ELSE 'ISP Domain' END,
CASE WHEN DATEDIFF(fwp.winDate, rpt_trials.trialEndDateTime) <= 10 THEN 1 ELSE 0 END,
ref_trpValues.trpCategory,
CONCAT(rpt_signupSource.trpValue, " ", IF(ref_trpValues.trpName IS NULL, "UNKNOWN TRP VALUE",ref_trpValues.trpName )),
rpt_signupSource.signupInsertDateTime,
fwp.userLimit,
apiClient.name AS APIClientName,
0,
0,
0,
CASE WHEN acc.Fortune_1000_Rank__c > 0 THEN 1 ELSE 0 END,
CASE WHEN l.Accepted_Date_Time__c IS NOT NULL THEN 1 ELSE 0 END,
CASE WHEN l.ConvertedDate IS NOT NULL THEN 1 ELSE 0 END,
l.Activity_Count__c,
CONCAT(rep.firstName,' ',rep.lastName),
l.Fit_Score__c,
l.Fit_Rating_SFDC__c,
l.mkto_si__Relative_Score_Value__c,
sl.device,
sl.browserBucket,
CASE WHEN sl.loginType IN('Google OAuth2', 'Google OAuth2 New') THEN 1 ELSE 0 END,
CASE WHEN sl.loginType = 'MS Azure AD' THEN 1 ELSE 0 END,
ur.Name,
rep.Id,
rpt_signupSource.slp,
0,
NULL,
u.emailAddress,
NULL,
NULL,
NULL,
NULL,
NULL,
NULL,
NULL,
'TrialOwner',
rpt_signupSource.landingPageVersion,
rpt_signupSource.lpa,
CURRENT_DATE,
rpt_signupSource.lang,
NULL AS 'newLogo',
NULL AS 'A13Region',
NULL AS 'market',
rpt_signupSource.exp,
NULL,
NULL as 'companySize'
FROM rpt_main_02.rpt_trials rpt_trials
JOIN rpt_main_02.userAccount u ON rpt_trials.userID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile ON rpt_paymentProfile.sourceUserID = rpt_trials.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource  ON u.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY)	ON u.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON arc_wellQualifiedLeads.userID = rpt_trials.userID AND associatedWithPaidAccount = 0
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = u.userID
LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON rpt_userIPLocation.ipCountry = ref_weightedStrongLeadFactor.IPCountry
LEFT OUTER JOIN rpt_main_02.arc_cDunn_wslfOverTimeUpdate wslf 	ON wslf.IPCountry = rpt_userIPLocation.ipCountry
	AND rpt_trials.trialDateTime BETWEEN wslf.trialMonthStartDate AND wslf.trialMonthEndDate
LEFT OUTER JOIN rpt_main_02.stg_salesforceLeadSource sfdc ON u.userID = sfdc.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = u.userID
LEFT OUTER JOIN rpt_main_02.arc_sourceUser_firstWinProduct fwp ON fwp.sourceUserID = u.userID
LEFT OUTER JOIN rpt_main_02.rpt_salesMarketingUserData role ON role.userID = u.userID AND role.dataKey = 'role'
LEFT OUTER JOIN rpt_main_02.rpt_trials team ON team.userID = u.userID 
	AND team.trialType = 3 AND team.firstTrial = 1
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = u.domain
LEFT OUTER JOIN rpt_main_02.ref_trpValues ON rpt_signupSource.trpValue = ref_trpValues.trpValue
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem ON rpt_signupRequestTrackingItem.signupRequestID = rpt_signupSource.signupRequestID 
	AND rpt_signupRequestTrackingItem.itemName = "client_id"
LEFT OUTER JOIN rpt_main_02.apiClient ON apiClient.clientID = rpt_signupRequestTrackingItem.itemValue
LEFT OUTER JOIN ss_sfdc_02.lead l FORCE INDEX (ppID) ON l.paymentProfileID__c = rpt_trials.paymentProfileID
LEFT OUTER JOIN ss_sfdc_02.user rep ON rep.Id = l.OwnerId
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog sl ON sl.sessionLogID = lct.firstSessionLogID
LEFT OUTER JOIN ss_sfdc_02.user_role ur ON ur.Id = rep.UserRoleId
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = u.domain
LEFT OUTER JOIN ss_sfdc_02.account acc ON d.Account__c = acc.Id

WHERE rpt_trials.firstTrial = 1 AND rpt_trials.trialType = 1 AND rpt_trials.trialDateTime >= @maxTrialStartDate AND u.domain != 'smartsheet.com' AND rpt_trials.trialDateTime >= '2013-01-01'

GROUP BY 1
ORDER BY rpt_trials.trialDateTime DESC
;


UPDATE rpt_main_02.stg_tableauTrialReport A
SET campaign = 'Null' WHERE A.campaign IS NULL;

/* 
UPDATE rpt_main_02.stg_tableauTrialReport A
SET wslQ4Ratio = (SELECT B.WSLRatio
	FROM rpt_workspace.cDunn_jan2015WSLCounts B
	WHERE B.bucket = A.bucket AND B.source = A.SignupSourceFriendly AND B.subSource = A.SignupSubSourceFriendly AND B.campaign = A.campaign) 
		WHERE (A.TrialStartDate >= '2015-01-01' AND TrialStartDate <= '2015-03-31') OR (A.TrialStartDate >= '2015-07-11 00:00:00' AND A.TrialStartDate <= '2015-07-15 23:59:59')
			OR (A.TrialStartDate >= '2015-11-05 00:00:00' AND A.TrialStartDate <= '2015-11-07 23:59:59');

UPDATE rpt_main_02.stg_tableauTrialReport A
SET wslDecRatio = (SELECT B.WSLRatio
	FROM rpt_workspace.cDunn_dec2015WSLCounts B
	WHERE B.bucket = A.bucket AND B.source = A.SignupSourceFriendly AND B.subSource = A.SignupSubSourceFriendly AND B.campaign = A.campaign) 
		WHERE (A.TrialStartDate >= '2015-01-01' AND TrialStartDate <= '2015-03-31') OR (A.TrialStartDate >= '2015-07-11 00:00:00' AND A.TrialStartDate <= '2015-07-15 23:59:59')
		OR (A.TrialStartDate >= '2015-11-05 00:00:00' AND A.TrialStartDate <= '2015-11-07 23:59:59');
*/
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET wslCombined = CASE WHEN A.TrialStartDate < '2015-01-01' THEN (A.IsStrongLeadAdjusted * A.weightedStrongLeadFactor)
			WHEN A.TrialStartDate >= '2015-04-01' THEN (A.IsStrongLeadAdjusted * A.weightedStrongLeadFactor)
			WHEN wslQ4Ratio IS NOT NULL THEN (A.IsStrongLeadAdjusted * A.wslQ4Ratio)
			WHEN wslQ4Ratio IS NULL AND wslDecRatio IS NOT NULL THEN (A.IsStrongLeadAdjusted * A.wslDecRatio)
			ELSE (A.IsStrongLeadAdjusted * 0.67) END WHERE A.IsStrongLeadAdjusted = 1;
			
UPDATE rpt_main_02.stg_tableauTrialReport A
SET weightedStrongLeadFactor = CASE WHEN wslQ4Ratio IS NOT NULL THEN wslQ4Ratio
					WHEN wslQ4Ratio IS NULL AND wslDecRatio IS NOT NULL THEN A.wslDecRatio
					ELSE 0.67 END 
		WHERE (A.TrialStartDate >= '2015-01-01' AND TrialStartDate <= '2015-03-31') OR (A.TrialStartDate >= '2015-07-11 00:00:00' AND A.TrialStartDate <= '2015-07-15 23:59:59')
		OR (A.TrialStartDate >= '2015-11-05 00:00:00' AND A.TrialStartDate <= '2015-11-07 23:59:59');
			
UPDATE rpt_main_02.stg_tableauTrialReport A
SET countAsPaid = (SELECT MAX(pp.countAsPaid) FROM rpt_main_02.rpt_paymentProfile pp WHERE pp.sourceUserID = A.userID);


UPDATE rpt_main_02.stg_tableauTrialReport A
SET hasPaid = (SELECT MAX(pp.hasPaid) FROM rpt_main_02.rpt_paymentProfile pp WHERE pp.sourceUserID = A.userID);

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.rpt_clientLogCountsByUserArchived clc ON clc.userID = A.userID
SET isStrongLead = CASE clc.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0 END WHERE A.isStrongLead = 0 OR A.isStrongLead IS NULL;

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.rpt_clientLogCountsByUserArchived clc ON clc.userID = A.userID
SET isStrongLeadAdjusted = CASE WHEN A.bucket IS NULL OR A.bucket = "Viral"
		THEN CASE clc.firstDayTrialLogCount  > 150 WHEN 1 THEN 1 ELSE 0 END
		ELSE CASE clc.firstDayLogCount  > 150 WHEN 1 THEN 1 ELSE 0 END
	END WHERE A.isStrongLeadAdjusted = 0 OR A.isStrongLead IS NULL;

	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET daysWellQualified = (SELECT COUNT(wq.snapshotDate) FROM rpt_main_02.arc_wellQualifiedLeads wq WHERE wq.userID = A.userID);


UPDATE rpt_main_02.stg_tableauTrialReport A
SET EverWellQual = (SELECT CASE WHEN COUNT(wq.snapshotDate) > 0 THEN 1 ELSE 0 END FROM rpt_main_02.arc_wellQualifiedLeads wq WHERE wq.userID = A.userID);

/* Insert Team Trial Members here */
INSERT IGNORE INTO rpt_main_02.stg_tableauTrialReport (userID, TrialStartDate, Bucket, SignupSourceFriendly, SignupSubSourceFriendly, IPCountry, IPRegion, IPCity, languageFriendly, loginCount,
	domain, OrgVsISP, emailAddress, trialUserType)
SELECT userID, orgModifyDate, 'Viral', 'Sharing', 'Team Trial Member', ipCountry, ipRegion, ipCity, languageFriendly, loginCount, domain,
CASE WHEN ispDomain = 1 THEN 'ISP Domain' ELSE 'Org Domain' END,
emailAddress, 'TeamTrialMember'
FROM rpt_main_02.stg_teamTrialMembers
WHERE state = 1;


/* Updates for new viral sourcing code */

DROP TABLE IF EXISTS rpt_main_02.stg_viralSourcingVirals;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_viralSourcingVirals
(userID BIGINT,
insertByUserID BIGINT,
domain VARCHAR(100),
insertByUserDomain VARCHAR(100),
isISP TINYINT,
insertByUserIsISP TINYINT,
sourceFriendly VARCHAR(100),
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_viralSourcingVirals
SELECT ttr.userID, u.insertByUserID, u.domain, uu.domain AS inserterDomain, 
CASE WHEN isp1.domain IS NOT NULL THEN 1 ELSE 0 END AS isISP,
CASE WHEN isp2.domain IS NOT NULL THEN 1 ELSE 0 END AS sharerIsISP,
CASE WHEN isp1.domain IS NOT NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to ISP)'
	WHEN isp1.domain IS NOT NULL AND isp2.domain IS NULL THEN 'Sharing (Org to ISP)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NOT NULL THEN 'Sharing (ISP to Org)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain = uu.domain THEN 'Sharing (Org to Org In Domain)'
	WHEN isp1.domain IS NULL AND isp2.domain IS NULL AND u.domain != uu.domain THEN 'Sharing (Org to Org Out Domain)'
		END AS sourceFriendly
FROM rpt_main_02.stg_tableauTrialReport ttr
JOIN rpt_main_02.userAccount u ON ttr.userID = u.userID
JOIN rpt_main_02.userAccount uu ON uu.userID = u.insertByUserID
LEFT JOIN rpt_main_02.arc_ISPDomains isp1 ON isp1.domain = u.domain
LEFT JOIN rpt_main_02.arc_ISPDomains isp2 ON isp2.domain = uu.domain
WHERE ttr.SignupSubSourceFriendly IN('Sharing','Team Trial Member')
AND ttr.TrialStartDate >= @maxTrialStartDate
GROUP BY 1
;

UPDATE rpt_main_02.stg_tableauTrialReport ttr
JOIN rpt_main_02.stg_viralSourcingVirals vsv ON vsv.userID = ttr.userID
SET ttr.SignupSourceFriendly = vsv.sourceFriendly;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET loginCount = (SELECT lct.loginCount FROM rpt_main_02.rpt_loginCountTotal lct WHERE lct.userID = A.userID);

UPDATE rpt_main_02.stg_tableauTrialReport A
SET firstWinProduct = (SELECT rpt_main_02.SMARTSHEET_PRODUCTNAME(fwp.productID) FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE A.hasPaid = 1;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET MRR = (SELECT (fwp.planRate_USD/fwp.paymentTerm) FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE A.hasPaid = 1;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET daysToBuy = (SELECT MAX(pp.daysToBuy) FROM rpt_main_02.rpt_paymentProfile pp WHERE pp.sourceUserID = A.userID) WHERE A.hasPaid = 1;


UPDATE rpt_main_02.stg_tableauTrialReport A
SET dataValue = (SELECT role.dataValue FROM rpt_main_02.rpt_salesMarketingUserData role WHERE role.userID = A.userID AND role.dataKey = 'role');

UPDATE rpt_main_02.stg_tableauTrialReport A
SET winDate = (SELECT fwp.winDate FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE A.hasPaid = 1;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET paymentTerm = (SELECT fwp.paymentTerm FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE A.hasPaid = 1;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET isFirst30DayWin = CASE WHEN DATEDIFF(A.winDate, A.TrialStartDate) <= 30 THEN 1 ELSE 0 END WHERE A.hasPaid = 1;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET isFirst60DayWin = CASE WHEN DATEDIFF(A.winDate, A.TrialStartDate) <= 60 THEN 1 ELSE 0 END WHERE A.hasPaid = 1;


UPDATE rpt_main_02.stg_tableauTrialReport A
SET currentProduct = (SELECT pp.productName FROM rpt_main_02.rpt_paymentProfile pp WHERE pp.sourceUserID = A.userID AND pp.accountType != 3 GROUP BY A.userID);

UPDATE rpt_main_02.stg_tableauTrialReport A
SET trialEndDateTime = (SELECT t.trialEndDateTime FROM rpt_main_02.rpt_trials t WHERE t.userID = A.userID AND t.firstTrial = 1 AND t.trialType = 1 GROUP BY A.userID) WHERE A.trialEndDateTime IS NULL;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET paidWithin10Days = CASE WHEN DATEDIFF(A.winDate, A.trialEndDateTime) <= 10 THEN 1 ELSE 0 END WHERE A.hasPaid = 1;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET userLimit = (SELECT fwp.userLimit FROM rpt_main_02.arc_sourceUser_firstWinProduct fwp
	WHERE fwp.sourceUserID = A.userID) WHERE A.hasPaid = 1;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET SalesAcceptedLead = (SELECT CASE WHEN l.Accepted_Date_Time__c IS NOT NULL THEN 1 ELSE 0 END
	FROM ss_sfdc_02.lead l FORCE INDEX (ppID)
	WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.SalesAcceptedLead = 0 OR A.SalesAcceptedLead IS NULL;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET RepActions = (SELECT l.Activity_Count__c FROM ss_sfdc_02.lead l FORCE INDEX (ppID)
	WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.RepActions = 0 OR A.RepActions IS NULL;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET SalesRep = (SELECT CONCAT(rep.firstName,' ',rep.lastName) FROM ss_sfdc_02.user rep
			JOIN ss_sfdc_02.lead l FORCE INDEX (ppID) ON rep.Id = l.OwnerId
			WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.SalesRep IS NULL;
			
UPDATE rpt_main_02.stg_tableauTrialReport A
SET FitScore = (SELECT l.Fit_Score__c FROM ss_sfdc_02.lead l FORCE INDEX (ppID)
	WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.FitScore IS NULL;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET FitRating = (SELECT l.Fit_Rating_SFDC__c FROM ss_sfdc_02.lead l FORCE INDEX (ppID)
	WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.FitRating IS NULL;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET RelativeScoreValue = (SELECT l.mkto_si__Relative_Score_Value__c FROM ss_sfdc_02.lead l FORCE INDEX (ppID)
	WHERE l.paymentProfileID__c = A.paymentProfileID GROUP BY A.paymentProfileID) WHERE A.RelativeScoreValue IS NULL;
	
UPDATE rpt_main_02.stg_tableauTrialReport A
SET firstSessionDevice = (SELECT sl.device FROM rpt_main_02.rpt_sessionLog sl
				JOIN rpt_main_02.rpt_loginCountTotal lct ON sl.sessionLogID = lct.firstSessionLogID
				WHERE lct.userID = A.userID) WHERE A.firstSessionDevice IS NULL;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET firstSessionBrowser = (SELECT sl.browserBucket FROM rpt_main_02.rpt_sessionLog sl
				JOIN rpt_main_02.rpt_loginCountTotal lct ON sl.sessionLogID = lct.firstSessionLogID
				WHERE lct.userID = A.userID) WHERE A.firstSessionBrowser IS NULL;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET GoogleOAuth = (SELECT CASE WHEN sl.loginType IN('Google OAuth2', 'Google OAuth2 New') THEN 1 ELSE 0 END
			FROM rpt_main_02.rpt_sessionLog sl
				JOIN rpt_main_02.rpt_loginCountTotal lct ON sl.sessionLogID = lct.firstSessionLogID
				WHERE lct.userID = A.userID) WHERE A.GoogleOAuth IS NULL;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET AzureOAuth = (SELECT CASE WHEN sl.loginType = 'MS Azure AD' THEN 1 ELSE 0 END
			FROM rpt_main_02.rpt_sessionLog sl
				JOIN rpt_main_02.rpt_loginCountTotal lct ON sl.sessionLogID = lct.firstSessionLogID
				WHERE lct.userID = A.userID) WHERE A.AzureOAuth IS NULL;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET isLicensed = NULL WHERE isLicensed = 1 AND hasPaid = 1;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET isLicensed = (SELECT CASE WHEN hpp.productID IS NOT NULL THEN 1 ELSE 0 END 
	FROM rpt_main_02.hist_paymentProfile hpp
	WHERE hpp.ownerID = A.userID AND hpp.productID IN(6,7,10,11) AND hpp.accountType != 3 
		AND hpp.modifyDateTime >= A.trialEndDateTime GROUP BY A.userID)
		WHERE A.hasPaid = 0 AND A.trialEndDateTime IS NOT NULL;

/* alter table rpt_main_02.stg_tableauTrialReport
add licenseDate datetime,
add first30DayLicensed tinyint; */
		
UPDATE rpt_main_02.stg_tableauTrialReport A
SET licenseDate = (SELECT MIN(hpp.modifyDateTime)
	FROM rpt_main_02.hist_paymentProfile hpp
WHERE hpp.ownerID = A.userID AND hpp.productID IN(6,7,10,11) AND hpp.accountType != 3 
	AND hpp.modifyDateTime >= A.trialEndDateTime GROUP BY A.userID)
WHERE A.isLicensed = 1 AND A.hasPaid = 0 AND A.trialEndDateTime IS NOT NULL;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET first30DayLicensed = CASE WHEN DATEDIFF(A.licenseDate, A.TrialStartDate) <= 30 THEN 1 ELSE 0 END WHERE isLicensed = 1;
		
INSERT IGNORE INTO rpt_workspace.cDunn_paidPlanJoinsNew (userID, paymentProfileID, trialDate, trialEndDate)
SELECT A.userID, A.paymentProfileID, A.TrialStartDate, A.trialEndDateTime
FROM rpt_main_02.stg_tableauTrialReport A
	WHERE A.isLicensed = 1
	LIMIT 1234567;
	
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinDate = (SELECT MIN(hpp.modifyDateTime)
	FROM rpt_main_02.hist_paymentProfile hpp
	WHERE hpp.ownerID = A.userID AND hpp.productID IN(6,7,10,11) AND hpp.accountType != 3 AND hpp.modifyDateTime >= A.trialEndDate) WHERE leavesFromTrialToJoinDate IS NULL;
	
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinedPlanID = (SELECT hpp.parentPaymentProfileID FROM rpt_main_02.hist_paymentProfile hpp 
	WHERE hpp.ownerID = A.userID AND hpp.accountType != 3 AND hpp.modifyDateTime = A.joinDate AND hpp.productID IN(6,7,10,11) GROUP BY A.userID)
WHERE leavesFromTrialToJoinDate IS NULL	
	;
	

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinDateUserLimit = (SELECT (hpp.userLimit+IFNULL(hpp.bonusUserCount,0)) FROM rpt_main_02.hist_paymentProfile hpp 
				WHERE hpp.paymentProfileID = A.joinedPlanID AND DATE_ADD(A.joinDate, INTERVAL 1 SECOND) 
				BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime GROUP BY A.userID)
					WHERE leavesFromTrialToJoinDate IS NULL;
				
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinDateLicensedUsers = (SELECT COUNT(DISTINCT(hpp.paymentProfileID)) FROM rpt_main_02.hist_paymentProfile hpp
				WHERE hpp.parentPaymentProfileID = A.joinedPlanID AND hpp.productID IN(6,7,10,11) AND A.joinDate 
					BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime AND hpp.paymentProfileID != A.paymentProfileID)
						WHERE leavesFromTrialToJoinDate IS NULL;

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinDateLicensesAvailable = joinDateUserLimit - joinDateLicensedUsers WHERE leavesFromTrialToJoinDate IS NULL;

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET trialDateUserLimit = (SELECT (IFNULL(hpp.userLimit,0)+IFNULL(hpp.bonusUserCount,0)) FROM rpt_main_02.hist_paymentProfile hpp 
				WHERE hpp.paymentProfileID = A.joinedPlanID AND DATE_ADD(A.trialDate, INTERVAL 1 SECOND) 
				BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime GROUP BY A.userID)
					WHERE leavesFromTrialToJoinDate IS NULL;
				
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET trialDateUserLimit = 0 WHERE trialDateUserLimit IS NULL;

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET trialDateUserLimit = 0 WHERE trialDateUserLimit = 1;
			
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET trialDateLicensedUsers = (SELECT COUNT(DISTINCT(hpp.paymentProfileID)) FROM rpt_main_02.hist_paymentProfile hpp
				WHERE hpp.parentPaymentProfileID = A.joinedPlanID AND hpp.productID IN(6,7,10,11) AND A.trialDate
					BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime AND hpp.paymentProfileID != A.paymentProfileID)
						WHERE leavesFromTrialToJoinDate IS NULL;
					
UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET trialDateLicensesAvailable = trialDateUserLimit - trialDateLicensedUsers WHERE leavesFromTrialToJoinDate IS NULL;


SELECT MAX(DATE_FORMAT(modifyDateTime, '%Y-%m-%d')) FROM rpt_workspace.cDunn_teamPlanJoinsNew INTO @maxJoinDate;

INSERT IGNORE INTO rpt_workspace.cDunn_teamPlanJoinsNew
SELECT hpp.paymentProfileID, hpp.parentPaymentProfileID, hpp.modifyDateTime
FROM rpt_main_02.hist_paymentProfile hpp
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hppOLD ON hpp.paymentProfileID = hppOLD.paymentProfileID
		AND (hpp.modifyDateTime = hppOLD.hist_effectiveThruDateTime OR hpp.modifyDateTime = DATE_ADD(hppOLD.hist_effectiveThruDateTime, INTERVAL 1 SECOND))
		WHERE hpp.productID IN(6,7,10) AND hpp.accountType = 2 
		AND hpp.parentPaymentProfileID IS NOT NULL
		AND (hppOLD.productID IN(0,1,2,3,4) OR hppOLD.productID IS NULL OR hppOLD.parentPaymentProfileID != hpp.parentPaymentProfileID)
		AND hpp.modifyDateTime >= @maxJoinDate
		LIMIT 23434343434;		

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET joinsFromTrialToJoinDate = (SELECT COUNT(DISTINCT(B.paymentProfileID)) 
				FROM rpt_workspace.cDunn_teamPlanJoinsNew B
					WHERE B.parentPaymentProfileID = A.joinedPlanID AND B.modifyDateTime BETWEEN A.trialDate AND A.joinDate
						AND B.paymentProfileID != A.paymentProfileID) WHERE leavesFromTrialToJoinDate IS NULL;

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew A
SET leavesFromTrialToJoinDate = (trialDateLicensedUsers + joinsFromTrialToJoinDate) - joinDateLicensedUsers;

UPDATE rpt_workspace.cDunn_paidPlanJoinsNew
SET expansionAbsorption = CASE WHEN joinDateUserLimit = trialDateUserLimit AND joinDateLicensesAvailable > 0 THEN 'Consumption'
				WHEN trialDateLicensesAvailable = 0 AND joinDateUserLimit > trialDateUserLimit AND joinDateLicensesAvailable > (joinDateUserLimit - trialDateUserLimit) THEN 'Consumption'
				WHEN trialDateLicensesAvailable = 0 AND joinDateUserLimit > trialDateUserLimit AND joinDateLicensesAvailable <= (joinDateUserLimit - trialDateUserLimit) THEN 'Expansion'
				WHEN trialDateLicensesAvailable = 0 AND joinDateUserLimit < trialDateUserLimit THEN 'Consumption'
				WHEN trialDateLicensesAvailable > 0 AND joinDateUserLimit > trialDateUserLimit AND joinDateLicensesAvailable > (joinDateUserLimit - trialDateUserLimit) THEN 'Consumption'
				WHEN trialDateLicensesAvailable > 0 AND joinDateUserLimit > trialDateUserLimit AND joinDateLicensesAvailable <= (joinDateUserLimit - trialDateUserLimit) THEN 'Expansion' 
				WHEN trialDateLicensesAvailable > 0 AND joinDateUserLimit < trialDateUserLimit THEN 'Consumption' END
					;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_workspace.cDunn_paidPlanJoinsNew B ON B.userID = A.userID AND B.trialDate = A.TrialStartDate
SET expansionConsumption = B.expansionAbsorption WHERE A.isLicensed = 1;
				
UPDATE rpt_main_02.stg_tableauTrialReport A
SET daysToWin = DATEDIFF(A.winDate, A.TrialStartDate) WHERE A.winDate IS NOT NULL;

UPDATE rpt_main_02.stg_tableauTrialReport A
SET daysToLicensed = DATEDIFF(A.licenseDate, A.TrialStartDate) WHERE A.isLicensed = 1;

UPDATE rpt_main_02.stg_tableauTrialReport A
LEFT OUTER JOIN rpt_workspace.cDunn_roleFormClicksRollup B ON A.userID = B.userID
SET A.seenRoleForm = CASE WHEN B.userID IS NOT NULL THEN 1 ELSE 0 END;

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.rpt_salesMarketingUserData role ON role.userID = A.userID
SET A.role = role.dataValue;

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = A.domain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
SET A.industry = acc.industry 
WHERE A.industry IS NULL AND A.TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);

UPDATE rpt_main_02.stg_tableauTrialReport A
STRAIGHT_JOIN rpt_workspace.cDunn_lead411Companies c ON c.domain = A.domain
STRAIGHT_JOIN rpt_workspace.bbosworth_Lead411IndustryMapping b ON c.industry = b.Lead411Industry
 SET A.Industry = b.Industry
WHERE A.industry IS NULL AND A.TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);

UPDATE rpt_main_02.stg_tableauTrialReport A
LEFT OUTER JOIN rpt_main_02.rpt_trials t ON t.userID = A.userID AND t.trialType = 3 AND t.firstTrial = 1 AND t.trialDateTime >= A.TrialStartDate
SET A.hadTeamTrial = CASE WHEN t.userID IS NOT NULL THEN 1 ELSE 0 END;

/*ALTER TABLE rpt_main_02.stg_tableauTrialReport
add dateUpdated date;*/

UPDATE rpt_main_02.stg_tableauTrialReport
SET dateUpdated=CURRENT_DATE;

UPDATE rpt_main_02.stg_tableauTrialReport A
LEFT JOIN rpt_workspace.cDunn_allDomainsPurchased B ON A.domain = B.domain AND DATE_FORMAT(A.TrialStartDate, '%Y-%m-01 00:00:00') = B.startMonth
SET newLogo = CASE WHEN OrgVsISP = 'ISP Domain' THEN 0
		WHEN B.domain IS NULL THEN 1 ELSE 0 END
	WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);
	
UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.ref_geoClassification B ON B.country = A.ipCountry
SET A.A13Region = B.geoRegion
WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.ref_emergingDevelopedMarkets B ON B.country = A.ipCountry
SET A.market= B.market
WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);

UPDATE rpt_main_02.stg_tableauTrialReport A
JOIN rpt_main_02.arc_integratedContentCategory B ON A.slp = B.slpURL
SET A.slpCategory = B.category
WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 10 DAY);

UPDATE rpt_main_02.stg_tableauTrialReport A
STRAIGHT_JOIN rpt_workspace.pj_domainDataCoverage ddc ON ddc.domain = A.domain
SET A.companySize = ddc.companySize;


SELECT * FROM rpt_main_02.stg_tableauTrialReport
WHERE TrialStartDate >= '2015-01-01' AND TrialStartDate < current_date()
;
	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-trialReportUpdateV2.sql");

