SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("usageDashboardUnassignedV2.sql");

DROP TABLE IF EXISTS rpt_workspace.js_usageDBUnassigned;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_usageDBUnassigned
(mainContactUserID INT(10), 
productName VARCHAR(50) DEFAULT NULL, 
productID int,
paymentProfileID INT(10) DEFAULT NULL, 
mainContactDomain VARCHAR(30) DEFAULT NULL, 
parentPaymentProfileID INT(10) DEFAULT NULL, 
mainContactEmailAddress VARCHAR(50) DEFAULT NULL,
sheetCount INT(5) DEFAULT 0,
sheetsCreated INT(5) DEFAULT 0,
sheetsShared INT(5) DEFAULT 0,
usersSharedTo INT(5) DEFAULT 0,
trialDate DATE,
persona VARCHAR(25),
paymentStartDate DATETIME,
StartDate DATETIME,
daysSinceLastLogin INT(5) DEFAULT 0,
Last30DayLogins INT(5) DEFAULT 0,
Last90DayLogins INT(5) DEFAULT 0,
totalLogins INT(5) DEFAULT 0,
userLimit INT(5) DEFAULT 0,
bonusUserCount INT(7) DEFAULT 0,
seatCount INT(5) DEFAULT 0,
activeProfileCount INT(5) DEFAULT 0,
accountType TINYINT(2) DEFAULT 0,
ACV DECIMAL(10,2) DEFAULT NULL,
sharedToByUserID INT(10) DEFAULT NULL,
ppID INT(10),
masterDomain VARCHAR(50) DEFAULT NULL,
everPaid TINYINT(2) DEFAULT 0,
productGroup2 VARCHAR(25) DEFAULT NULL,
ipCountry VARCHAR(25) DEFAULT NULL,
ipRegion VARCHAR(25) DEFAULT NULL,
ipCity VARCHAR(25) DEFAULT NULL,
role VARCHAR(50) DEFAULT NULL,
fullName VARCHAR(100) DEFAULT NULL,
Territory VARCHAR(100),
accountName VARCHAR(100),
paidCollab TINYINT,
totalCollabs INT,
internalCollabs INT,
accountID VARCHAR(25),
CSM VARCHAR(50),
last30DayLoginPlan INT,
userAccountID VARCHAR(25),
userAccountName VARCHAR(100),
sysAdmin TINYINT,
dashboardCount int,
jobTitle VARCHAR(100),
industry VARCHAR(100),
edu TINYINT,
netPromoterScore INT,
netPromoterScoreReason VARCHAR(500),
reportCount INT,
sightsEnabled tinyint,
closedByReseller INT,
PRIMARY KEY (mainContactUserID, ppID), 
KEY ix_domain(mainContactDomain), 
KEY ix_userID (mainContactUserID),
KEY ix_ppID (ppID),
KEY ix_master (masterDomain),
KEY ix_accountID (accountID))
;

INSERT INTO rpt_workspace.js_usageDBUnassigned (mainContactUserID, productName, paymentProfileID, mainContactDomain, parentPaymentProfileID, 
mainContactEmailAddress, ppID, masterDomain, accountID, accountName)
SELECT ppcu.mainContactUserID, ppcu.productName, ppcu.paymentProfileID, ppcu.mainContactDomain, ppcu.planID, ppcu.mainContactEmailAddress, ppcu.planID, ppcu.planDomain, acc.Id, acc.Name
FROM rpt_main_02.rpt_paidPlanCurrentUsers ppcu
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = ppcu.planDomain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c AND (acc.Territory__c LIKE '%Unassigned%' or acc.Territory__c='' or acc.Territory__c LIKE '%Partner%')
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = ppcu.planDomain
WHERE isp.domain IS NULL
GROUP BY 1
LIMIT 3453454353;

update rpt_workspace.js_usageDBUnassigned
set productID=
case when productName='Basic' then 3 when productName='Advanced' then 4 when productName='Premium' then 5 
when productName='Team' then 7 when productName='Enterprise_Legacy' then 6 when productName='Business' then 10 when productName='Enterprise' then 11
else 0 end;

DROP TABLE IF EXISTS rpt_workspace.js_usageDBUnassignedDomains;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_usageDBUnassignedDomains
(domain VARCHAR(50),
accountName varchar(50),
maxProductID int,
PRIMARY KEY (domain),
index (accountName),
index (maxProductID));

INSERT INTO rpt_workspace.js_usageDBUnassignedDomains
SELECT masterDomain, accountName, max(productID) FROM rpt_workspace.js_usageDBUnassigned
group by 1;

drop table if exists rpt_workspace.js_usageDBUnassignedDomainsCopy;
create table if not exists rpt_workspace.js_usageDBUnassignedDomainsCopy like rpt_workspace.js_usageDBUnassignedDomains;
insert rpt_workspace.js_usageDBUnassignedDomainsCopy select * from rpt_workspace.js_usageDBUnassignedDomains;

-- need to resolve order of this with the delete statements
insert ignore into rpt_workspace.js_usageDBUnassignedDomains(domain)
select A.Domain_Name_URL__c from ss_sfdc_02.domain A
join ss_sfdc_02.account B
on A.Account__c=B.Id
join rpt_workspace.js_usageDBUnassignedDomainsCopy C
on B.Name=C.accountName
left join rpt_main_02.arc_ISPDomains D
on A.Domain_Name_URL__c=D.domain
where B.Territory__c in ('','Unassigned (ISR3)') and D.domain is null;

DROP TABLE IF EXISTS rpt_workspace.js_usageDBUnassignedTrials;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_usageDBUnassignedTrials
(userID BIGINT,
paymentProfileID BIGINT,
productName VARCHAR(25),
mainContactDomain VARCHAR(100),
mainContactEmailAddress VARCHAR(100),
PRIMARY KEY (userID),
KEY domain (mainContactDomain));

INSERT INTO rpt_workspace.js_usageDBUnassignedTrials
SELECT pp.mainContactUserID, pp.paymentProfileID, pp.productName, pp.mainContactDomain, pp.mainContactEmailAddress
FROM rpt_main_02.rpt_paymentProfile pp
JOIN rpt_workspace.js_usageDBUnassignedDomains udd ON udd.domain = pp.mainContactDomain
WHERE pp.accountType != 3
AND pp.productID = 1
GROUP BY 1;

INSERT IGNORE INTO rpt_workspace.js_usageDBUnassigned (mainContactUserID, paymentProfileID, productName, mainContactDomain, mainContactEmailAddress, masterDomain, accountID, accountName)
SELECT udt.userID, udt.paymentProfileID, udt.productName, udt.mainContactDomain, udt.mainContactEmailAddress, udt.mainContactDomain, acc.Id, acc.Name
FROM rpt_workspace.js_usageDBUnassignedTrials udt
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = udt.mainContactDomain
LEFT OUTER JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c;

INSERT IGNORE INTO rpt_workspace.js_usageDBUnassigned (mainContactUserID, mainContactDomain, productName, mainContactEmailAddress, ppID, masterDomain, userAccountID, userAccountName)
SELECT A.userID, u.domain, 'Collaborator', u.emailAddress, A.sheetPlanID, A.sheetPlanDomain, acc.Id, acc.Name
FROM rpt_main_02.userAccount u
JOIN rpt_main_02.rpt_paidPlanSheetAccess A ON u.userID = A.userID AND A.loginCount > 0 AND (A.sheetPlanID != A.userPlanID OR A.userPlanID IS NULL)
JOIN rpt_workspace.js_usageDBUnassignedDomains B ON B.domain = A.sheetPlanDomain
LEFT OUTER JOIN rpt_workspace.js_usageDBUnassignedTrials udd ON udd.userID = u.userID
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = u.domain
LEFT OUTER JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
WHERE u.domain != 'smartsheet.com' 
AND udd.paymentProfileID IS NULL;

INSERT IGNORE INTO rpt_workspace.js_usageDBUnassigned (paymentProfileID, productName, mainContactDomain, ppID, mainContactEmailAddress, masterDomain, accountID, accountName)
SELECT pp.paymentProfileID, pp.productName, pp.mainContactDomain, pp.paymentProfileID, pp.mainContactEmailAddress, pp.mainContactDomain, acc.Id, acc.Name
FROM rpt_main_02.rpt_paymentProfile pp
JOIN rpt_workspace.js_usageDBUnassignedDomains B ON B.domain = pp.mainContactDomain
LEFT OUTER JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = pp.mainContactDomain
LEFT OUTER JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
WHERE pp.accountType = 3
AND pp.countAsPaid = 1
AND pp.productID IN(6,7,10,11)
;


UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanSheetAccess B ON A.mainContactUserID = B.userID AND B.loginCount > 0 AND B.userPlanID IS NULL
JOIN rpt_workspace.js_usageDBUnassignedDomains udd ON udd.domain = B.sheetPlanDomain
SET ppID = B.sheetPlanID WHERE A.productName = 'Trial';
	
UPDATE rpt_workspace.js_usageDBUnassigned A 
SET masterDomain = (SELECT pp.mainContactDomain 
FROM rpt_main_02.rpt_paymentProfile pp 
WHERE pp.paymentProfileID = A.ppID) WHERE A.productName = 'Trial' AND A.ppID != 0
;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN ss_sfdc_02.domain d ON d.Domain_Name_URL__c = A.masterDomain
JOIN ss_sfdc_02.account acc ON acc.Id = d.Account__c
SET A.accountId = acc.Id,
A.accountName = acc.Name
WHERE A.accountID IS NULL;
	
UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paymentProfile pp ON A.paymentProfileID = pp.paymentProfileID
SET A.accountType = pp.accountType;

UPDATE rpt_workspace.js_usageDBUnassigned A
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = A.mainContactUserID AND hpp.accountType != 3 AND hpp.productID IN(3,4,6,7,10,11)
SET everPaid = CASE WHEN hpp.ownerID IS NOT NULL THEN 1 ELSE 0 END
WHERE A.paymentProfileID IS NOT NULL
;

UPDATE rpt_workspace.js_usageDBUnassigned A
SET productGroup2 = CASE WHEN A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business','Enterprise_Legacy') THEN A.productName
			WHEN A.productName = 'Trial' THEN 'Trial'
			WHEN A.userAccountId = A.accountId THEN 'Internal Collaborator'
			WHEN A.mainContactDomain = A.masterDomain THEN 'Internal Collaborator'
			ELSE 'External Collaborator' END;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = A.mainContactUserID
SET paidCollab = CASE WHEN ppcu.mainContactUserID IS NOT NULL THEN 1 ELSE 0 END	WHERE A.productGroup2 IN('Internal Collaborator', 'External Collaborator');

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paymentProfile pp ON pp.paymentProfileID = A.paymentProfileID
SET A.sheetCount = pp.sheetCount,
A.paymentStartDate = pp.paymentStartDateClean
;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_sheetReportCreation B ON A.mainContactUserID = B.userID
SET A.sheetsCreated = B.sheetsCreated,
	A.reportCount = B.reportsCreated;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.stg_sharingCounts B ON A.mainContactUserID = B.userID
SET 	A.sheetsShared = B.sheetsShared,
	A.usersSharedTo = B.usersSharedTo
WHERE A.accountType != 3 AND A.mainContactUserID > 0;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_trials t ON t.userID = A.mainContactUserID AND t.firstTrial = 1 AND t.trialType = 1
SET A.trialDate = t.trialDateTime
WHERE A.accountType != 3
;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = A.mainContactUserID
SET A.persona = CASE WHEN ppcu.persona IN('Tom', 'Sally') THEN ppcu.persona ELSE 'Other' END
WHERE A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Enterprise_Legacy')
;

UPDATE rpt_workspace.js_usageDBUnassigned A
SET StartDate = A.paymentStartDate WHERE A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise', 'Trial','Business','Enterprise_Legacy');

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanSheetAccess B ON A.mainContactUserID = B.userID AND B.sheetPlanID = A.ppID
SET A.StartDate = B.minCollabDate
	WHERE A.productGroup2 IN('Internal Collaborator', 'External Collaborator');
    

DROP TABLE IF EXISTS rpt_workspace.js_minCollabDateUsageDBUnassigned;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_minCollabDateUsageDBUnassigned
(userID INT,
domain VARCHAR(50),
minCollabDate DATETIME,
PRIMARY KEY (userID, domain),
KEY (minCollabDate));

INSERT INTO rpt_workspace.js_minCollabDateUsageDBUnassigned
SELECT mainContactUserID, masterDomain, MIN(StartDate) FROM rpt_workspace.js_usageDBUnassigned
WHERE productGroup2 IN('Internal Collaborator', 'External Collaborator')
GROUP BY 1,2;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_workspace.js_minCollabDateUsageDBUnassigned B
ON A.mainContactUserID=B.userID AND A.masterDomain=B.domain
SET A.startDate=B.minCollabDate
WHERE A.productGroup2 IN('Internal Collaborator', 'External Collaborator');

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_loginCountTotal lct ON lct.userID = A.mainContactUserID
SET A.daysSinceLastLogin = lct.daysSinceLastLogin,
A.totalLogins = lct.loginCount
WHERE A.accountType != 3
;

UPDATE rpt_workspace.js_usageDBUnassigned A
LEFT OUTER JOIN rpt_workspace.cDunn_last30DayLoginCounts B ON B.userID = A.mainContactUserID
SET Last30DayLogins = B.logins
WHERE A.mainContactUserID > 0;

UPDATE rpt_workspace.js_usageDBUnassigned A
LEFT OUTER JOIN rpt_workspace.cDunn_last90DayLoginCounts B ON B.userID = A.mainContactUserID
SET Last90DayLogins = B.logins
WHERE A.mainContactUserID > 0;


UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paymentProfile pp ON A.paymentProfileID = pp.paymentProfileID AND pp.countAsPaid = 1
SET A.userLimit = pp.userLimit,
A.bonusUserCount = pp.bonusUserCount,
A.seatCount = pp.seatCount,
A.activeProfileCount = pp.activeProfileCount
WHERE A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business','Enterprise_Legacy');

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.paymentProfileID = A.paymentProfileID
SET A.ACV = ppi.ACV 
WHERE A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business','Enterprise_Legacy')
;


UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_userIPLocation ip ON ip.userID = A.mainContactUserID
SET 	A.ipCountry = ip.ipCountry,
	A.ipRegion = ip.ipRegion,
	A.ipCity = ip.ipCity;
	
UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.userAccount u ON u.userID = A.mainContactUserID
SET fullName = CONCAT(u.firstName," ",u.lastName)
WHERE A.mainContactUserID > 0;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountID
SET A.Territory = acc.Territory__c;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN ss_sfdc_02.opportunity B ON B.AccountID = A.accountID
SET A.closedByReseller=1
where B.Reseller_Opportunity__c='True';
					
UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_main_02.rpt_paidPlanCollabCount ppcc ON ppcc.paymentProfileID = A.paymentProfileID
SET A.totalCollabs = ppcc.totalCollaborators,
A.internalCollabs = ppcc.internalCollabs
WHERE A.productName IN ('Basic', 'Advanced') OR A.mainContactUserID = 0;	
	
UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN ss_sfdc_02.account acc ON acc.Id = A.accountID
JOIN ss_sfdc_02.user rep ON acc.Customer_Success__c = rep.Id
SET CSM = CONCAT(rep.FirstName," ",rep.LastName) 
WHERE A.accountID IS NOT NULL;
		
DROP TABLE IF EXISTS rpt_workspace.js_usageDBLoginCounts;		
CREATE TEMPORARY TABLE rpt_workspace.js_usageDBLoginCounts
SELECT ppID, COUNT(DISTINCT(mainContactUserID)) AS 'Users'
FROM rpt_workspace.js_usageDBUnassigned 
WHERE daysSinceLastLogin <= 30
AND accountType != 3
AND productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business','Enterprise_Legacy')
GROUP BY 1
;

CREATE UNIQUE INDEX ppID ON rpt_workspace.js_usageDBLoginCounts (ppID);

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_workspace.js_usageDBLoginCounts B ON A.paymentProfileID = B.ppID
SET last30DayLoginPlan = B.Users
WHERE A.productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business','Enterprise_Legacy') AND A.accountType IN(1,3);

/*			
DROP TABLE rpt_main_02.stg_usageDashboardPlans;
CREATE TABLE rpt_main_02.stg_usageDashboardPlans
(planID BIGINT,
PRIMARY KEY (planID));

INSERT INTO rpt_main_02.stg_usageDashboardPlans
SELECT DISTINCT ppID 
FROM rpt_workspace.js_usageDBUnassigned 
WHERE productName IN('Basic', 'Advanced', 'Team', 'Enterprise','Business');
*/

UPDATE rpt_workspace.js_usageDBUnassigned A
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = A.mainContactUserID
SET A.sysAdmin = CASE WHEN ppcu.sysAdmin = 1 THEN 1 ELSE 0 END
WHERE A.productName IN('Basic','Advanced','Team','Enterprise','Business','Enterprise_Legacy') AND A.paidCollab IS NULL;

/*
UPDATE rpt_workspace.js_usageDBUnassigned A
LEFT OUTER JOIN rpt_main_02.rpt_dashboardCountByUser du ON du.userID = A.mainContactUserID
SET A.dashboardCount = IFNULL(du.dashboardCount,0);
*/

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN rpt_workspace.pj_userDataCoverage B ON A.mainContactUserID = B.userID
SET 	A.jobTitle = B.Title,
		A.Role = B.Role,
		A.industry = B.Industry;
	
UPDATE rpt_workspace.js_usageDBUnassigned
SET edu = CASE WHEN masterDomain LIKE '%.edu%' THEN 1 ELSE 0 END;

UPDATE rpt_workspace.js_usageDBUnassigned A FORCE INDEX (ix_userID)
JOIN rpt_main_02.stg_NPS l on l.userID__c = A.mainContactUserID
SET 	A.netPromoterScore = l.Net_Promoter_Score__c,
	A.netPromoterScoreReason = l.Net_Promoter_Score_Reason__c;

UPDATE rpt_workspace.js_usageDBUnassigned A
JOIN ss_account_02.userConfigSetting ucs ON ucs.userID = A.mainContactUserID AND ucs.configPropertyID = 4024 AND ucs.valueBoolean = 1
SET A.sightsEnabled = 1;


SELECT mainContactUserID, 
productName, 
paymentProfileID, 
mainContactDomain, 
parentPaymentProfileID, 
mainContactEmailAddress, 
sheetCount, sheetsCreated, 
sheetsShared, usersSharedTo, 
trialDate, persona,
paymentStartDate, StartDate, 
daysSinceLastLogin, Last30DayLogins, 
Last90DayLogins, totalLogins, 
userLimit, bonusUserCount, 
seatCount, activeProfileCount, 
accountType, ACV, 
sharedToByUserID, ppID,
masterDomain, everPaid, 
productGroup2, ipCountry, 
ipRegion, ipCity, role, 
REPLACE(fullName,",","") AS 'fullName', 
Territory,
REPLACE(accountName,",","") AS accountName, 
paidCollab,
totalCollabs,
internalCollabs,
accountID,
CSM,
last30DayLoginPlan,
userAccountID,
userAccountName,
SysAdmin, dashboardCount,
REPLACE(jobTitle,",","") AS jobTitle,
REPLACE(industry,",","") AS industry,
edu,
netPromoterScore,
reportCount, sightsEnabled,
closedByReseller
FROM rpt_workspace.js_usageDBUnassigned
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("usageDashboardUnassignedV2.sql");

