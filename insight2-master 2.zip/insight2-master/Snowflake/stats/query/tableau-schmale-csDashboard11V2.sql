SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard11V2.sql");

select  userID, emailAddress, fullName, title, planID, accountID, accountName, paymentStartDate, daysLicensed, browserDaysActive, nativeAppDaysActive, 
totalDaysActive, currentCSRep as csRep, lastLoginDate, contactedPostLicenseDate, sfdcContactID, productName, initialCSRep, territory, segment from rpt_workspace.js_toothbrush30DaySnapshot
where planID is not null and currentCSRep is not null;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard11V2.sql");

