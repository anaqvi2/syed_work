
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("sheetLimitReport.sql");

SET @@sql_mode = '';


SELECT pp.paymentProfileID, pp.mainContactUserID, pp.mainContactDomain, pp.userLimit, pp.sheetCount, pp.bonusSheetCount, (pp.userLimit*50) AS sheetLimitNonBonus, 
(pp.userLimit*50)+pp.bonusSheetCount AS sheetLimit, ppi.ACV AS 'ARR', ppi.licensedUsers, ppi.salesforceAccountName, sc.sheetCount AS BeginningSheetCount,
(pp.sheetCount/((pp.userLimit*50)+pp.bonusSheetCount)) AS 'PercentSheetLimitUsed', (sc.sheetCount/sc.sheetLimit) AS 'BeginningPercentLimitUsed',
CASE WHEN (pp.sheetCount/((pp.userLimit*50)+pp.bonusSheetCount)) >= .75 AND (sc.sheetCount/sc.sheetLimit) < .75 THEN 1 ELSE 0 END AS 'Crossed75Percent'
FROM rpt_main_02.rpt_paymentProfile pp
JOIN rpt_main_02.rpt_paidPlanInfo ppi ON ppi.paymentProfileId = pp.paymentProfileId
LEFT JOIN rpt_main_02.hist_sheetCounts sc ON sc.paymentProfileID = pp.paymentProfileID AND sc.historyDate = DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
WHERE pp.productID = 7 AND pp.accountType = 3 AND pp.planRate_USD > 0
;
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("sheetLimitReport.sql");