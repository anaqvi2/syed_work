
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-paymentTransactionRollupV2.sql");

SET @@sql_mode = '';


SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DROP TABLE IF EXISTS rpt_main_02.stg_paymentHistory;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_paymentHistory
(paymentHistoryID INT,
paymentProfileID INT,
processorTransactionID VARCHAR(50),
transactionType INT,
result INT,
paymentType INT,
paymentAmount DECIMAL(10,2),
paymentDateTime DATETIME,
taxAmount DECIMAL(10,2),
currencyCode VARCHAR(25),
PRIMARY KEY (paymentHistoryID),
UNIQUE KEY processorTransactionID (processorTransactionID),
KEY ppID (paymentProfileID));

INSERT INTO rpt_main_02.stg_paymentHistory
SELECT paymentHistoryID, paymentProfileID, processorTransactionID, transactionType, result, paymentType, paymentAmount, paymentDateTime, taxAmount, currencyCode
FROM ss_core_02.paymentHistory
WHERE paymentDateTime >= DATE_SUB(CURRENT_DATE, INTERVAL 180 DAY);

DROP TABLE IF EXISTS rpt_main_02.rpt_paymentTransactionReport;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_paymentTransactionReport
(paymentHistoryID BIGINT,
paymentProfileID BIGINT,
transactionType VARCHAR(50),
result INT,
paymentType VARCHAR(25),
paymentAmountRaw DECIMAL(10,2),
paymentDateTime DATETIME,
taxAmount DECIMAL(10,2),
currencyCode VARCHAR(25),
country VARCHAR(100),
paymentAmountUSD DECIMAL(10,2),
exchangeRate DECIMAL(10,6),
transactionDateTime DATETIME,
last90Day VARCHAR(25),
last7Day VARCHAR(25),
lastDay VARCHAR(25),
dayRank INT,
PRIMARY KEY (paymentHistoryID),
KEY ppID (paymentProfileID),
KEY paymentDate (paymentDateTime));

INSERT INTO rpt_main_02.rpt_paymentTransactionReport
SELECT ph.paymentHistoryID, ph.paymentProfileID, rpt_main_02.SMARTSHEET_TRANTYPE(ph.transactionType), ph.result, rpt_main_02.SMARTSHEET_PAYMENTTYPE(ph.paymentType), 
ph.paymentAmount, ph.paymentDateTime, ph.taxAmount, ph.currencyCode, rpt_main_02.SMARTSHEET_COUNTRYNAME(hpp.billToCountryCode), ast.settlementAmount, ast.exchangeRate, ast.transactionDateTime,
NULL, NULL, NULL, NULL
FROM rpt_main_02.stg_paymentHistory ph
LEFT OUTER JOIN rpt_main_02.arc_settlementTransactions ast ON ast.processorTransactionID = ph.processorTransactionID
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hpp ON hpp.paymentProfileID = ph.paymentProfileID 
     AND hpp.modifyDateTime <= ph.paymentDateTime
     AND hpp.hist_effectiveThruDateTime > ph.paymentDateTime
WHERE ph.paymentDateTime >= '2015-06-01' AND DAYOFWEEK(ph.paymentDateTime) IN(2,3,4,5,6)
GROUP BY ph.paymentHistoryID
LIMIT 435435435;

SELECT dayRank FROM rpt_main_02.ref_weekdays WHERE dailyDate = DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d') INTO @currentDate;

UPDATE rpt_main_02.rpt_paymentTransactionReport A
JOIN rpt_main_02.ref_weekdays B ON DATE_FORMAT(A.paymentDateTime, '%Y-%m-%d') = B.dailyDate
SET A.dayRank = B.dayRank;

UPDATE rpt_main_02.rpt_paymentTransactionReport
SET last90Day = CASE WHEN dayRank >= (@currentDate - 90) THEN 'last90Day' ELSE '91+Day' END,
last7Day = CASE WHEN dayRank >= (@currentDate - 7) THEN 'last7Day' ELSE '8+Day' END,
lastDay = CASE WHEN dayRank >= (@currentDate - 1) THEN 'last1Day' ELSE '2+Day' END;


SELECT country,
SUM(CASE WHEN last90Day = 'last90Day' THEN paymentAmountUSD ELSE 0 END) AS 'Last 90-Day Payment',
SUM(CASE WHEN last90Day = 'last90Day' THEN paymentAmountUSD ELSE 0 END)/90 AS '90-Day Payment Average',
SUM(CASE WHEN last90Day = 'last90Day' THEN 1 ELSE 0 END) AS 'Last 90-Day Quantity',
SUM(CASE WHEN last90Day = 'last90Day' THEN 1 ELSE 0 END)/90 AS '90-Day Quantity Average',
(SUM(CASE WHEN last90Day = 'last90Day' AND paymentType = 'Credit Card' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last90Day = 'last90Day' THEN 1 ELSE 0 END)) AS '90-Day %Credit Card',
(SUM(CASE WHEN last90Day = 'last90Day' AND paymentType = 'Paypal' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last90Day = 'last90Day' THEN 1 ELSE 0 END)) AS '90-Day %Paypal',
(SUM(CASE WHEN last90Day = 'last90Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last90Day = 'last90Day' THEN 1 ELSE 0 END)) AS '90-Day %USD',
SUM(CASE WHEN last7Day = 'last7Day' THEN paymentAmountUSD ELSE 0 END) AS 'Last 7-Day Payment',
SUM(CASE WHEN last7Day = 'last7Day' THEN paymentAmountUSD ELSE 0 END)/7 AS '7-Day Payment Average',
SUM(CASE WHEN last7Day = 'last7Day' THEN 1 ELSE 0 END) AS 'Last 7-Day Quantity',
SUM(CASE WHEN last7Day = 'last7Day' THEN 1 ELSE 0 END)/7 AS '7-Day Quantity Average',
(SUM(CASE WHEN last7Day = 'last7Day' AND paymentType = 'Credit Card' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last7Day = 'last7Day' THEN 1 ELSE 0 END)) AS '7-Day %Credit Card',
(SUM(CASE WHEN last7Day = 'last7Day' AND paymentType = 'Paypal' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last7Day = 'last7Day' THEN 1 ELSE 0 END)) AS '7-Day %Paypal',
(SUM(CASE WHEN last7Day = 'last7Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END))/(SUM(CASE WHEN last7Day = 'last7Day' THEN 1 ELSE 0 END)) AS '7-Day %USD',
SUM(CASE WHEN lastDay = 'last1Day' THEN paymentAmountUSD ELSE 0 END) AS 'Last Day Payment',
SUM(CASE WHEN lastDay = 'last1Day' THEN 1 ELSE 0 END) AS 'Last Day Quantity',
(SUM(CASE WHEN lastDay = 'last1Day' AND paymentType = 'Credit Card' THEN 1 ELSE 0 END))/(SUM(CASE WHEN lastDay = 'last1Day' THEN 1 ELSE 0 END)) AS '1-Day %Credit Card',
(SUM(CASE WHEN lastDay = 'last1Day' AND paymentType = 'Paypal' THEN 1 ELSE 0 END))/(SUM(CASE WHEN lastDay = 'last1Day' THEN 1 ELSE 0 END)) AS '1-Day %Paypal',
(SUM(CASE WHEN lastDay = 'last1Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END))/(SUM(CASE WHEN lastDay = 'last1Day' THEN 1 ELSE 0 END)) AS '1-Day %USD',
(SUM(CASE WHEN lastDay = 'last1Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END)) AS 'Last Day USD Quantity',
(SUM(CASE WHEN last7Day = 'last7Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END)) AS 'Last 7-Day USD Quantity',
(SUM(CASE WHEN last90Day = 'last90Day' AND currencyCode = 'USD' THEN 1 ELSE 0 END)) AS 'Last 90-Day USD Quantity'
FROM rpt_main_02.rpt_paymentTransactionReport
WHERE result = 0
AND DATE_FORMAT(paymentDateTime, '%Y-%m-%d') != CURRENT_DATE()
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-paymentTransactionRollupV2.sql");