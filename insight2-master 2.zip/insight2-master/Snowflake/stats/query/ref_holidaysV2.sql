
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("ref_holidays.csv");

SET @@sql_mode = '';


/*Be sure to adjust ref_holidays table for holidays that fall on Weekends*/
Select * from rpt_main_02.ref_holidays
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("ref_holidays.csv");