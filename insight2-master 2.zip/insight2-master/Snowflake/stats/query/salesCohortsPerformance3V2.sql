SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("salesCohortsPerformance3V2.sql");

/*
drop table if exists rpt_workspace.js_SFDCservicesIncluded;
create table if not exists rpt_workspace.js_SFDCservicesIncluded
(repName varchar(50),
title varchar(50),
startClass varchar(50),
startClassSize int,
startDate date,
closeDate date,
dateDiff int,
amount dec(10,2),
servicesAmount dec(10,2),
opportunityName varchar(100),
opportunityID varchar(50),
primary key (repName, opportunityID),
index (startClass),
index (startDate),
index (closeDate));
*/

insert ignore into rpt_workspace.js_SFDCservicesIncluded(repName, title, startClass, startDate, closeDate, dateDiff, amount, servicesAmount, opportunityName, opportunityID)
select A.repName, A.title, A.startClass, A.startDate, B.closeDate, datediff(B.closeDate, A.startDate), B.Amount, B.Services_ACV__c, B.Name, B.Id from rpt_workspace.js_cohortPerformanceStaging A
join ss_sfdc_02.opportunity B
on A.repID=B.ownerID and A.startDate <= B.closeDate and B.closeDate < current_date and B.Amount > 0
where B.stageName='Closed Won' and B.Services_ACV__c > 0;

update rpt_workspace.js_SFDCservicesIncluded A
set startClassSize=
(select count(*) from rpt_workspace.js_cohortPerformanceStaging B
where A.startClass=B.startClass and A.title=B.title);

update rpt_workspace.js_SFDCservicesIncluded set opportunityName = REPLACE(opportunityName, '\n', '');
update rpt_workspace.js_SFDCservicesIncluded set opportunityName = REPLACE(opportunityName, '\r', '');
update rpt_workspace.js_SFDCservicesIncluded set opportunityName = REPLACE(opportunityName, '\r\n', '');

select * from rpt_workspace.js_SFDCservicesIncluded;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("salesCohortsPerformance3V2.sql");

