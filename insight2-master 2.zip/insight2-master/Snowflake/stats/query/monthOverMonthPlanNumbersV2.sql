SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Generating requestLogOpsV2.sql*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("monthOverMonthPlanNumbersV2.csv");

SELECT * FROM rpt_main_02.rpt_monthOverMonthPlans;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("monthOverMonthPlanNumbersV2.csv");
