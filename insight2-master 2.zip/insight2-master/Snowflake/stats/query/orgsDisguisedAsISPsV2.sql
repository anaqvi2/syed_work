SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("orgsDisguisedAsISPsV2.sql");

drop table if exists rpt_workspace.js_ispSharing;
create table if not exists rpt_workspace.js_ispSharing
(planID int,
domain varchar(50),
companyName varchar(50),
ISP int,
planType varchar(50),
ARR dec(10,2),
userLimit int,
licensedUsers int,
paymentStartDate date,
sharingDomain1 varchar(50),
sharingDomain1ISP int,
sharingDomain1Count int,
sharingDomain2 varchar(50),
sharingDomain2ISP int,
sharingDomain2Count int,
sharingDomain3 varchar(50),
sharingDomain3ISP int,
sharingDomain3Count int,
licensedDomain1 varchar(50),
licensedDomain1ISP int,
licensedDomain1Count int,
licensedDomain2 varchar(50),
licensedDomain2ISP int,
licensedDomain2Count int,
licensedDomain3 varchar(50),
licensedDomain3ISP int,
licensedDomain3Count int,
primary key (planID),
index (domain),
index (sharingDomain1),
index (sharingDomain2),
index (sharingDomain3),
index (licensedDomain1),
index (licensedDomain2),
index (licensedDomain3));

insert into rpt_workspace.js_ispSharing(planID, domain, planType, ARR, userLimit, licensedUsers, paymentStartDate)
select paymentProfileId, domain, productName, ACV, userLimit, licensedUsers, paymentStartDate from rpt_main_02.rpt_paidPlanInfo;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.domain=B.domain
set A.ISP=1;

delete from rpt_workspace.js_ispSharing
where ISP is null;

update rpt_workspace.js_ispSharing A
join rpt_main_02.rpt_paymentProfile B
on A.planID=B.paymentProfileID
set A.companyName=B.companyName;

drop table if exists rpt_workspace.js_ispSharing2;
create table if not exists rpt_workspace.js_ispSharing2
(planID int,
sharedToDomain varchar(50),
sharedToCount int,
index (planID),
index (sharedToDomain));

insert into rpt_workspace.js_ispSharing2
select sheetPlanID, userDomain, count(*) from rpt_main_02.rpt_paidPlanSheetAccess A
join rpt_workspace.js_ispSharing B
on A.sheetPlanID=B.planID
group by 1,2;

update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.sharedToDomain, j1.sharedtoCount 
from rpt_workspace.js_ispSharing2 j1 join (select planID, max(sharedToCount) as maxShares from rpt_workspace.js_ispSharing2 group by 1) j2 on j1.planId = j2.planID and j1.sharedToCount = j2.maxShares) stg
on stg.planID = A.planID
set A.sharingDomain1 = stg.sharedToDomain, 
A.sharingDomain1Count = stg.sharedtoCount;

update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.sharedToDomain, j1.sharedtoCount 
from rpt_workspace.js_ispSharing2 j1 join (select Y.planID, Z.sharingDomain1, max(Y.sharedToCount) as maxShares from rpt_workspace.js_ispSharing2 Y
join rpt_workspace.js_ispSharing Z
on Y.planID=Z.planID
where Y.sharedToDomain!=Z.sharingDomain1
group by 1) j2 
on j1.planId = j2.planID and j1.sharedToCount = j2.maxShares and j1.sharedToDomain!=j2.sharingDomain1) stg
on stg.planID = A.planID
set A.sharingDomain2 = stg.sharedToDomain, 
A.sharingDomain2Count = stg.sharedtoCount;

update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.sharedToDomain, j1.sharedtoCount 
from rpt_workspace.js_ispSharing2 j1 join (select Y.planID, Z.sharingDomain1, Z.sharingDomain2, max(Y.sharedToCount) as maxShares from rpt_workspace.js_ispSharing2 Y
join rpt_workspace.js_ispSharing Z
on Y.planID=Z.planID
where Y.sharedToDomain!=Z.sharingDomain1 and Y.sharedToDomain!=Z.sharingDomain2
group by 1) j2 
on j1.planId = j2.planID and j1.sharedToCount = j2.maxShares and j1.sharedToDomain!=j2.sharingDomain1 and j1.sharedToDomain!=j2.sharingDomain2) stg
on stg.planID = A.planID
set A.sharingDomain3 = stg.sharedToDomain, 
A.sharingDomain3Count = stg.sharedtoCount;




drop table if exists rpt_workspace.js_ispSharing3;
create table if not exists rpt_workspace.js_ispSharing3
(planID int,
licensedDomain varchar(50),
userCount int,
index (planID),
index (licensedDomain));

insert into rpt_workspace.js_ispSharing3
select A.planID, A.mainContactDomain, count(*) from rpt_main_02.rpt_paidPlanCurrentUsers A
join rpt_workspace.js_ispSharing B
on A.planID=B.planID
group by 1,2;


update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.licensedDomain, j1.userCount 
from rpt_workspace.js_ispSharing3 j1 join (select planID, max(userCount) as maxUsers from rpt_workspace.js_ispSharing3 group by 1) j2 on j1.planId = j2.planID and j1.userCount = j2.maxUsers) stg
on stg.planID = A.planID
set A.licensedDomain1 = stg.licensedDomain, 
A.licensedDomain1Count = stg.userCount;

update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.licensedDomain, j1.userCount
from rpt_workspace.js_ispSharing3 j1 join (select Y.planID, Z.licensedDomain1, max(Y.userCount) as maxUsers from rpt_workspace.js_ispSharing3 Y
join rpt_workspace.js_ispSharing Z
on Y.planID=Z.planID
where Y.licensedDomain!=Z.licensedDomain1
group by 1) j2 
on j1.planId = j2.planID and j1.userCount= j2.maxUsers and j1.licensedDomain!=j2.licensedDomain1) stg
on stg.planID = A.planID
set A.licensedDomain2 = stg.licensedDomain, 
A.licensedDomain2Count = stg.userCount;

update rpt_workspace.js_ispSharing A
join 
(select j1.planID, j1.licensedDomain, j1.userCount
from rpt_workspace.js_ispSharing3 j1 join (select Y.planID, Z.licensedDomain1, Z.licensedDomain2, max(Y.userCount) as maxUsers from rpt_workspace.js_ispSharing3 Y
join rpt_workspace.js_ispSharing Z
on Y.planID=Z.planID
where Y.licensedDomain!=Z.licensedDomain1 and Y.licensedDomain!=Z.licensedDomain2
group by 1) j2 
on j1.planId = j2.planID and j1.userCount = j2.maxUsers and j1.licensedDomain!=j2.licensedDomain1 and j1.licensedDomain!=j2.licensedDomain2) stg
on stg.planID = A.planID
set A.licensedDomain3 = stg.licensedDomain, 
A.licensedDomain3Count = stg.userCount;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.sharingDomain1=B.domain
set A.sharingDomain1ISP=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.sharingDomain2=B.domain
set A.sharingDomain2ISP=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.sharingdomain3=B.domain
set A.sharingDomain3ISP=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.licensedDomain1=B.domain
set A.licensedDomain1ISP=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.licensedDomain2=B.domain
set A.licensedDomain2ISP=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.arc_ISPDomains B
on A.licenseddomain3=B.domain
set A.licensedDomain3ISP=1;

alter table rpt_workspace.js_ispSharing
add companyNameSOUNDEX varchar(5),
add sharingDomain1SOUNDEX varchar(5),
add sharingDomain2SOUNDEX varchar(5),
add sharingDomain3SOUNDEX varchar(5);

update rpt_workspace.js_ispSharing
set companyNameSOUNDEX=soundex(companyName);

update rpt_workspace.js_ispSharing
set sharingDomain1SOUNDEX=soundex(sharingDomain1);

update rpt_workspace.js_ispSharing
set sharingDomain2SOUNDEX=soundex(sharingDomain2);

update rpt_workspace.js_ispSharing
set sharingDomain3SOUNDEX=soundex(sharingDomain3);

alter table rpt_workspace.js_ispSharing
add orgDomainGuess varchar(50),
add probabilityScore dec(10,2),
add domainHasPaid int,
add domainCurrentlyPays int;

update rpt_workspace.js_ispSharing
set orgDomainGuess=null;

update rpt_workspace.js_ispSharing
set probabilityScore=null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain1, probabilityScore = 3
where sharingDomain1Count >= 5 and sharingDomain1ISP is null and (sharingDomain2ISP = 1 or (sharingDomain2ISP is null and sharingDomain2Count <= 2));

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain1, probabilityScore = 3
where companyNameSoundex=sharingDomain1Soundex and sharingDomain1ISP is null and (sharingDomain1Count >= 3 or licensedDomain1Count >= 2)
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain2, probabilityScore = 3
where sharingDomain1ISP = 1 and sharingDomain2Count >= 5 and sharingDomain2ISP is null and (sharingDomain3ISP = 1 or (sharingDomain3ISP is null and sharingDomain3Count <= 2))
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain2, probabilityScore = 3
where sharingDomain1ISP = 1 and companyNameSoundex=sharingDomain2Soundex and sharingDomain2ISP is null and (sharingDomain2Count >= 3 or licensedDomain2Count >= 2)
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain3, probabilityScore = 3
where sharingDomain1ISP = 1 and sharingDomain2ISP = 1 and sharingDomain3Count >= 5 and sharingDomain3ISP is null
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain3, probabilityScore = 3
where sharingDomain1ISP = 1 and sharingDomain2ISP = 1 and companyNameSoundex=sharingDomain3Soundex and sharingDomain3ISP is null and (sharingDomain3Count >= 3 or licensedDomain3Count >= 2)
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain1, probabilityScore = 3 
where licensedDomain1Count >= 2 and licensedDomain1ISP is null and (licensedDomain2ISP=1 or licensedDomain2Count < 2)
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain2, probabilityScore = 3 
where licensedDomain1ISP=1 and licensedDomain2Count >= 2 and licensedDomain2ISP is null and (licensedDomain3ISP=1 or licensedDomain3Count < 2)
and OrgDomainGuess is null;





update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain1, probabilityScore = 2
where sharingDomain1Count >= 3 and sharingDomain1ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain1, probabilityScore = 3
where companyNameSoundex=sharingDomain1Soundex and sharingDomain1ISP is null
and orgDomainGuess is null;


update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain2, probabilityScore = 2
where sharingDomain1ISP=1 and sharingDomain2Count >= 3 and sharingDomain2ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain2, probabilityScore = 3
where sharingDomain1ISP = 1 and companyNameSoundex=sharingDomain2Soundex and sharingDomain2ISP is null
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain3, probabilityScore = 2
where sharingDomain1ISP=1 and sharingDomain2ISP=1 and sharingDomain3Count >= 3 and sharingDomain3ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain3, probabilityScore = 3
where sharingDomain1ISP = 1 and sharingDomain2ISP = 1 and companyNameSoundex=sharingDomain3Soundex and sharingDomain3ISP is null
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain1, probabilityScore = 2
where licensedDomain1Count >= 1 and licensedDomain1ISP is null and (licensedDomain2ISP=1 or licensedDomain2 is null)
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain2, probabilityScore = 2
where licensedDomain1ISP=1 and licensedDomain2Count >= 1 and licensedDomain2ISP is null and (licensedDomain3ISP=1 or licensedDomain3 is null)
and OrgDomainGuess is null;




update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain1, probabilityScore = 1
where sharingDomain1Count >= 1 and sharingDomain1ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain2, probabilityScore = 1
where sharingDomain1ISP=1 and sharingDomain2Count >= 1 and sharingDomain2ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=sharingDomain3, probabilityScore = 1
where sharingDomain1ISP=1 and sharingDomain2ISP=1 and sharingDomain3Count >= 1 and sharingDomain3ISP is null
and orgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain1, probabilityScore = 2
where licensedDomain1Count >= 1 and licensedDomain1ISP is null
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain2, probabilityScore = 2
where licensedDomain1ISP=1 and licensedDomain2Count >= 1 and licensedDomain2ISP is null
and OrgDomainGuess is null;

update rpt_workspace.js_ispSharing
set orgDomainGuess=licensedDomain3, probabilityScore = 1
where licensedDomain1ISP=1 and licensedDomain2ISP=1 and licensedDomain3Count >= 1 and licensedDomain3ISP is null
and OrgDomainGuess is null;

alter table rpt_workspace.js_ispSharing
add index(orgDomainGuess);

update rpt_workspace.js_ispSharing A
join rpt_workspace.cDunn_allDomainsPurchased B
on A.orgDomainGuess=B.domain
set A.domainHasPaid=1;

update rpt_workspace.js_ispSharing A
join rpt_main_02.rpt_paidPlanInfo B
on A.orgDomainGuess=B.domain
set A.domainCurrentlyPays=1;

update rpt_workspace.js_ispSharing
set domainHasPaid=1
where domainCurrentlyPays=1 and domainHasPaid is null;

alter table rpt_workspace.js_ispSharing
add mainContactEmailAddress varchar(50);

update rpt_workspace.js_ispSharing A
join rpt_main_02.rpt_paidPlanInfo B
on A.planID=B.paymentProfileID
join rpt_main_02.userAccount C
on B.mainContactUserID=C.userID
set A.mainContactEmailAddress=C.emailAddress;

select planID, planType, ARR, mainContactEmailAddress, orgDomainGuess, probabilityScore, domainHasPaid, domainCurrentlyPays from rpt_workspace.js_ispSharing;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("orgsDisguisedAsISPsV2.sql");

