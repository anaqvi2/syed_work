SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("salesCohortsPerformance4V2.sql");

/*
drop table if exists rpt_workspace.js_SFDCtotalPipeline;
create table if not exists rpt_workspace.js_SFDCtotalPipeline
(repName varchar(50),
repID varchar(50),
title varchar(50),
startClass varchar(50),
startClassSize int,
startDate date,
snapshotDate date,
dateDiff int,
pipelineSize dec(10,2),
primary key (repName, snapshotDate),
index (repID),
index (startClass),
index (startDate));

alter table rpt_workspace.js_SFDCtotalPipeline
add index (title);

alter table rpt_workspace.js_SFDCtotalPipeline
add index (dateDiff);
*/

select max(snapshotDate) from rpt_workspace.js_SFDCtotalPipeline into @maxDate;

insert ignore into rpt_workspace.js_SFDCtotalPipeline(repName, repID, title, startClass, startDate, snapshotDate, dateDiff)
select A.repName, A.repID, A.title, A.startClass, A.startDate, B.dailyDate, datediff(B.dailyDate, A.startDate) from rpt_workspace.js_cohortPerformanceStaging A
cross join rpt_main_02.ref_Dates B
where A.startDate <= B.dailyDate and B.dailyDate <= current_date;

update rpt_workspace.js_SFDCtotalPipeline A
set startClassSize=
(select count(*) from rpt_workspace.js_cohortPerformanceStaging B
where A.startClass=B.startClass and A.title=B.title);

update rpt_workspace.js_SFDCtotalPipeline A
set pipelineSize=
(select sum(Amount) from ss_sfdc_02.opportunity B
where A.repID=B.ownerID and B.CreatedDate <= A.snapshotDate and B.CloseDate > A.snapshotDate and B.Amount > 0)
where snapshotDate > @maxDate;

update rpt_workspace.js_SFDCtotalPipeline
set pipelineSize=0
where pipelineSize is null;

drop table if exists rpt_workspace.js_SFDCtotalPipelineNASStaging;
create table if not exists rpt_workspace.js_SFDCtotalPipelineNASStaging
(repName varchar(50),
title varchar(50),
startDate date,
snapshotDate date,
dateDiff int,
pipelineSize dec(10,2),
primary key (repName, snapshotDate),
index (title),
index (dateDiff),
index (startDate));

insert into rpt_workspace.js_SFDCtotalPipelineNASStaging(repName, title, startDate, snapshotDate, dateDiff)
select 'NAS Average', title, startDate, snapshotDate, dateDiff from rpt_workspace.js_SFDCtotalPipeline
where repName='Courtni Kenyon-George';

update rpt_workspace.js_SFDCtotalPipelineNASStaging A
set pipelineSize=
(select avg(pipelineSize) from rpt_workspace.js_SFDCtotalPipeline B
where A.dateDiff=B.dateDiff and B.title='New Account Specialist');



drop table if exists rpt_workspace.js_SFDCtotalPipelineNBRStaging;
create table if not exists rpt_workspace.js_SFDCtotalPipelineNBRStaging
(repName varchar(50),
title varchar(50),
startDate date,
snapshotDate date,
dateDiff int,
pipelineSize dec(10,2),
primary key (repName, snapshotDate),
index (title),
index (dateDiff),
index (startDate));

insert into rpt_workspace.js_SFDCtotalPipelineNBRStaging(repName, title, startDate, snapshotDate, dateDiff)
select 'NBR Average', title, startDate, snapshotDate, dateDiff from rpt_workspace.js_SFDCtotalPipeline
where repName='Justin Hatten';

update rpt_workspace.js_SFDCtotalPipelineNBRStaging A
set pipelineSize=
(select avg(pipelineSize) from rpt_workspace.js_SFDCtotalPipeline B
where A.dateDiff=B.dateDiff and B.title='New Business Representative');


drop table if exists rpt_workspace.js_SFDCtotalPipelineCDMStaging;
create table if not exists rpt_workspace.js_SFDCtotalPipelineCDMStaging
(repName varchar(50),
title varchar(50),
startDate date,
snapshotDate date,
dateDiff int,
pipelineSize dec(10,2),
primary key (repName, snapshotDate),
index (title),
index (dateDiff),
index (startDate));

insert into rpt_workspace.js_SFDCtotalPipelineCDMStaging(repName, title, startDate, snapshotDate, dateDiff)
select 'CDM Average', title, startDate, snapshotDate, dateDiff from rpt_workspace.js_SFDCtotalPipeline
where repName='Abbie Andrews';

update rpt_workspace.js_SFDCtotalPipelineCDMStaging A
set pipelineSize=
(select avg(pipelineSize) from rpt_workspace.js_SFDCtotalPipeline B
where A.dateDiff=B.dateDiff and B.title='Client Development Manager');



delete from rpt_workspace.js_SFDCtotalPipeline
where repName in ('NAS Average','NBR Average','CDM Average');

insert into rpt_workspace.js_SFDCtotalPipeline(repName, title, startDate, snapshotDate, dateDiff, pipelineSize)
select * from rpt_workspace.js_SFDCtotalPipelineNASStaging;

insert into rpt_workspace.js_SFDCtotalPipeline(repName, title, startDate, snapshotDate, dateDiff, pipelineSize)
select * from rpt_workspace.js_SFDCtotalPipelineNBRStaging;

insert into rpt_workspace.js_SFDCtotalPipeline(repName, title, startDate, snapshotDate, dateDiff, pipelineSize)
select * from rpt_workspace.js_SFDCtotalPipelineCDMStaging;


select * from rpt_workspace.js_SFDCtotalPipeline;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("salesCohortsPerformance4V2.sql");

