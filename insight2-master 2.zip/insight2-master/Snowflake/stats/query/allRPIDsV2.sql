SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("allRPIDs.sql");

SELECT DISTINCT paymentProfileID, billToRecurringBillingID 
FROM rpt_main_02.hist_paymentProfile 
WHERE billToRecurringBillingID IS NOT NULL GROUP BY 1,2;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("allRPIDs.sql");
