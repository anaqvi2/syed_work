SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-domainLevelChurnReportingV2.sql");

SELECT monthFriendly, startMonth, endMonth, monthSequence, paymentProfileID, ownerID, sourceUserID, accountType, rpt_main_02.SMARTSHEET_PAYMENTTYPE(paymentType) AS paymentType,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_main_02.SMARTSHEET_PRODUCTRANKCONVERT(MAX(rpt_main_02.SMARTSHEET_PRODUCTRANK(productID)))) AS highestPlan, IFNULL((SUM(paymentTotalfixedFOREX/paymentTerm)*12),0) AS 'ACV', SUM(IFNULL(userLimit,0)) AS licensesPurchased,
SUM(bonusUsers) AS bonusUsers, domain, isISP, initialStartMonth, initialMonthSequence, initialACV, MAX(paymentTerm) AS paymentTerm, 
SUM(CASE WHEN paymentTotal > 0 THEN 1 ELSE 0 END) AS 'Plans', initialLicenses, companySize
FROM rpt_main_02.rpt_monthEndCustomerProduct
/* WHERE DAYOFWEEK(CURRENT_DATE())=2 */
GROUP BY 1,2,3,14
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-domainLevelChurnReportingV2.sql");
