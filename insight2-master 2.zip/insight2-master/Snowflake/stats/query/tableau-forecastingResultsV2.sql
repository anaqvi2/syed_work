SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-forecastingResultsV2.sql");

DROP TABLE IF EXISTS rpt_main_02.stg_wormInfoUserLevelUPDATED;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wormInfoUserLevelUPDATED
(userID INT,
signupDate DATETIME,
wsl DEC(3,2),
win INT,
winDate DATETIME,
DAYOFWEEK VARCHAR(50),
ARR DEC(10,2),
productName VARCHAR(50),
userLimit INT,
domainLevelRecordTypeNew VARCHAR(50),
DATEDIFF INT,
bucket VARCHAR(50),
source VARCHAR(50),
subSource VARCHAR(50),
campaign VARCHAR(50),
worm VARCHAR(100),
PRIMARY KEY (userID, winDate),
INDEX (signupDate));

INSERT IGNORE INTO rpt_main_02.stg_wormInfoUserLevelUPDATED(userID, signupDate, wsl, bucket, source, subSource, campaign, ARR, winDate, productName, userLimit, domainLevelRecordTypeNew)
SELECT stg.userID, stg.TrialStartDate, stg.IsStrongLeadAdjusted*stg.WeightedStrongLeadFactor, stg.Bucket, stg.SignupSourceFriendly, 
stg.SignupSubSourceFriendly, stg.campaign, r.MonthlyPaymentChange*12, r.recordDateTime, r.NewProductName, r.newUserLimit, r.domainLevelRecordTypeNew
FROM rpt_main_02.stg_tableauTrialReport stg
LEFT JOIN rpt_main_02.output_RevenueSummaryMonthly r
ON stg.userID=r.mainContactUserID
WHERE stg.TrialStartDate BETWEEN DATE_SUB(CURRENT_DATE(), INTERVAL 150 DAY) AND DATE_SUB(CURRENT_DATE(), INTERVAL 60 DAY);

-- where ipCountry is null, about 7%
UPDATE rpt_main_02.stg_wormInfoUserLevelUPDATED
SET wsl=0
WHERE wsl IS NULL;

DELETE FROM rpt_main_02.stg_wormInfoUserLevelUPDATED
WHERE domainLevelRecordTypeNew IN ('EXPANSION','REDUCTION','CANCEL');

DELETE FROM rpt_main_02.stg_wormInfoUserLevelUPDATED
WHERE winDate < signupDate AND winDate!='0000-00-00 00:00:00';

DELETE FROM rpt_main_02.stg_wormInfoUserLevelUPDATED
WHERE (productName='Enterprise' OR userLimit > 10);

UPDATE rpt_main_02.stg_wormInfoUserLevelUPDATED
SET worm=CONCAT(bucket,"-",source,"-",subSource,"-",campaign);

UPDATE rpt_main_02.stg_wormInfoUserLevelUPDATED
SET win=
(CASE WHEN winDate='0000-00-00 00:00:00' THEN 0 ELSE 1 END);

UPDATE rpt_main_02.stg_wormInfoUserLevelUPDATED
SET DAYOFWEEK=DAYNAME(winDate);

UPDATE rpt_main_02.stg_wormInfoUserLevelUPDATED
SET DATEDIFF=
(SELECT DATEDIFF(winDate, signupDate));

DELETE FROM rpt_main_02.stg_wormInfoUserLevelUPDATED
WHERE DATEDIFF > 60;

DROP TABLE IF EXISTS rpt_main_02.stg_wormInfoV3;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wormInfoV3
SELECT worm FROM rpt_workspace.js_domainWormTop25
WHERE worm!='Viral-Sharing (Inserted by Smartsheet FinOps)-Sharing-NULL'
GROUP BY worm
ORDER BY SUM(ARR) DESC
LIMIT 25;

INSERT INTO rpt_main_02.stg_wormInfoV3
VALUES ('OtherWormsCombined');

ALTER TABLE rpt_main_02.stg_wormInfoV3
ADD wslTotal DEC(10,2),
ADD ARRTotal DEC(10,2),
ADD ARRWSLRatio DEC(10,4);

UPDATE rpt_main_02.stg_wormInfoV3 j1
SET wslTotal=
(SELECT SUM(wsl) FROM rpt_main_02.stg_wormInfoUserLevelUPDATED j2
WHERE j1.worm=j2.worm 
GROUP BY j2.worm);

UPDATE rpt_main_02.stg_wormInfoV3 j1
SET wslTotal=
(SELECT SUM(wsl) FROM rpt_main_02.stg_wormInfoUserLevelUPDATED j2
WHERE j2.worm NOT IN 
('Other-Website-Organic Search-Homepage',
'Other-Website-Direct Navigation-Homepage',
'Other-Website-Branded PPC (Google)-21 - Branding',
'Viral-Sharing (Org to Org Out Domain)-Sharing-NULL',
'Viral-Sharing (Org to Org In Domain)-Sharing-NULL',
'Other-Website-Direct Navigation-provconfirm',
'Paid-PPC-_Google Search-3 - Project Management',
'Paid-PPC-_Google Search-6 - Competitors',
'Paid-PPC - English - International-_Google Search - International - Tier 1-3 - Project Management',
'Viral-Sharing (ISP to Org)-Sharing-NULL',
'Other-Website-Direct Navigation-NULL',
'Paid-Paid Placement-Capterra-3 - Project Management',
'Paid-PPC-_Google Search-73 - Gantt',
'Partner-App Store-Apple App Store-NULL',
'Paid-PPC - English - International-_Google Search - International - Tier 1-6 - Competitors',
'Paid-PPC-_Bing Search-3 - Project Management',
'Paid-PPC - English - International-_Google Search - International - Tier 1-73 - Gantt',
'Partner-Partner-Chrome Web Store-NULL',
'Other-Website-Organic Search-top-project-management-excel-templates',
'Viral-Sharing (Org to ISP)-Sharing-NULL',
'Other-Website-Organic Search-blog/gantt-chart-excel',
'Partner-Partner-Google App. Marketplace-NULL',
'Viral-Sharing (ISP to ISP)-Sharing-NULL',
'Viral-Sharing-Signup with Sharing Tracking Codes-NULL',
'Paid-PPC-_Google Search-60 - Task Management')) 
WHERE j1.worm='OtherWormsCombined';

UPDATE rpt_main_02.stg_wormInfoV3 j1
SET ARRTotal=
(SELECT SUM(ARR) FROM rpt_main_02.stg_wormInfoUserLevelUPDATED j2
WHERE j1.worm=j2.worm
GROUP BY j2.worm);

UPDATE rpt_main_02.stg_wormInfoV3 j1
SET ARRTotal=
(SELECT SUM(ARR) FROM rpt_main_02.stg_wormInfoUserLevelUPDATED j2
WHERE j2.worm NOT IN 
('Other-Website-Organic Search-Homepage',
'Other-Website-Direct Navigation-Homepage',
'Other-Website-Branded PPC (Google)-21 - Branding',
'Viral-Sharing (Org to Org Out Domain)-Sharing-NULL',
'Viral-Sharing (Org to Org In Domain)-Sharing-NULL',
'Other-Website-Direct Navigation-provconfirm',
'Paid-PPC-_Google Search-3 - Project Management',
'Paid-PPC-_Google Search-6 - Competitors',
'Paid-PPC - English - International-_Google Search - International - Tier 1-3 - Project Management',
'Viral-Sharing (ISP to Org)-Sharing-NULL',
'Other-Website-Direct Navigation-NULL',
'Paid-Paid Placement-Capterra-3 - Project Management',
'Paid-PPC-_Google Search-73 - Gantt',
'Partner-App Store-Apple App Store-NULL',
'Paid-PPC - English - International-_Google Search - International - Tier 1-6 - Competitors',
'Paid-PPC-_Bing Search-3 - Project Management',
'Paid-PPC - English - International-_Google Search - International - Tier 1-73 - Gantt',
'Partner-Partner-Chrome Web Store-NULL',
'Other-Website-Organic Search-top-project-management-excel-templates',
'Viral-Sharing (Org to ISP)-Sharing-NULL',
'Other-Website-Organic Search-blog/gantt-chart-excel',
'Partner-Partner-Google App. Marketplace-NULL',
'Viral-Sharing (ISP to ISP)-Sharing-NULL',
'Viral-Sharing-Signup with Sharing Tracking Codes-NULL',
'Paid-PPC-_Google Search-60 - Task Management')) 
WHERE j1.worm='OtherWormsCombined';

UPDATE rpt_main_02.stg_wormInfoV3 j1
SET ARRWSLRatio=ARRTotal/wslTotal;

DROP TABLE IF EXISTS rpt_main_02.stg_wslRegressionV2part1;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wslRegressionV2part1
(DATE DATE,
WEEKOFYEAR INT,
worm VARCHAR(100),
wsl DEC(10,2),
wslDeseasonalized DEC(10,2),
PRIMARY KEY (DATE, worm));

INSERT IGNORE INTO rpt_main_02.stg_wslRegressionV2part1 (DATE, worm)
SELECT d.dailyDate, j.worm FROM rpt_main_02.ref_Dates d
CROSS JOIN rpt_main_02.stg_wormInfoV3 j
WHERE d.dailyDate >= DATE_SUB(CURRENT_DATE, INTERVAL 43 DAY) AND dailyDate < DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET WEEKOFYEAR=DATE_FORMAT(DATE,'%U');

UPDATE rpt_main_02.stg_wslRegressionV2part1 j JOIN
(SELECT SUM(IsStrongLeadAdjusted*WeightedStrongLeadFactor) WSL, CONCAT(Bucket,"-", SignupSourceFriendly,"-",SignupSubSourceFriendly,"-",campaign) AS worm, DATE(TrialStartDate) AS trialDate
FROM rpt_main_02.stg_tableauTrialReport 
WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 43 DAY)
GROUP BY worm, trialDate) stg 
ON j.worm=stg.worm AND j.date=stg.trialDate
SET j.wsl=stg.WSL;

UPDATE rpt_main_02.stg_wslRegressionV2part1 j JOIN
(SELECT SUM(IsStrongLeadAdjusted*WeightedStrongLeadFactor) WSL, DATE(TrialStartDate) trialDate FROM rpt_main_02.stg_tableauTrialReport 
WHERE CONCAT(Bucket,"-", SignupSourceFriendly,"-",SignupSubSourceFriendly,"-",campaign) NOT IN 
('Other-Website-Organic Search-Homepage',
'Other-Website-Direct Navigation-Homepage',
'Other-Website-Branded PPC (Google)-21 - Branding',
'Viral-Sharing (Org to Org Out Domain)-Sharing-NULL',
'Viral-Sharing (Org to Org In Domain)-Sharing-NULL',
'Other-Website-Direct Navigation-provconfirm',
'Paid-PPC-_Google Search-3 - Project Management',
'Paid-PPC-_Google Search-6 - Competitors',
'Paid-PPC - English - International-_Google Search - International - Tier 1-3 - Project Management',
'Viral-Sharing (ISP to Org)-Sharing-NULL',
'Other-Website-Direct Navigation-NULL',
'Paid-Paid Placement-Capterra-3 - Project Management',
'Paid-PPC-_Google Search-73 - Gantt',
'Partner-App Store-Apple App Store-NULL',
'Paid-PPC - English - International-_Google Search - International - Tier 1-6 - Competitors',
'Paid-PPC-_Bing Search-3 - Project Management',
'Paid-PPC - English - International-_Google Search - International - Tier 1-73 - Gantt',
'Partner-Partner-Chrome Web Store-NULL',
'Other-Website-Organic Search-top-project-management-excel-templates',
'Viral-Sharing (Org to ISP)-Sharing-NULL',
'Other-Website-Organic Search-blog/gantt-chart-excel',
'Partner-Partner-Google App. Marketplace-NULL',
'Viral-Sharing (ISP to ISP)-Sharing-NULL',
'Viral-Sharing-Signup with Sharing Tracking Codes-NULL',
'Paid-PPC-_Google Search-60 - Task Management')
AND TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 43 DAY)
GROUP BY trialDate) stg 
ON j.worm='OtherWormsCombined' AND j.date=stg.trialDate
SET j.wsl=stg.WSL;

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=0
WHERE wsl IS NULL;

 -- to generate a number for yesterday's viral...
/*
select avg(wsl) from rpt_main_02.stg_wslRegressionV2part1
where worm='Viral-Sharing (Org to Org Out Domain)-Sharing-NULL';
*/

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=6
WHERE worm='Viral-Sharing (ISP to ISP)-Sharing-NULL' AND DATE=DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=10
WHERE worm='Viral-Sharing (ISP to Org)-Sharing-NULL' AND DATE=DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=8
WHERE worm='Viral-Sharing (Org to ISP)-Sharing-NULL' AND DATE=DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=113
WHERE worm='Viral-Sharing (Org to Org In Domain)-Sharing-NULL' AND DATE=DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1
SET wsl=39
WHERE worm='Viral-Sharing (Org to Org Out Domain)-Sharing-NULL' AND DATE=DATE_SUB(CURRENT_DATE,INTERVAL 2 DAY);

UPDATE rpt_main_02.stg_wslRegressionV2part1 j1
JOIN rpt_main_02.stg_wslSeasonality2 j2
ON j1.weekOfYear=j2.weekOfYear
SET wslDeseasonalized=j1.wsl*(1/j2.factor);


DROP TABLE IF EXISTS rpt_main_02.stg_wslRegressionV2part2;
CREATE TABLE  IF NOT EXISTS rpt_main_02.stg_wslRegressionV2part2
(worm VARCHAR(100),
week1 INT,
wsl1 DEC(10,3),
week2 INT,
wsl2 DEC(10,3),
week3 INT,
wsl3 DEC(10,3),
week4 INT,
wsl4 DEC(10,3),
week5 INT,
wsl5 DEC(10,3),
week6 INT,
wsl6 DEC(10,3),
INDEX (worm));

INSERT INTO rpt_main_02.stg_wslRegressionV2part2(worm)
SELECT worm FROM rpt_main_02.stg_wormInfoV3;

UPDATE rpt_main_02.stg_wslRegressionV2part2
SET week1=1, week2=2, week3=3, week4=4, week5=5, week6=6;

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl6=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 8 DAY) AND j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl5=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 8 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 15 DAY) AND j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl4=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 15 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 22 DAY) AND j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl3=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 22 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 29 DAY) AND j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl2=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 29 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 36 DAY) AND j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part2 j1
SET wsl1=
(SELECT SUM(wslDeseasonalized) FROM rpt_main_02.stg_wslRegressionV2part1 j2
WHERE j2.date < DATE_SUB(CURRENT_DATE, INTERVAL 36 DAY) AND j2.date >= DATE_SUB(CURRENT_DATE, INTERVAL 43 DAY) AND j1.worm=j2.worm);


DROP TABLE IF EXISTS rpt_main_02.stg_wslRegressionV2part3;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wslRegressionV2part3
(worm VARCHAR(100),
a DEC(10,3),
b DEC(10,3),
c DEC(10,3),
d DEC(10,3),
e DEC(10,3),
f DEC(10,3),
alpha DEC(10,3),
beta DEC(10,3),
PRIMARY KEY(worm));

INSERT INTO rpt_main_02.stg_wslRegressionV2part3(worm)
SELECT worm FROM rpt_main_02.stg_wormInfoV3;

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET a=
(SELECT 6*((week1*wsl1)+(week2*wsl2)+(week3*wsl3)+(week4*wsl4)+(week5*wsl5)+(week6*wsl6)) FROM rpt_main_02.stg_wslRegressionV2part2 j2
WHERE j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET b=
(SELECT (week1+week2+week3+week4+week5+week6)*(wsl1+wsl2+wsl3+wsl4+wsl5+wsl6) FROM rpt_main_02.stg_wslRegressionV2part2 j2
WHERE j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET c=
(SELECT 6*(week1*week1+week2*week2+week3*week3+week4*week4+week5*week5+week6*week6) FROM rpt_main_02.stg_wslRegressionV2part2 j2
WHERE j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET d=
(SELECT (week1+week2+week3+week4+week5+week6)*(week1+week2+week3+week4+week5+week6) FROM rpt_main_02.stg_wslRegressionV2part2 j2
WHERE j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET alpha=(a-b)/(c-d);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET e=
(SELECT wsl1+wsl2+wsl3+wsl4+wsl5+wsl6 FROM rpt_main_02.stg_wslRegressionV2part2 j2
WHERE j1.worm=j2.worm);

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET f=alpha*21;

UPDATE rpt_main_02.stg_wslRegressionV2part3 j1
SET beta=(e-f)/6;

DROP TABLE IF EXISTS rpt_main_02.stg_wslTable;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wslTable
(dayDate DATE,
DAYOFWEEK VARCHAR(25),
dayOfWeekFactor DEC(10,3),
WEEKOFYEAR INT,
weekOfYearFactor DEC(10,3),
forecastWeek INT,
worm VARCHAR(100),
wsl DEC(10,2),
PRIMARY KEY (dayDate, worm));

INSERT IGNORE INTO rpt_main_02.stg_wslTable (dayDate, worm)
SELECT d.dailyDate, j.worm FROM rpt_main_02.ref_Dates d
CROSS JOIN rpt_main_02.stg_wormInfoV3 j
WHERE d.dailyDate >= DATE_SUB(CURRENT_DATE, INTERVAL 93 DAY) AND dailyDate <= DATE_ADD(CURRENT_DATE, INTERVAL 93 DAY);

UPDATE rpt_main_02.stg_wslTable
SET DAYOFWEEK=DAYNAME(dayDate);

UPDATE rpt_main_02.stg_wslTable j1
SET dayOfWeekFactor=
(SELECT factor FROM rpt_main_02.stg_wslWeekdayFactor2 j2
WHERE j1.dayOfWeek=j2.dayOfWeek);

UPDATE rpt_main_02.stg_wslTable
SET WEEKOFYEAR=DATE_FORMAT(dayDate, '%U');

UPDATE rpt_main_02.stg_wslTable j1
SET weekOfYearFactor=
(SELECT factor FROM rpt_main_02.stg_wslSeasonality2 j2
WHERE j1.weekOfYear=j2.weekOfYear);

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=7
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(CURRENT_DATE, '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=8
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 7 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=9
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=10
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 21 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=11
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 28 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=12
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 35 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=13
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 42 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=14
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 49 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=15
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 56 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=16
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 63 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=17
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 70 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=18
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 77 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=19
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 84 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=20
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 91 DAY), '%U');

UPDATE rpt_main_02.stg_wslTable
SET forecastWeek=21
WHERE DATE_FORMAT(dayDate, '%U')=DATE_FORMAT(DATE_ADD(CURRENT_DATE, INTERVAL 98 DAY), '%U');

DROP TABLE IF EXISTS rpt_main_02.stg_wslTableCopy;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_wslTableCopy LIKE rpt_main_02.stg_wslTable;
INSERT rpt_main_02.stg_wslTableCopy SELECT * FROM rpt_main_02.stg_wslTable;

UPDATE rpt_main_02.stg_wslTable j1
SET j1.forecastWeek=
(SELECT j2.forecastWeek FROM rpt_main_02.stg_wslTableCopy j2
WHERE j2.weekOfYear=0 LIMIT 1) WHERE j1.dayDate >= CURRENT_DATE AND j1.forecastWeek IS NULL;

UPDATE rpt_main_02.stg_wslTable j1
SET j1.forecastWeek=
(SELECT j2.forecastWeek FROM rpt_main_02.stg_wslTableCopy j2
WHERE j2.weekOfYear=52 LIMIT 1) WHERE j1.dayDate >= CURRENT_DATE AND j1.forecastWeek IS NULL;

UPDATE rpt_main_02.stg_wslTable j JOIN
(SELECT DATE_FORMAT(TrialStartDate,'%Y-%m-%d') AS trialDate, SUM(IsStrongLeadAdjusted*WeightedStrongLeadFactor) WSL, 
CONCAT(Bucket,"-", SignupSourceFriendly,"-",SignupSubSourceFriendly,"-",campaign) worm
FROM rpt_main_02.stg_tableauTrialReport WHERE DATE_FORMAT(TrialStartDate,'%Y-%m-%d') >= DATE_SUB(CURRENT_DATE, INTERVAL 61 DAY) GROUP BY trialDate, worm) stg
ON stg.trialDate = j.dayDate AND stg.worm=j.worm
SET j.wsl = stg.WSL;

UPDATE rpt_main_02.stg_wslTable j JOIN
(SELECT DATE(TrialStartDate) AS trialDate, SUM(IsStrongLeadAdjusted*WeightedStrongLeadFactor) WSL
FROM rpt_main_02.stg_tableauTrialReport WHERE TrialStartDate >= DATE_SUB(CURRENT_DATE, INTERVAL 61 DAY) 
AND CONCAT(Bucket,"-", SignupSourceFriendly,"-",SignupSubSourceFriendly,"-",campaign) NOT IN 
('Other-Website-Organic Search-Homepage',
'Other-Website-Direct Navigation-Homepage',
'Other-Website-Branded PPC (Google)-21 - Branding',
'Viral-Sharing (Org to Org Out Domain)-Sharing-NULL',
'Viral-Sharing (Org to Org In Domain)-Sharing-NULL',
'Other-Website-Direct Navigation-provconfirm',
'Paid-PPC-_Google Search-3 - Project Management',
'Paid-PPC-_Google Search-6 - Competitors',
'Paid-PPC - English - International-_Google Search - International - Tier 1-3 - Project Management',
'Viral-Sharing (ISP to Org)-Sharing-NULL',
'Other-Website-Direct Navigation-NULL',
'Paid-Paid Placement-Capterra-3 - Project Management',
'Paid-PPC-_Google Search-73 - Gantt',
'Partner-App Store-Apple App Store-NULL',
'Paid-PPC - English - International-_Google Search - International - Tier 1-6 - Competitors',
'Paid-PPC-_Bing Search-3 - Project Management',
'Paid-PPC - English - International-_Google Search - International - Tier 1-73 - Gantt',
'Partner-Partner-Chrome Web Store-NULL',
'Other-Website-Organic Search-top-project-management-excel-templates',
'Viral-Sharing (Org to ISP)-Sharing-NULL',
'Other-Website-Organic Search-blog/gantt-chart-excel',
'Partner-Partner-Google App. Marketplace-NULL',
'Viral-Sharing (ISP to ISP)-Sharing-NULL',
'Viral-Sharing-Signup with Sharing Tracking Codes-NULL',
'Paid-PPC-_Google Search-60 - Task Management') GROUP BY trialDate) stg
ON stg.trialDate = j.dayDate AND j.worm='OtherWormsCombined'
SET j.wsl = stg.WSL;

UPDATE rpt_main_02.stg_wslTable
SET wsl=0
WHERE wsl IS NULL;

UPDATE rpt_main_02.stg_wslTable j1
SET wsl=
(SELECT (((j2.alpha*j1.forecastWeek+j2.beta)*j1.weekOfYearFactor)/7)*j1.dayOfWeekFactor FROM rpt_main_02.stg_wslRegressionV2part3 j2
WHERE j1.worm=j2.worm) WHERE j1.dayDate >= CURRENT_DATE;

UPDATE rpt_main_02.stg_wslTable
SET wsl=0
WHERE wsl<0;



DELETE A.* FROM rpt_main_02.stg_dateValues A
JOIN rpt_main_02.ref_months B
ON DATE_FORMAT(A.dayDate, '%Y-%m')=DATE_FORMAT(B.endMonth, '%Y-%m')
WHERE DATE_FORMAT(A.dayDate, '%Y-%m') < DATE_FORMAT(CURRENT_DATE, '%Y-%m') AND A.dayDate < DATE_SUB(DATE(B.endMonth), INTERVAL 1 DAY);

INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-60,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -60 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-59,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -59 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-58,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -58 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-57,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -57 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-56,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -56 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-55,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -55 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-54,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -54 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-53,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -53 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-52,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -52 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-51,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -51 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-50,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -50 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-49,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -49 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-48,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -48 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-47,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -47 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-46,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -46 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-45,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -45 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-44,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -44 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-43,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -43 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-42,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -42 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-41,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -41 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-40,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -40 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-39,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -39 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-38,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -38 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-37,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -37 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-36,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -36 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-35,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -35 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-34,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -34 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-33,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -33 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-32,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -32 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-31,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -31 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-30,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -30 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-29,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -29 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-28,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -28 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-27,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -27 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-26,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -26 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-25,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -25 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-24,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -24 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-23,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -23 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-22,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -22 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-21,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -21 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-20,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -20 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-19,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -19 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-18,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -18 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-17,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -17 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-16,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -16 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-15,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -15 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-14,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -14 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-13,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -13 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-12,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -12 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-11,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -11 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-10,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -10 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-9,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -9 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-8,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -8 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-7,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -7 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-6,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -6 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-5,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -5 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-4,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -4 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-3,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -3 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-2,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -2 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),-1,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL -1 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));
INSERT IGNORE INTO rpt_main_02.stg_dateValues VALUES(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),0,DATE_ADD(DATE_ADD(CURRENT_DATE,INTERVAL 91 DAY),INTERVAL 0 DAY),DAYNAME(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY)),DATE_FORMAT(DATE_ADD(CURRENT_DATE,INTERVAL  91 DAY), '%U'));


DROP TABLE IF EXISTS rpt_main_02.stg_forecastMiddleTable;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_forecastMiddleTable
(dayDate DATE,
DAYOFWEEK VARCHAR(50),
WEEKOFYEAR VARCHAR(50),
t INT,
worm VARCHAR(100),
ARRForecast DEC(10,4),
PRIMARY KEY (dayDate, t, worm));

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable(dayDate, DAYOFWEEK, WEEKOFYEAR, t, worm, ARRForecast)
SELECT A.dayDate, A.dayOfWeek, A.weekOfYear, A.t, D.worm, (B.wsl*C.dailyPercentage*D.ARRWSLRatio*1.091) AS ARRForecast
FROM rpt_main_02.stg_dateValues A
JOIN rpt_main_02.stg_wslTable B ON B.dayDate = A.referenceDate
JOIN rpt_main_02.stg_crHistogram C ON C.t = A.t
JOIN rpt_main_02.stg_wormInfoV3 D ON D.worm=B.worm;

DROP TABLE IF EXISTS rpt_main_02.stg_forecastMiddleTable2;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_forecastMiddleTable2
(dayDate DATE,
DAYOFWEEK VARCHAR(50),
monthYear VARCHAR(50),
quarterYear VARCHAR(50),
ARRSource VARCHAR(100),
recordType VARCHAR(50),
assistedType VARCHAR(50),
ARRForecast DEC(10,2),
PRIMARY KEY (dayDate, ARRSource, assistedType));

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, j1.worm, 'NEW', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, 'Basic - Team 10/Business 10 Non-Trial Wins', 'NEW', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, 'Team 10+/Business 10+ & Enterprise Wins', 'NEW', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, 'ISP Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, 'Previously Paying Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, '<.5K ARR Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, '.5K-1K ARR Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, '1K-5K ARR Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, '5K-25K ARR Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

INSERT IGNORE INTO rpt_main_02.stg_forecastMiddleTable2(dayDate, ARRSource, recordType, assistedType)
SELECT j1.dayDate, '>25K ARR Base', 'EXPANSION', j2.assistedType FROM rpt_main_02.stg_forecastMiddleTable j1
CROSS JOIN rpt_main_02.stg_forecastAssistedType j2;

UPDATE rpt_main_02.stg_forecastMiddleTable2
SET DAYOFWEEK=DAYNAME(dayDate);

UPDATE rpt_main_02.stg_forecastMiddleTable2
SET monthYear=DATE_FORMAT(dayDate, '%M %Y');

UPDATE rpt_main_02.stg_forecastMiddleTable2
SET quarterYear=
CASE 
WHEN dayDate BETWEEN '2016-01-01' AND '2016-03-31' THEN 'Q1 2016' 
WHEN dayDate BETWEEN '2016-04-01' AND '2016-06-30' THEN 'Q2 2016'
WHEN dayDate BETWEEN '2016-07-01' AND '2016-09-30' THEN 'Q3 2016' 
WHEN dayDate BETWEEN '2016-10-01' AND '2016-12-31' THEN 'Q4 2016' 
WHEN dayDate BETWEEN '2017-01-01' AND '2017-03-31' THEN 'Q1 2017' 
WHEN dayDate BETWEEN '2017-04-01' AND '2017-06-30' THEN 'Q2 2017'
WHEN dayDate BETWEEN '2017-07-01' AND '2017-09-30' THEN 'Q3 2017' 
WHEN dayDate BETWEEN '2017-10-01' AND '2017-12-31' THEN 'Q4 2017' 
WHEN dayDate BETWEEN '2018-01-01' AND '2018-03-31' THEN 'Q1 2018' 
WHEN dayDate BETWEEN '2018-04-01' AND '2018-06-30' THEN 'Q2 2018'
WHEN dayDate BETWEEN '2018-07-01' AND '2018-09-30' THEN 'Q3 2018' 
WHEN dayDate BETWEEN '2018-10-01' AND '2018-12-31' THEN 'Q4 2018' 
END;

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
SET ARRForecast=
(SELECT SUM(j2.ARRForecast) FROM rpt_main_02.stg_forecastMiddleTable j2
WHERE j1.dayDate=j2.dayDate AND j1.ARRSource=j2.worm);

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
SET ARRForecast=ARRForecast*.36
WHERE assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
SET ARRForecast=ARRForecast*.64
WHERE assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
SET ARRForecast=ARRForecast*.36
WHERE assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
SET ARRForecast=ARRForecast*.64
WHERE assistedType='Unassisted' AND monthYear='January 2018';

/*
-- bias factor for trial NEW ARR (before and after) 
select monthYear, sum(ARRForecast) from rpt_main_02.stg_forecastMiddleTable2
where dayDate >= '2017-06-01' and dayDate < '2017-08-01'
group by 1; */

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=j1.ARRForecast*j2.factor;

/*
select monthYear,sum(ARRForecast) from rpt_main_02.stg_forecastMiddleTable2
where dayDate >= '2017-06-01' and dayDate < '2017-08-01'
group by 1; 
before/after=factor
-- before June= '1010563.95'
-- before July= '975049.15'
-- after June= '1069014.56'
-- after July= '981533.29'
-- June Factor= .95
-- July Factor= 1
*/

UPDATE rpt_main_02.stg_forecastMiddleTable2
SET ARRForecast=ARRForecast*.96
WHERE monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2
SET ARRForecast=ARRForecast*1.01
WHERE monthYear='January 2018';

-- divining of the variables section
UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(22750/31)*j2.factor
WHERE ARRSource='Basic - Team 10/Business 10 Non-Trial Wins' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(24570/31)*j2.factor
WHERE ARRSource='Basic - Team 10/Business 10 Non-Trial Wins' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(335335/31)*j2.factor
WHERE ARRSource='Team 10+/Business 10+ & Enterprise Wins' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(13650/31)*j2.factor
WHERE ARRSource='Team 10+/Business 10+ & Enterprise Wins' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(9100/31)*j2.factor
WHERE ARRSource='ISP Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(46069/31)*j2.factor
WHERE ARRSource='ISP Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(151060/31)*j2.factor
WHERE ARRSource='Previously Paying Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(119438/31)*j2.factor
WHERE ARRSource='Previously Paying Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(144178/31)*j2.factor
WHERE ARRSource='<.5K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(139059/31)*j2.factor
WHERE ARRSource='<.5K ARR Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(238875/31)*j2.factor
WHERE ARRSource='.5K-1K ARR Base' AND assistedType='Commercial Assisted' AND monthYear= 'December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(119949/31)*j2.factor
WHERE ARRSource='.5K-1K ARR Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(859950/31)*j2.factor
WHERE ARRSource='1K-5K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(226931/31)*j2.factor
WHERE ARRSource='1K-5K ARR Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(682500/31)*j2.factor
WHERE ARRSource='5K-25K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(51188/31)*j2.factor
WHERE ARRSource='5K-25K ARR Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(341250/31)*j2.factor
WHERE ARRSource='>25K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(40950/31)*j2.factor
WHERE ARRSource='>25K ARR Base' AND assistedType='Unassisted' AND monthYear='December 2017';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(22500/31)*j2.factor
WHERE ARRSource='Basic - Team 10/Business 10 Non-Trial Wins' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(31250/31)*j2.factor
WHERE ARRSource='Basic - Team 10/Business 10 Non-Trial Wins' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(431250/31)*j2.factor
WHERE ARRSource='Team 10+/Business 10+ & Enterprise Wins' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(20000/31)*j2.factor
WHERE ARRSource='Team 10+/Business 10+ & Enterprise Wins' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(7500/31)*j2.factor
WHERE ARRSource='ISP Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(30000/31)*j2.factor
WHERE ARRSource='ISP Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(225000/31)*j2.factor
WHERE ARRSource='Previously Paying Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(137500/31)*j2.factor
WHERE ARRSource='Previously Paying Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(150000/31)*j2.factor
WHERE ARRSource='<.5K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(99000/31)*j2.factor
WHERE ARRSource='<.5K ARR Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(325000/31)*j2.factor
WHERE ARRSource='.5K-1K ARR Base' AND assistedType='Commercial Assisted' AND monthYear= 'January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(127500/31)*j2.factor
WHERE ARRSource='.5K-1K ARR Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(945250/31)*j2.factor
WHERE ARRSource='1K-5K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(225000/31)*j2.factor
WHERE ARRSource='1K-5K ARR Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(900000/31)*j2.factor
WHERE ARRSource='5K-25K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(54250/31)*j2.factor
WHERE ARRSource='5K-25K ARR Base' AND assistedType='Unassisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(463750/31)*j2.factor
WHERE ARRSource='>25K ARR Base' AND assistedType='Commercial Assisted' AND monthYear='January 2018';

UPDATE rpt_main_02.stg_forecastMiddleTable2 j1
JOIN rpt_workspace.js_monthDayFactor2 j2
ON j1.dayDate=j2.dayDate
SET ARRForecast=(25000/31)*j2.factor
WHERE ARRSource='>25K ARR Base' AND assistedType='Unassisted' AND monthYear='January 2018';


DROP TABLE IF EXISTS rpt_workspace.js_actualsStaging;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_actualsStaging
SELECT paymentProfileID, recordDateTime, DATE(recordDateTime) AS recordDate, mainContactUserID, domain, ispDomain AS ISP, monthlyPaymentChange*12 AS ARR, domainLevelRecordTypeNew AS recordType,
NewProductName, NewUserLimit, salesRep, salesRepRole, salesTeam AS assistedType, Bucket AS SignupBucket, SignupSourceFriendly AS SignupSource, SignupSubSourceFriendly AS SignupSubSource, SignupCampaign FROM rpt_main_02.output_RevenueSummaryMonthlyTableau
WHERE recordDateTime >= '2016-01-01' AND currencyChange=0 AND futureLoss IS NULL;

ALTER TABLE rpt_workspace.js_actualsStaging
ADD worm VARCHAR(100),
ADD ARRSource VARCHAR(100),
ADD accountName VARCHAR(100),
ADD accountID VARCHAR(50),
ADD opportunityID VARCHAR(50),
ADD INDEX (paymentProfileID),
ADD INDEX (recordDateTime),
ADD INDEX (recordDate),
ADD INDEX (domain),
ADD INDEX (ISP),
ADD INDEX (assistedType),
ADD INDEX (worm),
MODIFY COLUMN ARR DEC(10,2);


UPDATE rpt_workspace.js_actualsStaging A
JOIN ss_sfdc_02.domain B
ON A.domain=B.Domain_Name_URL__c
JOIN ss_sfdc_02.account C 
ON B.Account__c=C.Id
SET A.accountName=C.Name, A.accountID=C.Id;

UPDATE rpt_workspace.js_actualsStaging A
LEFT JOIN ss_sfdc_02.opportunity B
ON A.paymentProfileID=B.parent_payment_profile_ID__c
AND DATE_FORMAT(TIMESTAMPADD(HOUR,-8,A.recordDateTime),'%Y-%m-01')=DATE_FORMAT(B.CloseDate,'%Y-%m-01') AND B.StageName='Closed Won' AND B.Amount>0 AND B.Product__c!='SERVICES'
SET A.opportunityID=B.Id;

UPDATE rpt_workspace.js_actualsStaging
SET SignupCampaign='NULL'
WHERE SignupCampaign IS NULL;

UPDATE rpt_workspace.js_actualsStaging
SET worm=CONCAT(SignupBucket,"-", SignupSource,"-", SignupSubSource,"-",SignupCampaign);

UPDATE rpt_workspace.js_actualsStaging
SET worm='OtherWormsCombined'
WHERE worm NOT IN
('Other-Website-Organic Search-Homepage',
'Other-Website-Direct Navigation-Homepage',
'Other-Website-Branded PPC (Google)-21 - Branding',
'Viral-Sharing (Org to Org Out Domain)-Sharing-NULL',
'Viral-Sharing (Org to Org In Domain)-Sharing-NULL',
'Other-Website-Direct Navigation-provconfirm',
'Paid-PPC-_Google Search-3 - Project Management',
'Paid-PPC-_Google Search-6 - Competitors',
'Paid-PPC - English - International-_Google Search - International - Tier 1-3 - Project Management',
'Viral-Sharing (ISP to Org)-Sharing-NULL',
'Other-Website-Direct Navigation-NULL',
'Paid-Paid Placement-Capterra-3 - Project Management',
'Paid-PPC-_Google Search-73 - Gantt',
'Partner-App Store-Apple App Store-NULL',
'Paid-PPC - English - International-_Google Search - International - Tier 1-6 - Competitors',
'Paid-PPC-_Bing Search-3 - Project Management',
'Paid-PPC - English - International-_Google Search - International - Tier 1-73 - Gantt',
'Partner-Partner-Chrome Web Store-NULL',
'Other-Website-Organic Search-top-project-management-excel-templates',
'Viral-Sharing (Org to ISP)-Sharing-NULL',
'Other-Website-Organic Search-blog/gantt-chart-excel',
'Partner-Partner-Google App. Marketplace-NULL',
'Viral-Sharing (ISP to ISP)-Sharing-NULL',
'Viral-Sharing-Signup with Sharing Tracking Codes-NULL',
'Paid-PPC-_Google Search-60 - Task Management');

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_main_02.rpt_trials B
ON A.mainContactUserID=B.userID
SET A.ARRSource=A.worm
WHERE A.recordType='NEW' AND A.NewProductName NOT IN ('Enterprise', 'Enterprise_Legacy') AND A.NewUserLimit <= 10;

UPDATE rpt_workspace.js_actualsStaging
SET ARRSource='Basic - Team 10/Business 10 Non-Trial Wins'
WHERE ARRSource IS NULL AND recordType='NEW' AND NewProductName NOT IN ('Enterprise', 'Enterprise_Legacy') AND NewUserLimit <= 10;

UPDATE rpt_workspace.js_actualsStaging
SET ARRSource='Team 10+/Business 10+ & Enterprise Wins'
WHERE ARRSource IS NULL AND recordType='NEW' AND (NewProductName IN ('Enterprise', 'Enterprise_Legacy') OR (NewProductName IN ('Team','Business') AND NewUserLimit > 10));



UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2016-11-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2016-11-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2016-11-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2016-11-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2016-11-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-11';



UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2016-12-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2016-12-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2016-12-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2016-12-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2016-12-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2016-12';


UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-01-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-01-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-01-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-01-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-01-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-01';


UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-02-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-02';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-02-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-02';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-02-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-02';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-02-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-02';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-02-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-02';


UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-03-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-03';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-03-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-03';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-03-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-03';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-03-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-03';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-03-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-03';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-04-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-04';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-04-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-04';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-04-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-04';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-04-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-04';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-04-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-04';


UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-05-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-05';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-05-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-05';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-05-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-05';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-05-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-05';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-05-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-05';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-06-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-06';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-06-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-06';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-06-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-06';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-06-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-06';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-06-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-06';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-07-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-07';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-07-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-07';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-07-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-07';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-07-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-07';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-07-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-07';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-08-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-08';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-08-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-08';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-08-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-08';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-08-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-08';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-08-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-08';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-09-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-09';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-09-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-09';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-09-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-09';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-09-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-09';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-09-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-09';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-10-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-10';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-10-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-10';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-10-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-10';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-10-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-10';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-10-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-10';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-11-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-11-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-11-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-11-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-11-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-11';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2017-12-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2017-12-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2017-12-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2017-12-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2017-12-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2017-12';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR < 500 AND B.monthYear='2018-01-01' AND B.ISP IS NULL
SET A.ARRSource='<.5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2018-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 500 AND B.ARR < 1000 AND B.monthYear='2018-01-01' AND B.ISP IS NULL
SET A.ARRSource='.5K-1K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2018-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 1000 AND B.ARR < 5000 AND B.monthYear='2018-01-01' AND B.ISP IS NULL
SET A.ARRSource='1K-5K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2018-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 5000 AND B.ARR < 25000 AND B.monthYear='2018-01-01' AND B.ISP IS NULL
SET A.ARRSource='5K-25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2018-01';

UPDATE rpt_workspace.js_actualsStaging A
JOIN rpt_workspace.js_acvBandsCustomers B
ON A.domain=B.customer AND B.ARR >= 25000 AND B.monthYear='2018-01-01' AND B.ISP IS NULL
SET A.ARRSource='>25K ARR Base'
WHERE A.recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m')='2018-01';


UPDATE rpt_workspace.js_actualsStaging A
SET ARRSource='ISP Base'
WHERE ISP=1 AND recordType='EXPANSION' AND DATE_FORMAT(A.recordDateTime, '%Y-%m') IN ('2016-11','2016-12','2017-01','2017-02','2017-03','2017-04', '2017-05', '2017-06', '2017-07', '2017-08', '2017-09', '2017-10', '2017-11', '2017-12', '2018-01');

UPDATE rpt_workspace.js_actualsStaging A
SET ARRSource='Previously Paying Base'
WHERE recordType='EXPANSION' AND ARRSource IS NULL AND DATE_FORMAT(A.recordDateTime, '%Y-%m') IN ('2016-11','2016-12','2017-01','2017-02','2017-03','2017-04', '2017-05', '2017-06', '2017-07', '2017-08', '2017-09', '2017-10', '2017-11', '2017-12', '2018-01');


UPDATE rpt_workspace.js_monthlyPerformance A
SET unassistedActualToDate=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE A.recordType=B.recordType AND assistedType='Unassisted' AND B.recordDate >= DATE_FORMAT(A.dayDate, '%Y-%m-01') AND B.recordDate <= A.dayDate)
WHERE dayDate < CURRENT_DATE;

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedActualToDate=0
WHERE unassistedActualToDate IS NULL AND dayDate < CURRENT_DATE;

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedActualPerBuyingDay=unassistedActualToDate/buyingDaysToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedActualTotal=unassistedActualPerBuyingDay*buyingDaysTotal;

UPDATE rpt_workspace.js_monthlyPerformance A
SET assistedCommercialActualToDate=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE A.recordType=B.recordType AND assistedType='Commercial Assisted' AND B.recordDate >= DATE_FORMAT(A.dayDate, '%Y-%m-01') AND B.recordDate <= A.dayDate)
WHERE dayDate < CURRENT_DATE;

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialActualToDate=0
WHERE assistedCommercialActualToDate IS NULL AND dayDate < CURRENT_DATE;

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialActualPerBuyingDay=assistedCommercialActualToDate/buyingDaysToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialActualTotal=assistedCommercialActualPerBuyingDay*buyingDaysTotal;

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialActualToDate=assistedCommercialActualToDate+unassistedActualToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialActualPerBuyingDay=commercialActualToDate/buyingDaysToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialActualTotal=commercialActualPerBuyingDay*buyingDaysTotal;


DROP TABLE IF EXISTS rpt_workspace.js_actualsStaging2;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_actualsStaging2
(recordType VARCHAR(50),
assistedType VARCHAR(50),
actualMTD DEC(10,2));

INSERT INTO rpt_workspace.js_actualsStaging2
SELECT recordType, 'Commercial Assisted', assistedCommercialActualToDate FROM rpt_workspace.js_monthlyPerformance
WHERE dayDate = DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

INSERT INTO rpt_workspace.js_actualsStaging2
SELECT recordType, 'Unassisted', unassistedActualToDate FROM rpt_workspace.js_monthlyPerformance
WHERE dayDate = DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialForecastTotal=
(SELECT (j2.forecast)+j1.actualMTD FROM rpt_workspace.js_actualsStaging2 j1
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2 
WHERE dayDate >= CURRENT_DATE AND monthYear=DATE_FORMAT(CURRENT_DATE, '%M %Y') AND recordType = 'NEW' AND assistedType='Commercial Assisted' GROUP BY 1) j2
WHERE j1.assistedType='Commercial Assisted' AND j1.recordType='NEW' LIMIT 1)
WHERE dayDate = DATE_SUB(CURRENT_DATE,INTERVAL 1 DAY) AND recordType='NEW';

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialForecastTotal=
(SELECT (j2.forecast)+j1.actualMTD FROM rpt_workspace.js_actualsStaging2 j1
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2 
WHERE dayDate >= CURRENT_DATE AND monthYear=DATE_FORMAT(CURRENT_DATE, '%M %Y') AND recordType = 'EXPANSION' AND assistedType='Commercial Assisted' GROUP BY 1) j2
WHERE j1.assistedType='Commercial Assisted' AND j1.recordType='EXPANSION' LIMIT 1)
WHERE dayDate = DATE_SUB(CURRENT_DATE,INTERVAL 1 DAY) AND recordType='EXPANSION';

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedForecastTotal=
(SELECT (j2.forecast)+j1.actualMTD FROM rpt_workspace.js_actualsStaging2 j1
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2 
WHERE dayDate >= CURRENT_DATE AND monthYear=DATE_FORMAT(CURRENT_DATE, '%M %Y') AND recordType = 'NEW' AND assistedType='Unassisted' GROUP BY 1) j2
WHERE j1.assistedType='Unassisted' AND j1.recordType='NEW' LIMIT 1)
WHERE dayDate = DATE_SUB(CURRENT_DATE,INTERVAL 1 DAY) AND recordType='NEW';

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedForecastTotal=
(SELECT (j2.forecast)+j1.actualMTD FROM rpt_workspace.js_actualsStaging2 j1
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2 
WHERE dayDate >= CURRENT_DATE AND monthYear=DATE_FORMAT(CURRENT_DATE, '%M %Y') AND recordType = 'EXPANSION' AND assistedType='Unassisted' GROUP BY 1) j2
WHERE j1.assistedType='Unassisted' AND j1.recordType='EXPANSION' LIMIT 1)
WHERE dayDate = DATE_SUB(CURRENT_DATE,INTERVAL 1 DAY) AND recordType='EXPANSION';



UPDATE rpt_workspace.js_monthlyPerformance A
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2
WHERE recordType = 'NEW' AND assistedType='Commercial Assisted' GROUP BY monthYear) B
ON A.monthYear=B.monthYear
SET assistedCommercialForecastTotal=forecast
WHERE recordType='NEW' AND dayDate IN (DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'));

UPDATE rpt_workspace.js_monthlyPerformance A
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2
WHERE recordType = 'EXPANSION' AND assistedType='Commercial Assisted' GROUP BY monthYear) B
ON A.monthYear=B.monthYear
SET assistedCommercialForecastTotal=forecast
WHERE recordType='EXPANSION' AND dayDate IN (DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'));

UPDATE rpt_workspace.js_monthlyPerformance A
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2
WHERE recordType = 'NEW' AND assistedType='Unassisted' GROUP BY monthYear) B
ON A.monthYear=B.monthYear
SET unassistedForecastTotal=forecast
WHERE recordType='NEW' AND dayDate IN (DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'));

UPDATE rpt_workspace.js_monthlyPerformance A
JOIN (SELECT monthYear, SUM(ARRForecast) AS forecast FROM rpt_main_02.stg_forecastMiddleTable2
WHERE recordType = 'EXPANSION' AND assistedType='Unassisted' GROUP BY monthYear) B
ON A.monthYear=B.monthYear
SET unassistedForecastTotal=forecast
WHERE recordType='EXPANSION' AND dayDate IN (DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'));

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialForecastTotal=assistedCommercialForecastTotal+unassistedForecastTotal;

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialForecastPerBuyingDay=assistedCommercialForecastTotal/buyingDaysTotal;

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedForecastPerBuyingDay=unassistedForecastTotal/buyingDaysTotal;

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialForecastPerBuyingDay=commercialForecastTotal/buyingDaysTotal;

UPDATE rpt_workspace.js_monthlyPerformance
SET assistedCommercialForecastToDate=assistedCommercialForecastPerBuyingDay*buyingDaysToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET unassistedForecastToDate=unassistedForecastPerBuyingDay*buyingDaysToDate;

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialForecastToDate=assistedCommercialForecastToDate+unassistedForecastToDate;


DROP TABLE IF EXISTS rpt_workspace.js_commercialDailyActuals;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_commercialDailyActuals
(dayDate DATE,
commercialAssistedNewARR DEC(10,2),
commercialAssistedExpansionARR DEC(10,2),
unassistedNewARR DEC(10,2),
unassistedExpansionARR DEC(10,2),
PRIMARY KEY (dayDate));

INSERT INTO rpt_workspace.js_commercialDailyActuals(dayDate)
SELECT dailyDate FROM rpt_main_02.ref_Dates
WHERE dailyDate >= '2016-01-01' AND dailyDate < CURRENT_DATE;

UPDATE rpt_workspace.js_commercialDailyActuals A
SET commercialAssistedNewARR=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE B.assistedType='Commercial Assisted' AND B.recordType='NEW' AND A.dayDate=B.recordDate);

UPDATE rpt_workspace.js_commercialDailyActuals A
SET commercialAssistedExpansionARR=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE B.assistedType='Commercial Assisted' AND B.recordType='EXPANSION' AND A.dayDate=B.recordDate);

UPDATE rpt_workspace.js_commercialDailyActuals A
SET unassistedNewARR=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE B.assistedType='Unassisted' AND B.recordType='NEW' AND A.dayDate=B.recordDate);

UPDATE rpt_workspace.js_commercialDailyActuals A
SET unassistedExpansionARR=
(SELECT SUM(ARR) FROM rpt_workspace.js_actualsStaging B
WHERE B.assistedType='Unassisted' AND B.recordType='EXPANSION' AND A.dayDate=B.recordDate);

UPDATE rpt_workspace.js_commercialDailyActuals
SET commercialAssistedNewARR=0
WHERE commercialAssistedNewARR IS NULL;

UPDATE rpt_workspace.js_commercialDailyActuals
SET commercialAssistedExpansionARR=0
WHERE commercialAssistedExpansionARR IS NULL;

UPDATE rpt_workspace.js_commercialDailyActuals
SET unassistedNewARR=0
WHERE unassistedNewARR IS NULL;

UPDATE rpt_workspace.js_commercialDailyActuals
SET unassistedExpansionARR=0
WHERE unassistedExpansionARR IS NULL;


DROP TABLE IF EXISTS rpt_workspace.js_runRateFormula1;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_runRateFormula1
(dayDate DATE,
buyingDayFactor DEC(10,2),
recordType VARCHAR(50),
commercialAssisted DEC(10,2),
unassisted DEC(10,2),
INDEX (dayDate));

INSERT INTO rpt_workspace.js_runRateFormula1(dayDate, buyingDayFactor, recordType)
SELECT dayDate, buyingDayFactor, recordType FROM rpt_workspace.js_monthlyPerformance
WHERE dayDate >= DATE_SUB(CURRENT_DATE, INTERVAL 35 DAY) AND dayDate < CURRENT_DATE;

UPDATE rpt_workspace.js_runRateFormula1 A
JOIN rpt_workspace.js_commercialDailyActuals B
ON A.dayDate=B.dayDate AND A.recordType='NEW' 
SET A.commercialAssisted=B.commercialAssistedNewARR;

UPDATE rpt_workspace.js_runRateFormula1 A
JOIN rpt_workspace.js_commercialDailyActuals B
ON A.dayDate=B.dayDate AND A.recordType='EXPANSION' 
SET A.commercialAssisted=B.commercialAssistedExpansionARR;

UPDATE rpt_workspace.js_runRateFormula1 A
JOIN rpt_workspace.js_commercialDailyActuals B
ON A.dayDate=B.dayDate AND A.recordType='NEW' 
SET A.unassisted=B.unassistedNewARR;

UPDATE rpt_workspace.js_runRateFormula1 A
JOIN rpt_workspace.js_commercialDailyActuals B
ON A.dayDate=B.dayDate AND A.recordType='EXPANSION' 
SET A.unassisted=B.unassistedExpansionARR;

DROP TABLE IF EXISTS rpt_workspace.js_runRateFormula2;
CREATE TABLE IF NOT EXISTS rpt_workspace.js_runRateFormula2
(buyingDayTotal DEC(10,2),
recordType VARCHAR(50),
commercialAssistedTotal DEC(10,2),
unassistedTotal DEC(10,2),
commercialAssistedPerBuyingDay DEC(10,2),
unassistedPerBuyingDay DEC(10,2));

INSERT INTO rpt_workspace.js_runRateFormula2(buyingDayTotal, recordType, commercialAssistedTotal, unassistedTotal)
SELECT SUM(buyingDayFactor), recordType, SUM(commercialAssisted), SUM(unassisted) FROM rpt_workspace.js_runRateFormula1
WHERE recordType='NEW';

INSERT INTO rpt_workspace.js_runRateFormula2(buyingDayTotal, recordType, commercialAssistedTotal, unassistedTotal)
SELECT SUM(buyingDayFactor), recordType, SUM(commercialAssisted), SUM(unassisted) FROM rpt_workspace.js_runRateFormula1
WHERE recordType='EXPANSION';

UPDATE rpt_workspace.js_runRateFormula2
SET commercialAssistedPerBuyingDay=commercialAssistedTotal/buyingDayTotal;

UPDATE rpt_workspace.js_runRateFormula2
SET unassistedPerBuyingDay=unassistedTotal/buyingDayTotal;


UPDATE rpt_workspace.js_monthlyPerformance A
JOIN rpt_workspace.js_runRateFormula2 B
ON A.recordType=B.recordType
SET A.commercialForecastLogicPerBuyingDay=B.commercialAssistedPerBuyingDay
WHERE dayDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

UPDATE rpt_workspace.js_monthlyPerformance A
JOIN rpt_workspace.js_runRateFormula2 B
ON A.recordType=B.recordType
SET A.unasisstedForecastLogicPerBuyingDay=B.unassistedPerBuyingDay
WHERE dayDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

UPDATE rpt_workspace.js_monthlyPerformance
SET commercialForecastLogicTotal=commercialForecastLogicPerBuyingDay*buyingDaysTotal
WHERE dayDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);

UPDATE rpt_workspace.js_monthlyPerformance
SET unasisstedForecastLogicTotal=unasisstedForecastLogicPerBuyingDay*buyingDaysTotal
WHERE dayDate=DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY);


(SELECT * FROM rpt_workspace.js_monthlyPerformance
WHERE dayDate IN (DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 4 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 5 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 8 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 9 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 10 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 11 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 13 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 14 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 15 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 16 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 17 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'))
AND CURRENT_DATE!=DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
ORDER BY recordType, dayDate)

UNION

(SELECT * FROM rpt_workspace.js_monthlyPerformance
WHERE dayDate IN (CURRENT_DATE,
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'), 
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 3 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 4 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 5 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 8 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 9 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 10 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 11 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 13 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 14 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 15 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 16 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_SUB(CURRENT_DATE, INTERVAL 17 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH)), '%Y-%m-%d'),
DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d'))
AND CURRENT_DATE=DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
ORDER BY recordType, dayDate);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-forecastingResultsV2.sql");


