SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("Last3MonthsFailedPaymentsV2.sql");

drop table rpt_workspace.pj_last3MonthTransactions;
create table rpt_workspace.pj_last3MonthTransactions
(monthFriendly varchar(30),
monthStart datetime,
monthEnd datetime,
paymentProfileID int(15),
mainContactUserID int(15),
mainContactEmailAddress varchar(100),
SysAdminEmailAddress varchar(100),
billToRecurringBillingID varchar(50),
paymentStartDateTime datetime,
paymentType int,
paymentTerm int,
planRate_USD decimal(10,2),
midMonthChanges decimal(10,2),
bookingsPayment decimal(10,2),
transactionsPayment decimal(10,2),
paymentTermChange datetime,
proratedMidMonthChanges decimal(10,2),
hasNotValidTransaction int,
everNotValidTransaction int,
blockedAccount int,
userAccountModifyDateTime datetime,
firstFailedPayment Datetime,
LastFailedPaymentResult int,
primary key (monthFriendly, paymentProfileID),
index(paymentProfileID),
index(monthStart));

insert into rpt_workspace.pj_last3MonthTransactions(monthFriendly,monthStart,monthEnd, paymentProfileID,mainContactUserID, mainContactEmailAddress, paymentStartDateTime, billToRecurringBillingID)
select ref.monthFriendly, ref.startMonth, ref.endMonth, pp.paymentProfileID,mainContactUserID,mainContactEmailAddress, pp.paymentStartDateClean, billToRecurringBillingID
from rpt_main_02.rpt_paymentProfile pp
	join rpt_main_02.ref_months ref on ref.startMonth >= pp.paymentStartDateClean and ref.startMonth > date_sub(current_date(), interval 4 month) and ref.startMonth < date_format(current_date(), '%Y-%m')
where pp.planRate_USD > 0 and pp.paymentTypeFriendly IN ('Credit Card','Paypal')
group by ref.startMonth, ref.endMonth, pp.paymentProfileID;

update rpt_workspace.pj_last3MonthTransactions pj 
join  ss_core_02.paymentHistory ph
ON ph.paymentProfileID = pj.paymentPRofileID 
and date_format(pj.MonthStart, '%Y-%m') = date_format(ph.paymentDateTime, '%Y-%m')
and result != 0
set hasNotValidTransaction = 1;

update rpt_workspace.pj_last3MonthTransactions pj 
join  ss_core_02.paymentHistory ph
ON ph.paymentProfileID = pj.paymentPRofileID 
and date(ph.paymentDateTime) >= date_sub(current_date(), interval 4 month)
and date_format(ph.paymentDateTime, '%Y-%m') < date_format(current_date(), '%Y-%m')
and result != 0
set everNotValidTransaction = 1;

delete from rpt_workspace.pj_last3MonthTransactions where everNotValidTransaction is null;

update rpt_workspace.pj_last3MonthTransactions pj
	join rpt_main_02.userAccount ua on ua.userID = pj.mainContactUserID
set blockedAccount = case when statusFlags & 16 = 1 then 1 else 0 end,
userAccountModifyDateTime = ua.modifyDateTime;

update rpt_workspace.pj_last3MonthTransactions pj
set firstFailedPayment = 
(select min(paymentDateTime)
from ss_core_02.paymentHistory ph
where ph.paymentProfileID = pj.paymentPRofileID 
and date(ph.paymentDateTime) >= date_sub(current_date(), interval 4 month)
and date_format(ph.paymentDateTime, '%Y-%m') < date_format(current_date(), '%Y-%m')
and result != 0);

update rpt_workspace.pj_last3MonthTransactions pj
join (select paymentProfileID, max(paymentDateTime) as maxDate from ss_core_02.paymentHistory ph
	where date(ph.paymentDateTime) >= date_sub(current_date(), interval 4 month)
    and date_format(ph.paymentDateTime, '%Y-%m') < date_format(current_date(), '%Y-%m') and result != 0 group by 1) stg on stg.paymentProfileID = pj.paymentProfileID
join ss_core_02.paymentHistory ph on ph.paymentProfileID = stg.paymentProfileID and ph.paymentDateTime=stg.maxDate
set pj.LastFailedPaymentResult = ph.result;

SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
update rpt_workspace.pj_last3MonthTransactions pj
	join rpt_main_02.hist_paymentProfile pp on pp.paymentProfileID = pj.paymentProfileID and pp.planRate_USD > 0 and pj.monthStart between pp.modifyDateTime and pp.hist_effectiveThruDateTime
    join rpt_main_02.hist_currencyExchange hce on pp.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode and pp.modifyDateTime between hce.modifyDateTime and hce.hist_effectiveThruDateTime
set pj.paymentType = pp.paymentType,
pj.paymentTerm = pp.paymentTerm,
pj.planRate_USD = (pp.planRate+planTaxRate)/hce.exchangeRate;

update rpt_workspace.pj_last3MonthTransactions p1
	join  rpt_workspace.pj_last3MonthTransactions p2  on p1.monthStart = date_add(p2.monthStart, interval 1 month) 
		and p1.paymentTerm != p2.paymentTerm
        and p1.paymentProfileID = p2.paymentProfileID
set p1.paymentTermChange = p2.monthStart ;

update rpt_workspace.pj_last3MonthTransactions p1
set p1.paymentTermChange =
(select max(hist_effectiveThruDateTime)
from rpt_main_02.hist_paymentProfile pp
where pp.paymentProfileID = p1.paymentProfileID 
and pp.hist_effectiveThruDateTime < p1.monthStart 
and pp.planRate > 0
and pp.paymentTerm = 1)
where  p1.paymentTerm = 12
and p1.paymentTermChange is null;

create table if not exists rpt_workspace.pj_last3MonthTransactions2 like rpt_workspace.pj_last3MonthTransactions; 
truncate table rpt_workspace.pj_last3MonthTransactions2;
insert into rpt_workspace.pj_last3MonthTransactions2
select * from rpt_workspace.pj_last3MonthTransactions ;

update rpt_workspace.pj_last3MonthTransactions p1
set p1.paymentTermChange = 
(select max(p2.paymentTermChange)
from rpt_workspace.pj_last3MonthTransactions2 p2
where p1.monthStart  > p2.monthStart
and p1.paymentProfileID = p2.paymentProfileID)
where p1.paymentTermChange is null;

update rpt_workspace.pj_last3MonthTransactions set paymentTermChange = paymentStartDateTime where paymentTermChange is null;

update rpt_workspace.pj_last3MonthTransactions pj 
	join rpt_main_02.output_RevenueSummaryMonthly rsm on rsm.paymentProfileID = pj.paymentProfileID 
		and date_format(rsm.recordDateTime, '%Y-%m') = date_format(pj.monthStart, '%Y-%m') and currencyChange = 0 and futureLoss is null and MonthlyPaymentChange > 0
set pj.midMonthChanges = (MonthlyPaymentChange*newPaymentTerm);

update rpt_workspace.pj_last3MonthTransactions set proratedMidMonthChanges = (case when month(monthStart) < month(paymentTermChange) then abs(month(monthStart)-month(paymentTermChange))*(midMonthChanges/12) 
		else (12-abs(month(monthStart)-month(paymentTermChange)))*(midMonthChanges/12) end);

update rpt_workspace.pj_last3MonthTransactions pj set midMonthChanges = 0 where midMonthChanges is null;

update rpt_workspace.pj_last3MonthTransactions pj 
set bookingsPayment = case when date_format(pj.monthStart, '%Y-%m') = date_format(date_add(pj.paymentTermChange, interval 1 month), '%Y-%m') and paymentTermChange > '2016-01-01' and paymentTermChange != paymentStartDateTime and paymentTerm = 12 then (planRate_USD+midMonthChanges)
	when month(pj.paymentTermChange) = month(pj.monthStart) and paymentTerm = 12 then (planRate_USD+midMonthChanges)
	when paymentTerm = 1 then (planRate_USD+midMonthChanges) end;

-- update rpt_workspace.pj_monthlyTransactions pj 
-- set bookingsPayment = case when  bookingsPayment is null and paymentTerm = 12 then proratedMidMonthChanges else 0 end
-- where bookingsPayment is null;

update rpt_workspace.pj_last3MonthTransactions pj 
SET pj.bookingsPayment = 
(SELECT SUM(ph.paymentAmount/hce.exchangeRate)
FROM ss_core_02.paymentHistory ph
	join rpt_main_02.hist_currencyExchange hce on ph.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode and ph.paymentDateTime between hce.modifyDateTime and hce.hist_effectiveThruDateTime
WHERE ph.paymentProfileID = pj.paymentPRofileID 
and date_format(pj.MonthStart, '%Y-%m') = date_format(ph.paymentDateTime, '%Y-%m')
and paymentMessage like '%prorated%'
and result = 0)
where bookingsPayment is null;

update rpt_workspace.pj_last3MonthTransactions pj 
SET pj.transactionsPayment = 
(SELECT SUM(ph.paymentAmount/hce.exchangeRate)
FROM ss_core_02.paymentHistory ph
	join rpt_main_02.hist_currencyExchange hce on ph.currencyCode COLLATE utf8mb4_unicode_520_ci = hce.currencyCode and ph.paymentDateTime between hce.modifyDateTime and hce.hist_effectiveThruDateTime
WHERE ph.paymentProfileID = pj.paymentPRofileID 
and date_format(pj.MonthStart, '%Y-%m') = date_format(ph.paymentDateTime, '%Y-%m')
and (paymentMessage not like '%Service%' or paymentMessage not like '%training%' or paymentMessage not like '%onboarding%' or paymentMessage not like '%start%' or paymentMessage != 'Design Desk Sessions' or paymentMessage is null)
and result = 0);

update rpt_workspace.pj_last3MonthTransactions pj 
	join rpt_main_02.rpt_paidPlanCurrentUsers ppcu on ppcu.planID = pj.paymentPRofileID and sysAdmin = 1
    join rpt_main_02.userAccount ua on ua.userID=ppcu.mainContactUserID
set pj.SysAdminEmailAddress = ua.emailAddress;

update rpt_workspace.pj_last3MonthTransactions set hasNotValidTransaction = 0 where hasNotValidTransaction is null;
update rpt_workspace.pj_last3MonthTransactions set everNotValidTransaction = 0 where everNotValidTransaction is null;

update rpt_workspace.pj_last3MonthTransactions pj  set transactionsPayment = 0 where transactionsPayment is null;
update rpt_workspace.pj_last3MonthTransactions pj  set bookingsPayment = 0 where bookingsPayment is null;

drop table rpt_workspace.pj_last3MonthTransactions_Final;
create table rpt_workspace.pj_last3MonthTransactions_Final
select paymentProfileID, 
paymentStartDateTime,
billToRecurringBillingID as RPID,
mainContactEmailAddress,
SysAdminEmailAddress,
blockedAccount,
date(max(case when hasNotValidTransaction = 1 then monthStart else null end)) as lastFailedPaymentMonth,
sum(bookingsPayment) as bookingsPayment, 
sum(transactionsPayment) as transactionsPayment ,
sum(bookingsPayment) - sum(transactionsPayment) as difference,
everNotValidTransaction,
concat(paymentProfileID,"-",date(max(case when hasNotValidTransaction = 1 then monthStart else null end))) as UniqueID,
userAccountModifyDateTime,
datediff(curdate(), firstFailedPayment) as daysSinceFirstFailedPayment,
LastFailedPaymentResult
from rpt_workspace.pj_last3MonthTransactions
group by 1 
having difference != 0
order by difference desc;

alter table rpt_workspace.pj_last3MonthTransactions_Final add primary key (paymentProfileID);
delete from rpt_workspace.pj_last3MonthTransactions_Final where difference < 0;

select * from rpt_workspace.pj_last3MonthTransactions_Final where UniqueID is not null;
/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("Last3MonthsFailedPaymentsV2.sql");
