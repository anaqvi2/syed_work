SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("dailyActiveUsersV2.csv");

SELECT DATE_SUB(MAX(DATE), INTERVAL 1 DAY) FROM rpt_workspace.cDunn_dailyInApp INTO @maxDate;

DELETE FROM rpt_workspace.cDunn_dailyInApp WHERE DATE >= @maxDate;

SELECT MIN(Id) FROM rpt_main_02.arc_clientEventRollup WHERE logDate >= @maxDate INTO @StartId;


INSERT IGNORE INTO rpt_workspace.cDunn_dailyInApp (DATE, userID, usageType)
SELECT logDate, insertByUserID, "App Client Events"
FROM rpt_main_02.arc_clientEventRollup WHERE id >= @StartId GROUP BY 1,2;

UPDATE rpt_workspace.cDunn_dailyInApp A
JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = A.userID AND A.date BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime
	AND hpp.accountType != 3 AND hpp.productID IN(3,4,6,7,10,11)
SET A.userType = 'LicensedUser' 
WHERE A.userType IS NULL AND A.date >= @maxDate;

UPDATE rpt_workspace.cDunn_dailyInApp A
JOIN rpt_main_02.hist_paymentProfile hpp ON hpp.ownerID = A.userID AND A.date BETWEEN hpp.modifyDateTime AND hpp.hist_effectiveThruDateTime
	AND hpp.accountType != 3 AND hpp.productID = 1
SET A.userType = 'Trial' 
WHERE A.userType IS NULL AND A.date >= @maxDate;

UPDATE rpt_workspace.cDunn_dailyInApp A
JOIN rpt_main_02.rpt_paidPlanSheetAccess ppsa ON ppsa.userID = A.userID AND A.date > ppsa.minCollabDate AND ppsa.userPlanID IS NULL
SET A.userType = 'Collab Associated with Paid Plan' 
WHERE A.userType IS NULL AND A.date >= @maxDate;

UPDATE rpt_workspace.cDunn_dailyInApp A
SET userType = 'Other Collab' WHERE userType IS NULL AND A.date >= @maxDate;


INSERT IGNORE INTO rpt_workspace.cDunn_dailyInApp
SELECT DATE_FORMAT(A.insertDateTime, '%Y-%m-%d'), A.userID,
CASE WHEN ppcu.mainContactUserID IS NOT NULL THEN 'LicensedUser'
	WHEN pp.mainContactUserID IS NOT NULL THEN 'Trial'
	WHEN ppsa.userID IS NOT NULL THEN 'Collab Associated with Paid Plan' 
	ELSE 'Other Collab' END AS UserType, "Mobile-Only Events"
FROM rpt_main_02.rpt_nativeAppSessions A
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = A.userID
LEFT OUTER JOIN rpt_main_02.rpt_paidPlanSheetAccess ppsa ON ppsa.userID = A.userID AND ppsa.loginCount > 0 AND ppsa.userPlanID IS NULL
LEFT JOIN rpt_main_02.rpt_paymentProfile pp FORCE INDEX (idx_rpt_paymentProfileMainContactUserID) ON pp.mainContactUserID = A.userID AND pp.accountType != 3 AND pp.productID = 1
WHERE A.insertDateTime >= @maxDate
GROUP BY 1,2;

DELETE FROM rpt_workspace.cDunn_inAppOutputDaily WHERE DATE >= @maxDate;

SELECT MAX(DATE) FROM rpt_workspace.cDunn_inAppOutputDaily WHERE DATE < CURRENT_DATE() INTO @maxDateInsert;

INSERT INTO rpt_workspace.cDunn_inAppOutputDaily
SELECT A.date,
A.userType,
A.usageType,
	COUNT(DISTINCT(A.userID)) AS Users	
FROM rpt_workspace.cDunn_dailyInApp A
WHERE DATE = DATE_ADD(@maxDateInsert, INTERVAL 1 DAY)
GROUP BY 1,2,3
;

SELECT MAX(DATE) FROM rpt_workspace.cDunn_inAppOutputDaily INTO @maxDateInsert;

INSERT INTO rpt_workspace.cDunn_inAppOutputDaily
SELECT A.date,
A.userType,
A.usageType,
	COUNT(DISTINCT(A.userID)) AS Users	
FROM rpt_workspace.cDunn_dailyInApp A
WHERE DATE = DATE_ADD(@maxDateInsert, INTERVAL 1 DAY)
GROUP BY 1,2,3
;

SELECT MAX(DATE) FROM rpt_workspace.cDunn_inAppOutputDaily INTO @maxDateInsert;

INSERT INTO rpt_workspace.cDunn_inAppOutputDaily
SELECT A.date,
A.userType,
A.usageType,
	COUNT(DISTINCT(A.userID)) AS Users	
FROM rpt_workspace.cDunn_dailyInApp A
WHERE DATE = DATE_ADD(@maxDateInsert, INTERVAL 1 DAY)
GROUP BY 1,2,3
;

SELECT MAX(DATE) FROM rpt_workspace.cDunn_inAppOutputDaily INTO @maxDateInsert;

INSERT INTO rpt_workspace.cDunn_inAppOutputDaily
SELECT A.date,
A.userType,
A.usageType,
	COUNT(DISTINCT(A.userID)) AS Users	
FROM rpt_workspace.cDunn_dailyInApp A
WHERE DATE = DATE_ADD(@maxDateInsert, INTERVAL 1 DAY)
GROUP BY 1,2,3
;

SELECT MAX(DATE) FROM rpt_workspace.cDunn_inAppOutputDaily INTO @maxDateInsert;

INSERT INTO rpt_workspace.cDunn_inAppOutputDaily
SELECT A.date,
A.userType,
A.usageType,
	COUNT(DISTINCT(A.userID)) AS Users	
FROM rpt_workspace.cDunn_dailyInApp A
WHERE DATE = DATE_ADD(@maxDateInsert, INTERVAL 1 DAY)
GROUP BY 1,2,3
;

SELECT * FROM rpt_workspace.cDunn_inAppOutputDaily 
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("dailyActiveUsersV2.csv");
