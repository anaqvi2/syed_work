/* Script was use to remove duplicates and create primary key for rpt_main_02.arc_clientEventRollup*/
 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("bookingRecords.sql");

DROP TABLE rpt_main_02.rpt_bookingRecords;
CREATE TABLE rpt_main_02.rpt_bookingRecords
(recordDateTime DATETIME,
record VARCHAR(100),
amount DECIMAL(10,2),
PRIMARY KEY (recordDateTime, record));

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today ARR", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today Gross", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES')
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today Assisted", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today Commercial", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesTeam = 'Commercial Assisted'
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today Unassisted", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 0
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today CDM", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'CDM'
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today NBR", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NBR'
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today NAS", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NAS'
GROUP BY 1;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime, '%Y-%m-%d'), "Today Losses", SUM(MonthlyPaymentChange)*12 
FROM rpt_main_02.output_RevenueSummaryMonthlyTableau 
WHERE DATE_FORMAT(recordDateTime, '%Y-%m-%d') = DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 1 DAY), '%Y-%m-%d')
AND currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('DOWNGRADES','LOSSES')
GROUP BY 1;



INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month ARR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL 
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month Gross Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES')
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month Assisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month Commercial Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesTeam = 'Commercial Assisted'
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month Unassisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 0 
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month CDM Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'CDM'
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month NBR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NBR'
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month NAS Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NAS'
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Month Loss Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('LOSSES','DOWNGRADES')
AND DATE_FORMAT(recordDateTime, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m')
GROUP BY 1
ORDER BY 3 LIMIT 1
;



INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter ARR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL 
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter Gross Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') 
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter Assisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter Commercial Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesTeam = 'Commercial Assisted'
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter Unassisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 0
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter CDM Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'CDM'
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter NBR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NBR'
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter NAS Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NAS'
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "Fiscal Quarter Loss Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('LOSSES','DOWNGRADES')
AND QUARTER(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = QUARTER(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
AND DATE_FORMAT(recordDateTime, '%Y') = DATE_FORMAT(CURRENT_DATE, '%Y')
GROUP BY 1
ORDER BY 3 LIMIT 1
;


INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY ARR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL 
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY Gross Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES')
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY Assisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY Commercial Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesTeam = 'Commercial Assisted'
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY Unassisted Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 0
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY CDM Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'CDM'
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY NBR Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NBR'
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY NAS Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('WINS','UPGRADES') AND salesAssisted = 1 AND salesRepRole = 'NAS'
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 DESC LIMIT 1
;

INSERT INTO rpt_main_02.rpt_bookingRecords
SELECT DATE_FORMAT(recordDateTime,'%Y-%m-%d'), "FY Loss Record", SUM(MonthlyPaymentChange)*12
FROM rpt_main_02.output_RevenueSummaryMonthly
WHERE currencyChange = 0 AND futureLoss IS NULL AND domainLevelRecordType IN('LOSSES','DOWNGRADES')
AND YEAR(DATE_SUB(DATE_FORMAT(recordDateTime, '%Y-%m-%d'), INTERVAL 1 MONTH)) = YEAR(DATE_SUB(DATE_FORMAT(CURRENT_DATE, '%Y-%m-%d'), INTERVAL 1 MONTH))
GROUP BY 1
ORDER BY 3 LIMIT 1
;

SELECT * FROM rpt_main_02.rpt_bookingRecords;

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("bookingRecords.sql");
