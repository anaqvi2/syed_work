SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2017-11-14AccountDiscoveryV2.sql");

/* Client Events
7204 = Form - Request Org Invite - Prompted on login	Open
2001 = Button	Click	btn_notNow	7204
2001 = Button	Click	btn_close	7204
2001 = Button	Click	btn_requestToJoin	7204
2001 = Button	Click	btn_send	7046
7211 = Form - Request Org Invite - Opened from Account Admin > Plan & Billing Info tab	Open
2001 = Button	Click	btn_notNow	7211
2001 = Button	Click	btn_close	7211
2001 = Button	Click	btn_requestToJoin	7211

create table rpt_workspace.pj_abTest_AccountDiscovery_raw_CE like arc_clientEvent;
alter table rpt_workspace.pj_abTest_AccountDiscovery_raw_CE add insertbyuserID int(15);
alter table rpt_workspace.pj_abTest_FreeUserUpgrade_raw_CE add key(insertbyuserID);
*/


select max(clientEventID) from rpt_workspace.pj_abTest_AccountDiscovery_raw_CE into @maxID;

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert ignore into rpt_workspace.pj_abTest_AccountDiscovery_raw_CE(clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID)
select clientEventID, objectID, actionID, parm1String, parm1Int, eventDateTime, sessionLogID
from ss_log_02.clientEvent
where ((objectID = 2001 and actionID = 22 and parm1String in ('btn_notNow','btn_close','btn_requestToJoin','btn_send') and parm1Int IN (7204, 7046, 7221))
or (objectID IN (7204, 7211) and actionID = 1))
and eventDatetime >= '2017-11-14 23:00:00'
and clientEventid > 25582198707
and clientEventid > (@maxID-100000);

update rpt_workspace.pj_abTest_AccountDiscovery_raw_CE pj
	join ss_core_02.sessionLog sl on sl.sessionLogID= pj.sessionLogID and sl.sessionLogID > 550412936
set pj.insertbyuserID = sl.userID;


/*
drop table rpt_workspace.pj_AccountDiscovery_EmailSend;
CREATE TABLE rpt_workspace.pj_AccountDiscovery_EmailSend
(requestLogID bigint(20),
  sessionType tinyint(4),
  urlActionID tinyint(4),
  formName varchar(100),
  formAction varchar(100),
  parm1 varchar(1000),
  parm2 varchar(1000),
  parm3 varchar(1000),
  parm4 varchar(1000),
  insertByUserID bigint(20),
  insertDateTime datetime,
  sessionLogID bigint(20),
  PRIMARY KEY (requestLogID),
  KEY insertByUserID (insertByUserID),
  KEY sessionLogID (sessionLogID),
  KEY insertDateTime (insertDateTime));*/

select max(requestLogID) from rpt_workspace.pj_AccountDiscovery_EmailSend into @maxRequestLogID;

SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
insert ignore into rpt_workspace.pj_AccountDiscovery_EmailSend (requestLogID, sessionType, urlActionID, formName, formAction, parm1, parm2, parm3, parm4, insertByUserID, insertDateTime, sessionLogID)
select requestLogID, sessionType, urlActionID, formName, formAction, parm1, parm2, parm3, parm4, insertByUserID, insertDateTime, sessionLogID
from ss_log_02.requestLog
where formAction  = 'fa_sendEmailToOrgAdmins'
and insertDateTime > '2017-11-15 00:00:00'
and requestLogID >  17668653884
and requestLogID > (@maxRequestLogID-1000);


truncate table rpt_workspace.pj_accountDiscoveryABTest;
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert into rpt_workspace.pj_accountDiscoveryABTest
SELECT 
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
siteSettingElementValue.insertDateTime,
userAccount.insertDateTime as smartsheetInsertDate,
userAccount.domain,
(case when d.domain is not null then 0 else 1 end) IsOrgDomain,
rpt_main_02.hist_paymentProfile.productID as  insertProduct,

-- user data
CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,
userAccount.languageFriendly,
case when ddc.companySize is null then "Not Available" else ddc.companySize end,

-- usage Data
rpt_loginCountTotal.firstLogin,
rpt_loginCountTotal.lastLogin,
count(distinct case when ce.objectID = 7204 and ce.actionID = 1 then ce.clientEventID end) as sawAccountDiscoveryPrompt,
count(distinct case when ce.objectID = 2001 and ce.actionID = 22 and ce.parm1String IN ("btn_notNow","btn_close") and ce.parm1Int = 7204 then ce.clientEventID end) as clickedClose,
count(distinct case when ce.objectID = 2001 and ce.actionID = 22 and ce.parm1String = "btn_requestToJoin" and ce.parm1Int = 7204 then ce.clientEventID  end) as clickedRequestToJoin,
count(distinct case when ce.objectID = 7211 and ce.actionID = 1 then ce.clientEventID end) as sawAccountDiscoveryAccount,
count(distinct case when ce.objectID = 2001 and ce.actionID = 22 and ce.parm1String IN ("btn_notNow","btn_close") and ce.parm1Int = 7211 then ce.clientEventID  end) as clickedCloseViaAccount,
count(distinct case when ce.objectID = 2001 and ce.actionID = 22 and ce.parm1String = "btn_requestToJoin" and ce.parm1Int = 7211 then ce.clientEventID  end) as clickedRequestToJoinViaAccount,
count(distinct case when ce.objectID = 2001 and ce.actionID = 22 and ce.parm1String = "btn_send" and ce.parm1Int = 7046 then ce.clientEventID  end) as clickedSend,
count(distinct case when rl.formAction  = 'fa_sendEmailToOrgAdmins' then requestLogID end) as sentOrgAdminEmail,

-- user product
min(rpt_trials.trialDateTime) as trialDateTime,
rpt_trials.firstTrial,
rpt_trials.trialType,
-- rpt_paymentProfile.paymentStartDateClean,
rpt_paymentProfile.paymentStartDateClean,
CASE WHEN rpt_paymentProfile.planRate_USD > 0 then ((rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm)*12) else 0 end as ARR,
rpt_paymentProfile.userLimit,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_paymentProfile.productID) as 'Win Product',
CASE WHEN opp.parent_payment_profile_ID__c IS NOT NULL THEN 1 WHEN rpt_paymentProfile.planRate_USD > 0 AND opp.parent_payment_profile_ID__c IS NULL then 0 ELSE NULL END as salesAssisted,
-- rpt_paymentProfile.countAsPaid,
-- rpt_paymentProfile.hasPaid,
-- rpt_paymentProfile.daysToBuy,
rpt_paymentProfile.paymentTerm,
rpt_paymentProfile2.productID as currentProduct,
rpt_paymentProfile2.parentPaymentProfileID,
CASE WHEN rpt_paymentProfile2.productID IN (3,4,6,7,10,11) then rpt_paymentProfile2.paymentStartDateClean else null end as LicenseDateTime,
CASE WHEN rpt_paymentProfile2.productID IN (3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
rpt_main_02.SMARTSHEET_PRODUCTNAME(rpt_paymentProfile2.productID) as 'Licensed Product',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS 'Basic?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS 'Advanced?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS 'Team?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise_Legacy?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 11 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 10 THEN 1 ELSE 0 
		END 
	END AS 'Business?',
CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS 'Cancelled?',
0 as UpgradeARR
	
FROM rpt_main_02.siteSettingElementValue siteSettingElementValue
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_trials.userID = siteSettingElementValue.userID and siteSettingElementValue.insertDateTime <= rpt_trials.trialDateTime
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = siteSettingElementValue.userID
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3'
	and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
    
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON siteSettingElementValue.userID = rpt_paymentProfile.sourceUserID
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean >= Date_sub(siteSettingElementValue.insertDateTime, interval 1 minute) 
    AND rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.planRate_USD > 0
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > siteSettingElementValue.insertDateTime
LEFT OUTER JOIN ss_sfdc_02.opportunity opp on opp.parent_payment_profile_ID__c = rpt_paymentProfile.paymentProfileID AND parent_payment_profile_ID__c IS NOT NULL AND opp.product__c != 'Services'
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,rpt_paymentProfile.paymentStartDateClean),'%Y-%m') = DATE_FORMAT(opp.CloseDate,'%Y-%m')

LEFT OUTER JOIN rpt_workspace.pj_domainDataCoverage ddc on ddc.domain = userAccount.domain
LEFT OUTER JOIN rpt_workspace.pj_abTest_AccountDiscovery_raw_CE ce on ce.insertbyuserID = siteSettingElementValue.userID
LEFT OUTER JOIN rpt_workspace.pj_abTest_AccountDiscovery_raw_CE ce2 on ce2.insertbyuserID = siteSettingElementValue.userID and ce2.parm1String = "btn_requestToJoin"
LEFT OUTER JOIN rpt_workspace.pj_AccountDiscovery_EmailSend rl on rl.insertbyuserID = ce2.insertbyuserID and rl.sessionLogID = ce2.sessionLogID and rl.insertDateTime between ce2.eventDatetime and date_add(ce2.eventDatetime, interval 2 minute)
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains d on d.domain = userAccount.domain
where siteSettingElementName = 'SS_ABTEST_PROMPT_TO_REQUEST_ORG_INVITE' 
AND siteSettingElementValue.siteSettingElementValueID > 131673364
GROUP BY 1,2,3,4
Limit 1234568;

select * from rpt_workspace.pj_accountDiscoveryABTest;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2017-11-14AccountDiscoveryV2.sql");