SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("tableau-schmale-csDashboard12V2.sql");

drop table if exists rpt_workspace.js_csDashboardCWCL;
create table if not exists rpt_workspace.js_csDashboardCWCL
select distinct A.Id as opportunityID, A.Parent_Payment_Profile_ID__c as paymentProfileID, A.name as opportunityName, A.accountID, A.Product__c as opportunityType, A.StageName as opportunityStage,
A.Amount as ARRvarianceForecast, A.Services_ACV__c as servicesForecast, A.CreatedDate, concat(D.firstName,' ',D.lastName) as csRep, C.Name from ss_sfdc_02.opportunity A
join rpt_main_02.rpt_csPlanReport B
on A.accountId=B.accountID
join ss_sfdc_02.account C
on A.accountId=C.Id
join ss_sfdc_02.user D
on A.Customer_Success__c=D.Id
where A.stageName in ('Closed Lost','Closed Won') and A.closeDate >= '2017-02-01' and A.Customer_Success__c is not null and A.Customer_Success__c!='';

alter table rpt_workspace.js_csDashboardCWCL
add salesRep varchar(50);

update rpt_workspace.js_csDashboardCWCL A
join ss_sfdc_02.opportunity B
on A.opportunityID=B.Id
join ss_sfdc_02.user C
on B.ownerId=C.Id
set A.salesRep=concat(C.FirstName,' ',C.LastName);

alter table rpt_workspace.js_csDashboardCWCL
add closeDate date;

update rpt_workspace.js_csDashboardCWCL A
join ss_sfdc_02.opportunity B
on A.opportunityID=B.Id 
set A.closeDate=B.CloseDate;

alter table rpt_workspace.js_csDashboardCWCL
add territory varchar(50),
add segment varchar(50);

update rpt_workspace.js_csDashboardCWCL A
join ss_sfdc_02.account B
on A.accountID=B.ID
set A.territory=B.Territory__c;

update rpt_workspace.js_csDashboardCWCL
set segment=
case when territory like 'Mid-Market%' then 'Mid-Market' 
when territory like 'SMB%' then 'SMB' 
when territory like 'Major%' then 'Major'
when territory like 'Vertical Market: Retail%' then 'Retail'
when territory like 'Vertical Market: EDU%' then 'EDU'
when territory like 'Vertical Market: Healthcare%' then 'Healthcare'
when territory like 'Vertical Market: Gov%' then 'Gov'
when (territory like 'Unassigned%' or territory='Not Enough Information (ISR3)' or territory='') then 'No Territory'
else 'Strategic'
end
where territory is not null;

select * from rpt_workspace.js_csDashboardCWCL;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("tableau-schmale-csDashboard12V2.sql");

