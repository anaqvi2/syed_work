select "******************************************************************************************************************************", NOW();
select "******** Throwaway Part 5: Misc - start ******** ", NOW();

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CALL rpt_main_02.SMARTSHEET_START_LOG ("Throwaway Part 5: Misc");
SET @@sql_mode = '';

CALL rpt_main_02.SMARTSHEET_START_LOG ("Max record IDs");

SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenID" INTO @NewMaxaccessTokenID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxaccessTokenSessionID" INTO @NewMaxaccessTokenSessionID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxbrandID" INTO @NewMaxbrandID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDInsert" INTO @NewMaxContainerIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxContainerIDModify" INTO @NewMaxContainerIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxgoogleAppsDomainID"  INTO @NewMaxgoogleAppsDomainID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxHPPmodifyDateTime"  INTO @NewMaxHPPmodifyDateTime;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxmailDistributionID"  INTO @NewMaxmailDistributionID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxopedIDIdentifierID"  INTO @NewMaxopedIDIdentifierID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationID"  INTO @NewMaxorganizationID;
SELECT maximumValue 	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorganizationUserRoleID"  INTO @NewMaxorganizationUserRoleID;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NEWmaxPaymentProfileID" 	 INTO @NEWmaxPaymentProfileID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxreminderID"  INTO @NewMaxreminderID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxRequestLogID" INTO @NewMaxRequestLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsessionLogID" INTO @NewMaxsessionLogID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDInsert" INTO @NewMaxsheetLinkIDInsert;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsheetLinkIDModify" INTO @NewMaxsheetLinkIDModify;
SELECT maximumValue 		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestID" 	 INTO @NewMaxsignupRequestID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsignupRequestTrackingItemID"  INTO @NewMaxsignupRequestTrackingItemID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxsiteSettingElementValueID"  INTO @NewMaxsiteSettingElementValueID;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDInsert"  INTO @NewMaxTemplateIDInsert;
SELECT maximumValue  	FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxTemplateIDModify" INTO @NewMaxTemplateIDModify;
SELECT maximumValue  		FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserID"  INTO @NewMaxuserID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxworkspaceID"  INTO @NewMaxworkspaceID;
SELECT maximumValue FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxuserDataID" INTO @NewMaxuserDataID;
SELECT maximumValue  FROM rpt_main_02.arc_maxRecordIDs where variableName = "NewMaxorgUserModifyDate" INTO @NewMaxorgUserModifyDate;

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Max record IDs");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.hist_userAccount insert");

UPDATE rpt_main_02.userAccount A
SET 	A.emailAddress = "user@netsuite.com"
WHERE A.domain = 'netsuite.com';


-- DROP TABLE IF EXISTS rpt_main_02.hist_userAccount;
CREATE TABLE IF NOT EXISTS rpt_main_02.hist_userAccount LIKE ss_core_02.hist_userAccount;


SELECT MAX(modifyDateTime) INTO @maxModifyDate FROM rpt_main_02.hist_userAccount;

INSERT rpt_main_02.hist_userAccount (
	userID, 
	firstName, 
	lastName, 
	nickName, 
	accountType, 
	emailAddress, 
	loginPassword, 
	locale, 
	timeZone, 
	newsFlags, 
	statusFlags, 
	insertByUserID, 
	insertDateTime, 
	modifyByUserID, 
	modifyDateTime, 
	sessionLogID,
	profileImage,
	domain,
	hist_effectiveThruDateTime)
SELECT
	ua.userID, 
	ua.firstName,
	ua.lastName, 
	ua.nickName, 
	ua.accountType, 
	ua.emailAddress, 
	ua.loginPassword, 
	ua.locale, 
	ua.timeZone, 
	ua.newsFlags, 
	ua.statusFlags, 
	ua.insertByUserID, 
	ua.insertDateTime, 
	ua.modifyByUserID, 
	ua.modifyDateTime, 
	ua.sessionLogID,
	ua.profileImage,
    SUBSTR(ua.emailAddress, INSTR(ua.emailAddress,'@') + 1),
    ua.hist_effectiveThruDateTime
FROM ss_core_02.hist_userAccount ua 
LEFT JOIN rpt_main_02.hist_userAccount hua ON
	ua.userID=hua.userID AND	
	ua.modifyDateTime=hua.modifyDateTime
WHERE hua.userID IS NULL
AND ua.modifyDateTime >= @maxModifyDate
AND DAYOFWEEK(NOW()) = 2
;

UPDATE rpt_main_02.hist_userAccount A
SET 	A.emailAddress = "user@netsuite.com"
WHERE A.domain = 'netsuite.com'
AND DAYOFWEEK(NOW()) = 2;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.hist_userAccount insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.hist_userAccount update");


-- Create staging table to identify previously exisiting records that need to be updated
DROP TABLE IF EXISTS rpt_main_02.stg_histuserAccount_update;

CREATE TABLE IF NOT EXISTS rpt_main_02.stg_histuserAccount_update 
(
	userID BIGINT,
	modifyDateTime DATETIME,
	hist_effectiveThruDateTime DATETIME
)
;

INSERT INTO rpt_main_02.stg_histuserAccount_update
SELECT userID, modifyDateTime, hist_effectiveThruDateTime
FROM ss_core_02.hist_userAccount
WHERE modifyDateTime >= @maxModifyDate
AND DAYOFWEEK(NOW()) = 2
;

CREATE INDEX ix_userID ON rpt_main_02.stg_histuserAccount_update (userID);
CREATE INDEX ix_modifyDateTime ON rpt_main_02.stg_histuserAccount_update (modifyDateTime);

-- Update hist_effectiveThruDateTime of previous paymentProfileIDs
UPDATE rpt_main_02.hist_userAccount hpp FORCE INDEX (hist_userAccount_idxPK)
JOIN ss_core_02.hist_userAccount coreHPP FORCE INDEX (hist_userAccount_idxPK) ON hpp.userID = coreHPP.userID
	AND hpp.modifyDateTime = coreHPP.modifyDateTime
	AND hpp.modifyDateTime != hpp.hist_effectiveThruDateTime  /*Only join on records with a change*/
	AND coreHPP.modifyDateTime != coreHPP.hist_effectiveThruDateTime /*To ensure only 1 record selected from coreDB*/
JOIN rpt_main_02.stg_histuserAccount_update stg ON coreHPP.userID = stg.userID 
	AND stg.modifyDateTime = coreHPP.hist_effectiveThruDateTime
	AND stg.modifyDateTime != stg.hist_effectiveThruDateTime /*Do not update with new hist_effectiveThruDateTime in case of Negative 1 second effective time*/
SET hpp.hist_effectiveThruDateTime = coreHPP.hist_effectiveThruDateTime
WHERE hpp.modifyDateTime != hpp.hist_effectiveThruDateTime /*Do not update if hist_effectiveThruDateTime is the same as modifyDateTime*/
AND DAYOFWEEK(NOW()) = 2;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.hist_userAccount update");

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_requestLogRESTSessions");

SELECT MAX(requestLogID) FROM rpt_main_02.arc_requestLogRESTSessions INTO @maxRequestLogID;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_requestLogRESTSessions
SELECT * 
FROM rpt_main_02.arc_requestLog
WHERE sessionType = 9 
AND requestLogID > @maxRequestLogID
;
COMMIT;
SET AUTOCOMMIT = 1;

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_requestLogRESTSessions");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_domainTrials");

DROP TABLE IF EXISTS rpt_main_02.rpt_domainTrials;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_domainTrials
(domain VARCHAR(200),
trials INT,
PRIMARY KEY (domain));

INSERT INTO rpt_main_02.rpt_domainTrials (domain, trials)

SELECT mainContactDomain, COUNT(DISTINCT(mainContactUserID))
FROM rpt_main_02.rpt_paymentProfile pp
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = pp.mainContactDomain
WHERE pp.productName = 'Trial'
AND isp.domain IS NULL
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_domainTrials");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.template insert");

/*Find latest record in table*/
SELECT MAX(insertDateTime) INTO @maxInsertDateTime FROM rpt_main_02.template;
SELECT MAX(modifyDateTime) INTO @maxModifyDateTime FROM rpt_main_02.template;

INSERT rpt_main_02.template
SELECT 
	ss_core_02.template.templateID,
	ss_core_02.template.containerID,
	ss_core_02.template.isPublic,
	ss_core_02.template.contributor,
	ss_core_02.template.priority,
	ss_core_02.template.previewImage,
	ss_core_02.template.previewImageLarge,
	ss_core_02.template.detailedIFrame,
	ss_core_02.template.containerType,
	NULL,
	ss_core_02.template.usageCount,
	ss_core_02.template.locale,
	ss_core_02.template.tags,
	ss_core_02.template.deleteStatus,
	ss_core_02.template.insertDateTime,
	ss_core_02.template.insertByUserID,
	ss_core_02.template.modifyDateTime,
	ss_core_02.template.modifyByUserID,
	ss_core_02.template.sessionLogID,
	ss_core_02.template.dataTimestamp
FROM ss_core_02.template
LEFT OUTER JOIN rpt_main_02.template t2 ON ss_core_02.template.templateID=t2.templateID
WHERE t2.templateID IS NULL
AND ss_core_02.template.insertDateTime >= @maxInsertDateTime 
AND ss_core_02.template.templateID <= @NewMaxTemplateIDInsert  /*Using daily time bound value from top*/
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.template insert");

 
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.template update");

-- Update Any Modified Records since last load
UPDATE rpt_main_02.template
JOIN (SELECT * FROM ss_core_02.template WHERE modifyDateTime >= @maxModifyDateTime AND templateID <= @NewMaxTemplateIDModify /*Using daily time bound value from top*/ FOR UPDATE) ss 
	ON rpt_main_02.template.templateID=ss.templateID
SET
	rpt_main_02.template.templateID = ss.templateID,
	rpt_main_02.template.containerID = ss.containerID,
	rpt_main_02.template.isPublic = ss.isPublic,
	rpt_main_02.template.contributor = ss.contributor,
	rpt_main_02.template.priority = ss.priority,
	rpt_main_02.template.previewImage = ss.previewImage,
	rpt_main_02.template.previewImageLarge = ss.previewImageLarge,
#	rpt_main_02.template.isSmartsheetTemplate = ss.isSmartsheetTemplate,
	rpt_main_02.template.usageCount = ss.usageCount,
	rpt_main_02.template.locale = ss.locale,
	rpt_main_02.template.deleteStatus = ss.deleteStatus,
	rpt_main_02.template.insertDateTime = ss.insertDateTime,
	rpt_main_02.template.insertByUserID = ss.insertByUserID,
	rpt_main_02.template.modifyDateTime = ss.modifyDateTime,
	rpt_main_02.template.modifyByUserID = ss.modifyByUserID,
	rpt_main_02.template.sessionLogID = ss.sessionLogID,
	rpt_main_02.template.dataTimestamp = ss.dataTimestamp
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.template update");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.brand workspace");

DROP TABLE IF EXISTS rpt_main_02.workspace;
CREATE TABLE IF NOT EXISTS rpt_main_02.workspace LIKE ss_core_02.workspace;

INSERT INTO rpt_main_02.workspace
SELECT *
FROM ss_core_02.workspace
;

CREATE INDEX idx_insertUserID ON rpt_main_02.workspace (insertByUserID);

DROP TABLE IF EXISTS rpt_main_02.brand;
CREATE TABLE IF NOT EXISTS rpt_main_02.brand LIKE ss_core_02.brand;

INSERT INTO rpt_main_02.brand
SELECT *
FROM ss_core_02.brand
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.brand workspace");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_userSessionActivity");


/* output value for debugging */
SELECT COUNT(*), MAX(userID), MAX(lastSessionID), SUM(sessionCount) FROM rpt_main_02.arc_userSessionActivity;

/* find starting point for new users */
SELECT MAX(userID) INTO @maxUserID FROM rpt_main_02.arc_userSessionActivity;

/* for startup case, if null convert to 0 */
SELECT IF (@maxUserID IS NULL, 0, @maxUserID) INTO @maxUserID;

/* output value for debugging */
SELECT "@maxUserID=", @maxUserID;

/* output value for debugging */
SELECT COUNT(*), MAX(userID) FROM rpt_main_02.arc_userSessionActivity;


/* add the new users - default count to zero so we can add to it */
INSERT rpt_main_02.arc_userSessionActivity(userID, sessionCount)
SELECT u.userID, 0 
FROM rpt_main_02.userAccount u
WHERE u.userID > @maxUserID
;
	
/* output value for debugging */
SELECT COUNT(*), MAX(userID) FROM rpt_main_02.arc_userSessionActivity;

/**************************************/	
/* find starting point for new session */
SELECT MAX(lastSessionID) INTO @maxSessionID FROM rpt_main_02.arc_userSessionActivity;

/* for startup case, if null convert to 0 */
SELECT IF (@maxSessionID IS NULL, 0, @maxSessionID) INTO @maxSessionID;

/* output value for debugging */
SELECT  "@maxSessionID=", @maxSessionID;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_userSessionActivity");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_newSessionLogRollupByUser insert");


/* create table to hold new session rollup data */
DROP TABLE IF EXISTS rpt_main_02.rpt_newSessionLogRollupByUser;
CREATE TABLE rpt_main_02.rpt_newSessionLogRollupByUser (
	userID 				INT, 
	firstSessionID 		INT, 
	firstSessionDateTime DATETIME, 
	lastSessionID 		INT, 
	lastSessionDateTime DATETIME, 
	sessionCount 		INT, 
	PRIMARY KEY(userID))
;
	
	
/* select the new sessions into a table for processing */
INSERT rpt_main_02.rpt_newSessionLogRollupByUser(
	userID, 
	firstSessionID, 
	firstSessionDateTime, 
	lastSessionId, 
	lastSessionDateTime, 
	sessionCount)
SELECT 
	sl.userID, 
	MIN(sl.sessionLogID), 
	MIN(sl.insertDateTime), 
	MAX(sl.sessionLogID), 
	MAX(sl.insertDateTime), 
	COUNT(sl.sessionLogID)
FROM ss_core_02.sessionLog sl
WHERE sl.sessionLogID > @maxSessionID AND sl.sessionLogID <= @NewMaxsessionLogID AND sl.loginAuthResult = 1
GROUP BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_newSessionLogRollupByUser insert");


/* output value for debugging */
SELECT "Rollup batch: ", COUNT(*), MIN(userID), MAX(userID), MIN(firstSessionID), MIN(firstSessionDateTime), MAX(lastSessionID), 
MAX(lastSessionDateTime), SUM(sessionCount) 
FROM rpt_main_02.rpt_newSessionLogRollupByUser;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_newSessionLogRollupByUser update");


/* set the intial values only if null */
UPDATE rpt_main_02.arc_userSessionActivity usa
JOIN rpt_main_02.rpt_newSessionLogRollupByUser nsru ON nsru.userID = usa.userID
SET usa.firstSessionID = nsru.firstSessionID, usa.firstSessionDateTime = nsru.firstSessionDateTime
WHERE usa.firstSessionID IS NULL
;

/* update the last values and running count*/
UPDATE rpt_main_02.arc_userSessionActivity usa
JOIN rpt_main_02.rpt_newSessionLogRollupByUser nsru ON nsru.userID = usa.userID
SET 
	usa.lastSessionID 		= nsru.lastSessionID, 
	usa.lastSessionDateTime = nsru.lastSessionDateTime,	
	usa.sessionCount 		= nsru.sessionCount  + usa.sessionCount;

/* output value for debugging */
SELECT COUNT(*), MAX(userID), MAX(lastSessionID), SUM(sessionCount) FROM rpt_main_02.arc_userSessionActivity
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_newSessionLogRollupByUser update");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_mailDistribution");


/*CREATE TABLE IF NOT EXISTS rpt_main_02.arc_mailDistribution LIKE ss_core_02.mailDistribution;*/
SELECT MAX(mailDistributionID) FROM rpt_main_02.arc_mailDistribution INTO @mailDistributionID;
SELECT IF (@mailDistributionID  IS NULL, 0, @mailDistributionID) INTO @mailDistributionID;

INSERT rpt_main_02.arc_mailDistribution
SELECT * 
FROM ss_core_02.mailDistribution
WHERE mailDistributionID > @mailDistributionID AND mailDistributionID <= @NewMaxmailDistributionID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_mailDistribution");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_organizationUser insert");


DROP TABLE IF EXISTS rpt_main_02.rpt_organizationUser;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_organizationUser(
	userID BIGINT,  
	paymentAdminCount SMALLINT,  
	userAdminCount SMALLINT,  
	dataAdminCount SMALLINT,  
	licenseUserCount SMALLINT,  
	memberCount SMALLINT, 
	resourceManagerCount SMALLINT,
	PRIMARY KEY(userID))
;

/******* Insert all userIds from organizationUserRole - start *******/
INSERT rpt_main_02.rpt_organizationUser (userID)
	SELECT userID
	FROM ss_core_02.organizationUserRole
	WHERE state = 1 AND organizationUserRoleID <= @NewMaxorganizationUserRoleID
	GROUP BY 1
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_organizationUser insert");


/******* Update paymentAdminCount  on each record *******/
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_organizationUser update");


UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.paymentAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'PAYMENT_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;

/******* Update userAdminCount  on each record *******/
UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.userAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'USER_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;
	
/******* Update dataAdminCount  on each record *******/
UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.dataAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'DATA_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;
	
/******* Update licenseUserCount  on each record *******/
UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.licenseUserCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'LICENSE_USER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;
	
/******* Update memberCount  on each record *******/
UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.memberCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'MEMBER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;

/******* Update memberCount  on each record *******/
UPDATE rpt_main_02.rpt_organizationUser rou
SET rou.resourceManagerCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'RESOURCE_MANAGER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= @NewMaxorganizationUserRoleID)
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_organizationUser update");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.openIDIdentifier insert");



CREATE TABLE IF NOT EXISTS rpt_main_02.openIDIdentifier
(
	openIDIdentifierID BIGINT,
	identity VARCHAR(200),
	userID BIGINT,
	provider VARCHAR(100),
	emailAddress VARCHAR(100),
	insertDateTime DATETIME,
	insertByUserID BIGINT,
	modifyDateTime DATETIME,
	modifyByUserID BIGINT,
	sessionLogID BIGINT,
	dataTimestamp INT,
	PRIMARY KEY (openIDIdentifierID),
	UNIQUE KEY OpenIdentifier_idx1 (identity,provider)
)
;


SELECT MAX(openIDIdentifierID) FROM rpt_main_02.openIDIdentifier INTO @maxopenIDIdentifierID;
SELECT MAX(modifyDateTime) FROM rpt_main_02.openIDIdentifier INTO @maxModifyDateTime;

INSERT INTO rpt_main_02.openIDIdentifier
SELECT 
	oid.openIDIdentifierID,
	oid.identity,
	oid.userID,
	oid.provider,
	oid.emailAddress,
	oid.insertDateTime,
	oid.insertByUserID,
	oid.modifyDateTime,
	oid.modifyByUserID,
	oid.sessionLogID,
	oid.dataTimestamp
FROM ss_core_02.openIDIdentifier oid
LEFT OUTER JOIN rpt_main_02.openIDIdentifier ins ON oid.openIDIdentifierID=ins.openIDIdentifierID
WHERE ins.openIDIdentifierID IS NULL
AND oid.openIDIdentifierID >= @maxopenIDIdentifierID AND oid.openIDIdentifierID <= @NewMaxopedIDIdentifierID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.openIDIdentifier insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.openIDIdentifier update");


UPDATE rpt_main_02.openIDIdentifier 
JOIN ss_core_02.openIDIdentifier ON rpt_main_02.openIDIdentifier.openIDIdentifierID=ss_core_02.openIDIdentifier.openIDIdentifierID
SET
	rpt_main_02.openIDIdentifier.openIDIdentifierID=ss_core_02.openIDIdentifier.openIDIdentifierID,
	rpt_main_02.openIDIdentifier.identity=ss_core_02.openIDIdentifier.identity,
	rpt_main_02.openIDIdentifier.userID=ss_core_02.openIDIdentifier.userID,
	rpt_main_02.openIDIdentifier.provider=ss_core_02.openIDIdentifier.provider,
	rpt_main_02.openIDIdentifier.emailAddress=ss_core_02.openIDIdentifier.emailAddress,
	rpt_main_02.openIDIdentifier.insertDateTime=ss_core_02.openIDIdentifier.insertDateTime,
	rpt_main_02.openIDIdentifier.insertByUserID=ss_core_02.openIDIdentifier.insertByUserID,
	rpt_main_02.openIDIdentifier.modifyDateTime=ss_core_02.openIDIdentifier.modifyDateTime,
	rpt_main_02.openIDIdentifier.modifyByUserID=ss_core_02.openIDIdentifier.modifyByUserID,
	rpt_main_02.openIDIdentifier.sessionLogID=ss_core_02.openIDIdentifier.sessionLogID,
	rpt_main_02.openIDIdentifier.dataTimestamp=ss_core_02.openIDIdentifier.dataTimestamp
WHERE ss_core_02.openIDIdentifier.modifyDateTime >= @maxModifyDateTime AND ss_core_02.openIDIdentifier.openIDIdentifierID <= @NewMaxopedIDIdentifierID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.openIDIdentifier update");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_remarketingSource insert");

-- DROP TABLE IF EXISTS rpt_main_02.rpt_remarketingSource;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_remarketingSource
(
userID BIGINT,
signupRequestID BIGINT,
insertDateTime DATETIME,
signupMonth VARCHAR(20),
signupWeek VARCHAR(20),
signupDay VARCHAR(20),
remarketingSource VARCHAR(100),
adVersion VARCHAR(20),
remarketingCampaign VARCHAR(100),
remarketingSegment VARCHAR(100),
KEY ix_userID (userID),
PRIMARY KEY (signupRequestID)
)
;


SET AUTOCOMMIT = 0;
INSERT INTO rpt_main_02.rpt_remarketingSource
SELECT 
r.userID,
r.signupRequestID, 
r.InsertDateTime,
DATE_FORMAT(r.insertDateTime, '%Y*%m(%b)') AS signupMonth, 
rpt_main_02.SMARTSHEET_WEEK(r.insertDateTime) AS signupWeek, 
DATE_FORMAT(r.insertDateTime, '%Y*%m*%d') AS signupDay, 
CASE source.itemValue 
	WHEN 1 THEN 'Adroll Remarketing'
	WHEN 2 THEN 'Adroll Facebook Remarketing'
	WHEN 3 THEN 'Remarketing List for Search Ads'
	WHEN 4 THEN 'Remarketing List for Search Ads International'
	WHEN 5 THEN 'Google Remarketing'
	WHEN 6 THEN 'Google Remarketing International'
	WHEN 7 THEN 'DoubleClick Remarketing'
	WHEN 8 THEN 'Facebook Remarketing'
	WHEN 9 THEN 'Gmail Remarketing'
ELSE NULL END AS RemarketingSource,

ad.itemValue AS adVersion,
-- campaign.itemValue AS RemarketingCampaign,

CONCAT(campaign.itemValue, " - ", IF(campaignLookup.campaignDescription IS NULL, "not found", campaignLookup.campaignDescription)) AS RemarketingCampaign, 
CONCAT(segment.itemValue, " - ", IF(segmentLookup.segmentDescription IS NULL, "not found", segmentLookup.segmentDescription)) AS RemarketingSegment
FROM ss_account_02.signupRequest r
JOIN (SELECT DISTINCT signupRequestID FROM rpt_main_02.rpt_signupRequestTrackingItem WHERE itemName LIKE 'rem%') rem ON r.signupRequestID=rem.signupRequestID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem source ON r.signupRequestID=source.signupRequestID AND source.itemName = 'rems'
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem ad ON r.signupRequestID=ad.signupRequestID AND ad.itemName = 'rema'
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem campaign ON r.signupRequestID=campaign.signupRequestID AND campaign.itemName = 'remc'
LEFT OUTER JOIN rpt_main_02.ref_campaignLookup campaignLookup ON campaign.itemValue=campaignLookup.campaignID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem segment ON r.signupRequestID=segment.signupRequestID AND segment.itemName = 'remm'
LEFT OUTER JOIN rpt_main_02.ref_campaignSegmentLookup segmentLookup ON segment.itemValue=segmentLookup.segmentID
LEFT OUTER JOIN rpt_main_02.rpt_remarketingSource  ins ON r.signupRequestID =ins.signupRequestID
-- WHERE source.itemValue IS NULL
WHERE r.resultStatus = 1
AND ins.signupRequestID IS NULL
ORDER BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_remarketingSource insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.accountChangeTicket insert");

CREATE TABLE IF NOT EXISTS rpt_main_02.accountChangeTicket
LIKE ss_core_02.accountChangeTicket
;

SELECT MAX(ticketID) FROM rpt_main_02.accountChangeTicket INTO @maxTicketID;

INSERT INTO rpt_main_02.accountChangeTicket
(
	ticketID,
	ticketType,
	ticketKey,
	ticket,
	ticketStatus,
	insertDateTime,
	insertByUserID,
	modifyDateTime,
	modifyByUserID,
	sessionLogID,
	dataTimestamp
)
SELECT 
	act.ticketID,
	act.ticketType,
	act.ticketKey,
	act.ticket,
	act.ticketStatus,
	act.insertDateTime,
	act.insertByUserID,
	act.modifyDateTime,
	act.modifyByUserID,
	act.sessionLogID,
	act.dataTimestamp
FROM ss_core_02.accountChangeTicket act
LEFT OUTER JOIN rpt_main_02.accountChangeTicket ins ON ins.ticketID=act.ticketID
WHERE ins.ticketID IS NULL
AND act.ticketID > @maxTicketID
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.accountChangeTicket insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.dashboardAccessMap");


SELECT MAX(insertDateTime) FROM rpt_main_02.dashboardAccessMap INTO @maxInsTimeDash;

REPLACE INTO rpt_main_02.dashboardAccessMap
SELECT dam.*,0
FROM ss_core_02.dashboardAccessMap dam
WHERE dam.insertDateTime >= @maxInsTimeDash;

DROP TABLE IF EXISTS rpt_main_02.stg_dashboardAccessMapDeletes;
CREATE TEMPORARY TABLE IF NOT EXISTS rpt_main_02.stg_dashboardAccessMapDeletes 
(dashboardID BIGINT, 
userID BIGINT, 
PRIMARY KEY (dashboardID, userID), 
KEY userID (userID));


INSERT INTO rpt_main_02.stg_dashboardAccessMapDeletes
SELECT mda.dashboardID, mda.userID
FROM rpt_main_02.dashboardAccessMap mda
LEFT OUTER JOIN ss_core_02.dashboardAccessMap cda ON cda.dashboardID = mda.dashboardID AND cda.userID = mda.userID
WHERE cda.dashboardID IS NULL
AND mda.deleteStatus = 0;

UPDATE rpt_main_02.dashboardAccessMap dam
JOIN rpt_main_02.stg_dashboardAccessMapDeletes del ON del.dashboardID = dam.dashboardID AND del.userID = dam.userID
SET dam.deleteStatus = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.dashboardAccessMap");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.siteSettingElementValue");


-- DROP TABLE IF EXISTS rpt_main_02.siteSettingElementValue;

SELECT MAX(modifyDateTime) FROM rpt_main_02.siteSettingElementValue 
	WHERE modifyDateTime < DATE_ADD(CURRENT_DATE(),INTERVAL +1 DAY) INTO @maxModifyDateTime;  /*Add qualifier in case there is a future modify date in the table*/

CREATE TABLE IF NOT EXISTS rpt_main_02.temp_siteSettingElementValue
SELECT *
FROM ss_account_02.siteSettingElementValue
WHERE modifyDateTime > @maxModifyDateTime
;

REPLACE INTO rpt_main_02.siteSettingElementValue 
SELECT 
	ssev.siteSettingElementValueID,
	ssev.siteSettingElementName,
	ssev.valueString,
	ssev.valueNumeric,
	ssev.valueBoolean,
	ssev.valueDateTime,
	ssev.userID,
	ssev.shipToUI,
	ssev.insertDateTime,
	ssev.insertByUserID,
	ssev.modifyDateTime,
	ssev.modifyByUserID,
	ssev.sessionLogID,
	ssev.dataTimestamp
FROM rpt_main_02.temp_siteSettingElementValue ssev
WHERE ssev.modifyDateTime > @maxModifyDateTime
;

DROP TABLE rpt_main_02.temp_siteSettingElementValue;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.siteSettingElementValue");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_cancelComment insert");

DROP TABLE IF EXISTS rpt_main_02.rpt_cancelComment;
CREATE TABLE rpt_main_02.rpt_cancelComment (
	userID				BIGINT, 
	cancelComment  		NVARCHAR(4000),
	cancelCommentDate 	DATETIME,
	paymentProfileID 	BIGINT,
	parentPaymentProfileID BIGINT,
	PRIMARY KEY(userID),
	INDEX (cancelCommentDate),
	INDEX (paymentProfileID),
	INDEX (parentPaymentProfileID));

/* Update cancel reason for folks that we have cancel comments for */
SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_cancelComment (userID, cancelComment, cancelCommentDate)
SELECT userID, valueString, modifyDateTime 
FROM rpt_main_02.siteSettingElementValue ss
WHERE ss.siteSettingElementName = 'CancelComments'
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_cancelComment insert");

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_cancelComment update");

SET AUTOCOMMIT = 0;
UPDATE rpt_main_02.rpt_cancelComment rc 
  JOIN rpt_main_02.rpt_paymentProfile pp ON rc.userID = pp.mainContactUserID AND pp.accountType != 3
SET rc.paymentProfileID = pp.paymentProfileID;
COMMIT;

/* Roll up cancel comments from a user's payment profile to their parent profile if they ever had one */
UPDATE rpt_main_02.rpt_cancelComment rc 
  JOIN rpt_main_02.hist_paymentProfile hp ON rc.paymentProfileID = hp.paymentProfileID 
  JOIN rpt_main_02.rpt_paymentProfile pp on hp.parentPaymentProfileID = pp.paymentProfileID
SET rc.parentPaymentProfileID = pp.paymentProfileID;
COMMIT;

/* Update the payment profile with their cancel comments */
UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.rpt_cancelComment rc ON rp.paymentProfileID = rc.paymentProfileID
SET rp.cancelPaymentComment = QUOTE(rc.cancelComment);  
COMMIT;

/* Update the PARENT payment profile with their cancel comments */
UPDATE rpt_main_02.rpt_paymentProfile rp
  JOIN rpt_main_02.rpt_cancelComment rc ON rp.paymentProfileID = rc.parentPaymentProfileID
SET rp.cancelPaymentComment = rc.cancelComment;  
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_cancelComment update");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_integrationRollupByUser");


DROP TABLE IF EXISTS rpt_main_02.rpt_integrationRollupByUser;
CREATE TABLE IF NOT EXISTS 
rpt_main_02.rpt_integrationRollupByUser(
	userID BIGINT, 
	googleOpenID INT, 
	googleFlag TINYINT,
	googleAppsOpenID INT, 
	googleAppsFlag TINYINT,
	salesforceOpenID INT, 
	salesforceSignup INT, 
	salesforceFlag TINYINT,
	zimbraSignup INT,
	zimbraFlag TINYINT,
	PRIMARY KEY(userID));

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_integrationRollupByUser(userID, googleFlag, googleAppsFlag, salesforceFlag, zimbraFlag)
SELECT u.userID,0,0,0,0 
FROM rpt_main_02.userAccount u
;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser r 
  JOIN rpt_main_02.openIDIdentifier o ON o.userID = r.userID AND o.provider = 'Google'
SET googleOpenID = 1;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser r 
  JOIN rpt_main_02.openIDIdentifier o ON o.userID = r.userID AND o.provider = 'GoogleApps'
SET googleAppsOpenID = 1;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser r 
  JOIN rpt_main_02.openIDIdentifier o ON o.userID = r.userID AND o.provider = 'Salesforce'
SET salesforceOpenID = 1;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser r 
  JOIN rpt_main_02.rpt_signupSource s ON s.userID = r.userID AND s.source = 28
SET salesforceSignup = 1;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser r 
  JOIN rpt_main_02.rpt_signupSource s ON s.userID = r.userID AND s.source = 24
SET zimbraFlag = 1;
COMMIT;

UPDATE rpt_main_02.rpt_integrationRollupByUser SET googleFlag = 1 WHERE googleOpenID > 0;
COMMIT;
UPDATE rpt_main_02.rpt_integrationRollupByUser SET googleAppsFlag = 1 WHERE googleAppsOpenID > 0;
COMMIT;
UPDATE rpt_main_02.rpt_integrationRollupByUser SET salesforceFlag = 1 WHERE salesforceOpenID > 0 OR salesforceSignup > 0;
COMMIT;
UPDATE rpt_main_02.rpt_integrationRollupByUser SET zimbraFlag = 1 WHERE zimbraSignup > 0;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_integrationRollupByUser");




/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_clientEventTemplateGallerySearch");


SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventTemplateGallerySearch INTO @maxClientEventID;


SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_clientEventTemplateGallerySearch
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID IN (552, 562)
AND actionID = 32 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_clientEventTemplateGallerySearch");

/*Start rpt_main_02.arc_clientEventSiteSearchTerms*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_clientEventSiteSearchTerms");


SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventSiteSearchTerms INTO @maxClientEventID;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_clientEventSiteSearchTerms 
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID = 7050 
AND actionID = 16 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_clientEventSiteSearchTerms");


/*Start rpt_main_02.arc_clientEventTemplateGalleryCategories*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_clientEventTemplateGalleryCategories");

SELECT MAX(clientEventID) FROM rpt_main_02.arc_clientEventTemplateGalleryCategories INTO @maxClientEventID;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.arc_clientEventTemplateGalleryCategories
SELECT * 
FROM rpt_main_02.arc_clientEvent
WHERE objectID IN (551,563) 
AND actionID = 22 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_clientEventTemplateGalleryCategories");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_userSessionActivityPT");


/* convert times to Pacific time zone using rough approximation  +8 hours */
DROP TABLE IF EXISTS rpt_main_02.rpt_userSessionActivityPT;
 
CREATE TABLE IF NOT EXISTS 
rpt_main_02.rpt_userSessionActivityPT(
	userID 			INT, 
	firstSessionID 		INT, 
	firstSessionDateTime 	DATETIME, 
	lastSessionID 		INT, 
	lastSessionDateTime 	DATETIME, 
	sessionCount 		INT, 
	PRIMARY KEY(userID));
	
SET AUTOCOMMIT = 0;	
INSERT rpt_main_02.rpt_userSessionActivityPT(
	userID , 
	firstSessionID, 
	firstSessionDateTime, 
	lastSessionID, 
	lastSessionDateTime, 
	sessionCount)
SELECT 
	usa.userID, 
	usa.firstSessionID, 
	CONVERT_TZ(usa.firstSessionDateTime,'+00:00','+8:00'), 
	usa.lastSessionID, 
	CONVERT_TZ(usa.lastSessionDateTime,'+00:00','+8:00'), 
	usa.sessionCount
FROM rpt_main_02.arc_userSessionActivity usa
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_userSessionActivityPT");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_loginCountWeekly");

DROP TABLE IF EXISTS rpt_main_02.rpt_loginCountWeekly;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_loginCountWeekly(
	userID BIGINT, 
	loginCount INT, 
	yearWeekNumb INT)
;

SET AUTOCOMMIT = 0;	
INSERT rpt_main_02.rpt_loginCountWeekly(
	userID, 
	yearWeekNumb, 
	loginCount)
SELECT 
	s.userID, 
	YEARWEEK(s.insertDateTime), 
	COUNT(*)
FROM rpt_main_02.rpt_sessionLog s
WHERE s.loginAuthResult = 1
GROUP BY 1,2
;
COMMIT;
SET AUTOCOMMIT = 1;

CREATE INDEX idx_loginCountWeeklyUserID ON rpt_main_02.rpt_loginCountWeekly (userID);

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_loginCountWeekly");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_integrationRollupByPaymentProfile");


/* Now rollup by payment profile so we can tell which Paid Customers use these features */
DROP TABLE IF EXISTS rpt_main_02.rpt_integrationRollupByPaymentProfile;
CREATE TABLE IF NOT EXISTS 
rpt_main_02.rpt_integrationRollupByPaymentProfile(
	paymentProfileID BIGINT, 
	googleFlag TINYINT,
	googleAppsFlag TINYINT,
	salesforceFlag TINYINT,
	zimbraFlag TINYINT,
	PRIMARY KEY(paymentProfileID));

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_integrationRollupByPaymentProfile
SELECT p.paymentProfileID, u.googleFlag, u.googleAppsFlag, u.salesforceFlag, u.zimbraFlag
FROM rpt_main_02.rpt_paymentProfile p 
JOIN rpt_main_02.rpt_integrationRollupByUser u ON p.ownerID = u.userID
WHERE p.accountType IN (1,2)
AND (u.googleFlag = 1 OR u.googleAppsFlag = 1 OR u.salesforceFlag = 1 OR u.zimbraFlag = 1)
;
COMMIT;

INSERT rpt_main_02.rpt_integrationRollupByPaymentProfile
SELECT p1.paymentProfileID, MAX(u.googleFlag), MAX(u.googleAppsFlag), MAX(u.salesforceFlag), MAX(u.zimbraFlag)
FROM rpt_main_02.rpt_paymentProfile p1 
  JOIN rpt_main_02.rpt_paymentProfile p2 ON p1.paymentProfileID = p2.parentPaymentProfileID 
  JOIN rpt_main_02.rpt_integrationRollupByUser u ON p2.ownerID = u.userID
WHERE p1.accountType IN (3)
  AND p2.accountTYPE IN (1,2)
  AND (u.googleFlag = 1 OR u.googleAppsFlag = 1 OR u.salesforceFlag = 1 OR u.zimbraFlag = 1)
GROUP BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_integrationRollupByPaymentProfile");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_clientLogCountsByPaymentProfile");


/* Sum the action counts by paymentProfile - this will rollup paymentProfiles to their parent too as the rpt_paymentProfileMaster table includes dup rows for profiles with parents  */
DROP TABLE IF EXISTS rpt_main_02.rpt_clientLogCountsByPaymentProfile;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_clientLogCountsByPaymentProfile(
	paymentProfileID BIGINT, 
	last90DayLogCount INT, 
	lifetimeLogCount INT, 
	PRIMARY KEY(paymentProfileID))
;

SET AUTOCOMMIT = 0;
INSERT rpt_main_02.rpt_clientLogCountsByPaymentProfile (
	paymentProfileID, 
	last90DayLogCount, 
	lifetimeLogCount)
SELECT 
	p.masterPaymentProfileID, 
	SUM(last90DayLogCount), 
	SUM(lifetimeLogCount)
FROM rpt_main_02.rpt_paymentProfileMaster p 
JOIN rpt_main_02.rpt_clientLogCountsByUserArchived clcua ON p.paymentProfileID = clcua.paymentProfileID
GROUP BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_clientLogCountsByPaymentProfile");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_monthEndCustomerProduct");

CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_monthEndCustomerProduct
(
  monthFriendly VARCHAR(15) DEFAULT NULL,
  startMonth DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
  endMonth DATETIME DEFAULT NULL,
  monthSequence TINYINT(4) DEFAULT NULL,
  paymentProfileID BIGINT(20) NOT NULL DEFAULT '0',
  ownerID BIGINT(20) DEFAULT NULL,
  sourceUserID BIGINT(20) DEFAULT NULL,
  accountType TINYINT(4) DEFAULT NULL,
  paymentType TINYINT(4) DEFAULT NULL,
  paymentFlags INT(11) DEFAULT NULL,
  parentPaymentProfileID BIGINT(20) DEFAULT NULL,
  paymentStartDateTime DATETIME DEFAULT NULL,
  productID INT(11) DEFAULT NULL,
  paymentTerm TINYINT(4) DEFAULT NULL,
  paymentTotal DECIMAL(38,10) DEFAULT NULL,
  paymentTotalfixedFOREX DECIMAL(38,10) DEFAULT NULL,
  userLimit INT(11) DEFAULT NULL,
  bonusUsers INT(11) DEFAULT NULL,
  billToRecurringBillingID VARCHAR(20) DEFAULT NULL,
  modifyDateTime DATETIME DEFAULT NULL,
  hist_effectiveThruDateTime DATETIME DEFAULT NULL,
/*  Add columns for Boolean value indicating whether each monthly listing indicates a WIN, Upgrade, Downgrade or LOSS */  
  isWin TINYINT(1) DEFAULT NULL,
  isUpgrade TINYINT(1) DEFAULT NULL,
  isDowngrade TINYINT(1) DEFAULT NULL,
  isLoss TINYINT(1) DEFAULT NULL,
  domain VARCHAR(100),
  isISP TINYINT,
  initialStartMonth DATETIME,
  initialStartMonthSequence INT,
  initialACV DECIMAL(10,2),
  initialLicenses INT,
  initialProductName VARCHAR(25),
  companySize VARCHAR(25),
  PRIMARY KEY (`paymentProfileID`,`startMonth`),
  KEY `idx_rpt_monthEndCustomerProduct` (`paymentProfileID`),
  KEY `idx_rpt_monthEndCustomerProductmodifyDateTime` (`modifyDateTime`),
  KEY `idx_rpt_monthEndCustomerProductEffectiveDateTime` (`hist_effectiveThruDateTime`),
  KEY `monthSequence` (`monthSequence`),
  KEY `sourceUserID` (sourceUserID)
) -- ENGINE=TokuDB DEFAULT CHARSET=utf8
;


DELETE FROM rpt_main_02.rpt_monthEndCustomerProduct
WHERE startMonth >=
(
	SELECT startMonth
	FROM rpt_main_02.ref_months WHERE startMonth < DATE_ADD(NOW(), INTERVAL - 5 DAY) AND endMonth > DATE_ADD(NOW(), INTERVAL -5 DAY)
)
;

INSERT IGNORE rpt_main_02.rpt_monthEndCustomerProduct
(
monthFriendly,
startMonth,
endMonth,
monthSequence,
paymentProfileID,
ownerID,
sourceUserID,
accountType,
paymentType,
paymentFlags,
parentPaymentProfileID,
paymentStartDateTime,
productID,
paymentTerm,
paymentTotal,
paymentTotalfixedFOREX,
userLimit,
bonusUsers,
billToRecurringBillingID,
modifyDateTime,
hist_effectiveThruDateTime,
domain
)
SELECT
ref_months.monthFriendly,
ref_months.startMonth,
ref_months.endMonth,
ref_months.monthSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.planRate/hce.exchangeRate,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime,
u.domain
FROM rpt_main_02.hist_paymentProfile ProductNew
JOIN rpt_main_02.ref_months ON ProductNew.hist_effectiveThruDateTime > ref_months.endMonth 
	AND ProductNew.modifyDateTime < ref_months.endMonth 
	AND ref_months.endMonth <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
	AND ref_months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID
JOIN rpt_main_02.rpt_paymentProfile ON rpt_paymentProfile.paymentProfileID = ProductNew.paymentProfileID
JOIN rpt_main_02.userAccount u ON u.userID = ppc.userID
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON ProductNew.currencyCode = hce.currencyCode
	AND ProductNew.paymentStartDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE ProductNew.parentPaymentProfileID IS NULL
AND ProductNew.planRate_USD > 0  /*Paid Accounts */
AND ProductNew.paymentType != 4  /*Not Promo Accounts */
ORDER BY MonthSequence
;

/*  Adds months after cancellation for paid accounts for use in comparisons and lookups   */


INSERT IGNORE rpt_main_02.rpt_monthEndCustomerProduct
(
monthFriendly,
startMonth,
endMonth,
monthSequence,
paymentProfileID,
ownerID,
sourceUserID,
accountType,
paymentType,
paymentFlags,
parentPaymentProfileID,
paymentStartDateTime,
productID,
paymentTerm,
paymentTotal,
paymentTotalfixedFOREX,
userLimit,
bonusUsers,
billToRecurringBillingID,
modifyDateTime,
hist_effectiveThruDateTime,
domain
)
SELECT 
ref_months.monthFriendly,
ref_months.startMonth,
ref_months.endMonth,
ref_months.monthSequence,
ProductNew.paymentProfileID,
ProductNew.ownerID,
ppc.userID,
ProductNew.accountType,
ProductNew.paymentType,
ProductNew.paymentFlags,
ProductNew.parentPaymentProfileID,
ProductNew.paymentStartDateTime,
ProductNew.productID,
ProductNew.paymentTerm,
ProductNew.planRate_USD,
ProductNew.planRate/hce.exchangeRate,
ProductNew.userLimit + IFNULL(ProductNew.bonusUserCount,0),
IFNULL(ProductNew.bonusUserCount,0),
ProductNew.billToRecurringBillingID,
ProductNew.modifyDateTime,
ProductNew.hist_effectiveThruDateTime,
u.domain
FROM rpt_main_02.rpt_monthEndCustomerProduct
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile ProductNew ON ProductNew.paymentProfileID  = rpt_monthEndCustomerProduct.paymentProfileID 
	AND ProductNew.planRate_USD <= 0  /* no money */
JOIN rpt_main_02.ref_months ON ProductNew.hist_effectiveThruDateTime > ref_months.endMonth 
	AND ProductNew.modifyDateTime < ref_months.endMonth
	AND ref_months.endMonth <= CONCAT ( LAST_DAY (NOW()), ' 23:59:59')
	AND ref_months.endMonth >= DATE_ADD(NOW(), INTERVAL -5 DAY)
JOIN rpt_main_02.rpt_paymentProfileContact ppc ON ppc.paymentProfileID = ProductNew.paymentProfileID
JOIN rpt_main_02.rpt_paymentProfile ON rpt_paymentProfile.paymentProfileID = ProductNew.paymentProfileID
JOIN rpt_main_02.userAccount u ON u.userID = ppc.userID
LEFT OUTER JOIN rpt_main_02.hist_currencyExchange hce ON ProductNew.currencyCode = hce.currencyCode
	AND ProductNew.paymentStartDateTime BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE ref_months.MonthSequence = rpt_monthEndCustomerProduct.MonthSequence + 1
ORDER BY monthSequence
;

DROP TABLE IF EXISTS rpt_workspace.cDunn_minModifyMecp;
CREATE TABLE IF NOT EXISTS rpt_workspace.cDunn_minModifyMecp
(paymentProfileID BIGINT,
firstStartMonth DATETIME,
PRIMARY KEY (paymentProfileID));

INSERT INTO rpt_workspace.cDunn_minModifyMecp
SELECT paymentProfileID, MIN(modifyDateTime)
FROM rpt_main_02.rpt_monthEndCustomerProduct
GROUP BY 1;

UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
JOIN rpt_workspace.cDunn_minModifyMecp B ON A.paymentProfileID = B.paymentProfileID
JOIN rpt_main_02.hist_userAccount hu ON hu.userID = A.sourceUserID AND B.firstStartMonth BETWEEN hu.modifyDateTime AND hu.hist_effectiveThruDateTime
SET A.domain = hu.domain
WHERE DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');
	
UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = A.domain
SET A.isISP = CASE WHEN isp.domain IS NOT NULL THEN 1 ELSE 0 END
	WHERE A.isISP IS NULL;

UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
SET domain = CONCAT(domain,"-",sourceUserID)
WHERE isISP = 1
AND DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

DROP TABLE IF EXISTS rpt_workspace.cDunn_mecpWithDomainStartMonths;
CREATE TABLE rpt_workspace.cDunn_mecpWithDomainStartMonths
(domain VARCHAR(100),
startMonth DATETIME,
monthSequence INT,
ACV DECIMAL(10,2),
licensesPurchased INT,
productName VARCHAR(25),
paymentType VARCHAR(50),
paymentTerm VARCHAR(25),
PRIMARY KEY (domain));

INSERT INTO rpt_workspace.cDunn_mecpWithDomainStartMonths (domain, startMonth)
SELECT domain, MIN(startMonth)
FROM rpt_main_02.rpt_monthEndCustomerProduct
GROUP BY 1;

UPDATE rpt_workspace.cDunn_mecpWithDomainStartMonths A
JOIN rpt_main_02.rpt_monthEndCustomerProduct B ON A.domain = B.domain AND A.startMonth = B.startMonth
SET A.monthSequence = B.monthSequence;

UPDATE rpt_workspace.cDunn_mecpWithDomainStartMonths A
SET ACV = (SELECT SUM((B.paymentTotal/B.paymentTerm)*12)
	FROM rpt_main_02.rpt_monthEndCustomerProduct B
	WHERE A.domain = B.domain AND A.startMonth = B.startMonth);

UPDATE rpt_workspace.cDunn_mecpWithDomainStartMonths A
SET licensesPurchased = (SELECT SUM(userLimit)
	FROM rpt_main_02.rpt_monthEndCustomerProduct B
	WHERE A.domain = B.domain AND A.startMonth = B.startMonth);

UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
STRAIGHT_JOIN rpt_workspace.cDunn_mecpWithDomainStartMonths B ON A.domain = B.domain
SET A.initialStartMonth = B.startMonth,
A.initialMonthSequence = B.monthSequence,
A.initialACV = B.ACV,
A.initialLicenses = B.licensesPurchased
WHERE DATE_FORMAT(A.startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
SET initialLicenses = 1 WHERE initialLicenses = 0
AND DATE_FORMAT(A.startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

UPDATE rpt_main_02.rpt_monthEndCustomerProduct A
JOIN rpt_workspace.pj_domainDataCoverage ddc ON A.domain = ddc.domain
SET A.companySize = ddc.companySize
WHERE DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');

CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_monthEndCustomerProduct UPDATE");
	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_monthEndCustomerProduct");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_monthOverMonthPlans");

DELETE FROM rpt_main_02.rpt_monthOverMonthPlans
WHERE DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m');


INSERT INTO rpt_main_02.rpt_monthOverMonthPlans
SELECT m.monthFriendly, 
m.startMonth,
m.endMonth,
	rpt_main_02.SMARTSHEET_PRODUCTNAME(hpp.productID) AS 'Product Name', 
	COUNT(DISTINCT(hpp.paymentProfileID)) AS 'Plans',
	SUM(hpp.planRate_USD/paymentTerm) AS 'MRR'
FROM rpt_main_02.hist_paymentProfile hpp
JOIN rpt_main_02.ref_months m ON hpp.hist_effectiveThruDateTime > m.endMonth
	AND hpp.modifyDateTime <= m.endMonth
	AND m.startMonth <= NOW() AND DATE_FORMAT(startMonth, '%Y-%m') >= DATE_FORMAT(DATE_SUB(CURRENT_DATE, INTERVAL 5 DAY), '%Y-%m')
WHERE hpp.productID > 2 AND hpp.planRate > 0 AND hpp.paymentType IN(1,2,3,6,8,10) AND hpp.accountType != 2
	GROUP BY 1,2,3,4;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_monthOverMonthPlans");

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.stg_sharingCounts");

SELECT MAX(maxShare) FROM rpt_workspace.cDunn_sharingSheetCounts INTO @maxUserShare;

INSERT IGNORE INTO rpt_workspace.cDunn_sharingUserCounts
SELECT insertByUserID, userID, MAX(insertDateTime)
FROM rpt_main_02.gridAccessMap
WHERE access < 50
AND insertDateTime > @maxUserShare
GROUP BY 1,2;

SELECT MAX(maxShare) FROM rpt_workspace.cDunn_sharingSheetCounts INTO @maxSheetShare;

INSERT IGNORE INTO rpt_workspace.cDunn_sharingSheetCounts
SELECT insertByUserID, gridID, MAX(insertDateTime)
FROM rpt_main_02.gridAccessMap
WHERE access < 50
AND insertDateTime > @maxSheetShare
GROUP BY 1,2;

DROP TABLE IF EXISTS rpt_main_02.stg_sharingCounts;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_sharingCounts
(userID BIGINT,
sheetsShared INT,
usersSharedTo INT,
PRIMARY KEY (userID));

INSERT INTO rpt_main_02.stg_sharingCounts (userID, sheetsShared)
SELECT insertByUserID, COUNT(DISTINCT(gridID))
FROM rpt_workspace.cDunn_sharingSheetCounts
GROUP BY 1;

UPDATE rpt_main_02.stg_sharingCounts A
SET usersSharedTo = (SELECT COUNT(DISTINCT(userID))
	FROM rpt_workspace.cDunn_sharingUserCounts B
		WHERE A.userID = B.insertByUserID);
		
SELECT MAX(scheduledUpdateID) FROM rpt_main_02.scheduledUpdate INTO @maxUpdateReq;

INSERT INTO rpt_main_02.scheduledUpdate
SELECT * FROM ss_core_02.scheduledUpdate
WHERE scheduledUpdateID > @maxUpdateReq
AND updateType = 2
;		
	
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.stg_sharingCounts");

CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.rpt_SFDCRollingPipeline");

DROP TABLE IF EXISTS rpt_main_02.rpt_SFDCRollingPipelineClosedInsert;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_SFDCRollingPipelineClosedInsert
(Id VARCHAR(50),
PRIMARY KEY (Id));

SELECT MAX(snapshotDateTime) FROM rpt_main_02.rpt_SFDCRollingPipeline INTO @lastSnapshotDateTime;

INSERT INTO rpt_main_02.rpt_SFDCRollingPipelineClosedInsert(Id)
SELECT Id FROM rpt_main_02.rpt_SFDCRollingPipeline
WHERE snapshotDateTime=@lastSnapshotDateTime AND stage NOT IN ('Closed Won','Closed Lost');

INSERT IGNORE INTO rpt_main_02.rpt_SFDCRollingPipeline(Id, NAME, Stage, Amount, CreatedDate, CloseDate, ServicesType, ServicesAmount, LeadSource, ProductName, OwnerID, 
ResellerOpportunity, SecurityPack, IntegrationPack, Sights, Salesforce, SCC, JIRA, snapshotDateTime, snapshotDate)
SELECT A.Id, NAME, StageName, (ARR_Variance__c/hce.exchangeRate), CreatedDate, CloseDate, Service__c, (Opportunity_One_Time_Total__c/hce.exchangeRate), 
LeadSource, Product__c, OwnerID, Reseller_Opportunity__c, Security_Pack__c, Integration_Pack__c, Dashboards__c, Salesforce_Integration__c, Project_Control_Center__c, 
Jira_Integration__c, NOW(), CURDATE() 
FROM ss_sfdc_02.opportunity A
JOIN rpt_main_02.rpt_SFDCRollingPipelineClosedInsert B ON A.Id=B.Id
JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = A.CurrencyIsoCode AND A.CloseDate BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
;

INSERT IGNORE INTO rpt_main_02.rpt_SFDCRollingPipeline(Id, NAME, Stage, Amount, CreatedDate, CloseDate, ServicesType, ServicesAmount, LeadSource, ProductName, OwnerID, 
ResellerOpportunity, SecurityPack, IntegrationPack, Sights, Salesforce, SCC, JIRA, snapshotDateTime, snapshotDate)
SELECT Id, NAME, StageName, (ARR_Variance__c/hce.exchangeRate), CreatedDate, CloseDate, Service__c, (Opportunity_One_Time_Total__c/hce.exchangeRate), LeadSource, Product__c, OwnerID, Reseller_Opportunity__c, 
Security_Pack__c, Integration_Pack__c, Dashboards__c, Salesforce_Integration__c, Project_Control_Center__c, Jira_Integration__c, NOW(), CURDATE() 
FROM ss_sfdc_02.opportunity A
JOIN rpt_main_02.hist_currencyExchange hce ON hce.currencyCode = A.CurrencyIsoCode AND A.CloseDate BETWEEN hce.modifyDateTime AND hce.hist_effectiveThruDateTime
WHERE createdDate > @lastSnapshotDateTime;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET closedWonActualAmount=Amount
WHERE Stage='Closed Won';

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET closedLostAmount=Amount
WHERE Stage='Closed Lost';

DROP TABLE IF EXISTS rpt_main_02.rpt_SFDCRollingPipelinePart2;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_SFDCRollingPipelinePart2
SELECT ID, Amount AS previousAmount FROM rpt_main_02.rpt_SFDCRollingPipeline
WHERE snapshotDateTime=@lastSnapshotDateTime AND snapshotDate < CURDATE();

ALTER TABLE rpt_main_02.rpt_SFDCRollingPipelinePart2
ADD currentAmount DEC(10,2),
ADD amountVariance DEC(10,2),
ADD PRIMARY KEY (ID);

UPDATE rpt_main_02.rpt_SFDCRollingPipelinePart2 A
JOIN rpt_main_02.rpt_SFDCRollingPipeline B
ON A.Id=B.Id 
SET A.currentAmount=B.Amount
WHERE B.snapshotDate=CURDATE();

UPDATE rpt_main_02.rpt_SFDCRollingPipelinePart2
SET amountVariance=currentAmount-previousAmount;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A 
JOIN rpt_main_02.rpt_SFDCRollingPipelinePart2 B
ON A.Id=B.Id AND A.snapshotDate=CURDATE()
SET A.oppExistedPreviousDay=1;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET newOppAmountForecast=Amount
WHERE oppExistedPreviousDay IS NULL AND snapshotDate=CURDATE();

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A 
JOIN rpt_main_02.rpt_SFDCRollingPipelinePart2 B
ON A.Id=B.Id AND A.snapshotDate=CURDATE()
SET A.oldOppAmountForecastVariance=B.amountVariance
WHERE A.Stage NOT IN ('Closed Won','Closed Lost');

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A 
JOIN rpt_main_02.rpt_SFDCRollingPipelinePart2 B
ON A.Id=B.id AND A.snapshotDate=CURDATE()
SET A.closedForecastActualVariance=B.amountVariance
WHERE A.Stage IN ('Closed Won','Closed Lost');

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET newOppAmountForecast=0
WHERE newOppAmountForecast IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET oldOppAmountForecastVariance=0
WHERE oldOppAmountForecastVariance IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET closedWonActualAmount=0
WHERE closedWonActualAmount IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET closedForecastActualVariance=0
WHERE closedForecastActualVariance IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET closedLostAmount=0
WHERE closedLostAmount IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET openAmount=
CASE WHEN stage NOT IN ('Closed Won','Closed Lost') THEN Amount
ELSE 0
END;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET previousDayOpenAmount=
CASE WHEN stage IN ('Closed Won','Closed Lost') AND oppExistedPreviousDay=1 THEN closedWonActualAmount+closedLostAmount-closedForecastActualVariance
WHEN stage IN ('Closed Won','Closed Lost') AND oppExistedPreviousDay IS NULL THEN 0
WHEN stage NOT IN ('Closed Won','Closed Lost') THEN openAmount-newOppAmountForecast-oldOppAmountForecastVariance
END
WHERE closedOppReOpened IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET netVariance=openAmount-previousDayOpenAmount;



DROP TABLE IF EXISTS rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened;
CREATE TABLE IF NOT EXISTS rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened
SELECT A.Id, A.Stage AS ClosedStage, A.Amount AS closedAmount, B.Amount AS openAmount, B.Amount-A.Amount AS amountVariance FROM rpt_main_02.rpt_SFDCRollingPipeline A
JOIN ss_sfdc_02.opportunity B
ON A.Id=B.Id
WHERE A.stage IN ('Closed Won','Closed Lost')
AND B.stageName NOT IN ('Closed Won','Closed Lost');

ALTER TABLE rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened
ADD currentDayStage VARCHAR(50);

UPDATE rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened A
JOIN rpt_main_02.rpt_SFDCRollingPipeline B
ON A.Id=B.Id 
SET A.currentDayStage=B.stage
WHERE B.snapshotDate=CURDATE();

INSERT IGNORE INTO rpt_main_02.rpt_SFDCRollingPipeline(Id, NAME, Stage, Amount, CreatedDate, CloseDate, ServicesType, ServicesAmount, LeadSource, ProductName, OwnerID, 
ResellerOpportunity, SecurityPack, IntegrationPack, Sights, Salesforce, SCC, JIRA, snapshotDateTime, snapshotDate, closedOppReOpened, oppExistedPreviousDay, newOppAmountForecast, 
oldOppAmountForecastVariance, closedWonActualAmount, closedLostAmount, closedForecastActualVariance, openAmount, previousDayOpenAmount, netVariance)
SELECT A.Id, NAME, StageName, Amount, CreatedDate, CloseDate, Service__c, Services_ACV__c, LeadSource, Product__c, OwnerID, Reseller_Opportunity__c, 
Security_Pack__c, Integration_Pack__c, Dashboards__c, Salesforce_Integration__c, Project_Control_Center__c, Jira_Integration__c, NOW(), CURDATE(), 1, NULL, 0, 
0, -B.closedAmount, 0, B.amountVariance, Amount, 0, Amount FROM ss_sfdc_02.opportunity A
JOIN rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened B
ON A.Id=B.Id
WHERE B.currentDayStage IS NULL AND B.ClosedStage='Closed Won';

INSERT IGNORE INTO rpt_main_02.rpt_SFDCRollingPipeline(Id, NAME, Stage, Amount, CreatedDate, CloseDate, ServicesType, ServicesAmount, LeadSource, ProductName, OwnerID, 
ResellerOpportunity, SecurityPack, IntegrationPack, Sights, Salesforce, SCC, JIRA, snapshotDateTime, snapshotDate, closedOppReOpened, oppExistedPreviousDay, newOppAmountForecast, 
oldOppAmountForecastVariance, closedWonActualAmount, closedLostAmount, closedForecastActualVariance, openAmount, previousDayOpenAmount, netVariance)
SELECT A.Id, NAME, StageName, Amount, CreatedDate, CloseDate, Service__c, Services_ACV__c, LeadSource, Product__c, OwnerID, Reseller_Opportunity__c, 
Security_Pack__c, Integration_Pack__c, Dashboards__c, Salesforce_Integration__c, Project_Control_Center__c, Jira_Integration__c, NOW(), CURDATE(), 1, NULL, 0, 
0, 0, -B.closedAmount, B.amountVariance, Amount, 0, Amount FROM ss_sfdc_02.opportunity A
JOIN rpt_main_02.rpt_SFDCRollingPipelineClosedReOpened B
ON A.Id=B.Id
WHERE B.currentDayStage IS NULL AND B.ClosedStage='Closed Lost';

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET ResellerOpportunity='False'
WHERE ResellerOpportunity IS NULL; 

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET SecurityPack='false'
WHERE SecurityPack IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET IntegrationPack='false'
WHERE IntegrationPack IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET Sights='false'
WHERE Sights IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET Salesforce='false'
WHERE Salesforce IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET SCC='false'
WHERE SCC IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET JIRA='false'
WHERE JIRA IS NULL;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET newOppAmountForecast=NULL, oldOppAmountForecastVariance=NULL, closedWonActualAmount=NULL, closedLostAmount=NULL, closedForecastActualVariance=NULL,
previousDayOpenAmount=NULL, netVariance=NULL
WHERE snapshotDate='2017-04-01';

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A
JOIN ss_sfdc_02.user B
ON A.OwnerID=B.Id 
LEFT JOIN ss_sfdc_02.user_role C
ON B.UserRoleID=C.Id
SET A.repName=CONCAT(B.FirstName,' ',B.LastName), A.salesTeam=C.Name;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET salesTeam='WW Sales'
WHERE repName IN ('Lindsay Gardner', 'Amir Khorram');

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A
JOIN rpt_main_02.rpt_SFDCRollingPipelineStageProbabilities2 B
ON A.Stage=B.Stage
SET A.modelClosedWonForecast=
CASE WHEN DATE_FORMAT(A.snapshotDate,'%Y-%m')!=DATE_FORMAT(A.closeDate,'%Y-%m') THEN 0
WHEN DATE_FORMAT(A.snapshotDate,'%Y-%m')=DATE_FORMAT(A.closeDate,'%Y-%m') THEN A.openAmount*B.ClosedWonAmountProbability
END
WHERE snapshotDate=CURDATE();

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET modelClosedWonForecast=0
WHERE Stage IN ('Closed Won','Closed Lost') AND snapshotDate=CURDATE();

UPDATE rpt_main_02.rpt_SFDCRollingPipeline A
JOIN ss_sfdc_02.opportunity B
ON A.Id=B.Id
SET A.createdBySDR=
CASE WHEN B.SDR_Attribution__c IS NOT NULL OR B.SDR_Attribution__c!='' THEN 1
ELSE 0
END;

SELECT MIN(snapshotDateTime) FROM rpt_main_02.rpt_SFDCRollingPipeline WHERE snapshotDate=CURDATE() INTO @lastSnapshotDateTime;

UPDATE rpt_main_02.rpt_SFDCRollingPipeline
SET snapshotDateTime=@lastSnapshotDateTime
WHERE snapshotDate=CURDATE();

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.rpt_SFDCRollingPipeline");

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** Throwaway Part 5: Misc - end ******** ", NOW();
/*End*/


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("Throwaway Part 5: Misc");