SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("OptimizelyExperimentsV2.csv");

SELECT 
userAccount.userID AS 'User ID', 
userAccount.emailAddress AS 'E-mail Address', 
rpt_optimizelyExperiments.experiment,
rpt_optimizelyExperiments.variation,
rpt_signupSource.signupInsertDateTime,
	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
	
rpt_signupSource.campaign,
rpt_signupSource.segment,
rpt_signupSource.keyword,
rpt_signupSource.ad_id,
rpt_signupSource.webSite,
rpt_signupSource.webPage,
rpt_signupSource.placement,
rpt_signupSource.network,
rpt_signupSource.slp,

	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Once',
	
	CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Twice',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
	
ttr.isStrongLeadAdjusted AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Lifetime Log Count >= 400',
	MIN(rpt_trials.trialDateTime) AS trialDateTime,
	CASE WHEN MIN(rpt_trials.trialDateTime) IS NULL THEN 0 ELSE 1 END AS HadTrial,	
	rpt_trials.trialType,
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0 ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',	
	rpt_paymentProfile.productName AS 'Product Name',
		rpt_paymentProfile.hasPaid,
	rpt_userIPLocation.ipCountry AS "IP Country",
	CASE WHEN ttr.isStrongLeadAdjusted = 1 THEN 1 ELSE 0 END AS 'StrongLeads',
	CASE WHEN ttr.isStrongLeadAdjusted = 1 THEN ttr.weightedStrongLeadFactor ELSE 0 END AS 'WeightedStrongLeads',
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL ELSE 	
		CASE rpt_paymentProfile.countAsPaid = 0 WHEN 1 THEN NULL ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm END
	END AS 'Monthly Revenue',
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS "Basic?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS "Advanced?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS "Team?",
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS "Enterprise_Legacy?",
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS "Cancelled?",
	
	CASE MIN(rpt_paymentProfile.paymentStartDateRaw) IS NOT NULL AND DATEDIFF(CURRENT_DATE(), MIN(rpt_paymentProfile.paymentStartDateRaw)) <= 35
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is In 35 Day Window',
rpt_signupSource.landingPageVersion,
CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * 
(rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
	
UserPP.userLimit AS TotalLicenses,
CASE WHEN rpt_paymentProfile.countAsPaid = 1 THEN (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm)*12
	ELSE (ParentPP.planRate_USD/ParentPP.paymentTerm)*12 END AS ACV,
CASE WHEN UserPP.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
UserPP.productName, 
UserPP.userLimit,
CASE WHEN fwp.sourceUserID IS NOT NULL THEN 1 ELSE 0 END AS 'Conversions',
fwp.userLimit AS 'Win Licenses',
(fwp.planRate_USD/fwp.paymentTerm) AS 'Win MRR',
CASE WHEN ttr.isLicensed IS NULL THEN 0 ELSE ttr.isLicensed END AS 'Licenses',
ttr.expansionConsumption,
rpt_signupSource.landingPageVersion,
CONCAT(rpt_signupSource.trpValue, " ", IF(trp.trpName IS NULL, "UNKNOWN TRP VALUE",trp.trpName)) AS 'TRP Value',

ab.siteSettingElementName,
ab.valueNumeric,
rpt_signupSource.lpa,
CASE WHEN o.Parent_Payment_Profile_ID__c IS NOT NULL THEN 1 ELSE 0 END AS 'SalesAssisted',
lx.itemValue AS 'lxCode',
rpt_main_02.`SMARTSHEET_PRODUCTNAME`(fwp.productID) AS winProduct,

CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 10 THEN 1 ELSE 0 
		END 
	END AS "Business?",
CASE WHEN isp.domain IS NOT NULL THEN 'ISP' ELSE 'ORG' END AS 'ISP Domain',
CASE WHEN rsm2.mainContactUserID IS NOT NULL THEN 1 ELSE 0 END AS 'NewLogo',
userAccount.domain,
ddc.companySize



FROM rpt_main_02.rpt_optimizelyExperiments
LEFT OUTER JOIN rpt_main_02.userAccount ON rpt_optimizelyExperiments.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_optimizelyExperiments.signupRequestID = rpt_signupSource.signupRequestID
LEFT OUTER JOIN rpt_main_02.rpt_trials ON userAccount.userID = rpt_trials.userID 
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile FORCE INDEX (idx_rpt_paymentProfileSourceUserID) ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.countAsPaid = 1
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON userAccount.userID = arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived FORCE INDEX (PRIMARY) ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser  ON rpt_optimizelyExperiments.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON rpt_optimizelyExperiments.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile UserPP ON userAccount.userID = UserPP.mainContactUserID AND UserPP.accountType != 3
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ParentPP ON ParentPP.paymentProfileID = UserPP.parentPaymentProfileID
LEFT OUTER JOIN rpt_main_02.stg_tableauTrialReport ttr ON ttr.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.ref_trpValues trp ON trp.trpValue = rpt_signupSource.trpvalue
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue ab ON ab.userID = userAccount.userID
	AND ab.siteSettingElementName = "SS_ABTEST_TEAM_TRIAL"
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly rsm ON rsm.mainContactUserID = userAccount.userID AND rsm.recordType = 'WINS'
LEFT OUTER JOIN ss_sfdc_02.opportunity o ON o.Parent_Payment_Profile_ID__c = rsm.paymentProfileID 
	AND o.StageName = 'Closed Won' AND o.product__c != 'Services'
	AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,rsm.recordDateTime),'%Y-%m-01')=DATE_FORMAT(o.CloseDate,'%Y-%m-01')
LEFT OUTER JOIN rpt_main_02.rpt_lxCodes lx ON lx.signupRequestID = rpt_signupSource.signupRequestID
LEFT OUTER JOIN rpt_main_02.arc_sourceUser_firstWinProduct fwp ON fwp.sourceUserID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains isp ON isp.domain = userAccount.domain
LEFT OUTER JOIN rpt_main_02.output_RevenueSummaryMonthly rsm2 ON rsm2.mainContactUserID = userAccount.userID AND rsm2.domainLevelRecordType = 'WINS'
	AND rsm2.ispDomain = 0
LEFT OUTER JOIN rpt_workspace.pj_domainDataCoverage ddc on ddc.domain = userAccount.domain

GROUP BY 1,2,3,4,5
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("OptimizelyExperimentsV2.csv");


