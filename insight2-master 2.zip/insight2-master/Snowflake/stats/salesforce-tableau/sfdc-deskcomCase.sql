



SELECT 
dcc.DeskCom_display_id__c AS 'Desk Case ID',
REPLACE(dcc.Name, SUBSTRING(dcc.Name, LOCATE('[', dcc.Name), LENGTH(dcc.Name) - LOCATE(']', REVERSE(dcc.Name)) - LOCATE('[', dcc.Name) + 2), '') AS 'Case Name',
dcc.DeskCom_Account__c AS 'Account Id',
dcc.DeskCom_Body__c AS Body,
dcc.DeskCom_Contact__c AS 'Contact Id',
dcc.DeskCom_Lead__c AS 'Lead Id',
dcc.DeskCom_Opportunity__c AS 'Opportunity Id',
dcc.DeskCom_case_url__c AS 'Case URL',
dcc.DeskCom_channel__c AS Channel,
dcc.DeskCom_created_at__c AS 'Created At',
dcc.DeskCom_priority__c AS Priority,
dcc.DeskCom_status__c AS 'Status',
dcc.DeskCom_subject__c AS 'Subject',
dcc.DeskCom_updated_at__c AS 'Updated At',
dcc.Id,
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'Owner Name',
dcc.CREATED_DATE AS 'Created Date',
CONCAT(cb.FIRST_NAME,' ',cb.LAST_NAME) AS 'Created By Name',
dcc.LastModifiedDate AS 'Last Modified Date',
CONCAT(lm.FIRST_NAME,' ',lm.LAST_NAME) AS 'Last Modified By Name'
FROM SFDC.PUBLIC.deskcom_case dcc
LEFT JOIN SFDC.PUBLIC.user u ON dcc.OWNER_ID=u.Id
LEFT JOIN SFDC.PUBLIC.user cb ON dcc.CreatedById=cb.Id
LEFT JOIN SFDC.PUBLIC.user lm ON dcc.LastModifiedById=lm.Id
;