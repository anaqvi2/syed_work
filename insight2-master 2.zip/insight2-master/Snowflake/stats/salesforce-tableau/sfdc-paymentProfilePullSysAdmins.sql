


SELECT cp.paymentProfileID, cp.OWNER_ID AS OrgID, org.userID, org.role, u.emailAddress, rpt_main_02.`SMARTSHEET_PRODUCTNAME`(cp.productID) AS productName
FROM ss_core_02.paymentProfile cp
JOIN ss_core_02.organizationUserRole org ON org.organizationID = cp.OWNER_ID AND org.role = 'PAYMENT_ADMIN'
JOIN ss_core_02.userAccount u ON u.userID = org.userID
WHERE cp.productID >= 3 AND cp.accountType = 3 AND cp.planRate > 0
;