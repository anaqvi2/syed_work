


SELECT 
otm.TeamMemberRole AS 'Team Member Role',
otm.Id,
otm.OpportunityId AS 'Opportunity Id',
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'User Name'
FROM SFDC.PUBLIC.opportunity_team_member otm
LEFT JOIN SFDC.PUBLIC.user u ON otm.UserId=u.Id
;