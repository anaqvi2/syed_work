

DROP TABLE rpt_workspace.cDunn_npsAll;
CREATE TABLE rpt_workspace.cDunn_npsAll
(npsID INT,
emailAddress VARCHAR(100),
userID BIGINT,
NetPromoterScore INT,
NetPromoterScoreReason VARCHAR(2000),
productName VARCHAR(25),
insightInsertDate DATETIME,
listID INT, 
leadId BIGINT,
listTypeId INT,
listType VARCHAR(100),
sentDateTime DATETIME,
formDateTime DATETIME,
formType VARCHAR(100),
formTypeID INT,
npsDate DATETIME,
ReviewType VARCHAR(25),
accountName VARCHAR(100),
CustomerSuccess VARCHAR(50),
FIRST_NAME VARCHAR(100),
LAST_NAME VARCHAR(100),
SalesRep VARCHAR(50),
licensedUsers INT,
NumberOfEmployees INT,
ARR DECIMAL(10,2),
Tier VARCHAR(5),
Health VARCHAR(25),
Role VARCHAR(100),
Title VARCHAR(100),
Territory VARCHAR(100),
AccountToBeAssigned VARCHAR(25),
ispDomain VARCHAR(25),
ppID BIGINT,
acvRange VARCHAR(50),
firstLicenseDate DATETIME,
daysToNps INT,
customerSurveyCount INT,
userSurveyCount INT,
country VARCHAR(100),
A13Region VARCHAR(100),
PRIMARY KEY (npsID),
KEY userID (userID),
KEY ppID (ppID),
KEY npsDate (npsDate));



INSERT INTO rpt_workspace.cDunn_npsAll (npsID, emailAddress, userID, NetPromoterScore, NetPromoterScoreReason, productName, insightInsertDate, listID, leadId,
					listTypeId, listType, sentDateTime, formDateTime, formType, formTypeID, npsDate, ReviewType, accountName, CustomerSuccess,
					FIRST_NAME, LAST_NAME, SalesRep, licensedUsers, NumberOfEmployees, ARR, Tier, Health, Role, Title, Territory, AccountToBeAssigned,
					ISPDomain, ppID, acvRange, firstLicenseDate, daysToNPS)
					
SELECT nps.npsID, nps.emailAddress, nps.userID, nps.netPromoterScore, nps.netPromoterScoreReason, nps.productName, nps.insertDateTime, 
amll.listID, amll.leadId, la.primaryAttributeValueId AS listTypeID, la.primaryAttributeValue AS listType, la.activityDateTime AS sentDateTime, MAX(form.activityDateTime) AS formDateTime, 
form.primaryAttributeValue AS formType, form.primaryAttributeValueID AS formTypeID, IFNULL(MAX(form.activityDateTime),nps.insertDateTime) AS 'npsDate',
CASE WHEN nps.netPromoterScore IN(9,10) THEN 'Promoter'
	WHEN nps.netPromoterScore IN(7,8) THEN 'Neutral'
	WHEN nps.netPromoterScore < 7 THEN 'Detractor' END AS 'ReviewType',
acc.Name, CONCAT(cs.FIRST_NAME," ",cs.LAST_NAME), u.FIRST_NAME, u.LAST_NAME, CONCAT(rep.FIRST_NAME," ",rep.LAST_NAME), ppi.licensedUsers, acc.NumberOfEmployees, ppi.ACV,  
csa.accountTier, csa.accountHealth, udc.Role, udc.Title, acc.Territory__c, acc.Account_To_Be_Assigned__c, 
CASE WHEN isp.domain IS NOT NULL THEN 'ISP Domain' ELSE 'Org Domain' END, NULL,
NULL, fl.firstLicenseDate, NULL
FROM leadflow.arc_marketo_lead_nps nps
JOIN rpt_main_02.userAccount u ON u.userID = nps.userID
LEFT JOIN leadflow.arc_marketo_lead_lists amll ON amll.userID = nps.userID AND amll.listID IN
      (33268, 76512, 128696, 153267, 153268, 160629, 164362, 164780, 164781, 164782, 164783,
       164784, 164785, 164786, 164789, 164790, 164791, 164792, 164793, 164794)
LEFT JOIN leadflow.arc_marketo_lead_activity la ON la.leadId = amll.leadId AND la.activityTypeId = 6 
	AND la.primaryAttributeValueID IN(16615,16670,19972,19973,21218,21219,21305,21401,21527,21672,21864,22011,22247,22423,22577,22637,22844,23113,23324,23787)
LEFT JOIN leadflow.arc_marketo_lead_activity form ON form.leadId = amll.leadId AND form.activityTypeId = 2 AND form.primaryAttributeValueID IN(1975,2437,2430)
	AND form.activityDateTime < nps.insertDateTime
LEFT JOIN SFDC.PUBLIC.domain d ON d.Domain_Name_URL__c = u.domain
LEFT JOIN SFDC.PUBLIC.account acc ON acc.Id = d.Account__c
LEFT JOIN SFDC.PUBLIC.user cs ON cs.Id = acc.Customer_Success__c
LEFT JOIN SFDC.PUBLIC.user rep ON rep.Id = acc.OWNER_ID
LEFT JOIN MAIN.RPT.paidPlanCurrentUsers ppcu ON ppcu.mainContactUserID = u.userID
LEFT JOIN MAIN.RPT.paidPlanInfo ppi ON ppi.paymentProfileID = ppcu.planID
LEFT JOIN MAIN.RPT.csaReport csa ON csa.accountId = acc.Id
LEFT JOIN rpt_workspace.pj_userDataCoverage udc ON udc.userID = u.userID
LEFT JOIN MAIN.ARC.ISPDomains isp ON isp.domain = d.Domain_Name_URL__c
LEFT JOIN rpt_workspace.cDunn_userFirstLicenseDate fl ON fl.userID = u.userID


WHERE nps.emailAddress NOT LIKE '%smartsheet.com'
GROUP BY 1 
;

UPDATE rpt_workspace.cDunn_npsAll A
JOIN leadflow.arc_marketo_lead_activity form ON form.leadId = A.leadID AND form.activityTypeId = 2 AND form.primaryAttributeValueID IN(1975,2437,2430)
	AND form.activityDateTime = A.formDateTime
SET A.formType = form.primaryAttributeValue,
	A.formTypeID = form.primaryAttributeValueID;
	
UPDATE rpt_workspace.cDunn_npsAll A
JOIN leadflow.arc_marketo_lead_activity la 
	ON la.leadId = A.leadId AND la.activityTypeId = 6 
	AND la.primaryAttributeValueID IN(16615,16670,19972,19973,21218,21219,21305,21401,21527,21672,21864,22011,22247,22423,22577,22637,22844,23113,23324,23787)
	AND la.activityDateTime < A.formDateTime
SET sentDateTime = la.activityDateTime ;

UPDATE rpt_workspace.cDunn_npsAll A
JOIN leadflow.arc_marketo_lead_activity la 
	ON la.leadId = A.leadId AND la.activityTypeId = 6 
	AND la.primaryAttributeValueID IN(16615,16670,19972,19973,21218,21219,21305,21401,21527,21672,21864,22011,22247,22423,22577,22637,22844,23113,23324,23787)
	AND la.activityDateTime = A.sentDateTime
SET A.listType = la.primaryAttributeValue,
	A.listTypeID = la.primaryAttributeValueID;
	
UPDATE rpt_workspace.cDunn_npsAll A
SET daysToNPS = DATEDIFF(A.npsDate,A.firstLicenseDate);

UPDATE rpt_workspace.cDunn_npsAll A
JOIN MAIN.HIST.paymentProfile hpp ON hpp.OWNER_ID = A.userID AND hpp.accountType != 3 AND hpp.productID > 2
	AND A.npsDate BETWEEN hpp.MODIFY_DATE_TIME AND hpp.HIST_EFFECTIVE_THRU_DATE_TIME
SET A.ppID = CASE WHEN hpp.parentPaymentProfileID IS NULL THEN hpp.paymentProfileID ELSE hpp.parentPaymentProfileID END;

UPDATE rpt_workspace.cDunn_npsAll A
JOIN MAIN.HIST.paymentProfile hpp ON hpp.paymentProfileID = A.ppID 
AND A.npsDate BETWEEN hpp.MODIFY_DATE_TIME AND hpp.HIST_EFFECTIVE_THRU_DATE_TIME
SET A.acvRange = CASE WHEN (hpp.planRate_USD/hpp.paymentTerm)*12 <= 1000 THEN "Less than 1K"
			WHEN (hpp.planRate_USD/hpp.paymentTerm)*12 <= 2000 THEN "1K-2K"
			WHEN (hpp.planRate_USD/hpp.paymentTerm)*12 <= 3000 THEN "2K-3K"
			WHEN (hpp.planRate_USD/hpp.paymentTerm)*12 <=5000 THEN "3K-5K"
			WHEN (hpp.planRate_USD/hpp.paymentTerm)*12 > 5000 THEN "5K+" END;
			
DROP TABLE IF EXISTS rpt_workspace.cDunn_customerNPSCounts;
CREATE TEMPORARY TABLE rpt_workspace.cDunn_customerNPSCounts
SELECT accountName, COUNT(*) AS surveys
FROM rpt_workspace.cDunn_npsAll
GROUP BY 1;

CREATE UNIQUE INDEX accountName ON rpt_workspace.cDunn_customerNPSCounts (accountName);

UPDATE rpt_workspace.cDunn_npsAll A
JOIN rpt_workspace.cDunn_customerNPSCounts B ON A.accountName = B.accountName
SET A.customerSurveyCount = B.surveys;


DROP TABLE IF EXISTS rpt_workspace.cDunn_userNPSCounts;
CREATE TEMPORARY TABLE rpt_workspace.cDunn_userNPSCounts
SELECT userID, COUNT(*) AS surveys
FROM rpt_workspace.cDunn_npsAll
GROUP BY 1;

CREATE UNIQUE INDEX userID ON rpt_workspace.cDunn_userNPSCounts (userId);

UPDATE rpt_workspace.cDunn_npsAll A
JOIN rpt_workspace.cDunn_userNPSCounts B ON A.userID = B.userId
SET A.userSurveyCount = B.surveys;

UPDATE rpt_workspace.cDunn_npsAll A
JOIN MAIN.RPT.userIPLocation ip ON ip.userID = A.userID
SET A.country = ip.ipCountry;

UPDATE rpt_workspace.cDunn_npsAll A
JOIN MAIN.REF.geoClassification B ON A.country = B.country
SET A.A13Region = B.geoRegion;
	
SELECT * FROM rpt_workspace.cDunn_npsAll
;