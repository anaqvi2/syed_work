



SELECT CONCAT(rep.FIRST_NAME," ",rep.LAST_NAME), acc.Territory__c, acc.Id, acc.Name, MAX(t.ActivityDate) AS 'Last Engagement'
FROM SFDC.PUBLIC.account acc
JOIN SFDC.PUBLIC.user rep ON acc.OWNER_ID = rep.Id
LEFT JOIN SFDC.PUBLIC.task t ON t.AccountId = acc.Id AND t.Type = 'Engagement' AND t.Status = 'Completed'
WHERE acc.Territory__c IS NOT NULL AND rep.Title = 'Client Development Manager'
GROUP BY 3
;