



SELECT 
c.FIRST_NAME AS 'First Name',
c.LAST_NAME AS 'Last Name',
c.MailingCity AS 'Mailing City',
c.MailingState AS 'Mailing State',
c.MailingPostalCode AS 'Mailing Postal Code',
c.MailingCountry AS 'Mailing Country',
c.Phone,
c.MobilePhone AS 'Mobile Phone',
c.Email,
c.Title,
c.Department,
c.LeadSource AS 'Lead Source',
c.HasOptedOutOfEmail AS 'Has Opted Out of Email',
c.Contact_Type__c AS 'Contact Type',
c.Additional_Email__c AS 'Additional Email',
c.mkto2_Lead_Score__c AS 'mkto2 Lead Score',
c.userID__c AS userID,
c.paymentProfileID__c AS paymentProfileID,
c.parentPaymentProfileID__c AS parentPaymentProfileID,
c.OptOutSales__c AS 'Opt Out Sales',
c.OptOutMarketing__c AS 'Opt Out Marketing',
c.Last_Webinar_Attended__c AS 'Last Webinar Attended',
c.Id,
c.AccountId AS 'Account Id',
a.Name AS 'Account Name',
c.ReportsToId AS 'Reports To Id',
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'Owner Name',
c.CREATED_DATE AS 'Created Date',
CONCAT(cb.FIRST_NAME,' ',cb.LAST_NAME) AS 'Created By Name',
c.LastModifiedDate AS 'Last Modified Date',
CONCAT(lm.FIRST_NAME,' ',lm.LAST_NAME) AS 'Last Modified By Name',
c.LastActivityDate AS 'Last Activity Date',
c.Fit_Rating__c AS 'Fit Rating',
c.Fit_Score__c AS 'Fit Score',
c.mkto_si__Relative_Score_Value__c AS 'Relative Score Value',
c.mkto_si__Urgency_Value__c AS 'Urgency Value',
c.productName__c AS Product,
c.Lead_Owner_at_Import__c as 'Lead Owner at Import',
c.Dashboard_Count__c AS 'Sights Count',
c.Dashboards_Enabled_Date_Time__c AS 'Sights Enabled Date'
FROM SFDC.PUBLIC.contact c
LEFT JOIN SFDC.PUBLIC.user u ON c.OWNER_ID=u.Id
LEFT JOIN SFDC.PUBLIC.user cb ON c.CreatedById=cb.Id
LEFT JOIN SFDC.PUBLIC.user lm ON c.LastModifiedById=lm.Id
LEFT JOIN SFDC.PUBLIC.account a ON c.AccountId=a.Id
;