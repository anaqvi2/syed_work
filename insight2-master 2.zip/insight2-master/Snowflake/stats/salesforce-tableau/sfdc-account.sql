



SELECT 
a.Name, 
a.Type,
a.BillingStreet AS 'Billing Street',
a.BillingCity AS 'Billing City',
a.BillingState AS 'Billing State',
a.BillingPostalCode AS 'Billing Postal Code',
a.BillingCountry AS 'Billing Country',
a.ShippingStreet AS 'Shipping Street',
a.ShippingCity AS 'Shipping City',
a.ShippingState AS 'Shipping State',
a.ShippingPostalCode AS 'Shipping Postal Code',
a.ShippingCountry AS 'Shipping Country',
a.Phone,
a.Website,
a.SIC,
a.Industry,
a.AnnualRevenue AS 'Annual Revenue',
a.NumberOfEmployees AS 'Number of Employees',
a.Master_Account_Number__c AS 'Master Account Number',
a.Domain__c AS Domain,
a.Buying_Phase__c AS 'Buying Phase',
a.Territory__c AS Territory,
a.Least_Common_Denominator__c AS 'Least Common Denominator',
a.Activity_Count__c AS 'Activity Count',
a.Named_Account_Active_Date__c AS 'Named Account Active Date',
a.Id,
a.MasterRecordId AS 'Master Record Id',
rt.Name AS 'Record Type',
a.ParentId AS 'Parent Id',
CONCAT(u.FIRST_NAME,' ',u.LAST_NAME) AS 'Owner Name',
ur.Name as 'Owner Role',
a.CREATED_DATE AS 'Created Date',
CONCAT(cb.FIRST_NAME,' ',cb.LAST_NAME) AS 'Created By Name',
a.LastModifiedDate AS 'Last Modified Date',
CONCAT(lm.FIRST_NAME,' ',lm.LAST_NAME) AS 'Last Modified By Name',
a.LastActivityDate AS 'Last Activity Date',
a.Fortune_1000__c AS 'Fortune 1000',
a.Fortune_1000_Rank__c AS 'Fortune 1000 Rank',
a.Account_Type__c AS 'Account Type',
a.Strategic_Beachhead__c as 'Strategic Beachhead',
a.Account_To_Be_Assigned__c as 'Account To Be Assigned',
a.Reseller_Renewal_Discount_Percentage__c AS 'Reseller Renewal Discount Percentage',
a.Reseller_Effective_Date__c AS 'Reseller Effective Date',
CONCAT(cs.FIRST_NAME,' ',cs.LAST_NAME) AS 'Customer Success'
FROM SFDC.PUBLIC.account a
LEFT JOIN SFDC.PUBLIC.user u ON a.OWNER_ID=u.Id
LEFT JOIN SFDC.PUBLIC.user_role ur ON u.UserRoleId = ur.Id
LEFT JOIN SFDC.PUBLIC.record_type rt ON a.RecordTypeId=rt.Id 
LEFT JOIN SFDC.PUBLIC.user cb ON a.CreatedById=cb.Id
LEFT JOIN SFDC.PUBLIC.user lm ON a.LastModifiedById=lm.Id
LEFT JOIN SFDC.PUBLIC.user cs ON cs.Id = a.Customer_Success__c
;