

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-queryHistory.csv");

-- Select all query history from the past two months
SELECT *
FROM leadflow.arc_marketo_query_history
WHERE startTime >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 2 MONTH);

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-queryHistory.csv");
