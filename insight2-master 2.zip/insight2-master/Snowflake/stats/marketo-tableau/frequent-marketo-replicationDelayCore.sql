

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-replicationDelayCore.csv");

-- Select all lead activities from the past three months
SELECT *
FROM MAIN.ARC.insightHealth;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-replicationDelayCore.csv");
