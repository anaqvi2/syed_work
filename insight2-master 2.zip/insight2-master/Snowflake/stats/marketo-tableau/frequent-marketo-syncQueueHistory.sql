

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG ("Marketo Tableau Hourly", "marketo-syncQueueHistory.csv");

-- Log current state of the Marketo sync queue
INSERT INTO leadflow.arc_marketo_upload_sync_history
    SELECT CURRENT_TIMESTAMP(), "marketoLeadsUploadCondeep.sql", muf.priority, COUNT(mu.userID)
    FROM leadflow.arc_marketo_upload_flags muf
        LEFT OUTER JOIN leadflow.arc_marketo_upload mu ON muf.priority = mu.pushToMarketo
    WHERE muf.priority != 0
    GROUP BY muf.priority
    ORDER BY muf.priority DESC
;

-- Select all sync queue history from the past three months
SELECT * FROM leadflow.arc_marketo_upload_sync_history
WHERE insertDateTime >= DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 3 MONTH)
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG ("Marketo Tableau Hourly", "marketo-syncQueueHistory.csv");