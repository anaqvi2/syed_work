

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-bulletinReceivedRollup.csv");

-- Get all users who have disabled bulletins in the app
DROP TABLE IF EXISTS rpt_main_02.stg_bulletinUnsubscribeUsers;
CREATE TABLE IF NOT EXISTS rpt_main_02.stg_bulletinUnsubscribeUsers
(PRIMARY KEY (userID))
    SELECT
        ucs.userID,
        our.organizationID
    FROM ss_account_02.userConfigSetting ucs
        LEFT JOIN ss_core_02.organizationUserRole our ON ucs.userID = our.userID AND our.role = "MEMBER" AND our.state = 1
    WHERE ucs.configPropertyID = 1300
    UNION
    SELECT
        our.userID,
        ocs.organizationID
    FROM ss_account_02.orgConfigSetting ocs
        JOIN ss_core_02.organizationUserRole our
            ON ocs.organizationID = our.organizationID AND our.role = "MEMBER" AND our.state = 1
    WHERE ocs.configPropertyID = 1300
;

-- Get number of users who have logged in since Bulletins launched
SELECT COUNT(*) INTO @numUsersLoggedInSinceBulletinLaunch
FROM leadflow.arc_marketo_upload
WHERE lastLogin >= '2016-06-22' -- Bulletin feature launch date
;

-- Get counts by number of bulletins received
SELECT
    bulletins,
    CASE WHEN bulletins > 0 THEN COUNT(userID) ELSE @numUsersLoggedInSinceBulletinLaunch END users,
    SUM(opens) opens,
    SUM(closes) closes,
    SUM(clicks) clicks,
    SUM(unsubscribes) unsubscribes
FROM (
         SELECT
             userID,
             COUNT(bulletinID) bulletins,
             SUM(isOpen) opens,
             SUM(isClose) closes,
             SUM(isClick) clicks,
             SUM(isUnsubscribe) unsubscribes
         FROM (
                  SELECT
                      bu.userID,
                      bu.bulletinID,
                      IFNULL(SUM(ce.actionID = 1 AND ce.objectID = 10717) > 0, 0)  isOpen,
                      IFNULL(SUM(ce.actionID = 2 AND ce.objectID = 10717) > 0, 0)  isClose,
                      IFNULL(SUM(ce.actionID = 22 AND ce.objectID = 10718) > 0, 0) isClick,
                      IFNULL(SUM(
                                 CASE
                                 WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1
                                     THEN 0
                                 WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0
                                     THEN 1
                                 WHEN ucs.valueBoolean = 1
                                     THEN 0
                                 WHEN ucs.valueBoolean = 0
                                     THEN 1
                                 WHEN ocs.valueBoolean = 0
                                     THEN 1
                                 ELSE 0
                                 END) > 0, 0)                          isUnsubscribe
                  FROM ss_account_02.bulletinUser bu
                      JOIN ss_account_02.bulletin b ON bu.bulletinID = b.bulletinID
                      LEFT JOIN MAIN.ARC.clientEventBulletin ce ON bu.userID = ce.insertByUserID AND bu.bulletinID = ce.parm1Int
                      LEFT JOIN rpt_main_02.stg_bulletinUnsubscribeUsers buu ON bu.userID = buu.userID
                      LEFT JOIN ss_account_02.orgConfigSetting ocs ON buu.organizationID = ocs.organizationID
                                                                   AND ocs.configPropertyID = 1300
                                                                   AND ocs.insertDateTime BETWEEN
                                                                       b.startDateTime AND b.endDateTime
                      LEFT JOIN ss_account_02.userConfigSetting ucs ON buu.userID = ucs.userID
                                                                    AND ucs.configPropertyID = 1300
                                                                    AND ucs.insertDateTime BETWEEN
                                                                        b.startDateTime AND b.endDateTime
                  WHERE bu.userID NOT IN (SELECT userID FROM leadflow.arc_marketo_lead_lists WHERE listID = 111557) -- Ignore Marketo seed list users
                  GROUP BY bu.userID, bu.bulletinID

                  UNION

                  SELECT
                      buu.userID,
                      NULL,
                      0,
                      0,
                      0,
                      IFNULL(SUM(
                                 CASE
                                 WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 1
                                     THEN 0
                                 WHEN ocs.isFinal = 1 AND ocs.valueBoolean = 0
                                     THEN 1
                                 WHEN ucs.valueBoolean = 1
                                     THEN 0
                                 WHEN ucs.valueBoolean = 0
                                     THEN 1
                                 WHEN ocs.valueBoolean = 0
                                     THEN 1
                                 ELSE 0
                                 END), 0)                          isUnsubscribe
                  FROM rpt_main_02.stg_bulletinUnsubscribeUsers buu
                      LEFT JOIN ss_account_02.orgConfigSetting ocs ON buu.organizationID = ocs.organizationID
                                                                   AND ocs.configPropertyID = 1300
                      LEFT JOIN ss_account_02.userConfigSetting ucs ON buu.userID = ucs.userID
                                                                    AND ucs.configPropertyID = 1300
                      LEFT JOIN ss_account_02.bulletinUser bu ON buu.userID = bu.userID
                  WHERE bu.userID IS NULL
                  GROUP BY buu.userID
              ) bulletinUserActivity
         GROUP BY bulletinUserActivity.userID
     ) bulletinCountUserActivity
GROUP BY bulletinCountUserActivity.bulletins
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-bulletinReceivedRollup.csv");
