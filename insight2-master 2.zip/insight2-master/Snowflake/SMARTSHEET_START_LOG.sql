"SMARTSHEET_START_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_START_LOG`( in buildSource varchar(100), IN buildStep VARCHAR(250) )
BEGIN
DECLARE bID INT;
DECLARE bS INT;
DECLARE startTime DATETIME;
SELECT MAX(buildSequence) INTO bS FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE();
IF bS IS NULL 
THEN SET bS = 0;
ELSE SET bS = (SELECT MAX(buildSequence) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;
SELECT MAX(buildID) INTO bID FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE();
IF bID IS NULL
THEN SET bID = (SELECT MAX(buildID)+1 FROM leadflow.arc_marketo_query_history);
ELSE SET bID = (SELECT MAX(buildID) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, ""%Y-%m-%d"") = CURRENT_DATE() );
END IF
;
SET bS = bS+1;
SET startTime = NOW();
INSERT INTO leadflow.arc_marketo_query_history (buildID, buildSequence, buildSource, buildStep, startTime)
SELECT bID, bS, buildSource, buildStep, startTime;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"

"SMARTSHEET_STOP_LOG","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_STOP_LOG`( IN buildSource VARCHAR(100), IN buildStep VARCHAR(250) )
BEGIN
DECLARE endTime DATETIME;
DECLARE buildSequence INT;
SET endTime = NOW();
SET buildSequence = (SELECT MAX(mqh.buildSequence) FROM leadflow.arc_marketo_query_history mqh 
WHERE mqh.buildStep = buildStep and mqh.buildSource = buildSource AND DATE_FORMAT(mqh.startTime, ""%Y-%m-%d"") = CURRENT_DATE());
UPDATE leadflow.arc_marketo_query_history arc
SET
    arc.timeElapsed = TIME_TO_SEC(TIMEDIFF(endTime, startTime)),
    arc.endTime = endTime
WHERE
    arc.buildStep = buildStep
    and arc.buildSource = buildSource
    and arc.buildSequence = buildSequence
    AND DATE_FORMAT(arc.startTime, ""%Y-%m-%d"") = CURRENT_DATE()
;
END","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
