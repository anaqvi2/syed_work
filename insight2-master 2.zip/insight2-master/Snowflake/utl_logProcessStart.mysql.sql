"utl_logProcessStart","NO_ENGINE_SUBSTITUTION","CREATE DEFINER=`pjalalian`@`%` PROCEDURE `utl_logProcessStart`(in a_processName varchar(50)
						 ,in a_parentProcessId int
                         ,in a_processText varchar(2000)
						 ,in a_logLevel varchar(10)
						 ,in a_levelCtrlNum varchar(10)  
                         ,out a_processId int								
						 )
begin

declare v_logLevelNum tinyint;
declare v_parentProcessName varchar(50);

select logLevelNum
into v_logLevelNum 
from utl_logLevel 
where logLevel = a_logLevel;

select processName
into v_parentProcessName
from utl_processLog
where processId = a_parentProcessId;

if v_logLevelNum is null
then 
   select 'WARNING: LOGLEVEL IS INVALID' from dual; 
elseif v_logLevelNum <= a_levelCtrlNum   
then
insert into utl_processLog values
( a_processId
 ,a_processName
 ,a_parentProcessId
 ,v_parentProcessName
 ,a_logLevel
 ,now()
 ,null
 ,null
 ,a_processText
);
end if;

SELECT LAST_INSERT_ID() into a_processId;

end","utf8","utf8_general_ci","utf8mb4_unicode_520_ci"
