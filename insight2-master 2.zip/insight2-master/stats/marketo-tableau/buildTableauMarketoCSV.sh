
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/marketo-tableau

# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
PERIOD=$2
#LOG_FILE=${STATS_HOME}/logs/buildCSV_${LOG_DATE}.log
#exec > $LOG_FILE 2>&1

DB_SERVER=127.0.0.1
DB_NAME=leadflow

# die gracefully if it's Saturday or Sunday
# dow=`date +"%A"`
# if [ $dow = "Saturday" ] || [ $dow = "Sunday" ]
#then
#	echo "it's the weekend, exiting without working."
#	exit 0
#fi

# Remove any previous reports
rm -f ${STATS_OUTPUT}/*

. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_HOME}/reportFuncsMarketo.sh

for SQL_FILE in `ls -r ${STATS_QUERY}/${PERIOD}-marketo*.sql`
do
  echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
  cat ${SQL_FILE}
  outputReport ${SQL_FILE} ${DB_SERVER} ${DB_NAME} ${DB_USER} ${DB_PWD}
  echo ""
done



# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

zipReports marketo-*.csv marketo-tableau-${PERIOD}-${LOG_DATE}.tar.gz

# actually show the results in Jenkins console
#cat ${LOG_FILE}
