SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Daily", "marketo-leadActivities.csv");

-- Select all lead activities from the past three months
SELECT
    marketoGUID,
    id,
    leadId                  AS 'Lead ID',
    activityDateTime        AS 'Activity Date',
    activityTypeId          AS 'Activity Type ID',
    primaryAttributeValueId AS 'Primary Attribute ID',
    primaryAttributeValue   AS 'Primary Attribute',
    mailingId               AS 'Mailing ID',
    choiceNumber            AS 'Choice',
    device                  AS 'Device',
    isMobileDevice          AS 'Is Mobile',
    platform                AS 'Platform',
    stepId                  AS 'Step ID',
    testVariant             AS 'Test Variant',
    userAgent               AS 'User Agent',
    category                AS 'Category',
    details                 AS 'Details',
    email                   AS 'Email',
    subcategory             AS 'Subcategory',
    clientIpAddress         AS 'Client IP',
    formFields              AS 'Form Fields',
    queryParameters         AS 'Query Parameters',
    referrerUrl             AS 'Referrer URL',
    webformId               AS 'Webform ID',
    webpageId               AS 'Webpage ID',
    link                    AS 'Link',
    linkId                  AS 'Link ID',
    type                    AS 'Type',
    date                    AS 'Date',
    description             AS 'Description',
    source                  AS 'Source',
    friendLeadId            AS 'Friend Lead ID',
    searchEngine            AS 'Search Engine',
    searchQuery             AS 'Search Query',
    webpageUrl              AS 'Webpage URL'
FROM leadflow.arc_marketo_lead_activity
WHERE
    activityDateTime >= DATE_SUB(NOW(), INTERVAL 90 DAY)
-- ORDER BY activityDateTime DESC
;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Daily", "marketo-leadActivities.csv");
