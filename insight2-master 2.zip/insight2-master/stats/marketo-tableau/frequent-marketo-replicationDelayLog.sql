SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

-- Start Logging
CALL leadflow.SMARTSHEET_START_LOG("Marketo Tableau Hourly", "marketo-replicationDelayLog.csv");

-- Select all lead activities from the past three months
SELECT *
FROM rpt_main_02.arc_insightHealthLog;

-- Stop Logging
CALL leadflow.SMARTSHEET_STOP_LOG("Marketo Tableau Hourly", "marketo-replicationDelayLog.csv");
