-- https://opscon.smartsheet.com/b/oc#/ops-tools/bulletins

-- Add bulletin data to the bulletin table
INSERT IGNORE INTO rpt_main_02.arc_bulletin
(`bulletinID`, `status`, `type`, `target`, `userIdListFileName`, `description`, `startDateTime`, `endDateTime`, `backgroundColor`)
VALUES
(1000041, 1, 1, 1, '2016-10-20-BLT0021-ent-sys-admin-list-with-seed.csv', 'BLT0021 - Hosting Provider Notification to 2.6k', '2016-10-21 18:00', '2016-10-29 00:00', '#fffe2'),
(1000042, 1, 2, 1, '2016-10-26 BLT0020 - active-collabs-with-seed.csv', 'BLT0020A - Out Domain Upgrade to Paid - More Active - v2', '2016-10-26 23:02', '2016-11-03 00:00', '#c5e4af'),
(1000043, 1, 2, 1, '2016-10-25-BLT0022-delta-users-with-seed.csv', 'BLT0022 - On-Site Training at Delta', '2016-10-26 00:00', '2016-11-01 00:00', '#c5e4af'),
(1000044, 1, 1, 2, NULL,'r47 Venus LDR Maintenance Message','2016-11-04 21:00:00','2016-11-04 22:48:52',NULL),
(1000045, 1, 1, 2, NULL,'r47 Venus LDR Maintenance Message','2016-11-04 22:46:16','2016-11-13 01:00:31',NULL),
(1000051, 1, 2, 1, 'Seed-List.csv', 'BLT0028 - Internal Test of Bulletin with no link', '2016-11-18 23:30:00', '2016-11-19 01:00:00', '#c5e4af'),
(1000046, 1, 2, 1, 'BLT0023_2016-11-12_venus-sights-bulletin-with-seed-list.csv', 'BLT0023 - Venus Release to Sights Users', '2016-11-14 17:50:00', '2016-11-22 01:00:00', '#c5e4af'),
(1000048, 1, 2, 1, 'BLT0026B_2016-11-14_less-engaged-collabs_with-seed.csv', 'BLT0026B - Less Engaged Collabs ~40k - Challenger', '2016-11-14 23:00:00', '2016-11-23 01:00:00', '#c5e4af'),
(1000047, 1, 2, 1, 'BLT0026A_2016-11-14_less-engaged-collabs_with-seed.csv', 'BLT0026A - Less Engaged Collabs ~40k - Champion','2016-11-14 23:00:00','2016-11-23 01:00:00', '#c5e4af'),
(1000049, 1, 2, 1, 'BLT0030_2016-11-16_stanford-users_with-seed.csv', 'BLT0030 - Stanford Security Notification', '2016-11-16 22:00:00', '2017-04-01 01:00:00', '#ffffe2'),
(1000054, 1, 2, 1, 'In_App_Bulletins_BLT0031___Export_List_inc_non-English_with_Seed.csv', 'BLT0031 - Genentech & Roche Coffee Hour', DATE_ADD('2016-11-22 16:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-31 17:00:00', INTERVAL 8 HOUR), '#ffffe2'),
(1000053, 1, 2, 1, 'BLT0028B_2016-11-28_trialers-no-share-with-seed.csv', 'BLT0028B - Trialers not shared to 45k - No Link - 40%', DATE_ADD('2016-11-28 15:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-05 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000052, 1, 2, 1, 'BLT0028A_2016-11-28_trialers-no-share-with-seed.csv', 'BLT0028A - Trialers not shared to 45k - CTA Link - 40%', DATE_ADD('2016-11-28 15:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-05 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000056, 1, 2, 1, 'BLT0032_2016-11-28_whirlpool-survey-with-seed.csv', 'BLT0032 - Whirlpool Survey', DATE_ADD('2016-11-28 17:10:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-23 17:00:00', INTERVAL 8 HOUR), '#f8dbb1'),
(1000055, 1, 1, 2, NULL , 'DC Flip Maintenance Message', DATE_ADD('2016-11-28 00:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-10 17:01:00', INTERVAL 8 HOUR), NULL),
(1000058, 1, 2, 1, '2016-12-02_BLT0025_team-basic-users-with-seed.csv', 'BLT0025 - Business Upsell to Users - 50k', DATE_ADD('2016-12-02 16:30:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-16 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000059, 1, 2, 1, '2016-12-02_BLT0024_team-basic-admins-with-seed.csv', 'BLT0024 - Business Upsell to Admins - 31k', DATE_ADD('2016-12-02 16:30:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-16 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000061, 1, 2, 1, 'BLT0029C_2016-12-06_emphasis-on-promo-with-seed.csv', 'BLT0029C - Community Promotion - All Community - 10%', DATE_ADD('2016-12-06 15:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-15 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000060, 1, 2, 1, 'BLT0029B_2016-12-06_emphasis-on-promo-with-seed.csv', 'BLT0029B - Community Promotion - More Community - 10%', DATE_ADD('2016-12-06 15:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-15 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000050, 1, 2, 1, 'BLT0029A_2016-12-06_emphasis-on-promo-with-seed.csv', 'BLT0029A - Community Promotion - More Promo - 10%', DATE_ADD('2016-12-06 15:00:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-15 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000062, 1, 2, 1, '2016-12-14_BLT0036_non-community-users-with-seed.csv', 'BLT0036 - Community Promotion Remainder', DATE_ADD('2016-12-14 16:30:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-21 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000063, 1, 2, 1, '2016-12-14_BLT0035A_trialers-with-seed.csv', 'BLT0035A - Trialers not shared to 20k - CTA Link - 40%', DATE_ADD('2016-12-14 16:45:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-23 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000064, 1, 2, 1, '2016-12-14_BLT0035B_trialers-with-seed.csv', 'BLT0035B - Trialers not shared to 20k - No Link - 40%', DATE_ADD('2016-12-14 16:45:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-23 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000065, 1, 2, 1, '2016-12-15_BLT0027A_out-domain-collabs-with-seed.csv', 'BLT0027A - Out Domain Collab Upgrade to Paid - Active', DATE_ADD('2016-12-15 16:50:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-23 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000066, 1, 2, 1, '2016-12-15_BLT0037_out-domain-collabs-with-seed.csv', 'BLT0037 - Out Domain Collab Upgrade to Paid - Active with Prev Lists', DATE_ADD('2016-12-15 16:45:00', INTERVAL 8 HOUR), DATE_ADD('2016-12-23 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000068, 1, 2, 1, 'BLT0040A-2017-01-18-teams-with-seed.csv', 'BLT0040A - Antelope Release - Teams', DATE_ADD('2017-01-18 12:30:00', INTERVAL 8 HOUR), DATE_ADD('2017-01-25 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000069, 1, 2, 1, 'BLT0040B-2017-01-18-non-team-45-day-actives-with-seed.csv', 'BLT0040B - Antelope Release - Non-Team 45-Day Actives', DATE_ADD('2017-01-18 13:15:00', INTERVAL 8 HOUR), DATE_ADD('2017-01-25 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000070, 1, 2, 1, 'BLT0040C-2017-01-18-non-team-45-90-day-actives-with-seed.csv', 'BLT0040C - Antelope Release - Non-Team 45-90-Day Actives', DATE_ADD('2017-01-18 14:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-01-25 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),

(1000079, 1, 2, 1, 'BLT0042A_2017-02-16_export-list-with-seed.csv', 'BLT0042A - Out-Domain Collabs - Upgrade - 50%', DATE_ADD('2017-02-16 17:25:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-07 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000080, 1, 2, 1, 'BLT0042B_2017-02-16_export-list-with-seed.csv', 'BLT0042B - Out-Domain Collabs - Upgrade - 50%', DATE_ADD('2017-02-16 17:25:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-07 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000077, 1, 2, 1, 'BLT0039A_2017-02-16_export-list-with-seed.csv', 'BLT0039A - In-Domain Collabs - No Sharing - 40%', DATE_ADD('2017-02-16 17:15:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-07 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000078, 1, 2, 1, 'BLT0039B_2017-02-16_export-list-with-seed.csv', 'BLT0039B - In-Domain Collabs - No Sharing - 40%', DATE_ADD('2017-02-16 17:15:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-07 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),

(1000074, 1, 2, 1, 'BLT0043_2017-02-17_azure-auth-mobile-bulletin-with-seed.csv', 'BLT0043 - New Azure Auth Mobile Login', DATE_ADD('2017-02-17 14:40:00', INTERVAL 8 HOUR), DATE_ADD('2017-02-24 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),

(1000081, 1, 2, 1, 'BLT0045_adidas-list-with-seed.csv', 'BLT0045 - adidas Smartsheet Challenge', DATE_ADD('2017-02-26 10:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-04 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000086, 1, 2, 1, 'BLT0046_2017-03-03_adidas-user-list_with-seed.csv', 'BLT0046 - adidas Smartsheet Challenge 2', DATE_ADD('2017-03-05 10:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-11 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000082, 1, 2, 1, 'BLT0038A_2017-03-02_blog-list-a_with-seed.csv', 'BLT0038A - Subscribe to the Blog - 25%', DATE_ADD('2017-03-03 16:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-10 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000083, 1, 2, 1, 'BLT0038B_2017-03-02_blog-list-b_with-seed.csv', 'BLT0038B - Subscribe to the Blog - 25%', DATE_ADD('2017-03-03 16:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-10 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000084, 1, 2, 1, 'BLT0038C_2017-03-02_blog-list-c_with-seed.csv', 'BLT0038C - Subscribe to the Blog - 25%', DATE_ADD('2017-03-03 16:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-10 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000085, 1, 2, 1, 'BLT0038D_2017-03-02_blog-list-d_with-seed.csv', 'BLT0038D - Subscribe to the Blog - 25%', DATE_ADD('2017-03-03 16:00:00', INTERVAL 8 HOUR), DATE_ADD('2017-03-10 17:00:00', INTERVAL 8 HOUR), '#c5e4af'),
(1000087, 1, 2, 1, 'BLT0047_2017-03-09_GE-users-with-seed.csv', 'BLT0047 - GE Training', DATE_ADD('2017-03-09 16:15:00', INTERVAL 8 HOUR), DATE_ADD('2017-04-06 17:00:00', INTERVAL 8 HOUR), '#aec3f2')
;

-- Add the list of userIDs to the bulletinUser table
LOAD DATA LOCAL INFILE 'C:/Users/jmarzinke/Google Drive/Bulletin User Lists/BLT0047_2017-03-09_GE-users-with-seed.csv'
INTO TABLE rpt_main_02.arc_bulletinUser
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(bulletinID, userID)
;

-- Test that everything looks right
SELECT
    b.bulletinID,
    b.userIDListFileName,
    b.description,
    b.startDateTime,
    b.endDateTime,
    COUNT(bu.userID)
FROM rpt_main_02.arc_bulletin b
    JOIN rpt_main_02.arc_bulletinUser bu ON b.bulletinID = bu.bulletinID
GROUP BY b.bulletinID
ORDER BY b.bulletinID DESC
;

-- update rpt_main_02.arc_bulletinUser
-- set bulletinID = 1000027
-- where bulletinID = 1000030
-- ;

-- select * from rpt_main_02.arc_bulletinUser_copy
-- where bulletinID = 1000030
-- limit 100000
-- ;

-- select count(*) from rpt_main_02.arc_clientEventBulletin
-- where parm1Int = 1000026
-- ;