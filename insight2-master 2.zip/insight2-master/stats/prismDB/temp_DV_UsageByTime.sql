-- Usage by Time (Post Jul 1)
		-- +++++ NEED TO MOVE THIS TO A TABLE AND QUERY FROM THERE ++++++
SELECT DATE_FORMAT(DATE_ADD(CE.eventDateTime,INTERVAL -8 HOUR), '%H') AS InsertHour, 
	COUNT(DISTINCT UT.mainContactUserID) AS DistinctUsers, 
	COUNT(DISTINCT CE.clientEventID) AS NumEvents 
	FROM rpt_main_02.arc_clientEvent CE
	INNER JOIN rpt_main_02.rpt_sessionLog SS
		ON SS.sessionLogID = CE.sessionLogID AND SS.SessionLogID > 84434113
	INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
		ON SS.userID = UT.mainContactUserID 
	WHERE UT.masterDomain = @domain
	AND CE.clientEventID> 5765262659
	AND UT.currentProductGroup NOT IN ('Trial','External Collaborator')
	GROUP BY 1;