-- Sheets Viewed
SELECT OpenMonth, OpenDate, SheetCategory, SUM(NumSheetsViewed)  AS Counts
FROM rpt_workspace.rArunk_OrgDB_SheetsViewedCategory SV 
WHERE masterDomain=@domain 
AND SV.SheetCategory != "Reports"
GROUP BY 1,2,3
ORDER BY 1
LIMIT 123456789;