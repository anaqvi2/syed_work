/* **** MAP VIEW **** */
-- Geo Distribution
SELECT UT.ipCountry, UT.ipRegion, UT.ipCity, 
	CASE 
	WHEN UT.currentProductGroup LIKE '%Collab%' THEN UT.currentProductGroup 
	WHEN UT.currentProductGroup LIKE '%Trial%' THEN UT.currentProductGroup
	ELSE "Licensed User" END AS currentProductGroup,
	COUNT(DISTINCT UT.mainContactUserID) AS NumUsers 
FROM rpt_workspace.rArunk_OrgDB_UserTable UT
WHERE UT.currentproductGroup NOT IN ('External Collaborator') 
AND UT.masterDomain = @domain
GROUP BY UT.ipCountry, UT.ipRegion, UT.ipCity, UT.currentProductGroup
ORDER BY NumUsers DESC
LIMIT 123456789
;
/* **** END MAP VIEW **** */