-- Licensed Users Chart (Area Chart)

SELECT 

	CASE WHEN UT.StartDate<'2013-01-01' THEN '2012-12' ELSE DATE_FORMAT(UT.StartDate,'%Y-%m') END AS StartMonth, 
	
	CASE WHEN UT.StartDate<'2013-01-01' THEN '2012-12-31' ELSE UT.StartDate END AS StartDate, 
	
	CASE WHEN UT.currentProductGroup LIKE '%Collab%' THEN UT.currentProductGroup 
	WHEN UT.currentProductGroup LIKE '%Trial%' THEN UT.currentProductGroup
	ELSE "Licensed User" END AS currentProductGroup,
	
	COUNT(UT.mainContactUserID) AS NumUsers  
FROM rpt_workspace.rArunk_OrgDB_UserTable UT
WHERE UT.masterDomain = @domain
AND UT.currentProductGroup is not null
GROUP BY 2,3
ORDER BY 1 ASC
LIMIT 1234567;