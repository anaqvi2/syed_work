/* ---- **** Dashboard View **** ---- */

-- Feature Usage 
		SET @TotUsers := (SELECT COUNT(DISTINCT(UT.mainContactUserID))NumUsers 
				FROM rpt_workspace.rArunk_OrgDB_UserTable UT WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%'
				AND UT.currentProductGroup NOT LIKE '%trial%'
				);

		-- Total Licensed Users
			SELECT  "Total Licensed Users", COUNT(DISTINCT(UT.mainContactUserID))NumUsers, COUNT(DISTINCT(UT.mainContactUserID))/ @TotUsers AS PCT_LicensedUsers, 1 AS Median
			FROM rpt_workspace.rArunk_OrgDB_UserTable UT
			WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%'
			AND UT.currentProductGroup NOT LIKE '%trial%'

			UNION
		-- Sheets Created
			SELECT "Sheets Created" ,COUNT(DISTINCT ST.ownerPaymentProfileID)AS NumUsers, COUNT(DISTINCT ST.ownerPaymentProfileID)/ @TotUsers AS PCT, 0.7062 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
			WHERE ST.masterDomain = @domain AND ST.containerType=2
			UNION 
		-- Reports Created
			SELECT "Reports Created" ,COUNT(DISTINCT ST.ownerPaymentProfileID) AS NumUsers, COUNT(DISTINCT ST.ownerPaymentProfileID)/@TotUsers AS PCT, 0.0998 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
			WHERE ST.masterDomain = @domain AND ST.containerType=3

			UNION
		-- Sheet Imports 
			SELECT "Sheet Imports" ,COUNT(DISTINCT ST.ownerPaymentProfileID) AS NumUsers, COUNT(DISTINCT ST.ownerPaymentProfileID) / @TotUsers AS PCT, 0.2702 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
			INNER JOIN rpt_main_02.container C
				ON C.containerID = ST.containerID AND C.containerType=2 AND C.sourceID IS NULL
			WHERE ST.masterDomain = @domain AND ST.containerType=2

			UNION 
		-- Sharing 
			SELECT  "Sharing", COUNT(DISTINCT(GAM.insertByUserID))NumUsers, COUNT(DISTINCT(GAM.insertByUserID))/ @TotUsers AS PCT, 0.775 AS Median
			FROM rpt_main_02.gridAccessMap GAM
			 INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = GAM.insertByUserID 
			WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%'
			AND UT.currentProductGroup NOT LIKE '%trial%'
			UNION			
		-- Discussions
			SELECT  "Discussions Created", COUNT(DISTINCT(D.insertByUserID))NumUsers, COUNT(DISTINCT(D.insertByUserID))/@TotUsers AS PCT, 0.4738 AS Median
			FROM rpt_main_02.discussion D
			 INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = D.insertByUserID 
			WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%'
			AND UT.currentProductGroup NOT LIKE '%trial%'
			UNION 
		-- Attachments
			SELECT  "AttachmentsAdded", COUNT(DISTINCT(DA.insertByUserID))NumUsers, COUNT(DISTINCT(DA.insertByUserID))/@TotUsers AS PCT, 0.5519 AS Median
			FROM rpt_main_02.docAttachment DA
			 INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = DA.insertByUserID 
			WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%'
			AND UT.currentProductGroup NOT LIKE '%trial%'
			UNION
		-- Alerts 
			SELECT "Alerts", COUNT(DISTINCT SFT.insertByUserID) NumUsers , COUNT(DISTINCT SFT.insertByUserID)/@TotUsers AS PCT, 0.1287 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = SFT.insertByUserID AND UT.currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE SFT.masterDomain= @domain AND SFT.FeatureType = 'Alerts'

			UNION 
		-- Notifications 
			SELECT "Notifications", COUNT(DISTINCT SFT.insertByUserID) NumUsers , COUNT(DISTINCT SFT.insertByUserID)/@TotUsers AS PCT, 0.3603 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = SFT.insertByUserID AND UT.currentProductGroup NOT LIKE '%collab%'
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE SFT.masterDomain= @domain AND SFT.FeatureType = 'Notifications'

			UNION 
		-- Web Forms
			SELECT "Web Forms", COUNT(DISTINCT SFT.insertByUserID) NumUsers , COUNT(DISTINCT SFT.insertByUserID)/@TotUsers AS PCT, 0.111 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = SFT.insertByUserID AND UT.currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE SFT.masterDomain= @domain AND SFT.FeatureType = 'Web Forms'

			UNION 
		-- Update Requests
			SELECT "Update Requests", COUNT(DISTINCT SFT.insertByUserID) NumUsers , COUNT(DISTINCT SFT.insertByUserID)/@TotUsers AS PCT, 0.16 AS Median
			FROM rpt_workspace.rArunk_OrgDB_SpecialFeaturesTable SFT
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = SFT.insertByUserID AND UT.currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE SFT.masterDomain= @domain AND SFT.FeatureType = 'Update Requests'
			
UNION
			
	SELECT "Row Hierarchy", COUNT(DISTINCT(B.insertByUserID)), COUNT(DISTINCT(B.insertByUserID))/@TotUsers AS PCT, 0.4774 AS Median
	FROM rpt_workspace.cDunn_prismClientEvents B
	JOIN rpt_workspace.rArunk_OrgDB_UserTable UT ON UT.mainContactUserID = B.insertByUserID AND currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE B.objectID IN(5005,5006) AND UT.masterDomain = @domain
			
UNION
			
SELECT "Conditional Formatting", COUNT(DISTINCT(B.insertByUserID)), COUNT(DISTINCT(B.insertByUserID))/@TotUsers AS PCT, 0.4774 AS Median
	FROM rpt_workspace.cDunn_prismClientEvents B
	JOIN rpt_workspace.rArunk_OrgDB_UserTable UT ON UT.mainContactUserID = B.insertByUserID AND currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE B.objectID IN(7088,12100) AND UT.masterDomain = @domain
			
UNION		
			
SELECT "Gantt View", COUNT(DISTINCT(B.insertByUserID)), COUNT(DISTINCT(B.insertByUserID))/@TotUsers AS PCT, 0.4774 AS Median
	FROM rpt_workspace.cDunn_prismClientEvents B
	JOIN rpt_workspace.rArunk_OrgDB_UserTable UT ON UT.mainContactUserID = B.insertByUserID AND currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE B.objectID IN(5050) AND UT.masterDomain = @domain
			
UNION

SELECT "View History", COUNT(DISTINCT(B.insertByUserID)), COUNT(DISTINCT(B.insertByUserID))/@TotUsers AS PCT, 0.4774 AS Median
	FROM rpt_workspace.cDunn_prismClientEvents B
	JOIN rpt_workspace.rArunk_OrgDB_UserTable UT ON UT.mainContactUserID = B.insertByUserID AND currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE B.objectID IN(10207) AND UT.masterDomain = @domain

			/* UNION 
		-- Row Hierarchy
			SELECT "Row Hierarchy", COUNT(DISTINCT CE.insertByUserID), COUNT(DISTINCT CE.insertByUserID)/@TotUsers AS PCT, 0.4774 as Median
			FROM rpt_main_02.arc_clientEventRollup CE
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = CE.insertByUserID AND currentProductGroup NOT LIKE '%collab%' 
				AND UT.currentProductGroup NOT LIKE '%trial%'
			WHERE CE.objectID IN(5005, 5006) AND UT.masterDomain = @domain

			UNION
		-- Conditional Formatting
			SELECT "Conditional Formatting", COUNT(DISTINCT ER.insertByUserID), COUNT(DISTINCT ER.insertByUserID)/@TotUsers AS PCT, 0.312 AS Median
			FROM rpt_main_02.arc_clientEventRollup ER
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = ER.insertByUserID 
			WHERE ER.objectID IN(7088,12100) AND UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%' 
			AND UT.currentProductGroup NOT LIKE '%trial%'

			UNION
		-- Gantt View
			SELECT "Gantt View", COUNT(DISTINCT ER.insertByUserID), COUNT(DISTINCT ER.insertByUserID)/@TotUsers AS PCT, 0.6712 as Median
			FROM rpt_main_02.arc_clientEventRollup ER
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = ER.insertByUserID 
			WHERE ER.objectID IN(5050) AND UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%' 
			AND UT.currentProductGroup NOT LIKE '%trial%'

			UNION 
		-- View History
			SELECT "View History", COUNT(DISTINCT ER.insertByUserID), COUNT(DISTINCT ER.insertByUserID)/@TotUsers AS PCT, 0.1222 as Median
			FROM rpt_main_02.arc_clientEventRollup ER
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = ER.insertByUserID 
			WHERE ER.objectID IN(10207) AND UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%' 
			AND UT.currentProductGroup NOT LIKE '%trial%' */

			UNION
		-- Mobile Usage
			SELECT "Mobile Usage", COUNT(DISTINCT DT.mainContactUserID), COUNT(DISTINCT DT.mainContactUserID)/@TotUsers AS PCT, 0.1 AS Median
			FROM rpt_workspace.rArunk_OrgDB_UserDevicesTable DT
			INNER JOIN rpt_workspace.rArunk_OrgDB_UserTable UT
				ON UT.mainContactUserID = DT.mainContactUserID 
			WHERE UT.masterDomain = @domain AND UT.currentProductGroup NOT LIKE '%collab%' 
			AND UT.currentProductGroup NOT LIKE '%trial%'
			AND DT.device !='Computer'
	;



/* **** END DASHBOARD VIEW **** */