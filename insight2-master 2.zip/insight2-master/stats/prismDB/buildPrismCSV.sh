
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/prismDB


# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
#LOG_FILE=${STATS_HOME}/logs/buildCSV_${LOG_DATE}.log
#exec > $LOG_FILE 2>&1

# Set Domain Variable based on pass in from Jenkins
DOMAIN=$(echo $2 | cut -d"'" -f2)
SQLDOMAIN=$2

DB_SERVER=127.0.0.1
DB_NAME_V2=ss_core_02



# Remove any previous reports
rm -f ${STATS_OUTPUT}/*


. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_QUERY}/reportFuncsPrism.sh

for SQL_FILE in ${STATS_QUERY}/prism*.sql 
do
  echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  #echo $DOMAIN
  #echo $SQLDOMAIN
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
  outputReport ${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
done



# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

zipReports prism*.csv prism-${DOMAIN}-${LOG_DATE}.zip

# actually show the results in Jenkins console
#cat ${LOG_FILE}
