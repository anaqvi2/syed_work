-- Shares Added 
SELECT DATE_FORMAT(GAM.insertDateTime, '%Y-%m') AS InsertMonth, DATE_FORMAT(GAM.insertDateTime, '%Y-%m-%d') AS insertDate, 
	CASE 
		WHEN GAM.Access = 40 THEN "Admin" 
		WHEN GAM.access = 30 THEN "Editor w/ Sharing"
		WHEN GAM.access = 20 THEN "Editor"
		WHEN GAM.access = 10 THEN "Viewer"
	END AS AccessLevels, 
	COUNT(DISTINCT GAM.userID) SharesAdded
FROM rpt_workspace.rArunk_OrgDB_SheetsTable ST 
INNER JOIN rpt_main_02.gridAccessMap GAM ON GAM.gridID = ST.GridID 
	AND GAM.access<50
WHERE ST.masterDomain = @domain
GROUP BY 1,2,3
LIMIT 123456789
;