-- Active Users in last 90 days 
SELECT 
CASE 
	WHEN DATEDIFF(NOW(),UT.LastActiveDate)> 90 
	THEN "Inactive" 
	ELSE "Active" 
END AS IsActive, 
COUNT(DISTINCT UT.mainContactUserID) NumUsers
FROM rpt_workspace.rArunk_OrgDB_UserTable UT
WHERE UT.currentProductGroup IN ("Enterprise","Team") 
AND UT.masterDomain = @domain
GROUP BY 1
;