
SMARTUSER_HOME=$HOME
STATS_HOME=${WORKSPACE}/stats
STATS_OUTPUT=${STATS_HOME}/output
STATS_QUERY=${STATS_HOME}/query

# Log date is passed in from restoreFromBackup.sh script
LOG_DATE=$1
#LOG_FILE=${STATS_HOME}/logs/buildCSV_${LOG_DATE}.log
#exec > $LOG_FILE 2>&1

DB_SERVER=127.0.0.1
DB_NAME_V2=ss_core_02

# die gracefully if it's Saturday or Sunday
# dow=`date +"%A"`
# if [ $dow = "Saturday" ] || [ $dow = "Sunday" ]
#then
#	echo "it's the weekend, exiting without working."
#	exit 0
#fi

# Remove any previous reports
rm -f ${STATS_OUTPUT}/*

. ${SMARTUSER_HOME}/backupinfo.sh
. ${STATS_HOME}/reportFuncs.sh

for SQL_FILE in ${STATS_QUERY}/RevenueSummary*.sql
do
echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
 # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
outputReport ${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
done

for SQL_FILE in tableau-domainLevelChurnReportingV2.sql tableau-trialReportUpdateV2.sql payingCustomersV2.sql MQLReportV2.sql ref_holidaysV2.sql userPPC_detailed_English_Display_V2.sql userPPC_detailed_English_Search_V2.sql userPPC_detailed_ForeignLanguage_V2.sql OptimizelyExperimentsV2.sql tableau-forecastingResultsV2.sql tableau-forecastingResults2V2.sql tableau-forecastingResults5V2.sql tableau-forecastingResults6V2.sql netBookings1V2.sql netBookings2V2.sql tableau-sales_carson_A_usageDashboardV2.sql tableau-carson-buyingDayCalendarV2.sql tableau-sales_carson_A_usageDashboardMidMarketV2.sql tableau-sales_carson_A_usageDashboardSMBV2.sql tableau-sales_carson_A_usageDashboardStrategicV2.sql tableau-schmale-csDashboard1V2.sql tableau-schmale-csDashboard2V2.sql tableau-schmale-csDashboard3V2.sql tableau-schmale-csDashboard4V2.sql tableau-schmale-csDashboard5V2.sql tableau-schmale-csDashboard6V2.sql tableau-schmale-csDashboard7V2.sql tableau-schmale-csDashboard8V2.sql tableau-schmale-csDashboard9V2.sql tableau-schmale-csDashboard10V2.sql tableau-schmale-csDashboard11V2.sql tableau-schmale-csDashboard12V2.sql tableau-schmale-csDashboard13V2.sql tableau-schmale-csDashboard14V2.sql usageDashboardUnassignedV2.sql customerRenewalDataV2.sql salesforceRollingPipelineV2.sql 5KThresholdCustomersV2.sql FY18GrowthScorecardV2.sql SLPTRPmappingV2.sql referralRewardsV2.sql UseCaseReportV2.sql OrgConfigSettingsSummaryV2.sql salesCohortsPerformanceV2.sql salesCohortsPerformance2V2.sql salesCohortsPerformance3V2.sql salesCohortsPerformance4V2.sql tableau-unlicensedOrgMembersV2.sql signupDailyV2.sql tableau-eduPlansV2.sql tableau-paymentTransactionRollupV2.sql tableau-paymentTransactionFullV2.sql monthOverMonthPlanNumbersV2.sql customerMasterV2.sql orgsDisguisedAsISPsV2.sql usageDashboardResellerV2.sql tableau-currentPayingCustomersV2.sql monthlyBookingsSnapshotsV2.sql tableau-sales_carson_D_allPaidPlansV2.sql tableau-deadAccountsV2.sql tableau-sales_carson_E_trialReportByAccountV2.sql marketo_combinedAPIDeveloperListV2.sql integratedContentTrackingV2.sql UseCaseReportV2.sql sheetLimitReportV2.sql TemplateUsageConversionV2.sql tableau-licensedUsersByGeoV2.sql tableau-planStatsByGeoV2.sql tableau-ConvWaterfallWinsV2.sql   

do
echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
outputReport ${STATS_QUERY}/${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
done


#for SQL_FILE in ${STATS_QUERY}/tableau*.sql
#do
#  echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
#  outputReport ${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
#done

#for SQL_FILE in ref_holidaysV2.sql userPPC_detailed_V2.sql signupDailyV2.sql TemplateUsageConversionV2.sql trialsRestarts_V2.sql trialsBySource_V2.sql userPPC_wellQualifiedLeadsV2.sql
#do
#  echo "**** $(date +%X) : Running report ${SQL_FILE} ****"
  # Args are: outputReportToZip [QueryFile] [DB_SERVER] [DB_NANE] [USER] [PWD]
#  outputReport ${STATS_QUERY}/${SQL_FILE} ${DB_SERVER} ${DB_NAME_V2} ${DB_USER} ${DB_PWD}
#done


# We want all errors to show up at the top, so we don't have to review the whole file.
# Grep them to a new file and then add the rest of the log file below.
#grep -iw error ${LOG_FILE} | grep -v "Duplicate key name" > ${LOG_FILE}.results
#cat ${LOG_FILE} >> ${LOG_FILE}.results

zipReports *V2.csv insight-${LOG_DATE}-a.zip

# actually show the results in Jenkins console
#cat ${LOG_FILE}
