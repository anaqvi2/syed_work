USE rpt_workspace;

SET SQL_SAFE_UPDATES=0;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
DROP TABLE IF EXISTS rpt_workspace.jmarzinke_emDup;
CREATE TABLE rpt_workspace.jmarzinke_emDup
SELECT hypothesizedEmail, COUNT(*) c FROM jmarzinke_lead411EmployeeConfidence GROUP BY hypothesizedEmail HAVING c > 1 LIMIT 123123123123123;

SELECT personID, COUNT(*) c FROM jmarzinke_lead411EmployeeConfidence GROUP BY personID HAVING c > 1
;

CREATE INDEX eID ON rpt_workspace.jmarzinke_emDup (hypothesizedEmail);

SELECT COUNT(*) FROM jmarzinke_lead411EmployeeConfidence;
SELECT COUNT(*) FROM rpt_workspace.jmarzinke_emDup;

SELECT * FROM jmarzinke_lead411EmployeesClean
WHERE emailAddress LIKE "%arkansaswooddoors.com"
;

SELECT hypothesizedEmail, COUNT(*) COUNT FROM jmarzinke_lead411EmployeeConfidence
GROUP BY hypothesizedEmail
ORDER BY COUNT DESC
;

-- drop table rpt_workspace.pj_emDup;

/* CATEGORIZING DUPLICATES */

DROP TABLE IF EXISTS rpt_workspace.jmarzinke_emDup2;
CREATE TABLE rpt_workspace.jmarzinke_emDup2
(personID INT(15),
hypothesizedEmail VARCHAR(100),
confidence INT,
emailAddress VARCHAR(50),
firstName VARCHAR(25),
lastName VARCHAR(25),
domain VARCHAR(50),
KEY (personID),
KEY (hypothesizedEmail));


INSERT INTO rpt_workspace.jmarzinke_emDup2(personID, hypothesizedEmail, confidence)
SELECT a.personID, a.hypothesizedEmail, a.confidence 
FROM jmarzinke_lead411EmployeeConfidence a
JOIN rpt_workspace.jmarzinke_emDup p ON p.hypothesizedEmail = a.hypothesizedEmail;


UPDATE rpt_workspace.jmarzinke_emDup2 p JOIN jmarzinke_lead411EmployeesClean a
	ON a.personID = p.personID
SET p.emailAddress = a.emailAddress,
	p.firstName = a.firstName,
	p.lastName = a.lastName,
	p.domain = a.domain;

ALTER TABLE rpt_workspace.jmarzinke_emDup2 ADD result INT;

SELECT COUNT(*) FROM rpt_workspace.jmarzinke_emDup2;

SELECT confidence, COUNT(*) FROM rpt_workspace.jmarzinke_emDup2
GROUP BY confidence
ORDER BY confidence ASC
;

UPDATE rpt_workspace.jmarzinke_emDup2
SET result = NULL
;

SELECT COUNT(*) FROM rpt_workspace.jmarzinke_emDup2 d1
JOIN rpt_workspace.jmarzinke_emDup2 d2
    ON d1.hypothesizedEmail = d2.hypothesizedEmail
    AND d1.confidence = d2.confidence
    AND d1.personID != d2.personID
    AND d1.confidence = 10
WHERE d1.result IS NULL AND d2.personID IS NOT NULL
;

UPDATE rpt_workspace.jmarzinke_emDup2 d1
JOIN rpt_workspace.jmarzinke_emDup2 d2
    ON d1.hypothesizedEmail = d2.hypothesizedEmail
    AND d1.confidence = d2.confidence
    AND d1.personID != d2.personID
    AND d1.confidence = 10
SET d1.result = 2
WHERE d1.result IS NULL
;

-- 2 lead411 duplicate email
UPDATE rpt_workspace.jmarzinke_emDup2 p1
	JOIN rpt_workspace.jmarzinke_emDup2 p2 
    ON p1.hypothesizedEmail = p2.hypothesizedEmail
    AND p1.confidence = p2.confidence 
    AND p1.personID!=p2.personID
    AND p1.confidence = 10
SET p1.result = CASE WHEN p2.personID IS NOT NULL THEN 2 ELSE 0 END
WHERE p1.result IS NULL;

UPDATE rpt_workspace.jmarzinke_emDup2 SET result = NULL WHERE result = 2 AND (emailAddress = '215693.lead.10211740@cendant.leadrouter.com' OR emailAddress LIKE '@%');

SELECT result, COUNT(*) FROM rpt_workspace.jmarzinke_emDup2
GROUP BY result
ORDER BY result
;

-- 3 email from 411 matches hypothesized email

UPDATE rpt_workspace.jmarzinke_emDup2 p1
	JOIN rpt_workspace.jmarzinke_emDup2 p2 
    ON p1.hypothesizedEmail = p2.hypothesizedEmail
    AND p1.confidence != p2.confidence 
    AND p1.personID!=p2.personID
    AND p2.confidence = 10
SET p1.result = CASE WHEN p2.personID IS NOT NULL THEN 3 ELSE 0 END
WHERE p1.result IS NULL;

-- 31 email from 411 matches hypothesized email

UPDATE rpt_workspace.jmarzinke_emDup2 p1
	JOIN rpt_workspace.jmarzinke_emDup2 p2 
    ON p1.hypothesizedEmail = p2.hypothesizedEmail
    AND p1.confidence != p2.confidence 
    AND p1.personID!=p2.personID
    AND p1.confidence = 10
SET p1.result = CASE WHEN p2.personID IS NOT NULL THEN 31 ELSE 0 END
WHERE p1.result IS NULL AND p2.result = 3;

-- LEFT OFF HERE

DROP TABLE rpt_workspace.jmarzinke_emDupMAX;
CREATE TEMPORARY TABLE rpt_workspace.jmarzinke_emDupMAX
SELECT personID, hypothesizedEmail, MAX(confidence) AS confidence
FROM rpt_workspace.jmarzinke_emDup2 
WHERE result IS NULL
AND confidence != 10
GROUP BY hypothesizedEmail;

-- ranking remaining hypothesized email dupes 4
UPDATE rpt_workspace.jmarzinke_emDup2 p1
	JOIN rpt_workspace.jmarzinke_emDupMAX  p2 
    ON p1.hypothesizedEmail = p2.hypothesizedEmail
SET p1.result = CASE WHEN p2.confidence > p1.confidence THEN 4 END
WHERE p1.result IS NULL;

-- ranking remaining hypothesized email dupes, confidence the same 5
UPDATE rpt_workspace.jmarzinke_emDup2 p1
	JOIN rpt_workspace.jmarzinke_emDupMAX  p2 
    ON p1.hypothesizedEmail = p2.hypothesizedEmail
    AND p1.personID != p2.personID
SET p1.result = CASE WHEN p2.confidence = p1.confidence THEN 5 END
WHERE p1.result IS NULL;

-- outliers who didn't fall in any category but email right
UPDATE rpt_workspace.jmarzinke_emDup2 p1 SET result = '6' WHERE personID IN ('13098975','29119857');

-- emails that look like domains but first and last present and can hypothesize.
UPDATE rpt_workspace.jmarzinke_emDup2 p1 SET result = '7' WHERE result IS NULL;

SELECT result, COUNT(*) FROM rpt_workspace.jmarzinke_emDup2
GROUP BY result
ORDER BY result
;

/* HYPOTHESIZING DOMAIN EMAILS */

DROP TABLE  jmarzinke_lead411EmployeeConfidence2;
CREATE TABLE jmarzinke_lead411EmployeeConfidence2 (
personID INT(11),
hypothesizedEmail VARCHAR(100), 
confidence TINYINT(3), 
PRIMARY KEY (personID, hypothesizedEmail, confidence));


-- inner joins lWarr_emailFormat with cDunn_lead411Employees to make email formats of all users on that domain
-- have to comment and uncomment each eamil format and run each one in the select and where clause
INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(SUBSTRING(firstName, 1, 1), lastName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(firstName, lastName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(firstName, '.', lastName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(lastName, SUBSTRING(firstName, 1, 1), '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(lastName, firstName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(lastName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(firstName, SUBSTRING(lastName, 1, 1), '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(firstName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

INSERT IGNORE INTO jmarzinke_lead411EmployeeConfidence2 (personID, hypothesizedEmail, confidence)
SELECT personID, LOWER(CONCAT(lastName, '.', firstName, '@', domain)), confidence
FROM rpt_workspace.jmarzinke_emDup2
WHERE result = 7
;

-- Make all confidences of 0 = 1 so that domains with no known emails can have a confidence of 0.  
UPDATE jmarzinke_lead411EmployeeConfidence2
SET confidence = 1
WHERE confidence = 0; 

SELECT COUNT(*) FROM jmarzinke_lead411EmployeeConfidence2;

/* CEALNING UP CONFIDENCE TABLE */

DELETE ec FROM jmarzinke_lead411EmployeeConfidence ec
JOIN rpt_workspace.jmarzinke_emDup2 ed ON ec.personID = ed.personID AND ed.result IN (1, 7)
;
EXPLAIN
DELETE FROM jmarzinke_lead411EmployeeConfidence WHERE personID IN (SELECT personID FROM rpt_workspace.jmarzinke_emDup2 WHERE result = '1');
DELETE FROM jmarzinke_lead411EmployeeConfidence WHERE personID IN (SELECT personID FROM rpt_workspace.jmarzinke_emDup2 WHERE result = '7');

DROP TABLE rpt_workspace.jmarzinke_temp;
CREATE TABLE rpt_workspace.jmarzinke_temp 
SELECT DISTINCT personID FROM rpt_workspace.jmarzinke_emDup2 WHERE result IN ('2','3','4','5') ORDER BY personID DESC;

CREATE INDEX pID ON rpt_workspace.jmarzinke_temp(personID);

UPDATE ignore jmarzinke_lead411EmployeeConfidence a 
SET a.confidence = CASE WHEN a.personID IN (SELECT personID FROM rpt_workspace.jmarzinke_temp) THEN -1 ELSE confidence END;

select * from jmarzinke_lead411EmployeeConfidence
where personID = 8288634
;

-- insert into rpt_main_02.arc_lead411EmployeeConfidence (personID, hypothesizedEmail, confidence)
-- select * from rpt_workspace.lWarr_lead411EmployeeConfidence2;
CREATE TEMPORARY TABLE rpt_workspace.pj_testing SELECT * FROM rpt_main_02.arc_lead411EmployeeConfidence LIMIT 3000000;

-- UPDATE rpt_main_02.arc_lead411EmployeeConfidence a
-- RIGHT JOIN rpt_workspace.pj_temp t ON a.personID = t.personID
-- SET a.confidence = -1;

INSERT ignore INTO jmarzinke_lead411EmployeeConfidence(personID, hypothesizedEmail, confidence)
SELECT personID, hypothesizedEmail, confidence FROM jmarzinke_lead411EmployeeConfidence2;


SELECT COUNT(*) FROM jmarzinke_lead411EmployeeConfidence WHERE confidence = '-1';
