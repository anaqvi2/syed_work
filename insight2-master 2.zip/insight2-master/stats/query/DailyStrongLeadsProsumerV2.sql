SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeadsProsumerV2.csv");

/*Generating DailyStrongLeadsProsumerV2.sql*/
/*CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_DailyStrongLeads(
	snapshotDate DATE,
	userInsertDateTIme DATETIME,
	userID BIGINT, 
	dailyCount INT,
	firstDayLogCount INT,
	SSOwner VARCHAR(20),
	employeeCount INT,
	leadType VARCHAR(20),
	random FLOAT(10,9),
	PRIMARY KEY(userID));*/

/*Generate output of Daily Strong Leads for \\SOL */
SELECT 
CASE arc_HooversCompanyData.companyName IS NULL
	WHEN 1 THEN userAccount.domain
	ELSE arc_HooversCompanyData.companyName END AS "companyName",
userAccount.domain,
userAccount.firstName,
CASE userAccount.lastName IS NULL 
	WHEN 1 THEN "No Last Name"
	ELSE userAccount.lastName END AS 'lastName',
NULL AS "Title",
userAccount.emailAddress,

arc_HooversCompanyData.address AS "Street Address",
arc_HooversCompanyData.primaryCity,
arc_HooversCompanyData.primaryState,
arc_HooversCompanyData.postalCode AS "PostalCode",
userAccount.countryFriendly AS Country,
arc_HooversCompanyData.employeesTotal,
arc_sfdc_upload.OwnerID,
CASE arc_sfdc_upload.OwnerID
	WHEN "00540000001UFlQ" THEN "Gene"
	WHEN "00540000001UFla" THEN "Kevin" 
	WHEN "00540000001UFlV" THEN "Ben" 	 
	WHEN "00540000001UFlf" THEN "Taylor" 
	WHEN "00540000001UcZX" THEN "AJ"	
	ELSE "Error" 
	END AS SSOwner,	
(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 
	AND ProfileCount.productID IN(3,4,6,7,10)) AS CurrentPaidUsersFromDomain,
	
(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
	WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 
	AND ProfileCount.productID = 6 AND ProfileCount.productID IN(3,4,6,7,10,11)
	AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain,
	
userAccount.languageFriendly AS "Language",
CONCAT(arc_HooversCompanyData.areaCode, "-",arc_HooversCompanyData.PrimaryContactPhone) AS "PrimaryContactPhone",

CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
	WHEN 1 THEN 1
	ELSE 0
END AS 'Is Strong Lead'

FROM rpt_main_02.arc_sfdc_upload
JOIN rpt_main_02.userAccount ON arc_sfdc_upload.Email = userAccount.emailAddress
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_main_02.rpt_paymentProfile.mainContactUserID = userAccount.userID 
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID =  rpt_clientLogCountsByUserArchived.userID

WHERE uploadDateTime IS NULL

AND LeadSource = "Prosumer-SL150"

GROUP BY emailAddress;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeadsProsumerV2.csv");
