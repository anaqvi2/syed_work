SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2016-04-13PricingMatrixMedallionV2.sql");

/*create table rpt_workspace.pj_abtest_paymentActions
(insertByUserID INT,
logDate DATE,
objectID INT,
actionID INT,
parm1Int INT,
parm1String VARCHAR(100),
logCount INT,
primary key (insertByUserID, logDate, objectID, actionID, parm1Int, parm1String),
key ix_logdate (logdate),
key ix_insertByUserID (insertByUserID)
);

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert into rpt_workspace.pj_abtest_paymentActions
select * from rpt_main_02.arc_clientEventRollup
where objectID IN (2151,2152,2153,2155,2161)
and logDate >= '2016-03-01';*/

select max(logDate) from  rpt_workspace.pj_abtest_paymentActions into @maxLogDate;

insert ignore into rpt_workspace.pj_abtest_paymentActions
select * from rpt_main_02.arc_clientEventRollup
where objectID IN (2151,2152,2153,2155,2161)
and logDate >= date_sub(@maxLogDate, interval 2 day);

SELECT 
siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_trials.trialDateTime,
DATE_FORMAT(rpt_main_02.rpt_trials.trialDateTime, "%Y-%m-%d") AS trialDate,
rpt_main_02.hist_paymentProfile.productID,
rpt_main_02.hist_paymentProfile.paymentStartDateTime,

-- usage Data
rpt_loginCountTotal.firstLogin,
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,	
CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Twice',

-- user data
CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,
userAccount.languageFriendly,
teamTrialABTest.valueNumeric as teamTrialABTestGroup,
rpt_optimizelyExperiments.variation,

-- user product
CASE WHEN opp.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END as salesAssisted,
rpt_paymentProfile.paymentStartDateClean,
CASE WHEN rpt_paymentProfile.planRate_USD > 0 then (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm) else 0 end as MRR,
rpt_paymentProfile.userLimit,
rpt_paymentProfile.countAsPaid,
rpt_paymentProfile.hasPaid,
rpt_paymentProfile.daysToBuy,
rpt_paymentProfile.paymentTerm,
CASE WHEN rpt_paymentProfile2.productID IN (3,4,6,7) THEN 1 ELSE 0 END AS CountAsPaidProduct,
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS 'Basic?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS 'Advanced?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS 'Team?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise?',
CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS 'Cancelled?',
CASE WHEN pwa.objectID = '2151' THEN 1 ELSE 0 END AS ViewedStep1
	
FROM rpt_main_02.siteSettingElementValue 
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_trials.userID = siteSettingElementValue.userID and trialType = '1' and firstTrial = '1' and  
	((siteSettingElementValue.insertDateTime between rpt_trials.trialDateTime and rpt_trials.trialEndDateTime) or (siteSettingElementValue.insertDateTime >= rpt_trials.trialDateTime and rpt_trials.trialEndDateTime is null))
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > siteSettingElementValue.insertDateTime and productID > 2
LEFT OUTER JOIN ss_sfdc_02.opportunity opp on opp.parent_payment_profile_ID__c = rpt_paymentProfile.paymentProfileID AND parent_payment_profile_ID__c IS NOT NULL AND opp.product__c != 'Services'
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,rpt_paymentProfile.paymentStartDateClean),'%Y-%m') = DATE_FORMAT(opp.CloseDate,'%Y-%m')
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > siteSettingElementValue.insertDateTime
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3'
	and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
LEFT OUTER JOIN rpt_workspace.pj_abtest_paymentActions pwa on siteSettingElementValue.userID=pwa.insertbyuserID and pwa.logDate >= date_format(siteSettingElementValue.insertDateTime, '%Y-%m-%d')
LEFT OUTER JOIN rpt_main_02.siteSettingElementValue as teamTrialABTest on teamTrialABTest.userID = siteSettingElementValue.userID and teamTrialABTest.siteSettingElementName =  "SS_ABTEST_TEAM_TRIAL"
LEFT OUTER JOIN rpt_main_02.rpt_optimizelyExperiments on rpt_optimizelyExperiments.userID = siteSettingElementValue.userID and experiment = 5861190203

WHERE siteSettingElementValue.siteSettingElementName =  "SS_ABTEST_PRICING_MATRIX_BEST_VALUE_MEDALLION_2"
AND siteSettingElementValue.siteSettingElementValueID > 47012145
GROUP BY 1,2,3,4
Limit 1234568;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2016-04-13PricingMatrixMedallionV2.sql");
