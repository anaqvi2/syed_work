SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2016-06-21CardViewTipV2.sql");


/*
drop table if exists rpt_workspace.pj_cardViewTipClientEvents;
create table rpt_workspace.pj_cardViewTipClientEvents like rpt_main_02.arc_clientEventRollup;

create index objectID on rpt_workspace.pj_cardViewTipClientEvents(objectID);
create index actionID on rpt_workspace.pj_cardViewTipClientEvents(actionID);
create index parm1String on rpt_workspace.pj_cardViewTipClientEvents(parm1String);
create index logCount on rpt_workspace.pj_cardViewTipClientEvents(logCount);

alter table rpt_workspace.pj_cardViewTipClientEvents add primary key(logDate, insertbyuserID, objectID, actionID, parm1String, parm1Int);
*/
/*
select max(logDate) from rpt_workspace.pj_cardViewTipClientEvents into @logDate;

insert ignore into rpt_workspace.pj_cardViewTipClientEvents
select * from rpt_main_02.arc_clientEventRollup
where objectID IN (8510,8509, 8507,8505)
and actionID = 22
and logDate >= '2016-06-22'
and insertbyuserID > 10000
and logDate >= Date_sub(@logDate, interval 2 day)
;

insert ignore into rpt_workspace.pj_cardViewTipClientEvents
select * from rpt_main_02.arc_clientEventRollup
where objectID IN (8510)
and actionID = 1
and logDate >= '2016-06-22'
and insertbyuserID > 10000 
and logDate >= Date_sub(@logDate, interval 2 day)
;

insert ignore into rpt_workspace.pj_cardViewTipClientEvents
select * from rpt_main_02.arc_clientEventRollup
where objectID = 2001
and actionID = 22
and parm1String = "btn_got_it"
and logDate >= '2016-06-22'
and insertbyuserID > 10000
and logDate >= Date_sub(@logDate, interval 2 day)
;

drop table if exists rpt_workspace.pj_stg_collabTip;
create table rpt_workspace.pj_stg_collabTip
(siteSettingElementName varchar(100),
userID int(15),
valueNumeric int,
insertDateTime datetime,
insertDate date,
trialDateTime datetime,
insertProductID int,
insertPaymentStartDateTime datetime,
firstSessionLogID bigint,
sessionDateTime datetime,
signoutDateTime datetime,
sessionTime decimal(10,2),
firstDayLogCount int,
`Is Strong Lead` int,
WellQualCount int,
`EverWellQual` int,
`User Logged In At Least 3 Times` int,
sharingCount int,
lifetimeSheetCount int, 
sheetCount int, 
lifetimeLogCount int,
`Signup Bucket` varchar(100),
`Signup Source Friendly` varchar(100),
`Signup Sub Source Friendly`varchar(100),
campaign varchar(100),
ipCountry varchar(100),    
languageFriendly varchar(100),
domain varchar(100),
hasPaid int,
daysToBuy int,
paymentTerm varchar(15),
userLimit int,
`Basic?` int,
`Advanced?` int,
`Team?` int,
`Enterprise?` int,
`Cancelled?` int,
paymentStartDateClean datetime, 
paymentStartDate date,
CountAsPaidProduct int,
ARR decimal(10,2),
salesAssisted int,
gotCardViewTip int,
ClickedGotIt int,
ClosedX int,
ClickedLearnMore int,
ClickedOutOfModal int,
GotDropdownColumnError int,
ClickedCardView int,
SawCardView int,
CardViewSheetCount int,
index (userID),
index (insertDate));

insert into rpt_workspace.pj_stg_collabTip(
siteSettingElementName,
userID,
valueNumeric,
insertDateTime,
insertDate,
trialDateTime,
firstSessionLogID,
sessionDateTime,
signoutDateTime,
sessionTime,
firstDayLogCount,
`Is Strong Lead`,
WellQualCount,
`EverWellQual`,
`User Logged In At Least 3 Times`,
sharingCount,
lifetimeSheetCount, 
sheetCount, 
lifetimeLogCount,
`Signup Bucket`,
`Signup Source Friendly`,
`Signup Sub Source Friendly`,
campaign,
ipCountry,    
languageFriendly,
domain)

SELECT siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
siteSettingElementValue.insertDateTime,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_trials.trialDateTime,
-- activity data
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0 WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
CASE rpt_loginCountTotal.loginCount >= 4 WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 3 Times',
rpt_featureCountRollupByUser.sharingCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
-- user info
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
CASE rpt_signupSource.bucket IS NULL WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
CASE rpt_signupSource.sourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly END AS 'Signup Source Friendly',
CASE rpt_signupSource.subSourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,    
userAccount.languageFriendly,
userAccount.domain

FROM rpt_main_02.siteSettingElementValue 
JOIN rpt_main_02.userAccount ON userAccount.userID = siteSettingElementValue.insertbyuserID 
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_trials.userID = siteSettingElementValue.userID and trialType = '1' and firstTrial = '1' and  
	((siteSettingElementValue.insertDateTime between rpt_trials.trialDateTime and rpt_trials.trialEndDateTime) or (siteSettingElementValue.insertDateTime >= rpt_trials.trialDateTime and rpt_trials.trialEndDateTime is null)) 
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser ON siteSettingElementValue.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
-- LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3' and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime

WHERE siteSettingElementName =  "SS_ABTEST_CARD_VIEW_TIP" 
AND siteSettingElementValueID > 75861581
GROUP BY 1,2,3,4
LIMIT 123456789
;

UPDATE rpt_workspace.pj_stg_collabTip 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON pj_stg_collabTip.userID = rpt_paymentProfile.mainContactUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > pj_stg_collabTip.insertDateTime and rpt_paymentProfile.productID > 2
LEFT OUTER JOIN ss_sfdc_02.opportunity opp on opp.parent_payment_profile_ID__c = rpt_paymentProfile.paymentProfileID AND parent_payment_profile_ID__c IS NOT NULL AND opp.product__c != 'Services'
		AND DATE_FORMAT(TIMESTAMPADD(HOUR,-7,rpt_paymentProfile.paymentStartDateClean),'%Y-%m') = DATE_FORMAT(opp.CloseDate,'%Y-%m') AND opp.StageName = 'Closed Won' 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON pj_stg_collabTip.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > pj_stg_collabTip.insertDateTime and rpt_paymentProfile2.productID > 2
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = pj_stg_collabTip.userID and rpt_main_02.hist_paymentProfile.accountType != '3' and pj_stg_collabTip.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
set
pj_stg_collabTip.insertProductID = hist_paymentProfile.productID,
pj_stg_collabTip.insertPaymentStartDateTime = hist_paymentProfile.paymentStartDateTime,
pj_stg_collabTip.hasPaid = rpt_paymentProfile.hasPaid,
pj_stg_collabTip.daysToBuy = rpt_paymentProfile.daysToBuy,
pj_stg_collabTip.paymentTerm = CASE WHEN rpt_paymentProfile.paymentTermFriendly IN ('Monthly','Annual','Semi-Annual') THEN rpt_paymentProfile.paymentTermFriendly else NULL END,
pj_stg_collabTip.userLimit = CASE WHEN rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.productID != 9 THEN rpt_paymentProfile.userLimit ELSE 0 end,
`Basic?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 END END,
`Advanced?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 END END ,
`Team?` =  CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 END END,
`Enterprise?` = CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 END END,
`Cancelled?` = CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END,
pj_stg_collabTip.paymentStartDateClean = rpt_paymentProfile.paymentStartDateClean,
pj_stg_collabTip.paymentStartDate = Date_format(rpt_paymentProfile.paymentStartDateClean, "%Y-%m-%d"),
pj_stg_collabTip.CountAsPaidProduct = CASE WHEN rpt_paymentProfile2.productID IN(3,4,6,7) THEN 1 ELSE 0 END,
pj_stg_collabTip.ARR = CASE WHEN rpt_paymentProfile.planRate_USD > 0 then (12*(rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm)) else 0 end,
pj_stg_collabTip.salesAssisted = CASE WHEN opp.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END;


update rpt_workspace.pj_stg_collabTip 
LEFT OUTER JOIN 
(select insertbyuserID, 
sum(CASE WHEN pj_cardViewTipClientEvents.objectID = 2001 THEN 1 else 0 end) as ClickedGotIt,
sum(CASE WHEN pj_cardViewTipClientEvents.objectID = 8505 THEN 1 else 0 end) as ClosedX,
sum(CASE WHEN pj_cardViewTipClientEvents.objectID = 8509 THEN 1 else 0 end) as ClickedLearnMore,
sum(CASE WHEN pj_cardViewTipClientEvents.objectID = 8507 THEN 1 else 0 end) as ClickedOutOfModal,
sum(CASE WHEN pj_cardViewTipClientEvents.objectID = 8510 THEN 1 else 0 end) as gotCardViewTip
FROM 
rpt_workspace.pj_cardViewTipClientEvents GROUP BY 1) cardViewTipClientEvents ON cardViewTipClientEvents.insertbyuserID=pj_stg_collabTip.userID 
LEFT OUTER JOIN 
(select insertbyuserID, 
sum(CASE WHEN pj_cardViewClientEvents.objectID = 1602 and pj_cardViewClientEvents.actionID = 1 and pj_cardViewClientEvents.parm1String = "msg_card_minconfig" THEN 1 else 0 end) as GotDropdownColumnError,
sum(CASE WHEN pj_cardViewClientEvents.objectID = 5034 THEN 1 else 0 end) as ClickedCardView,
sum(CASE WHEN pj_cardViewClientEvents.objectID = 5304 THEN 1 else 0 end) as SawCardView
FROM 
rpt_workspace.pj_cardViewClientEvents GROUP BY 1) cardViewClientEvents ON cardViewClientEvents.insertbyuserID=pj_stg_collabTip.userID 
set
pj_stg_collabTip.ClickedGotIt = case when cardViewTipClientEvents.ClickedGotIt > 0 then 1 else 0 end,
pj_stg_collabTip.ClosedX = case when cardViewTipClientEvents.ClosedX > 0 then 1 else 0 end,
pj_stg_collabTip.ClickedLearnMore = case when cardViewTipClientEvents.ClickedLearnMore > 0 then 1 else 0 end,
pj_stg_collabTip.ClickedOutOfModal = case when cardViewTipClientEvents.ClickedOutOfModal > 0 then 1 else 0 end,
pj_stg_collabTip.gotCardViewTip = case when cardViewTipClientEvents.gotCardViewTip > 0 then 1 else 0 end,
pj_stg_collabTip.GotDropdownColumnError = case when cardViewClientEvents.GotDropdownColumnError > 0 then 1 else 0 end,
pj_stg_collabTip.ClickedCardView = case when cardViewClientEvents.ClickedCardView > 0 then 1 else 0 end,
pj_stg_collabTip.SawCardView = case when cardViewClientEvents.SawCardView > 0 then 1 else 0 end;


update rpt_workspace.pj_stg_collabTip
set CardViewSheetCount =
(select count(distinct containerID)
FROM rpt_main_02.container
WHERE container.insertbyuserID = pj_stg_collabTip.userID
AND container.sourceID IN (17,49177927,49177940,49177918,49177911,49869288,49177873,49177885,50151456,50153175,50154296,50155916,50161909,50163343,50174488,50175111,50180496,50180507, 50180532, 50181781, 50181794, 49954102)
);*/

select * from rpt_workspace.pj_stg_collabTip limit 1234567;



/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2016-06-21CardViewTipV2.sql");