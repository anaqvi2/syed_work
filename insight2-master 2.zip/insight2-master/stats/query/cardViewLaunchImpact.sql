SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

CALL rpt_main_02.SMARTSHEET_START_LOG ("cardViewLaunchImpact.sql");

select max(logDate) from rpt_workspace.pj_cardViewClientEvents into @maxDate;

insert ignore into rpt_workspace.pj_cardViewClientEvents (insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID IN (5300, 5301, 5302, 5303, 5304, 5305, 5306, 5307, 5308, 5309, 5310, 5311, 5312, 5313, 5314, 5315, 5316, 5317, 5318, 5034, 321, 7168, 13550, 13551)
and logDate > date_sub(@maxDate, interval 2 day)
and insertbyuserID > 10000
and logDate >= '2016-06-22';

insert ignore into rpt_workspace.pj_cardViewClientEvents (insertByUserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID = 1602
and actionID = 1
and parm1String = "msg_card_minconfig"
and logDate >date_sub(@maxDate, interval 2 day)
and insertbyuserID > 10000
and logDate >= '2016-06-22';

select max(logDate) from rpt_workspace.pj_cardViewLaunchEffectiveness_setup into @minLogDate;

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness_setup(logDate,userID)
select min(date), userID
from rpt_main_02.last30DayClientEventDate
where userID > 10000
and date >= date_sub(@minLogDate, interval 2 day)
and date >= '2016-06-22'
group by 2;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_main_02.rpt_paidPlanSheetAccess sa on sa.userID = pj.userID and userPlanId is null
set currentProductName = "Collaborator";

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
set currentProductName = 
(select productName
from rpt_main_02.rpt_paymentProfile pp
where pp.mainContactUserID = pj.userID
and pp.accountType != 3
Limit 1)
where currentProductName is null;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	left outer join rpt_main_02.rpt_signupSource ss on pj.userID = ss.userID
set pj.bucket = CASE ss.bucket IS NULL WHEN 1 THEN "Viral" ELSE ss.bucket END,
	pj.sourceFriendly = CASE ss.sourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE ss.sourceFriendly END,
	pj.subSourceFriendly = CASE ss.subSourceFriendly IS NULL WHEN 1 THEN "Sharing" ELSE ss.subSourceFriendly END,
	pj.campaign = ss.campaign;
    
update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_main_02.userAccount on pj.userID = userAccount.userID
	left outer join rpt_main_02.arc_ISPDomains on arc_ISPDomains.domain = userAccount.domain
    left outer join rpt_main_02.rpt_userIPLocation on  pj.userID = rpt_userIPLocation.userID
set pj.languageFriendly = userAccount.languageFriendly,
	pj.domain = userAccount.domain,
	pj.ipCountry = rpt_userIPLocation.ipCountry,
    pj.isOrgDomain = case when arc_ISPDomains.domain is null then 1 else 0 end;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
set cardViewViewCount =
(select sum(logCount)
from rpt_workspace.pj_cardViewClientEvents
where objectID = 5304
and actionID = 51
and pj_cardViewClientEvents.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID);

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
set firstCardViewViewDateTime =
(select min(logDate)
from rpt_workspace.pj_cardViewClientEvents
where objectID = 5304
and actionID = 51
and pj_cardViewClientEvents.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID);

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_main_02.rpt_paidPlanSheetAccess sa on sa.userID = pj.userID and sa.userPlanId is null
set firstImpressionProduct = "Collaborator"
where firstImpressionProduct is null;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
	join rpt_main_02.hist_paymentProfile on pj_cardViewLaunchEffectiveness_setup.userID = hist_paymentProfile.ownerID 
		and hist_paymentProfile.accountType != 3 
		and date_format(hist_paymentProfile.modifyDateTime, '%Y-%m-%d') <= pj_cardViewLaunchEffectiveness_setup.firstCardViewViewDateTime
        and date_format(hist_paymentProfile.hist_effectiveThruDateTime, '%Y-%m-%d') > pj_cardViewLaunchEffectiveness_setup.firstCardViewViewDateTime
set pj_cardViewLaunchEffectiveness_setup.firstImpressionProduct = rpt_main_02.SMARTSHEET_PRODUCTNAME(hist_paymentProfile.productID)
where firstImpressionProduct is null;


update rpt_workspace.pj_cardViewLaunchEffectiveness_setup 
set cardViewCreatedCount =
(select count(distinct containerID)
from rpt_main_02.container 
where container.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID
and container.sourceID IN (17,49177927,49177940,49177918,49177911,49869288,49177873,49177885,50151456,50153175,50154296,50155916,50161909,50163343,50174488,50175111,50180496,50180507, 50180532, 50181781, 50181794, 49954102));

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
set cardViewInteractionCount =
(select sum(logCount)
from rpt_workspace.pj_cardViewClientEvents
where rpt_workspace.pj_cardViewClientEvents.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID
and objectID NOT IN (1602, 5034, 5304)
);

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
set gotCardViewTip =
(select sum(logCount)
from rpt_workspace.pj_cardViewTipClientEvents
where rpt_workspace.pj_cardViewTipClientEvents.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID
and objectID IN (8510)
);

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
	join rpt_main_02.stg_tableauTrialReport on stg_tableauTrialReport.userID = pj_cardViewLaunchEffectiveness_setup.userID and trialDateTime is null
set pj_cardViewLaunchEffectiveness_setup.trialDateTime = stg_tableauTrialReport.trialStartDate,
	pj_cardViewLaunchEffectiveness_setup.isStrongLead = stg_tableauTrialReport.IsStrongLeadAdjusted;
    
create temporary table rpt_workspace.pj_dropDownError
(insertByUserID int(15), 
logDate date, 
objectID int, 
actionID int, 
parm1String varchar(50), 
parm1Int int, 
logCount int,
index (insertbyuserID),
index (logDate));

insert into rpt_workspace.pj_dropDownError
select * from rpt_workspace.pj_cardViewClientEvents where objectID = 1602
and actionID = 1
and parm1String = "msg_card_minconfig";

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup
set GotDropdownColumnError =
(select sum(logCount)
from rpt_workspace.pj_dropDownError
where rpt_workspace.pj_dropDownError.insertbyuserID = pj_cardViewLaunchEffectiveness_setup.userID
and objectID = 1602
and actionID = 1
and parm1String = "msg_card_minconfig" 
);

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup set GotDropdownColumnError = 0 where GotDropdownColumnError is null;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_workspace.js_toothbrushTotals js on pj.userID = js.userID and js.monthDate = '2016-06-01'
set juneDaysActive = daysActiveOnEither
;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_workspace.js_toothbrushTotals js on pj.userID = js.userID and js.monthDate = '2016-07-01'
set julyDaysActive = daysActiveOnEither
;

-- alter table rpt_workspace.pj_cardViewLaunchEffectiveness_setup add column daysActive int;

update rpt_workspace.pj_cardViewLaunchEffectiveness_setup pj
	join rpt_workspace.js_toothbrushTotals js on pj.userID = js.userID and date_format(js.monthDate, '%Y-%m') = date_format(firstCardViewViewDateTime, '%Y-%m')
set daysActive = daysActiveOnEither
;

drop table if exists rpt_workspace.pj_cardViewLaunchEffectiveness;
create table rpt_workspace.pj_cardViewLaunchEffectiveness
(logDate date,
userID int(15),
domain varchar(100),
isOrgDomain int,
ipCountry varchar(25),
languageFriendly varchar(100),
bucket varchar(100),
sourceFriendly varchar(100),
subSourceFriendly varchar(100),
campaign varchar(100),
trialDateTime datetime,
isStrongLead int,
currentProductName varchar(25),
firstImpressionProduct varchar(25),
Action varchar(100),
counts int,
GotDropdownColumnError int,
primary key (userID, Action),
index (userID));

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness(logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, Action, counts, trialDateTime,isStrongLead, GotDropdownColumnError)
select logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, "Had App Activity", 1, trialDateTime, isStrongLead, sum(GotDropdownColumnError)
from rpt_workspace.pj_cardViewLaunchEffectiveness_setup
group by 1,2;

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness(logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, Action, counts, trialDateTime, isStrongLead, GotDropdownColumnError)
select logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, "Viewed Card View", sum(cardViewViewCount), trialDateTime, isStrongLead, GotDropdownColumnError
from rpt_workspace.pj_cardViewLaunchEffectiveness_setup
where cardViewViewCount is not null and cardViewViewCount > 0
group by 1,2;

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness(logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, Action, counts, trialDateTime, isStrongLead, GotDropdownColumnError)
select logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, "Created Card View Sheet", sum(cardViewCreatedCount), trialDateTime, isStrongLead, GotDropdownColumnError
from rpt_workspace.pj_cardViewLaunchEffectiveness_setup
where cardViewCreatedCount is not null and cardViewCreatedCount > 0
group by 1,2;

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness(logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, Action, counts, trialDateTime, isStrongLead, GotDropdownColumnError)
select logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, "Interacted With Card View", sum(cardViewInteractionCount), trialDateTime, isStrongLead, GotDropdownColumnError
from rpt_workspace.pj_cardViewLaunchEffectiveness_setup
where cardViewInteractionCount is not null and cardViewInteractionCount > 0
group by 1,2;

insert ignore into rpt_workspace.pj_cardViewLaunchEffectiveness(logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, Action, counts, trialDateTime, isStrongLead, GotDropdownColumnError)
select logDate, userID, domain, isOrgDomain, ipCountry, languageFriendly, bucket, sourceFriendly, subSourceFriendly, campaign, currentProductName, firstImpressionProduct, "Got Card View Tip", sum(gotCardViewTip), trialDateTime, isStrongLead, GotDropdownColumnError
from rpt_workspace.pj_cardViewLaunchEffectiveness_setup
where gotCardViewTip is not null and gotCardViewTip > 0
group by 1,2;

select * from rpt_workspace.pj_cardViewLaunchEffectiveness  limit 123123123;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("cardViewLaunchImpact.sql");