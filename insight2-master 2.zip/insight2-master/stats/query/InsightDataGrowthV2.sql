SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("InsightDataGrowthV2.csv");

SELECT * FROM rpt_main_02.arc_InsightTableSizes
WHERE snapshotDate > DATE_ADD(NOW(), INTERVAL -35 DAY)
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("InsightDataGrowthV2.csv");
