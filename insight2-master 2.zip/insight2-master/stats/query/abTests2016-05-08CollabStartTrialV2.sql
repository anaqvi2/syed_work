SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTests2016-05-08CollabStartTrialV2.sql");

/* drop table rpt_workspace.pj_abtest_collabForm;
create table rpt_workspace.pj_abtest_collabForm
(insertByUserID INT,
logDate DATE,
objectID INT,
actionID INT,
parm1Int INT,
parm1String VARCHAR(100),
logCount INT,
primary key (insertByUserID, logDate, objectID, actionID, parm1Int, parm1String),
key ix_logdate (logdate),
key ix_insertByUserID (insertByUserID)
);

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert into rpt_workspace.pj_abtest_collabForm (insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID = 7183
and actionID = 1
and logDate >= '2016-05-06';

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert into rpt_workspace.pj_abtest_collabForm (insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID = 2001
and actionID = 22
and parm1String = 'btn_continue'
and parm1Int = 7183
and logDate >= '2016-05-06'; */

select max(logDate) from  rpt_workspace.pj_abtest_collabForm into @maxLogDate;

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert ignore into rpt_workspace.pj_abtest_collabForm (insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID = 7183
and actionID = 1
and logDate >= date_sub(@maxLogDate, interval 2 day);

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
insert ignore into rpt_workspace.pj_abtest_collabForm (insertbyuserID, logDate, objectID, actionID, parm1String, parm1Int, logCount)
select * from rpt_main_02.arc_clientEventRollup
where objectID = 2001
and actionID = 22
and parm1String = 'btn_continue'
and parm1Int = 7183
and logDate  >= date_sub(@maxLogDate, interval 2 day);

SELECT siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_main_02.rpt_trials.trialDateTime,
DATE_FORMAT(rpt_main_02.rpt_trials.trialDateTime, "%Y-%m-%d") AS trialDate,

-- activity data
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
CASE rpt_loginCountTotal.loginCount >= 4 
	WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 3 Times',
rpt_featureCountRollupByUser.sharingCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
CASE WHEN collabPrompt.objectID = 7183 and collabPrompt.actionID = 1 THEN 1 ELSE 0 END as SawPrompt,
CASE WHEN continueButton.objectID = 2001 THEN 1 ELSE 0 END as ContinueButton,
CASE WHEN collabPrompt.objectID = 7183 THEN sum(collabPrompt.logCount) ELSE 0 END as formViews,

-- user info
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
		END AS 'Signup Bucket',
CASE rpt_signupSource.sourceFriendly IS NULL
	WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',
CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',
rpt_signupSource.campaign,
rpt_userIPLocation.ipCountry,    
userAccount.languageFriendly,

-- conversion data
rpt_paymentProfile.hasPaid,
case when rpt_paymentProfile.countAsPaid = 1 then 1 else 0 end as countAsPaid,
rpt_paymentProfile.daysToBuy,
CASE WHEN rpt_paymentProfile.paymentTermFriendly IN ('Monthly','Annual','Semi-Annual') THEN rpt_paymentProfile.paymentTermFriendly else NULL END as paymentTerm,
CASE WHEN rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.productID != 9 THEN rpt_paymentProfile.userLimit ELSE 0 end AS userLimit,
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS 'Basic?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS 'Advanced?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS 'Team?',
CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
CASE WHEN rpt_paymentProfile.planRate_USD > 0 AND rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise?',
CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS 'Cancelled?',
rpt_paymentProfile.paymentStartDateClean,
Date_format(rpt_paymentProfile.paymentStartDateClean, "%Y-%m-%d") as paymentStartDate,
CASE WHEN rpt_paymentProfile2.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
CASE WHEN rpt_paymentProfile.planRate_USD > 0 then (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm) else 0 end as MRR,
CASE WHEN opp.parent_payment_profile_ID__c IS NOT NULL THEN 1 ELSE 0 END as salesAssisted

FROM rpt_main_02.siteSettingElementValue 
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_main_02.rpt_trials.userID = siteSettingElementValue.userID and rpt_main_02.rpt_trials.trialDateTime > "2016-05-07 00:00:00" and firstTrial = '1' and trialType = '1'
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser ON siteSettingElementValue.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON siteSettingElementValue.userID = rpt_paymentProfile.sourceUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > siteSettingElementValue.insertDateTime and rpt_paymentProfile.productID > 2
LEFT OUTER JOIN ss_sfdc_02.opportunity opp on opp.parent_payment_profile_ID__c = rpt_paymentProfile.paymentProfileID AND parent_payment_profile_ID__c IS NOT NULL AND opp.product__c != 'Services'
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > siteSettingElementValue.insertDateTime and rpt_paymentProfile2.productID > 2
LEFT OUTER JOIN rpt_workspace.pj_abtest_collabForm collabPrompt on siteSettingElementValue.userID=collabPrompt.insertbyuserID and collabPrompt.objectID = 7183
LEFT OUTER JOIN rpt_workspace.pj_abtest_collabForm continueButton on siteSettingElementValue.userID=continueButton.insertbyuserID and continueButton.objectID = 2001
WHERE siteSettingElementName =  "SS_ABTEST_COLLAB_START_TRIAL" 
AND siteSettingElementValueID > 73110787
GROUP BY 1,2,3,4
LIMIT 123456789
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTests2016-05-08CollabStartTrialV2.sql");