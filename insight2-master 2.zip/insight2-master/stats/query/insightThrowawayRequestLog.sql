select "******************************************************************************************************************************", NOW();
select "******** InsightThrowawayRequestLog - start ******** ", NOW();
/* Use to batch process ss_log_02.requestLog */

 
SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("InsightThrowawayRequestLog");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_requestLog");

CALL rpt_main_02.etl_requestLog_batches(@processId,@logLevel);

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_requestLog");

CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_requestLogRESTSessions");

SELECT MAX(requestLogID) FROM rpt_main_02.arc_requestLogRESTSessions INTO @maxRequestLogID;

INSERT rpt_main_02.arc_requestLogRESTSessions
SELECT * 
FROM ss_log_02.requestLog
WHERE sessionType = 9 
AND requestLogID > @maxRequestLogID
and requestLogID <= (@maxRequestLogID+30000000)
;

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_requestLogRESTSessions");

/*Start Logging*/
CALL rpt_main_02.SEGMENTED_START_LOG ("rpt_main_02.arc_paidAccountTransfers");

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_paidAccountTransfers
(
	requestLogID bigint,
	transferDate datetime,
	transferStatus varchar(100),
	transferFromUserID bigint,
	transferToUserID bigint,
	transferType varchar(100),
	primary key ix_requestLogID (requestLogID),
	key ix_transferDate (transferDate),
	key ix_userID (transferFromUserID),
	key ix_TransferToUserID (transferToUserID)
)
;


SELECT MAX(requestLogID) FROM rpt_main_02.arc_paidAccountTransfers INTO @maxTransferID;

INSERT INTO rpt_main_02.arc_paidAccountTransfers (requestLogID, transferDate, transferStatus, transferFromUserID, transferToUserID, transferType)
SELECT 
requestLog.requestLogID,
requestLog.insertDateTime AS TransferDate,
requestLog.parm4 AS TransferStatus,
FROMUSER.userID AS FromUserID,
TOUSER.userID AS ToUserID,
requestLog.parm3 AS TransferType
FROM rpt_main_02.arc_requestLog requestLog
LEFT OUTER JOIN rpt_main_02.userAccount FROMUSER ON FROMUSER.userID = requestLog.parm1
LEFT OUTER JOIN rpt_main_02.userAccount TOUSER ON TOUSER.userID = requestLog.parm2
WHERE requestLog.parm3 LIKE 'TRANSFER_PAID_ACCOUNT:%' 
-- and requestLog.parm4 = 'true' currently including both successful and failed attempts. This line would only take Successful attempts
AND requestLog.requestLogID > @maxTransferID
AND requestLog.requestLogID <= (@maxTransferID+30000000)
;

CALL rpt_main_02.SEGMENTED_STOP_LOG ("rpt_main_02.arc_paidAccountTransfers");

/*Stop Logging*/
CALL rpt_main_02.SEGMENTED_STOP_LOG ("InsightThrowawayRequestLog");