-- Get current day of week
SELECT DAYNAME(current_date()) INTO @result;

-- SELECT @result;
-- SELECT 'Sunday' INTO @result;

-- This should only run on Sunday
-- If any other day, pass in dummy sql statement
SELECT IF (@result = 'Sunday','CALL rpt_main_02.SMARTSHEET_TABLE_OPTIMIZER();' ,'SELECT 1;') INTO @sql_text;
-- SELECT @sql_text;

-- Execute as prepared statement
PREPARE SQL1 FROM @sql_text;
EXECUTE SQL1;
DEALLOCATE PREPARE SQL1;