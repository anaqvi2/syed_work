/*  List to get current collaborators for newsletters, release emails, webinar invites and other for Marketo email sends.
 *  
 *  2015-07-17 TWJ
 * 
 * */

SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT
userAccount.emailAddress,
userAccount.locale,				-- include raw locale for importing if needed
userAccount.localeFriendly,
userAccount.newsFlags,
arc_domainEmailExclusion.excludeFromMarketingEmail,
rpt_loginCountTotal.loginCount,
rpt_loginCountTotal.lastLogin,
rpt_paymentProfile.paymentProfileID,
rpt_paymentProfile.productID, 
CASE (userAccount.statusFlags & 8)  
	WHEN 8 THEN '1'
	ELSE '0'
END AS 'License Accepted'

FROM userAccount
JOIN rpt_loginCountTotal ON userAccount.UserID = rpt_loginCountTotal.userID
JOIN rpt_paidPlanSheetAccess B ON B.userID = userAccount.userID		-- they have access to sheets from a paid account
LEFT OUTER JOIN rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.mainContactUserID
LEFT OUTER JOIN arc_doNotContactList ON arc_doNotContactList.emailAddress = userAccount.emailAddress
LEFT OUTER JOIN arc_domainEmailExclusion ON userAccount.domain = arc_domainEmailExclusion.domain

WHERE userAccount.newsFlags & 1 AND
userAccount.statusFlags & 8 = 8 AND -- they have accepted the eula
rpt_loginCountTotal.loginCount >= 3 AND
rpt_loginCountTotal.lastLogin > DATE_ADD(CURRENT_DATE(), INTERVAL -60 DAY) AND  -- logged in last 60 days
arc_doNotContactList.emailAddress IS NULL AND
COALESCE(arc_domainEmailExclusion.excludeFromMarketingEmail,"") != 1 AND  -- not domain opted out
(rpt_paymentProfile.paymentProfileID IS NULL OR rpt_paymentProfile.productID = 2) AND -- they don't have a paymentProfile or it is FREE
B.userPlanID IS NULL 	
AND userAccount.languageFriendly NOT IN('French', 'Spanish', 'Portuguese', 'Russian', 'German', 'Italian', 'Japanese') -- take out for foreign language

GROUP BY 1
ORDER BY 1
LIMIT 123456789;
