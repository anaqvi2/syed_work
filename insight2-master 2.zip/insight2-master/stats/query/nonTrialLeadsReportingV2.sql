SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("nonTrialLeadsReportingV2.sql");

drop table if exists rpt_workspace.js_nonTrialTracking;
create table if not exists rpt_workspace.js_nonTrialTracking
(taskID varchar(50),
trafficSource varchar(100),
taskSource varchar(50),
taskSubSource varchar(50),
taskCreatedDate datetime,
taskSubject varchar(100),
taskOwnerID varchar(50),
taskOwner varchar(50),
taskOwnerRole varchar(50),
taskOpportunityID varchar(50),
taskWhoID varchar(50),
taskTTTC dec(10,2),
taskStatus varchar(50),
leadName varchar(50),
leadEmailAddress varchar(50),
leadTitle varchar(50),
leadUserID int,
contactName varchar(50),
contactEmailAddress varchar(50),
contactTitle varchar(50),
contactUserID int,
taskDomain varchar(50),
ISP int,
taskIsFortune1000 int,
existingCustomer int,
taskProductNameAtCreation varchar(50),
accountID varchar(50),
accountName varchar(50),
mappingType varchar(50),
type1_opportunityID varchar(50),
type1_opportunityName varchar(100),
type1_opportunityCreatedDate datetime,
type1_opportunityStage varchar(50),
type1_opportunityARR dec(10,2),
type1_opportunityCommishARR dec(10,2),
type1_opportunityOwnerID varchar(50),
type1_opportunityOwner varchar(50),
type1_opportunityCloseDate date,
type1_opportunityDateDiff int,
type1_opportunityClosedWon varchar(50),
type1_opportunityCycleTime int,
type2_opportunityID varchar(50),
type2_opportunityName varchar(100),
type2_opportunityCreatedDate datetime,
type2_opportunityStage varchar(50),
type2_opportunityARR dec(10,2),
type2_opportunityCommishARR dec(10,2),
type2_opportunityOwnerID varchar(50),
type2_opportunityOwner varchar(50),
type2_opportunityCloseDate date,
type2_opportunityDateDiff int,
type2_opportunityClosedWon varchar(50),
type2_opportunityCycleTime int,
type3_opportunityID varchar(50),
type3_opportunityName varchar(100),
type3_opportunityCreatedDate datetime,
type3_opportunityStage varchar(50),
type3_opportunityARR dec(10,2),
type3_opportunityCommishARR dec(10,2),
type3_opportunityOwnerID varchar(50),
type3_opportunityOwner varchar(50),
type3_opportunityCloseDate date,
type3_opportunityDateDiff int,
type3_opportunityClosedWon varchar(50),
type3_opportunityCycleTime int,
primary key (taskID, type1_opportunityID, type2_opportunityID, type3_opportunityID),
index (taskCreatedDate),
index (taskOwnerID),
index (taskOpportunityID),
index (taskWhoID),
index (taskDomain),
index (mappingType),
index (leadEmailAddress),
index (contactEmailAddress),
index (type1_opportunityCreatedDate),
index (type2_opportunityCreatedDate),
index (type3_opportunityCreatedDate));

INSERT IGNORE INTO rpt_workspace.js_nonTrialTracking(taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOpportunityID, taskWhoID, taskTTTC, taskStatus,
type1_opportunityID, type1_opportunityName, type1_opportunityCreatedDate, type1_opportunityStage, type1_opportunityARR, type1_opportunityCommishARR, type1_opportunityOwnerID, type1_opportunityOwner, type1_opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhatID, A.WhoID, A.Time_To_Task_Completion__c, A.Status,
B.Id, B.Name, B.CreatedDate, B.StageName, B.Amount, B.Commissionable_ACV__c, B.OwnerID, concat(C.FirstName,' ',C.LastName), B.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.opportunity B
ON A.WhatID=B.Id
JOIN ss_sfdc_02.user C
ON B.OwnerId=C.Id
WHERE A.Traffic_Source__c != '';
	
update rpt_workspace.js_nonTrialTracking
set type1_opportunityDateDiff=datediff(type1_opportunityCreatedDate, taskCreatedDate);

update rpt_workspace.js_nonTrialTracking
set type1_opportunityClosedWon=type1_opportunityID
where type1_opportunityStage='Closed Won';

update rpt_workspace.js_nonTrialTracking
set type1_opportunityCycleTime=datediff(type1_opportunityCloseDate, taskCreatedDate)
where type1_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
join ss_sfdc_02.opportunity_contact_role C
on B.Id=C.ContactId
join ss_sfdc_02.opportunity D
on C.OpportunityID=D.Id
join ss_sfdc_02.user E
on D.OwnerId=E.Id
set A.type2_opportunityID=D.Id, A.type2_opportunityName=D.Name, A.type2_opportunityCreatedDate=D.CreatedDate, A.type2_opportunityStage=D.StageName, A.type2_opportunityARR=D.Amount, 
A.type2_opportunityCommishARR=D.Commissionable_ACV__c, A.type2_opportunityOwnerID=D.OwnerID, A.type2_opportunityOwner=concat(E.FirstName,' ',E.LastName), A.type2_opportunityCloseDate=D.CloseDate
where D.CreatedDate >= date(A.taskCreatedDate) and D.CreatedDate < date_add(A.taskCreatedDate, interval 60 day) and A.type1_opportunityID=D.Id;

update rpt_workspace.js_nonTrialTracking
set type2_opportunityDateDiff=datediff(type2_opportunityCreatedDate, taskCreatedDate);

update rpt_workspace.js_nonTrialTracking
set type2_opportunityClosedWon=type2_opportunityID
where type2_opportunityStage='Closed Won';

update rpt_workspace.js_nonTrialTracking
set type2_opportunityCycleTime=datediff(type2_opportunityCloseDate, taskCreatedDate)
where type2_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
join ss_sfdc_02.opportunity C
on B.AccountId=C.AccountId
join ss_sfdc_02.user D
on C.OwnerId=D.Id
set A.type3_opportunityID=C.Id, A.type3_opportunityName=C.Name, A.type3_opportunityCreatedDate=C.CreatedDate, A.type3_opportunityStage=C.StageName, A.type3_opportunityARR=C.Amount, 
A.type3_opportunityCommishARR=C.Commissionable_ACV__c, A.type3_opportunityOwnerID=C.OwnerID, A.type3_opportunityOwner=concat(D.FirstName,' ',D.LastName), A.type3_opportunityCloseDate=C.CloseDate
where C.CreatedDate >= A.taskCreatedDate and C.CreatedDate < date_add(A.taskCreatedDate, interval 60 day) and A.type1_opportunityID=C.Id;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityDateDiff=datediff(type3_opportunityCreatedDate, taskCreatedDate);

update rpt_workspace.js_nonTrialTracking
set type3_opportunityClosedWon=type3_opportunityID
where type3_opportunityStage='Closed Won';

update rpt_workspace.js_nonTrialTracking
set type3_opportunityCycleTime=datediff(type3_opportunityCloseDate, taskCreatedDate)
where type3_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking
set mappingType=
case when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID='' then 1 
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID='' then 2 
when type1_opportunityID='' and type2_opportunityID='' and type3_opportunityID!='' then 3 
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID='' then 12
when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID!='' then 13
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID!='' then 23
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID!='' then 123
else 0 end;

drop table if exists rpt_workspace.js_nonTrialTrackingStaging;
create table if not exists rpt_workspace.js_nonTrialTrackingStaging
(opportunityID varchar(50),
primary key (opportunityID));

insert ignore into rpt_workspace.js_nonTrialTrackingStaging
select type1_opportunityID from rpt_workspace.js_nonTrialTracking
where type1_opportunityID!='';

INSERT IGNORE INTO rpt_workspace.js_nonTrialTracking(taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOpportunityID, taskWhoID, taskTTTC, taskStatus,
type2_opportunityID, type2_opportunityName, type2_opportunityCreatedDate, type2_opportunityStage, type2_opportunityARR, type2_opportunityCommishARR, type2_opportunityOwnerID, type2_opportunityOwner, type2_opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhatID, A.WhoID, A.Time_To_Task_Completion__c, A.Status,
D.Id, D.Name, D.CreatedDate, D.StageName, D.Amount, D.Commissionable_ACV__c, D.OwnerID, concat(E.FirstName,' ',E.LastName), D.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.contact B 
ON A.WhoID=B.Id
JOIN ss_sfdc_02.opportunity_contact_role C
ON B.Id=C.ContactId
JOIN ss_sfdc_02.opportunity D
ON C.OpportunityID=D.Id
JOIN ss_sfdc_02.user E
ON D.OwnerId=E.Id
LEFT JOIN rpt_workspace.js_nonTrialTrackingStaging F
ON D.Id=F.opportunityID
WHERE A.Traffic_Source__c != ''  and F.opportunityID is null and 
D.CreatedDate >= A.CreatedDate and D.CreatedDate < date_add(A.CreatedDate, interval 60 day);

update rpt_workspace.js_nonTrialTracking
set type2_opportunityDateDiff=datediff(type2_opportunityCreatedDate, taskCreatedDate)
where mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type2_opportunityClosedWon=type2_opportunityID
where type2_opportunityStage='Closed Won' and mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type2_opportunityCycleTime=datediff(type2_opportunityCloseDate, taskCreatedDate)
where mappingType is null and type2_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
join ss_sfdc_02.opportunity C
on B.AccountId=C.AccountId
join ss_sfdc_02.user D
on C.OwnerId=D.Id
set A.type3_opportunityID=C.Id, A.type3_opportunityName=C.Name, A.type3_opportunityCreatedDate=C.CreatedDate, A.type3_opportunityStage=C.StageName, A.type3_opportunityARR=C.Amount, 
A.type3_opportunityCommishARR=C.Commissionable_ACV__c, A.type3_opportunityOwnerID=C.OwnerID, A.type3_opportunityOwner=concat(D.FirstName,' ',D.LastName), A.type3_opportunityCloseDate=C.CloseDate
where C.CreatedDate >= A.taskCreatedDate and C.CreatedDate < date_add(A.taskCreatedDate, interval 60 day) and A.type2_opportunityID=C.Id and A.mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityDateDiff=datediff(type3_opportunityCreatedDate, taskCreatedDate)
where mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityClosedWon=type3_opportunityID
where type3_opportunityStage='Closed Won' and mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityCycleTime=datediff(type3_opportunityCloseDate, taskCreatedDate)
where mappingType is null and type3_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking
set mappingType=
case when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID='' then 1 
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID='' then 2 
when type1_opportunityID='' and type2_opportunityID='' and type3_opportunityID!='' then 3 
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID='' then 12
when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID!='' then 13
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID!='' then 23
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID!='' then 123
else 0 end;

drop table if exists rpt_workspace.js_nonTrialTrackingStaging2;
create table if not exists rpt_workspace.js_nonTrialTrackingStaging2
(opportunityID varchar(50),
primary key (opportunityID));

insert ignore into rpt_workspace.js_nonTrialTrackingStaging2
select type2_opportunityID from rpt_workspace.js_nonTrialTracking
where type2_opportunityID!='';

INSERT IGNORE INTO rpt_workspace.js_nonTrialTracking(taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOpportunityID, taskWhoID, taskTTTC, taskStatus,
type3_opportunityID, type3_opportunityName, type3_opportunityCreatedDate, type3_opportunityStage, type3_opportunityARR, type3_opportunityCommishARR, type3_opportunityOwnerID, type3_opportunityOwner, type3_opportunityCloseDate)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhatID, A.WhoID, A.Time_To_Task_Completion__c, A.Status,
C.Id, C.Name, C.CreatedDate, C.StageName, C.Amount, C.Commissionable_ACV__c, C.OwnerID, concat(D.FirstName,' ',D.LastName), C.CloseDate
FROM ss_sfdc_02.task A
JOIN ss_sfdc_02.contact B 
ON A.WhoID=B.Id
JOIN ss_sfdc_02.opportunity C
ON B.AccountId=C.AccountId
JOIN ss_sfdc_02.user D
ON C.OwnerId=D.Id
LEFT JOIN rpt_workspace.js_nonTrialTrackingStaging2 E
ON C.Id=E.opportunityID
WHERE A.Traffic_Source__c != ''  and E.opportunityID is null and 
C.CreatedDate >= A.CreatedDate and C.CreatedDate < date_add(A.CreatedDate, interval 60 day);

update rpt_workspace.js_nonTrialTracking
set type3_opportunityDateDiff=datediff(type3_opportunityCreatedDate, taskCreatedDate)
where mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityClosedWon=type3_opportunityID
where type3_opportunityStage='Closed Won' and mappingType is null;

update rpt_workspace.js_nonTrialTracking
set type3_opportunityCycleTime=datediff(type3_opportunityCloseDate, taskCreatedDate)
where mappingType is null and type3_opportunityClosedWon is not null;

update rpt_workspace.js_nonTrialTracking
set mappingType=
case when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID='' then 1 
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID='' then 2 
when type1_opportunityID='' and type2_opportunityID='' and type3_opportunityID!='' then 3 
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID='' then 12
when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID!='' then 13
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID!='' then 23
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID!='' then 123
else 0 end;

update rpt_workspace.js_nonTrialTracking A
left join ss_sfdc_02.lead B
on A.taskWhoID=B.Id
left join ss_sfdc_02.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join ss_sfdc_02.account D
on C.Account__c=D.Id
set A.leadName=concat(B.FirstName,' ',B.LastName), A.leadEmailAddress=B.Email, A.leadTitle=B.Title, A.accountID=D.Id, A.accountName=D.Name;

update rpt_workspace.js_nonTrialTracking A
left join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
left join ss_sfdc_02.account C
on B.AccountId=C.Id
set A.contactName=concat(B.FirstName,' ',B.LastName), A.contactEmailAddress=B.Email, A.contactTitle=B.Title, A.accountID=C.Id, A.accountName=C.Name;

delete from rpt_workspace.js_nonTrialTracking
where accountName like 'ISP Account%' and mappingType=3;

drop table if exists rpt_workspace.js_nonTrialTrackingStaging3;
create table if not exists rpt_workspace.js_nonTrialTrackingStaging3
(taskID varchar(50),
primary key (taskID));

insert ignore into rpt_workspace.js_nonTrialTrackingStaging3
select taskID from rpt_workspace.js_nonTrialTracking;

INSERT INTO rpt_workspace.js_nonTrialTracking(taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOpportunityID, taskWhoID, taskTTTC, taskStatus)
SELECT A.Id, A.Traffic_Source__c,
TRIM(LEFT(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') - 1))), -- returns left most part
TRIM(SUBSTRING(A.Traffic_Source__c, (INSTR(A.Traffic_Source__c, '/') + 1))), -- returns right most part
A.CreatedDate, A.SUBJECT, A.OwnerID, A.WhatID, A.WhoID, A.Time_To_Task_Completion__c, A.Status
FROM ss_sfdc_02.task A
LEFT JOIN rpt_workspace.js_nonTrialTrackingStaging3 B
on A.Id=B.taskID
WHERE A.Traffic_Source__c != '' AND B.taskID IS NULL;

update rpt_workspace.js_nonTrialTracking
set mappingType=
case when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID='' then 1 
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID='' then 2 
when type1_opportunityID='' and type2_opportunityID='' and type3_opportunityID!='' then 3 
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID='' then 12
when type1_opportunityID!='' and type2_opportunityID='' and type3_opportunityID!='' then 13
when type1_opportunityID='' and type2_opportunityID!='' and type3_opportunityID!='' then 23
when type1_opportunityID!='' and type2_opportunityID!='' and type3_opportunityID!='' then 123
else 0 end;

UPDATE rpt_workspace.js_nonTrialTracking A
SET A.taskSource = "None"
WHERE A.taskSource IS NULL OR A.taskSource = '';

UPDATE rpt_workspace.js_nonTrialTracking A
SET A.taskSubSource = "None"
WHERE A.taskSubSource IS NULL OR A.taskSubSource = '';

UPDATE rpt_workspace.js_nonTrialTracking A
JOIN ss_sfdc_02.user B ON A.taskOwnerID=B.Id
JOIN ss_sfdc_02.user_role C ON B.userRoleID=C.Id
SET
A.taskOwner = CONCAT(B.FirstName,' ',B.LastName),
A.taskOwnerRole = C.Name;

update rpt_workspace.js_nonTrialTracking A
join ss_sfdc_02.lead B
on A.taskWhoID=B.Id
left join ss_sfdc_02.domain C
on B.Domain__c=C.Domain_Name_URL__c
left join ss_sfdc_02.account D
on C.Account__c=D.Id
set A.leadName=concat(B.FirstName,' ',B.LastName), A.leadEmailAddress=B.Email, A.leadTitle=B.Title, A.accountID=D.Id, A.accountName=D.Name;

update rpt_workspace.js_nonTrialTracking A
join ss_sfdc_02.contact B
on A.taskWhoID=B.Id
left join ss_sfdc_02.account C
on B.AccountId=C.Id
set A.contactName=concat(B.FirstName,' ',B.LastName), A.contactEmailAddress=B.Email, A.contactTitle=B.Title, A.accountID=C.Id, A.accountName=C.Name;

update rpt_workspace.js_nonTrialTracking
set taskDomain=(SUBSTR(leadEmailAddress, INSTR(leadEmailAddress, '@') + 1))
where leadName is not null;

update rpt_workspace.js_nonTrialTracking
set taskDomain=(SUBSTR(contactEmailAddress, INSTR(contactEmailAddress, '@') + 1))
where contactName is not null;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.arc_ISPDomains B
on A.taskDomain=B.domain
set A.ISP=1;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.ref_Oct2016fortune1000 B
on A.taskDomain=B.domain
set taskIsFortune1000=1;

drop table if exists rpt_workspace.js_allDomainsPurchased;
create table if not exists rpt_workspace.js_allDomainsPurchased
select domain, min(winDate) as winDate from rpt_workspace.cDunn_allPlansPurchased 
group by 1;

alter table rpt_workspace.js_allDomainsPurchased
add index (domain),
add index (winDate);

update rpt_workspace.js_nonTrialTracking A
join rpt_workspace.js_allDomainsPurchased B
on A.taskDomain=B.domain and A.taskCreatedDate >= B.winDate
set A.existingCustomer=1;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.userAccount B
on A.leadEmailAddress=B.emailAddress
set A.leadUserID=B.userID;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.userAccount B
on A.contactEmailAddress=B.emailAddress
set A.contactUserID=B.userID;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.hist_paymentProfile B
on A.leadUserID=B.ownerID and B.accountType!=3 and B.modifyDateTime <= A.taskCreatedDate and B.hist_effectiveThruDateTime > A.taskCreatedDate
set A.taskProductNameAtCreation=rpt_main_02.SMARTSHEET_PRODUCTNAME(B.productID)
where A.leadName is not null;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.hist_paymentProfile B
on A.contactUserID=B.ownerID and B.accountType!=3 and B.modifyDateTime <= A.taskCreatedDate and B.hist_effectiveThruDateTime > A.taskCreatedDate
set A.taskProductNameAtCreation=rpt_main_02.SMARTSHEET_PRODUCTNAME(B.productID)
where A.contactName is not null;

update rpt_workspace.js_nonTrialTracking
set taskProductNameAtCreation='Free / Cancelled'
where taskProductNameAtCreation in ('Free','Cancelled');

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.userAccount B
on A.leadEmailAddress=B.emailAddress
set taskProductNameAtCreation='Collab'
where A.taskCreatedDate > B.insertDateTime and A.taskProductNameAtCreation is null;

update rpt_workspace.js_nonTrialTracking A
join rpt_main_02.userAccount B
on A.contactEmailAddress=B.emailAddress
set taskProductNameAtCreation='Collab'
where A.taskCreatedDate > B.insertDateTime and A.taskProductNameAtCreation is null;

update rpt_workspace.js_nonTrialTracking 
set accountID=null, accountName=null
where accountID='' or ISP=1;

update rpt_workspace.js_nonTrialTracking
set taskSource=taskSubSource, taskSubSource='None'
where taskSource='None';

drop table if exists rpt_workspace.js_nonTrialTrackingFinal;
create table if not exists rpt_workspace.js_nonTrialTrackingFinal

select taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOwner, taskOwnerRole, taskOpportunityID, taskWhoID, leadName, leadEmailAddress, leadTitle, 
contactName, contactEmailAddress, contactTitle, taskDomain, taskIsFortune1000, existingCustomer, taskProductNameAtCreation, accountID, accountName, mappingType, type1_opportunityID as opportunityID, 
type1_opportunityName as opportunityName, type1_opportunityStage as opportunityStage, type1_opportunityARR as opportunityARR, 
type1_opportunityCommishARR as opportunityCommishARR, type1_opportunityOwnerID as opportunityOwnerID, type1_opportunityOwner as opportunityOwner, 
type1_opportunityCreatedDate as opportunityCreatedDate, type1_opportunityCloseDate as opportunityCloseDate, type1_opportunityDateDiff as leadCreatedOppCreatedDateDiff, type1_opportunityClosedWon as opportunityClosedWon, 
type1_opportunityCycleTime as opportunityCycleTime, taskTTTC, taskStatus, leadUserID, contactUserID from rpt_workspace.js_nonTrialTracking
where mappingType in (0,1,12,13,123)

union

select taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOwner, taskOwnerRole, taskOpportunityID, taskWhoID, leadName, leadEmailAddress, leadTitle, 
contactName, contactEmailAddress, contactTitle, taskDomain, taskIsFortune1000, existingCustomer, taskProductNameAtCreation, accountID, accountName, mappingType, type2_opportunityID as opportunityID, 
type2_opportunityName as opportunityName, type2_opportunityStage as opportunityStage, type2_opportunityARR as opportunityARR, 
type2_opportunityCommishARR as opportunityCommishARR, type2_opportunityOwnerID as opportunityOwnerID, type2_opportunityOwner as opportunityOwner, 
type2_opportunityCreatedDate as opportunityCreatedDate, type2_opportunityCloseDate as opportunityCloseDate, type2_opportunityDateDiff as leadCreatedOppCreatedDateDiff, type2_opportunityClosedWon as opportunityClosedWon,
type2_opportunityCycleTime as opportunityCycleTime, taskTTTC, taskStatus, leadUserID, contactUserID from rpt_workspace.js_nonTrialTracking
where mappingType in (2,23)

union 

select taskID, trafficSource, taskSource, taskSubSource, taskCreatedDate, taskSubject, taskOwnerID, taskOwner, taskOwnerRole, taskOpportunityID, taskWhoID, leadName, leadEmailAddress, leadTitle, 
contactName, contactEmailAddress, contactTitle, taskDomain, taskIsFortune1000, existingCustomer, taskProductNameAtCreation, accountID, accountName, mappingType, type3_opportunityID as opportunityID, 
type3_opportunityName as opportunityName, type3_opportunityStage as opportunityStage, type3_opportunityARR as opportunityARR, 
type3_opportunityCommishARR as opportunityCommishARR, type3_opportunityOwnerID as opportunityOwnerID, type3_opportunityOwner as opportunityOwner, 
type3_opportunityCreatedDate as opportunityCreatedDate, type3_opportunityCloseDate as opportunityCloseDate, type3_opportunityDateDiff as leadCreatedOppCreatedDateDiff, type3_opportunityClosedWon as opportunityClosedWon,
type3_opportunityCycleTime as opportunityCycleTime, taskTTTC, taskStatus, leadUserID, contactUserID from rpt_workspace.js_nonTrialTracking
where mappingType=3

order by taskCreatedDate desc;

update rpt_workspace.js_nonTrialTrackingFinal
set opportunityName=replace(opportunityName,'\r','');

update rpt_workspace.js_nonTrialTrackingFinal
set opportunityName=replace(opportunityName,'\n','');

update rpt_workspace.js_nonTrialTrackingFinal
set taskTTTC=null
where taskTTTC=0;

alter table rpt_workspace.js_nonTrialTrackingFinal
add followUpActivityCount int,
add index (leadEmailAddress),
add index (contactEmailAddress);

update rpt_workspace.js_nonTrialTrackingFinal A
set followUpActivityCount=
(select count(distinct B.Id) from ss_sfdc_02.task B
join ss_sfdc_02.lead C
on B.WhoId=C.Id 
where A.leadEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.taskCreatedDate, interval 30 day) and B.LastModifiedDate > A.taskCreatedDate)
where leadEmailAddress is not null;

update rpt_workspace.js_nonTrialTrackingFinal A
set followUpActivityCount=
(select count(distinct B.Id) from ss_sfdc_02.task B
join ss_sfdc_02.contact C
on B.WhoId=C.Id 
where A.contactEmailAddress=C.Email and B.Traffic_Source__c ='' and B.LastModifiedDate <= date_add(A.taskCreatedDate, interval 30 day) and B.LastModifiedDate > A.taskCreatedDate)
where contactEmailAddress is not null;

drop table if exists rpt_workspace.js_nonTrialTrackingFinalCopy;
create table if not exists rpt_workspace.js_nonTrialTrackingFinalCopy like rpt_workspace.js_nonTrialTrackingFinal;
insert into rpt_workspace.js_nonTrialTrackingFinalCopy select * from rpt_workspace.js_nonTrialTrackingFinal;

alter table rpt_workspace.js_nonTrialTrackingFinalCopy
add index (opportunityID),
add index (taskID);

alter table rpt_workspace.js_nonTrialTrackingFinal
add taskCount int,
add followUpActivityCountCalc dec(10,2),
add taskTTTCCalc dec(10,2),
add opportunityCount int,
add opportunityARRCalc dec(10,2);

update rpt_workspace.js_nonTrialTrackingFinal A
set taskCount=
(select count(*) from rpt_workspace.js_nonTrialTrackingFinalCopy B
where A.taskID=B.taskID);

update rpt_workspace.js_nonTrialTrackingFinal
set followUpActivityCountCalc=followUpActivityCount/taskCount;

update rpt_workspace.js_nonTrialTrackingFinal
set taskTTTCCalc=taskTTTC/taskCount;

update rpt_workspace.js_nonTrialTrackingFinal A
set opportunityCount=
(select count(*) from rpt_workspace.js_nonTrialTrackingFinalCopy B
where A.opportunityID=B.opportunityID and B.opportunityID!='')
where A.opportunityID!='';

update rpt_workspace.js_nonTrialTrackingFinal
set opportunityARRCalc=opportunityARR/opportunityCount;

alter table rpt_workspace.js_nonTrialTrackingFinal
add securityPack varchar(10),
add integrationPack varchar(10),
add sights varchar(10),
add salesforce varchar(10),
add pcc varchar(10),
add jira varchar(10),
add strongLead int,
add companySize varchar(50),
add index (taskDomain),
add index (opportunityID),
add index (leadUserID),
add index (contactUserID);

update rpt_workspace.js_nonTrialTrackingFinal A
join ss_sfdc_02.opportunity B
on A.opportunityId=B.Id 
set A.securityPack=B.Security_Pack__c, A.integrationPack=B.Integration_Pack__c, A.sights=B.Dashboards__c, A.salesforce=B.Salesforce_Integration__c, 
A.pcc=B.Project_Control_Center__c, A.jira=B.Jira_Integration__c;

update rpt_workspace.js_nonTrialTrackingFinal A
join rpt_main_02.stg_tableauTrialReport B
on A.leadUserID=B.userID
set A.strongLead=B.IsStrongLead
where A.leadUserID is not null;

update rpt_workspace.js_nonTrialTrackingFinal A
join rpt_main_02.stg_tableauTrialReport B
on A.contactUserID=B.userID
set A.strongLead=B.IsStrongLead
where A.contactUserID is not null;

update rpt_workspace.js_nonTrialTrackingFinal A
join rpt_workspace.pj_domainDataCoverage B
on A.taskDomain=B.domain
set A.companySize=B.companySize;

select * from rpt_workspace.js_nonTrialTrackingFinal;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("nonTrialLeadsReportingV2.sql");

