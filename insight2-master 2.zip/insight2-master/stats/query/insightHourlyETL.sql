set session transaction isolation level read uncommitted;

/***************************************************************************************************************************/
/* This is running every Hour.  We use it to push data from large tables: ex: archiving clientEvent and requestLog  	*/
/***************************************************************************************************************************/
SELECT MAX(gridID) 					FROM ss_core_02.grid  INTO @NewMaxgridID;
SELECT MAX(userID) 					FROM ss_core_02.userAccount  INTO @NewMaxuserID;

-- set session transaction isolation level repeatable read;


SELECT 5 INTO @logLevelCtrlNum;     #DEBUG:5, INFO:4, WARN:3, ERROR:2, FATAL:1, OFF:0
SELECT 0 INTO @parentProcessId;
                                              
call utl_logProcessStart('prepV2DataCorePull','insightHourlyETL,'','INFO',@logLevelCtrlNum, @parentProcessId);

call etl_userAccount(@NewMaxuserID,@parentProcessId,@logLevelCtrlNum);
call etl_grid(@parentProcessId,@logLevelCtrlNum);
call etl_gridAccessMap(@parentProcessId,@logLevelCtrlNum);
call etl_ClientEvent(@parentProcessId,@logLevelCtrlNum);
call etl_RequestLog(@parentProcessId,@logLevelCtrlNum);

call utl_logProcessStart(@parentProcessId);




	
	
  
