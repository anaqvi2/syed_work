SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* SELECT docAttachment.containerID AS AttachmentContainer, docAttachment.docAttachmentID, 
CASE docAttachment.attachmentType
	WHEN 1 THEN "File"
	WHEN 2 THEN "Google Drive"
	WHEN 3 THEN "Link"
	WHEN 4 THEN "Box"
	WHEN 5 THEN "Dropbox"
	WHEN 6 THEN "Evernote"
	ELSE "Other" END AS AttachmentType, 
CASE docAttachment.docType
	WHEN 0 THEN 'OTHER'
WHEN 1 THEN 'WORD'
WHEN 2 THEN 'EXCEL'
WHEN 3 THEN 'POWERPOINT'
WHEN 4 THEN 'PDF'
WHEN 5 THEN 'TEXT'
WHEN 6 THEN 'ZIP'
WHEN 7 THEN 'PROJECT'
WHEN 8 THEN 'WORDX'
WHEN 9 THEN 'POWERPOINTX'
WHEN 10 THEN 'EXCELX'
WHEN 11 THEN 'PNG'
WHEN 12 THEN 'JPEG'
WHEN 13 THEN 'GIF'
WHEN 14 THEN 'IMAGE'
WHEN 15 THEN 'HTML'
WHEN 16 THEN 'VCF'
WHEN 17 THEN 'MSG'
WHEN 18 THEN 'MP3'
WHEN 19 THEN 'WMV'
WHEN 20 THEN 'GOOGLEDOC'
WHEN 21 THEN 'GOOGLESPREADSHEET'
WHEN 22 THEN 'GOOGLEPRESENTATION'
WHEN 23 THEN 'GOOGLEPDF'
WHEN 24 THEN 'LINK'
WHEN 25 THEN 'BACKUP'
WHEN 26 THEN 'GOOGLEFILE'
WHEN 27 THEN 'ICAL'
WHEN 28 THEN 'SVG'
WHEN 29 THEN 'XML'
WHEN 30 THEN 'GOOGLEDRAWING'
WHEN 31 THEN 'BOXFOLDER'
WHEN 32 THEN 'BOXWEBDOC'
ELSE "OTher" END AS DocumentType,
docAttachmentView.insertDateTime AS AttachmentViewDateTime,
docAttachmentView.insertByUserID AS AttachmentViewUserID,
userAccount.emailAddress AS AttachmentViewUserEmail
FROM ss_core_02.docAttachment
JOIN ss_core_02.docAttachmentView ON docAttachment.docAttachmentID = docAttachmentView.docAttachmentID
LEFT OUTER JOIN rpt_main_02.userAccount ON docAttachmentView.insertByUserID = userAccount.userID
WHERE docAttachment.attachmentCreatedByUserID = 4310613 AND docAttachment.insertByUserID = 4310613 AND docAttachmentView.insertByUserID != 0;

*/