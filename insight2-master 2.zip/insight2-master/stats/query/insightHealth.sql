
/***************************************************************************************************************************/
/* This is running every 5 minutes, so it has to run super fast...			*/
/***************************************************************************************************************************/




/*
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_insightHealth(
	healthCheckDate				DATETIME, 
	replicationLastRecordDate	DATETIME,
	replicationDelaySeconds		mediumint unsigned,

	KEY(healthCheckDate));
*/


SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT "************************************* start rows: " ,ROW_COUNT(), NOW();

-- Check ss_core_02 latency
SELECT MAX(sessionLogID) FROM ss_core_02.sessionLog INTO @MaxSessionLogID;
SELECT "************************************* Core MAX(sessionLogID) rows: " ,ROW_COUNT(), NOW();

INSERT rpt_main_02.arc_insightHealth(healthCheckDate, replicationLastRecordDate, replicationDelaySeconds)
SELECT NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) FROM ss_core_02.sessionLog WHERE sessionLogID = @MaxSessionLogID;
SELECT "************************************* INSERT rpt_main_02.arc_insightHealth rows: " ,ROW_COUNT(), NOW();

-- Check ss_account_02 latency
SELECT MAX(signupRequestTrackingItemID) FROM ss_account_02.signupRequestTrackingItem INTO @MaxAccountID;
SELECT "************************************* Account MAX(signupRequestTrackingItemID) rows: " ,ROW_COUNT(), NOW();

INSERT rpt_main_02.arc_insightHealthAccount(healthCheckDate, replicationLastRecordDate, replicationDelaySeconds)
SELECT NOW(), MAX(insertDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), insertDateTime)) FROM ss_account_02.signupRequestTrackingItem WHERE signupRequestTrackingItemID = @MaxAccountID;
SELECT "************************************* INSERT rpt_main_02.arc_insightHealthAccount rows: " ,ROW_COUNT(), NOW();

-- Check ss_log_02 latency
SELECT MAX(clientEventID) FROM ss_log_02.clientEvent INTO @MaxClientEventID;
SELECT "************************************* Log MAX(clientEventID) rows: " ,ROW_COUNT(), NOW();

INSERT rpt_main_02.arc_insightHealthLog(healthCheckDate, replicationLastRecordDate, replicationDelaySeconds)
SELECT NOW(), MAX(eventDateTime), TIME_TO_SEC(TIMEDIFF(NOW(), eventDateTime)) FROM ss_log_02.clientEvent WHERE clientEventID = @MaxClientEventID;
SELECT "************************************* INSERT rpt_main_02.arc_insightHealth rows: " ,ROW_COUNT(), NOW();

SELECT * FROM information_schema.tokudb_lock_waits
LIMIT 1000;
SELECT "************************************* tokudb_lock_waits: " ,ROW_COUNT(), NOW();

SHOW FULL PROCESSLIST;

	
 
