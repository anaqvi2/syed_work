SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("netBookings3V2.sql");
/*
update rpt_workspace.js_quarterlyPerformance2 A
set strategicActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Strategic' and B.recordDate >= '2016-01-01' and B.recordDate < '2016-04-01' and B.recordDate <= A.dayDate)
where quarterYear='Q1 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set strategicActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Strategic' and B.recordDate >= '2016-04-01' and B.recordDate < '2016-07-01' and B.recordDate <= A.dayDate)
where quarterYear='Q2 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set strategicActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Strategic' and B.recordDate >= '2016-07-01' and B.recordDate < '2016-10-01' and B.recordDate <= A.dayDate)
where quarterYear='Q3 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set strategicActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Strategic' and B.recordDate >= '2016-10-01' and B.recordDate < '2017-01-01' and B.recordDate <= A.dayDate)
where quarterYear='Q4 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set strategicActualToDate=0
where strategicActualToDate is null and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set strategicActualPerBuyingDay=strategicActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set strategicActualTotal=strategicActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_quarterlyPerformance2 A
set customerSuccessActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Customer Success' and B.recordDate >= '2016-01-01' and B.recordDate < '2016-04-01' and B.recordDate <= A.dayDate)
where quarterYear='Q1 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set customerSuccessActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Customer Success' and B.recordDate >= '2016-04-01' and B.recordDate < '2016-07-01' and B.recordDate <= A.dayDate)
where quarterYear='Q2 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set customerSuccessActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Customer Success' and B.recordDate >= '2016-07-01' and B.recordDate < '2016-10-01' and B.recordDate <= A.dayDate)
where quarterYear='Q3 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set customerSuccessActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Customer Success' and B.recordDate >= '2016-10-01' and B.recordDate < '2017-01-01' and B.recordDate <= A.dayDate)
where quarterYear='Q4 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set customerSuccessActualToDate=0
where customerSuccessActualToDate is null and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set customerSuccessActualPerBuyingDay=customerSuccessActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set customerSuccessActualTotal=customerSuccessActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_quarterlyPerformance2 A
set partnerSalesActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Partner Sales' and B.recordDate >= '2016-01-01' and B.recordDate < '2016-04-01' and B.recordDate <= A.dayDate)
where quarterYear='Q1 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set partnerSalesActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Partner Sales' and B.recordDate >= '2016-04-01' and B.recordDate < '2016-07-01' and B.recordDate <= A.dayDate)
where quarterYear='Q2 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set partnerSalesActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Partner Sales' and B.recordDate >= '2016-07-01' and B.recordDate < '2016-10-01' and B.recordDate <= A.dayDate)
where quarterYear='Q3 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2 A
set partnerSalesActualToDate=
(select sum(ARR) from rpt_workspace.js_actualsStaging B
where A.recordType=B.recordType and assistedType='Partner Sales' and B.recordDate >= '2016-10-01' and B.recordDate < '2017-01-01' and B.recordDate <= A.dayDate)
where quarterYear='Q4 2016' and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set partnerSalesActualToDate=0
where partnerSalesActualToDate is null and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set partnerSalesActualPerBuyingDay=partnerSalesActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set partnerSalesActualTotal=partnerSalesActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_quarterlyPerformance2 A
join rpt_workspace.js_quarterlyPerformance B
set A.commercialActualToDate=B.commercialActualToDate
where A.dayDate=B.dayDate and A.recordType=B.recordType;

update rpt_workspace.js_quarterlyPerformance2
set commercialActualToDate=0
where commercialActualToDate is null and dayDate < current_date;

update rpt_workspace.js_quarterlyPerformance2
set commercialActualPerBuyingDay=commercialActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set commercialActualTotal=commercialActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_quarterlyPerformance2
set netBookingsActualToDate=commercialActualToDate+strategicActualToDate+customerSuccessActualToDate+partnerSalesActualToDate;

update rpt_workspace.js_quarterlyPerformance2
set netBookingsActualPerBuyingDay=netBookingsActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set netBookingsActualTotal=netBookingsActualPerBuyingDay*buyingDaysTotal;

update rpt_workspace.js_quarterlyPerformance2
set grossBookingsActualToDate=commercialActualToDate+strategicActualToDate+partnerSalesActualToDate;

update rpt_workspace.js_quarterlyPerformance2
set grossBookingsActualPerBuyingDay=grossBookingsActualToDate/buyingDaysToDate;

update rpt_workspace.js_quarterlyPerformance2
set grossBookingsActualTotal=grossBookingsActualPerBuyingDay*buyingDaysTotal;

select * from rpt_workspace.js_quarterlyPerformance2
where dayDate in (date_sub(current_date, interval 1 day), '2016-03-31', '2016-06-30', '2016-09-30')
order by recordType, dayDate;
*/
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("netBookings3V2.sql");

