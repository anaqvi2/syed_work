use test;

set session transaction isolation level read uncommitted;

# Column Count
select gcd.gridId, count(*) colCount
from ss_core_02.gridColumnDef gcd
where gcd.gridId in (
   select gridId
   from ss_core_02.grid
   where gridId > (
      select max(gridId) -100
      from ss_core_02.grid
                   )
                    )
group by gcd.gridId;



# Row Count
select gr.gridId, count(*) rowCount
from ss_core_02.gridRow gr
where gridId in (
select gridId
   from ss_core_02.grid
   where gridId > (
      select max(gridId) -100
      from ss_core_02.grid
                   )
                    
)
group by gr.gridId;

# Data Size
select count(*) from (
select gd.gridId
      ,sum(ifnull(length(dataString),0)+
           ifnull(length(cast(dataNumeric as char)),0)+
           ifnull(length(formulaDefinition),0)
          ) as size    
from ss_core_02.gridData gd
where gd.gridId in (
   select gridId
   from ss_core_02.grid
   where modifyDateTime between '2014-06-08' and '2014-06-09' 
                   )
group by gd.gridId
) x;

set session transaction isolation level repeatable read;


