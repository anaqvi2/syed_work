SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("BoostMediaAdwordsCampaignDataV2.csv");

SELECT
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y-%m-%d') AS 'SignupDate', 

	rpt_signupSourceUser.adVersion AS 'SignupAdID',
	COUNT(rpt_signupSourceUser.userID) AS UsersSignedUp,
	SUM(CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END) AS 'StrongLeads',

ROUND(SUM(CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 WHEN 1 THEN 
	CASE WHEN rpt_signupSourceUser.signupInsertDateTime < '2014-06-01 00:00:00' THEN ref_weightedStrongLeadFactor.weightedStrongLeadFactor
		ELSE wslf.weightedStrongLeadFactor END
ELSE 0 END),2) AS "WeightedStrongLeads",
SUM(CASE WHEN rpt_paymentProfile.countAsPaid IS NULL THEN 0 ELSE rpt_paymentProfile.countAsPaid END ) AS 'Count as Paid'

FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON rpt_userIPLocation.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.ref_weightedStrongLeadFactor ON rpt_userIPLocation.ipCountry = ref_weightedStrongLeadFactor.IPCountry
LEFT OUTER JOIN rpt_main_02.arc_cDunn_wslfOverTimeUpdate wslf 	ON wslf.IPCountry = rpt_userIPLocation.ipCountry
	AND rpt_signupSourceUser.signupInsertDateTime BETWEEN wslf.trialMonthStartDate AND wslf.trialMonthEndDate
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID AND  rpt_paymentProfile.accountType !=2
	
WHERE userAccount.insertDateTime  >= "2014-09-10" AND rpt_signupSourceUser.userID IS NOT NULL 
AND (subSourceFriendly LIKE "%Google%" OR subSourceFriendly = "_Bing Search") 
AND rpt_signupSourceUser.adVersion NOT LIKE "-%" AND rpt_signupSourceUser.adVersion IS NOT NULL
GROUP BY 1,2
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("BoostMediaAdwordsCampaignDataV2.csv");


