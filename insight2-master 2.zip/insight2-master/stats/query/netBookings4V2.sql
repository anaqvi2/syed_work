SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("netBookings4V2.sql");
/*
select dayDate, quarterYear, recordType, 
netBookingsActualToDate, netBookingsPlanTotal, 
grossBookingsActualToDate, grossBookingsPlanTotal, 
commercialActualToDate, commercialPlanTotal, 
strategicActualToDate, strategicPlanTotal,
partnerSalesActualToDate, partnerSalesPlanTotal,
customerSuccessActualToDate, customerSuccessPlanTotal 
from rpt_workspace.js_quarterlyPerformance2
where dayDate <= DATE_FORMAT(LAST_DAY(DATE_ADD(CURRENT_DATE, INTERVAL 2 MONTH)), '%Y-%m-%d');
*/
/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("netBookings4V2.sql");

