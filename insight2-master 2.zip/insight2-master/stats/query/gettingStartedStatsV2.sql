SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("gettingStartedStatsV2.sql");


/*
drop table if exists rpt_workspace.js_gettingStarted;
create table if not exists rpt_workspace.js_gettingStarted
(userID int,
signupInsertDateTime datetime,
slp varchar(100),
lx varchar(100),
country varchar(50),
language varchar(50),
createdSheet int,
PutYourProjectNameHere int,
EventPlanAndBudget int,
ToDoList int,
TeamTaskListByPriority int,
BlankSheet int,
AgileBacklogTemplate int,
ProductLaunchInCardView int,
TaskAndIssueTrackerTemplate int,
BasicProjectPlanTemplate int,
BlankKanbanSheet int,
BlankSheetTemplate int,
AgileProjectTemplateWithGantt int,
ContentCalendarTemplateWithGantt int,
primary key (userID));
*/

insert ignore into rpt_workspace.js_gettingStarted(userID, signupInsertDateTime, slp, lx)
select userID, signupInsertDateTime, A.slp, B.itemValue from rpt_main_02.rpt_signupSource A
join ss_account_02.signupRequestTrackingItem B
on A.signupRequestID=B.signupRequestID
where (A.slp in ('blog/gantt-chart-excel', 'c/online-gantt-chart', 's/global-online-gantt-chart', 'coordinate-anything-with-smartsheet', 
's/manage-agile-projects', 's/kanban-software', 's/scrum-software', 'c/agile-teams', 'c/card-view', 's/project-management-tool', 'c/marketing-teams', 'pricing',
" ") or A.slp is null) 
and A.signupInsertDateTime>='2016-02-22' and B.itemName='lx';

delete from rpt_workspace.js_gettingStarted
where lx not in ('pndEm-4V6AgqV0vutzZ_wA', 'X_yCY9mH5ywY9WKANazDYA', 'nMqd8fORueDwoZOLz2LpVQ', 'duH1Hj7ptdECV_UaNjYgjA', 'AU2SjHVum3_OGeTRphD2ow', 'aJEiMosb2GPFfT_6FdPD1Q', 'FhMOLwmv6G8RaaSSiSry1g', 'nMqd8fORueDwoZOLz2LpVQ')
and (slp in ('blog/gantt-chart-excel', 'c/online-gantt-chart', 's/global-online-gantt-chart', 's/manage-agile-projects', 's/kanban-software', 's/scrum-software', 
'c/agile-teams', 'c/card-view', 's/project-management-tool', 'c/marketing-teams', 'pricing'," ") or slp is null);

delete from rpt_workspace.js_gettingStarted
where lx not in ('pndEm-4V6AgqV0vutzZ_wA', 'lzzFrKFABKuL6c-g-0V_AA') and slp='coordinate-anything-with-smartsheet';

update rpt_workspace.js_gettingStarted
set slp='Home Page'
where slp is null;

update rpt_workspace.js_gettingStarted
set slp='Home Page'
where slp=" ";

update rpt_workspace.js_gettingStarted j
set country=
(select ipCountry from rpt_main_02.rpt_signupSource s
where j.userID=s.userID);

update rpt_workspace.js_gettingStarted j
join rpt_main_02.userAccount ua
on j.userID=ua.userID
set j.country=ua.countryFriendly
where j.country is null;

update rpt_workspace.js_gettingStarted j
join rpt_main_02.userAccount ua
on j.userID=ua.userID
set j.language=ua.languageFriendly;

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.createdSheet=1
where c.containerType=2;

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.PutYourProjectNameHere=1
where c.containerType=2 and c.sourceID='1000059';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.EventPlanAndBudget=1
where c.containerType=2 and c.sourceID='43711696';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.ToDoList=1
where c.containerType=2 and c.sourceID='2579912';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.TeamTaskListByPriority=1
where c.containerType=2 and c.sourceID='24420752';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.BlankSheet=1
where c.containerType=2 and c.sourceID='43712184';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.AgileBacklogTemplate=1
where c.containerType=2 and c.sourceID='50324875';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.ProductLaunchInCardView=1
where c.containerType=2 and c.sourceID='49872114';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.TaskAndIssueTrackerTemplate=1
where c.containerType=2 and c.sourceID='50153175';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.BasicProjectPlanTemplate=1
where c.containerType=2 and c.sourceID='50155916';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.BlankKanbanSheet=1
where c.containerType=2 and c.sourceID='49954102';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.BlankSheetTemplate=1
where c.containerType=2 and c.sourceID='50154296';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.AgileProjectTemplateWithGantt=1
where c.containerType=2 and c.sourceID='50326861';

update rpt_workspace.js_gettingStarted j
join rpt_main_02.container c
on j.userID=c.insertByUserID
set j.ContentCalendarTemplateWithGantt=1
where c.containerType=2 and c.sourceID='50069320';

update rpt_workspace.js_gettingStarted
set createdSheet=0
where createdSheet is null;

update rpt_workspace.js_gettingStarted
set PutYourProjectNameHere=0
where PutYourProjectNameHere is null;

update rpt_workspace.js_gettingStarted
set EventPlanAndBudget=0
where EventPlanAndBudget is null;

update rpt_workspace.js_gettingStarted
set ToDoList=0
where ToDoList is null;

update rpt_workspace.js_gettingStarted
set TeamTaskListByPriority=0
where TeamTaskListByPriority is null;

update rpt_workspace.js_gettingStarted
set BlankSheet=0
where BlankSheet is null;

update rpt_workspace.js_gettingStarted
set AgileBacklogTemplate=0
where AgileBacklogTemplate is null;

update rpt_workspace.js_gettingStarted
set ProductLaunchInCardView=0
where ProductLaunchInCardView is null;

update rpt_workspace.js_gettingStarted
set TaskAndIssueTrackerTemplate=0
where TaskAndIssueTrackerTemplate is null;

update rpt_workspace.js_gettingStarted
set BasicProjectPlanTemplate=0
where BasicProjectPlanTemplate is null;

update rpt_workspace.js_gettingStarted
set BlankKanbanSheet=0
where BlankKanbanSheet is null;

update rpt_workspace.js_gettingStarted
set BlankSheetTemplate=0
where BlankSheetTemplate is null;

update rpt_workspace.js_gettingStarted
set AgileProjectTemplateWithGantt=0
where AgileProjectTemplateWithGantt is null;

update rpt_workspace.js_gettingStarted
set ContentCalendarTemplateWithGantt=0
where ContentCalendarTemplateWithGantt is null;

select * from rpt_workspace.js_gettingStarted;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("gettingStartedStatsV2.sql");

