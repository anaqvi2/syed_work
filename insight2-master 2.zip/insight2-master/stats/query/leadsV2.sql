SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("leadsV2.csv");

/*Generating leadsV2.csv*/
SELECT  
	COUNT(u.userID) AS 'Lead Count',
	
	rpt_paymentProfile.productName AS 'Current Product Name',
		
	DATE_FORMAT((arc_userSessionActivity.firstSessionDateTime), '%Y-%m-%d') AS 'First Login Date',
	
	rpt_main_02.SMARTSHEET_WEEK(arc_userSessionActivity.firstSessionDateTime) AS 'First Login Week',
	
	DATE_FORMAT((arc_userSessionActivity.firstSessionDateTime), '%Y*%m(%b)') AS 'First Login Month',
			
	CASE rpt_signupSource.bucket IS NULL 
		WHEN 1 THEN "Viral"
		ELSE rpt_signupSource.bucket 
	END AS 'Bucket',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly 
	END AS 'Signup Source',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly 
	END AS 'Signup Sub-Source',
	
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN 0
		ELSE 1
	END AS 'User Signed Up',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
		
	CASE rpt_organizationUser.memberCount IS NULL
		WHEN 1 THEN 0
		ELSE rpt_organizationUser.memberCount
	END AS 'Is Org Member',
	
	CASE rpt_organizationUser.licenseUserCount IS NULL
		WHEN 1 THEN 0
		ELSE rpt_organizationUser.licenseUserCount
	END AS 'Is Org License User',
	
	CASE u.insertByUserID = 0
		WHEN 1 THEN 0
		ELSE 1
	END AS 'Inserted by Other',
	
	insertByPaymentProfile.productName AS 'Product of Sharer',
	
	CASE (u.statusFlags & 8)  
		WHEN 8 THEN '1'
		ELSE '0'
	END AS 'License Accepted',
	
	CASE (u.statusFlags & 4) 
		WHEN 4 THEN '1'
		ELSE '0'
	END AS 'Password Set',

	
	CASE u.domain = insertedByUser.domain
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Matching Domains',
	
	CASE u.domain IN 
	('Aol.com', 
	'att.net',
	'bellsouth.net',
	'bigpond.com',
	'bigpond.net.au',
	'btinternet.com',
	'comcast.net', 
	'cox.net',
	'charter.net',
	'earthlink.net',
	'gmail.com', 
	'googlemail.com', 
	'hotmail.com', 
	'hotmail.co.uk', 
	'hotmail.es', 
	'hotmail.fr', 
	'live.com', 
	'mac.com',
	'mail.com'
	'me.com',
	'msn.com', 
	'mweb.co.za',
	'optusnet.com.au',
	'orange.fr',
	'outlook.com',
	'prodigy.net.mx',
	'rogers.com',
	'sbcglobal.net', 
	'shaw.ca',
	'telus.net',
	'uol.com.br',
	'verizon.net', 
	'vodafone.co.nz',
	'westnet.com.au',
	'xtra.co.nz',
	'ymail.com'
	'yahoo.com', 
	'yahoo.co.in',
	'yahoo.co.uk', 
	'yahoo.com.br',
	'yahoo.es', 
	'yahoo.fr',
	'cfl.rr.com',
	'austin.rr.com',
	'nc.rr.com',
	'socal.rr.com',
	'ca.rr.com',
	'tx.rr.com',
	'tampabay.rr.com',
	'nc.rr.com',
	'san.rr.com',
	'wi.rr.com',
	'nycap.rr.com',
	'kc.rr.com',
	'tampabay.rr.com',
	'woh.rr.com',
	'tampabay.rr.com',
	'woh.rr.com',
	'carolina.rr.com') OR
	 insertedByUser.domain IN 
	('Aol.com', 
	'att.net',
	'bellsouth.net',
	'bigpond.com',
	'bigpond.net.au',
	'btinternet.com',
	'comcast.net', 
	'cox.net',
	'charter.net',
	'earthlink.net',
	'gmail.com', 
	'googlemail.com', 
	'hotmail.com', 
	'hotmail.co.uk', 
	'hotmail.es', 
	'hotmail.fr', 
	'live.com', 
	'mac.com',
	'mail.com'
	'me.com',
	'msn.com', 
	'mweb.co.za',
	'optusnet.com.au',
	'orange.fr',
	'outlook.com',
	'prodigy.net.mx',
	'rogers.com',
	'sbcglobal.net', 
	'shaw.ca',
	'telus.net',
	'uol.com.br',
	'verizon.net', 
	'vodafone.co.nz',
	'westnet.com.au',
	'xtra.co.nz',
	'ymail.com'
	'yahoo.com', 
	'yahoo.co.in',
	'yahoo.co.uk', 
	'yahoo.com.br',
	'yahoo.es', 
	'yahoo.fr',
	'cfl.rr.com',
	'austin.rr.com',
	'nc.rr.com',
	'socal.rr.com',
	'ca.rr.com',
	'tx.rr.com',
	'tampabay.rr.com',
	'nc.rr.com',
	'san.rr.com',
	'wi.rr.com',
	'nycap.rr.com',
	'kc.rr.com',
	'tampabay.rr.com',
	'woh.rr.com',
	'tampabay.rr.com',
	'woh.rr.com',
	'carolina.rr.com')
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User or Sharer has ISP Domain'

FROM rpt_main_02.userAccount u
LEFT OUTER JOIN rpt_main_02.rpt_signupSource 							ON u.userID = rpt_signupSource.userID 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  						ON u.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType !=3  /* could be multiple, only link to non-org */
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  insertByPaymentProfile	ON u.insertByUserID = insertByPaymentProfile.sourceUserID AND insertByPaymentProfile.accountType !=3   /* could be multiple, only link to non-org */
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived			ON u.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 						ON u.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 					ON u.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   				ON u.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_userSessionActivity						ON u.userID = arc_userSessionActivity.userID
LEFT OUTER JOIN rpt_main_02.rpt_organizationUser						ON u.userID = rpt_organizationUser.userID
LEFT OUTER JOIN rpt_main_02.userAccount	insertedByUser					ON u.insertByUserID = insertedByUser.userID

WHERE arc_userSessionActivity.firstSessionDateTime 
AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "Sunday"
GROUP BY 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19 /* grouping like leads together to reduce report size */
LIMIT 1234567890
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("leadsV2.csv");
