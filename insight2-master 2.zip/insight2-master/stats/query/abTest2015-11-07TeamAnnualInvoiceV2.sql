SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("abTest2015-11-07TeamAnnualInvoice_V2.sql");

drop table rpt_main_02.stg_abtest_paymentActions;
create table rpt_main_02.stg_abtest_paymentActions
select * from rpt_main_02.rpt_payment_waterfall_actions
where logDate > '2015-11-06';

create index uID on rpt_main_02.stg_abtest_paymentActions(insertbyuserID);
create index oID on rpt_main_02.stg_abtest_paymentActions(objectID);

drop table if exists rpt_main_02.stg_teamAnnualInvoice;
create table rpt_main_02.stg_teamAnnualInvoice
SELECT siteSettingElementValue.siteSettingElementName,
siteSettingElementValue.userID, 
siteSettingElementValue.valueNumeric,
DATE_FORMAT(siteSettingElementValue.insertDateTime, "%Y-%m-%d") AS insertDate,
rpt_trials.trialDateTime,
rpt_main_02.hist_paymentProfile.productID,
rpt_main_02.hist_paymentProfile.paymentStartDateTime,
rpt_loginCountTotal.firstSessionLogID, 
rpt_sessionLog.insertDateTime AS sessionDateTime,
rpt_sessionLog.signoutDateTime,
TIMEDIFF(rpt_sessionLog.signoutDateTime, rpt_sessionLog.insertDateTime) AS SessionTime,
/* COUNT(DISTINCT arc_clientEvent.clientEventID) */ null AS first5MinClientEvents,
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
	CASE rpt_signupSource.bucket IS NULL
		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket
	END AS 'Signup Bucket',
	       
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing" ELSE rpt_signupSource.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

rpt_clientLogCountsByUserArchived.firstDayLogCount,
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1 ELSE 0 END AS 'Is Strong Lead',
	COUNT(arc_wellQualifiedLeads.snapshotDate) AS WellQualCount,
	
	CASE COUNT(arc_wellQualifiedLeads.snapshotDate) > 0
	WHEN 1 THEN 1 ELSE 0 END AS 'EverWellQual',
rpt_featureCountRollupByUser.sharingCount,
rpt_containerCountsByUser.lifetimeSheetCount,
rpt_containerCountsByUser.sheetCount,
	CASE rpt_loginCountTotal.loginCount >= 2 
		WHEN 1 THEN 1 ELSE 0
	END AS 'User Logged In At Least Twice',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1 ELSE 0 END AS 'User Logged In At Least 4 Times',
-- rpt_paymentProfile.hasPaid,
case when rpt_paymentProfile.planrate_USD > 0 then 1 else 0 end as hasPaid,
	rpt_paymentProfile.daysToBuy,

	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 3 THEN 1 ELSE 0 
		END 
	END AS 'Basic?',
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 4 THEN 1 ELSE 0 
		END 
	END AS 'Advanced?',
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 7 THEN 1 ELSE 0 
		END 
	END AS 'Team?',
	CASE WHEN rpt_paymentProfile.productID < 3 THEN NULL ELSE 
		CASE WHEN rpt_paymentProfile.productID  = 6 THEN 1 ELSE 0 
		END 
	END AS 'Enterprise?',
	CASE WHEN rpt_paymentProfile.productID = 0 THEN 1 ELSE 0 END AS 'Cancelled?',
	rpt_paymentProfile.paymentStartDateClean,
	ip.ipCountry,
	userAccount.languageFriendly,
	CASE WHEN rpt_paymentProfile2.productID IN(3,4,6,7,10,11) THEN 1 ELSE 0 END AS CountAsPaidProduct,
    CASE WHEN rpt_paymentProfile.planRate_USD > 0 then (rpt_paymentProfile.planRate_USD/rpt_paymentProfile.paymentTerm) else 0 end as MRR,
    CASE WHEN pa.objectID is not null THEN '1' else 0 end as ViewedStep2or3
	
FROM rpt_main_02.siteSettingElementValue 
LEFT OUTER JOIN rpt_main_02.rpt_trials on rpt_main_02.rpt_trials.userID = siteSettingElementValue.userID and rpt_main_02.rpt_trials.trialDateTime > "2015-11-07 00:00:00" and trialType = '1' and firstTrial = '1'
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON siteSettingElementValue.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON siteSettingElementValue.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser ON siteSettingElementValue.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser ON siteSettingElementValue.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_wellQualifiedLeads ON siteSettingElementValue.userID =  arc_wellQualifiedLeads.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal ON siteSettingElementValue.userID =  rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_sessionLog ON rpt_loginCountTotal.firstsessionLogID = rpt_sessionLog.sessionLogID
/* LEFT OUTER JOIN rpt_main_02.arc_clientEvent ON rpt_loginCountTotal.firstsessionLogID = arc_clientEvent.sessionLogID 
	AND arc_clientEvent.eventDateTime < DATE_ADD(rpt_sessionLog.insertDateTime, INTERVAL 5 MINUTE) */
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ON siteSettingElementValue.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_userIPLocation.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON userAccount.userID = rpt_paymentProfile.sourceUserID 
	AND rpt_paymentProfile.accountType != 2 AND rpt_paymentProfile.paymentStartDateClean > "2015-11-07 00:00:00"
LEFT OUTER JOIN rpt_main_02.rpt_userIPLocation ip on ip.userID = userAccount.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile rpt_paymentProfile2 ON userAccount.userID = rpt_paymentProfile2.mainContactUserID 
	AND rpt_paymentProfile2.accountType != 3 AND rpt_paymentProfile2.paymentStartDateClean > "2015-11-07 00:00:00"
LEFT OUTER JOIN rpt_main_02.hist_paymentProfile on rpt_main_02.hist_paymentProfile.ownerID = siteSettingElementValue.userID and rpt_main_02.hist_paymentProfile.accountType != '3'
	and siteSettingElementValue.insertDateTime between rpt_main_02.hist_paymentProfile.modifyDateTime and rpt_main_02.hist_paymentProfile.hist_effectiveThruDateTime
LEFT OUTER JOIN rpt_main_02.stg_abtest_paymentActions pa on siteSettingElementValue.userID=pa.insertbyuserID and pa.objectID IN (2153,2152)
	
WHERE siteSettingElementName =  "SS_ABTEST_TEAM_ANNUAL_INVOICE" -- AND rpt_sessionLog.insertDateTime > "2015-11-07 00:00:00" AND siteSettingElementValueID > 48192097
GROUP BY 1,2,3,4;

select * from rpt_main_02.stg_teamAnnualInvoice limit 123123123123;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("abTest2015-11-07TeamAnnualInvoice_V2.sql");
