SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("licensedUserCentricV2.csv");

DROP TABLE IF EXISTS rpt_workspace.ams_viral_newPlansTrials;
CREATE TABLE rpt_workspace.ams_viral_newPlansTrials (
UserID INT,
StartTime DATETIME,
ProductName VARCHAR(20))
;


INSERT INTO rpt_workspace.ams_viral_newPlansTrials
SELECT DISTINCT *
FROM
(
	SELECT A.ownerID AS UserID
	,A.modifyDateTime AS StartTime
    ,CASE
		WHEN A.productID=3 THEN 'Basic'
        WHEN A.productID=4 THEN 'Advanced'
        WHEN A.productID=6 THEN 'Enterprise_Legacy'
        WHEN A.productID=7 THEN 'Team'
        WHEN A.productID=9 THEN 'Student'
        WHEN A.productID=10 THEN 'Business'
        WHEN A.productID=11 THEN 'Enterprise'
        ELSE 'bad'
        END AS ProductName
	FROM rpt_main_02.hist_paymentProfile A
	INNER JOIN
	(
		SELECT ownerID
		, MIN(modifyDateTime) AS StartTime
		FROM rpt_main_02.hist_paymentProfile
        WHERE NOT accountType = 3
        AND NOT productID<3
		GROUP BY ownerID
	) B ON A.ownerID=B.ownerID AND A.modifyDateTime = B.StartTime
	WHERE StartTime>='2016-01-01'
    HAVING NOT ProductName='bad'
) A

UNION ALL

(
	SELECT ownerID AS UserID
	, MIN(modifyDateTime) AS StartTime
	,'Trial' AS ProductName
	FROM rpt_main_02.hist_paymentProfile
	WHERE NOT accountType = 3
	AND productID=1
	GROUP BY ownerID
	HAVING StartTime>='2016-01-01'
)
;

# THIS JOINS IT TO CARSONS COLLAB REPORT AND PULLS OUT KEY DATA
DROP TABLE IF EXISTS rpt_workspace.ams_viral_view;
CREATE TABLE rpt_workspace.ams_viral_view (
UserID INT,
StartTime DATETIME,
ProductName VARCHAR(20),
StartMonth INT,
firstSharedTo DATETIME,
insertByUserPlan VARCHAR(20),
firstLogin DATETIME,
licenseDate DATETIME,
isInsertedByPhishing INT,
isCollabDomainISP INT,
isSharerDomainISP INT
);


INSERT INTO rpt_workspace.ams_viral_view
SELECT A.*
,DATE_FORMAT(StartTime,'%Y%m') AS StartMonth
,B.firstSharedTo
,B.insertByUserPlan
,B.firstLogin
,B.licenseDate
,IF(ISNULL(B.insertedByPhishingUsers),0,1) AS isInsertedByPhishing
,IF(B.isISPDomain='Org Domain',0,1) AS isCollabDomainISP
,IF(ISNULL(D.domain),0,1) AS isSharerDomainISP

FROM rpt_workspace.ams_viral_newPlansTrials A
LEFT JOIN rpt_workspace.cDunn_collabReport B ON A.UserID=B.insertByUserID
LEFT JOIN rpt_main_02.userAccount C ON C.userID=B.insertByUserID
LEFT JOIN rpt_main_02.arc_ISPDomains D ON C.domain=D.domain
;

SELECT * FROM rpt_workspace.ams_viral_view;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("licensedUserCentric.csv");

