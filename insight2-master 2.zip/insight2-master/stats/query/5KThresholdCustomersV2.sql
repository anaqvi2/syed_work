SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SET @@sql_mode = '';


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("5KThresholdCustomersV2.sql");

update rpt_workspace.js_5kTransactions A
set nextMonthARR=
(select sum(ACV) from rpt_main_02.rpt_paidPlanInfo B
where A.customer=B.domain)
where A.monthYear='2018-01-01' and A.ISP is null;

update rpt_workspace.js_5kTransactions A
set nextMonthARR=
(select ACV from rpt_main_02.rpt_paidPlanInfo B
where A.paymentProfileID=B.paymentProfileID)
where A.monthYear='2018-01-01' and A.ISP=1;


drop table if exists rpt_workspace.js_5kTransactionsFinal;
create table if not exists rpt_workspace.js_5kTransactionsFinal
(monthYear date,
recordDate date,
recordType varchar(50),
oldARR dec(10,2),
newARR dec(10,2),
varianceARR dec(10,2),
customer varchar(50),
accountName varchar(50),
opportunityName varchar(100),
opportunityOwner varchar(50),
closeDate date,
assisted int,
ISP int,
threshold varchar(50),
primary key (monthYear, customer, threshold),
index (customer),
index (recordDate));

insert into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Expansion' from rpt_workspace.js_5kTransactions
where ARR < 5000 and nextMonthARR >= 5000;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 5000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 5000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 5000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 5000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -5000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -5000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '5k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Reduction' from rpt_workspace.js_5kTransactions
where ARR >= 5000 and nextMonthARR < 5000;



insert into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Expansion' from rpt_workspace.js_5kTransactions
where ARR < 50000 and nextMonthARR >= 50000;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 50000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 50000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 50000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 50000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -50000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -50000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '50k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Reduction' from rpt_workspace.js_5kTransactions
where ARR >= 50000 and nextMonthARR < 50000;



insert into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Expansion' from rpt_workspace.js_5kTransactions
where ARR < 100000 and nextMonthARR >= 100000;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 100000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'Expansion' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Expansion' and domainStartingMRR=0 and OldMonthlyPayment=0 and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 100000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 100000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), 0, MonthlyPaymentChange*12, MonthlyPaymentChange*12, 'New' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='New' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange > 100000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, domain, MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -100000/12 and ispDomain=0;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, recordDate, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', date_format(recordDateTime, '%Y-%m-01'), recordDateTime, concat(domain,'-',paymentProfileID), MonthlyPaymentChange*12, 0, MonthlyPaymentChange*12, 'Cancel' from rpt_main_02.output_RevenueSummaryMonthly
where domainLevelRecordTypeNew='Cancel' and recordDateTime >= '2016-01-01' and MonthlyPaymentChange < -100000/12 and ispDomain=1;

insert ignore into rpt_workspace.js_5kTransactionsFinal(threshold, monthYear, customer, oldARR, newARR, varianceARR, recordType)
select '100k Threshold', monthYear, customer, ARR, NextMonthARR, NextMonthARR-ARR, 'Reduction' from rpt_workspace.js_5kTransactions
where ARR >= 100000 and nextMonthARR < 100000;

update rpt_workspace.js_5kTransactionsFinal A
join ss_sfdc_02.domain B
on A.customer=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=C.Name;

drop table if exists rpt_workspace.js_5kTransactionsStaging;
create table if not exists rpt_workspace.js_5kTransactionsStaging
(customer varchar(50),
opportunityName varchar(100),
paymentProfileID int,
ownerID varchar(50),
closeDate date,
opportunityOwner varchar(50),
index (customer),
index (opportunityName),
index (paymentProfileID),
index (ownerID),
index (closeDate),
index (opportunityOwner));

insert into rpt_workspace.js_5kTransactionsStaging(opportunityName, paymentProfileID, closeDate, ownerID)
select Name, Parent_Payment_Profile_ID__c, CloseDate, OwnerId from ss_sfdc_02.opportunity
where StageName='Closed Won' and Services_ACV__c=0 and closeDate >= '2016-01-01';

update rpt_workspace.js_5kTransactionsStaging A
join rpt_main_02.rpt_paymentProfile B
on A.paymentProfileID=B.paymentProfileID
set A.customer=B.mainContactDomain
where B.accountType!=2;

update rpt_workspace.js_5kTransactionsStaging A
join ss_sfdc_02.user B
on A.ownerID=B.Id
set A.opportunityOwner=B.UserName;

update rpt_workspace.js_5kTransactionsFinal A
join rpt_workspace.js_5kTransactionsStaging B
on A.customer=B.customer
set A.opportunityName=B.opportunityName, A.closeDate=B.closeDate, A.opportunityOwner=B.opportunityOwner
where A.monthYear=date_format(B.closeDate, '%Y-%m-01');

update rpt_workspace.js_5kTransactionsFinal A
join ss_sfdc_02.domain B
on A.customer=B.Domain_Name_URL__c
join ss_sfdc_02.account C
on B.Account__c=C.Id
set A.accountName=C.Name;

update rpt_workspace.js_5kTransactionsFinal
set assisted=1
where opportunityName is not null;

update rpt_workspace.js_5kTransactionsFinal A
join rpt_workspace.js_acvBandsCustomers B
on A.customer=B.customer
set A.ISP=B.ISP;

drop table if exists rpt_workspace.js_5kTransactionsStaging2;
create table if not exists rpt_workspace.js_5kTransactionsStaging2
(monthYear date,
customer varchar(50),
threshold varchar(50),
expansionARR dec(10,2),
primary key (monthYear, customer),
index (threshold));

insert ignore into rpt_workspace.js_5kTransactionsStaging2
select monthYear, customer, threshold, newARR from rpt_workspace.js_5kTransactionsFinal
where recordType='Cancel';

update rpt_workspace.js_5kTransactionsStaging2 A
join rpt_main_02.output_RevenueSummaryMonthly B
on A.customer=B.domain and A.monthYear=date_format(B.recordDateTime, '%Y-%m-01')
set A.expansionARR=B.monthlyPaymentChange*12
where B.domainLevelRecordTypeNew='Expansion' and B.recordType='Wins';

delete A.* from rpt_workspace.js_5kTransactionsFinal A
join rpt_workspace.js_5kTransactionsStaging2 B
on A.monthYear=B.monthYear and A.customer=B.customer and B.threshold='5k Threshold' and B.expansionARR >= 5000;

delete A.* from rpt_workspace.js_5kTransactionsFinal A
join rpt_workspace.js_5kTransactionsStaging2 B
on A.monthYear=B.monthYear and A.customer=B.customer and B.threshold='50k Threshold' and B.expansionARR >= 50000;

delete A.* from rpt_workspace.js_5kTransactionsFinal A
join rpt_workspace.js_5kTransactionsStaging2 B
on A.monthYear=B.monthYear and A.customer=B.customer and B.threshold='100k Threshold' and B.expansionARR >= 100000;

select * from rpt_workspace.js_5kTransactionsFinal;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("5KThresholdCustomersV2.sql");

