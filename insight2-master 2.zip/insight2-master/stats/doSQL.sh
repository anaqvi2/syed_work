
SMARTUSER_HOME=$HOME
STATS_HOME="${WORKSPACE}/stats"
STATS_OUTPUT="${STATS_HOME}/output"
STATS_QUERY="${STATS_HOME}/query"

DB_SERVER=127.0.0.1
DB_NAME=ss_core_02
DB_USER=insight

. "${SMARTUSER_HOME}/backupinfo.sh"
. "${STATS_HOME}/reportFuncs.sh"


while getopts d:u:hpsf OPT; do
  case $OPT in
    d)
      DB_NAME=$OPTARG
      ;;
    h)
      exit
      ;;
    u)
      DB_USER=$OPTARG
      ;;
    p)
      PRETEND=true
      DB_PWD="password"
      ;;
    s)
      SILENT_ARG="-s"
      ;;
    f)
      FORCE_ARG="--force"
      ;;
    ?)
      exit
    ;;
  esac
done

# Make $@ have the remainder of the options
shift $(( OPTIND - 1 ));

for SQL in $@; do
  SQL_PATH=$SQL

  if [ -r "$STATS_QUERY/$SQL" ]; then
    SQL_PATH="$STATS_QUERY/$SQL"
  fi

  if [ "${SQL:0:1}" = "/" ]; then
    # Absolute path provided
    SQL_PATH=$SQL
  fi

  if [ "${SQL:0:2}" = "./" ]; then
    # Relative path provided 
    SQL_PATH=$SQL
  fi
  
  if [ ! -r $SQL_PATH ]; then
     echo "Unable to open $SQL_PATH"
     exit 1
  fi
echo $DB_PWD
  if [ $PRETEND ]; then
    echo "mysql -h $DB_SERVER -D $DB_NAME -u $DB_USER --password=$DB_PWD  -v --unbuffered < $SQL_PATH"
  else
    mysql -h $DB_SERVER -D $DB_NAME -u $DB_USER --password=$DB_PWD $SILENT_ARG -v --unbuffered < $SQL_PATH
  fi

done
