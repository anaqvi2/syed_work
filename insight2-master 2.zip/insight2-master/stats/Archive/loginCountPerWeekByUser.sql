
SELECT userID as UserID, yearWeekNumb as YearWeekNumber, loginCount as LoginCount
FROM rpt_main_02.rpt_loginCountWeekly;

