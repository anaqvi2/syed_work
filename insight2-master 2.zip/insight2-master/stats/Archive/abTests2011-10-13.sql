SELECT 
	userAccount.userID AS 'User ID', 
	userAccount.emailAddress AS 'E-mail Address', 
	ss.valueNumeric AS 'SS_ABTEST_VIDEO_2',
	ss2.valueNumeric AS 'SS_ABTEST_FOLLOW_UP_MAILS_1',
	ss3.valueNumeric AS 'SS_ABTEST_PAYMENT_CVV',

	/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	       
	CONCAT(DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTimePT, '%Y'), "*", 
	       LPAD(MONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0"), "*", 
	       LPAD(DAYOFMONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0")) AS 'Signup Day PT', 

	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment',

	DATE_FORMAT(rpt_paymentProfile.paymentInsertDate, '%Y*%m(%b)') AS 'Payment Insert Month', 
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE rpt_paymentProfile.countAsPaid = 0
				WHEN 1 THEN NULL
				ELSE rpt_paymentProfile.paymentTotal / rpt_paymentProfile.paymentTerm
			END
	END AS 'Monthly Revenue',
		
	
	CASE rpt_paymentProfile.countAsPaid IS NULL OR rpt_paymentProfile.countAsPaid = 0
		WHEN 1 THEN 0
		ELSE 
			CASE rpt_paymentProfile.paymentTerm
			     WHEN 12 THEN 1
			     ELSE 0
			END	
	END AS 'Is Annual',
			
	rpt_paymentProfile.paymentTermFriendly AS 'Payment Term',
			
		/* add a period so Excel won't try to interpret keywords that start with + as a formula */
	CONCAT(". ", SUBSTRING(rpt_signupSourceUser.keyword,1,100)) 		AS 'Signup Keyword',

	rpt_signupSourceUser.adVersion AS 'Ad Version',

	rpt_signupSourceUser.landingPageVersion AS landingPageVersion,
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE rpt_clientLogCountsByUserArchived.lifetimeLogCount >= 400 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Lifetime Log Count >= 400',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',
	
	CASE rpt_paymentProfile.paymentStartDateRaw IS NOT NULL AND DATEDIFF(CURRENT_DATE(), rpt_paymentProfile.paymentStartDateRaw) <= 35
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is In 35 Day Window',
	
	CASE (userAccount.newsFlags & 1)  
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Receive News',
	CASE (userAccount.newsFlags & 2)  
		WHEN 2 THEN '1'
		ELSE '0'
	END AS 'Receive Morning Mail',
	
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'
		ELSE '0'
	END AS 'License Accepted',
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'
		ELSE '0'
	END AS 'Password Set',
	CASE (userAccount.statusFlags & 2) 
		WHEN 2 THEN '1'
		ELSE '0'
	END  AS 'Welcome Mail Sent',
	CASE (userAccount.statusFlags & 1) 
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Email Set',
	
	fcflrbu.paymentFormViewCount AS 'Payment Form View Count',
	
	CASE fcflrbu.paymentFormViewCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Viewed Payment Form At Least Once',

	fcflrbu.overviewVideoViewCount AS 'Overview Video View Count',
	
	CASE fcflrbu.overviewVideoViewCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Viewed Overview Video At Least Once',
		
	rpt_paymentProfile.productName AS 'Product Name',
	
	CASE rpt_paymentProfile.countAsPaid
		WHEN 1 THEN
			CASE rpt_paymentProfile.productID
				WHEN 0 THEN "0" /* "Cancelled"  */
				WHEN 1 THEN "0" /* "Trial"      */
				WHEN 2 THEN "0" /* "Free"       */
				WHEN 3 THEN "0" /* "Basic"      */
				WHEN 4 THEN "0" /* "Advanced"   */
				WHEN 5 THEN "0" /* "Premium"    */
				WHEN 7 THEN "1" /* "Team"       */
				WHEN 8 THEN "1" /* "Team Plus"  */
				WHEN 6 THEN "1" /* "Enterprise" */
				ELSE "0"
			END
		ELSE 0
	END AS 'Team or Higher'

	
	

FROM userAccount 
LEFT OUTER JOIN siteSettingElementValue ss ON userAccount.userID = ss.userID AND ss.siteSettingElementName = "SS_ABTEST_VIDEO_2"
LEFT OUTER JOIN siteSettingElementValue ss2 ON userAccount.userID = ss2.userID AND ss2.siteSettingElementName = "SS_ABTEST_FOLLOW_UP_MAILS_1"
LEFT OUTER JOIN siteSettingElementValue ss3 ON userAccount.userID = ss3.userID AND ss3.siteSettingElementName = "SS_ABTEST_PAYMENT_CVV"
LEFT OUTER JOIN rpt_main_02.rpt_featureCountFromLogsRollupByUser fcflrbu ON userAccount.userID = fcflrbu.userID 
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  			ON userAccount.userID = rpt_paymentProfile.sourceUserID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 			ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON userAccount.userID = rpt_containerCountsByUser.userID
LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   	ON userAccount.userID = rpt_featureCountRollupByUser.userID
WHERE ss.siteSettingElementName = "SS_ABTEST_VIDEO_2" 
OR ss2.siteSettingElementName = "SS_ABTEST_FOLLOW_UP_MAILS_1"
OR ss3.siteSettingElementName = "SS_ABTEST_PAYMENT_CVV"



