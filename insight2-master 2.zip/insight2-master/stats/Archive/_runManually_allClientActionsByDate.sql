SELECT 
	CASE DATE_FORMAT(cglr.logDate, '%U')
		/* combine the partial weeks at the end of the year and beginning of year into one week */
		WHEN 52 THEN CONCAT(DATE_FORMAT(cglr.logDate, '%Y'), "*52-0")
		WHEN 0 THEN CONCAT((DATE_FORMAT(cglr.logDate, '%Y') -1), "*52-0")
	
		ELSE DATE_FORMAT(cglr.logDate, '%Y*%U')
	END 												AS 'Log Week', 
	DATE_FORMAT(cglr.logDate, '%Y*%m(%b)') 				AS 'Log Month', 
	DATE_FORMAT(cglr.logDate, '%Y') 					AS 'Log Year', 
	CONCAT(gll.description," - ",gll2.description) 		AS 'Global Log Item-Action', 
	SUM(cglr.logCount)									AS 'Action Count', 
	COUNT(DISTINCT insertByUserID)						AS 'Unique User Count'
FROM rpt_main_02.arc_clientEventRollup cglr
JOIN ss_log_02.clientEventLookup gll ON cglr.objectID = gll.clientEventLookupID
JOIN ss_log_02.clientEventLookup gll2 ON cglr.actionID = gll2.clientEventLookupID
WHERE logDate >= '2011-01-01' AND cglr.actionID != 2  /* filter out close actions */
GROUP BY 1, 4
ORDER BY 1,4
LIMIT 1234567890