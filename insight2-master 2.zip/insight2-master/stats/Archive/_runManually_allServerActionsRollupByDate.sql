SELECT 
	slr.logDate 														AS 'Log Date', 
	CASE DATE_FORMAT(slr.logDate, '%U')
		/* combine the partial weeks at the end of the year and beginning of year into one week */
		WHEN 52 THEN CONCAT(DATE_FORMAT(slr.logDate, '%Y'), "*52-0")
		WHEN 0 THEN CONCAT((DATE_FORMAT(slr.logDate, '%Y') -1), "*52-0")
	
		ELSE DATE_FORMAT(slr.logDate, '%Y*%U')
	END 																AS 'Log Week', 
	DATE_FORMAT(slr.logDate, '%Y*%m(%b)') 								AS 'Log Month', 
	DATE_FORMAT(slr.logDate, '%Y') 										AS 'Log Year', 
	CONCAT(sal.formName," - ",sal.formAction," - ",sal.urlActionID) 	AS 'Form Name-Action-URLaction', 
	SUM(slr.logCount)													AS 'Action Count', 
	COUNT(DISTINCT insertByUserID)										AS 'Unique User Count',
	AVG(totalRequestDuration)											AS 'Average Request Duration'
FROM rpt_main_02.arc_serverLogRollup slr
JOIN rpt_main_02.arc_serverActionLookup sal ON slr.actionID = sal.actionID
WHERE logDate >= '2012-01-01'
GROUP BY 1,5
ORDER BY logDate, formAction
LIMIT 1234567890;