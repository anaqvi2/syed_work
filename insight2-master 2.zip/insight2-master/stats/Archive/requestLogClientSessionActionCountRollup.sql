SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT  
	scr.sessionLogID,
	scr.insertDateTime,
	scr.insertDateTimePT AS 'Session Insert In Pacific Time',
	scr.sessionLength,
 	DATE_FORMAT(scr.insertDateTimePT, '%b%y') 	AS 'Session Month',
	DATE_FORMAT(scr.insertDateTimePT , '%U') 	AS 'Session Week',
	DATE_FORMAT(scr.insertDateTimePT , '%W') 	AS 'Session Day Of Week',
	DAYOFYEAR(scr.insertDateTimePT) 		AS 'Session Day of Year',

        scr.userID AS 'User ID',
        scr.emailAddress AS 'Email Address',
	scr.sessionActionCount AS 'Session Action Count',
	scr.sessionErrorCount AS 'Session Error Count',
	scr.browser AS Browser,

	IF (scr.sessionActionCount > 120, 1, 0) AS 'Is Strong Lead',
	IF (scr.sessionErrorCount > 0, 1, 0) AS 'Session Had Stack Trace',

	rpt_loginCountTotal.firstLogin 	AS FirstLoginDate, 
	rpt_loginCountTotal.loginCount 	AS LoginCount,
	IF (scr.sessionLogID = rpt_loginCountTotal.firstSessionLogID, 1, 0) AS 'Very First Session',

	paymentProfile.productID,
	CASE paymentProfile.productID
		WHEN 0 THEN "Cancelled"
		WHEN 1 THEN "Trial"
		WHEN 2 THEN "Free"
		WHEN 3 THEN "Basic"
		WHEN 4 THEN "Advanced"
		WHEN 5 THEN "Premium"
		ELSE "Other"
	END AS ProductName,

	CASE paymentProfile.paymentType
		WHEN 0 THEN "None"
		WHEN 1 THEN "Paid by user"
		WHEN 2 THEN "Paid by user"
		WHEN 3 THEN "Custom"
		WHEN 4 THEN "Promo"
		WHEN 5 THEN "Additional Account"
		ELSE "Other"
	END AS PaymentTypeFriendly,

	CASE PromoCode = 'HAYEMPL'
		WHEN 1 THEN 0 		/* don't count employee seats as paid */
		ELSE
			CASE paymentProfile.paymentType
				WHEN 0 THEN 0	/* none */
				WHEN 1 THEN     /* cc */
					IF (paymentProfile.paymentTotal > 0, 1, 0)		
				WHEN 2 THEN 	/* bill to */
					IF (paymentProfile.paymentTotal > 0, 1, 0)		
				WHEN 3 THEN 	/* custom - calculate the seats for custom / enterprise deal  */
					IF (paymentProfile.paymentTotal > 0, 1, 0)
				WHEN 4 THEN 0	/* promo */
				WHEN 5 THEN 	/* add account */
		
					CASE paymentProfile.accountType
						WHEN 2 THEN 0	/* enterprise - add to accounts never paid*/	
						WHEN 1 THEN	/* regular */
							/* only count the AddTo Accounts if actual paid separately  */
							IF (paymentProfile.paymentTotal > 0 , 1, 0) 
					END
				ELSE 0
			END
	END AS "Count as Paid",

	rpt_signupSource.signupInsertDateTime 	AS SignupDateTime,
	DAYOFYEAR(rpt_signupSource.signupInsertDateTime) AS SignupDayOfYear,

	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS SignupSourceFriendly,

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly
	END AS SignupSubSourceFriendly,

	rpt_signupSource.campaign 		AS SignupCampaign,
	rpt_signupSource.segment 		AS SignupSegment,
	rpt_signupSource.keyword 		AS SignupKeyword,
	rpt_signupSource.referrer 		AS SignupReferrer,
	rpt_signupSource.queryValue		AS SignupQueryValue,
	rpt_signupSource.mySmartsheetReferralLink AS SignupMySmartsheetReferralLink,
	rpt_signupSource.mySmartsheetReferralLinkFriendly AS SignupMySmartsheetReferralLinkFriendly,
	rpt_signupSource.appLaunchType 		AS SignupShortcutType,
	rpt_signupSource.appLaunchParm1 	AS SignupShourcutParm1,
	rpt_signupSource.appLaunchParm1Friendly	AS SignupShourcutParm1Friendly

FROM rpt_main_02.rpt_sessionLog scr
LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSource ON scr.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile paymentProfile 		ON scr.userID = paymentProfile.mainContactUserID AND paymentProfile.accountType != 3
LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal rpt_loginCountTotal ON scr.userID = rpt_loginCountTotal.userID
WHERE scr.insertDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -30 DAY)

