

/*  We don't want to drop this table since it contains rolled up data */
CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_userSessionActivity(
	userID 					INT, 
	firstSessionID 			INT, 
	firstSessionDateTime 	DATETIME, 
	lastSessionID 			INT, 
	lastSessionDateTime 	DATETIME, 
	sessionCount 			INT, 
	PRIMARY KEY(userID)) ENGINE = MYISAM;

CREATE TABLE IF NOT EXISTS `arc_clientEventRollup` (
  `insertByUserID` 		int(11) NOT NULL,
  `logDate` 			date NOT NULL,
  `objectID` 			smallint(6) NOT NULL,
  `actionID` tinyint(4) NOT NULL,
  `parm1String` 		varchar(100) DEFAULT NULL,
  `parm1Int` 			int(11) DEFAULT NULL,
  `logCount` 			smallint(6) NOT NULL,
  KEY `idx_rpt_clientGlobalLogRollupNEWUserIDParm1` (`insertByUserID`,`objectID`),
  KEY `idx_rpt_clientGlobalLogRollupLogDate` (`logDate`)
) ENGINE=MYISAM CHARSET=utf8;

 CREATE TABLE `arc_serverLogRollup` (
  `insertByUserID` 		int(11) NOT NULL,
  `actionID` 			int(11) NOT NULL,
  `logDate` 			date NOT NULL,
  `logCount` 			smallint(6) NOT NULL,
  `totalRequestDuration` int(11) NOT NULL,
  KEY `idx_rpt_clientGlobalLogRollupUserIDParm1` (`insertByUserID`),
  KEY `idx_arc_serverLogRollupLogDate` (`logDate`)
) ENGINE=MyISAM CHARSET=utf8;


CREATE TABLE IF NOT EXISTS rpt_main_02.arc_wellQualifiedLeads(
	snapshotDate	DATE,
	userID 			INT, 
	loginStrength	DECIMAL (10,5),
	lifetimeLogCount INT,
	sheetCount INT,
	sharingCount INT,
	leadStrength	DECIMAL (10,5),  
	PRIMARY KEY(userID, snapshotDate));