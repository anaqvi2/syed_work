-- Pull down all leads that were Smartscored but not uploaded to SFDC
select ss.*
from rpt_main_02.arc_DailySmartscoreLeads ss
left join rpt_main_02.arc_marketo_upload sfdc on ss.userID=sfdc.userID
	and sfdc.salesForceleadSource like '%Smartscore%'
where sfdc.userID is null
;
