

select "******** prepSignupV2Data.sql - start ******** ", NOW();


/* this new content was added to the start of prepV2 until the infrastructure to run mulitple prep scripts is ready. */



select "******** prepSignupV2Data.sql - end step 2 ******** ", NOW();
