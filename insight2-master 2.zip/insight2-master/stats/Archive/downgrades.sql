SELECT DISTINCT 
hppNew.paymentProfileID AS 'Payment Profile ID', 
hppNew.ownerID AS 'Owner ID', 
CASE hppNew.accountType
 WHEN 1 THEN u.emailAddress
 WHEN 3 THEN opp.mainContactEmailAddress
 WHEN 2 THEN u.emailAddress
 ELSE "ERROR" END AS 'Email Address',
c.sheetCount AS 'Current Sheet Count',

DATE_FORMAT(hppNew.paymentStartDateTime, '%Y-%m-%d') AS 'Payment Start Date',
DATE_FORMAT(hppNew.paymentStartDateTime, '%b%Y') AS 'Payment Start Month',

DATE_FORMAT(hppNew.modifyDateTime, '%Y-%m-%d') AS 'Downgrade Date',
DATE_FORMAT(hppNew.modifyDateTime, '%Y-%U') AS 'Downgrade Week',
DATE_FORMAT(hppNew.modifyDateTime, '%b%Y') AS 'Downgrade Month',

DATEDIFF(hppNew.modifyDateTime, hppNew.paymentStartDateTime) AS 'Days To Downgrade',

hppOld.productID AS 'Old ProductID', 
hppNew.productID AS 'Downgraded Product ID', 
pp.productID AS 'Current Product ID',

rpt_main_02.SMARTSHEET_PRODUCTNAME(hppOld.productID) AS 'Old Product Name',
hppOld.userLimit AS 'Old User Limit',
rpt_main_02.SMARTSHEET_PRODUCTNAME(hppNew.productID) AS 'Downgraded Product Name',
hppOld.userLimit AS 'New User Limit',
rpt_main_02.SMARTSHEET_PRODUCTNAME(pp.productID) AS 'Current Product Name',
pp.UserLimit AS 'Current User Limit',

CASE 
WHEN hppOld.planRate = 0 THEN hppOrg.planRate
ELSE hppOld.planRate 
END AS 'Old Payment Total', 

hppNew.planRate  AS 'Downgrade Payment Total',

CASE 
WHEN hppOld.planRate  = 0 THEN hppOrg.planRate/hppOrg.paymentTerm
ELSE hppOld.planRate/hppOld.paymentTerm
END AS 'Old Payment Monthly', 

hppNew.planRate/hppNew.paymentTerm AS 'Downgrade Payment Monthly',

CASE 
WHEN hppOld.planRate = 0 THEN hppNew.planRate/hppNew.paymentTerm - hppOrg.planRate/hppOrg.paymentTerm
ELSE hppNew.planRate/hppNew.paymentTerm - hppOld.planRate/hppOld.paymentTerm
END AS 'Net Decrease of Payment Monthly'

FROM ss_core_02.hist_paymentProfile hppNew
JOIN ss_core_02.hist_paymentProfile hppOld ON hppNew.paymentProfileID = hppOld.paymentProfileID 
LEFT OUTER JOIN ss_core_02.hist_paymentProfile hppOrg ON hppOld.parentPaymentProfileID = hppOrg.paymentProfileID AND hppOld.modifyDateTime = hppOrg.modifyDateTime
JOIN ss_core_02.paymentProfile pp ON pp.paymentProfileID = hppNew.paymentProfileID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfileSheetCount c ON hppNew.paymentProfileID = c.paymentProfileID
LEFT OUTER JOIN ss_core_02.userAccount u ON hppNew.ownerID = u.userID AND hppNew.accountType != 3 
LEFT OUTER JOIN ss_core_02.organization o ON hppNew.ownerID = o.organizationID AND hppNew.accountType = 3
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile opp ON o.paymentProfileID = opp.paymentProfileID

WHERE hppNew.modifyDateTime >= '2009-01-01'
AND hppNew.productID >= 3  /*New product is above Cancelled, Trial or Free */
AND hppOld.productID >= 4  /*Eliminated promotional accounts and other non-true upgrades */
AND hppOld.planRate > 0  /*Eliminated promotional accounts and other non-true upgrades */
AND hppNew.planRate > 0 
AND hppNew.planRate != hppOld.planRate /* Eliminates specific cases where customers changed products without changing prices */
AND hppOld.planRate/hppOld.paymentTerm > hppNew.planRate/hppNew.paymentTerm  /* Eliminate cases where unique pricing turns a downgrade into a higher price.  Often from "Premium" to "Advanced")*/
AND hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND

ORDER BY hppNew.modifyDateTime;