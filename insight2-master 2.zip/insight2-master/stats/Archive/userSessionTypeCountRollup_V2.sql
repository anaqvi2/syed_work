
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("userSessionTypeCountRollup_V2.csv");


/*Generating userSessionTypeCountRollup_V2.csv*/
SELECT
	userAccount.emailAddress AS 'E-mail Address', 

	/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	       
	CONCAT(DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTimePT, '%Y'), "*", 
	       LPAD(MONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0"), "*", 
	       LPAD(DAYOFMONTH(rpt_signupSourceUser.signupInsertDateTimePT), 2, "0")) AS 'Signup Day PT', 

	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup Sub Source Friendly',

	rpt_signupSourceUser.campaign 				AS 'Signup Campaign',
	rpt_signupSourceUser.segment 				AS 'Signup Segment',

	DATE_FORMAT(rpt_paymentProfile.paymentInsertDate, '%Y*%m(%b)') AS 'Payment Insert Month', 
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE rpt_paymentProfile.countAsPaid = 0
				WHEN 1 THEN NULL
				ELSE rpt_paymentProfile.paymentTotal / rpt_paymentProfile.paymentTerm
			END
	END AS 'Monthly Revenue',
	
	CASE rpt_loginCountTotal.loginCount >= 1 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least Once',

	CASE rpt_loginCountTotal.loginCount >= 4 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'User Logged In At Least 4 Times',
	
	CASE rpt_clientLogCountsByUserArchived.firstDayLogCount  > 150 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Strong Lead',

	CASE (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Well Qualified Lead',

	
	totalCount AS 'Total Session Count', 
	iPadCount AS 'iPad Session Count', 
	iPhoneCount AS 'iPhone Session Count', 
	iPodCount AS 'iPhone Session Count', 
	blackberryCount AS 'Blackberry Session Count', 
	xoomCount AS 'Xoom Session Count', 
	ieCount AS 'IE Session Count', 
	firefoxCount AS 'Firefox Session Count', 
	safariCount AS 'Safari Session Count', 
	chromeCount AS 'Chrome Session Count', 
	otherCount AS 'Other Browser Session Count'



FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.userAccount userAccount2		ON userAccount.insertByUserID = userAccount2.userID
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  			ON userAccount.userID = rpt_paymentProfile.sourceUserID AND rpt_paymentProfile.accountType !=3 
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   	ON userAccount.userID = rpt_featureCountRollupByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 			ON userAccount.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON userAccount.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_browserSessionsByUser	ON userAccount.userID = rpt_browserSessionsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_domainRollup 			ON rpt_featureCountRollupByUser.domain 	= rpt_domainRollup.domain
  LEFT OUTER JOIN rpt_main_02.rpt_userAncestor 			ON userAccount.emailAddress 	= rpt_userAncestor.userEmailAddress
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceAncestor	ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email

WHERE rpt_loginCountTotal.loginCount >= 1 	AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "Sunday"
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("userSessionTypeCountRollup_V2.csv");






