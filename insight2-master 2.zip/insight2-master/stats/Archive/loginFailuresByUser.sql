
SELECT f.emailAddress as EmailAddress, IFNULL(u.userID,-1) as UserID, f.yearWeekNumb as YearWeekNumb, f.failureCount as FailureCount, IFNULL(l.loadCount,0) as LoadCount
FROM rpt_main_02.rpt_loginFailure f 
  left outer join rpt_main_02.userAccount u on f.emailAddress = u.emailAddress
  left outer join rpt_main_02.rpt_desktopLoad l on u.userID = l.userID and f.yearWeekNumb = l.yearWeekNumb;
