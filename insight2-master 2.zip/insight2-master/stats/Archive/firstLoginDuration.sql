SELECT 
	ce.sessionLogID AS 'Session Log ID',
	s.userID AS 'User ID',
	s.browser AS Browser,

	DATE_FORMAT(ce.eventDateTime, '%Y') AS 'Year', 
	DATE_FORMAT(ce.eventDateTime, '%Y*%m(%b)') AS 'Month',
	DATE_FORMAT(ce.eventDateTime, '%Y*%U') AS 'Week', 
	CONCAT(DATE_FORMAT(ce.eventDateTime , '%Y'), "*", 
		LPAD(MONTH(ce.eventDateTime),2,"0"), "*", 
		LPAD(DAYOFMONTH(ce.eventDateTime),2,"0")) AS 'Date', 
    
	ce.parm1Int AS 'Duration',
	 
	CASE ce.parm1Int < 5000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 5 Seconds',

	CASE ce.parm1Int < 20000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 20 Seconds',

	CASE ce.parm1Int < 60000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 1 Minute',

	CASE ce.parm1Int < 180000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 3 Minutes',

	CASE ce.parm1Int < 600000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 10 Minutes',
	
	CASE ce.parm1Int < 3600000 
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Under 1 hour'
	
FROM rpt_main_02.arc_clientEvent ce
JOIN rpt_main_02.rpt_sessionLog s ON ce.sessionLogID = s.sessionLogID
JOIN rpt_main_02.rpt_loginCountTotal f ON ce.sessionLogID = f.firstSessionLogID
WHERE objectID = 101 AND actionID = 99
AND ce.eventDateTime >= DATE_ADD(CURRENT_DATE(), INTERVAL -14 DAY);

/*
GlobalLogManager.prototype.LOG_ID_DIAGNOSTIC	= 99;
GlobalLogManager.prototype.LOG_ID_DESKTOP	= 101;
*/
