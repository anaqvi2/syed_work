SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT 
	CASE urlActionID
          WHEN -1 THEN "JOB"
          WHEN 1 THEN "HOME"
          WHEN 2 THEN "EMBED"
          WHEN 3 THEN "IMAGE"
          WHEN 4 THEN "IMAGE"
          WHEN 5 THEN "OPSCON"
          WHEN 6 THEN "OPSSTATUS"
          WHEN 7 THEN "PWD"
          WHEN 8 THEN "PWDCONF"
          WHEN 9 THEN "PUBLISH"
          WHEN 10 THEN "SIGNUP"
          WHEN 11 THEN "SIGNUPEMBED"
          WHEN 12 THEN "JS"
          WHEN 13 THEN "UPDATEREQUEST"
          WHEN 14 THEN "UPLOAD"
          WHEN 15 THEN "UNSUBSCRIBE"
          WHEN 22 THEN "MOBILE"
          ELSE "OTHER"
        END AS UrlType,
        CONCAT(reqLog.formName,' - ', reqLog.formAction) AS 'Action',

	userAccount.userID 		AS UserID,
	userAccount.emailAddress 	AS EmailAddress,
	SUBSTR(userAccount.emailAddress, INSTR(userAccount.emailAddress,'@') + 1) AS Domain,
	"0" AS EmailExistsInClassic,

	CASE DATE_FORMAT(reqLog.insertDateTime, '%U')
		/* combine the partial weeks at the end of the year and beginning of year into one week */
		WHEN 52 THEN "52-0"
		WHEN 0 THEN "52-0"
		ELSE DATE_FORMAT(reqLog.insertDateTime, '%U')
	END AS 'Action Week',

	DATE_FORMAT(reqLog.insertDateTime, '%Y-%m-%d') AS 'Action Date',
	DATEDIFF(reqLog.insertDateTime, rpt_loginCountTotal.firstLogin) AS 'Days Action After First Login',

        rpt_sessionLog.browser AS Browser,

	CASE (userAccount.newsFlags & 1)  
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Receive News',
	CASE (userAccount.newsFlags & 2)  
		WHEN 2 THEN '1'
		ELSE '0'
	END AS 'Receive Morning Mail',
	CASE (userAccount.statusFlags & 1) 
		WHEN 1 THEN '1'
		ELSE '0'
	END AS 'Email Set',
	CASE (userAccount.statusFlags & 8)  
		WHEN 8 THEN '1'
		ELSE '0'
	END AS 'License Accepted',
	CASE (userAccount.statusFlags & 4) 
		WHEN 4 THEN '1'
		ELSE '0'
	END AS 'Password Set',
	CASE (userAccount.statusFlags & 2) 
		WHEN 2 THEN '1'
		ELSE '0'
	END  AS 'Welcome Mail Sent',

       CASE paymentProfile.paymentType
	 WHEN 0 THEN "NONE"
	 WHEN 1 THEN "CC"
	 WHEN 2 THEN "BILLTO"
	 WHEN 3 THEN "CUSTOM"
	 WHEN 4 THEN "PROMO"
	 WHEN 5 THEN "ADDACCOUNT"
	 ELSE "Other"
       END AS PaymentType,

        COUNT(*) AS LoadCount,
        AVG(reqLog.requestDuration) AS AverageLoadDuration,

	/* from paymentProfile */
	paymentProfile.productID 	AS ProductID,
	CASE paymentProfile.productID
		WHEN 0 THEN "Cancelled"
		WHEN 1 THEN "Trial"
		WHEN 2 THEN "Free"
		WHEN 3 THEN "Basic"
		WHEN 4 THEN "Advanced"
		WHEN 5 THEN "Premium"
		ELSE "Other"
	END AS ProductName,
	paymentProfile.paymentTerm 	AS PaymentTerm,
	CASE paymentProfile.paymentTerm
		WHEN 1 THEN "Monthly"
		WHEN 12 THEN "Annual"
		ELSE "Other"
	END AS paymentTermFriendly,

	paymentProfile.paymentTotal AS PaymentTotal,
	paymentProfile.paymentTotal / paymentProfile.paymentTerm AS MonthlyRevenue,
	paymentProfile.promoCode 		AS PromoCode,

	CASE paymentProfile.paymentType
		WHEN 0 THEN "NONE"
		WHEN 1 THEN "CC"
		WHEN 2 THEN "BILLTO"
		WHEN 3 THEN "CUSTOM"
		WHEN 4 THEN "PROMO"
		WHEN 5 THEN "ADDACCOUNT"
		ELSE "OTHER"
	END AS PaymentType,
	CASE paymentProfile.paymentType
		WHEN 0 THEN "None"
		WHEN 1 THEN "Paid by user"
		WHEN 2 THEN "Paid by user"
		WHEN 3 THEN "Custom"
		WHEN 4 THEN "Promo"
		WHEN 5 THEN "Additional Account"
		ELSE "Other"
	END AS PaymentTypeFriendly,
	paymentProfile.paymentStartDateTime AS paymentStartDateRaw,

	CASE paymentProfile.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (paymentProfile.promoCode = 'BETALOCKIN' AND paymentProfile.insertDateTime < '2008-10-', '2008-09-30', paymentProfile.paymentStartDateTime) 
		ELSE IF (paymentProfile.insertDateTime > '2008-09-30', paymentProfile.insertDateTime, '2008-09-29')
	END AS PaymentStartDateClean,

	CASE paymentProfile.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (paymentProfile.promoCode = 'BETALOCKIN' AND paymentProfile.insertDateTime < '2008-10-01', 'Sep08', DATE_FORMAT(paymentProfile.paymentStartDateTime, '%b%y')) 
		ELSE IF (paymentProfile.insertDateTime > '2008-09-30', DATE_FORMAT(paymentProfile.insertDateTime, '%b%y'), 'Sep08')
	END AS PaymentStartMonth,

	CASE paymentProfile.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (paymentProfile.promoCode = 'BETALOCKIN' AND paymentProfile.insertDateTime < '2008-10-01', DATE_FORMAT('2008-09-30', '%U'), DATE_FORMAT(paymentProfile.paymentStartDateTime, '%U')) 
		ELSE IF (paymentProfile.insertDateTime > '2008-09-30', DATE_FORMAT(paymentProfile.insertDateTime, '%U'), DATE_FORMAT('2008-09-30', '%U'))
	END AS PaymentStartWeek,

	CASE paymentProfile.paymentStartDateTime > '2008-09-30' 
		WHEN 1 THEN IF (paymentProfile.promoCode = 'BETALOCKIN' AND paymentProfile.insertDateTime < '2008-10-01', DAYOFYEAR('2008-09-30'), DAYOFYEAR(paymentProfile.paymentStartDateTime)) 
		ELSE IF (paymentProfile.insertDateTime > '2008-09-30', DATE_FORMAT(paymentProfile.insertDateTime, '%U'), DAYOFYEAR('2008-09-30'))
	END AS PaymentStartDay,

	CASE DATEDIFF(paymentStartDateTime, paymentProfile.insertDateTime) < 0
		WHEN 1 THEN NULL
		ELSE DATEDIFF(paymentStartDateTime, paymentProfile.insertDateTime)
	END AS DaysToBuy,

	DATE_FORMAT(paymentProfile.insertDateTime, '%Y-%m-%d') AS PaymentInsertDate,
	DATE_FORMAT(paymentProfile.insertDateTime, '%b%y') AS PaymentInsertMonth,
	CASE DATE_FORMAT(paymentProfile.insertDateTime, '%U')
		/* combine the partial weeks at the end of the year and beginning of year into one week */
		WHEN 52 THEN "52-0"
		WHEN 0 THEN "52-0"
		ELSE DATE_FORMAT(paymentProfile.insertDateTime, '%U')
	END AS PaymentInsertWeek,
	DAYOFYEAR(paymentProfile.insertDateTime) AS PaymentInsertDay,



	/* common rpt_signupSource and rpt_loginCountTotal */
	rpt_signupSource.signupInsertDateTime 	AS SignTime,
	DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%b%y') AS SignupMonth,
	CASE DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%U')
		/* combine the partial weeks at the end of the year and beginning of year into one week */
		WHEN 52 THEN "52-0"
		WHEN 0 THEN "52-0"
		ELSE DATE_FORMAT(rpt_signupSource.signupInsertDateTime, '%U')
	END AS SignupWeek,
	DAYOFYEAR(rpt_signupSource.signupInsertDateTime) AS SignupDay,

	rpt_signupSource.source AS SignupSource,
	CASE rpt_signupSource.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.sourceFriendly
	END AS SignupSourceFriendly,

	CASE rpt_signupSource.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSource.subSourceFriendly
	END AS SignupSubSourceFriendly,

	rpt_signupSource.campaign 		AS SignupCampaign,
	rpt_signupSource.segment 		AS SignupSegment,
	rpt_signupSource.keyword 		AS SignupKeyword,
	rpt_signupSource.referrer 		AS SignupReferrer,
	rpt_signupSource.queryValue		AS SignupQueryValue,
	rpt_signupSource.mySmartsheetReferralLink AS SignupMySmartsheetReferralLink,
	rpt_signupSource.appLaunchType 		AS SignupShortcutType,
	rpt_signupSource.appLaunchParm1 	AS SignupShourcutParm1,
	rpt_signupSource.appLaunchParm1Friendly	AS SignupShourcutParm1Friendly,

	rpt_loginCountTotal.firstLogin 		AS FirstLogin, 
	rpt_loginCountTotal.firstLoginWeek 	AS FirstLoginWeek, 
	rpt_loginCountTotal.lastLogin 		AS LastLogin, 
	rpt_loginCountTotal.lastLoginWeek 	AS LastLoginWeek, 
	rpt_loginCountTotal.loginStrength,	
	rpt_loginCountTotal.loginCount 		AS LoginCount,

	rpt_loginCountTotal.firstLoginMonth,	
	rpt_loginCountTotal.firstLoginDay,	
	rpt_loginCountTotal.daysSinceFirstLogin,	
	rpt_loginCountTotal.daysSinceLastLogin,

	rpt_containerCountsByUser.sheetsSharedFromPaidAccount AS 'Sheets Shared From Paid Account', 
	CASE rpt_containerCountsByUser.sheetsSharedFromPaidAccount > 0
		WHEN 1 THEN 1
		ELSE 0
	END AS 'Is Associated With Paid Account'


FROM ss_log_02.requestLog reqLog
	JOIN ss_core_02.userAccount 					ON reqLog.insertByUserID = userAccount.userID
	LEFT OUTER JOIN rpt_main_02.rpt_sessionLog 			ON reqLog.sessionLogID = rpt_sessionLog.sessionLogID
	LEFT OUTER JOIN rpt_main_02.rpt_signupSource rpt_signupSource 	ON reqLog.insertByUserID = rpt_signupSource.userID
	LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal rpt_loginCountTotal 	ON userAccount.userID = rpt_loginCountTotal.userID
	LEFT OUTER JOIN ss_core_02.paymentProfile 			ON userAccount.userID = paymentProfile.ownerID
	LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON userAccount.userID = rpt_containerCountsByUser.userID
WHERE (formName = 'desktop' AND formAction = 'loadData') OR (urlActionID = 22 AND formAction = 'fa_loadGridView')
GROUP BY 1,2,3,4,5,6,7;





