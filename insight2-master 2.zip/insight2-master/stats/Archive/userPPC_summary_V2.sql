
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("userPPC_summary_V2.csv");


/*Generating userPPC_summary_V2.csv*/
SELECT 
	userAccount.emailAddress AS 'E-mail Address', 

		/* common rpt_signupSource and rpt_loginCountTotal */
	DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)') AS 'Signup Month', 
	
	CASE rpt_signupSourceUser.sourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.sourceFriendly
	END AS 'Signup Source Friendly',

	CASE rpt_signupSourceUser.subSourceFriendly IS NULL
		WHEN 1 THEN "Sharing"
		ELSE rpt_signupSourceUser.subSourceFriendly
	END AS 'Signup SubSource Friendly',

	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN DATE_FORMAT(rpt_signupSourceUser.signupInsertDateTime, '%Y*%m(%b)')
		ELSE DATE_FORMAT(rpt_signupSourceAncestor.signupInsertDateTime, '%Y*%m(%b)')
	END AS 'Working Signup Month',
	
	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN 	
				CASE rpt_signupSourceUser.sourceFriendly IS NULL
					WHEN 1 THEN "Sharing"
					ELSE rpt_signupSourceUser.sourceFriendly
				END
		ELSE 
				CASE rpt_signupSourceUser.sourceFriendly IS NULL  		/* if we already have source info, use it */
					WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 
					ELSE
						CASE rpt_signupSourceUser.sourceFriendly != "PPC"		/* if there is an ancestor source and a user source 		*/
							WHEN 1 THEN rpt_signupSourceAncestor.sourceFriendly 	/* use the anscestor source if the user source is sharing 	*/
							ELSE rpt_signupSourceUser.sourceFriendly				/* otherwise use the user source 							*/
						END
				END
	END AS 'Working Source',


	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN 	
				CASE rpt_signupSourceUser.subSourceFriendly IS NULL
					WHEN 1 THEN "Sharing"
					ELSE rpt_signupSourceUser.subSourceFriendly
				END
		ELSE 
				CASE rpt_signupSourceUser.subSourceFriendly IS NULL  		/* if we already have source info, use it */
					WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 
					ELSE 
						CASE rpt_signupSourceUser.subSourceFriendly != "PPC"		/* if there is an ancestor sub source and a user sub source 	*/
							WHEN 1 THEN rpt_signupSourceAncestor.subSourceFriendly 	/* use the anscestor sub source if the user source is sharing 	*/
							ELSE rpt_signupSourceUser.subSourceFriendly				/* otherwise use the user sub source 							*/
						END
				END
	END AS 'Working Sub Source',

	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN rpt_signupSourceUser.campaign
		ELSE
			CASE rpt_signupSourceUser.campaign IS NULL
				WHEN 1 THEN rpt_signupSourceAncestor.campaign
				ELSE rpt_signupSourceUser.campaign
			END
	END AS 'Working Campaign',

	CASE rpt_signupSourceAncestor.email IS NULL 
		WHEN 1 THEN rpt_signupSourceUser.segment
		ELSE 
			CASE rpt_signupSourceUser.campaign IS NULL
				WHEN 1 THEN rpt_signupSourceAncestor.segment
				ELSE rpt_signupSourceUser.segment
			END
	END AS 'Working Segment',	
       
	DATE_FORMAT(rpt_paymentProfile.paymentInsertDate, '%Y*%m(%b)') AS 'Payment Insert Month', 
	DATE_FORMAT(rpt_paymentProfile.paymentStartDateClean, '%Y*%m(%b)') AS 'Payment Start Month', 
	
	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN 0
		ELSE rpt_paymentProfile.countAsPaid
	END AS 'Count as Paid',

	CASE rpt_paymentProfile.countAsPaid IS NULL
		WHEN 1 THEN NULL
		ELSE 	
			CASE rpt_paymentProfile.countAsPaid = 0
				WHEN 1 THEN NULL
				ELSE rpt_paymentProfile.planRate_USD / rpt_paymentProfile.paymentTerm
			END
	END AS 'Monthly Revenue'
	

FROM rpt_main_02.userAccount userAccount
  LEFT OUTER JOIN rpt_main_02.userAccount userAccount2		ON userAccount.insertByUserID = userAccount2.userID
  LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile  		ON userAccount.userID = rpt_paymentProfile.sourceUserID
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceUser ON userAccount.userID = rpt_signupSourceUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_userAncestor 			ON userAccount.emailAddress 	= rpt_userAncestor.userEmailAddress
  LEFT OUTER JOIN rpt_main_02.rpt_signupSource AS rpt_signupSourceAncestor	ON rpt_userAncestor.ancestorEmailAddress = rpt_signupSourceAncestor.email
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 		ON userAccount.userID = rpt_loginCountTotal.userID

WHERE rpt_main_02.rpt_loginCountTotal.lastLogin >= '2009/01/01' OR rpt_signupSourceUser.signupInsertDateTime >= '2009/01/01' OR userAccount.insertDateTime >= '2009/01/01'
;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("userPPC_summary_V2.csv");

