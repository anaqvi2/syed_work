
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("PrepV2 Salesforce");


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeads prosumer insert");



/*Generating DailyStrongLeadsProsumerV2.sql*/
/*CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_DailyStrongLeads(
	snapshotDate DATE,
	userInsertDateTIme DATETIME,
	userID BIGINT, 
	dailyCount INT,
	firstDayLogCount INT,
	SSOwner VARCHAR(20),
	employeeCount INT,
	leadType VARCHAR(20),
	random FLOAT(10,9),
	PRIMARY KEY(userID));*/


/*Insert Prosumer Leads*/
INSERT rpt_main_02.arc_DailyStrongLeads(snapshotDate, userID, userDomain, userInsertDateTime, firstDayLogCount, employeeCount, leadType, random)

SELECT 	
CURRENT_DATE(),
rpt_clientLogCountsByUserArchived.userID,
userAccount.domain,
userAccount.insertDateTime,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
MAX(employeesTotal) AS MaxEmployees,
"Prosumer",
RAND()

FROM rpt_main_02.rpt_clientLogCountsByUserArchived
JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_DailyStrongLeads ON arc_DailyStrongLeads.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain 
	AND userAccount.domain != "yahoo.com"  /*so that Yahoo users are included. Otherwise they would be excluded by the 1000 employee limit*/
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedLeads ON arc_DailyWellQualifiedLeads.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_paymentProfile.mainContactUserID = rpt_clientLogCountsByUserArchived.userID 
	AND rpt_paymentProfile.accountType != 3
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON userAccount.domain=arc_ISPDomains.domain

WHERE rpt_clientLogCountsByUserArchived.firstDayLogCount > 150
AND userAccount.insertDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
AND userAccount.countryFriendly = "United States"
AND rpt_paymentProfile.productID = 1
AND rpt_main_02.arc_DailyStrongLeads.snapshotDate IS NULL
AND arc_DailyWellQualifiedLeads.snapshotDate IS NULL
AND arc_ISPDomains.domain IS NULL 

GROUP BY 2

HAVING MaxEmployees < 1000 OR MaxEmployees IS NULL
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeads prosumer insert");


/*Insert Enterprise Leads*/

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeads enterprise insert");

INSERT rpt_main_02.arc_DailyStrongLeads(snapshotDate, userID, userDomain, userInsertDateTime, firstDayLogCount, employeeCount, leadType, random)

SELECT 	
CURRENT_DATE(),
rpt_clientLogCountsByUserArchived.userID,
userAccount.domain,
userAccount.insertDateTime,
rpt_clientLogCountsByUserArchived.firstDayLogCount,
MAX(employeesTotal) AS MaxEmployees,
"Enterprise",
RAND()

FROM rpt_main_02.rpt_clientLogCountsByUserArchived
JOIN rpt_main_02.userAccount ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_DailyStrongLeads ON arc_DailyStrongLeads.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain 
	AND userAccount.domain != "yahoo.com"  /*so that Yahoo users are included. Otherwise they would be excluded by the 1000 employee limit*/
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedLeads ON arc_DailyWellQualifiedLeads.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_paymentProfile.mainContactUserID = rpt_clientLogCountsByUserArchived.userID 
	AND rpt_paymentProfile.accountType != 3
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON userAccount.domain=arc_ISPDomains.domain
WHERE rpt_clientLogCountsByUserArchived.firstDayLogCount > 150
AND rpt_paymentProfile.productID = 1
AND rpt_main_02.arc_DailyStrongLeads.snapshotDate IS NULL
AND arc_DailyWellQualifiedLeads.snapshotDate IS NULL

AND userAccount.countryFriendly = "United States"
AND userAccount.insertDateTime > DATE_ADD(CURRENT_DATE(), INTERVAL -3 DAY)
AND arc_ISPDomains.domain IS NULL

GROUP BY 2

HAVING MaxEmployees >= 1000
;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeads enterprise insert");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeads prosumer assignment");


/*Update SSOwner for TAM Domains*/
UPDATE rpt_main_02.arc_DailyStrongLeads
LEFT OUTER JOIN rpt_main_02.arc_sfdc_enterpriseDomains ON arc_sfdc_enterpriseDomains.companyDomain = arc_DailyStrongLeads.userDomain
SET arc_DailyStrongLeads.SSOwner = arc_sfdc_enterpriseDomains.SSOwner
WHERE arc_DailyStrongLeads.SSOwner IS NULL AND snapshotDate = CURRENT_DATE();

/*Update SSOwner for previously existing domains*/
UPDATE rpt_main_02.arc_DailyStrongLeads LEFT OUTER JOIN rpt_main_02.arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailyStrongLeads.userDomain
SET arc_DailyStrongLeads.SSOwner = arc_sfdc_domains.SSOwner WHERE arc_DailyStrongLeads.SSOwner IS NULL AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer";


/*Insert new Prosumer domains*/
INSERT rpt_main_02.arc_sfdc_domains (companyDomain, dateAdded)
SELECT userDomain, CURRENT_DATE()
FROM rpt_main_02.arc_DailyStrongLeads 
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON arc_DailyStrongLeads.userDomain=arc_ISPDomains.domain 
WHERE leadType = "Prosumer" AND snapshotDate = CURRENT_DATE() AND SSOwner IS NULL AND userDomain IS NOT NULL
AND arc_ISPDomains.domain IS NULL
GROUP BY 1;

/*Assign owners for new domains*/
SELECT MAX(nullCount) INTO @nullCount FROM rpt_main_02.arc_sfdc_domains; /*find starting point for count for randomdistribution*/

UPDATE rpt_main_02.arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 WHERE SSOwner IS NULL;

UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 9 = 0 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Taylor" WHERE nullCount  % 9 = 1 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Kevin" WHERE nullCount  % 9 = 2 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "AJ" WHERE nullCount  % 9 = 3  AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Jennifer" WHERE nullCount % 9 = 4 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Darren" WHERE nullCount % 9 = 5 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Sarah" WHERE nullCount % 9 = 6 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Sean" WHERE nullCount % 9 = 7 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Joe" WHERE nullCount % 9 = 8 AND SSOwner IS NULL;

/*Count the unassigned users for potential AB Test purposes*/
SET @reachoutNum = 0;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET dailyCount = @reachoutNum:=@reachoutNum + 1	WHERE dailyCount IS NULL AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;

/*Update SSOwner for these now assigned domains*/
UPDATE rpt_main_02.arc_DailyStrongLeads LEFT OUTER JOIN rpt_main_02.arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailyStrongLeads.userDomain
SET arc_DailyStrongLeads.SSOwner = arc_sfdc_domains.SSOwner WHERE leadType = "Prosumer" and arc_DailyStrongLeads.SSOwner IS NULL AND snapshotDate = CURRENT_DATE();

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeads prosumer assignment");


/*Assign owners for Enterprise*/
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeads enterprise assignment");


UPDATE rpt_main_02.arc_DailyStrongLeads
LEFT OUTER JOIN rpt_main_02.userAccount ON userAccount.userID = arc_DailyStrongLeads.userID
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON rpt_main_02.userAccount.domain = arc_HooversCompanyData.companyDomain 
LEFT OUTER JOIN rpt_main_02.arc_sfdc_stateRegions ON arc_HooversCompanyData.primaryState = arc_sfdc_stateRegions.state
SET arc_DailyStrongLeads.SSOwner = arc_sfdc_stateRegions.SSAssignee WHERE snapshotDate = CURRENT_DATE() and arc_DailyStrongLeads.SSOwner IS NULL AND leadType = "Enterprise";

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeads enterprise assignment");


/*
Removing this section eliminates the assignment of ISP domains to reps. This should prevent them from entering the arc_sfdc_upload table
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Ben" WHERE dailyCount % 8 = 0 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Taylor" WHERE dailyCount % 8 = 1 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Kevin" WHERE dailyCount % 8 = 2 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "AJ" WHERE dailyCount % 8 = 3 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Jennifer" WHERE dailyCount % 8 = 4 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Darren" WHERE dailyCount % 8 = 5 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Sarah" WHERE dailyCount % 8 = 6 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_DailyStrongLeads
SET SSOwner = "Sean" WHERE dailyCount % 8 = 7 AND snapshotDate = CURRENT_DATE() AND leadType = "Prosumer" AND SSOwner IS NULL;
 */


/*Insert into SFDC upload table*/
/*Start Logging*/
--CALL rpt_main_02.SMARTSHEET_START_LOG ("DailyStrongLeads arc_sfdc_upload");
--
--
--INSERT rpt_main_02.arc_sfdc_upload(
--	Company,
--	OwnerID,
--	STATUS,
--	domain__c,
--	userID__c,
--	paymentProfileID__c,
--	parentPaymentProfileID__c,
--	FirstName,
--	LastName, 	
--	Email,
--	Street,	
--	City,
--	State,
--	PostalCode,
--	Country,
--	Phone,
--	NumberOfEmployees,
--	AnnualRevenue,	
--	Title,
--	Website,
--	LeadSource,
--	Trial_Start_Date__c,
--	Search_Term__c,
--	Source_Bucket__c,
--	ExistingEnterpriseDomain)
--	
--SELECT 
--CASE arc_HooversCompanyData.companyName IS NULL
--	WHEN 1 THEN userAccount.domain
--	ELSE arc_HooversCompanyData.companyName END AS "companyName",
--CASE arc_DailyStrongLeads.SSOwner
--	WHEN "Gene" 	THEN "00540000001UFlQ"
--	WHEN "Kevin" 	THEN "00540000001UFla"
--	WHEN "Ben" 	THEN "00540000001UFlV"
--	WHEN "Taylor" 	THEN "00540000001UFlf"
--	WHEN "AJ"	THEN "00540000001UcZX"
--	WHEN "Jennifer"	THEN "00540000001V65s"
--	WHEN "Darren"	THEN "00540000001V66H"
--	WHEN "Sarah"   THEN "00540000002FcZI"
--	WHEN "Max" 		THEN "00540000001TpXD"
--	WHEN "Tyler" 	THEN "00540000001UFty"
--	WHEN "Gene" 	THEN "00540000001UFlQ"
--	WHEN "Sean" 	THEN "00540000002Fm0c"
--	WHEN "Joe"      THEN "00540000002Fqe3"
--	WHEN "Taryn" THEN "00540000001U30S"
--	WHEN "Tim" THEN "00540000001U30X"
--	WHEN "Eric" THEN "00540000001UiO2"
--	WHEN "Max" 		THEN "00540000001TpXD"
--	WHEN "Tyler" 	THEN "00540000001UFty"
--	ELSE "Error" 
--	END AS SSAssigneeID,	
--	"New",
--	userAccount.domain, 
--	userAccount.userID,
--	rpt_paymentProfile.paymentProfileID, 
--	rpt_paymentProfile.parentPaymentProfileID,
--	REPLACE(userAccount.firstName,'"',"'"),
--	CASE userAccount.lastName IS NULL 
--		WHEN 1 THEN "No Last Name"
--		ELSE 
--			CASE WHEN userAccount.lastName = " " THEN "No Last Name" ELSE userAccount.lastName END
--		END,
--	userAccount.emailAddress,	
--	arc_HooversCompanyData.address,
--	arc_HooversCompanyData.primaryCity,
--	arc_HooversCompanyData.primaryState,
--	arc_HooversCompanyData.postalCode,
--	userAccount.countryFriendly,
--	CONCAT(arc_HooversCompanyData.areaCode, "-", arc_HooversCompanyData.PrimaryContactPhone),
--	arc_HooversCompanyData.employeesTotal,
--	arc_HooversCompanyData.revenue,
--	NULL,
--	userAccount.domain, 
--	"Prosumer-SL150",
--	MAX(trialDateTime),
--	rpt_signupSource.keyword,
--	CASE rpt_signupSource.bucket IS NULL
--		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
--	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
--		WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 
--		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
--		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain
--
--FROM rpt_main_02.arc_DailyStrongLeads
--JOIN rpt_main_02.userAccount ON arc_DailyStrongLeads.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_main_02.rpt_paymentProfile.mainContactUserID = userAccount.userID AND rpt_paymentProfile.accountType !=3
--LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
--LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived ON userAccount.userID =  rpt_clientLogCountsByUserArchived.userID
--LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_upload ON arc_sfdc_upload.userID__c = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.arc_doNotContactList ON userAccount.domain = arc_doNotContactList.domain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_excludeList on arc_sfdc_excludeList.emailAddress = userAccount.emailAddress
--
--WHERE rpt_main_02.rpt_paymentProfile.accountType !=3
--AND snapshotDate = CURRENT_DATE()
--AND leadType = "Prosumer"
--AND SSOwner IS NOT NULL
--AND arc_sfdc_upload.uploadID IS NULL
--AND arc_doNotContactList.InsertDate IS NULL
--AND arc_sfdc_excludeList.emailAddress IS NULL
--
--GROUP BY emailAddress
--
--HAVING CurrentEnterpriseUsersFromDomain = 0;
--
--
--INSERT rpt_main_02.arc_sfdc_upload(
--	Company,
--	OwnerID,
--	STATUS,
--	domain__c,
--	userID__c,
--	paymentProfileID__c,
--	parentPaymentProfileID__c,
--	FirstName,
--	LastName, 	
--	Email,
--	Street,	
--	City,
--	State,
--	PostalCode,
--	Country,
--	Phone,
--	NumberOfEmployees,
--	AnnualRevenue,	
--	Title,
--	Website,
--	LeadSource,
--	Trial_Start_Date__c,
--	Search_Term__c,
--	Source_Bucket__c,
--	ExistingEnterpriseDomain)
--SELECT arc_HooversCompanyData.companyName,
--	CASE arc_DailyStrongLeads.SSOwner
--		WHEN "Taryn" THEN "00540000001U30S"
--		WHEN "Tim" THEN "00540000001U30X"
--		WHEN "Eric" THEN "00540000001UiO2"
--		WHEN "Max" 		THEN "00540000001TpXD"
--		WHEN "Tyler" 	THEN "00540000001UFty"
--		WHEN "Gene" 	THEN "00540000001UFlQ"
--		ELSE "Error" END,
--	"New",
--	userAccount.domain, 
--	userAccount.userID,
--	rpt_paymentProfile.paymentProfileID, 
--	rpt_paymentProfile.parentPaymentProfileID,
--	REPLACE(userAccount.firstName,'"',"'"),
--	CASE userAccount.lastName IS NULL 
--		WHEN 1 THEN "No Last Name"
--		ELSE 
--			CASE WHEN userAccount.lastName = " " THEN "No Last Name" ELSE userAccount.lastName END
--		END,
--	userAccount.emailAddress,
--	arc_HooversCompanyData.address, 
--	arc_HooversCompanyData.primaryCity,
--	arc_HooversCompanyData.primaryState,
--	arc_HooversCompanyData.postalCode,
--	"United States", 		
--	CONCAT(arc_HooversCompanyData.areaCode, "-", arc_HooversCompanyData.PrimaryContactPhone),
--	arc_HooversCompanyData.employeesTotal,
--	arc_HooversCompanyData.revenue,
--	NULL AS "Title",
--	userAccount.domain, 
--	"Enterprise-SL150",
--	MAX(trialDateTime),
--	rpt_signupSource.keyword,
--	CASE rpt_signupSource.bucket IS NULL
--		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
--	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 AND ProfileCount.productID = 6
--	AND ProfileCount.productID > 2)
--			
--FROM rpt_main_02.arc_DailyStrongLeads
--LEFT OUTER JOIN rpt_main_02.userAccount AS userAccount ON userAccount.userID = arc_DailyStrongLeads.userID
--LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
--LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_main_02.rpt_paymentProfile.mainContactUserID = userAccount.userID AND rpt_paymentProfile.accountType !=3
--LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_upload ON arc_sfdc_upload.userID__c = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.arc_doNotContactList ON userAccount.domain = arc_doNotContactList.domain
--LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON userAccount.domain=arc_ISPDomains.domain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_excludeList on arc_sfdc_excludeList.emailAddress = userAccount.emailAddress
--WHERE arc_DailyStrongLeads.snapshotDate = CURRENT_DATE()
--AND userAccount.countryFriendly = "United States"
--AND arc_HooversCompanyData.employeesTotal >= 1000
--AND arc_sfdc_upload.uploadID IS NULL
--AND arc_doNotContactList.InsertDate IS NULL
--AND arc_ISPDomains.domain IS NULL
--AND arc_sfdc_excludeList.emailAddress IS NULL
--
--GROUP BY userAccount.emailAddress;
--
--/*Stop Logging*/
--CALL rpt_main_02.SMARTSHEET_STOP_LOG ("DailyStrongLeads arc_sfdc_upload");
--
--


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.arc_DailyWellQualifiedProsumer");



/*Generating DailyWellQualified1ProsumerV2.csv*/
INSERT rpt_main_02.arc_DailyWellQualifiedProsumer(snapshotDate,userID, userDomain, leadStrength, employeeCount)

SELECT 
rpt_main_02.arc_DailyWellQualifiedLeads.snapshotDate,
rpt_main_02.arc_DailyWellQualifiedLeads.userID,
rpt_main_02.userAccount.domain,
rpt_main_02.arc_DailyWellQualifiedLeads.leadStrength,
MAX(employeesTotal) AS MaxEmployees

FROM rpt_main_02.arc_DailyWellQualifiedLeads
JOIN rpt_main_02.userAccount ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = rpt_main_02.userAccount.userID
LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON rpt_main_02.userAccount.domain = arc_HooversCompanyData.companyDomain 
	AND rpt_main_02.userAccount.domain != "yahoo.com"  /*so that Yahoo users are included. Otherwise they would be excluded by the 1000 employee limit*/
LEFT OUTER JOIN rpt_main_02.arc_DailyStrongLeads ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = arc_DailyStrongLeads.userID AND SSOwner IS NOT NULL 
LEFT OUTER JOIN rpt_main_02.arc_DailyWellQualifiedProsumer ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = arc_DailyWellQualifiedProsumer.userID

WHERE arc_DailyWellQualifiedLeads.snapshotDate = CURRENT_DATE()
AND rpt_main_02.userAccount.languageFriendly = "English"
AND arc_DailyStrongLeads.snapshotDate IS NULL
AND arc_DailyWellQualifiedProsumer.snapShotDate IS NULL 

GROUP BY 1,2

HAVING MaxEmployees < 1000 OR MaxEmployees IS NULL
ORDER BY leadStrength DESC;

/*Update SSOwner for TAM Domains*/
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
LEFT OUTER JOIN rpt_main_02.arc_sfdc_enterpriseDomains ON arc_sfdc_enterpriseDomains.companyDomain = arc_DailyWellQualifiedProsumer.userDomain
SET arc_DailyWellQualifiedProsumer.SSOwner = arc_sfdc_enterpriseDomains.SSOwner 
WHERE arc_DailyWellQualifiedProsumer.SSOwner IS NULL AND snapshotDate = CURRENT_DATE();

/*Assign SSOwner from previous assignments*/
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer LEFT OUTER JOIN rpt_main_02.arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailyWellQualifiedProsumer.userDomain
SET arc_DailyWellQualifiedProsumer.SSOwner = arc_sfdc_domains.SSOwner WHERE arc_DailyWellQualifiedProsumer.SSOwner IS NULL AND arc_DailyWellQualifiedProsumer.snapshotDate = CURRENT_DATE();

/*Insert new domains*/
INSERT rpt_main_02.arc_sfdc_domains (companyDomain, dateAdded)
SELECT userDomain, CURRENT_DATE()
FROM rpt_main_02.arc_DailyWellQualifiedProsumer
LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON arc_DailyWellQualifiedProsumer.userDomain=arc_ISPDomains.domain
WHERE snapshotDate = CURRENT_DATE() AND SSOwner IS NULL AND userDomain IS NOT NULL
AND arc_ISPDomains.domain IS NULL
GROUP BY 1;

/*Assign owners for new domains*/
SELECT MAX(nullCount) INTO @nullCount FROM rpt_main_02.arc_sfdc_domains; /*find starting point for count for randomdistribution*/

UPDATE rpt_main_02.arc_sfdc_domains
SET nullCount = @nullCount:=@nullCount + 1 WHERE SSOwner IS NULL;

UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Ben" WHERE nullCount % 9 = 0 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Taylor" WHERE nullCount  % 9 = 1 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Kevin" WHERE nullCount  % 9 = 2 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "AJ" WHERE nullCount  % 9 = 3  AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Jennifer" WHERE nullCount % 9 = 4 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Darren" WHERE nullCount % 9 = 5 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Sarah" WHERE nullCount % 9 = 6 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Sean" WHERE nullCount % 9 = 7 AND SSOwner IS NULL;
UPDATE rpt_main_02.arc_sfdc_domains
SET SSOwner = "Joe" WHERE nullCount % 9 = 8 AND SSOwner IS NULL;

/*Update SSOwner for these now assigned domains*/
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer LEFT OUTER JOIN rpt_main_02.arc_sfdc_domains ON arc_sfdc_domains.companyDomain = arc_DailyWellQualifiedProsumer.userDomain
SET arc_DailyWellQualifiedProsumer.SSOwner = arc_sfdc_domains.SSOwner WHERE snapshotDate = CURRENT_DATE() and arc_DailyWellQualifiedProsumer.SSOwner IS NULL;

/*Count the unassigned users for potential AB Test purposes*/
SET @reachoutNum = 0;
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET dailyCount = @reachoutNum:=@reachoutNum + 1	WHERE snapshotDate = CURRENT_DATE()AND SSOwner IS NULL;

/* Do not assign ISP domains. By not assigning them they should not go into the arc_sfdc_upload table  */
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Ben" WHERE dailyCount % 9 = 0 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Taylor" WHERE dailyCount % 9 = 1 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Kevin" WHERE dailyCount % 9 = 2 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "AJ" WHERE dailyCount % 9 = 3 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Darren" WHERE dailyCount % 9 = 4 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Jennifer" WHERE dailyCount % 9 = 5 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Sarah" WHERE dailyCount % 9 = 6 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Sean" WHERE dailyCount % 9 = 7 AND snapshotDate = CURRENT_DATE();
UPDATE rpt_main_02.arc_DailyWellQualifiedProsumer
SET SSOwner = "Joe" WHERE dailyCount % 9 = 8 AND snapshotDate = CURRENT_DATE();


--INSERT rpt_main_02.arc_sfdc_upload(
--	Company,
--	OwnerID,
--	STATUS,
--	domain__c,
--	userID__c,
--	paymentProfileID__c,
--	parentPaymentProfileID__c,
--	FirstName,
--	LastName, 	
--	Email,
--	Street,	
--	City,
--	State,
--	PostalCode,
--	Country,
--	Phone,
--	NumberOfEmployees,
--	AnnualRevenue,	
--	Title,
--	Website,
--	LeadSource,
--	Trial_Start_Date__c,
--	Search_Term__c,
--	Source_Bucket__c,
--	ExistingEnterpriseDomain)
--	
--SELECT 
--CASE arc_HooversCompanyData.companyName IS NULL
--	WHEN 1 THEN userAccount.domain
--	ELSE arc_HooversCompanyData.companyName END AS "companyName",
--CASE arc_DailyWellQualifiedProsumer.SSOwner
--	WHEN "Gene" 	THEN "00540000001UFlQ"
--	WHEN "Kevin" 	THEN "00540000001UFla"
--	WHEN "Ben" 	THEN "00540000001UFlV"
--	WHEN "Taylor" 	THEN "00540000001UFlf"
--	WHEN "AJ"	THEN "00540000001UcZX"
--	WHEN "Jennifer"	THEN "00540000001V65s"
--	WHEN "Darren"	THEN "00540000001V66H"
--	WHEN "Sarah"   THEN "00540000002FcZI"
--	WHEN "Max" 		THEN "00540000001TpXD"
--	WHEN "Tyler" 	THEN "00540000001UFty"
--	WHEN "Gene" 	THEN "00540000001UFlQ"
--	WHEN "Sean" 	THEN "00540000002Fm0c"
--	WHEN "Joe" 	THEN "00540000002Fqe3"
--	WHEN "Taryn" THEN "00540000001U30S"
--	WHEN "Tim" THEN "00540000001U30X"
--	WHEN "Eric" THEN "00540000001UiO2"
--	WHEN "Max" 		THEN "00540000001TpXD"
--	WHEN "Tyler" 	THEN "00540000001UFty"
--	ELSE "Error" 
--	END AS SSAssigneeID,	
--	"New",
--	userAccount.domain, 
--	userAccount.userID,
--	rpt_paymentProfile.paymentProfileID, 
--	rpt_paymentProfile.parentPaymentProfileID,
--	REPLACE(userAccount.firstName,'"',"'"),
--	CASE userAccount.lastName IS NULL 
--		WHEN 1 THEN "No Last Name"
--		ELSE 
--			CASE WHEN userAccount.lastName = " " THEN "No Last Name" ELSE userAccount.lastName END
--		END,
--	userAccount.emailAddress,	
--	arc_HooversCompanyData.address,
--	arc_HooversCompanyData.primaryCity,
--	arc_HooversCompanyData.primaryState,
--	arc_HooversCompanyData.postalCode,
--	userAccount.countryFriendly,
--	CONCAT(arc_HooversCompanyData.areaCode, "-", arc_HooversCompanyData.PrimaryContactPhone),
--	arc_HooversCompanyData.employeesTotal,
--	arc_HooversCompanyData.revenue,
--	NULL,
--	userAccount.domain, 
--	"Prosumer-WQL",
--	MAX(trialDateTime),
--	rpt_signupSource.keyword,
--	CASE rpt_signupSource.bucket IS NULL
--		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
--	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON ProfileCount.mainContactDomain = arc_ISPDomains.domain
--		WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 
--		AND ProfileCount.productID = 6 AND ProfileCount.productID > 2
--		AND arc_ISPDomains.domain IS NULL) AS CurrentEnterpriseUsersFromDomain
--
--FROM rpt_main_02.arc_DailyWellQualifiedProsumer
--JOIN rpt_main_02.userAccount ON arc_DailyWellQualifiedProsumer.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_main_02.rpt_paymentProfile.mainContactUserID = userAccount.userID AND rpt_paymentProfile.accountType !=3
--LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_upload ON arc_sfdc_upload.userID__c = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.arc_doNotContactList ON userAccount.domain = arc_doNotContactList.domain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_excludeList on arc_sfdc_excludeList.emailAddress = userAccount.emailAddress
--
--WHERE rpt_main_02.rpt_paymentProfile.accountType !=3
--AND arc_DailyWellQualifiedProsumer.snapshotDate = CURRENT_DATE()
--AND SSOwner IS NOT NULL
--AND arc_sfdc_upload.uploadID IS NULL
--AND arc_doNotContactList.InsertDate IS NULL
--AND arc_sfdc_excludeList.emailAddress IS NULL
--
--GROUP BY emailAddress
--
--HAVING CurrentEnterpriseUsersFromDomain = 0;

/*Update arc_DailyWellQualifiedLeads table to indicate which of the Daily Well Quals are contacted*/
UPDATE rpt_main_02.arc_DailyWellQualifiedLeads
  JOIN rpt_main_02.arc_DailyWellQualifiedProsumer ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = rpt_main_02.arc_DailyWellQualifiedProsumer.userID 
SET rpt_main_02.arc_DailyWellQualifiedLeads.contacted = 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.arc_DailyWellQualifiedProsumer");




/*Start Logging*/
--CALL rpt_main_02.SMARTSHEET_START_LOG ("rpt_main_02.DailyWellQualifiedEnterprise");

/*CREATE TABLE IF NOT EXISTS 
rpt_main_02.arc_sfdc_upload(
	uploadID BIGINT NOT NULL AUTO_INCREMENT,
	Company VARCHAR(100),
	OwnerID VARCHAR(25),
	STATUS VARCHAR(25),
	domain__c VARCHAR(100),
	FirstName VARCHAR(50),
	LastName VARCHAR(50), 	
	Email VARCHAR(100),
	Street VARCHAR(100),	
	City VARCHAR(50),
	State VARCHAR(25),
	PostalCode VARCHAR(25),
	Country VARCHAR(25),
	Phone VARCHAR (100),
	NumberOfEmployees INT,
	AnnualRevenue DECIMAL (32,10),	
	Title VARCHAR(50),
	Website VARCHAR(100),
	LeadSource VARCHAR(25),
	uploadDateTime DATETIME,
	PRIMARY KEY(uploadID)); */

/*Generating DailyWellQualifiedEnterpriseV2.csv*/
--INSERT rpt_main_02.arc_sfdc_upload(
--	Company,
--	OwnerID,
--	STATUS,
--	domain__c,
--	userID__c,
--	paymentProfileID__c,
--	parentPaymentProfileID__c,
--	FirstName,
--	LastName, 	
--	Email,
--	Street,	
--	City,
--	State,
--	PostalCode,
--	Country,
--	Phone,
--	NumberOfEmployees,
--	AnnualRevenue,	
--	Title,
--	Website,
--	LeadSource,
--	Trial_Start_Date__c,
--	Search_Term__c,
--	Source_Bucket__c,
--	ExistingEnterpriseDomain)
--SELECT arc_HooversCompanyData.companyName,
--	CASE arc_sfdc_enterpriseDomains.SSOwner IS NULL
--		WHEN 0 THEN 
--			CASE arc_sfdc_enterpriseDomains.SSOwner
--				WHEN "Max" 	THEN "00540000001TpXD"
--				WHEN "Tyler" 	THEN "00540000001UFty"
--				WHEN "Gene" 	THEN "00540000001UFlQ"
--				ELSE "Error - No TAM" END
--		ELSE
--			CASE arc_sfdc_stateRegions.SSAssignee 
--			WHEN "Taryn" 	THEN "00540000001U30S"
--			WHEN "Tim" 	THEN "00540000001U30X"
--			WHEN "Eric" THEN "00540000001UiO2"
--			ELSE "Error - No Ent Sales" END  
--		END AS SSOwner,
--	"New",
--	userAccount.domain, 
--	userAccount.userID,
--	rpt_paymentProfile.paymentProfileID, 
--	rpt_paymentProfile.parentPaymentProfileID,
--	REPLACE(userAccount.firstName,'"',"'"),
--	CASE userAccount.lastName IS NULL 
--		WHEN 1 THEN "No Last Name"
--		ELSE 
--			CASE WHEN userAccount.lastName = " " THEN "No Last Name" ELSE userAccount.lastName END
--		END AS NAME,
--	userAccount.emailAddress,
--	arc_HooversCompanyData.address, 
--	arc_HooversCompanyData.primaryCity,
--	arc_HooversCompanyData.primaryState,
--	arc_HooversCompanyData.postalCode,
--	"United States", 		
--	CONCAT(arc_HooversCompanyData.areaCode, "-", arc_HooversCompanyData.PrimaryContactPhone),
--	arc_HooversCompanyData.employeesTotal,
--	arc_HooversCompanyData.revenue,
--	NULL AS "Title",
--	userAccount.domain, 
--	"Enterprise-WQL",
--	MAX(trialDateTime),
--	rpt_signupSource.keyword,
--	CASE rpt_signupSource.bucket IS NULL
--		WHEN 1 THEN "Viral" ELSE rpt_signupSource.bucket END AS 'Signup Bucket',
--	(SELECT COUNT(*) FROM rpt_main_02.rpt_paymentProfile ProfileCount WHERE ProfileCount.mainContactDomain = userAccount.domain AND ProfileCount.accountType !=3 AND ProfileCount.productID = 6
--	AND ProfileCount.productID > 2) AS FromPaidAccount
--			
--FROM rpt_main_02.arc_DailyWellQualifiedLeads
--LEFT OUTER JOIN rpt_main_02.userAccount AS userAccount ON userAccount.userID = arc_DailyWellQualifiedLeads.userID
--LEFT OUTER JOIN rpt_main_02.arc_HooversCompanyData ON userAccount.domain = arc_HooversCompanyData.companyDomain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_stateRegions ON arc_HooversCompanyData.primaryState = arc_sfdc_stateRegions.state
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_enterpriseDomains ON userAccount.domain = arc_sfdc_enterpriseDomains.companyDomain
--LEFT OUTER JOIN rpt_main_02.rpt_paymentProfile ON rpt_main_02.rpt_paymentProfile.mainContactUserID = userAccount.userID AND rpt_paymentProfile.accountType !=3
--LEFT OUTER JOIN rpt_main_02.arc_DailyStrongLeads ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = arc_DailyStrongLeads.userID AND arc_DailyStrongLeads.SSOwner IS NOT NULL 
--LEFT OUTER JOIN rpt_main_02.rpt_trials ON rpt_trials.userID = userAccount.userID 
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_upload ON arc_sfdc_upload.userID__c = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.rpt_signupSource ON rpt_signupSource.userID = userAccount.userID
--LEFT OUTER JOIN rpt_main_02.arc_doNotContactList ON userAccount.domain = arc_doNotContactList.domain
--LEFT OUTER JOIN rpt_main_02.arc_ISPDomains ON userAccount.domain = arc_ISPDomains.domain
--LEFT OUTER JOIN rpt_main_02.arc_sfdc_excludeList on arc_sfdc_excludeList.emailAddress = userAccount.emailAddress
--
--WHERE arc_DailyWellQualifiedLeads.snapshotDate = CURRENT_DATE()
--AND arc_DailyStrongLeads.snapshotDate IS NULL
--AND arc_doNotContactList.InsertDate IS NULL
--AND userAccount.countryFriendly = "United States"
--AND arc_HooversCompanyData.employeesTotal >= 1000
--AND arc_ISPDomains.domain IS NULL
--AND arc_sfdc_upload.uploadID IS NULL
--AND arc_sfdc_excludeList.emailAddress IS NULL
--
--GROUP BY userAccount.emailAddress;
--
--
--/*Update arc_DailyWellQualifiedLeads table to indicate which of the Daily Well Quals are contacted*/
--UPDATE rpt_main_02.arc_DailyWellQualifiedLeads
--  JOIN rpt_main_02.arc_sfdc_upload ON rpt_main_02.arc_DailyWellQualifiedLeads.userID = arc_sfdc_upload.userID__c  AND LeadSource = "Enterprise-WQL"
--SET rpt_main_02.arc_DailyWellQualifiedLeads.contacted = 1;
--
--/*Stop Logging*/
--CALL rpt_main_02.SMARTSHEET_STOP_LOG ("rpt_main_02.DailyWellQualifiedEnterprise");

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("PrepV2 Salesforce");

