SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

select  CASE urlActionID
          WHEN -1 THEN "JOB"
          WHEN 1 THEN "HOME"
          WHEN 2 THEN "EMBED"
          WHEN 3 THEN "IMAGE"
          WHEN 4 THEN "IMAGE"
          WHEN 5 THEN "OPSCON"
          WHEN 6 THEN "OPSSTATUS"
          WHEN 7 THEN "PWD"
          WHEN 8 THEN "PWDCONF"
          WHEN 9 THEN "PUBLISH"
          WHEN 10 THEN "SIGNUP"
          WHEN 11 THEN "SIGNUPEMBED"
          WHEN 12 THEN "JS"
          WHEN 13 THEN "UPDATEREQUEST"
          WHEN 14 THEN "UPLOAD"
          WHEN 15 THEN "UNSUBSCRIBE"
          WHEN 22 THEN "MOBILE"
          ELSE "OTHER"
        END as UrlType,
        CONCAT(r.formName,' - ', r.formAction) as Action,
        r.insertByUserID as UserID,
        u.emailAddress as email,
        REPLACE(r.parm1,',','') as parm1,
        REPLACE(r.parm2,',','') as parm2,
        REPLACE(r.parm3,',','') as parm3,
        REPLACE(r.parm4,',','') as parm4,
        DATE_FORMAT(r.insertDateTime, '%y') as Year,
        DATE_FORMAT(r.insertDateTime, '%m') as Month,
        DATE_FORMAT(r.insertDateTime, '%U') as Week,
        DATE_FORMAT(r.insertDateTime, '%d') as Day,
        CASE
          WHEN INSTR(s.userAgent,'Firefox/1') THEN "Firefox 1"
          WHEN INSTR(s.userAgent,'Firefox/2') THEN "Firefox 2"
          WHEN INSTR(s.userAgent,'Firefox/3') THEN "Firefox 3"
          WHEN INSTR(s.userAgent,'MSIE 6.0') THEN "IE 6.0"
          WHEN INSTR(s.userAgent,'MSIE 7.0') THEN "IE 7.0"
          WHEN INSTR(s.userAgent,'Safari') THEN "Safari"
          WHEN INSTR(s.userAgent,'Opera/9') THEN "Opera 9"
          WHEN INSTR(s.userAgent,'Opera/8') THEN "Opera 8"
          WHEN INSTR(s.userAgent,'Camino') THEN "Camino"
          ELSE userAgent
        END as Browser,
        CASE (u.newsFlags & 1) WHEN 1 THEN 'True' ELSE 'False' END as ReceiveNews,
        DATE_FORMAT(su.signupInsertDateTime, '%y') as signupYear,
        DATE_FORMAT(su.signupInsertDateTime, '%m') as signupMonth,
        DATE_FORMAT(su.signupInsertDateTime, '%U') as signupWeek,
        DATE_FORMAT(su.signupInsertDateTime, '%d') as signupDay,
        su.classicCustomer as ClassicCustomer,
        su.source as SignupSource, 
        su.campaign as SignupCampaign, 
        su.segment as SignupSegment, 
        su.keyword as SignupKeyword, 
        su.referrer as SignupReferrer, 
        su.appLaunchType as SignupShortcutType, 
        su.appLaunchParm1 as SignupShourcutParm1, 
        l.loginCount as LoginCount,
        max(p.productID) as ProductID,
        count(*) as Count,
        avg(r.requestDuration) as Average
from ss_log_02.requestLog r
        join ss_core_02.userAccount u on r.insertByUserID = u.userID
        left outer join ss_core_02.sessionLog s on r.sessionLogID = s.sessionLogID
        left outer join rpt_main_02.rpt_signupSource su on r.insertByUserID = su.userID
        left outer join rpt_main_02.rpt_loginCountTotal l on u.userID = l.userID
        left outer join ss_core_02.paymentProfile p on u.userID = p.ownerID
WHERE r.insertDateTime > DATE_SUB(CURDATE(), INTERVAL 30 DAY)
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27;

