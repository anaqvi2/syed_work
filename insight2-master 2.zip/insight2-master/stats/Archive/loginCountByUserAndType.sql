SELECT u.emailAddress, IFNULL(g.domain, "") as GoogleAppDomain, t.* 
FROM rpt_main_02.rpt_loginCountByType t 
  JOIN rpt_main_02.userAccount u ON t.userID = u.userID
  LEFT OUTER JOIN rpt_main_02.googleAppsDomain g ON g.domain = substring(u.emailAddress, INSTR(u.emailAddress, '@')+1);