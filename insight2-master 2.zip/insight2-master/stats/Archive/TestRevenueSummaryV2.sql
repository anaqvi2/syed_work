/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("output_RevenueSummary.csv");


Select * from rpt_main_02.output_RevenueSummary;


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("output_RevenueSummary.csv");
