SET @runDate = CURRENT_DATE();
SET @marinStartDate = DATE("2013-05-07");
SET @lookbackDate = DATE_ADD(@runDate, INTERVAL -14 DAY);   /* set to the max number of days we might ever be down between runs */
SET @cutoffDate = DATE_ADD(@runDate, INTERVAL -180 DAY);	/* signups get 180 days to convert */


/***************************************************************************************************************************/
/* Marin Extract - prep the list of new PPC Trials */
/***************************************************************************************************************************/

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_marin_signups table - start ******** ", NOW();



/* We want this run to only happen once per day.  Since we don't have good flow control outside of stored procedures
   we use this flag in all the select statements so no records are processed in the second run */
   
SET @runAlreadyPerformedForRunDate = FALSE;

SELECT (runDate IS NOT NULL)
INTO @runAlreadyPerformedForRunDate
FROM rpt_main_02.arc_marin_processStatus
WHERE runDate = @runDate;

SELECT @runAlreadyPerformedForRunDate;




CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_processStatus(
	runDate DATE, 
	processStatus TINYINT, 
	rollupDateTime DATETIME, 
	extractDateTime DATETIME, 
	confirmDateTime DATETIME, 
	PRIMARY KEY(runDate));
	
CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_signups(
	userID BIGINT, 
	signupSourceUserID BIGINT, /* the userID for the original signup source record, only different than userID for pull thru */
	signupDate DATE, 
	runDate DATE, 
	PRIMARY KEY(userID));


/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql insert direct users");

	
/* insert the direct users */
INSERT rpt_main_02.arc_marin_signups(userID, signupSourceUserID, signupDate, runDate)
SELECT userAccount.userID, userAccount.userID, DATE(signupInsertDateTime), @runDate
FROM rpt_main_02.userAccount  
JOIN rpt_main_02.rpt_loginCountTotal 				ON userAccount.userID = rpt_loginCountTotal.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource 		ON userAccount.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.arc_marin_signups 		ON userAccount.userID = arc_marin_signups.userID 
WHERE rpt_loginCountTotal.loginCount > 0      							/* we are only going to count those people who log in at least once */
AND DATE(signupInsertDateTime) >= @cutoffDate 							/* only look back to the cut-off */
AND DATE(signupInsertDateTime) >= @marinStartDate						/* don't pull any data before Marin was implemented */
AND rpt_main_02.arc_marin_signups.runDate IS NULL                       /* only include those not in the list already  */
AND (rpt_signupSource.sourceFriendly IN ("PPC", "PPC - Foreign Language", "PPC - English - International")
     OR rpt_signupSource.subSourceFriendly IN ("Smartsheet Paid Bing Search", "Smartsheet Paid Google Search"))
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql insert direct users");

/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql insert pull thru users");


/* insert the pull thru users */
INSERT rpt_main_02.arc_marin_signups(userID, signupSourceUserID, signupDate, runDate)
SELECT userAccount.userID, userAccountAncestor.userID, DATE(signupInsertDateTime), @runDate
FROM rpt_main_02.userAccount  AS userAccountAncestor
JOIN rpt_main_02.rpt_userAncestor 								ON userAccountAncestor.emailAddress 	= rpt_userAncestor.ancestorEmailAddress
JOIN rpt_main_02.userAccount 									ON userAccount.emailAddress	 			= rpt_userAncestor.userEmailAddress
JOIN rpt_main_02.rpt_loginCountTotal 							ON userAccount.userID = rpt_loginCountTotal.userID
JOIN rpt_main_02.rpt_loginCountTotal AS loginCountTotalAncestor	ON userAccountAncestor.userID = loginCountTotalAncestor.userID
LEFT OUTER JOIN rpt_main_02.rpt_signupSource 					ON userAccountAncestor.userID = rpt_signupSource.userID
LEFT OUTER JOIN rpt_main_02.arc_marin_signups 					ON userAccount.userID = arc_marin_signups.userID 
WHERE rpt_loginCountTotal.loginCount > 0      							/* we are only going to count those people who log in at least once */
AND DATE(signupInsertDateTime) >= @cutoffDate 							/* only look back to the cut-off */
AND DATE(signupInsertDateTime) >= @marinStartDate						/* don't pull any data before Marin was implemented */
AND loginCountTotalAncestor.firstLogin >= @cutoffDate 					/* pull thru only gets counted after if the ancestor is inserted in the cut-off period */
AND rpt_main_02.arc_marin_signups.runDate IS NULL                       /* only include those not int the list already  */
AND (rpt_signupSource.sourceFriendly IN ("PPC", "PPC - Foreign Language", "PPC - English - International")
     OR rpt_signupSource.subSourceFriendly IN ("Smartsheet Paid Bing Search", "Smartsheet Paid Google Search"))
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql insert pull thru users");



/***************************************************************************************************************************/
/* Marin Extract - prep the list of new PPC Strong Leads */
/***************************************************************************************************************************/

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_marin_strongLeads table - start ******** ", NOW();

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_strongLeads(
	userID BIGINT, 
	runDate DATE, 
	PRIMARY KEY(userID));
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_strongLeads");

	
INSERT rpt_main_02.arc_marin_strongLeads(userID, runDate)
SELECT arc_marin_signups.userID, @runDate
FROM rpt_main_02.arc_marin_signups  
JOIN rpt_main_02.rpt_clientLogCountsByUserArchived 	ON arc_marin_signups.userID = rpt_clientLogCountsByUserArchived.userID
LEFT OUTER JOIN rpt_main_02.arc_marin_strongLeads 	ON arc_marin_signups.userID = arc_marin_strongLeads.userID 
WHERE rpt_clientLogCountsByUserArchived.firstDayLogCount > 150  		/* only include those past the strong lead threshold */
AND arc_marin_signups.runDate > @lookbackDate 							/* strong leads only need a couple days to mature, keep lookback small to run faster, long enough to cover being down for a few days */
AND rpt_main_02.arc_marin_strongLeads.runDate IS NULL                   /* only include those not int the list already  */
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_strongLeads");


/***************************************************************************************************************************/
/* Marin Extract - prep the list of new PPC Well Qualifed Leads */
/***************************************************************************************************************************/

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_marin_WQLeads table - start ******** ", NOW();

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_WQLeads(
	userID BIGINT, 
	runDate DATE, 
	PRIMARY KEY(userID));
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_WQLeads");
	
	
INSERT rpt_main_02.arc_marin_WQLeads(userID, runDate)
SELECT arc_marin_signups.userID, @runDate
FROM rpt_main_02.arc_marin_signups  
  LEFT OUTER JOIN rpt_main_02.rpt_loginCountTotal 				ON arc_marin_signups.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_main_02.rpt_clientLogCountsByUserArchived	ON arc_marin_signups.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_main_02.rpt_containerCountsByUser 		ON arc_marin_signups.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_main_02.rpt_featureCountRollupByUser   	ON arc_marin_signups.userID = rpt_featureCountRollupByUser.userID
LEFT OUTER JOIN rpt_main_02.arc_marin_WQLeads 	ON arc_marin_signups.userID = arc_marin_WQLeads.userID 
/* Note this logic does not use productID, we don't care if they are in a trial or already paid. 
 * We just care if they turned into a user that met the well-qualified threshold.  */
WHERE  (rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  
	 * (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) > .05		/* only include those past the well qualified threshold */
AND arc_marin_signups.runDate > DATE_ADD(@runDate, INTERVAL -45 DAY)  /* only look at the signups from the last 45 days */
AND rpt_main_02.arc_marin_WQLeads.runDate IS NULL                     /* only include those not int the list already  */
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_WQLeads");



/***************************************************************************************************************************/
/* Marin Extract - prep the list of new PPC Wins */
/***************************************************************************************************************************/

SELECT "******************************************************************************************************************************", NOW();
SELECT "******** arc_marin_wins table - start ******** ", NOW();


CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_wins(
	userID BIGINT, 
	winDate DATE, 
	runDate DATE, 
	dollarValue NUMERIC(38,2) NOT NULL,
	paymentProfileID		BIGINT,  /* only included for auditing purposes */
	PRIMARY KEY(userID));			 /* we only count one win per person    */
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_wins");
		

/* individual -> individual or team -> team wins */
INSERT rpt_main_02.arc_marin_wins(userID, winDate, runDate, dollarValue, paymentProfileID)
SELECT 
	arc_marin_signups.userID, 
	DATE_FORMAT(MIN(hppNew.paymentStartDateTime), "%Y-%m-%d"),
	@runDate,
	ROUND(MAX(hppNew.planRate_USD/hppNew.paymentTerm), 2),  
	pp.paymentProfileID
FROM rpt_main_02.arc_marin_signups  
JOIN rpt_main_02.rpt_paymentProfile pp		ON arc_marin_signups.userID = pp.sourceUserID
JOIN rpt_main_02.hist_paymentProfile hppNew ON pp.paymentProfileID = hppNew.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOld ON pp.paymentProfileID = hppOld.paymentProfileID 
LEFT OUTER JOIN rpt_main_02.arc_marin_wins  ON arc_marin_signups.userID = arc_marin_wins.userID
WHERE pp.productID >= 3  /* still basic or higher */
AND pp.planRate_USD > 0 	 /* still paying */
AND hppNew.modifyDateTime >= @lookbackDate 					/* needs to have been modified in lookback period  */
AND arc_marin_signups.runDate > @cutoffDate 	 			/* signups have until the cutoff to get upgrades */
AND rpt_main_02.arc_marin_wins.runDate IS NULL           /* only include those not in the list already   */
AND hppOld.planRate_USD = 0 									/* brand new wins only							*/
AND hppNew.planRate_USD > 0
AND hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;  /* don't take the chance of dupes found and have the whole batch rejected because of primary key constraint */


/* individual -> team wins */
INSERT rpt_main_02.arc_marin_wins(userID, winDate, runDate, dollarValue, paymentProfileID)
SELECT 
	arc_marin_signups.userID, 
	DATE_FORMAT(MIN(hppOrg.paymentStartDateTime), "%Y-%m-%d"),
	@runDate,
	ROUND(MAX(hppOrg.planRate_USD/hppOrg.paymentTerm), 2),  
	pp.paymentProfileID 
FROM rpt_main_02.arc_marin_signups  
JOIN rpt_main_02.rpt_paymentProfile pp		ON arc_marin_signups.userID = pp.sourceUserID
JOIN rpt_main_02.hist_paymentProfile hppNew ON pp.paymentProfileID = hppNew.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOld ON pp.paymentProfileID = hppOld.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOrg ON hppNew.parentPaymentProfileID = hppOrg.paymentProfileID AND hppNew.modifyDateTime = hppOrg.modifyDateTime
LEFT OUTER JOIN rpt_main_02.arc_marin_wins 	ON arc_marin_signups.userID = arc_marin_wins.userID
WHERE pp.productID >= 3  /* still basic or higher */
AND hppOrg.planRate_USD > 0 	 /* org is paying */
AND hppNew.modifyDateTime >= @lookbackDate						 			 /* needs to have been modified in lookback period  */
AND arc_marin_signups.runDate > @cutoffDate  	 						 /* signups have until the cutoff to get upgrades */
AND rpt_main_02.arc_marin_wins.runDate IS NULL                    	     /* only include those not in the list already  */
AND hppOld.planRate_USD = 0 													 /* brand new wins only							*/
AND hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND
/* looking for individual -> team upgrades */
AND hppNew.parentPaymentProfileID IS NOT NULL
AND hppOld.accountType = 1 AND hppNew.accountType = 2 /*Where a "Standard" account moves to "Multi-User"*/
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1;  /* don't take the chance of dupes found and have the whole batch rejected because of primary key constraint */

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_wins");



/***************************************************************************************************************************/
/* Marin Extract - prep the list of new PPC Upgrades */
/***************************************************************************************************************************/

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_upgrades(
	userID BIGINT, 
	oldEffectiveThruDateTime DATETIME, 
	upgradeDate DATE, 
	runDate DATE, 
	oldValue NUMERIC(38,2) NOT NULL,
	newValue NUMERIC(38,2) NOT NULL,
	upgradeValue NUMERIC(38,2) NOT NULL,
	paymentProfileID		BIGINT,  /* only included for auditing purposes */
	PRIMARY KEY(userID, oldEffectiveThruDateTime));
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_upgrades");
		
	
/* individual -> individual or team -> team upgrades */
INSERT rpt_main_02.arc_marin_upgrades(userID, oldEffectiveThruDateTime, upgradeDate, runDate, oldValue, newValue, upgradeValue, paymentProfileID)
SELECT 
	arc_marin_signups.userID, 
	hppOld.hist_effectiveThruDateTime,
	DATE(hppOld.hist_effectiveThruDateTime),
	@runDate,
	ROUND(MIN(hppOld.planRate_USD/hppOld.paymentTerm),2),  
	ROUND(MAX(hppNew.planRate_USD/hppNew.paymentTerm),2),  
	ROUND(MAX(hppNew.planRate_USD/hppNew.paymentTerm) - MIN(hppOld.planRate_USD/hppOld.paymentTerm), 2), 
	pp.paymentProfileID
FROM rpt_main_02.arc_marin_signups  
JOIN rpt_main_02.rpt_paymentProfile pp		ON arc_marin_signups.userID = pp.sourceUserID
JOIN rpt_main_02.hist_paymentProfile hppNew ON pp.paymentProfileID = hppNew.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOld ON pp.paymentProfileID = hppOld.paymentProfileID 
LEFT OUTER JOIN rpt_main_02.arc_marin_upgrades ON arc_marin_signups.userID = arc_marin_upgrades.userID AND arc_marin_upgrades.oldEffectiveThruDateTime = arc_marin_upgrades.oldEffectiveThruDateTime 
WHERE pp.productID >= 3  /* still basic or higher */
AND pp.planRate_USD > 0 	 /* still paying */
AND hppNew.modifyDateTime >= @lookbackDate 					/* needs to have been modified in lookback period  */
AND arc_marin_signups.runDate > @cutoffDate 	 			/* signups have until the cutoff to get upgrades */
AND rpt_main_02.arc_marin_upgrades.runDate IS NULL       /* only include those not in the list already  */
AND hppOld.productID >= 3
AND hppOld.planRate_USD > 0 
AND hppOld.planRate_USD/hppOld.paymentTerm < hppNew.planRate_USD/hppNew.paymentTerm  /* Eliminate special cases or mistakes where a lower price was used for a upgraded product */
AND hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1,2;  /* don't take the chance of dupes found and have the whole batch rejected because of primary key constraint */

/* individual -> team upgrades */
INSERT rpt_main_02.arc_marin_upgrades(userID, oldEffectiveThruDateTime, upgradeDate, runDate, oldValue, newValue, upgradeValue, paymentProfileID)
SELECT 
	arc_marin_signups.userID, 
	hppOld.hist_effectiveThruDateTime,
	DATE(hppOld.hist_effectiveThruDateTime),
	@runDate,
	ROUND(MIN(hppOld.planRate_USD/hppOld.paymentTerm), 2), 
	ROUND(MAX(hppOrg.planRate_USD/hppOrg.paymentTerm), 2),  
	ROUND(MAX(hppOrg.planRate_USD/hppOrg.paymentTerm) - MIN(hppOld.planRate_USD/hppOld.paymentTerm), 2),  
	pp.paymentProfileID
FROM rpt_main_02.arc_marin_signups  
JOIN rpt_main_02.rpt_paymentProfile pp		ON arc_marin_signups.userID = pp.sourceUserID
JOIN rpt_main_02.hist_paymentProfile hppNew ON pp.paymentProfileID = hppNew.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOld ON pp.paymentProfileID = hppOld.paymentProfileID 
JOIN rpt_main_02.hist_paymentProfile hppOrg ON hppNew.parentPaymentProfileID = hppOrg.paymentProfileID AND hppNew.modifyDateTime = hppOrg.modifyDateTime
/* to-do: allow for upgrades on different days, so match on userID and runDate */
LEFT OUTER JOIN rpt_main_02.arc_marin_upgrades 	ON arc_marin_signups.userID = arc_marin_upgrades.userID AND arc_marin_upgrades.oldEffectiveThruDateTime = arc_marin_upgrades.oldEffectiveThruDateTime 
WHERE pp.productID >= 3  /* still basic or higher */
AND hppOrg.planRate_USD > 0 	 /* still paying */
AND hppNew.modifyDateTime >= @lookbackDate						 			 /* needs to have been modified in lookback period  */
AND arc_marin_signups.runDate > @cutoffDate  	 						 /* signups have until the cutoff to get upgrades */
AND rpt_main_02.arc_marin_upgrades.runDate IS NULL                    	 /* only include those not in the list already  */
AND hppOld.productID >= 3
AND hppOld.planRate_USD > 0 
AND hppOld.planRate_USD/hppOld.paymentTerm < hppOrg.planRate_USD/hppOrg.paymentTerm  /* Eliminate special cases or mistakes where a lower price was used for a upgraded product */
AND hppNew.modifyDateTime = hppOld.hist_effectiveThruDateTime + INTERVAL 1 SECOND
/* looking for individual -> team upgrades */
AND hppNew.parentPaymentProfileID IS NOT NULL
AND hppOld.accountType = 1 AND hppNew.accountType = 2 /*Where a "Standard" account moves to "Multi-User"*/
AND NOT @runAlreadyPerformedForRunDate
GROUP BY 1,2;  /* don't take the chance of dupes found and have the whole batch rejected because of primary key constraint */


/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_upgrades");


/***************************************************************************************************************************/
/* Marin Extract -  Roll up associated records for the file to be uploaded to Marin  */
/***************************************************************************************************************************/

CREATE TABLE IF NOT EXISTS rpt_main_02.arc_marin_uploadRollup(
	runDate 		DATE, 
	signupDate 		DATE, 
	mkwid 			VARCHAR(50), 
	adversion 		VARCHAR(50), 
	keyword 		VARCHAR(50), 
	matchType 		VARCHAR(25), 
	signups 		INT, 
	strongLeads 	INT, 
	wellQualifieds 	INT, 
	wins 			INT, 	
	revenue 		NUMERIC(38,2),
	currency 		VARCHAR(25), 
	KEY(signupDate));
	
/*Start Logging*/
CALL rpt_main_02.SMARTSHEET_START_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_uploadRollup");
	
	
/* insert the rollup into a table for the extraction and for auditing */
INSERT rpt_main_02.arc_marin_uploadRollup(runDate, signupDate, mkwid, adversion, keyword, matchType, signups, strongLeads, wellQualifieds, wins, revenue, currency)
SELECT
	@runDate AS 'Date', 
	arc_marin_signups.signupDate AS 'Date', 
		
	IF(rpt_signupSource.mkwid 		IS NULL, "", rpt_signupSource.mkwid)								AS 'Keyword ID',
 	IF(rpt_signupSource.adVersion 	IS NULL, "", SUBSTRING_INDEX(rpt_signupSource.adVersion, '-', -1)) 	AS 'Creative ID', /* remove anything before - */
  	IF(rpt_signupSource.keyword 	IS NULL, "", rpt_signupSource.keyword)	 							AS 'Keyword',						
  	IF(rpt_signupSource.matchType 	IS NULL, "", rpt_signupSource.matchType) 							AS 'Match Type',

  	SUM(IF(arc_marin_signups.runDate = @runDate, 1, 0)) AS 'sign_up Conv',
	COUNT(arc_marin_strongLeads.userID) 				AS 'strong_lead Conv',
	COUNT(arc_marin_WQLeads.userID) 					AS 'well_qual_lead Conv',
	COUNT(arc_marin_wins.userID) 						AS 'paid_win Conv',

	(IF(SUM(arc_marin_wins.dollarValue) IS NULL, 0,SUM(arc_marin_wins.dollarValue)) + 	
	IF(SUM(arc_marin_upgrades.upgradeValue) IS NULL, 0,SUM(arc_marin_upgrades.upgradeValue))) * 24 /* 24 month Lifespan */	
	AS 'paid_win Rev',

    "USD" AS 'Currency'
FROM rpt_main_02.arc_marin_signups
LEFT OUTER JOIN rpt_main_02.arc_marin_strongLeads 	ON arc_marin_signups.userID = arc_marin_strongLeads.userID AND arc_marin_strongLeads.runDate = @runDate
LEFT OUTER JOIN rpt_main_02.arc_marin_WQLeads 		ON arc_marin_signups.userID = arc_marin_WQLeads.userID AND arc_marin_WQLeads.runDate = @runDate 
LEFT OUTER JOIN rpt_main_02.arc_marin_wins 			ON arc_marin_signups.userID = arc_marin_wins.userID AND arc_marin_wins.runDate = @runDate 
LEFT OUTER JOIN rpt_main_02.arc_marin_upgrades		ON arc_marin_signups.userID = arc_marin_upgrades.userID AND arc_marin_upgrades.runDate = @runDate 
LEFT OUTER JOIN rpt_main_02.rpt_signupSource 		ON arc_marin_signups.signupSourceUserID = rpt_signupSource.userID
WHERE 
	(arc_marin_signups.runDate = @runDate OR			/* any of these criteria will cause the record to appear in the roll up */
	arc_marin_strongLeads.runDate IS NOT NULL OR 
	arc_marin_WQLeads.runDate IS NOT NULL OR 
	arc_marin_wins.runDate IS NOT NULL OR 
	arc_marin_upgrades.runDate IS NOT NULL) 
	AND NOT @runAlreadyPerformedForRunDate
GROUP BY 2,3,4,5,6;

/*Stop Logging*/
CALL rpt_main_02.SMARTSHEET_STOP_LOG ("marin_bulkRevenueadd_rollup.sql arc_marin_uploadRollup");


/* insert record to track the process */
INSERT rpt_main_02.arc_marin_processStatus(runDate, processStatus, rollupDateTime)
SELECT @runDate, 0, NOW();
	
