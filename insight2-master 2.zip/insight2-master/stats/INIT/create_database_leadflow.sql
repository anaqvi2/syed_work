/*
SQLyog Community v12.4.2 (64 bit)
MySQL - 5.7.17-12-log : Database - leadflow
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`leadflow` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci */;

USE `leadflow`;

/*Table structure for table `AMUBugFix` */

CREATE TABLE `AMUBugFix` (
  `insertDateTime` datetime DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `AMUCloneMax` */

CREATE TABLE `AMUCloneMax` (
  `insertDateTime` datetime DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `paymentProfileId` bigint(20) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `AMUCompareLeads` */

CREATE TABLE `AMUCompareLeads` (
  `paymentProfileId` bigint(20) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `AMUdups` */

CREATE TABLE `AMUdups` (
  `paymentProfileId` bigint(20) DEFAULT NULL,
  `count(*)` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `AMUdupsInsert` */

CREATE TABLE `AMUdupsInsert` (
  `paymentProfileId` bigint(20) DEFAULT NULL,
  `count(*)` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `AMUdupsUpdate` */

CREATE TABLE `AMUdupsUpdate` (
  `paymentProfileId` bigint(20) DEFAULT NULL,
  `count(*)` bigint(21) NOT NULL DEFAULT '0'
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `accountEvent` */

CREATE TABLE `accountEvent` (
  `accountEventID` smallint(5) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `creationDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifyDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`accountEventID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The tracked events in the user''s account life-cycle';

/*Table structure for table `accountState` */

CREATE TABLE `accountState` (
  `accountStateID` tinyint(4) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `creationDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifyDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`accountStateID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The core states a userAccount can go through';

/*Table structure for table `amu_pp_bugs` */

CREATE TABLE `amu_pp_bugs` (
  `paymentProfileID` bigint(20) NOT NULL DEFAULT '0',
  `insertDateTime` datetime NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `amumodifyDateTime` datetime DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `amu_user_bugs` */

CREATE TABLE `amu_user_bugs` (
  `userId` bigint(20) NOT NULL DEFAULT '0',
  `insertDateTime` datetime NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `amumodifyDateTime` datetime DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `amuemailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `amufirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `amulastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `amunewsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `amustatusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `amulocale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `amutimeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_activity_nurture` */

CREATE TABLE `arc_marketo_activity_nurture` (
  `id` bigint(20) NOT NULL,
  `leadId` bigint(20) DEFAULT NULL,
  `activityDateTime` datetime DEFAULT NULL,
  `activityTypeId` smallint(6) DEFAULT NULL,
  `primaryAttributeValueId` mediumint(9) DEFAULT NULL COMMENT 'programId',
  `primaryAttributeValue` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'programName',
  `campaignId` mediumint(9) DEFAULT NULL,
  `trackId` mediumint(9) DEFAULT NULL,
  `newTrackId` mediumint(9) DEFAULT NULL,
  `previousTrackId` mediumint(9) DEFAULT NULL,
  `newNurtureCadence` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousNurtureCadence` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activityDateTime_idx` (`activityDateTime`),
  KEY `activityTypeId_activityDateTime_idx` (`activityTypeId`,`activityDateTime`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_activity_program_status_progression` */

CREATE TABLE `arc_marketo_activity_program_status_progression` (
  `id` bigint(20) NOT NULL,
  `leadId` bigint(20) DEFAULT NULL,
  `activityDateTime` datetime DEFAULT NULL,
  `activityTypeId` smallint(6) DEFAULT NULL,
  `primaryAttributeValueId` mediumint(9) DEFAULT NULL COMMENT 'programId',
  `primaryAttributeValue` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL COMMENT 'programName',
  `campaignId` mediumint(9) DEFAULT NULL,
  `acquiredBy` tinyint(1) DEFAULT NULL,
  `oldStatusId` int(11) DEFAULT NULL,
  `oldStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newStatusId` int(11) DEFAULT NULL,
  `newStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `reason` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `success` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activityDateTime_idx` (`activityDateTime`),
  KEY `activityTypeId_activityDateTime_idx` (`activityTypeId`,`activityDateTime`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_asset_program` */

CREATE TABLE `arc_marketo_asset_program` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `channel` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `createdDateTime` datetime DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `folderName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `folderType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `folderValue` int(11) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `type` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `updatedDateTime` datetime DEFAULT NULL,
  `url` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `workspace` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_email_activity` */

CREATE TABLE `arc_marketo_email_activity` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `sendActivityID` bigint(20) NOT NULL,
  `leadID` bigint(20) NOT NULL,
  `primaryAttributeValueID` mediumint(9) NOT NULL,
  `primaryAttributeValue` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `sendDateTime` datetime DEFAULT NULL,
  `deliverDateTime` datetime DEFAULT NULL,
  `openDateTime` datetime DEFAULT NULL,
  `clickDateTime` datetime DEFAULT NULL,
  `bounceDateTime` datetime DEFAULT NULL,
  `softBounceDateTime` datetime DEFAULT NULL,
  `unsubscribeDateTime` datetime DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `sendDateTime_idx` (`sendDateTime`),
  KEY `leadID_primaryAttributeValueID_idx` (`leadID`,`primaryAttributeValueID`),
  KEY `deliverDateTime_idx` (`deliverDateTime`),
  KEY `openDateTime_idx` (`openDateTime`),
  KEY `clickDateTime_idx` (`clickDateTime`),
  KEY `bounceDateTime_idx` (`bounceDateTime`),
  KEY `softBounceDateTime_idx` (`softBounceDateTime`),
  KEY `unsubscribeDateTime_idx` (`unsubscribeDateTime`)
) ENGINE=TokuDB AUTO_INCREMENT=611927135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_lead_activity` */

CREATE TABLE `arc_marketo_lead_activity` (
  `ID` bigint(20) NOT NULL,
  `leadId` bigint(20) DEFAULT NULL,
  `activityDateTime` datetime DEFAULT NULL,
  `activityTypeId` smallint(6) DEFAULT NULL,
  `primaryAttributeValueId` mediumint(9) DEFAULT NULL,
  `primaryAttributeValue` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `mailingId` mediumint(9) DEFAULT NULL,
  `choiceNumber` smallint(6) DEFAULT NULL,
  `device` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isMobileDevice` smallint(6) DEFAULT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `stepId` mediumint(9) DEFAULT NULL,
  `testVariant` mediumint(9) DEFAULT NULL,
  `userAgent` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `category` tinyint(4) DEFAULT NULL,
  `details` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subcategory` smallint(6) DEFAULT NULL,
  `clientIpAddress` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `formFields` varchar(2000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `queryParameters` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referrerUrl` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `webformId` smallint(6) DEFAULT NULL,
  `webpageId` mediumint(9) DEFAULT NULL,
  `link` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `linkId` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `source` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `friendLeadId` bigint(20) DEFAULT NULL,
  `searchEngine` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `searchQuery` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `webpageUrl` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `campaignRunId` int(11) DEFAULT NULL,
  `hasPredictive` tinyint(4) DEFAULT NULL,
  `isPredictive` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `activityTypeID_idx` (`activityTypeId`),
  KEY `activityDateTime_idx` (`activityDateTime`),
  KEY `primaryAttributeValueId_idx` (`primaryAttributeValueId`),
  KEY `activityType_DateTime_idx` (`activityTypeId`,`activityDateTime`),
  KEY `leadId_primaryAttributeValueId_activityTypeId_idx` (`leadId`,`primaryAttributeValueId`,`activityTypeId`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_lead_activity_query_history` */

CREATE TABLE `arc_marketo_lead_activity_query_history` (
  `startDateTime` datetime NOT NULL,
  `endDateTime` datetime NOT NULL,
  `activityTypeID` smallint(6) NOT NULL,
  PRIMARY KEY (`startDateTime`,`endDateTime`,`activityTypeID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Table structure for table `arc_marketo_lead_activity_types` */

CREATE TABLE `arc_marketo_lead_activity_types` (
  `ID` smallint(6) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attributeName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attributeDataType` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isPrimary` tinyint(4) DEFAULT NULL,
  `databaseName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_lead_lists` */

CREATE TABLE `arc_marketo_lead_lists` (
  `listID` int(11) NOT NULL,
  `listName` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `userID` bigint(20) DEFAULT NULL,
  `leadID` bigint(20) NOT NULL,
  `leadStatus` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `acceptedDateTime` datetime DEFAULT NULL,
  `2StarDateTime` datetime DEFAULT NULL,
  `3StarDateTime` datetime DEFAULT NULL,
  `activityCount` mediumint(9) DEFAULT NULL,
  `createdDateTime` datetime DEFAULT NULL,
  `newLeadTriggerDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`listID`,`emailAddress`),
  KEY `leadId` (`leadID`),
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_lead_nps` */

CREATE TABLE `arc_marketo_lead_nps` (
  `npsID` bigint(20) NOT NULL AUTO_INCREMENT,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userID` bigint(20) DEFAULT NULL,
  `netPromoterScore` tinyint(4) DEFAULT NULL,
  `netPromoterScoreReason` varchar(2000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`npsID`),
  UNIQUE KEY `unique_idx` (`userID`,`netPromoterScore`,`netPromoterScoreReason`(511))
) ENGINE=TokuDB AUTO_INCREMENT=26365 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_lead_program` */

CREATE TABLE `arc_marketo_lead_program` (
  `leadId` bigint(20) NOT NULL,
  `programId` mediumint(9) NOT NULL,
  `userID` bigint(20) DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `createdDateTime` datetime DEFAULT NULL,
  `updatedDateTime` datetime DEFAULT NULL,
  `progressionStatus` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `stream` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nurtureCadence` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isExhausted` tinyint(1) DEFAULT NULL,
  `acquiredBy` tinyint(1) DEFAULT NULL,
  `reachedSuccess` tinyint(1) DEFAULT NULL,
  `reachedSuccessDate` datetime DEFAULT NULL,
  `membershipDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`leadId`,`programId`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_query_history` */

CREATE TABLE `arc_marketo_query_history` (
  `buildID` int(11) DEFAULT NULL,
  `buildSequence` smallint(6) DEFAULT NULL,
  `buildSource` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `buildStep` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime DEFAULT NULL,
  `timeElapsed` int(11) DEFAULT NULL,
  PRIMARY KEY (`buildSource`,`buildStep`,`startTime`),
  KEY `buildID_buildSequence_idx` (`buildID`,`buildSequence`),
  KEY `buildID_buildStep_idx` (`buildID`,`buildStep`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload` */

CREATE TABLE `arc_marketo_upload` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `idx_emailAddress` (`emailAddress`),
  KEY `idx_paymentProfileId` (`paymentProfileID`),
  KEY `idx_insertDateTime` (`insertDateTime`),
  KEY `idx_emailDomain` (`emailDomain`),
  KEY `idx_ppModifyDateTime` (`ppModifyDateTime`),
  KEY `idx_push_to_marketo` (`pushToMarketo`),
  KEY `idx_isOrgDomain` (`isOrgDomain`),
  KEY `idx_dashboardsEnabledDateTime` (`dashboardsEnabledDateTime`),
  KEY `salesforceOwnerAtImport` (`salesforceOwnerAtImport`),
  KEY `updateDateTime_idx` (`updateDateTime`),
  KEY `userAccountModifyDateTime_idx` (`userAccountModifyDateTime`),
  KEY `trialStartDateTime_idx` (`trialStartDateTime`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_backup` */

CREATE TABLE `arc_marketo_upload_backup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `idx_emailAddress` (`emailAddress`),
  KEY `idx_paymentProfileId` (`paymentProfileID`),
  KEY `idx_insertDateTime` (`insertDateTime`),
  KEY `idx_emailDomain` (`emailDomain`),
  KEY `idx_ppModifyDateTime` (`ppModifyDateTime`),
  KEY `idx_push_to_marketo` (`pushToMarketo`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_control` */

CREATE TABLE `arc_marketo_upload_control` (
  `executionDateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '1',
  `max_amu_insertDateTime` datetime DEFAULT NULL,
  `max_amu_updateDateTime` datetime DEFAULT NULL,
  `max_amu_uaId` bigint(20) DEFAULT NULL,
  `max_amu_uaModifyDateTime` datetime DEFAULT NULL,
  `max_amu_ppId` bigint(20) DEFAULT NULL,
  `max_amu_ppModifyDateTime` datetime DEFAULT NULL,
  `max_amu_TrialStartDateTime` datetime DEFAULT NULL,
  `max_sscore_uaId` bigint(20) DEFAULT NULL,
  `max_sscore_uaModifyDateTime` datetime DEFAULT NULL,
  `max_sscore_uaInsertDateTime` datetime DEFAULT NULL,
  `max_sscore_ppId` bigint(20) DEFAULT NULL,
  `max_sscore_ppModifyDateTime` datetime DEFAULT NULL,
  `max_sscore_ppInsertDateTime` datetime DEFAULT NULL,
  `max_leadseed_ppModifyDateTime` datetime DEFAULT NULL,
  `max_sscore_slSessionLogID` bigint(20) DEFAULT NULL,
  KEY `active_idx` (`active`)
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `arc_marketo_upload_copy` */

CREATE TABLE `arc_marketo_upload_copy` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `idx_emailAddress` (`emailAddress`),
  KEY `idx_paymentProfileId` (`paymentProfileID`),
  KEY `idx_insertDateTime` (`insertDateTime`),
  KEY `idx_emailDomain` (`emailDomain`),
  KEY `idx_ppModifyDateTime` (`ppModifyDateTime`),
  KEY `idx_push_to_marketo` (`pushToMarketo`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_flags` */

CREATE TABLE `arc_marketo_upload_flags` (
  `priority` tinyint(4) NOT NULL,
  PRIMARY KEY (`priority`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8;

/*Table structure for table `arc_marketo_upload_journal` */

CREATE TABLE `arc_marketo_upload_journal` (
  `journalDateTime` datetime(5) NOT NULL DEFAULT CURRENT_TIMESTAMP(5),
  `journalAction` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`journalDateTime`,`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_journal_20161219` */

CREATE TABLE `arc_marketo_upload_journal_20161219` (
  `journalDateTime` datetime(5) NOT NULL DEFAULT CURRENT_TIMESTAMP(5),
  `journalAction` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`journalDateTime`,`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_journal_temp` */

CREATE TABLE `arc_marketo_upload_journal_temp` (
  `journalDateTime` datetime(5) NOT NULL DEFAULT CURRENT_TIMESTAMP(5),
  `journalAction` varchar(16) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`journalDateTime`,`userID`),
  KEY `idx_userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_sync_history` */

CREATE TABLE `arc_marketo_upload_sync_history` (
  `insertDateTime` datetime DEFAULT NULL,
  `processName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `syncFlag` int(11) DEFAULT NULL,
  `recordCount` int(11) DEFAULT NULL,
  KEY `insertDateTime` (`insertDateTime`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_marketo_upload_updateSeeds` */

CREATE TABLE `arc_marketo_upload_updateSeeds` (
  `paymentProfileId` bigint(20) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `arc_sfdc_domains` */

CREATE TABLE `arc_sfdc_domains` (
  `companyDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `dateAdded` datetime DEFAULT NULL,
  `SSOwner` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nullCount` int(11) DEFAULT NULL,
  `valueCheck` tinyint(4) DEFAULT NULL,
  `sfdcOwner` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Status__c` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `beachheadDomain` tinyint(4) DEFAULT NULL,
  `beachheadDomainID` int(11) DEFAULT NULL,
  PRIMARY KEY (`companyDomain`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `condeepAMUInsertStartDate` */

CREATE TABLE `condeepAMUInsertStartDate` (
  `startDate` datetime DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `context` */

CREATE TABLE `context` (
  `contextID` smallint(5) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `creationDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifyDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`contextID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='A refinement of a feature, interaction, etc. that indicates the context it occurs in.';

/*Table structure for table `coreTableData_to_sync_test` */

CREATE TABLE `coreTableData_to_sync_test` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `hceexchangeRate` decimal(38,10) DEFAULT NULL,
  `orgmainContactUserID` bigint(20) DEFAULT NULL,
  `orgname` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `orgorganizationID` bigint(20) DEFAULT '0',
  `pppbillToAddress1` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToAddress2` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToCity` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToCountryCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToPostCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToRegionCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppcurrencyCode` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppppaymentEndDateTime` datetime DEFAULT NULL,
  `ppppaymentFlags` int(11) DEFAULT NULL,
  `ppppaymentProfileID` bigint(20) DEFAULT '0',
  `ppppaymentStartDateTime` datetime DEFAULT NULL,
  `ppppaymentTerm` tinyint(4) DEFAULT NULL,
  `pppplanRate` decimal(38,10) DEFAULT NULL,
  `pppprimaryContactPhone` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppaccountType` tinyint(4) NOT NULL,
  `ppbillToAddress1` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToAddress2` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToCity` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToCountryCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToPostCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToRegionCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppcurrencyCode` varchar(10) CHARACTER SET utf8mb4 NOT NULL,
  `ppmodifyDateTime` datetime NOT NULL,
  `ppnextPaymentDate` datetime DEFAULT NULL,
  `pppaymentProfileID` bigint(20) NOT NULL DEFAULT '0',
  `ppparentPaymentProfileID` bigint(20) DEFAULT NULL,
  `pppaymentEndDateTime` datetime DEFAULT NULL,
  `pppaymentFlags` int(11) NOT NULL,
  `pppaymentStartDateTime` datetime DEFAULT NULL,
  `pppaymentTerm` tinyint(4) NOT NULL,
  `ppplanRate` decimal(38,10) NOT NULL,
  `ppprimaryContactPhone` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppproductID` int(11) NOT NULL,
  `ppuserLimit` int(11) NOT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `pppaymentType` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ppactualLastPaymentDate` datetime DEFAULT NULL,
  `pppromoCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppinsertDateTime` datetime NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `coreTableData_to_synca` */

CREATE TABLE `coreTableData_to_synca` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `hceexchangeRate` decimal(38,10) DEFAULT NULL,
  `orgmainContactUserID` bigint(20) DEFAULT NULL,
  `orgname` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `orgorganizationID` bigint(20) DEFAULT '0',
  `pppbillToAddress1` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToAddress2` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToCity` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToCountryCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToPostCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppbillToRegionCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pppcurrencyCode` varchar(10) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppppaymentEndDateTime` datetime DEFAULT NULL,
  `ppppaymentFlags` int(11) DEFAULT NULL,
  `ppppaymentProfileID` bigint(20) DEFAULT '0',
  `ppppaymentStartDateTime` datetime DEFAULT NULL,
  `ppppaymentTerm` tinyint(4) DEFAULT NULL,
  `pppplanRate` decimal(38,10) DEFAULT NULL,
  `pppprimaryContactPhone` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppaccountType` tinyint(4) NOT NULL,
  `ppbillToAddress1` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToAddress2` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToCity` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToCountryCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToPostCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppbillToRegionCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppcurrencyCode` varchar(10) CHARACTER SET utf8mb4 NOT NULL,
  `ppmodifyDateTime` datetime NOT NULL,
  `ppnextPaymentDate` datetime DEFAULT NULL,
  `pppaymentProfileID` bigint(20) NOT NULL DEFAULT '0',
  `ppparentPaymentProfileID` bigint(20) DEFAULT NULL,
  `pppaymentEndDateTime` datetime DEFAULT NULL,
  `pppaymentFlags` int(11) NOT NULL,
  `pppaymentStartDateTime` datetime DEFAULT NULL,
  `pppaymentTerm` tinyint(4) NOT NULL,
  `ppplanRate` decimal(38,10) NOT NULL,
  `ppprimaryContactPhone` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppproductID` int(11) NOT NULL,
  `ppuserLimit` int(11) NOT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `pppaymentType` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ppactualLastPaymentDate` datetime DEFAULT NULL,
  `pppromoCode` varchar(50) CHARACTER SET utf8mb4 DEFAULT NULL,
  `ppinsertDateTime` datetime NOT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `feature` */

CREATE TABLE `feature` (
  `featureID` smallint(5) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `creationDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifyDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`featureID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The tracked features of the application a user can use';

/*Table structure for table `featureUsageByUserCounts` */

CREATE TABLE `featureUsageByUserCounts` (
  `userID` int(11) NOT NULL,
  `accountStateID` tinyint(4) NOT NULL,
  `featureID` smallint(5) unsigned NOT NULL,
  `contextID` smallint(5) unsigned DEFAULT NULL,
  `count` int(10) unsigned DEFAULT NULL,
  `firstUse` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `latestUse` datetime NOT NULL,
  `lastEventSourceID` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'mysql-bin.000000:0000000000000000',
  `addedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `serialNumber` int(10) unsigned DEFAULT '1',
  KEY `featureUsageByAccountState_idx` (`accountStateID`),
  KEY `featureUsageByFeature_idx` (`featureID`),
  KEY `featureUsageByContext_idx` (`contextID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The features used by each user';

/*Table structure for table `interaction` */

CREATE TABLE `interaction` (
  `interactionID` smallint(5) unsigned NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `creationDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifyDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`interactionID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The tracked interactions a user can have with the Smartsheet organization';

/*Table structure for table `interactionsByUserCounts` */

CREATE TABLE `interactionsByUserCounts` (
  `userID` int(11) NOT NULL,
  `accountStateID` tinyint(4) NOT NULL,
  `interactionID` smallint(5) unsigned NOT NULL,
  `contextID` smallint(5) unsigned DEFAULT NULL,
  `count` int(10) unsigned DEFAULT NULL,
  `firstUse` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `latestUse` datetime NOT NULL,
  PRIMARY KEY (`userID`),
  KEY `interactionByAccountState_idx` (`accountStateID`),
  KEY `interactionByInteraction_idx` (`interactionID`),
  KEY `interactionByContext_idx` (`contextID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='The interactions with Smartsheet by each user';

/*Table structure for table `leadSeed` */

CREATE TABLE `leadSeed` (
  `insertDateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `paymentProfileID` bigint(20) NOT NULL,
  `ppInsertDateTime` datetime NOT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productID` bigint(20) NOT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountType` int(11) NOT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userID` bigint(20) NOT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `googleUserId` bigint(20) DEFAULT NULL,
  `firstSharedToDate` datetime DEFAULT NULL,
  `previousProductId` bigint(20) DEFAULT NULL,
  `signupRequestId` bigint(20) DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `ABTests` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`paymentProfileID`),
  KEY `idx_userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `leadSeed_20150126` */

CREATE TABLE `leadSeed_20150126` (
  `insertDateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `paymentProfileID` bigint(20) NOT NULL,
  `ppInsertDateTime` datetime NOT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productID` bigint(20) NOT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountType` int(11) NOT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userID` bigint(20) NOT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `googleUserId` bigint(20) DEFAULT NULL,
  `firstSharedToDate` datetime DEFAULT NULL,
  `previousProductId` bigint(20) DEFAULT NULL,
  `signupRequestId` bigint(20) DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `ABTests` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `rptMainAMU` */

CREATE TABLE `rptMainAMU` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `rpt_fitScoreModelV1` */

CREATE TABLE `rpt_fitScoreModelV1` (
  `Category` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Variable` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Coefficient` decimal(18,8) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `rpt_fitScoreModelV2` */

CREATE TABLE `rpt_fitScoreModelV2` (
  `Category` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Variable` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `Coefficient` decimal(18,8) DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_leadAssignmentNBR` */

CREATE TABLE `arc_leadAssignmentNBR` (
  `AssignmentID` int(11) DEFAULT NULL,
  `SSOwner` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `arc_leadAssignmentNAS` */

CREATE TABLE `arc_leadAssignmentNAS` (
  `AssignmentID` int(11) DEFAULT NULL,
  `SSOwner` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `stg_leadRedistributionNBR` */

CREATE TABLE `stg_leadRedistributionNBR` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SSOwner` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `DomainCount` int(11) DEFAULT NULL,
  `UserCount` int(11) DEFAULT NULL,
  `LeadRate` decimal(38,10) DEFAULT NULL,
  `AdjLeadRate` int(11) DEFAULT NULL,
  `LeadCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `stg_leadRedistributionNAS` */

CREATE TABLE `stg_leadRedistributionNAS` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SSOwner` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `DomainCount` int(11) DEFAULT NULL,
  `UserCount` int(11) DEFAULT NULL,
  `LeadRate` decimal(38,10) DEFAULT NULL,
  `AdjLeadRate` int(11) DEFAULT NULL,
  `LeadCount` int(11) DEFAULT NULL,
  `salesTeam` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `stg_leadRedistributionNAS_backup` */

CREATE TABLE `stg_leadRedistributionNAS_backup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SSOwner` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `DomainCount` int(11) DEFAULT NULL,
  `UserCount` int(11) DEFAULT NULL,
  `LeadRate` decimal(38,10) DEFAULT NULL,
  `AdjLeadRate` int(11) DEFAULT NULL,
  `LeadCount` int(11) DEFAULT NULL,
  `salesTeam` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=TokuDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `stg_userSessionRollup` */

CREATE TABLE `stg_userSessionRollup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `sessionMonth` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `DesktopSessions` int(11) DEFAULT NULL,
  `NativeAppSessions` int(11) DEFAULT NULL,
  `MobileWebSessions` int(11) DEFAULT NULL,
  PRIMARY KEY (`userID`,`sessionMonth`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `testLeadsToPush_20141212` */

CREATE TABLE `testLeadsToPush_20141212` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_411_inferred_title` */

CREATE TABLE `tmp_411_inferred_title` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `inferredTitle` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_abtests` */

CREATE TABLE `tmp_abtests` (
  `userID` bigint(20) NOT NULL,
  `NewABTestValue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_all_created_marketo_leads_since_20170101` */

CREATE TABLE `tmp_all_created_marketo_leads_since_20170101` (
  `marketoLeadID` bigint(20) NOT NULL,
  `userID` bigint(20) NOT NULL,
  `emailAddress` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoCreateDateTime` datetime DEFAULT NULL,
  `marketoUpdateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_associate_leads` */

CREATE TABLE `tmp_associate_leads` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_created_users` */

CREATE TABLE `tmp_created_users` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_cs_report_changes` */

CREATE TABLE `tmp_cs_report_changes` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_fit_score_cleanup` */

CREATE TABLE `tmp_fit_score_cleanup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_lead_cleanup` */

CREATE TABLE `tmp_lead_cleanup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_license_tags` */

CREATE TABLE `tmp_license_tags` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `licenseTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_marketo_api_error_cleanup` */

CREATE TABLE `tmp_marketo_api_error_cleanup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_marketo_leads` */

CREATE TABLE `tmp_marketo_leads` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `idx_emailAddress` (`emailAddress`),
  KEY `idx_paymentProfileId` (`paymentProfileID`),
  KEY `idx_insertDateTime` (`insertDateTime`),
  KEY `idx_emailDomain` (`emailDomain`),
  KEY `idx_ppModifyDateTime` (`ppModifyDateTime`),
  KEY `idx_push_to_marketo` (`pushToMarketo`),
  KEY `idx_isOrgDomain` (`isOrgDomain`),
  KEY `idx_dashboardsEnabledDateTime` (`dashboardsEnabledDateTime`),
  KEY `salesforceOwnerAtImport` (`salesforceOwnerAtImport`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_new_lead_signup_info` */

CREATE TABLE `tmp_new_lead_signup_info` (
  `signupRequestTrackingItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `signupRequestID` bigint(20) NOT NULL,
  `itemType` tinyint(4) NOT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `itemValue` varchar(500) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `dataTimestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`signupRequestTrackingItemID`),
  KEY `signupRequestTrackingItem_idx1` (`signupRequestID`)
) ENGINE=InnoDB AUTO_INCREMENT=185685912 DEFAULT CHARSET=utf8mb4;

/*Table structure for table `tmp_new_lead_signup_info2` */

CREATE TABLE `tmp_new_lead_signup_info2` (
  `signupRequestTrackingItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `signupRequestID` bigint(20) NOT NULL,
  `itemType` tinyint(4) NOT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `itemValue` varchar(500) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `dataTimestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`signupRequestTrackingItemID`),
  KEY `signupRequestTrackingItem_idx1` (`signupRequestID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Table structure for table `tmp_new_lead_signup_infoa` */

CREATE TABLE `tmp_new_lead_signup_infoa` (
  `signupRequestTrackingItemID` bigint(20) NOT NULL AUTO_INCREMENT,
  `signupRequestID` bigint(20) NOT NULL,
  `itemType` tinyint(4) NOT NULL,
  `itemName` varchar(100) DEFAULT NULL,
  `itemValue` varchar(500) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `dataTimestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`signupRequestTrackingItemID`),
  KEY `signupRequestTrackingItem_idx1` (`signupRequestID`)
) ENGINE=InnoDB AUTO_INCREMENT=175414291 DEFAULT CHARSET=utf8mb4;

/*Table structure for table `tmp_paymentProfile_marketoSync2` */

CREATE TABLE `tmp_paymentProfile_marketoSync2` (
  `paymentProfileID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ownerID` bigint(20) NOT NULL,
  `accountType` tinyint(4) NOT NULL,
  `paymentType` tinyint(4) NOT NULL,
  `paymentFlags` int(11) NOT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `paymentStartDateTime` datetime NOT NULL,
  `paymentEndDateTime` datetime DEFAULT NULL,
  `estimatedLastPaymentDate` datetime DEFAULT NULL,
  `actualLastPaymentDate` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `productID` int(11) NOT NULL,
  `productPriceID` int(11) DEFAULT NULL,
  `promoCode` varchar(50) DEFAULT NULL,
  `userLimit` int(11) NOT NULL,
  `bonusSheetCount` int(11) NOT NULL,
  `bonusUserCount` int(11) DEFAULT NULL,
  `bonusStorageKb` int(11) DEFAULT NULL,
  `loyaltyBonusSheetCount` int(11) DEFAULT NULL,
  `loyaltyBonusStorageKb` int(11) DEFAULT NULL,
  `loyaltyNextBonusDateTime` datetime DEFAULT NULL,
  `loyaltyNextBonusSheetCount` int(11) DEFAULT NULL,
  `loyaltyNextBonusStorageKb` int(11) DEFAULT NULL,
  `paymentTerm` tinyint(4) NOT NULL,
  `currencyCode` varchar(10) NOT NULL,
  `planRate` decimal(38,10) NOT NULL,
  `planTaxRate` decimal(38,10) NOT NULL,
  `taxCalculatedRate` decimal(38,10) NOT NULL,
  `taxLastCalcDateTime` datetime DEFAULT NULL,
  `primaryContactPhone` varchar(20) DEFAULT NULL,
  `referralEmailAddress` varchar(100) DEFAULT NULL,
  `reportingSeatCount` int(11) DEFAULT NULL,
  `billToRecurringBillingID` varchar(20) DEFAULT NULL,
  `billToCCNumber` varchar(20) DEFAULT NULL,
  `billToCCExpMonth` int(11) DEFAULT NULL,
  `billToCCExpYear` int(11) DEFAULT NULL,
  `billToCCName` varchar(100) DEFAULT NULL,
  `billToFirstName` varchar(50) DEFAULT NULL,
  `billToLastName` varchar(50) DEFAULT NULL,
  `billToEmailAddress` varchar(100) DEFAULT NULL,
  `billToCompany` varchar(50) DEFAULT NULL,
  `billToPO` varchar(50) DEFAULT NULL,
  `billToAddress1` varchar(50) DEFAULT NULL,
  `billToAddress2` varchar(50) DEFAULT NULL,
  `billToCity` varchar(50) DEFAULT NULL,
  `billToRegionCode` varchar(50) DEFAULT NULL,
  `billToPostCode` varchar(50) DEFAULT NULL,
  `billToCountryCode` varchar(50) DEFAULT NULL,
  `billToPPPayerID` varchar(50) DEFAULT NULL,
  `billToPPAgreementID` varchar(50) DEFAULT NULL,
  `billToPORequired` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `dataTimestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`paymentProfileID`),
  KEY `paymentProfile_idx0` (`ownerID`),
  KEY `paymentProfile_idx1` (`parentPaymentProfileID`),
  KEY `paymentProfile_idx2` (`billToPPPayerID`),
  KEY `paymentProfile_idx3` (`paymentEndDateTime`,`productID`),
  KEY `paymentProfile_idx4` (`paymentType`),
  KEY `idx_modifyDate` (`modifyDateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=9257907 DEFAULT CHARSET=utf8mb4;

/*Table structure for table `tmp_paymentProfile_marketoSynca` */

CREATE TABLE `tmp_paymentProfile_marketoSynca` (
  `paymentProfileID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ownerID` bigint(20) NOT NULL,
  `accountType` tinyint(4) NOT NULL,
  `paymentType` tinyint(4) NOT NULL,
  `paymentFlags` int(11) NOT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `paymentStartDateTime` datetime NOT NULL,
  `paymentEndDateTime` datetime DEFAULT NULL,
  `estimatedLastPaymentDate` datetime DEFAULT NULL,
  `actualLastPaymentDate` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `productID` int(11) NOT NULL,
  `productPriceID` int(11) DEFAULT NULL,
  `promoCode` varchar(50) DEFAULT NULL,
  `userLimit` int(11) NOT NULL,
  `bonusSheetCount` int(11) NOT NULL,
  `bonusUserCount` int(11) DEFAULT NULL,
  `bonusStorageKb` int(11) DEFAULT NULL,
  `loyaltyBonusSheetCount` int(11) DEFAULT NULL,
  `loyaltyBonusStorageKb` int(11) DEFAULT NULL,
  `loyaltyNextBonusDateTime` datetime DEFAULT NULL,
  `loyaltyNextBonusSheetCount` int(11) DEFAULT NULL,
  `loyaltyNextBonusStorageKb` int(11) DEFAULT NULL,
  `paymentTerm` tinyint(4) NOT NULL,
  `currencyCode` varchar(10) NOT NULL,
  `planRate` decimal(38,10) NOT NULL,
  `planTaxRate` decimal(38,10) NOT NULL,
  `taxCalculatedRate` decimal(38,10) NOT NULL,
  `taxLastCalcDateTime` datetime DEFAULT NULL,
  `primaryContactPhone` varchar(20) DEFAULT NULL,
  `referralEmailAddress` varchar(100) DEFAULT NULL,
  `reportingSeatCount` int(11) DEFAULT NULL,
  `billToRecurringBillingID` varchar(20) DEFAULT NULL,
  `billToCCNumber` varchar(20) DEFAULT NULL,
  `billToCCExpMonth` int(11) DEFAULT NULL,
  `billToCCExpYear` int(11) DEFAULT NULL,
  `billToCCName` varchar(100) DEFAULT NULL,
  `billToFirstName` varchar(50) DEFAULT NULL,
  `billToLastName` varchar(50) DEFAULT NULL,
  `billToEmailAddress` varchar(100) DEFAULT NULL,
  `billToCompany` varchar(50) DEFAULT NULL,
  `billToPO` varchar(50) DEFAULT NULL,
  `billToAddress1` varchar(50) DEFAULT NULL,
  `billToAddress2` varchar(50) DEFAULT NULL,
  `billToCity` varchar(50) DEFAULT NULL,
  `billToRegionCode` varchar(50) DEFAULT NULL,
  `billToPostCode` varchar(50) DEFAULT NULL,
  `billToCountryCode` varchar(50) DEFAULT NULL,
  `billToPPPayerID` varchar(50) DEFAULT NULL,
  `billToPPAgreementID` varchar(50) DEFAULT NULL,
  `billToPORequired` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `dataTimestamp` int(11) NOT NULL DEFAULT '0',
  `ourRole` varchar(50) DEFAULT NULL,
  `ourState` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`paymentProfileID`),
  KEY `paymentProfile_idx0` (`ownerID`),
  KEY `paymentProfile_idx1` (`parentPaymentProfileID`),
  KEY `paymentProfile_idx2` (`billToPPPayerID`),
  KEY `paymentProfile_idx3` (`paymentEndDateTime`,`productID`),
  KEY `paymentProfile_idx4` (`paymentType`),
  KEY `idx_modifyDate` (`modifyDateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=9075581 DEFAULT CHARSET=utf8mb4;

/*Table structure for table `tmp_payment_type` */

CREATE TABLE `tmp_payment_type` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `nextPaymentDate` datetime DEFAULT NULL,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_pp_our_updates` */

CREATE TABLE `tmp_pp_our_updates` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_product_cleanup` */

CREATE TABLE `tmp_product_cleanup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_sfdc_domain_account_usera` */

CREATE TABLE `tmp_sfdc_domain_account_usera` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `Domain_Name_URL__c` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `csEmail` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `csFirstName` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `csLastName` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `csPhone` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `doEmail` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `doFirstName` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `doLastName` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `doTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `doPhone` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_signup_cleanup` */

CREATE TABLE `tmp_signup_cleanup` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  `pushToMarketo` tinyint(1) DEFAULT NULL,
  `insertDateTime` datetime DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  `uploadDateTime` datetime DEFAULT NULL,
  `uploadStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userAccountModifyDateTime` datetime DEFAULT NULL,
  `ppModifyDateTime` datetime DEFAULT NULL,
  `trialModifyDateTime` datetime DEFAULT NULL,
  `salesforceOwnerAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceStatus` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `smartscoreCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceLeadSource` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailDomain` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isOrgDomain` tinyint(1) DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ABTests` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCountry` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedGoogleAuthentication` tinyint(1) DEFAULT NULL,
  `isGoogleAppsInstalledDomain` tinyint(1) DEFAULT NULL,
  `domainsHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainUseInPastYear` int(11) DEFAULT NULL,
  `currentDomainTrials` int(11) DEFAULT NULL,
  `wasSharedToPriorToTrial` tinyint(1) DEFAULT NULL,
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `productName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountRole` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `planRate` decimal(41,2) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(41,2) DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `teamTrial` tinyint(1) DEFAULT NULL,
  `trialStartDateTime` datetime DEFAULT NULL,
  `trialEndDateDateTime` datetime DEFAULT NULL,
  `isTrialRestart` tinyint(1) DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToAddress` varchar(101) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `historyHighestPlan` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTrackingKeyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_s_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_c_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupTracking_m_code` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `signupSubSource` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `marketoTrackingCookie` varchar(1500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastMobileLogin` datetime DEFAULT NULL,
  `isEverWellQualified` tinyint(1) DEFAULT NULL,
  `isStrongLead` tinyint(1) DEFAULT NULL,
  `eventLogCount` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `sheetCount` int(11) DEFAULT NULL,
  `sharingCount` int(11) DEFAULT NULL,
  `reportCount` int(11) DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `numberOfEmployees` int(11) DEFAULT NULL,
  `churnRiskCategory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `usedReminders` tinyint(1) DEFAULT NULL,
  `usedBrandedWorkspace` tinyint(1) DEFAULT NULL,
  `usedDriveAttachment` tinyint(1) DEFAULT NULL,
  `usedEvernoteAttachment` tinyint(1) DEFAULT NULL,
  `usedCellLinking` tinyint(1) DEFAULT NULL,
  `usedChangeView` tinyint(1) DEFAULT NULL,
  `discussionCount` int(11) DEFAULT NULL,
  `importedSheetCount` int(11) DEFAULT NULL,
  `templateCount` int(11) DEFAULT NULL,
  `webFormCount` int(11) DEFAULT NULL,
  `columnPropertyFormCount` int(11) DEFAULT NULL,
  `hierarchyCount` int(11) DEFAULT NULL,
  `attachmentCount` int(11) DEFAULT NULL,
  `upgradeWizardProgress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `insertSource` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `fitScore` tinyint(3) DEFAULT NULL,
  `fitRating` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appBehaviorScore` int(11) DEFAULT NULL,
  `appBehaviorScoreOld` int(11) DEFAULT NULL,
  `appBehaviorScoreNew` int(11) DEFAULT NULL,
  `recurringBillingCancelled` tinyint(1) DEFAULT NULL,
  `domainOptOut` tinyint(1) DEFAULT NULL,
  `appOptOut` tinyint(1) DEFAULT NULL,
  `containerCount` int(11) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `signupTrackingAppLaunchType` tinyint(1) DEFAULT NULL,
  `userAccountInsertByUserID` bigint(20) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `persona` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipRegion` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `organizationRoles` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `inferredTitle` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `iOSAppLoginCount` int(11) DEFAULT NULL,
  `androidAppLoginCount` int(11) DEFAULT NULL,
  `highestSharedSheetPermission` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `solutionsUsed` varchar(1000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `salesforceOwnerRoleAtImport` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipCity` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `isUserAgreementAccepted` tinyint(1) DEFAULT NULL,
  `imagesInGridCount` int(11) DEFAULT NULL,
  `organizationID` bigint(20) DEFAULT NULL,
  `inferredRole` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dashboardsEnabledDateTime` datetime DEFAULT NULL,
  `dashboardCount` int(11) DEFAULT NULL,
  `successRepEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `successRepPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountHealth` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountTier` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountCSADripBucket` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerEmail` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerFirstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerLastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerTitle` varchar(80) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `domainOwnerPhoneNumber` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `orgProductName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `bonusLicenseLimit` int(11) DEFAULT NULL,
  `assignedLicenseCount` int(11) DEFAULT NULL,
  `pendingLicenseCount` int(11) DEFAULT NULL,
  `licenseTags` varchar(256) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `cardViewViewCount` int(11) DEFAULT NULL,
  `lastBulletinCloseDateTime` datetime DEFAULT NULL,
  `accountTerritory` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `previousUserLimit` int(11) DEFAULT NULL,
  `userTags` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyBuckets` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `idx_emailAddress` (`emailAddress`),
  KEY `idx_paymentProfileId` (`paymentProfileID`),
  KEY `idx_insertDateTime` (`insertDateTime`),
  KEY `idx_emailDomain` (`emailDomain`),
  KEY `idx_ppModifyDateTime` (`ppModifyDateTime`),
  KEY `idx_push_to_marketo` (`pushToMarketo`),
  KEY `idx_isOrgDomain` (`isOrgDomain`),
  KEY `idx_dashboardsEnabledDateTime` (`dashboardsEnabledDateTime`),
  KEY `salesforceOwnerAtImport` (`salesforceOwnerAtImport`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `tmp_update_users` */

CREATE TABLE `tmp_update_users` (
  `userId` bigint(20) NOT NULL DEFAULT '0',
  KEY `idxtmp` (`userId`)
) ENGINE=TokuDB DEFAULT CHARSET=latin1;

/*Table structure for table `tmp_usage_data_updated_since_20170202` */

CREATE TABLE `tmp_usage_data_updated_since_20170202` (
  `userID` bigint(20) NOT NULL DEFAULT '0',
  KEY `userID` (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/*Table structure for table `userLead` */

CREATE TABLE `userLead` (
  `userID` bigint(20) NOT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `firstName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `accountStateID` smallint(6) DEFAULT NULL,
  `accountRole` enum('Individual','Member','Owner') COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Individual',
  `organizationName` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `statusFlags` int(11) DEFAULT NULL,
  `accountCreateDateTime` datetime NOT NULL,
  `accountCreateByUserID` bigint(20) NOT NULL,
  `locale` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `newsFlags` int(11) NOT NULL DEFAULT '0',
  `paymentProfileID` bigint(20) DEFAULT NULL,
  `parentPaymentProfileID` bigint(20) DEFAULT NULL,
  `paymentStartDateTime` datetime DEFAULT NULL,
  `paymentTerm` tinyint(4) DEFAULT NULL,
  `nextPaymentDateTime` datetime DEFAULT NULL,
  `primaryContactPhone` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCity` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToRegionCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToPostCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `billToCountryCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `paymentProfileInsertDateTime` datetime DEFAULT NULL,
  `paymentProfileModifyDateTime` datetime DEFAULT NULL,
  `paymentFlags` int(11) NOT NULL DEFAULT '0',
  `accountType` tinyint(4) DEFAULT NULL,
  `productID` int(11) DEFAULT NULL,
  `previousProductID` int(11) DEFAULT NULL,
  `userLimit` int(11) DEFAULT NULL,
  `parentPaymentStartDateTime` datetime DEFAULT NULL,
  `parentPaymentEndDateTime` datetime DEFAULT NULL,
  `currencyCode` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `planRate` decimal(38,10) DEFAULT NULL,
  `monthlyPlanRate_USD` decimal(38,10) DEFAULT NULL,
  `signupRequestID` bigint(20) DEFAULT NULL,
  `googleServiceUse` int(10) unsigned DEFAULT '0',
  `errata` text COLLATE utf8mb4_unicode_520_ci,
  `lastEventSourceID` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'mysql-bin.000000:0000000000000000',
  `addedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedDateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `serialNumber` int(10) unsigned DEFAULT '1',
  PRIMARY KEY (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci COMMENT='The core marketing information about a user account';

/*Table structure for table `userSignupRequest` */

CREATE TABLE `userSignupRequest` (
  `userID` bigint(20) NOT NULL,
  `signupRequestID` bigint(20) NOT NULL,
  `firstName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lastName` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `emailAddress` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resultStatus` smallint(6) DEFAULT NULL,
  `resultErrorCode` smallint(6) DEFAULT NULL,
  `insertDateTime` datetime NOT NULL,
  `insertByUserID` bigint(20) NOT NULL,
  `modifyDateTime` datetime NOT NULL,
  `modifyByUserID` bigint(20) NOT NULL,
  `sessionLogID` bigint(20) NOT NULL,
  `keyword` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sourceID` int(9) DEFAULT NULL,
  `campaignID` int(9) DEFAULT NULL,
  `marketSegmentID` int(9) DEFAULT NULL,
  `adVersionID` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `landingPage` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `landingPageVersion` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `clickPath` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `trialPathID` int(11) DEFAULT NULL,
  `queryString` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `adSite` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `adPlacement` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `matchType` varchar(25) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `adNetworkSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appLaunchType` smallint(6) DEFAULT NULL,
  `referringUserCode` varchar(14) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referringUserID` bigint(20) DEFAULT NULL,
  `referrerURL` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subSourceType` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `subSourceID` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `deviceType` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `deviceModel` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `googleClickID` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `utmExperimentID` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `aBTestBucket` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `webSiteChat` enum('Yes','No','Error') COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `remarketingSourceID` int(9) DEFAULT NULL,
  `remarketingAdVersionID` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `remarketingMarketSegmentID` int(9) DEFAULT NULL,
  `remarketingCampaignID` int(9) DEFAULT NULL,
  `marketoCookie` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `adID` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `phraseID` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `positionID` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `positionType` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `additionalPhrases` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `mishmashSource` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `typeData` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `googleSiteLinksCode` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `apiClientID` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelyExperimentIDs` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `optimizelySegmentsMap` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `thirdPartyState` varchar(500) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `appLaunchParm1` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ipAddress` varchar(46) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `samlValue` varchar(258) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `errata` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`userID`)
) ENGINE=TokuDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

/* Trigger structure for table `arc_marketo_upload` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'jmarzinke'@'%' */ /*!50003 TRIGGER `arc_marketo_upload_insert` BEFORE INSERT ON `arc_marketo_upload` FOR EACH ROW BEGIN
  IF @disable_triggers IS NULL THEN
    INSERT INTO arc_marketo_upload_journal
    SET journalAction = 'INSERT',
      userID = NEW.userID,
      pushToMarketo = NEW.pushToMarketo,
      insertDateTime = NEW.insertDateTime,
      updateDateTime = NEW.updateDateTime,
      uploadDateTime = NEW.uploadDateTime,
      uploadStatus = NEW.uploadStatus,
      userAccountModifyDateTime = NEW.userAccountModifyDateTime,
      ppModifyDateTime = NEW.ppModifyDateTime,
      trialModifyDateTime = NEW.trialModifyDateTime,
      salesforceOwnerAtImport = NEW.salesforceOwnerAtImport,
      salesforceStatus = NEW.salesforceStatus,
      smartscoreCode = NEW.smartscoreCode,
      salesforceLeadSource = NEW.salesforceLeadSource,
      firstName = NEW.firstName,
      lastName = NEW.lastName,
      emailAddress = NEW.emailAddress,
      emailDomain = NEW.emailDomain,
      isOrgDomain = NEW.isOrgDomain,
      website = NEW.website,
      newsFlags = NEW.newsFlags,
      statusFlags = NEW.statusFlags,
      locale = NEW.locale,
      timeZone = NEW.timeZone,
      ABTests = NEW.ABTests,
      ipCountry = NEW.ipCountry,
      usedGoogleAuthentication = NEW.usedGoogleAuthentication,
      isGoogleAppsInstalledDomain = NEW.isGoogleAppsInstalledDomain,
      domainsHighestPlan = NEW.domainsHighestPlan,
      domainUseInPastYear = NEW.domainUseInPastYear,
      currentDomainTrials = NEW.currentDomainTrials,
      wasSharedToPriorToTrial = NEW.wasSharedToPriorToTrial,
      paymentProfileID = NEW.paymentProfileID,
      parentPaymentProfileID = NEW.parentPaymentProfileID,
      productName = NEW.productName,
      accountRole = NEW.accountRole,
      userLimit = NEW.userLimit,
      paymentStartDateTime = NEW.paymentStartDateTime,
      nextPaymentDate = NEW.nextPaymentDate,
      paymentTerm = NEW.paymentTerm,
      planRate = NEW.planRate,
      monthlyPlanRate_USD = NEW.monthlyPlanRate_USD,
      currencyCode = NEW.currencyCode,
      teamTrial = NEW.teamTrial,
      trialStartDateTime = NEW.trialStartDateTime,
      trialEndDateDateTime = NEW.trialEndDateDateTime,
      isTrialRestart = NEW.isTrialRestart,
      primaryContactPhone = NEW.primaryContactPhone,
      billToAddress = NEW.billToAddress,
      billToCity = NEW.billToCity,
      billToRegionCode = NEW.billToRegionCode,
      billToPostCode = NEW.billToPostCode,
      billToCountryCode = NEW.billToCountryCode,
      organizationName = NEW.organizationName,
      historyHighestPlan = NEW.historyHighestPlan,
      signupTrackingKeyword = NEW.signupTrackingKeyword,
      signupTracking_s_code = NEW.signupTracking_s_code,
      signupTracking_c_code = NEW.signupTracking_c_code,
      signupTracking_m_code = NEW.signupTracking_m_code,
      signupBucket = NEW.signupBucket,
      signupSource = NEW.signupSource,
      signupSubSource = NEW.signupSubSource,
      marketoTrackingCookie = NEW.marketoTrackingCookie,
      lastLogin = NEW.lastLogin,
      lastMobileLogin = NEW.lastMobileLogin,
      isEverWellQualified = NEW.isEverWellQualified,
      isStrongLead = NEW.isStrongLead,
      eventLogCount = NEW.eventLogCount,
      loginCount = NEW.loginCount,
      sheetCount = NEW.sheetCount,
      sharingCount = NEW.sharingCount,
      reportCount = NEW.reportCount,
      company = NEW.company,
      numberOfEmployees = NEW.numberOfEmployees,
      churnRiskCategory = NEW.churnRiskCategory,
      role = NEW.role,
      usedReminders = NEW.usedReminders,
      usedBrandedWorkspace = NEW.usedBrandedWorkspace,
      usedDriveAttachment = NEW.usedDriveAttachment,
      usedEvernoteAttachment = NEW.usedEvernoteAttachment,
      usedCellLinking = NEW.usedCellLinking,
      usedChangeView = NEW.usedChangeView,
      discussionCount = NEW.discussionCount,
      importedSheetCount = NEW.importedSheetCount,
      templateCount = NEW.templateCount,
      webFormCount = NEW.webFormCount,
      columnPropertyFormCount = NEW.columnPropertyFormCount,
      hierarchyCount = NEW.hierarchyCount,
      attachmentCount = NEW.attachmentCount,
      upgradeWizardProgress = NEW.upgradeWizardProgress,
      insertSource = NEW.insertSource,
      fitScore = NEW.fitScore,
      fitRating = NEW.fitRating,
      appBehaviorScore = NEW.appBehaviorScore,
      appBehaviorScoreOld = NEW.appBehaviorScoreOld,
      appBehaviorScoreNew = NEW.appBehaviorScoreNew,
      recurringBillingCancelled = NEW.recurringBillingCancelled,
      domainOptOut = NEW.domainOptOut,
      appOptOut = NEW.appOptOut,
      containerCount = NEW.containerCount,
      signupRequestID = NEW.signupRequestID,
      signupTrackingAppLaunchType = NEW.signupTrackingAppLaunchType,
      userAccountInsertByUserID = NEW.userAccountInsertByUserID,
      parentPaymentStartDateTime = NEW.parentPaymentStartDateTime,
      persona = NEW.persona,
      ipRegion = NEW.ipRegion,
      organizationRoles = NEW.organizationRoles,
      inferredTitle = NEW.inferredTitle,
      iOSAppLoginCount = NEW.iOSAppLoginCount,
      androidAppLoginCount = NEW.androidAppLoginCount,
      highestSharedSheetPermission = NEW.highestSharedSheetPermission,
      solutionsUsed = NEW.solutionsUsed,
      salesforceOwnerRoleAtImport = NEW.salesforceOwnerRoleAtImport,
      ipCity = NEW.ipCity,
      isUserAgreementAccepted = NEW.isUserAgreementAccepted,
      imagesInGridCount = NEW.imagesInGridCount,
      organizationID = NEW.organizationID,
      inferredRole = NEW.inferredRole,
      dashboardsEnabledDateTime = NEW.dashboardsEnabledDateTime,
      dashboardCount = NEW.dashboardCount,
      successRepEmail = NEW.successRepEmail,
      successRepFirstName = NEW.successRepFirstName,
      successRepLastName = NEW.successRepLastName,
      successRepPhoneNumber = NEW.successRepPhoneNumber,
      accountHealth = NEW.accountHealth,
      accountTier = NEW.accountTier,
      accountCSADripBucket = NEW.accountCSADripBucket,
      domainOwnerEmail = NEW.domainOwnerEmail,
      domainOwnerFirstName = NEW.domainOwnerFirstName,
      domainOwnerLastName = NEW.domainOwnerLastName,
      domainOwnerTitle = NEW.domainOwnerTitle,
      domainOwnerPhoneNumber = NEW.domainOwnerPhoneNumber,
      orgProductName = NEW.orgProductName,
      bonusLicenseLimit = NEW.bonusLicenseLimit,
      assignedLicenseCount = NEW.assignedLicenseCount,
      pendingLicenseCount = NEW.pendingLicenseCount,
      licenseTags = NEW.licenseTags,
      cardViewViewCount = NEW.cardViewViewCount,
      lastBulletinCloseDateTime = NEW.lastBulletinCloseDateTime,
      accountTerritory = NEW.accountTerritory,
      previousUserLimit = NEW.previousUserLimit,
      userTags = NEW.userTags,
      optimizelyBuckets = NEW.optimizelyBuckets,
      paymentType = NEW.paymentType
    ;
  END IF;
END */$$


DELIMITER ;

/* Trigger structure for table `arc_marketo_upload` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'jmarzinke'@'%' */ /*!50003 TRIGGER `arc_marketo_upload_update` BEFORE UPDATE ON `arc_marketo_upload` FOR EACH ROW BEGIN
  if @disable_triggers is null then
    INSERT INTO arc_marketo_upload_journal
    SET journalAction = 'UPDATE',
      userID = NEW.userID,
      pushToMarketo = NEW.pushToMarketo,
      insertDateTime = NEW.insertDateTime,
      updateDateTime = NEW.updateDateTime,
      uploadDateTime = NEW.uploadDateTime,
      uploadStatus = NEW.uploadStatus,
      userAccountModifyDateTime = NEW.userAccountModifyDateTime,
      ppModifyDateTime = NEW.ppModifyDateTime,
      trialModifyDateTime = NEW.trialModifyDateTime,
      salesforceOwnerAtImport = NEW.salesforceOwnerAtImport,
      salesforceStatus = NEW.salesforceStatus,
      smartscoreCode = NEW.smartscoreCode,
      salesforceLeadSource = NEW.salesforceLeadSource,
      firstName = NEW.firstName,
      lastName = NEW.lastName,
      emailAddress = NEW.emailAddress,
      emailDomain = NEW.emailDomain,
      isOrgDomain = NEW.isOrgDomain,
      website = NEW.website,
      newsFlags = NEW.newsFlags,
      statusFlags = NEW.statusFlags,
      locale = NEW.locale,
      timeZone = NEW.timeZone,
      ABTests = NEW.ABTests,
      ipCountry = NEW.ipCountry,
      usedGoogleAuthentication = NEW.usedGoogleAuthentication,
      isGoogleAppsInstalledDomain = NEW.isGoogleAppsInstalledDomain,
      domainsHighestPlan = NEW.domainsHighestPlan,
      domainUseInPastYear = NEW.domainUseInPastYear,
      currentDomainTrials = NEW.currentDomainTrials,
      wasSharedToPriorToTrial = NEW.wasSharedToPriorToTrial,
      paymentProfileID = NEW.paymentProfileID,
      parentPaymentProfileID = NEW.parentPaymentProfileID,
      productName = NEW.productName,
      accountRole = NEW.accountRole,
      userLimit = NEW.userLimit,
      paymentStartDateTime = NEW.paymentStartDateTime,
      nextPaymentDate = NEW.nextPaymentDate,
      paymentTerm = NEW.paymentTerm,
      planRate = NEW.planRate,
      monthlyPlanRate_USD = NEW.monthlyPlanRate_USD,
      currencyCode = NEW.currencyCode,
      teamTrial = NEW.teamTrial,
      trialStartDateTime = NEW.trialStartDateTime,
      trialEndDateDateTime = NEW.trialEndDateDateTime,
      isTrialRestart = NEW.isTrialRestart,
      primaryContactPhone = NEW.primaryContactPhone,
      billToAddress = NEW.billToAddress,
      billToCity = NEW.billToCity,
      billToRegionCode = NEW.billToRegionCode,
      billToPostCode = NEW.billToPostCode,
      billToCountryCode = NEW.billToCountryCode,
      organizationName = NEW.organizationName,
      historyHighestPlan = NEW.historyHighestPlan,
      signupTrackingKeyword = NEW.signupTrackingKeyword,
      signupTracking_s_code = NEW.signupTracking_s_code,
      signupTracking_c_code = NEW.signupTracking_c_code,
      signupTracking_m_code = NEW.signupTracking_m_code,
      signupBucket = NEW.signupBucket,
      signupSource = NEW.signupSource,
      signupSubSource = NEW.signupSubSource,
      marketoTrackingCookie = NEW.marketoTrackingCookie,
      lastLogin = NEW.lastLogin,
      lastMobileLogin = NEW.lastMobileLogin,
      isEverWellQualified = NEW.isEverWellQualified,
      isStrongLead = NEW.isStrongLead,
      eventLogCount = NEW.eventLogCount,
      loginCount = NEW.loginCount,
      sheetCount = NEW.sheetCount,
      sharingCount = NEW.sharingCount,
      reportCount = NEW.reportCount,
      company = NEW.company,
      numberOfEmployees = NEW.numberOfEmployees,
      churnRiskCategory = NEW.churnRiskCategory,
      role = NEW.role,
      usedReminders = NEW.usedReminders,
      usedBrandedWorkspace = NEW.usedBrandedWorkspace,
      usedDriveAttachment = NEW.usedDriveAttachment,
      usedEvernoteAttachment = NEW.usedEvernoteAttachment,
      usedCellLinking = NEW.usedCellLinking,
      usedChangeView = NEW.usedChangeView,
      discussionCount = NEW.discussionCount,
      importedSheetCount = NEW.importedSheetCount,
      templateCount = NEW.templateCount,
      webFormCount = NEW.webFormCount,
      columnPropertyFormCount = NEW.columnPropertyFormCount,
      hierarchyCount = NEW.hierarchyCount,
      attachmentCount = NEW.attachmentCount,
      upgradeWizardProgress = NEW.upgradeWizardProgress,
      insertSource = NEW.insertSource,
      fitScore = NEW.fitScore,
      fitRating = NEW.fitRating,
      appBehaviorScore = NEW.appBehaviorScore,
      appBehaviorScoreOld = NEW.appBehaviorScoreOld,
      appBehaviorScoreNew = NEW.appBehaviorScoreNew,
      recurringBillingCancelled = NEW.recurringBillingCancelled,
      domainOptOut = NEW.domainOptOut,
      appOptOut = NEW.appOptOut,
      containerCount = NEW.containerCount,
      signupRequestID = NEW.signupRequestID,
      signupTrackingAppLaunchType = NEW.signupTrackingAppLaunchType,
      userAccountInsertByUserID = NEW.userAccountInsertByUserID,
      parentPaymentStartDateTime = NEW.parentPaymentStartDateTime,
      persona = NEW.persona,
      ipRegion = NEW.ipRegion,
      organizationRoles = NEW.organizationRoles,
      inferredTitle = NEW.inferredTitle,
      iOSAppLoginCount = NEW.iOSAppLoginCount,
      androidAppLoginCount = NEW.androidAppLoginCount,
      highestSharedSheetPermission = NEW.highestSharedSheetPermission,
      solutionsUsed = NEW.solutionsUsed,
      salesforceOwnerRoleAtImport = NEW.salesforceOwnerRoleAtImport,
      ipCity = NEW.ipCity,
      isUserAgreementAccepted = NEW.isUserAgreementAccepted,
      imagesInGridCount = NEW.imagesInGridCount,
      organizationID = NEW.organizationID,
      inferredRole = NEW.inferredRole,
      dashboardsEnabledDateTime = NEW.dashboardsEnabledDateTime,
      dashboardCount = NEW.dashboardCount,
      successRepEmail = NEW.successRepEmail,
      successRepFirstName = NEW.successRepFirstName,
      successRepLastName = NEW.successRepLastName,
      successRepPhoneNumber = NEW.successRepPhoneNumber,
      accountHealth = NEW.accountHealth,
      accountTier = NEW.accountTier,
      accountCSADripBucket = NEW.accountCSADripBucket,
      domainOwnerEmail = NEW.domainOwnerEmail,
      domainOwnerFirstName = NEW.domainOwnerFirstName,
      domainOwnerLastName = NEW.domainOwnerLastName,
      domainOwnerTitle = NEW.domainOwnerTitle,
      domainOwnerPhoneNumber = NEW.domainOwnerPhoneNumber,
      orgProductName = NEW.orgProductName,
      bonusLicenseLimit = NEW.bonusLicenseLimit,
      assignedLicenseCount = NEW.assignedLicenseCount,
      pendingLicenseCount = NEW.pendingLicenseCount,
      licenseTags = NEW.licenseTags,
      cardViewViewCount = NEW.cardViewViewCount,
      lastBulletinCloseDateTime = NEW.lastBulletinCloseDateTime,
      accountTerritory = NEW.accountTerritory,
      previousUserLimit = NEW.previousUserLimit,
      userTags = NEW.userTags,
      optimizelyBuckets = NEW.optimizelyBuckets,
      paymentType = NEW.paymentType
    ;
  end if;
END */$$


DELIMITER ;

/* Trigger structure for table `arc_marketo_upload` */

DELIMITER $$

/*!50003 CREATE */ /*!50017 DEFINER = 'jmarzinke'@'%' */ /*!50003 TRIGGER `arc_marketo_upload_delete` BEFORE DELETE ON `arc_marketo_upload` FOR EACH ROW BEGIN
  IF @disable_triggers IS NULL THEN
    INSERT INTO arc_marketo_upload_journal
    SET journalAction = 'DELETE',
      userID = OLD.userID,
      pushToMarketo = OLD.pushToMarketo,
      insertDateTime = OLD.insertDateTime,
      updateDateTime = OLD.updateDateTime,
      uploadDateTime = OLD.uploadDateTime,
      uploadStatus = OLD.uploadStatus,
      userAccountModifyDateTime = OLD.userAccountModifyDateTime,
      ppModifyDateTime = OLD.ppModifyDateTime,
      trialModifyDateTime = OLD.trialModifyDateTime,
      salesforceOwnerAtImport = OLD.salesforceOwnerAtImport,
      salesforceStatus = OLD.salesforceStatus,
      smartscoreCode = OLD.smartscoreCode,
      salesforceLeadSource = OLD.salesforceLeadSource,
      firstName = OLD.firstName,
      lastName = OLD.lastName,
      emailAddress = OLD.emailAddress,
      emailDomain = OLD.emailDomain,
      isOrgDomain = OLD.isOrgDomain,
      website = OLD.website,
      newsFlags = OLD.newsFlags,
      statusFlags = OLD.statusFlags,
      locale = OLD.locale,
      timeZone = OLD.timeZone,
      ABTests = OLD.ABTests,
      ipCountry = OLD.ipCountry,
      usedGoogleAuthentication = OLD.usedGoogleAuthentication,
      isGoogleAppsInstalledDomain = OLD.isGoogleAppsInstalledDomain,
      domainsHighestPlan = OLD.domainsHighestPlan,
      domainUseInPastYear = OLD.domainUseInPastYear,
      currentDomainTrials = OLD.currentDomainTrials,
      wasSharedToPriorToTrial = OLD.wasSharedToPriorToTrial,
      paymentProfileID = OLD.paymentProfileID,
      parentPaymentProfileID = OLD.parentPaymentProfileID,
      productName = OLD.productName,
      accountRole = OLD.accountRole,
      userLimit = OLD.userLimit,
      paymentStartDateTime = OLD.paymentStartDateTime,
      nextPaymentDate = OLD.nextPaymentDate,
      paymentTerm = OLD.paymentTerm,
      planRate = OLD.planRate,
      monthlyPlanRate_USD = OLD.monthlyPlanRate_USD,
      currencyCode = OLD.currencyCode,
      teamTrial = OLD.teamTrial,
      trialStartDateTime = OLD.trialStartDateTime,
      trialEndDateDateTime = OLD.trialEndDateDateTime,
      isTrialRestart = OLD.isTrialRestart,
      primaryContactPhone = OLD.primaryContactPhone,
      billToAddress = OLD.billToAddress,
      billToCity = OLD.billToCity,
      billToRegionCode = OLD.billToRegionCode,
      billToPostCode = OLD.billToPostCode,
      billToCountryCode = OLD.billToCountryCode,
      organizationName = OLD.organizationName,
      historyHighestPlan = OLD.historyHighestPlan,
      signupTrackingKeyword = OLD.signupTrackingKeyword,
      signupTracking_s_code = OLD.signupTracking_s_code,
      signupTracking_c_code = OLD.signupTracking_c_code,
      signupTracking_m_code = OLD.signupTracking_m_code,
      signupBucket = OLD.signupBucket,
      signupSource = OLD.signupSource,
      signupSubSource = OLD.signupSubSource,
      marketoTrackingCookie = OLD.marketoTrackingCookie,
      lastLogin = OLD.lastLogin,
      lastMobileLogin = OLD.lastMobileLogin,
      isEverWellQualified = OLD.isEverWellQualified,
      isStrongLead = OLD.isStrongLead,
      eventLogCount = OLD.eventLogCount,
      loginCount = OLD.loginCount,
      sheetCount = OLD.sheetCount,
      sharingCount = OLD.sharingCount,
      reportCount = OLD.reportCount,
      company = OLD.company,
      numberOfEmployees = OLD.numberOfEmployees,
      churnRiskCategory = OLD.churnRiskCategory,
      role = OLD.role,
      usedReminders = OLD.usedReminders,
      usedBrandedWorkspace = OLD.usedBrandedWorkspace,
      usedDriveAttachment = OLD.usedDriveAttachment,
      usedEvernoteAttachment = OLD.usedEvernoteAttachment,
      usedCellLinking = OLD.usedCellLinking,
      usedChangeView = OLD.usedChangeView,
      discussionCount = OLD.discussionCount,
      importedSheetCount = OLD.importedSheetCount,
      templateCount = OLD.templateCount,
      webFormCount = OLD.webFormCount,
      columnPropertyFormCount = OLD.columnPropertyFormCount,
      hierarchyCount = OLD.hierarchyCount,
      attachmentCount = OLD.attachmentCount,
      upgradeWizardProgress = OLD.upgradeWizardProgress,
      insertSource = OLD.insertSource,
      fitScore = OLD.fitScore,
      fitRating = OLD.fitRating,
      appBehaviorScore = OLD.appBehaviorScore,
      appBehaviorScoreOld = OLD.appBehaviorScoreOld,
      appBehaviorScoreNew = OLD.appBehaviorScoreNew,
      recurringBillingCancelled = OLD.recurringBillingCancelled,
      domainOptOut = OLD.domainOptOut,
      appOptOut = OLD.appOptOut,
      containerCount = OLD.containerCount,
      signupRequestID = OLD.signupRequestID,
      signupTrackingAppLaunchType = OLD.signupTrackingAppLaunchType,
      userAccountInsertByUserID = OLD.userAccountInsertByUserID,
      parentPaymentStartDateTime = OLD.parentPaymentStartDateTime,
      persona = OLD.persona,
      ipRegion = OLD.ipRegion,
      organizationRoles = OLD.organizationRoles,
      inferredTitle = OLD.inferredTitle,
      iOSAppLoginCount = OLD.iOSAppLoginCount,
      androidAppLoginCount = OLD.androidAppLoginCount,
      highestSharedSheetPermission = OLD.highestSharedSheetPermission,
      solutionsUsed = OLD.solutionsUsed,
      salesforceOwnerRoleAtImport = OLD.salesforceOwnerRoleAtImport,
      ipCity = OLD.ipCity,
      isUserAgreementAccepted = OLD.isUserAgreementAccepted,
      imagesInGridCount = OLD.imagesInGridCount,
      organizationID = OLD.organizationID,
      inferredRole = OLD.inferredRole,
      dashboardsEnabledDateTime = OLD.dashboardsEnabledDateTime,
      dashboardCount = OLD.dashboardCount,
      successRepEmail = OLD.successRepEmail,
      successRepFirstName = OLD.successRepFirstName,
      successRepLastName = OLD.successRepLastName,
      successRepPhoneNumber = OLD.successRepPhoneNumber,
      accountHealth = OLD.accountHealth,
      accountTier = OLD.accountTier,
      accountCSADripBucket = OLD.accountCSADripBucket,
      domainOwnerEmail = OLD.domainOwnerEmail,
      domainOwnerFirstName = OLD.domainOwnerFirstName,
      domainOwnerLastName = OLD.domainOwnerLastName,
      domainOwnerTitle = OLD.domainOwnerTitle,
      domainOwnerPhoneNumber = OLD.domainOwnerPhoneNumber,
      orgProductName = OLD.orgProductName,
      bonusLicenseLimit = OLD.bonusLicenseLimit,
      assignedLicenseCount = OLD.assignedLicenseCount,
      pendingLicenseCount = OLD.pendingLicenseCount,
      licenseTags = OLD.licenseTags,
      cardViewViewCount = OLD.cardViewViewCount,
      lastBulletinCloseDateTime = OLD.lastBulletinCloseDateTime,
      accountTerritory = OLD.accountTerritory,
      previousUserLimit = OLD.previousUserLimit,
      userTags = OLD.userTags,
      optimizelyBuckets = OLD.optimizelyBuckets,
      paymentType = OLD.paymentType
    ;
  END IF;
END */$$


DELIMITER ;

/* Function  structure for function  `getAppBehaviorScoreV1` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getAppBehaviorScoreV1`(loginCount INT, eventLogCount INT, sheetCount INT, sharingCount INT,  reportCount INT,
                                                                         isTeamTrial INT, accountRole varchar(100)) RETURNS int(11)
DETERMINISTIC
  BEGIN
    DECLARE getBehaviorScore INT;
    SET getBehaviorScore =
    COALESCE(loginCount, 0) +
    COALESCE(eventLogCount / 100, 0)  +
    (COALESCE(sheetCount, 0) * 5) +
    (COALESCE(sharingCount, 0) * 5)	+
    (LEAST(COALESCE(sharingCount, 0), 1) * 15) +
    (COALESCE(reportCount, 0) * 5)	+
    (LEAST(COALESCE(reportCount, 0), 1) * 15);



    IF isTeamTrial = 1
    THEN SET getBehaviorScore = getBehaviorScore + 10;
    end if;
    IF isTeamTrial = 1 AND accountRole = "Owner"
    THEN SET getBehaviorScore = getBehaviorScore + 10;
    END IF;
    RETURN getBehaviorScore;
  END */$$
DELIMITER ;

/* Function  structure for function  `getFitScoreV1` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getFitScoreV1`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50), m_code INT, wasShared INT) RETURNS tinyint(3)
DETERMINISTIC
  BEGIN

    DECLARE betaZero DECIMAL(20,5);
    DECLARE beta1 DECIMAL(20,5);
    DECLARE beta2 DECIMAL(20,5);
    DECLARE beta3 DECIMAL(20,5);
    DECLARE beta4 DECIMAL (20,5);
    DECLARE P DECIMAL(20,10);
    DECLARE aP DECIMAL(20,10);
    DECLARE fP DECIMAL (10,6);
    DECLARE dm INT;
    DECLARE X1 VARCHAR(50);
    DECLARE X2a VARCHAR(50);
    DECLARE X2b VARCHAR (50);
    DECLARE X2 VARCHAR(50);
    DECLARE X3 VARCHAR(50);
    DECLARE X4 INT;
    SET dm = isOrgDomain;
    SET X1 = 	(CASE
                 WHEN locale IS NULL THEN 'None'
                 ELSE locale
                 END);
    SET X2a = 	(CASE
                  WHEN s_code IS NULL THEN 'None'
                  WHEN s_code = '' 	THEN 'Blank'
                  ELSE s_code
                  END);
    SET X2b = (CASE
               WHEN c_code IS NULL THEN 'None'
               WHEN c_code = '' 	THEN 'Blank'
               ELSE c_code
               END);
    SET X2 = CONCAT(X2a, "_", X2b);

    SET X3 = 	(CASE
                 WHEN m_code IS NULL THEN 'None'
                 WHEN m_code = '' 	THEN 'Blank'
                 ELSE m_code
                 END);
    SET X4 = wasShared;
    IF dm = '0' THEN SET aP = '.001';

    ELSEIF dm = '1' AND (
      (X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
      OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
      OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
      OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
      OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
      OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
      OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
    )
      THEN SET aP = '.001';

    ELSEIF dm = '1'
      THEN SET
      betaZero = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'Intercept'),
      beta1 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'locale' AND  c.Variable = X1),
      beta2 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'sc_code' AND c.Variable = X2),
      beta3 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'm_code' AND  c.Variable = X3),
      beta4 = (SELECT Coefficient FROM rpt_fitScoreModelV1 c WHERE c.Category = 'wasSharedToPriorToTrial'),
      P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4))+1);

        SET aP = (CASE WHEN P > .1 THEN .1
                  WHEN P <.001 THEN .001
                  WHEN P IS NULL THEN .015
                  ELSE P
                  END);
    END IF;
    SET fP = ROUND(aP*1000);
    RETURN fP;
  END */$$
DELIMITER ;

/* Function  structure for function  `getFitScoreV2` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `getFitScoreV2`(isOrgDomain INT, locale VARCHAR(50), s_code VARCHAR(50), c_code VARCHAR(50),
                                                                 m_code      VARCHAR(50), wasShared INT, inserteduser TINYINT,
                                                                 itemValue   VARCHAR(25)) RETURNS tinyint(3)
  BEGIN

    DECLARE betaZero DECIMAL(20,5);
    DECLARE beta1 DECIMAL(20,5);
    DECLARE beta2 DECIMAL(20,5);
    DECLARE beta3 DECIMAL(20,5);
    DECLARE beta4 DECIMAL (20,5);
    DECLARE beta5 DECIMAL (20,5);
    DECLARE P DECIMAL(20,10);
    DECLARE aP DECIMAL(20,10);
    DECLARE fP DECIMAL (10,6);
    DECLARE dm INT;
    DECLARE X1 VARCHAR(50);
    DECLARE X2a VARCHAR(50);
    DECLARE X2b VARCHAR (50);
    DECLARE X2 VARCHAR(50);
    DECLARE X3 VARCHAR(50);
    DECLARE X4 INT;
    DECLARE X5 INT;
    DECLARE X6 INT;
    SET dm = isOrgDomain;
    SET X1 = 	(CASE
                 WHEN locale IS NULL THEN 'None'
                 ELSE locale
                 END);
    SET X2a = 	(CASE
                  WHEN s_code IS NULL THEN 'None'
                  WHEN s_code = '' 	THEN 'Blank'
                  ELSE s_code
                  END);
    SET X2b = (CASE
               WHEN c_code IS NULL THEN 'None'
               WHEN c_code = '' 	THEN 'Blank'
               ELSE c_code
               END);
    SET X2 = CONCAT(X2a, "_", X2b);

    SET X3 = 	(CASE
                 WHEN m_code IS NULL THEN 'None'
                 WHEN m_code = '' 	THEN 'Blank'
                 ELSE m_code
                 END);
    SET X4 = wasShared;
    SET X5 = inserteduser;
    SET X6 = itemValue;
    IF (dm = 0 OR (X6 IN ('2','6','10','11') AND (X2a = 'None' or X2a = 'Blank'))) THEN SET aP = '.001';

    ELSEIF dm = '1' AND (
      (X1 = 'en_US' AND X2 = '1_69' AND X3 = '350' AND X4 =0)
      OR (X1 = 'en_US' AND X2 = '161_5706' AND X3 = '3100' AND X4 =0)
      OR (X1 = 'de_DE' AND X2 = '145_73' AND X3 = '3000' AND X4 =0)
      OR (X1 = 'en_US' AND X2 = '32_None' AND X3 = '107' AND X4 =0)
      OR (X1 = 'de_AT' AND X2 = '158_None' AND X3 = 'None' AND X4 =0)
      OR (X1 = 'de_DE' AND X2= '145_61' AND X3='3000' AND X4 = 0)
      OR (X1 = 'ru_RU' AND X2 = '210_73' AND X3 = '3000' AND X4 = 0)
    )
      THEN SET aP = '.001';

    ELSEIF dm = '1'
      THEN SET
      betaZero = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'Intercept'), 0),
      beta1 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'locale' AND  c.Variable = X1), 0),
      beta2 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'sc_code' AND c.Variable = X2), 0),
      beta3 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'm_code' AND  c.Variable = X3), 0),
      beta4 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'wasSharedToPriorToTrial'), 0),
      beta5 = COALESCE((SELECT Coefficient FROM leadflow.rpt_fitScoreModelV2 c WHERE c.Category = 'insertedByUser'), 0),
      P=EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))/(EXP(betaZero+beta1+beta2+beta3+(beta4*X4)+(beta5*X5))+1);

        SET aP = (CASE WHEN P > .1 THEN .1
                  WHEN P <.001 THEN .001
                  WHEN P IS NULL THEN .015
                  ELSE P
                  END);
    END IF;
    SET fP = ROUND(aP*1000);
    RETURN fP;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_ACCOUNT_ROLE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_ACCOUNT_ROLE`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE accountRole VARCHAR(50);
    SET accountRole =
    CASE
    WHEN  parentPaymentProfileID IS NULL THEN "Individual"
    WHEN orgMainContactUserID = userID THEN "Owner"
    ELSE "Member"
    END;
    RETURN accountRole;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_BILLING_ADDRESS` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_BILLING_ADDRESS`(address1 VARCHAR(50), address2 VARCHAR(50)) RETURNS varchar(101) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE billingAddress VARCHAR(101);
    SET billingAddress = TRIM(CONCAT(COALESCE(address1,"") ," ", COALESCE(address2,"")));
    RETURN billingAddress;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_CLEAN_IPADDRESS` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_CLEAN_IPADDRESS`(ipAddress VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE cleanIpAddress VARCHAR(50);
    SET cleanIpAddress =
    CASE WHEN INSTR (ipAddress, "," ) > 0
      THEN SUBSTRING_INDEX(ipAddress, ",", 1)
    ELSE ipAddress
    END;
    RETURN cleanIpAddress;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_EXTRACT_DOMAIN` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_EXTRACT_DOMAIN`(emailAddress VARCHAR(100)) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE domain VARCHAR(100);
    SET domain = SUBSTR(emailAddress, INSTR(emailAddress,'@') + 1);
    RETURN domain;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_LAST_NAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LAST_NAME`(lastName VARCHAR(50)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE processedLastName VARCHAR(50);
    SET processedLastName =
    CASE WHEN lastName IS NULL 	THEN NULL
    WHEN lastName = "" 		THEN NULL
    WHEN lastName = " " 	THEN NULL
    ELSE lastName
    END;
    RETURN processedLastName;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_LICENSE_TAG` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LICENSE_TAG`(assignedLicenseCount INT, pendingLicenseCount INT, paidLicenseLimit INT, previousPaidLicenseLimit INT, licenseUserCount INT) RETURNS varchar(256) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE licenseTags VARCHAR(256);
    SET licenseTags =
    CONCAT_WS(
        ';',
        CASE WHEN assignedLicenseCount + pendingLicenseCount >= paidLicenseLimit THEN 'assigned100Percent' END,
        CASE WHEN licenseUserCount >= 3 THEN 'assigned3OrMoreLast7Days' END,
        CASE WHEN paidLicenseLimit - previousPaidLicenseLimit < 0 THEN 'licenseLimitTrendingDown' END
    )
    ;
    RETURN CASE WHEN licenseTags = '' THEN NULL ELSE licenseTags END;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_LICENSE_TAG_TEST` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_LICENSE_TAG_TEST`(assignedLicenseCount int, pendingLicenseCount int, paidLicenseLimit int, previousPaidLicenseLimit int, licenseUserCount int) RETURNS varchar(256) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE licenseTags VARCHAR(256);
    SET licenseTags =
    CONCAT_WS(
        ';',
        CASE WHEN assignedLicenseCount + pendingLicenseCount >= paidLicenseLimit THEN 'assigned100Percent' END,
        CASE WHEN licenseUserCount >= 3 THEN 'assigned3OrMoreLast7Days' END,
        case when paidLicenseLimit - previousPaidLicenseLimit < 0 then 'licenseLimitTrendingDown' end
    )
    ;
    RETURN case when licenseTags = '' then null else licenseTags end;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_RECURRING_BILLING_CANCELLED` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_RECURRING_BILLING_CANCELLED`(parentPaymentProfileID BIGINT, orgMainContactUserID BIGINT, userID BIGINT, usersPaymentFlags tinyint, parentPaymentFlags tinyint) RETURNS tinyint(1)
DETERMINISTIC
  BEGIN
    DECLARE isBillingCancelled TINYINT(1);
    DECLARE paymentFlags TINYINT(1);
    SET paymentFlags =
    CASE
    WHEN  parentPaymentProfileID IS NULL THEN usersPaymentFlags
    WHEN orgMainContactUserID = userID THEN parentPaymentFlags
    ELSE usersPaymentFlags
    END;

    set isBillingCancelled =
    case
    when paymentFlags & 16 = 16 then 1
    else 0
    end;

    RETURN isBillingCancelled;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_SHARE_PERMISSION` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_SHARE_PERMISSION`(sharePermission INT) RETURNS varchar(25) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE sharePermissionName VARCHAR(25);
    SET sharePermissionName =
    CASE sharePermission
    when null then "None"
    WHEN 0 THEN "None"
    WHEN 10 THEN "View"
    WHEN 20 THEN "Editor"
    WHEN 30 THEN "EditorCanShare"
    WHEN 40 THEN "Admin"
    WHEN 50 THEN "Owner"
    ELSE CONCAT('Permission ', sharePermission)
    END;
    return sharePermissionName;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_UPGRADE_WIZARD_PROGRESS` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_UPGRADE_WIZARD_PROGRESS`(ViewedConfirmPage TINYINT, PayPalComplete TINYINT, PayPalStart TINYINT, ViewedStep3 TINYINT, ViewedStep2 TINYINT, ViewedStep1 TINYINT) RETURNS varchar(100) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE friendlyProgressValue VARCHAR(100);
    SET friendlyProgressValue =
    CASE
    WHEN ViewedConfirmPage > 0 THEN "Complete"
    WHEN PayPalComplete > 0 THEN "PayPalComplete"
    WHEN PayPalStart > 0 THEN "PayPalStart"
    WHEN ViewedStep3 > 0 THEN "Step3"
    WHEN ViewedStep2 > 0 THEN "Step2"
    WHEN ViewedStep1 > 0 THEN "Step1"
    ELSE ""
    END;
    RETURN friendlyProgressValue;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_USER_TAG` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_USER_TAG`(isInsertedByOrgDomain TINYINT, insertedEmailDomain VARCHAR(100),
                                                                    insertedByEmailDomain VARCHAR(100), signupContactMe VARCHAR(100)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE userTags VARCHAR(255);
    SET userTags =
    CONCAT_WS(
        ';',
        CASE
        WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain != insertedByEmailDomain
          THEN CONCAT('insertedByOutDomain', ':@', insertedByEmailDomain)
        WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain = insertedByEmailDomain
          THEN 'insertedByInDomain'
        WHEN isInsertedByOrgDomain = 0
          THEN 'insertedByISPDomain'
        WHEN isInsertedByOrgDomain = -1
          THEN 'insertedBySelf'
        END,
        CASE
        WHEN signupContactMe = 'true'
          THEN 'fullContactTrial:contactMe'
        END
    );
    RETURN CASE WHEN userTags = ''
      THEN NULL
           ELSE userTags END;
  END */$$
DELIMITER ;

/* Function  structure for function  `MARKETO_USER_TAG_TEST` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `MARKETO_USER_TAG_TEST`(isInsertedByOrgDomain TINYINT, insertedEmailDomain VARCHAR(100),
                                                                         insertedByEmailDomain VARCHAR(100), signupContactMe VARCHAR(100)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE userTags VARCHAR(255);
    SET userTags =
    CONCAT_WS(
        ';',
        CASE
        WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain != insertedByEmailDomain
          THEN CONCAT('insertedByOutDomain', ':@', insertedByEmailDomain)
        WHEN isInsertedByOrgDomain = 1 AND insertedEmailDomain = insertedByEmailDomain
          THEN 'insertedByInDomain'
        WHEN isInsertedByOrgDomain = 0
          THEN 'insertedByISPDomain'
        WHEN isInsertedByOrgDomain = -1
          THEN 'insertedBySelf'
        END,
        CASE
        WHEN signupContactMe = 'true'
          THEN 'fullContactTrial:contactMe'
        END
    );
    RETURN CASE WHEN userTags = ''
      THEN NULL
           ELSE userTags END;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_ACCOUNTTYPE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_ACCOUNTTYPE`(accountType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE accountTypeName VARCHAR(50);
    SET accountTypeName =
    CASE accountType
    WHEN 1 THEN "Standard"
    WHEN 2 THEN "Multi-user"
    WHEN 3 THEN "Organization"
    ELSE CONCAT('Account Type ', accountType)
    END;
    return accountTypeName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_AUTHRESULT` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_AUTHRESULT`(AuthType SMALLINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE AuthResultName VARCHAR(50);
    SET AuthResultName =
    CASE AuthType
    WHEN 1 THEN "SUCCESS"
    WHEN 0 THEN "No error"
    WHEN -1 THEN "INVALID_USER_OR_PASSWORD"
    WHEN -2 THEN "LOGIN_TICKET_DOES_NOT_EXIST"
    WHEN -3 THEN "DUPLICATE_LOGIN_TICKETS"
    WHEN -4 THEN "LOGIN_TICKET_CORRUPT"
    WHEN -5 THEN "LOGIN_TICKET_NOT_VALID"
    WHEN -6 THEN "ACCOUNT_LOCKEDOUT"
    WHEN -7 THEN "REUSED_REQUEST_DIGEST"
    WHEN -8 THEN "INVALID_REQUEST_DIGEST"
    WHEN -9 THEN "NO_MATCHING_USER"
    WHEN -10 THEN "INVALID_EMAIL_FORMAT"
    WHEN -11 THEN "USER_NOT_CONFIRMED"
    WHEN -12 THEN "ACCOUNT_BLOCKED"
    WHEN -13 THEN "INVALID_UPDATE_TICKET"
    WHEN -14 THEN "ACCOUNT_LOCKEDOUT_MAX"
    WHEN -15 THEN "BLOCKED_IP_ADDRESS"
    WHEN -16 THEN "SAML_REQUIRED_FOR_AUTH"
    WHEN -17 THEN "ACCESS_TOKEN_REQUIRED"
    WHEN -18 THEN "ACCESS_TOKEN_EXPIRED"
    WHEN -19 THEN "Rest User Credentials"
    WHEN -20 THEN "INVALID_ASSUME_USER"
    WHEN -21 THEN "ASSUME_USER_REQUIRED"
    WHEN -22 THEN "LEGACY_PASSWORD_FORMAT"
    ELSE CONCAT ('AuthResult ', AuthType)
    END;
    return AuthResultName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_BROWSERDEVICE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSERDEVICE`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE browserDevice VARCHAR(50);
    SET browserDevice =
    CASE
    WHEN INSTR(userAgent,'myTouch') 	THEN "myTouch"
    WHEN INSTR(userAgent,'Nexus') 		THEN "Nexus"
    WHEN INSTR(userAgent,'LG') 			THEN "LG"
    WHEN INSTR(userAgent,'SGH') 		THEN "SAMSUNG-SGH"
    WHEN INSTR(userAgent,'APA9292KT') 	THEN "HTC-EVO (APA9292KT)"
    WHEN INSTR(userAgent,'ADR6300') 	THEN "HTC-Incredible (ADR6300)"
    WHEN INSTR(userAgent,'HTC') 		THEN "HTC"
    WHEN INSTR(userAgent,'Treo') 		THEN "Treo"
    WHEN INSTR(userAgent,'Droid2') 		THEN "Droid2"
    WHEN INSTR(userAgent,'DroidX') 		THEN "DroidX"
    WHEN INSTR(userAgent,' Droid') 		THEN "Droid"
    WHEN INSTR(userAgent,'Xoom') 		THEN "Xoom"
    WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
    WHEN INSTR(userAgent,'Nokia') 		THEN "Nokia"
    WHEN INSTR(userAgent,'PlayBook') 	THEN "Playbook"
    WHEN INSTR(userAgent,'iPod') 		THEN "iPod"
    WHEN INSTR(userAgent,'iPhone') 		THEN "iPhone"
    WHEN INSTR(userAgent,'iPad') 		THEN "iPad"
    WHEN INSTR(userAgent,'Mobile') 		THEN "Mobile Device"
    WHEN INSTR(userAgent,'Mini') 		THEN "Mobile Device"
    WHEN INSTR(userAgent,'Fennec') 		THEN "Mobile Device"
    WHEN INSTR(userAgent,'Android') 	THEN "Mobile Device"
    WHEN INSTR(userAgent,'pixi') 		THEN "pixi"
    ELSE "Computer"
    END;
    return browserDevice;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_BROWSERNAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSERNAME`(userAgent NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE browserName VARCHAR(50);
    SET browserName =
    CASE
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0.1%') THEN "iOS App 1.0.1"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0%') THEN "iOS App 1.0"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.1%') THEN "iOS App 1.1"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.2%') THEN "iOS App 1.2"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.3%') THEN "iOS App 1.3"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.4%') THEN "iOS App 1.4"
    WHEN userAgent LIKE ('%Mac OS X%Smartsheet%') THEN "iOS App v?"
    WHEN userAgent LIKE ('%Android%Smartsheet 1.0%') THEN "Android App 1.0"
    WHEN userAgent LIKE ('%Android%Smartsheet 1.1%') THEN "Android App 1.1"
    WHEN userAgent LIKE ('%Android%Smartsheet 1.2%') THEN "Android App 1.2"
    WHEN userAgent LIKE ('%Android%Smartsheet%') THEN "Android App v?"
    WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
    WHEN INSTR(userAgent,'Firefox/10') 	THEN "Firefox 10"
    WHEN INSTR(userAgent,'Firefox/11') 	THEN "Firefox 11"
    WHEN INSTR(userAgent,'Firefox/12') 	THEN "Firefox 12"
    WHEN INSTR(userAgent,'Firefox/13') 	THEN "Firefox 13"
    WHEN INSTR(userAgent,'Firefox/14') 	THEN "Firefox 14"
    WHEN INSTR(userAgent,'Firefox/15') 	THEN "Firefox 15"
    WHEN INSTR(userAgent,'Firefox/16') 	THEN "Firefox 16"
    WHEN INSTR(userAgent,'Firefox/17') 	THEN "Firefox 17"
    WHEN INSTR(userAgent,'Firefox/18') 	THEN "Firefox 18"
    WHEN INSTR(userAgent,'Firefox/19') 	THEN "Firefox 19"
    WHEN INSTR(userAgent,'Firefox/20') 	THEN "Firefox 20"
    WHEN INSTR(userAgent,'Firefox/21') 	THEN "Firefox 21"
    WHEN INSTR(userAgent,'Firefox/22') 	THEN "Firefox 22"
    WHEN INSTR(userAgent,'Firefox/23') 	THEN "Firefox 23"
    WHEN INSTR(userAgent,'Firefox/24') 	THEN "Firefox 24"
    WHEN INSTR(userAgent,'Firefox/25') 	THEN "Firefox 25"
    WHEN INSTR(userAgent,'Firefox/26') 	THEN "Firefox 26"
    WHEN INSTR(userAgent,'Firefox/27') 	THEN "Firefox 27"
    WHEN INSTR(userAgent,'Firefox/28') 	THEN "Firefox 28"
    WHEN INSTR(userAgent,'Firefox/29') 	THEN "Firefox 29"
    WHEN INSTR(userAgent,'Firefox/30') 	THEN "Firefox 30"
    WHEN INSTR(userAgent,'Firefox/31') 	THEN "Firefox 31"
    WHEN INSTR(userAgent,'Firefox/32') 	THEN "Firefox 32"
    WHEN INSTR(userAgent,'Firefox/1') 	THEN "Firefox 1"
    WHEN INSTR(userAgent,'Firefox/2') 	THEN "Firefox 2"
    WHEN INSTR(userAgent,'Firefox/3') 	THEN "Firefox 3"
    WHEN INSTR(userAgent,'Firefox/4') 	THEN "Firefox 4"
    WHEN INSTR(userAgent,'Firefox/5') 	THEN "Firefox 5"
    WHEN INSTR(userAgent,'Firefox/6') 	THEN "Firefox 6"
    WHEN INSTR(userAgent,'Firefox/7') 	THEN "Firefox 7"
    WHEN INSTR(userAgent,'Firefox/8') 	THEN "Firefox 8"
    WHEN INSTR(userAgent,'Firefox/9') 	THEN "Firefox 9"
    WHEN INSTR(userAgent,'Firefox') 	THEN "Firefox v?"
    WHEN INSTR(userAgent,'MSIE 4.') 	THEN "IE 4"
    WHEN INSTR(userAgent,'MSIE 5.') 	THEN "IE 5"
    WHEN INSTR(userAgent,'MSIE 6.') 	THEN "IE 6"
    WHEN INSTR(userAgent,'MSIE 7.') 	THEN "IE 7"
    WHEN INSTR(userAgent,'MSIE 8.') 	THEN "IE 8"
    WHEN INSTR(userAgent,'MSIE 9.') 	THEN "IE 9"
    WHEN INSTR(userAgent,'MSIE 10.')  THEN "IE 10"
    WHEN userAgent LIKE '%Trident%rv:11%' THEN "IE 11"
    WHEN userAgent LIKE '%Trident%rv:12%' THEN "IE 12"
    WHEN userAgent LIKE '%Trident%rv:13%' THEN "IE 13"
    WHEN userAgent LIKE '%Trident%rv:14%' THEN "IE 14"
    WHEN userAgent LIKE '%Trident%rv:15%' THEN "IE 15"
    WHEN INSTR(userAgent,'Chrome/10') 	THEN "Chrome 10"
    WHEN INSTR(userAgent,'Chrome/11') 	THEN "Chrome 11"
    WHEN INSTR(userAgent,'Chrome/12') 	THEN "Chrome 12"
    WHEN INSTR(userAgent,'Chrome/13') 	THEN "Chrome 13"
    WHEN INSTR(userAgent,'Chrome/14') 	THEN "Chrome 14"
    WHEN INSTR(userAgent,'Chrome/15') 	THEN "Chrome 15"
    WHEN INSTR(userAgent,'Chrome/16') 	THEN "Chrome 16"
    WHEN INSTR(userAgent,'Chrome/17') 	THEN "Chrome 17"
    WHEN INSTR(userAgent,'Chrome/18') 	THEN "Chrome 18"
    WHEN INSTR(userAgent,'Chrome/19') 	THEN "Chrome 19"
    WHEN INSTR(userAgent,'Chrome/20') 	THEN "Chrome 20"
    WHEN INSTR(userAgent,'Chrome/21') 	THEN "Chrome 21"
    WHEN INSTR(userAgent,'Chrome/22') 	THEN "Chrome 22"
    WHEN INSTR(userAgent,'Chrome/23') 	THEN "Chrome 23"
    WHEN INSTR(userAgent,'Chrome/24') 	THEN "Chrome 24"
    WHEN INSTR(userAgent,'Chrome/25') 	THEN "Chrome 25"
    WHEN INSTR(userAgent,'Chrome/26') 	THEN "Chrome 26"
    WHEN INSTR(userAgent,'Chrome/27') 	THEN "Chrome 27"
    WHEN INSTR(userAgent,'Chrome/28') 	THEN "Chrome 28"
    WHEN INSTR(userAgent,'Chrome/29') 	THEN "Chrome 29"
    WHEN INSTR(userAgent,'Chrome/30') 	THEN "Chrome 30"
    WHEN INSTR(userAgent,'Chrome/31') 	THEN "Chrome 31"
    WHEN INSTR(userAgent,'Chrome/32') 	THEN "Chrome 32"
    WHEN INSTR(userAgent,'Chrome/33') 	THEN "Chrome 33"
    WHEN INSTR(userAgent,'Chrome/34') 	THEN "Chrome 34"
    WHEN INSTR(userAgent,'Chrome/35') 	THEN "Chrome 35"
    WHEN INSTR(userAgent,'Chrome/36') 	THEN "Chrome 36"
    WHEN INSTR(userAgent,'Chrome/37') 	THEN "Chrome 37"
    WHEN INSTR(userAgent,'Chrome/38') 	THEN "Chrome 38"
    WHEN INSTR(userAgent,'Chrome/39') 	THEN "Chrome 39"
    WHEN INSTR(userAgent,'Chrome/1') 	THEN "Chrome 1"
    WHEN INSTR(userAgent,'Chrome/2') 	THEN "Chrome 2"
    WHEN INSTR(userAgent,'Chrome/3') 	THEN "Chrome 3"
    WHEN INSTR(userAgent,'Chrome/4') 	THEN "Chrome 4"
    WHEN INSTR(userAgent,'Chrome/5') 	THEN "Chrome 5"
    WHEN INSTR(userAgent,'Chrome/6') 	THEN "Chrome 6"
    WHEN INSTR(userAgent,'Chrome/7') 	THEN "Chrome 7"
    WHEN INSTR(userAgent,'Chrome/8') 	THEN "Chrome 8"
    WHEN INSTR(userAgent,'Chrome/9') 	THEN "Chrome 9"
    WHEN INSTR(userAgent,'Chrome') 	THEN "Chrome v?"
    WHEN userAgent LIKE ('%3._ Mobile%Safari%') THEN "Mobile Safari 3"
    WHEN userAgent LIKE ('%3._._ Mobile%Safari%') THEN "Mobile Safari 3"
    WHEN userAgent LIKE ('%4._ Mobile%Safari%')  THEN "Mobile Safari 4"
    WHEN userAgent LIKE ('%4._._ Mobile%Safari%') THEN "Mobile Safari 4"
    WHEN userAgent LIKE ('%5._ Mobile%Safari%') THEN "Mobile Safari 5"
    WHEN userAgent LIKE ('%5._._ Mobile%Safari%') THEN "Mobile Safari 5"
    WHEN userAgent LIKE ('%6._ Mobile%Safari%') THEN "Mobile Safari 6"
    WHEN userAgent LIKE ('%6.___ Mobile%Safari%') THEN "Mobile Safari 6"
    WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 7"
    WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 7"
    WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 8"
    WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 8"
    WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 9"
    WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 9"
    WHEN userAgent LIKE ('%Mobile%Safari%') THEN "Mobile Safari v?"
    WHEN userAgent LIKE ('%3._ Safari%') 	THEN "Safari 3"
    WHEN userAgent LIKE ('%3._._ Safari%') 	THEN "Safari 3"
    WHEN userAgent LIKE ('%4._ Safari%') 	THEN "Safari 4"
    WHEN userAgent LIKE ('%4._._ Safari%') 	THEN "Safari 4"
    WHEN userAgent LIKE ('%5._ Safari%') 	THEN "Safari 5"
    WHEN userAgent LIKE ('%5._._ Safari%') 	THEN "Safari 5"
    WHEN userAgent LIKE ('%6._ Safari%') 	THEN "Safari 6"
    WHEN userAgent LIKE ('%6._._ Safari%') 	THEN "Safari 6"
    WHEN userAgent LIKE ('%6._._.____ Safari%') 	THEN "Safari 6"
    WHEN userAgent LIKE ('%7._ Safari%') 	THEN "Safari 7"
    WHEN userAgent LIKE ('%7._._ Safari%') 	THEN "Safari 7"
    WHEN userAgent LIKE ('%7._._._ Safari%') 	THEN "Safari 7"
    WHEN userAgent LIKE ('%8._ Safari%') 	THEN "Safari 8"
    WHEN userAgent LIKE ('%8._._ Safari%') 	THEN "Safari 8"
    WHEN userAgent LIKE ('%8._._._ Safari%') 	THEN "Safari 8"
    WHEN userAgent LIKE ('%9._ Safari%') 	THEN "Safari 9"
    WHEN userAgent LIKE ('%9._._ Safari%') 	THEN "Safari 9"
    WHEN userAgent LIKE ('%9._._._ Safari%') 	THEN "Safari 9"
    WHEN INSTR(userAgent,'Safari/7534.48.3') 	THEN "Safari 5"
    WHEN INSTR(userAgent,'Safari/8536.25') 	THEN "Safari 6"
    WHEN userAgent LIKE ('%Safari%') 	THEN "Safari v?"
    WHEN INSTR(userAgent,'Opera/8') 	THEN "Opera 8"
    WHEN INSTR(userAgent,'Opera 8') 	THEN "Opera 8"
    WHEN INSTR(userAgent,'Opera/9') 	THEN "Opera 9"
    WHEN INSTR(userAgent,'Opera 9') 	THEN "Opera 9"
    WHEN INSTR(userAgent,'Opera/10') 	THEN "Opera 10"
    WHEN INSTR(userAgent,'Opera 10') 	THEN "Opera 10"
    WHEN INSTR(userAgent,'Opera/11') 	THEN "Opera 11"
    WHEN INSTR(userAgent,'Opera 11') 	THEN "Opera 11"
    WHEN INSTR(userAgent,'Opera/12') 	THEN "Opera 12"
    WHEN INSTR(userAgent,'Opera 12') 	THEN "Opera 12"
    WHEN INSTR(userAgent,'Opera') 	THEN "Opera v?"
    WHEN INSTR(userAgent,'Camino') 	THEN "Camino"
    WHEN INSTR(userAgent,'Mobile') THEN "Other Mobile Browser"
    ELSE "Other Browser"
    END;
    RETURN browserName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_BROWSEROS` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_BROWSEROS`(userAgent NVARCHAR(255)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE browserOS VARCHAR(20);
    SET browserOS =
    CASE
    WHEN INSTR(userAgent,'sunOS') 		THEN "sunOS"
    WHEN INSTR(userAgent,'FreeBSD') 	THEN "FreeBSD"
    WHEN INSTR(userAgent,'openBSD') 	THEN "openBSD"
    WHEN INSTR(userAgent,'SymbianOS') 	THEN "SymbianOS"
    WHEN INSTR(userAgent,'Symbian') 	THEN "SymbianOS"
    WHEN INSTR(userAgent,'webOS') 		THEN "webOS"
    WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
    WHEN INSTR(userAgent,'Android') 	THEN "Android"
    WHEN INSTR(userAgent,'Linux') 		THEN "Linux"
    WHEN INSTR(userAgent,'Windows CE') 	THEN "Windows CE"
    WHEN INSTR(userAgent,'Windows Phone OS') 	THEN "Windows Phone OS"
    WHEN INSTR(userAgent,'Windows') 	THEN "Windows"
    WHEN INSTR(userAgent,'OS 3') 		THEN "iOS"
    WHEN INSTR(userAgent,'OS 4') 		THEN "iOS"
    WHEN INSTR(userAgent,'OS 5') 		THEN "iOS"
    WHEN INSTR(userAgent,'OS 6') 		THEN "iOS"
    WHEN INSTR(userAgent,'OS 7') 		THEN "iOS"
    WHEN INSTR(userAgent,'OS 8') 		THEN "iOS"
    WHEN INSTR(userAgent,'iPhone OS') 	THEN "iOS"
    WHEN INSTR(userAgent,'iPad') 	THEN "iOS"
    WHEN INSTR(userAgent,'iPhone') 	THEN "iOS"
    WHEN INSTR(userAgent,'iOS') 	THEN "iOS"
    WHEN INSTR(userAgent,'Mac') 		THEN "Mac"
    WHEN INSTR(userAgent,'crOS ') 		THEN "Chrome OS"
    ELSE "Other OS"
    END;
    RETURN browserOS;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_COUNTRYNAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_COUNTRYNAME`(countryCode VARCHAR(25)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE countryName VARCHAR(50);
    SET countryName =
    CASE countryCode
    WHEN 'AF' THEN 'Afghanistan'
    WHEN 'Afghanistan' THEN 'Afghanistan'
    WHEN 'AX' THEN 'Aland Islands'
    WHEN 'AL' THEN 'Albania'
    WHEN 'DZ' THEN 'Algeria'
    WHEN 'AS' THEN 'American Samoa'
    WHEN 'AD' THEN 'Andorra'
    WHEN 'AO' THEN 'Angola'
    WHEN 'AI' THEN 'Anguilla'
    WHEN 'AQ' THEN 'Antarctica'
    WHEN 'AG' THEN 'Antigua and Barbuda'
    WHEN 'AR' THEN 'Argentina'
    WHEN 'AM' THEN 'Armenia'
    WHEN 'AW' THEN 'Aruba'
    WHEN 'AU' THEN 'Australia'
    WHEN 'AUST' THEN 'Australia'
    WHEN 'AUSTRALIA' THEN 'Australia'
    WHEN 'AT' THEN 'Austria'
    WHEN 'Osterreich' THEN 'Austria'
    WHEN 'AZ' THEN 'Azerbaidjan'
    WHEN 'BS' THEN 'Bahamas'
    WHEN 'BH' THEN 'Bahrain'
    WHEN 'BD' THEN 'Bangladesh'
    WHEN 'BB' THEN 'Barbados'
    WHEN 'BY' THEN 'Belarus'
    WHEN 'BE' THEN 'Belgium'
    WHEN 'Belgium' THEN 'Belgium'
    WHEN 'BZ' THEN 'Belize'
    WHEN 'BJ' THEN 'Benin'
    WHEN 'BM' THEN 'Bermuda'
    WHEN 'BT' THEN 'Bhutan'
    WHEN 'BO' THEN 'Bolivia'
    WHEN 'BQ' THEN 'Bonaire'
    WHEN 'BA' THEN 'Bosnia-Herzegovina'
    WHEN 'BW' THEN 'Botswana'
    WHEN 'Botswana' THEN 'Botswana'
    WHEN 'BV' THEN 'Bouvet Island'
    WHEN 'BR' THEN 'Brazil'
    WHEN 'Brasil' THEN 'Brazil'
    WHEN 'Brazil' THEN 'Brazil'
    WHEN 'IO' THEN 'British Indian Ocean Territory'
    WHEN 'BN' THEN 'Brunei Darussalam'
    WHEN 'BG' THEN 'Bulgaria'
    WHEN 'Bulgaria' THEN 'Bulgaria'
    WHEN 'BF' THEN 'Burkina Faso'
    WHEN 'BI' THEN 'Burundi'
    WHEN 'KH' THEN 'Cambodia'
    WHEN 'CM' THEN 'Cameroon'
    WHEN 'CA' THEN 'Canada'
    WHEN 'Canada' THEN 'Canada'
    WHEN 'Newfoundland' THEN 'Canada'
    WHEN 'CV' THEN 'Cape Verde'
    WHEN 'KY' THEN 'Cayman Islands'
    WHEN 'Cayman Islands' THEN 'Cayman Islands'
    WHEN 'CF' THEN 'Central African Republic'
    WHEN 'TD' THEN 'Chad'
    WHEN 'CL' THEN 'Chile'
    WHEN 'Chile' THEN 'Chile'
    WHEN 'CN' THEN 'China'
    WHEN 'China' THEN 'China'
    WHEN 'CX' THEN 'Christmas Island'
    WHEN 'CC' THEN 'Cocos Islands'
    WHEN 'CO' THEN 'Colombia'
    WHEN 'Colombia' THEN 'Colombia'
    WHEN 'KM' THEN 'Comoros'
    WHEN 'CD' THEN 'Congo'
    WHEN 'CG' THEN 'Congo'
    WHEN 'CK' THEN 'Cook Islands'
    WHEN 'CR' THEN 'Costa Rica'
    WHEN 'Costa Rica' THEN 'Costa Rica'
    WHEN 'CI' THEN "Cote D'Ivoire"
    WHEN 'HR' THEN 'Croatia'
    WHEN 'CU' THEN 'Cuba'
    WHEN 'CW' THEN 'Curacao'
    WHEN 'CY' THEN 'Cyprus'
    WHEN 'CZ' THEN 'Czech Republic'
    WHEN 'Czech Republic' THEN 'Czech Republic'
    WHEN 'DK' THEN 'Denmark'
    WHEN 'Denmark' THEN 'Denmark'
    WHEN 'DJ' THEN 'Djibouti'
    WHEN 'DM' THEN 'Dominica'
    WHEN 'DO' THEN 'Dominican Republic'
    WHEN 'Republica Dominicana' THEN 'Dominican Republic'
    WHEN 'EC' THEN 'Ecuador'
    WHEN 'Ecuador' THEN 'Ecuador'
    WHEN 'EG' THEN 'Egypt'
    WHEN 'SV' THEN 'El Salvador'
    WHEN 'GQ' THEN 'Equatorial Guinea'
    WHEN 'ER' THEN 'Eritrea'
    WHEN 'EE' THEN 'Estonia'
    WHEN 'Estonia' THEN 'Estonia'
    WHEN 'ET' THEN 'Ethiopia'
    WHEN 'FK' THEN 'Falkland Islands'
    WHEN 'FO' THEN 'Faroe Islands'
    WHEN 'FJ' THEN 'Fiji'
    WHEN 'Fiji' THEN 'Fiji'
    WHEN 'FI' THEN 'Finland'
    WHEN 'FR' THEN 'France'
    WHEN 'FRANCE' THEN 'France'
    WHEN 'GF' THEN 'French Guyana'
    WHEN 'PF' THEN 'French Polynesia'
    WHEN 'TF' THEN 'French Southern Territories'
    WHEN 'GA' THEN 'Gabon'
    WHEN 'GM' THEN 'Gambia'
    WHEN 'GE' THEN 'Georgia'
    WHEN 'DE' THEN 'Germany'
    WHEN 'Deutschland' THEN 'Germany'
    WHEN 'Germany' THEN 'Germany'
    WHEN 'GH' THEN 'Ghana'
    WHEN 'GI' THEN 'Gibraltar'
    WHEN 'GR' THEN 'Greece'
    WHEN 'GREECE' THEN 'Greece'
    WHEN 'GL' THEN 'Greenland'
    WHEN 'GD' THEN 'Grenada'
    WHEN 'GP' THEN 'Guadeloupe'
    WHEN 'GU' THEN 'Guam'
    WHEN 'GT' THEN 'Guatemala'
    WHEN 'GUATEMALA' THEN 'Guatemala'
    WHEN 'GG' THEN 'Guernsey'
    WHEN 'GN' THEN 'Guinea'
    WHEN 'GW' THEN 'Guinea-Bissau'
    WHEN 'GY' THEN 'Guyana'
    WHEN 'HT' THEN 'Haiti'
    WHEN 'HM' THEN 'Heard and McDonald Islands'
    WHEN 'HN' THEN 'Honduras'
    WHEN 'HK' THEN 'Hong Kong'
    WHEN 'HU' THEN 'Hungary'
    WHEN 'Hungary' THEN 'Hungary'
    WHEN 'IS' THEN 'Iceland'
    WHEN 'IN' THEN 'India'
    WHEN 'India' THEN 'India'
    WHEN 'ID' THEN 'Indonesia'
    WHEN 'INDONESIA' THEN 'Indonesia'
    WHEN 'IR' THEN 'Iran'
    WHEN 'IQ' THEN 'Iraq'
    WHEN 'IE' THEN 'Ireland'
    WHEN 'Ireland' THEN 'Ireland'
    WHEN 'IM' THEN 'Isle of Man'
    WHEN 'IL' THEN 'Israel'
    WHEN 'Israel' THEN 'Israel'
    WHEN 'IT' THEN 'Italy'
    WHEN 'Italia' THEN 'Italy'
    WHEN 'ITALY' THEN 'Italy'
    WHEN 'JM' THEN 'Jamaica'
    WHEN 'JP' THEN 'Japan'
    WHEN 'Japan' THEN 'Japan'
    WHEN 'JE' THEN 'Jersey'
    WHEN 'JO' THEN 'Jordan'
    WHEN 'KZ' THEN 'Kazakhstan'
    WHEN 'KE' THEN 'Kenya'
    WHEN 'KI' THEN 'Kiribati'
    WHEN 'KP' THEN 'Korea'
    WHEN 'KW' THEN 'Kuwait'
    WHEN 'KG' THEN 'Kyrgyzstan'
    WHEN 'LA' THEN 'Laos'
    WHEN 'LV' THEN 'Latvia'
    WHEN 'Latvia' THEN 'Latvia'
    WHEN 'LB' THEN 'Lebanon'
    WHEN 'Lebanon' THEN 'Lebanon'
    WHEN 'LS' THEN 'Lesotho'
    WHEN 'LR' THEN 'Liberia'
    WHEN 'LY' THEN 'Libya'
    WHEN 'Libya' THEN 'Libyan Arab Jamahiriya'
    WHEN 'LI' THEN 'Liechtenstein'
    WHEN 'LT' THEN 'Lithuania'
    WHEN 'Lithuania' THEN 'Lithuania'
    WHEN 'LU' THEN 'Luxembourg'
    WHEN 'MO' THEN 'Macau'
    WHEN 'MK' THEN 'Macedonia'
    WHEN 'MG' THEN 'Madagascar'
    WHEN 'MW' THEN 'Malawi'
    WHEN 'MY' THEN 'Malaysia'
    WHEN 'Malaysia' THEN 'Malaysia'
    WHEN 'MV' THEN 'Maldives'
    WHEN 'ML' THEN 'Mali'
    WHEN 'MT' THEN 'Malta'
    WHEN 'MH' THEN 'Marshall Islands'
    WHEN 'MQ' THEN 'Martinique'
    WHEN 'MR' THEN 'Mauritania'
    WHEN 'MU' THEN 'Mauritius'
    WHEN 'YT' THEN 'Mayotte'
    WHEN 'MX' THEN 'Mexico'
    WHEN '77710' THEN 'Mexico'
    WHEN 'Mexico' THEN 'Mexico'
    WHEN 'Mexico D.F (Mexico)' THEN 'Mexico'
    WHEN 'FM' THEN 'Micronesia'
    WHEN 'MD' THEN 'Moldavia'
    WHEN 'MC' THEN 'Monaco'
    WHEN 'MN' THEN 'Mongolia'
    WHEN 'ME' THEN 'Montenegro'
    WHEN 'MS' THEN 'Montserrat'
    WHEN 'MA' THEN 'Morocco'
    WHEN 'Morocco' THEN 'Morocco'
    WHEN 'MZ' THEN 'Mozambique'
    WHEN 'MM' THEN 'Myanmar'
    WHEN 'NA' THEN 'Namibia'
    WHEN 'NR' THEN 'Nauru'
    WHEN 'NP' THEN 'Nepal'
    WHEN 'NL' THEN 'Netherlands'
    WHEN 'Netherlands' THEN 'Netherlands'
    WHEN 'The Netherlands' THEN 'Netherlands'
    WHEN 'NC' THEN 'New Caledonia'
    WHEN 'NZ' THEN 'New Zealand'
    WHEN 'New Zealand' THEN 'New Zealand'
    WHEN 'NI' THEN 'Nicaragua'
    WHEN 'NE' THEN 'Niger'
    WHEN 'NG' THEN 'Nigeria'
    WHEN 'NU' THEN 'Niue'
    WHEN 'NF' THEN 'Norfolk Island'
    WHEN 'MP' THEN 'Northern Mariana Islands'
    WHEN 'NO' THEN 'Norway'
    WHEN 'Norway' THEN 'Norway'
    WHEN 'OM' THEN 'Oman'
    WHEN 'ZZ' THEN 'Other'
    WHEN 'PK' THEN 'Pakistan'
    WHEN 'PW' THEN 'Palau'
    WHEN 'PS' THEN 'Palestine'
    WHEN 'PA' THEN 'Panama'
    WHEN 'Panama' THEN 'Panama'
    WHEN 'PG' THEN 'Papua New Guinea'
    WHEN 'PY' THEN 'Paraguay'
    WHEN 'Paraguay' THEN 'Paraguay'
    WHEN 'PE' THEN 'Peru'
    WHEN 'Peru' THEN 'Peru'
    WHEN 'PH' THEN 'Philippines'
    WHEN 'PN' THEN 'Pitcairn Islands'
    WHEN 'PL' THEN 'Poland'
    WHEN 'Capgemini' THEN 'Poland'
    WHEN 'Krakow' THEN 'Poland'
    WHEN 'Poland' THEN 'Poland'
    WHEN 'Polska' THEN 'Poland'
    WHEN 'PT' THEN 'Portugal'
    WHEN 'Portugal' THEN 'Portugal'
    WHEN 'PR' THEN 'Puerto Rico'
    WHEN 'QA' THEN 'Qatar'
    WHEN 'RE' THEN 'Reunion'
    WHEN 'RO' THEN 'Romania'
    WHEN 'Romania' THEN 'Romania'
    WHEN 'RU' THEN 'Russia'
    WHEN 'Russia' THEN 'Russia'
    WHEN 'Russian Federation' THEN 'Russia'
    WHEN 'RW' THEN 'Rwanda'
    WHEN 'BL' THEN 'Saint Barthelemy'
    WHEN 'SH' THEN 'Saint Helena'
    WHEN 'KN' THEN 'Saint Kitts and Nevis Anguilla'
    WHEN 'LC' THEN 'Saint Lucia'
    WHEN 'MF' THEN 'Saint Martin'
    WHEN 'SX' THEN 'Saint Martin'
    WHEN 'VC' THEN 'Saint Vincent and Grenadines'
    WHEN 'WS' THEN 'Samoa'
    WHEN 'SM' THEN 'San Marino'
    WHEN 'ST' THEN 'Sao Tome and Principe'
    WHEN 'SA' THEN 'Saudi Arabia'
    WHEN 'SN' THEN 'Senegal'
    WHEN 'RS' THEN 'Serbia'
    WHEN 'SC' THEN 'Seychelles'
    WHEN 'SL' THEN 'Sierra Leone'
    WHEN 'SG' THEN 'Singapore'
    WHEN 'SK' THEN 'Slovakia'
    WHEN 'Slovakia' THEN 'Slovakia'
    WHEN 'SI' THEN 'Slovenia'
    WHEN 'Slovenia' THEN 'Slovenia'
    WHEN 'SB' THEN 'Solomon Islands'
    WHEN 'SO' THEN 'Somalia'
    WHEN 'ZA' THEN 'South Africa'
    WHEN 'RSA' THEN 'South Africa'
    WHEN 'South Africa' THEN 'South Africa'
    WHEN 'GS' THEN 'South Georgia and the South Sandwich Islands'
    WHEN 'KR' THEN 'South Korea'
    WHEN 'SS' THEN 'South Sudan'
    WHEN 'ES' THEN 'Spain'
    WHEN 'Espana' THEN 'Spain'
    WHEN 'Spain' THEN 'Spain'
    WHEN 'LK' THEN 'Sri Lanka'
    WHEN 'PM' THEN 'St. Pierre and Miquelon'
    WHEN 'SD' THEN 'Sudan'
    WHEN 'SR' THEN 'Suriname'
    WHEN 'SJ' THEN 'Svalbard and Jan Mayen Islands'
    WHEN 'SZ' THEN 'Swaziland'
    WHEN 'SE' THEN 'Sweden'
    WHEN 'Sweden' THEN 'Sweden'
    WHEN 'CH' THEN 'Switzerland'
    WHEN 'Switzerland' THEN 'Switzerland'
    WHEN 'SY' THEN 'Syrian Arab Republic'
    WHEN 'TW' THEN 'Taiwan'
    WHEN 'Taiwan' THEN 'Taiwan'
    WHEN 'TJ' THEN 'Tajikistan'
    WHEN 'TZ' THEN 'Tanzania'
    WHEN 'Tanzania' THEN 'Tanzania'
    WHEN 'TH' THEN 'Thailand'
    WHEN 'Thailand' THEN 'Thailand'
    WHEN 'TL' THEN 'Timor-Leste'
    WHEN 'TG' THEN 'Togo'
    WHEN 'TK' THEN 'Tokelau'
    WHEN 'TO' THEN 'Tonga'
    WHEN 'TT' THEN 'Trinidad and Tobago'
    WHEN 'TN' THEN 'Tunisia'
    WHEN 'TR' THEN 'Turkey'
    WHEN 'Turkey' THEN 'Turkey'
    WHEN 'TM' THEN 'Turkmenistan'
    WHEN 'TC' THEN 'Turks and Caicos Islands'
    WHEN 'TV' THEN 'Tuvalu'
    WHEN 'UG' THEN 'Uganda'
    WHEN 'UA' THEN 'Ukraine'
    WHEN 'AE' THEN 'United Arab Emirates'
    WHEN 'UAE' THEN 'United Arab Emirates'
    WHEN 'GB' THEN 'United Kingdom'
    WHEN 'England' THEN 'United Kingdom'
    WHEN 'United Kingdom' THEN 'United Kingdom'
    WHEN 'UK' THEN 'United Kingdom'
    WHEN 'US' THEN 'United States'
    WHEN 'United States' THEN 'United States'
    WHEN 'United States of America' THEN 'United States'
    WHEN 'USA' THEN 'United States'
    WHEN 'UM' THEN 'United States Minor Outlying Islands'
    WHEN 'UY' THEN 'Uruguay'
    WHEN 'Uruguay' THEN 'Uruguay'
    WHEN 'UZ' THEN 'Uzbekistan'
    WHEN 'VU' THEN 'Vanuatu'
    WHEN 'VA' THEN 'Vatican City'
    WHEN 'VE' THEN 'Venezuela'
    WHEN 'VN' THEN 'Vietnam'
    WHEN 'VG' THEN 'Virgin Islands'
    WHEN 'VI' THEN 'Virgin Islands'
    WHEN 'WF' THEN 'Wallis and Futuna'
    WHEN 'EH' THEN 'Western Sahara'
    WHEN 'YE' THEN 'Yemen'
    WHEN 'ZM' THEN 'Zambia'
    WHEN 'ZW' THEN 'Zimbabwe'
    ELSE CONCAT('Country ', countryCode)
    END;
    RETURN countryName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_GET_BUCKET` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_BUCKET`(source NVARCHAR(255)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE GET_BUCKET VARCHAR(20);
    SET GET_BUCKET =
    CASE

    WHEN source IN ("Sharing", "Referrals", "Application")
      THEN "Viral"


    WHEN source IN ("Affiliate", "Campaign", "Email Campaigns", "General Awareness", "Free Directory", "SEO", "Social", "Website Links","Blog Posse")
      THEN "Other"


    WHEN source IN ("Partner", "App Store")
      THEN "Partner"


    WHEN source IN ("Paid Placement", "PPC - Foreign Language", "PPC - English - International", "PPC","Paid - Social","Paid - Email")
      THEN "Paid"
    ELSE "--unknown bucket--"
    END;
    RETURN GET_BUCKET;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_GET_QUERY_PARAMETER` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_QUERY_PARAMETER`(url NVARCHAR(500), parameterName NVARCHAR(50)) RETURNS varchar(500) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE parameterValue VARCHAR(500);
    DECLARE parameterNameLength BIGINT;
    DECLARE startPosition BIGINT;
    DECLARE endPosition BIGINT;
    SET parameterValue = NULL;


    SET startPosition = LOCATE(CONCAT("?", parameterName, "="), url);

    IF startPosition = 0 THEN
      SET startPosition = LOCATE(CONCAT("&", parameterName, "="), url);
    END IF;


    IF startPosition > 0 THEN

      SET parameterNameLength = LENGTH(parameterName) + 2;

      SET endPosition = LOCATE("&" , url, startPosition + 1);

      IF endPosition > 0 THEN
        SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength, endPosition - (startPosition + parameterNameLength));
      ELSE
        SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength);
      END IF;
    END IF;

    RETURN parameterValue;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_GET_SOURCE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_GET_SOURCE`(subSource NVARCHAR(255)) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE GET_SOURCE VARCHAR(50);
    SET GET_SOURCE =
    CASE

    WHEN subSource IN ("Signup with Sharing Tracking Codes", "Signup Inserted by Smartsheet User")
      THEN "Sharing"
    WHEN subSource IN ("Web Forms - Powered BY Smartsheet", "Published Sheet - Powered by Smartsheet")
      THEN "Application"
    WHEN subSource IN ("Mail Link", "My Smartsheet Referral", "Referral Rewards")
      THEN "Referrals"


    WHEN subSource IN ("Amazon Web Services", "AWS Marketplace", "Brad Egeland", "Crowdsourcing.org", "Sitepoint", "Sage Non-Profit", "Office Arrow", "VA Network", "Veronica Conway",
                                              "Jott", "Success Connections", "smallbiztrends.com", "A Clayton's Secretary", "Officebundle.com",
                                                                             "Caroline Melville Society of Virtual Assistants", "Caroline Melville Virtually Sorted",
                                                                             "Baird Consulting", "Biz Recipes", "OnlineBizU", "Assistant Match", "Ki-Work", "Tradeshow Coach", "Regina Minger","Kindle",
                       "Stack Overflow")
      THEN "Affiliate"
    WHEN subSource IN ("TJ McCue", "NAPS")
      THEN "Campaign"
    WHEN subSource IN ("Email")
      THEN "Email Campaigns"
    WHEN subSource IN ("Smartsheet Search", "Smartsheet Search (Not Provided)" ,
                       "Smartsheet Paid Google Search", "Smartsheet Paid Bing Search" ,
                       "Direct Navigation", "Distributed Container")
      THEN "General Awareness"
    WHEN subSource IN ("Google Templates", "thesmallbusinessweb.com")
      THEN "Free Directory"
    WHEN subSource IN ("SEO", "SEO (Not Provided)")
      THEN "SEO"
    WHEN subSource IN ("YouTube (unpaid)", "Twitter (unpaid)", "Social Media (generic)", "Facebook (unpaid)", "LinkedIn (unpaid)", "Google+ (unpaid)", "Social Media Coordinator - Keri",
                       "Slideshare.net")
      THEN "Social"
    WHEN subSource IN ("External Source Links")
      THEN "Website Links"

    WHEN subSource IN ("Apple App Store", "Android App Store", "Google Play Store")
      THEN "App Store"
    WHEN subSource IN ( "Elizabeth Harrin (blog posse)", "Robert Kelly (blog posse)", "Lindsay Scott (blog posse)")
      THEN "Blog Posse"

    WHEN subSource IN ("Google App. Marketplace", "Chrome Web Store", "Intuit", "Zimbra", "Salesforce.com", "Box", "Cloud Alliance for Google Apps",
                                                  "Centrify", "Google Drive - New File", "Google Drive - Import","Zapier","Dropbox","123 Contact Form","Marketo Launchpoint","Docusign",
                                                                                                                          "MailChimp","Harvest","Evernote","Amazon Mechanical Turk","AppGuru","Backupify","Bitium","Easy Insight",
                                                                                                                                                                                                          "OneLogin","PingOne","Klipfolio","Tools4ever","Okta","Third Party Authorization Flow","BetterCloud",
                                                                                                                                                                                                          "Smartsheet Merge (Google Docs Add-on)","Smartsheet Forms (Google Forms Add-on)","Microsoft","Wave")
      THEN "Partner"


    WHEN subSource IN ("Serchen", "The Deck", "PM Sherpa", "GetApp.com", "Geekwire", "USA Today", "Pac NW Soccer","Spiceworks")
      THEN "Paid Placement"

    WHEN subSource IN ( "Spanish - Google Search Test", "Spanish - Google Display Network Test",
                                                        "Spanish (US) - Google Display", "Spanish (US) - Google Search",
                                                        "Spanish (Mexico) - Google Display", "Spanish (Mexico) - Google Search",
                                                        "Spanish (Spain) - Google Display", "Spanish (Spain) - Google Search",
                                                        "Spanish (Other) - Google Display", "Spanish (Other) - Google Search",
                                                        "Spanish (Argentina)  Google Display", "Spanish (Argentina)  Google Search",
                                                                                               "Spanish (Peru)  Google Display", "Spanish (Peru)  Google Search",
                                                                                               "Spanish (Venezuela)  Google Display", "Spanish (Venezuela)  Google Search",
                                                                                               "Spanish (Chile)  Google Display", "Spanish (Chile)  Google Search",
                                                                                               "Spanish (Guatemala)  Google Display", "Spanish (Guatemala)  Google Search",
                                                                                               "Spanish (Ecuador)  Google Display", "Spanish (Ecuador)  Google Search",

                                                                                                                                    "French (Tier 1) - Google Display", "French (Tier 1) - Google Search",
                                                                                                                                    "French (Tier 2) - Google Display", "French (Tier 2) - Google Search",

                                                                                                                                    "Portuguese (Brazil) - Google Display", "Portuguese (Brazil) - Google Search",
                                                                                                                                    "Portuguese (Portugal) - Google Display", "Portuguese (Portugal) - Google Search",

                                                                                                                                    "German - Google Display", "German - Google Search",

                                                                                                                                                               "Italian - Google Display", "Italian - Google Search",
                                                                                                                                                               "Bing Search - French",
                                                                                                                                                               "Bing Search - German",
                                                                                                                                                               "Bing Search - Portuguese (Brazil)",
                                                                                                                                                               "Bing Search - Portuguese (Portugal)",
                                                                                                                                                               "Bing Search - Spanish",
                                                                                                                                                               "Bing Search - Italian",
                                                                                                                                                               "Google Search - Russian",
                        "Yandex (paid)",
                        "Google Search - Japanese",
                        "Yahoo Japan")
      THEN "PPC - Foreign Language"

    WHEN subSource IN ( "Bing Search (Canada)", "Bing Search (Singapore)", "Bing Search (UK)",

                                                "South Africa - Google Display", "South Africa - Google Search",
                                                "Israel - Google Display", "Israel - Google Search",
                                                "Saudi Arabia - Google Display", "Saudi Arabia - Google Search",

                                                "Belgium - Google Display", "Belgium - Google Search",
      "Finland - Google Display", "Finland - Google Search",
      "Denmark - Google Display", "Denmark - Google Search",
      "Netherlands - Google Display", "Netherlands - Google Search",
      "Norway - Google Display", "Norway - Google Search",
      "Sweden - Google Display", "Sweden - Google Search",
      "Germany - Google Display", "Germany - Google Search",
      "France - Google Display", "France - Google Search",
      "Spain - Google Display", "Spain - Google Search",
      "Italy - Google Display", "Italy - Google Search",

      "Turkey - Google Display", "Turkey - Google Search",
      "Russia - Google Display", "Russia - Google Search",

      "Hong Kong - Google Display", "Hong Kong - Google Search",
      "Singapore - Google Display", "Singapore - Google Search",
      "Japan - Google Display", "Japan - Google Search",
      "South Korea - Google Display", "South Korea - Google Search",
      "China - Google Display", "China - Google Search",

      "Mexico - Google Display", "Mexico - Google Search",

      "Brazil - Google Display", "Brazil - Google Search",
      "Columbia - Google Display", "Columbia - Google Search",
      "Argentina - Google Display", "Argentina - Google Search",

      "India - Google Display", "India - Google Search",
      "Indonesia - Google Display", "Indonesia - Google Search",
      "Malaysia - Google Display", "Malaysia - Google Search",
      "Philippines - Google Display", "Philippines - Google Search",

      "_Display - Managed Placements - Tier 1 International", "_Display - Managed Placements - Tier 2 International",
                        "_Google Search - International - Tier 1", "_Google Search - International - Tier 2",
                        "Google Display International - Text Ads", "Google Display International - Image Ads",
                        "Bing Search - International - Tier 1",
                        "Google Search Companion Marketing (International)")
      THEN "PPC - English - International"

    WHEN subSource IN (
      "_Google Search",
      "_Google Display Network",
      "Yahoo",
      "Ask.com",
      "_Google Search",
      "Go2Web20.net",
      "_Bing Search",
      "_Bing Content Network",
      "Ad Ready Network",
      "Facebook",
      "LinkedIn",
      "LinkedIn InMail",
      "LinkedIn International (paid)",
      "_Google Display (iPad only)",
      "_Google Search (iPad only)",
      "Google Remarketing (Paid Visitors)", "Google Remarketing (Non-paid Visitors)", "Google Remarketing (Nurture Signups)",
      "Bing Search (French - Canada)", "Bing Search (French - France)",
      "Youtube (promoted videos)",
      "_Display - Managed Placements",
      "Google Adwords Sitelinks",
      "Google Mobile Search (iphone)", "Google Mobile Search (non-iphone)",
      "Enterprise Display Test - Spreadsheet Hell - Desktop", "Enterprise Display Test - Spreadsheet Hell - Mobile",
      "BlueKai - (Google)", "Similar Audiences - (Google)",
      "Gmail Ads",
      "Gmail Ads - International",
      "Google Display - Interest Targeted",
      "Video for Adwords",
      "Google Business Category Display",
      "Seattle GEO Target (Google Search)",
      "Seattle GEO Target (Bing Search)",
      "Seattle GEO Target (Google Display Image)",
      "Seattle GEO Target (Bing Content)",
      "Seattle GEO Target (Google Text Display)",
      "Google Display - Image Ads",
      "Google Display - Text Ads",
      "Google Search Companion Marketing",
      "Similar Audiences (Google) - International",
      "Google Display - Interest Targeted (International)",
      "Bing Display - Text Ads (USA)",
      "Bing Display - Text Ads (English Not USA)",
      "Bing Sitelinks",
      "Display - Select Keyword",
      "Display - Select Keyword (International)"
    )
      THEN "PPC"
    WHEN subsource IN ("Twitter (paid)") THEN "Paid - Social"
    WHEN subsource IN ("DemandMetric.com","ProjectManagers.net","ProjectsAtWork.com","ProjectManagement.com") THEN "Paid - Email"
    ELSE "--unknown source--"
    END;
    RETURN GET_SOURCE;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_LOGINTYPENAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_LOGINTYPENAME`(loginType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE loginTypeName VARCHAR(50);
    SET loginTypeName =
    CASE loginType
    WHEN 1 THEN "Drupal Login (deprecated)"
    WHEN 2 THEN "Login Form"
    WHEN 3 THEN "Request Digest (deprecated)"
    WHEN 4 THEN "Login Ticket Drupal (deprecated)"
    WHEN 5 THEN "OPS Monitor (deprecated)"
    WHEN 6 THEN "OPS Console (deprecated)"
    WHEN 7 THEN "Login Ticket Auto Signin"
    WHEN 8 THEN "Login Ticket Remember Me"
    WHEN 9 THEN "API"
    WHEN 10 THEN "Login Ticket Password Reset"
    WHEN 11 THEN "Update Request"
    WHEN 12 THEN "Quick Add"
    WHEN 13 THEN "Editable Publish"
    WHEN 14 THEN "OpenID"
    WHEN 15 THEN "Read-only Publish"
    WHEN 16 THEN "Intuit Workplace (deprecated)"
    WHEN 17 THEN "Ops Console OpenID (deprecated)"
    WHEN 18 THEN "Gadget Session Exchange"
    WHEN 19 THEN "SSO Salesforce"
    WHEN 20 THEN "SSO SAML"
    WHEN 21 THEN "Rest User Credentials"
    WHEN 22 THEN "Rest Access Token"
    WHEN 23 THEN "Login Ticket Remember Me Mobile"
    WHEN 24 THEN "API"
    WHEN 25 THEN "Rest Auth Code"
    WHEN 26 THEN "Rest Refresh Token"
    WHEN 27 THEN "Rest Unauthenticated"
    WHEN 28 THEN "Rest Google Token Android"
    WHEN 29 THEN "Google OAuth2"
    ELSE CONCAT ('login ', loginType)
    END;
    return loginTypeName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_NEXTPAYMENTDATE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_NEXTPAYMENTDATE`(currentDateTime                DATETIME,
                                                                              iNextPaymentDate              DATETIME,
                                                                              pNextPaymentDate              DATETIME,
                                                                              paymentTerm                   TINYINT,
                                                                              iActualLastPaymentDate        DATETIME,
                                                                              pActualLastPaymentDate        DATETIME,
                                                                              accountType                   TINYINT,
                                                                              iPaymentStartDateTime         DATETIME,
                                                                              pPaymentStartDateTime         DATETIME,
                                                                              iPromoCode                    VARCHAR(50),
                                                                              pPromoCode                    VARCHAR(50),
                                                                              iPaymentProfileInsertDateTime DATETIME,
                                                                              pPaymentProfileInsertDateTime DATETIME) RETURNS datetime
DETERMINISTIC
  BEGIN
    DECLARE newNextPaymentDate DATETIME;
    declare nextPaymentDate datetime;
    declare actualLastPaymentDate datetime;
    DECLARE paymentStartDateTime DATETIME;
    DECLARE paymentStartDateTimeClean DATETIME;
    declare promoCode varchar(50);
    declare paymentProfileInsertDateTime datetime;


    SET nextPaymentDate = CASE WHEN accountType = 2 THEN pNextPaymentDate ELSE iNextPaymentDate END;
    SET actualLastPaymentDate = CASE WHEN accountType = 2 THEN pActualLastPaymentDate ELSE iActualLastPaymentDate END;
    SET paymentStartDateTime = CASE WHEN accountType = 2 THEN pPaymentStartDateTime ELSE ipaymentStartDateTime END;
    SET promoCode = CASE WHEN accountType = 2 THEN pPromoCode ELSE iPromoCode END;
    SET paymentProfileInsertDateTime = CASE WHEN accountType = 2 THEN pPaymentProfileInsertDateTime ELSE iPaymentProfileInsertDateTime END;


    SET paymentStartDateTimeClean =
    CASE paymentStartDateTime > '2008-09-30'
    WHEN 1
      THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
    ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
    END;


    SET newNextPaymentDate =
    CASE
    WHEN nextPaymentDate > currentDateTime
      THEN nextPaymentDate
    ELSE
      CASE
      WHEN paymentTerm = 12
        THEN
          CASE
          WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_FORMAT(
                CONCAT(YEAR(currentDateTime + 1), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)),
                '%Y-%m-%d 00:00:00')
          WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
               > currentDateTime
            THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
          ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
          END
      WHEN paymentTerm IN (1, 6)
        THEN
          CASE
          WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                            rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
          WHEN paymentTerm = 1
            THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
          ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
          END
      ELSE NULL
      END
    END;
    RETURN newNextPaymentDate;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_NEXTPAYMENTDATETEST` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_NEXTPAYMENTDATETEST`(currentDateTime                DATETIME,
                                                                                  iNextPaymentDate              DATETIME,
                                                                                  pNextPaymentDate              DATETIME,
                                                                                  paymentTerm                   TINYINT,
                                                                                  iActualLastPaymentDate        DATETIME,
                                                                                  pActualLastPaymentDate        DATETIME,
                                                                                  accountType                   TINYINT,
                                                                                  iPaymentStartDateTime         DATETIME,
                                                                                  pPaymentStartDateTime         DATETIME,
                                                                                  iPromoCode                    VARCHAR(50),
                                                                                  pPromoCode                    VARCHAR(50),
                                                                                  iPaymentProfileInsertDateTime DATETIME,
                                                                                  pPaymentProfileInsertDateTime DATETIME) RETURNS datetime
DETERMINISTIC
  BEGIN
    DECLARE newNextPaymentDate DATETIME;
    declare nextPaymentDate datetime;
    declare actualLastPaymentDate datetime;
    DECLARE paymentStartDateTime DATETIME;
    DECLARE paymentStartDateTimeClean DATETIME;
    declare promoCode varchar(50);
    declare paymentProfileInsertDateTime datetime;


    SET nextPaymentDate = CASE WHEN accountType = 2 THEN pNextPaymentDate ELSE iNextPaymentDate END;
    SET actualLastPaymentDate = CASE WHEN accountType = 2 THEN pActualLastPaymentDate ELSE iActualLastPaymentDate END;
    SET paymentStartDateTime = CASE WHEN accountType = 2 THEN pPaymentStartDateTime ELSE ipaymentStartDateTime END;
    SET promoCode = CASE WHEN accountType = 2 THEN pPromoCode ELSE iPromoCode END;
    SET paymentProfileInsertDateTime = CASE WHEN accountType = 2 THEN pPaymentProfileInsertDateTime ELSE iPaymentProfileInsertDateTime END;


    SET paymentStartDateTimeClean =
    CASE paymentStartDateTime > '2008-09-30'
    WHEN 1
      THEN IF(promoCode = 'BETALOCKIN' AND paymentProfileInsertDateTime < '2008-10-01', '2008-09-30', paymentStartDateTime)
    ELSE IF(paymentProfileInsertDateTime > '2008-09-30', paymentProfileInsertDateTime, '2008-09-29')
    END;


    SET newNextPaymentDate =
    CASE
    WHEN nextPaymentDate > currentDateTime
      THEN nextPaymentDate
    ELSE
      CASE
      WHEN paymentTerm = 12
        THEN
          CASE
          WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_FORMAT(
                CONCAT(YEAR(currentDateTime + 1), '-', MONTH(actualLastPaymentDate), '-', DAY(actualLastPaymentDate)),
                '%Y-%m-%d 00:00:00')
          WHEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
               > currentDateTime
            THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) YEAR)
          ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +((YEAR(currentDateTime) - YEAR(paymentStartDateTimeClean)) + 1) YEAR)
          END
      WHEN paymentTerm IN (1, 6)
        THEN
          CASE
          WHEN nextPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(nextPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate > DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL paymentTerm MONTH)
          WHEN actualLastPaymentDate < DATE_ADD(currentDateTime, INTERVAL -paymentTerm MONTH)
            THEN DATE_ADD(actualLastPaymentDate, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                            rpt_main_02.SMARTSHEET_MONTH(actualLastPaymentDate)) MONTH)
          WHEN paymentTerm = 1
            THEN DATE_ADD(paymentStartDateTimeClean, INTERVAL +(rpt_main_02.SMARTSHEET_MONTH(currentDateTime) -
                                                                rpt_main_02.SMARTSHEET_MONTH(paymentStartDateTimeClean)) MONTH)
          ELSE DATE_ADD(paymentStartDateTimeClean, INTERVAL +(paymentTerm) MONTH)
          END
      ELSE NULL
      END
    END;
    RETURN newNextPaymentDate;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PAYMENTSTARTDATETIME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTSTARTDATETIME`(accountType                TINYINT,
                                                                                   productID                  INT,
                                                                                   paymentStartDateTime       DATETIME,
                                                                                   parentPaymentStartDateTime DATETIME) RETURNS datetime
DETERMINISTIC
  BEGIN
    DECLARE newPaymentStartDateTime DATETIME;
    SET newPaymentStartDateTime =
    CASE
    WHEN
      accountType = 2 AND
      productID = 7 AND
      paymentStartDateTime < COALESCE(parentPaymentStartDateTime, "")
      THEN parentPaymentStartDateTime
    ELSE paymentStartDateTime
    END;
    RETURN newPaymentStartDateTime;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PAYMENTTERM` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTTERM`(paymentTerm TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE paymentTermName VARCHAR(50);
    SET paymentTermName =
    CASE paymentTerm
    WHEN 1 THEN "Monthly"
    WHEN 6 THEN "Semi-Annual"
    WHEN 12 THEN "Annual"
    ELSE CONCAT('Payment Term ', paymentTerm)
    END;
    RETURN paymentTermName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PAYMENTTYPE` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PAYMENTTYPE`(paymentType TINYINT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE paymentTypeName VARCHAR(50);
    SET paymentTypeName =
    CASE paymentType
    WHEN 0 THEN "None"
    WHEN 1 THEN "Credit Card"
    WHEN 2 THEN "Bill To"
    WHEN 3 THEN "Custom"
    WHEN 4 THEN "Promo"
    WHEN 5 THEN "Paid by Other"
    WHEN 6 THEN "Third Party"
    WHEN 7 THEN "Third Party - By Other"
    WHEN 8 THEN "PayPal"
    WHEN 9 THEN "Developer"
    WHEN 10 THEN "Bill To App"
    ELSE CONCAT('Payment Type ', paymentType)
    END;
    return paymentTypeName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PRODUCTNAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTNAME`(productID INT) RETURNS varchar(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE productName VARCHAR(50);
    SET productName =
    CASE productID
    WHEN -1 THEN NULL
    WHEN 0 THEN "Cancelled"
    WHEN 1 THEN "Trial"
    WHEN 2 THEN "Free"
    WHEN 3 THEN "Basic"
    WHEN 4 THEN "Advanced"
    WHEN 5 THEN "Premium"
    WHEN 7 THEN "Team"
    WHEN 8 THEN "Team Plus"
    WHEN 6 THEN "Enterprise_Legacy"
    WHEN 9 THEN "Student"
    WHEN 10 THEN "Business"
    WHEN 11 THEN "Enterprise"
    ELSE CONCAT('Product ', productID)
    END;
    RETURN productName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PRODUCTNAMERANK` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTNAMERANK`(productName varchar(50)) RETURNS tinyint(4)
DETERMINISTIC
  BEGIN
    DECLARE productRank TINYINT;
    SET productRank =
    CASE productName
    WHEN "Cancelled"   THEN 1
    WHEN "Trial"       THEN 2
    WHEN "Free"        THEN 3
    WHEN "Student"     THEN 4
    WHEN "Basic"       THEN 5
    WHEN "Advanced"    THEN 6
    WHEN "Premium"     THEN 7
    WHEN "Team"        THEN 8
    WHEN "Team Plus"   THEN 9
    WHEN "Business"    THEN 10
    WHEN "Enterprise"  THEN 11
    ELSE -1
    END;
    RETURN productRank;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_PRODUCTRANK` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_PRODUCTRANK`(productID INT) RETURNS tinyint(4)
DETERMINISTIC
  BEGIN
    DECLARE productRank TINYINT;
    SET productRank =
    CASE productID
    WHEN 0 THEN 1
    WHEN 1 THEN 2
    WHEN 2 THEN 3
    WHEN 9 THEN 4
    WHEN 3 THEN 5
    WHEN 4 THEN 6
    WHEN 5 THEN 7
    WHEN 7 THEN 8
    WHEN 8 THEN 9
    WHEN 10 THEN 10
    WHEN 6 THEN 11
    ELSE -1
    END;
    RETURN productRank;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_SFDCNAME` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SFDCNAME`(sfdcName VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE DBName VARCHAR(200);
    SET DBName =
    CASE sfdcName
    WHEN '00540000002I1xUAAS' THEN 'Annika'
    WHEN '00540000002r9VrAAI' THEN 'Brian'
    WHEN '00540000002HJjdAAG' THEN 'Chad'
    WHEN '00540000002n53kAAA' THEN 'Colton'
    WHEN '00540000003TBobAAG' THEN 'Dan'
    WHEN '00533000003ftWzAAI' THEN 'Daniel'
    WHEN '00540000001V66HAAS' THEN 'Darren'
    WHEN '00540000002nyKdAAI' THEN 'David'
    WHEN '00540000002pgcUAAQ' THEN 'Diana'
    WHEN '00533000003Tx3EAAS' THEN 'DrewJ'
    WHEN '00540000002qo7CAAQ' THEN 'Drew'
    WHEN '00540000002pPx6AAE' THEN 'Evan'
    WHEN '00540000002pD6KAAU' THEN 'Gary'
    WHEN '00540000002qWBaAAM' THEN 'Jeana'
    WHEN '00540000001V65sAAC' THEN 'Jennifer'
    WHEN '00533000003UqHGAA0' THEN 'Joel'
    WHEN '00540000002HFLrAAO' THEN 'Kara'
    WHEN '00540000002IYVtAAO' THEN 'Ken'
    WHEN '00540000002qXdzAAE' THEN 'Kevin'
    WHEN '00533000003ftXEAAY' THEN 'Lee'
    WHEN '00540000002n544AAA' THEN 'Liz'
    WHEN '00540000002pPwrAAE' THEN 'Maddie'
    WHEN '00540000002oaOPAAY' THEN 'Matthew'
    WHEN '00540000001TpXDAA0' THEN 'Max'
    WHEN '00533000003X6qpAAC' THEN 'Nate'
    WHEN '00540000002q7KrAAI' THEN 'Nick'
    WHEN '00540000002qXeiAAE' THEN 'NickN'
    WHEN '00533000003UqHLAA0' THEN 'PaulC'
    WHEN '00540000002orVSAAY' THEN 'Roman'
    WHEN '00540000002HLLxAAO' THEN 'Ryaire'
    WHEN '00540000002pgcPAAQ' THEN 'Ryan'
    WHEN '00533000003ftX4AAI' THEN 'SamH'
    WHEN '00533000003U473AAC' THEN 'SarahB'
    WHEN '00540000002FcZIAA0' THEN 'Sarah'
    WHEN '00540000002Fm0cAAC' THEN 'Sean'
    WHEN '00540000002J7pjAAC' THEN 'Steve'
    WHEN '00540000001UFtyAAG' THEN 'Tyler'
    WHEN '00540000002qf8LAAQ' THEN 'Tom'
    WHEN '00540000001U30SAAS' THEN 'Taryn'
    WHEN '00540000001U6hoAAC' THEN 'Desk Integration'
    WHEN '00540000002nu18AAA' THEN 'Andrew Imhoff'
    WHEN '00540000001UHNaAAO' THEN 'Leads Uploader'
    WHEN '00540000002HoCGAA0' THEN 'Marketo Integration'

    WHEN '00533000003Tx39AAC' THEN 'Sam'
    WHEN '00533000003UaPiAAK' THEN 'NickC'
    WHEN '00540000001U30XAAS' THEN 'Tim'
    WHEN '00540000001UcZXAA0' THEN 'AJ'
    WHEN '00540000001UFlfAAG' THEN 'Taylor'
    WHEN '00540000001UFlVAAW' THEN 'Ben'
    WHEN '00540000001UiO2AAK' THEN 'Eric'
    WHEN '00540000002Fqe3AAC' THEN 'Joe'
    WHEN '00540000002GeyBAAS' THEN 'Jeff'
    WHEN '00540000002GeyGAAS' THEN 'Chris'
    WHEN '00540000002HJwXAAW' THEN 'ChrisK'
    WHEN '00540000002I1xKAAS' THEN 'Karrin'
    WHEN '00540000002IocCAAS' THEN 'Michael'
    WHEN '00540000002Iuo4AAC' THEN 'JeffD'
    WHEN '00540000002JDUTAA4' THEN 'Anthony'
    WHEN '00540000002nfpCAAQ' THEN 'Alex'
    WHEN '00540000002nyKnAAI' THEN 'Paul'
    WHEN '00540000002pPwwAAE' THEN 'Alex'
    WHEN '00540000002r9XiAAI' THEN 'Sebrina'
    WHEN '00540000002IJzPAAW' THEN 'Platform'
    WHEN '00533000003X6quAAC' THEN 'BenL'
    WHEN '00533000003X6qzAAC' THEN 'MattS'
    WHEN '00533000003X6r4AAC' THEN 'MarkL'
    WHEN '00533000003UqH6AAK' THEN 'Lauren'
    WHEN '00540000002r9WkAAI' THEN 'SeanM'
    when '00533000003U0iyAAC' THEN 'Jana'
    WHEN '00533000003ft2kAAA' THEN 'Mason'
    WHEN '00533000003gDpNAAU' then 'Cassie'
    when '00533000003qkhHAAQ' THEN 'JeffDy'
    when '00533000003g3CLAAY' then 'Glenn'
    when '00533000003rC4mAAE' THEN 'JeffB'
    when '00533000003uQZ1AAM' then 'MikeBo'
    when '00533000003w7shAAA' then 'Kari'
    when '00533000003w7swAAA' then 'Rich'
    WHEN '00533000003y0SRAAY' THEN 'Julie'
    when '00533000003wglgAAA' then 'MattSu'
    WHEN '00533000003zZSYAA2' then 'Bill'
    when '00533000003zZSsAAM' THEN 'Keith'
    WHEN '00533000003zZSiAAM' THEN 'DavidS'
    WHEN '00533000003OTJPAA4' THEN 'RobR'
    WHEN '00533000003OTfaAAG' THEN 'AbbieA'
    WHEN '00533000003OTn0AAG' THEN 'PaulHa'
    WHEN '00533000003OTohAAG' THEN 'ChristineA'
    WHEN '00533000003OTp6AAG' THEN 'DanM'
    WHEN '00533000003OTcqAAG' THEN 'CourtniK'
    ELSE sfdcName
    END;
    RETURN DBName;
  END */$$
DELIMITER ;

/* Function  structure for function  `SMARTSHEET_SFDCNAMECONVERT` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` FUNCTION `SMARTSHEET_SFDCNAMECONVERT`(sfdcName VARCHAR(50)) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
DETERMINISTIC
  BEGIN
    DECLARE DBName VARCHAR(200);
    SET DBName =
    CASE sfdcName
    WHEN 'Annika' THEN  '00540000002I1xUAAS'
    WHEN 'Brian' THEN '00540000002r9VrAAI'
    WHEN 'Chad' THEN '00540000002HJjdAAG'
    WHEN 'Colton' THEN '00540000002n53kAAA'
    WHEN 'Dan' THEN '00540000003TBobAAG'
    WHEN 'Daniel' THEN '00533000003ftWzAAI'
    WHEN 'Darren' THEN '00540000001V66HAAS'
    WHEN 'David' THEN '00540000002nyKdAAI'
    WHEN 'Diana' THEN '00540000002pgcUAAQ'
    WHEN 'DrewJ' THEN '00533000003Tx3EAAS'
    WHEN 'Drew' THEN '00540000002qo7CAAQ'
    WHEN 'Evan' THEN '00540000002pPx6AAE'
    WHEN 'Gary' THEN '00540000002pD6KAAU'
    WHEN 'Jeana' THEN '00540000002qWBaAAM'
    WHEN 'Jennifer' THEN '00540000001V65sAAC'
    WHEN 'Joel' THEN '00533000003UqHGAA0'
    WHEN 'Kara' THEN '00540000002HFLrAAO'
    WHEN 'Ken' THEN '00540000002IYVtAAO'
    WHEN 'Kevin' THEN '00540000002qXdzAAE'
    WHEN 'Lee' THEN '00533000003ftXEAAY'
    WHEN 'Liz' THEN '00540000002n544AAA'
    WHEN 'Maddie' THEN '00540000002pPwrAAE'
    WHEN 'Matthew' THEN '00540000002oaOPAAY'
    WHEN 'Max' THEN '00540000001TpXDAA0'
    WHEN 'Nate' THEN '00533000003X6qpAAC'
    WHEN 'Nick' THEN '00540000002q7KrAAI'
    WHEN 'NickN' THEN '00540000002qXeiAAE'
    WHEN 'PaulC' THEN '00533000003UqHLAA0'
    WHEN 'Roman' THEN '00540000002orVSAAY'
    WHEN 'Ryaire' THEN '00540000002HLLxAAO'
    WHEN 'Ryan' THEN '00540000002pgcPAAQ'
    WHEN 'SamH' THEN '00533000003ftX4AAI'
    WHEN 'SarahB' THEN '00533000003U473AAC'
    WHEN 'Sarah' THEN '00540000002FcZIAA0'
    WHEN 'Sean' THEN '00540000002Fm0cAAC'
    WHEN 'Steve' THEN '00540000002J7pjAAC'
    WHEN 'Tyler' THEN '00540000001UFtyAAG'
    WHEN 'Tom' THEN '00540000002qf8LAAQ'
    WHEN 'Taryn' THEN '00540000001U30SAAS'
    WHEN 'Desk' THEN '00540000001U6hoAAC'
    WHEN 'Andrew Imhoff' THEN '00540000002nu18AAA'
    WHEN 'Leads Uploader' THEN '00540000001UHNaAAO'
    WHEN 'Marketo Integration' THEN '00540000002HoCGAA0'
    WHEN 'Sam' THEN '00533000003Tx39AAC'
    WHEN 'NickC' THEN '00533000003UaPiAAK'
    WHEN 'Tim' THEN '00540000001U30XAAS'
    WHEN 'AJ' THEN '00540000001UcZXAA0'
    WHEN 'Taylor' THEN '00540000001UFlfAAG'
    WHEN 'Ben' THEN '00540000001UFlVAAW'
    WHEN 'Eric' THEN '00540000001UiO2AAK'
    WHEN 'Joe' THEN '00540000002Fqe3AAC'
    WHEN 'Jeff' THEN '00540000002GeyBAAS'
    WHEN 'Chris' THEN '00540000002GeyGAAS'
    WHEN 'ChrisK' THEN '00540000002HJwXAAW'
    WHEN 'Karrin' THEN '00540000002I1xKAAS'
    WHEN 'Michael' THEN '00540000002IocCAAS'
    WHEN 'JeffD' THEN '00540000002Iuo4AAC'
    WHEN 'Anthony' THEN '00540000002JDUTAA4'
    WHEN 'Alex' THEN '00540000002nfpCAAQ'
    WHEN 'Paul' THEN '00540000002nyKnAAI'
    WHEN 'Alex' THEN '00540000002pPwwAAE'
    WHEN 'Sebrina' THEN '00540000002r9XiAAI'
    WHEN 'Platform' THEN '00540000002IJzPAAW'
    WHEN 'BenL' THEN '00533000003X6quAAC'
    WHEN 'MattS' THEN '00533000003X6qzAAC'
    WHEN 'MarkL' THEN '00533000003X6r4AAC'
    WHEN 'Lauren' THEN '00533000003UqH6AAK'
    WHEN 'SeanM' THEN '00540000002r9WkAAI'
    WHEN 'Jana' THEN '00533000003U0iyAAC'
    WHEN 'Mason' THEN '00533000003ft2kAAA'
    WHEN 'Cassie' THEN '00533000003gDpNAAU'
    WHEN 'JeffDy' THEN '00533000003qkhHAAQ'
    WHEN 'Glenn' THEN '00533000003g3CLAAY'
    WHEN 'JeffB' THEN '00533000003rC4mAAE'
    WHEN 'MikeBo' THEN '00533000003uQZ1AAM'
    WHEN 'Kari' THEN '00533000003w7shAAA'
    WHEN 'Rich' THEN '00533000003w7swAAA'
    WHEN 'Julie' THEN '00533000003y0SRAAY'
    WHEN 'MattSu' THEN '00533000003wglgAAA'
    WHEN 'Bill' THEN '00533000003zZSYAA2'
    WHEN 'Keith' THEN '00533000003zZSsAAM'
    WHEN 'DavidS' THEN '00533000003zZSiAAM'
    WHEN 'RobR' THEN '00533000003OTJPAA4'
    WHEN 'AbbieA' THEN '00533000003OTfaAAG'
    WHEN 'PaulHa' THEN '00533000003OTn0AAG'
    WHEN 'ChristineA' THEN '00533000003OTohAAG'
    WHEN 'DanM' THEN '00533000003OTp6AAG'
    WHEN 'CourtniK' THEN '00533000003OTcqAAG'

    ELSE sfdcName
    END;
    RETURN DBName;
  END */$$
DELIMITER ;



/* Procedure structure for procedure `SMARTSHEET_START_LOG` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_START_LOG`( in buildSource varchar(100), IN buildStep VARCHAR(250) )
  BEGIN
    DECLARE bID INT;
    DECLARE bS INT;
    DECLARE startTime DATETIME;
    SELECT MAX(buildSequence) INTO bS FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, "%Y-%m-%d") = CURRENT_DATE();
    IF bS IS NULL
    THEN SET bS = 0;
    ELSE SET bS = (SELECT MAX(buildSequence) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, "%Y-%m-%d") = CURRENT_DATE() );
    END IF
    ;
    SELECT MAX(buildID) INTO bID FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, "%Y-%m-%d") = CURRENT_DATE();
    IF bID IS NULL
    THEN SET bID = (SELECT MAX(buildID)+1 FROM leadflow.arc_marketo_query_history);
    ELSE SET bID = (SELECT MAX(buildID) FROM leadflow.arc_marketo_query_history WHERE DATE_FORMAT(leadflow.arc_marketo_query_history.startTime, "%Y-%m-%d") = CURRENT_DATE() );
    END IF
    ;
    SET bS = bS+1;
    SET startTime = NOW();
    INSERT INTO leadflow.arc_marketo_query_history (buildID, buildSequence, buildSource, buildStep, startTime)
      SELECT bID, bS, buildSource, buildStep, startTime;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `SMARTSHEET_STOP_LOG` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_STOP_LOG`( IN buildSource VARCHAR(100), IN buildStep VARCHAR(250) )
  BEGIN
    DECLARE endTime DATETIME;
    DECLARE buildSequence INT;
    SET endTime = NOW();
    SET buildSequence = (SELECT MAX(mqh.buildSequence) FROM leadflow.arc_marketo_query_history mqh
    WHERE mqh.buildStep = buildStep and mqh.buildSource = buildSource AND DATE_FORMAT(mqh.startTime, "%Y-%m-%d") = CURRENT_DATE());
    UPDATE leadflow.arc_marketo_query_history arc
    SET
      arc.timeElapsed = TIME_TO_SEC(TIMEDIFF(endTime, startTime)),
      arc.endTime = endTime
    WHERE
      arc.buildStep = buildStep
      and arc.buildSource = buildSource
      and arc.buildSequence = buildSequence
      AND DATE_FORMAT(arc.startTime, "%Y-%m-%d") = CURRENT_DATE()
    ;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `SMARTSHEET_TABLE_OPTIMIZER` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `SMARTSHEET_TABLE_OPTIMIZER`()
  BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE maxClientEventID BIGINT;
    DECLARE TableName VARCHAR(200);
    DECLARE cur1 CURSOR FOR
      SELECT DISTINCT TABLE_NAME
      FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA = 'rpt_main_02'

      ORDER BY TABLE_NAME
    ;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN cur1;
    read_loop: LOOP
      FETCH cur1 INTO TableName;
      IF done THEN
        LEAVE read_loop;
      END IF;
      SELECT TableName;
      SET @table_name = TableName;
      SET @sql_text = CONCAT('OPTIMIZE TABLE ',@table_name);
      PREPARE stmt1 FROM @sql_text;

      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;
    END LOOP;
    CLOSE cur1;
  END */$$
DELIMITER ;

/* Procedure structure for procedure `utl_checkLeadSeeds` */

DELIMITER $$

/*!50003 CREATE DEFINER=`jmarzinke`@`%` PROCEDURE `utl_checkLeadSeeds`()
  begin
    DECLARE noLeads CONDITION FOR SQLSTATE '45001';
    declare leadCount int default 0;
    set leadCount = (
      select count(*)
      from leadSeed
      where insertDateTime > date_sub(now(),interval 20 MINUTE));

    select day(insertDateTime) day, hour(insertDateTime) hour, count(*)
    from leadSeed
    where insertDateTime > date_sub(now(),interval 23 hour)
    group by day(insertDateTime), hour(insertDateTime);
    IF leadCount = 0 THEN
      SIGNAL noLeads
      SET MESSAGE_TEXT = 'NO LEADS IN LAST HOUR!!!';
    END IF;
  end */$$
DELIMITER ;

/*Table structure for table `tmp_collabs_opt_out2` */

DROP TABLE IF EXISTS `tmp_collabs_opt_out2`;

/*!50001 CREATE TABLE  `tmp_collabs_opt_out2`(
  `userID` bigint(20) ,
  `excludeFromMarketingEmail` tinyint(4)
)*/;

/*View structure for view tmp_collabs_opt_out2 */

/*!50001 DROP TABLE IF EXISTS `tmp_collabs_opt_out2` */;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`jmarzinke`@`%` SQL SECURITY DEFINER VIEW `tmp_collabs_opt_out2` AS select `mu2`.`userID` AS `userID`,`dee`.`excludeFromMarketingEmail` AS `excludeFromMarketingEmail` from (((((`leadflow`.`arc_marketo_upload` `mu` join `rpt_main_02`.`arc_domainEmailExclusion` `dee` on(((`mu`.`emailDomain` = `dee`.`domain`) and (`dee`.`excludeFromMarketingEmail` = 1) and (`dee`.`domain` <> 'smartsheet.com')))) join `rpt_main_02`.`userAccount` `ua` on((`mu`.`userID` = `ua`.`insertByUserID`))) left join `rpt_main_02`.`arc_domainEmailExclusion` `dee2` on(((`ua`.`domain` = `dee2`.`domain`) and (coalesce(`dee2`.`excludeFromMarketingEmail`,0) = 1)))) left join `rpt_main_02`.`arc_paymentProfileEmailExclusion` `ppee` on(((`ua`.`domain` = `mu`.`emailDomain`) and (coalesce(`ppee`.`excludeFromMarketingEmail`,0) = 1)))) join `leadflow`.`arc_marketo_upload` `mu2` on((`ua`.`userID` = `mu2`.`userID`))) where (isnull(`dee2`.`domain`) and isnull(`ppee`.`parentPaymentProfileID`)) union select `mu2`.`userID` AS `userID`,`ppee`.`excludeFromMarketingEmail` AS `excludeFromMarketingEmail` from ((((((`ss_core_02`.`paymentProfile` `pp` join `rpt_main_02`.`arc_paymentProfileEmailExclusion` `ppee` on(((`pp`.`parentPaymentProfileID` = `ppee`.`parentPaymentProfileID`) and (`ppee`.`excludeFromMarketingEmail` = 1) and (`ppee`.`parentPaymentProfileID` <> 1274494)))) join `leadflow`.`arc_marketo_upload` `mu` on((`pp`.`ownerID` = `mu`.`userID`))) join `rpt_main_02`.`userAccount` `ua` on((`mu`.`userID` = `ua`.`insertByUserID`))) left join `rpt_main_02`.`arc_paymentProfileEmailExclusion` `ppee2` on(((`ua`.`domain` = `mu`.`emailDomain`) and (coalesce(`ppee2`.`excludeFromMarketingEmail`,0) = 1)))) left join `rpt_main_02`.`arc_domainEmailExclusion` `dee` on(((`ua`.`domain` = `dee`.`domain`) and (coalesce(`dee`.`excludeFromMarketingEmail`,0) = 1)))) join `leadflow`.`arc_marketo_upload` `mu2` on((`ua`.`userID` = `mu2`.`userID`))) where (isnull(`ppee2`.`parentPaymentProfileID`) and isnull(`dee`.`domain`)) limit 100000 */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
