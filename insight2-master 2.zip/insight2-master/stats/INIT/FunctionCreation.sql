select "******************************************************************************************************************************", NOW();
select "******** Create Functions in rpt_main_02  ******** ", NOW();


delimiter //

/*Proc to optimize (rebuild tables and indexes) for tables with a combined table and index size less than 50GB*/
CREATE PROCEDURE rpt_main_02.`SMARTSHEET_TABLE_OPTIMIZER`()
BEGIN

DECLARE done INT DEFAULT 0;

DECLARE TableName VARCHAR(200);

DECLARE cur1 CURSOR FOR 
SELECT DISTINCT TABLE_NAME
FROM 
(
	SELECT table_schema, table_name, engine, row_format, table_rows, data_length/1000000000 AS data_length_GB, index_length/1000000000 AS index_length_GB, create_time, update_time, check_time
	FROM information_schema.tables 
	WHERE table_schema = 'rpt_main_02'
	AND (check_time IS NULL
	OR check_time < DATE_ADD(CURRENT_DATE(),INTERVAL -7 DAY))
) a
WHERE data_length_GB+index_length_GB <= 50
ORDER BY TABLE_NAME
;


DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

OPEN cur1;

read_loop: LOOP
	FETCH cur1 INTO TableName;
	IF done THEN
	LEAVE read_loop;
END IF;

SELECT TableName;
SET @table_name = TableName;
SET @sql_text = CONCAT('OPTIMIZE TABLE ',@table_name);
PREPARE stmt1 FROM @sql_text;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

END LOOP;

CLOSE cur1;

END
//



/*Function to initiate logging for nightly job process*/
CREATE PROCEDURE rpt_main_02.`SMARTSHEET_START_LOG`(IN tableName VARCHAR(300) )
BEGIN


DECLARE bN INT;
DECLARE pS INT;
DECLARE startTime DATETIME;

SELECT MAX(prepSequence) INTO pS FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, "%Y-%m-%d") = CURRENT_DATE();


IF pS IS NULL 
THEN SET pS = 0;
ELSE SET pS = (SELECT MAX(prepSequence) FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, "%Y-%m-%d") = CURRENT_DATE() );
END IF
;

SELECT MAX(buildNumber) INTO bN FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, "%Y-%m-%d") = CURRENT_DATE();

IF bN IS NULL
THEN SET bN = (SELECT MAX(buildNumber)+1 FROM rpt_main_02.arc_prepV2QueryHistory);
ELSE SET bN = (SELECT MAX(buildNumber) FROM rpt_main_02.arc_prepV2QueryHistory WHERE DATE_FORMAT(rpt_main_02.arc_prepV2QueryHistory.startTime, "%Y-%m-%d") = CURRENT_DATE() );
END IF
;


SET pS = pS+1;
SET startTime = NOW();

INSERT INTO rpt_main_02.arc_prepV2QueryHistory (buildNumber, prepSequence, tableName, startTime)
SELECT bN, pS, tableName, startTime;
END
//


/*Function to end logging on nightly job process*/
CREATE PROCEDURE rpt_main_02.`SMARTSHEET_STOP_LOG`(IN tableName VARCHAR(300) )
BEGIN

DECLARE endTime DATETIME;

SET endTime = NOW();


UPDATE rpt_main_02.arc_prepV2QueryHistory arc
SET timeElapsed = TIME_TO_SEC(TIMEDIFF(endTime,startTime))
WHERE arc.tableName = tableName
AND DATE_FORMAT(arc.startTime, "%Y-%m-%d") = CURRENT_DATE()
;


END//       

/* Function to produce Product Name when given ProductID */
DROP FUNCTION IF EXISTS `SMARTSHEET_PRODUCTNAME`$$

CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTNAME`(productID INT) RETURNS VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_unicode_520_ci
    DETERMINISTIC
BEGIN
DECLARE productName VARCHAR(50);
SET productName =
  CASE productID
     WHEN -1 THEN NULL
     WHEN 0 THEN "Cancelled"
     WHEN 1 THEN "Trial"
     WHEN 2 THEN "Free"
     WHEN 3 THEN "Basic"
     WHEN 4 THEN "Advanced"
     WHEN 5 THEN "Premium"
     WHEN 7 THEN "Team"
     WHEN 8 THEN "Team Plus"
     WHEN 6 THEN "Enterprise"
     WHEN 9 THEN "Student"
     WHEN 10 THEN "Business"
     ELSE CONCAT('Product ', productID)
  END;
RETURN productName;
END$$

/* Function to rank the Products given their ProductID.  
 * Solves the problem of Enterprise Accounts being given a productID = 6. */
DROP FUNCTION IF EXISTS `SMARTSHEET_PRODUCTRANK`$$

CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTRANK`(productID INT) RETURNS TINYINT(4)
    DETERMINISTIC
BEGIN
DECLARE productRank TINYINT;
SET productRank =
  CASE productID
     WHEN 0 THEN 1 /* productID = 0  "Cancelled" */
     WHEN 1 THEN 2 /* productID = 1  "Trial" */
     WHEN 2 THEN 3 /* productID = 2  "Free" */
     WHEN 9 THEN 4 /* productID = 9 "Student" */
     WHEN 3 THEN 5 /* productID = 3  "Basic" */
     WHEN 4 THEN 6 /* productID = 4  "Advanced" */
     WHEN 5 THEN 7 /* productID = 5  "Premium" */
     WHEN 7 THEN 8 /* productID = 7  "Team */
     WHEN 8 THEN 9 /* productID = 8  "Team Plus" */
     WHEN 10 THEN 10 /* productID = 10 "Business" */
     WHEN 6 THEN 11 /* productID = 6  "Enterprise" */
     ELSE -1
  END;
RETURN productRank;
END$$

/* Function to get the Product name given their product rank. */
DROP FUNCTION IF EXISTS `SMARTSHEET_PRODUCTRANKCONVERT`$$

CREATE DEFINER=`cdunn`@`%` FUNCTION `SMARTSHEET_PRODUCTRANKCONVERT`(productRank TINYINT) RETURNS TINYINT(4)
    DETERMINISTIC
BEGIN
DECLARE productRankConvert TINYINT;
SET productRank = 
  CASE productRank
     WHEN 1 THEN 0/* productID = 0  "Cancelled" */
     WHEN 2 THEN 1/* productID = 1  "Trial" */
     WHEN 3 THEN 2/* productID = 2  "Free" */
     WHEN 4 THEN 9 /* productID = 9 "Student" */
     WHEN 5 THEN 3/* productID = 3  "Basic" */
     WHEN 6 THEN 4/* productID = 4  "Advanced" */
     WHEN 7 THEN 5/* productID = 5  "Premium" */
     WHEN 8 THEN 7/* productID = 7  "Team */
     WHEN 9 THEN 8/* productID = 8  "Team Plus" */
     WHEN 10 THEN 10/* productID = 10  "Business" */
     WHEN 11 THEN 6 /* productID = 6  "Enterprise" */
     ELSE -1
  END;
RETURN productRank;
END$$


/*Function to produce the LogIn Type Name when given a numeric LogInType*/
DROP FUNCTION IF EXISTS SMARTSHEET_LOGINTYPENAME//	
CREATE FUNCTION SMARTSHEET_LOGINTYPENAME (loginType TINYINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE loginTypeName VARCHAR(50);
SET loginTypeName = 
	CASE loginType
		WHEN 1 THEN "Drupal Login (deprecated)"
		WHEN 2 THEN "Login Form"
		WHEN 3 THEN "Request Digest (deprecated)"
		WHEN 4 THEN "Login Ticket Drupal (deprecated)"
		WHEN 5 THEN "OPS Monitor (deprecated)"
		WHEN 6 THEN "OPS Console (deprecated)"
		WHEN 7 THEN "Login Ticket Auto Signin"
		WHEN 8 THEN "Login Ticket Remember Me"
		WHEN 9 THEN "API"
		WHEN 10 THEN "Login Ticket Password Reset"
		WHEN 11 THEN "Update Request"
		WHEN 12 THEN "Quick Add"
		WHEN 13 THEN "Editable Publish"
		WHEN 14 THEN "OpenID"
		WHEN 15 THEN "Read-only Publish"
		WHEN 16 THEN "Intuit Workplace (deprecated)"
		WHEN 17 THEN "Ops Console OpenID (deprecated)"
		WHEN 18 THEN "Gadget Session Exchange"
		WHEN 19 THEN "SSO Salesforce"
		WHEN 20 THEN "SSO SAML"
		WHEN 21 THEN "Rest User Credentials"
		WHEN 22 THEN "Rest Access Token"
		WHEN 23 THEN "Login Ticket Remember Me Mobile"
		WHEN 24 THEN "API"
		WHEN 25 THEN "Rest Auth Code"
		WHEN 26 THEN "Rest Refresh Token"
		WHEN 27 THEN "Rest Unauthenticated"
		WHEN 28 THEN "Rest Google Auth"
		WHEN 29 THEN "Google OAuth2"
		WHEN 30 THEN "Google OAuth2"
        WHEN 31 THEN "Signup"
		WHEN 32 THEN "MS Azure AD"
		WHEN 33 THEN "Rest Google JWT Auth"
		when 34 THEN "Web Form"
        WHEN 35 THEN "Download Ticket"
        WHEN 36 THEN "Rest Azure JWT Auth"
        WHEN 37 THEN "Rest Azure Ticket Auth"
        WHEN 38 THEN "Approval Request"
		ELSE CONCAT ('login ', loginType)
	END;
return loginTypeName;
END
//

/*Function to produce the Authentication Result when given a numeric AuthType*/
DROP FUNCTION IF EXISTS SMARTSHEET_AUTHRESULT//	
CREATE FUNCTION SMARTSHEET_AUTHRESULT (AuthType SMALLINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE AuthResultName VARCHAR(50);
SET AuthResultName = 
	CASE AuthType
		WHEN 1 THEN "SUCCESS"
		WHEN 0 THEN "No error"
		WHEN -1 THEN "INVALID_USER_OR_PASSWORD"
		WHEN -2 THEN "LOGIN_TICKET_DOES_NOT_EXIST"
		WHEN -3 THEN "DUPLICATE_LOGIN_TICKETS"
		WHEN -4 THEN "LOGIN_TICKET_CORRUPT"
		WHEN -5 THEN "LOGIN_TICKET_NOT_VALID"
		WHEN -6 THEN "ACCOUNT_LOCKEDOUT"
		WHEN -7 THEN "REUSED_REQUEST_DIGEST"
		WHEN -8 THEN "INVALID_REQUEST_DIGEST"
		WHEN -9 THEN "NO_MATCHING_USER"
		WHEN -10 THEN "INVALID_EMAIL_FORMAT"
		WHEN -11 THEN "USER_NOT_CONFIRMED"
		WHEN -12 THEN "ACCOUNT_BLOCKED"
		WHEN -13 THEN "INVALID_UPDATE_TICKET"
		WHEN -14 THEN "ACCOUNT_LOCKEDOUT_MAX"
		WHEN -15 THEN "BLOCKED_IP_ADDRESS"
		WHEN -16 THEN "SAML_REQUIRED_FOR_AUTH"
		WHEN -17 THEN "ACCESS_TOKEN_REQUIRED"
		WHEN -18 THEN "ACCESS_TOKEN_EXPIRED"
		WHEN -19 THEN "Rest User Credentials"
		WHEN -20 THEN "INVALID_ASSUME_USER"
		WHEN -21 THEN "ASSUME_USER_REQUIRED"
		WHEN -22 THEN "LEGACY_PASSWORD_FORMAT"
		ELSE CONCAT ('AuthResult ', AuthType)
	END;
return AuthResultName;
END
//

/*
			SUCCESS						(  1, null),
			NO_ERROR					(  0, ProcessingException.Error.AUTH_NO_MATCHING_USER		, RestProcessingException.RestError.AUTH_USER_NOT_FOUND),
			INVALID_USER_OR_PASSWORD	( -1, ProcessingException.Error.AUTH_NO_MATCHING_USER		, RestProcessingException.RestError.AUTH_USER_NOT_FOUND),
			LOGIN_TICKET_DOES_NOT_EXIST	( -2, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			DUPLICATE_LOGIN_TICKETS		( -3, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			LOGIN_TICKET_CORRUPT		( -4, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			LOGIN_TICKET_NOT_VALID		( -5, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			ACCOUNT_LOCKEDOUT			( -6, ProcessingException.Error.AUTH_ACCOUNT_LOCKEDOUT		, RestProcessingException.RestError.AUTH_ACCOUNT_LOCKEDOUT),
			REUSED_REQUEST_DIGEST		( -7, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			INVALID_REQUEST_DIGEST		( -8, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			NO_MATCHING_USER			( -9, ProcessingException.Error.AUTH_NO_MATCHING_USER		, RestProcessingException.RestError.AUTH_USER_NOT_FOUND),
			INVALID_EMAIL_FORMAT		(-10, ProcessingException.Error.AUTH_INVALID_EMAIL			, RestProcessingException.RestError.AUTH_INVALID_EMAIL),
			USER_NOT_CONFIRMED			(-11, ProcessingException.Error.AUTH_ACCOUNT_NOT_CONFIRMED	, RestProcessingException.RestError.AUTH_ACCOUNT_NOT_VERIFIED),
			ACCOUNT_BLOCKED				(-12, ProcessingException.Error.AUTH_ACCOUNT_BLOCKED		, RestProcessingException.RestError.AUTH_ACCOUNT_BLOCKED),
			INVALID_UPDATE_TICKET		(-13, ProcessingException.Error.AUTH_INVALID_LOGIN_TICKET	),
			ACCOUNT_LOCKEDOUT_MAX		(-14, ProcessingException.Error.AUTH_NO_MATCHING_USER		, RestProcessingException.RestError.AUTH_USER_NOT_FOUND),
			BLOCKED_IP_ADDRESS			(-15, ProcessingException.Error.AUTH_ACCOUNT_BLOCKED		, RestProcessingException.RestError.AUTH_ACCOUNT_BLOCKED),
			SAML_REQUIRED_FOR_AUTH		(-16, ProcessingException.Error.SAML_SIGNON_REQUIRED		, RestProcessingException.RestError.SSO_REQUIRED),
			ACCESS_TOKEN_REQUIRED		(-17, null													, RestProcessingException.RestError.TOKEN_REQUIRED ),
			INVALID_ACCESS_TOKEN 	    (-18, null													, RestProcessingException.RestError.TOKEN_INVALID	),
			ACCESS_TOKEN_EXPIRED		(-19, null													, RestProcessingException.RestError.TOKEN_EXPIRED),	
			INVALID_ASSUME_USER			(-20, null													, RestProcessingException.RestError.INVALID_ASSUME_USER),	
			ASSUME_USER_REQUIRED		(-21, null													, RestProcessingException.RestError.ASSUME_USER_NOT_FOUND),	
			LEGACY_PASSWORD_FORMAT		(-22, ProcessingException.Error.AUTH_NO_MATCHING_USER		, RestProcessingException.RestError.AUTH_USER_NOT_FOUND),
*/


/*Function to produce a text Login Status when a numermic LoginStatus*/
DROP FUNCTION IF EXISTS SMARTSHEET_LOGINSTATUS//	
CREATE FUNCTION SMARTSHEET_LOGINSTATUS (loginStatus TINYINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE LoginStatusName VARCHAR(20);
SET LoginStatusName = 
	CASE loginStatus
		WHEN 2 THEN "Authenticated"
		WHEN 0 THEN "Unresolved"
		ELSE CONCAT ('LoginStatus ', loginStatus)
	END;
return LoginStatusName;
END
//

/*Function to produce text for Account Type when given numeric accountType*/
DROP FUNCTION IF EXISTS SMARTSHEET_ACCOUNTTYPE//
CREATE FUNCTION SMARTSHEET_ACCOUNTTYPE(accountType TINYINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE accountTypeName VARCHAR(50);
SET accountTypeName = 
  CASE accountType
     WHEN 1 THEN "Standard"
     WHEN 2 THEN "Multi-user"
     WHEN 3 THEN "Organization"
     ELSE CONCAT('Account Type ', accountType)
  END;
return accountTypeName;
END
//

/*Function to produce text for Payment Type when given numeric paymentType*/
DROP FUNCTION IF EXISTS SMARTSHEET_PAYMENTTYPE//
CREATE FUNCTION SMARTSHEET_PAYMENTTYPE(paymentType TINYINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE paymentTypeName VARCHAR(50);
SET paymentTypeName =
  CASE paymentType
	WHEN 0 THEN "None"
	WHEN 1 THEN "Credit Card"
	WHEN 2 THEN "Bill To"
	WHEN 3 THEN "Custom"
	WHEN 4 THEN "Promo"
	WHEN 5 THEN "Paid by Other"
	WHEN 6 THEN "Third Party"
	WHEN 7 THEN "Third Party - By Other"
	WHEN 8 THEN "Paypal"
	WHEN 9 THEN "Developer"
	WHEN 10 THEN "Bill To App"
	ELSE CONCAT('Payment Type ', paymentType)
  END;
return paymentTypeName;
END
//

/*Function to produce text for Payment Term when given numeric paymentTerm*/
DROP FUNCTION IF EXISTS SMARTSHEET_PAYMENTTERM//
CREATE FUNCTION SMARTSHEET_PAYMENTTERM(paymentTerm TINYINT)
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE paymentTermName VARCHAR(50);
SET paymentTermName = 
  CASE paymentTerm
     WHEN 1 THEN "Monthly"
     WHEN 6 THEN "Semi-Annual"
     WHEN 12 THEN "Annual"
     ELSE CONCAT('Payment Term ', paymentTerm)
  END;
RETURN paymentTermName;
END
//

/*Function to identify the specific Browser when given a userAgent string with many variable*/
DROP FUNCTION IF EXISTS SMARTSHEET_BROWSERNAME//
CREATE FUNCTION SMARTSHEET_BROWSERNAME(userAgent NVARCHAR(255))
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE browserName VARCHAR(50);
  SET browserName = 
	CASE
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0.1%') THEN "iOS App 1.0.1" /*Consider search logic around CASE and 1.0 vs. 1.0.1 */
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.0%') THEN "iOS App 1.0"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.1%') THEN "iOS App 1.1"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.2%') THEN "iOS App 1.2"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.3%') THEN "iOS App 1.3"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.4%') THEN "iOS App 1.4"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 1.5%') THEN "iOS App 1.5"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 2.0%') THEN "iOS App 2.0"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet 2.1%') THEN "iOS App 2.1"
		WHEN userAgent LIKE ('%Mac OS X%Smartsheet%') THEN "iOS App v?"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.0%') THEN "Android App 1.0"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.1%') THEN "Android App 1.1"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.2%') THEN "Android App 1.2"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.3%') THEN "Android App 1.3"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.4%') THEN "Android App 1.4"
		WHEN userAgent LIKE ('%Android%Smartsheet 1.5%') THEN "Android App 1.5"
		WHEN userAgent LIKE ('%Android%Smartsheet 2.0%') THEN "Android App 2.0"
		WHEN userAgent LIKE ('%Android%Smartsheet%') THEN "Android App v?"			
		WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
		WHEN INSTR(userAgent,'Firefox/10') 	THEN "Firefox 10"
		WHEN INSTR(userAgent,'Firefox/11') 	THEN "Firefox 11"
		WHEN INSTR(userAgent,'Firefox/12') 	THEN "Firefox 12"
		WHEN INSTR(userAgent,'Firefox/13') 	THEN "Firefox 13"
		WHEN INSTR(userAgent,'Firefox/14') 	THEN "Firefox 14"
		WHEN INSTR(userAgent,'Firefox/15') 	THEN "Firefox 15"
		WHEN INSTR(userAgent,'Firefox/16') 	THEN "Firefox 16"
		WHEN INSTR(userAgent,'Firefox/17') 	THEN "Firefox 17"
		WHEN INSTR(userAgent,'Firefox/18') 	THEN "Firefox 18"
		WHEN INSTR(userAgent,'Firefox/19') 	THEN "Firefox 19"
		WHEN INSTR(userAgent,'Firefox/20') 	THEN "Firefox 20"
		WHEN INSTR(userAgent,'Firefox/21') 	THEN "Firefox 21"
		WHEN INSTR(userAgent,'Firefox/22') 	THEN "Firefox 22"
		WHEN INSTR(userAgent,'Firefox/23') 	THEN "Firefox 23"
		WHEN INSTR(userAgent,'Firefox/24') 	THEN "Firefox 24"
		WHEN INSTR(userAgent,'Firefox/25') 	THEN "Firefox 25"
		WHEN INSTR(userAgent,'Firefox/26') 	THEN "Firefox 26"
		WHEN INSTR(userAgent,'Firefox/27') 	THEN "Firefox 27"
		WHEN INSTR(userAgent,'Firefox/28') 	THEN "Firefox 28"
		WHEN INSTR(userAgent,'Firefox/29') 	THEN "Firefox 29"
		WHEN INSTR(userAgent,'Firefox/30') 	THEN "Firefox 30"
		WHEN INSTR(userAgent,'Firefox/31') 	THEN "Firefox 31"
		WHEN INSTR(userAgent,'Firefox/32') 	THEN "Firefox 32"
		WHEN INSTR(userAgent,'Firefox/33') 	THEN "Firefox 33"
		WHEN INSTR(userAgent,'Firefox/34') 	THEN "Firefox 34"
		WHEN INSTR(userAgent,'Firefox/35') 	THEN "Firefox 35"
		WHEN INSTR(userAgent,'Firefox/36') 	THEN "Firefox 36"
		WHEN INSTR(userAgent,'Firefox/37') 	THEN "Firefox 37"
		WHEN INSTR(userAgent,'Firefox/38') 	THEN "Firefox 38"
		WHEN INSTR(userAgent,'Firefox/38') 	THEN "Firefox 39"
		WHEN INSTR(userAgent,'Firefox/1') 	THEN "Firefox 1"
		WHEN INSTR(userAgent,'Firefox/2') 	THEN "Firefox 2"
		WHEN INSTR(userAgent,'Firefox/3') 	THEN "Firefox 3"
		WHEN INSTR(userAgent,'Firefox/4') 	THEN "Firefox 4"
		WHEN INSTR(userAgent,'Firefox/5') 	THEN "Firefox 5"
		WHEN INSTR(userAgent,'Firefox/6') 	THEN "Firefox 6"
		WHEN INSTR(userAgent,'Firefox/7') 	THEN "Firefox 7"
		WHEN INSTR(userAgent,'Firefox/8') 	THEN "Firefox 8"
		WHEN INSTR(userAgent,'Firefox/9') 	THEN "Firefox 9"
		WHEN INSTR(userAgent,'Firefox') 	THEN "Firefox v?"
		WHEN INSTR(userAgent,'MSIE 4.') 	THEN "IE 4"
		WHEN INSTR(userAgent,'MSIE 5.') 	THEN "IE 5"
		WHEN INSTR(userAgent,'MSIE 6.') 	THEN "IE 6"
		WHEN INSTR(userAgent,'MSIE 7.') 	THEN "IE 7"
		WHEN INSTR(userAgent,'MSIE 8.') 	THEN "IE 8"
		WHEN INSTR(userAgent,'MSIE 9.') 	THEN "IE 9"
		WHEN INSTR(userAgent,'MSIE 10.')  THEN "IE 10"
		WHEN userAgent LIKE '%Trident%rv:11%' THEN "IE 11"
		WHEN userAgent LIKE '%Trident%rv:12%' THEN "IE 12"
		WHEN userAgent LIKE '%Trident%rv:13%' THEN "IE 13"
		WHEN userAgent LIKE '%Trident%rv:14%' THEN "IE 14"
		WHEN userAgent LIKE '%Trident%rv:15%' THEN "IE 15"
		WHEN INSTR(userAgent,'Chrome/10') 	THEN "Chrome 10"
		WHEN INSTR(userAgent,'Chrome/11') 	THEN "Chrome 11"
		WHEN INSTR(userAgent,'Chrome/12') 	THEN "Chrome 12"
		WHEN INSTR(userAgent,'Chrome/13') 	THEN "Chrome 13"
		WHEN INSTR(userAgent,'Chrome/14') 	THEN "Chrome 14"
		WHEN INSTR(userAgent,'Chrome/15') 	THEN "Chrome 15"
		WHEN INSTR(userAgent,'Chrome/16') 	THEN "Chrome 16"
		WHEN INSTR(userAgent,'Chrome/17') 	THEN "Chrome 17"
		WHEN INSTR(userAgent,'Chrome/18') 	THEN "Chrome 18"
		WHEN INSTR(userAgent,'Chrome/19') 	THEN "Chrome 19"
		WHEN INSTR(userAgent,'Chrome/20') 	THEN "Chrome 20"
		WHEN INSTR(userAgent,'Chrome/21') 	THEN "Chrome 21"
		WHEN INSTR(userAgent,'Chrome/22') 	THEN "Chrome 22"
		WHEN INSTR(userAgent,'Chrome/23') 	THEN "Chrome 23"
		WHEN INSTR(userAgent,'Chrome/24') 	THEN "Chrome 24"
		WHEN INSTR(userAgent,'Chrome/25') 	THEN "Chrome 25"
		WHEN INSTR(userAgent,'Chrome/26') 	THEN "Chrome 26"
		WHEN INSTR(userAgent,'Chrome/27') 	THEN "Chrome 27"
		WHEN INSTR(userAgent,'Chrome/28') 	THEN "Chrome 28"
		WHEN INSTR(userAgent,'Chrome/29') 	THEN "Chrome 29"
		WHEN INSTR(userAgent,'Chrome/30') 	THEN "Chrome 30"
		WHEN INSTR(userAgent,'Chrome/31') 	THEN "Chrome 31"
		WHEN INSTR(userAgent,'Chrome/32') 	THEN "Chrome 32"
		WHEN INSTR(userAgent,'Chrome/33') 	THEN "Chrome 33"
		WHEN INSTR(userAgent,'Chrome/34') 	THEN "Chrome 34"
		WHEN INSTR(userAgent,'Chrome/35') 	THEN "Chrome 35"
		WHEN INSTR(userAgent,'Chrome/36') 	THEN "Chrome 36"
		WHEN INSTR(userAgent,'Chrome/37') 	THEN "Chrome 37"
		WHEN INSTR(userAgent,'Chrome/38') 	THEN "Chrome 38"
		WHEN INSTR(userAgent,'Chrome/39') 	THEN "Chrome 39"
		WHEN INSTR(userAgent,'Chrome/40') 	THEN "Chrome 40"
		WHEN INSTR(userAgent,'Chrome/41') 	THEN "Chrome 41"
		WHEN INSTR(userAgent,'Chrome/42') 	THEN "Chrome 42"
		WHEN INSTR(userAgent,'Chrome/43') 	THEN "Chrome 43"
		WHEN INSTR(userAgent,'Chrome/44') 	THEN "Chrome 44"
		WHEN INSTR(userAgent,'Chrome/45') 	THEN "Chrome 45"
		WHEN INSTR(userAgent,'Chrome/46') 	THEN "Chrome 46"
		WHEN INSTR(userAgent,'Chrome/1') 	THEN "Chrome 1"  /* needs to be at end so it doesnt match Chrome/10.. */
		WHEN INSTR(userAgent,'Chrome/2') 	THEN "Chrome 2"
		WHEN INSTR(userAgent,'Chrome/3') 	THEN "Chrome 3"
		WHEN INSTR(userAgent,'Chrome/4') 	THEN "Chrome 4"
		WHEN INSTR(userAgent,'Chrome/5') 	THEN "Chrome 5"
		WHEN INSTR(userAgent,'Chrome/6') 	THEN "Chrome 6"
		WHEN INSTR(userAgent,'Chrome/7') 	THEN "Chrome 7"
		WHEN INSTR(userAgent,'Chrome/8') 	THEN "Chrome 8"
		WHEN INSTR(userAgent,'Chrome/9') 	THEN "Chrome 9"
		WHEN INSTR(userAgent,'Chrome') 	THEN "Chrome v?"
		WHEN userAgent LIKE ('%3._ Mobile%Safari%') THEN "Mobile Safari 3" 
		WHEN userAgent LIKE ('%3._._ Mobile%Safari%') THEN "Mobile Safari 3" 
		WHEN userAgent LIKE ('%4._ Mobile%Safari%')  THEN "Mobile Safari 4" 
		WHEN userAgent LIKE ('%4._._ Mobile%Safari%') THEN "Mobile Safari 4" 
		WHEN userAgent LIKE ('%5._ Mobile%Safari%') THEN "Mobile Safari 5" 
		WHEN userAgent LIKE ('%5._._ Mobile%Safari%') THEN "Mobile Safari 5" 
		WHEN userAgent LIKE ('%6._ Mobile%Safari%') THEN "Mobile Safari 6" 
		WHEN userAgent LIKE ('%6.___ Mobile%Safari%') THEN "Mobile Safari 6" 
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 7" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 7" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 8" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 8" 	
		WHEN userAgent LIKE ('%7._ Mobile%Safari%') THEN "Mobile Safari 9" 
		WHEN userAgent LIKE ('%7.___ Mobile%Safari%') THEN "Mobile Safari 9" 	
		WHEN userAgent LIKE ('%Mobile%Safari%') THEN "Mobile Safari v?" 
		WHEN userAgent LIKE ('%3._ Safari%') 	THEN "Safari 3" 
		WHEN userAgent LIKE ('%3._._ Safari%') 	THEN "Safari 3" 
		WHEN userAgent LIKE ('%4._ Safari%') 	THEN "Safari 4" 
		WHEN userAgent LIKE ('%4._._ Safari%') 	THEN "Safari 4" 
		WHEN userAgent LIKE ('%5._ Safari%') 	THEN "Safari 5" 
		WHEN userAgent LIKE ('%5._._ Safari%') 	THEN "Safari 5" 
		WHEN userAgent LIKE ('%6._ Safari%') 	THEN "Safari 6" 
		WHEN userAgent LIKE ('%6._._ Safari%') 	THEN "Safari 6" 
		WHEN userAgent LIKE ('%6._._.____ Safari%') 	THEN "Safari 6" 	
		WHEN userAgent LIKE ('%7._ Safari%') 	THEN "Safari 7" 
		WHEN userAgent LIKE ('%7._._ Safari%') 	THEN "Safari 7" 
		WHEN userAgent LIKE ('%7._._._ Safari%') 	THEN "Safari 7" 
		WHEN userAgent LIKE ('%8._ Safari%') 	THEN "Safari 8" 
		WHEN userAgent LIKE ('%8._._ Safari%') 	THEN "Safari 8" 
		WHEN userAgent LIKE ('%8._._._ Safari%') 	THEN "Safari 8" 
		WHEN userAgent LIKE ('%9._ Safari%') 	THEN "Safari 9" 
		WHEN userAgent LIKE ('%9._._ Safari%') 	THEN "Safari 9" 
		WHEN userAgent LIKE ('%9._._._ Safari%') 	THEN "Safari 9" 
		WHEN INSTR(userAgent,'Safari/7534.48.3') 	THEN "Safari 5"
		WHEN INSTR(userAgent,'Safari/8536.25') 	THEN "Safari 6"
		WHEN userAgent LIKE ('%Safari%') 	THEN "Safari v?" 
		WHEN INSTR(userAgent,'Opera/8') 	THEN "Opera 8"
		WHEN INSTR(userAgent,'Opera 8') 	THEN "Opera 8"
		WHEN INSTR(userAgent,'Opera/9') 	THEN "Opera 9"
		WHEN INSTR(userAgent,'Opera 9') 	THEN "Opera 9"
		WHEN INSTR(userAgent,'Opera/10') 	THEN "Opera 10"
		WHEN INSTR(userAgent,'Opera 10') 	THEN "Opera 10"
		WHEN INSTR(userAgent,'Opera/11') 	THEN "Opera 11"
		WHEN INSTR(userAgent,'Opera 11') 	THEN "Opera 11"
		WHEN INSTR(userAgent,'Opera/12') 	THEN "Opera 12"
		WHEN INSTR(userAgent,'Opera 12') 	THEN "Opera 12"
		WHEN INSTR(userAgent,'Opera') 	THEN "Opera v?"
		WHEN INSTR(userAgent,'Camino') 	THEN "Camino"
		WHEN INSTR(userAgent,'Mobile') THEN "Other Mobile Browser"
		ELSE "Other Browser"
	END;
RETURN browserName;
END
//	

/*Function to identify the general Browser when given a userAgent string with many variables*/
DROP FUNCTION IF EXISTS SMARTSHEET_BROWSERBUCKET//
CREATE FUNCTION SMARTSHEET_BROWSERBUCKET(userAgent NVARCHAR(255))
RETURNS VARCHAR(20) DETERMINISTIC
BEGIN
DECLARE browserBucket VARCHAR(20);
  SET browserBucket = 
 	CASE
		WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
		WHEN INSTR(userAgent,'Firefox') 	THEN "Firefox"
		WHEN INSTR(userAgent,'MSIE') 	THEN "IE"
		WHEN INSTR(userAgent,'Trident') THEN "IE"
		WHEN INSTR(userAgent,'Chrome') 	THEN "Chrome"
		WHEN INSTR(userAgent,'Safari') 	THEN "Safari"
		WHEN INSTR(userAgent,'Opera') 	THEN "Opera"
		WHEN INSTR(userAgent,'Camino') 	THEN "Camino"
		WHEN userAgent LIKE ('%Mac OS%Smartsheet%') THEN "Native iOS App"
		WHEN userAgent LIKE ('%Android%Smartsheet%') THEN "Native Android App"
		ELSE "Other Browser"
	END;
RETURN browserBucket;
END
//

/*Function to identify the OS used when given a userAgent string with many variables*/
DROP FUNCTION IF EXISTS SMARTSHEET_BROWSEROS//
CREATE FUNCTION SMARTSHEET_BROWSEROS(userAgent NVARCHAR(255))
RETURNS VARCHAR(20) DETERMINISTIC
BEGIN
DECLARE browserOS VARCHAR(20);
  SET browserOS = 
	CASE
		WHEN INSTR(userAgent,'sunOS') 		THEN "sunOS"
		WHEN INSTR(userAgent,'FreeBSD') 	THEN "FreeBSD"
		WHEN INSTR(userAgent,'openBSD') 	THEN "openBSD"
		WHEN INSTR(userAgent,'SymbianOS') 	THEN "SymbianOS"
		WHEN INSTR(userAgent,'Symbian') 	THEN "SymbianOS"
		WHEN INSTR(userAgent,'webOS') 		THEN "webOS"
		WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
		WHEN INSTR(userAgent,'Android') 	THEN "Android"
		WHEN INSTR(userAgent,'Linux') 		THEN "Linux"
		WHEN INSTR(userAgent,'Windows CE') 	THEN "Windows CE"
		WHEN INSTR(userAgent,'Windows Phone OS') 	THEN "Windows Phone OS"
		WHEN INSTR(userAgent,'Windows') 	THEN "Windows"
		WHEN INSTR(userAgent,'OS 3') 		THEN "iOS"
		WHEN INSTR(userAgent,'OS 4') 		THEN "iOS"
		WHEN INSTR(userAgent,'OS 5') 		THEN "iOS"
		WHEN INSTR(userAgent,'OS 6') 		THEN "iOS"
		WHEN INSTR(userAgent,'OS 7') 		THEN "iOS"
		WHEN INSTR(userAgent,'OS 8') 		THEN "iOS"
		WHEN INSTR(userAgent,'iPhone OS') 	THEN "iOS"
		WHEN INSTR(userAgent,'iPad') 	THEN "iOS"
		WHEN INSTR(userAgent,'iPhone') 	THEN "iOS"
		WHEN INSTR(userAgent,'iOS') 	THEN "iOS"
		WHEN INSTR(userAgent,'Mac') 		THEN "Mac"
		WHEN INSTR(userAgent,'crOS ') 		THEN "Chrome OS" /* space at end so it doesn't match 'microsoft' */
		ELSE "Other OS"
	END;
RETURN browserOS;
END
//	

/*Function identifying the device used when given a userAgent string with many variables*/
DROP FUNCTION IF EXISTS SMARTSHEET_BROWSERDEVICE//
CREATE FUNCTION SMARTSHEET_BROWSERDEVICE(userAgent NVARCHAR(255))
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE browserDevice VARCHAR(50);
  SET browserDevice = 
	CASE  
		WHEN INSTR(userAgent,'myTouch') 	THEN "myTouch"
		WHEN INSTR(userAgent,'Nexus') 		THEN "Nexus"
		WHEN INSTR(userAgent,'LG') 			THEN "LG"
		WHEN INSTR(userAgent,'SGH') 		THEN "SAMSUNG-SGH"
		WHEN INSTR(userAgent,'APA9292KT') 	THEN "HTC-EVO (APA9292KT)"
		WHEN INSTR(userAgent,'ADR6300') 	THEN "HTC-Incredible (ADR6300)"
		WHEN INSTR(userAgent,'HTC') 		THEN "HTC"
		WHEN INSTR(userAgent,'Treo') 		THEN "Treo"
		WHEN INSTR(userAgent,'Droid2') 		THEN "Droid2"
		WHEN INSTR(userAgent,'DroidX') 		THEN "DroidX"
		WHEN INSTR(userAgent,' Droid') 		THEN "Droid"
		WHEN INSTR(userAgent,'Xoom') 		THEN "Xoom"
		WHEN INSTR(userAgent,'BlackBerry') 	THEN "BlackBerry"
		WHEN INSTR(userAgent,'Nokia') 		THEN "Nokia"
		WHEN INSTR(userAgent,'PlayBook') 	THEN "Playbook"
		WHEN INSTR(userAgent,'iPod') 		THEN "iPod"			/* needs to be before iPhone */
		WHEN INSTR(userAgent,'iPhone') 		THEN "iPhone"
		WHEN INSTR(userAgent,'iPad') 		THEN "iPad"
		WHEN INSTR(userAgent,'Mobile') 		THEN "Mobile Device"
		WHEN INSTR(userAgent,'Mini') 		THEN "Mobile Device"
		WHEN INSTR(userAgent,'Fennec') 		THEN "Mobile Device"
		WHEN INSTR(userAgent,'Android') 	THEN "Mobile Device"
		WHEN INSTR(userAgent,'pixi') 		THEN "pixi"
		ELSE "Computer"
	END;
return browserDevice;
END
//	


/* Extract out query string parameter */
DROP FUNCTION IF EXISTS SMARTSHEET_GET_QUERY_PARAMETER//
CREATE FUNCTION SMARTSHEET_GET_QUERY_PARAMETER(url NVARCHAR(500), parameterName NVARCHAR(50))
RETURNS VARCHAR(500) DETERMINISTIC
BEGIN
DECLARE parameterValue VARCHAR(500);
DECLARE parameterNameLength BIGINT;
DECLARE startPosition BIGINT;
DECLARE endPosition BIGINT;

  SET parameterValue = NULL;
  
  /* parameter could start with ? or  */
  SET startPosition = LOCATE(CONCAT("?", parameterName, "="), url);

  /* or parameter could start with & */
 IF startPosition = 0 THEN
	SET startPosition = LOCATE(CONCAT("&", parameterName, "="), url);
  END IF;
  
  /* found it */
  IF startPosition > 0 THEN
  
	  SET parameterNameLength = LENGTH(parameterName) + 2;  /* +2 for ? or & and then the = */
		
	  SET endPosition = LOCATE("&" , url, startPosition + 1);
	  	
	  IF endPosition > 0 THEN
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength, endPosition - (startPosition + parameterNameLength));
	  ELSE
		SET parameterValue = SUBSTRING(url, startPosition + parameterNameLength);
	  END IF;
  END IF;
  
RETURN parameterValue;
END
//	


/* Lookup the Bucket for any given source */
DROP FUNCTION IF EXISTS SMARTSHEET_GET_BUCKET//
CREATE FUNCTION SMARTSHEET_GET_BUCKET(source NVARCHAR(255))
RETURNS VARCHAR(20) DETERMINISTIC
BEGIN
DECLARE GET_BUCKET VARCHAR(20);
  SET GET_BUCKET = 
 	CASE
		/***** viral bucket *****/
		WHEN source IN ("Sharing", "Referrals", "Application") 	
			THEN "Viral"
			
		/***** other bucket *****/
		WHEN source IN ("Affiliate", "Campaign", "Email Campaigns", "General Awareness", "Free Directory", "SEO", "Social", "Website Links","Blog Posse", "Website")  	
			THEN "Other"		
			
		/***** partner bucket *****/
		WHEN source IN ("Partner", "App Store","Reseller")  	
			THEN "Partner"
			
		/***** paid bucket *****/
		WHEN source IN ("Paid Placement", "PPC - Foreign Language", "PPC - English - International", "PPC","Paid - Social","Paid - Email")
		THEN "Paid"
		ELSE "--unknown bucket--"
	END;
RETURN GET_BUCKET;
END
//	



/* Lookup the source for any given sub-source */
DROP FUNCTION IF EXISTS SMARTSHEET_GET_SOURCE//
CREATE FUNCTION SMARTSHEET_GET_SOURCE(subSource NVARCHAR(255))
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE GET_SOURCE VARCHAR(50);
  SET GET_SOURCE = 
 	CASE
		
		WHEN subSource IN ("Signup with Sharing Tracking Codes", "Signup Inserted by Smartsheet User") 	
			THEN "Sharing"
		WHEN subSource IN ("Web Forms - Powered BY Smartsheet", "Published Sheet - Powered by Smartsheet")  	
			THEN "Application"	
		WHEN subSource IN ("Mail Link", "My Smartsheet Referral", "Referral Rewards")  	
			THEN "Referrals"	
			
		
		WHEN subSource IN ("Amazon Web Services", "AWS Marketplace", "Brad Egeland", "Crowdsourcing.org", "Sitepoint", "Sage Non-Profit", "Office Arrow", "VA Network", "Veronica Conway",
							"Jott", "Success Connections", "smallbiztrends.com", "A Clayton's Secretary", "Officebundle.com", 
							"Caroline Melville Society of Virtual Assistants", "Caroline Melville Virtually Sorted",
							"Baird Consulting", "Biz Recipes", "OnlineBizU", "Assistant Match", "Ki-Work", "Tradeshow Coach", "Regina Minger","Kindle",
							"Stack Overflow", "VANetworking.com")  	
			THEN "Affiliate"		
		WHEN subSource IN ("TJ McCue", "NAPS")  	
			THEN "Campaign"	
		WHEN subSource IN ("Puget Sound PMI", "Solution Center Brochure", "Solution Center")
			Then "General Awareness"
		WHEN subSource IN ("Email")  	
			THEN "Email Campaigns"	
		WHEN subSource IN ("Smartsheet Search", "Smartsheet Search (Not Provided)" , "Organic Search",
							"Branded PPC (Google)", "Branded PPC (Bing)" , 
							"Direct Navigation", "Distributed Container", "SEO", "SEO (Not Provided)", "Integrated Content Pages")  	
			THEN "Website"
		WHEN subSource IN ("Google Templates", "thesmallbusinessweb.com")  	
			THEN "Free Directory"		
		WHEN subSource IN ("YouTube (unpaid)", "Twitter (unpaid)", "Social Media (generic)", "Facebook (unpaid)", "LinkedIn (unpaid)", "Google+ (unpaid)", "Social Media Coordinator - Keri",
		"Slideshare.net", "LinkedIn remarketing platform")  	
			THEN "Social"		
		WHEN subSource IN ("External Source Links")  	
			THEN "Website Links"	
		
		WHEN subSource IN ("Apple App Store", "Android App Store", "Google Play Store")  	
			THEN "App Store"	
		WHEN subSource IN ( "Elizabeth Harrin (blog posse)", "Robert Kelly (blog posse)", "Lindsay Scott (blog posse)")  	
			THEN "Blog Posse"	
		
		WHEN subSource IN ("Google App. Marketplace", "Chrome Web Store", "Intuit", "Zimbra", "Salesforce.com", "Box", "Cloud Alliance for Google Apps", 
							"Centrify", "Google Drive - New File", "Google Drive - Import","Zapier","Dropbox","123 Contact Form","Marketo Launchpoint","Docusign",
							"MailChimp","Harvest","Evernote","Amazon Mechanical Turk","AppGuru","Backupify","Bitium","Easy Insight",
							"OneLogin","PingOne","Klipfolio","Tools4ever","Okta","Third Party Authorization Flow","BetterCloud",
							"Smartsheet Merge (Google Docs Add-on)","Smartsheet Forms (Google Forms Add-on)","Microsoft",
							"Microsoft Office 365/Azure Marketplace","Google general","Microsoft Office Store", "Box", "Microsoft Referral", "Microsoft Referral 0365 Launcher",
							"Evernote Integration","OutlookApp Integration", "School of Bookkeeping","Microsoft Teams signup","Project Vision Dynamics USA",
                            "SoftwareONE Chile", "SoftwareONE Brazil", "SoftwareONE Argentina", "eSource Mexico", "Comparex Germany", "Searce India", 
                            "Softline Malaysia", "Softline Thailand", "Softline Vietnam", "Softline Korea", "SoftwareONE USA", "Mbizer Singapore", "Six Step Australia", 
                            "Cardinal Consulting Australia", "SoftwareONE Uruguay", "SoftwareOne UK", "SoftwareOne France", "SoftwareONE Japan"
					)  	
			THEN "Partner"
		WHEN subSource IN ("Cloud Sherpa","gPartner","Business Cloud","Ciruseo","Softline India","Cyberco Procore Connector") 
			THEN "Reseller"
		
		
		WHEN subSource IN ("Serchen", "The Deck", "PM Sherpa", "GetApp.com", "Geekwire", "USA Today", "Pac NW Soccer","Spiceworks",
		 "Wave", "Capterra", "FindtheBest Paid", "Project-Management.com", "Projects At Work")
			THEN "Paid Placement"
			
		WHEN subSource IN ( "Spanish - Google Search Test", "Spanish - Google Display Network Test",
							"Spanish (US) - Google Display", "Spanish (US) - Google Search",
							"Spanish (Mexico) - Google Display", "Spanish (Mexico) - Google Search",
							"Spanish (Spain) - Google Display", "Spanish (Spain) - Google Search",
							"Spanish (Other) - Google Display", "Spanish (Other) - Google Search",
							"Spanish (Argentina)  Google Display", "Spanish (Argentina)  Google Search",
							"Spanish (Peru)  Google Display", "Spanish (Peru)  Google Search",
							"Spanish (Venezuela)  Google Display", "Spanish (Venezuela)  Google Search",
							"Spanish (Chile)  Google Display", "Spanish (Chile)  Google Search",
							"Spanish (Guatemala)  Google Display", "Spanish (Guatemala)  Google Search",
							"Spanish (Ecuador)  Google Display", "Spanish (Ecuador)  Google Search",
							
							"French (Tier 1) - Google Display", "French (Tier 1) - Google Search",
							"French (Tier 2) - Google Display", "French (Tier 2) - Google Search",
							
							"Portuguese (Brazil) - Google Display", "Portuguese (Brazil) - Google Search",
							"Portuguese (Portugal) - Google Display", "Portuguese (Portugal) - Google Search",
											
							"German - Google Display", "German - Google Search",
							
							"Italian - Google Display", "Italian - Google Search",
							"Bing Search - French",
							"Bing Search - German",
							"Bing Search - Portuguese (Brazil)",
							"Bing Search - Portuguese (Portugal)",
							"Bing Search - Spanish",
							"Bing Search - Italian",
							"Google Search - Russian",
							"Yandex (paid)",
							"Google Search - Japanese",				 
							"Yahoo Japan",
							"French - Display - Interest Targeted",
							"Japanese - Display - Interest Targeted",
							"Google Display Japan",
							"Russian - Display - Interest Targeted",
							"Russian - Display",
							"German - Display - Interest Targeted",
							"Italian - Display - Interest Targeted",
							"Portuguese (Brazil) - Display - Interest Targeted",
							"Portuguese (Portugal) - Display - Interest Targeted",
							"Spanish - Display - Interest Targeted")
			THEN "PPC - Foreign Language"
			
		WHEN subSource IN ( "Bing Search (Canada)", "Bing Search (Singapore)", "Bing Search (UK)",
		
							"South Africa - Google Display", "South Africa - Google Search", 
							"Israel - Google Display", "Israel - Google Search",
							"Saudi Arabia - Google Display", "Saudi Arabia - Google Search",
				
							"Belgium - Google Display", "Belgium - Google Search",
							"Finland - Google Display", "Finland - Google Search",
							"Denmark - Google Display", "Denmark - Google Search",
							"Netherlands - Google Display", "Netherlands - Google Search",
							"Norway - Google Display", "Norway - Google Search",
							"Sweden - Google Display", "Sweden - Google Search",
							"Germany - Google Display", "Germany - Google Search",
							"France - Google Display", "France - Google Search", 
							"Spain - Google Display", "Spain - Google Search",
							"Italy - Google Display", "Italy - Google Search",
							
							"Turkey - Google Display", "Turkey - Google Search",
							"Russia - Google Display", "Russia - Google Search",
							
							"Hong Kong - Google Display", "Hong Kong - Google Search",
							"Singapore - Google Display", "Singapore - Google Search",
							"Japan - Google Display", "Japan - Google Search",
							"South Korea - Google Display", "South Korea - Google Search",
							"China - Google Display", "China - Google Search",
							
							"Mexico - Google Display", "Mexico - Google Search",
							
							"Brazil - Google Display", "Brazil - Google Search",
							"Columbia - Google Display", "Columbia - Google Search",
							"Argentina - Google Display", "Argentina - Google Search",
							
							"India - Google Display", "India - Google Search",
							"Indonesia - Google Display", "Indonesia - Google Search",
							"Malaysia - Google Display", "Malaysia - Google Search",
							"Philippines - Google Display", "Philippines - Google Search",
							
							"_Display - Managed Placements - Tier 1 International", "_Display - Managed Placements - Tier 2 International",
							"_Google Search - International - Tier 1", "_Google Search - International - Tier 2",
							"Google Display International - Text Ads", "Google Display International - Image Ads",
							"Bing Search - International - Tier 1",
							"Google Search Companion Marketing (International)",
							"Yahoo Search INT",
                            "YouTube Promoted Videos (INT)",
                            "Google Display - In-Market Audience (INT)")
			THEN "PPC - English - International"
			
		WHEN subSource IN ( 
				"_Google Search", 
				"_Google Display Network",	
				 "Yahoo",
				 "Ask.com",
				 "_Google Search",
				 "Go2Web20.net",
				"_Bing Search",
				"_Bing Content Network",
				"Ad Ready Network",
				"Facebook",
				"LinkedIn",
				"LinkedIn InMail",
				"LinkedIn International (paid)",
				"_Google Display (iPad only)",
				"_Google Search (iPad only)",									
				"Google Remarketing (Paid Visitors)", "Google Remarketing (Non-paid Visitors)", "Google Remarketing (Nurture Signups)",			
				"Bing Search (French - Canada)", "Bing Search (French - France)",
				"Youtube (promoted videos)",
				"_Display - Managed Placements",
				"Google Adwords Sitelinks",
				"Google Mobile Search (iphone)", "Google Mobile Search (non-iphone)",
				"Enterprise Display Test - Spreadsheet Hell - Desktop", "Enterprise Display Test - Spreadsheet Hell - Mobile",
				"BlueKai - (Google)", "Similar Audiences - (Google)",
				"Gmail Ads",
				"Gmail Ads - International",
				"Google Display - Interest Targeted",
				"Video for Adwords",
 				"Google Business Category Display",
 				"Seattle GEO Target (Google Search)",
				"Seattle GEO Target (Bing Search)",
				"Seattle GEO Target (Google Display Image)",
				"Seattle GEO Target (Bing Content)",
				"Seattle GEO Target (Google Text Display)",
				"Google Display - Image Ads",
				"Google Display - Text Ads",
				"Google Search Companion Marketing",
				"Similar Audiences (Google) - International",
				"Google Display - Interest Targeted (International)",
				"Bing Display - Text Ads (USA)",
				"Bing Display - Text Ads (English Not USA)",
				"Bing Sitelinks",
				"Display - Select Keyword",
				"Display - Select Keyword (International)",
				"Yahoo Display - Native Ads",
				"GetApp Paid",
				"Yahoo Search",
				"DoubleClick Campaign Manager",
				"DoubleClick Interest Targeted",
				"DoubleClick Context Matched",
				"DoubleClick Manual Placement",
                "Google Display - In-Market Audience",
                "StackOverflow",
                "Instagram(Paid)",
                "Techcrunch",
                "G2 Crowd (paid)",
                "Google Product Listing Ads"
				 )
		THEN "PPC"
		WHEN subsource IN ("Twitter (paid)","Facebook (paid) - International EN") THEN "Paid - Social"
		WHEN subsource IN ("DemandMetric.com","ProjectManagers.net","ProjectsAtWork.com","ProjectManagement.com") THEN "Paid - Email"
		ELSE "--unknown source--"
	END;
RETURN GET_SOURCE;
END
//	


/*Function to return full weeks from MySQL defined weeks.  Will need to be updated in 2017/18*/
--DROP FUNCTION IF EXISTS SMARTSHEET_WEEK//
--CREATE FUNCTION SMARTSHEET_WEEK(startDateTime DATETIME)
--RETURNS VARCHAR(20) DETERMINISTIC
--BEGIN
--DECLARE weekFriendly VARCHAR(20);
--SET weekFriendly = 
--  CASE DATE_FORMAT(startDateTime, '%Y') 
--	WHEN 2012 THEN 
--		CASE DATE_FORMAT(startDateTime, '%U')
--			WHEN 53 THEN CONCAT(DATE_FORMAT(startDateTime, '%Y'), '*53-0')
--			ELSE DATE_FORMAT(startDateTime, '%Y*%U') 
--		END
--	WHEN 2013 THEN 
--		CASE DATE_FORMAT(startDateTime, '%U')
--			WHEN 0 THEN CONCAT((DATE_FORMAT(startDateTime, '%Y') -1), '*53-0')
--			ELSE DATE_FORMAT(startDateTime, '%Y*%U') 
--		END 
--	ELSE 
--		CASE DATE_FORMAT(startDateTime, '%U')
--			WHEN 52 THEN CONCAT(DATE_FORMAT(startDateTime, '%Y'), '*52-0')
--			WHEN 0 THEN CONCAT((DATE_FORMAT(startDateTime, '%Y') -1), '*52-0')
--			ELSE DATE_FORMAT(startDateTime, '%Y*%U') 
--		END
--	END;
--RETURN weekFriendly;
--END
--//
DROP FUNCTION IF EXISTS SMARTSHEET_WEEK//
CREATE FUNCTION SMARTSHEET_WEEK(startDateTime DATETIME)
RETURNS VARCHAR(20) DETERMINISTIC
BEGIN
DECLARE weekFriendly VARCHAR(20);
SET weekFriendly = 
  CONCAT(YEAR(startDateTime),"*" , 
	CASE WHEN WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) < 10 THEN CONCAT("0", WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3)) 
	ELSE WEEK(DATE_ADD(startDateTime,INTERVAL +1 DAY),3) END);
RETURN weekFriendly;
END
//

/*Function to produce Country Name when given CountryCode*/
DROP FUNCTION IF EXISTS SMARTSHEET_COUNTRYNAME//
CREATE FUNCTION SMARTSHEET_COUNTRYNAME(countryCode VARCHAR(25))
RETURNS VARCHAR(50) DETERMINISTIC
BEGIN
DECLARE countryName VARCHAR(50);
SET countryName = 
  CASE countryCode
	WHEN 'AF' THEN 'Afghanistan'
	WHEN 'Afghanistan' THEN 'Afghanistan'
	WHEN 'AX' THEN 'Aland Islands'
	WHEN 'AL' THEN 'Albania'
	WHEN 'DZ' THEN 'Algeria'
	WHEN 'AS' THEN 'American Samoa'
	WHEN 'AD' THEN 'Andorra'
	WHEN 'AO' THEN 'Angola'
	WHEN 'AI' THEN 'Anguilla'
	WHEN 'AQ' THEN 'Antarctica'
	WHEN 'AG' THEN 'Antigua and Barbuda'
	WHEN 'AR' THEN 'Argentina'
	WHEN 'AM' THEN 'Armenia'
	WHEN 'AW' THEN 'Aruba'
	WHEN 'AU' THEN 'Australia'
	WHEN 'AUST' THEN 'Australia'
	WHEN 'AUSTRALIA' THEN 'Australia'
	WHEN 'AT' THEN 'Austria'
	WHEN 'Osterreich' THEN 'Austria'
	WHEN 'AZ' THEN 'Azerbaidjan'
	WHEN 'BS' THEN 'Bahamas'
	WHEN 'BH' THEN 'Bahrain'
	WHEN 'BD' THEN 'Bangladesh'
	WHEN 'BB' THEN 'Barbados'
	WHEN 'BY' THEN 'Belarus'
	WHEN 'BE' THEN 'Belgium'
	WHEN 'Belgium' THEN 'Belgium'
	WHEN 'BZ' THEN 'Belize'
	WHEN 'BJ' THEN 'Benin'
	WHEN 'BM' THEN 'Bermuda'
	WHEN 'BT' THEN 'Bhutan'
	WHEN 'BO' THEN 'Bolivia'
	WHEN 'BQ' THEN 'Bonaire'
	WHEN 'BA' THEN 'Bosnia-Herzegovina'
	WHEN 'BW' THEN 'Botswana'
	WHEN 'Botswana' THEN 'Botswana'
	WHEN 'BV' THEN 'Bouvet Island'
	WHEN 'BR' THEN 'Brazil'
	WHEN 'Brasil' THEN 'Brazil'
	WHEN 'Brazil' THEN 'Brazil'
	WHEN 'IO' THEN 'British Indian Ocean Territory'
	WHEN 'BN' THEN 'Brunei Darussalam'
	WHEN 'BG' THEN 'Bulgaria'
	WHEN 'Bulgaria' THEN 'Bulgaria'
	WHEN 'BF' THEN 'Burkina Faso'
	WHEN 'BI' THEN 'Burundi'
	WHEN 'KH' THEN 'Cambodia'
	WHEN 'CM' THEN 'Cameroon'
	WHEN 'CA' THEN 'Canada'
	WHEN 'Canada' THEN 'Canada'
	WHEN 'Newfoundland' THEN 'Canada'
	WHEN 'CV' THEN 'Cape Verde'
	WHEN 'KY' THEN 'Cayman Islands'
	WHEN 'Cayman Islands' THEN 'Cayman Islands'
	WHEN 'CF' THEN 'Central African Republic'
	WHEN 'TD' THEN 'Chad'
	WHEN 'CL' THEN 'Chile'
	WHEN 'Chile' THEN 'Chile'
	WHEN 'CN' THEN 'China'
	WHEN 'China' THEN 'China'
	WHEN 'CX' THEN 'Christmas Island'
	WHEN 'CC' THEN 'Cocos Islands'
	WHEN 'CO' THEN 'Colombia'
	WHEN 'Colombia' THEN 'Colombia'
	WHEN 'KM' THEN 'Comoros'
	WHEN 'CD' THEN 'Congo'
	WHEN 'CG' THEN 'Congo'
	WHEN 'CK' THEN 'Cook Islands'
	WHEN 'CR' THEN 'Costa Rica'
	WHEN 'Costa Rica' THEN 'Costa Rica'
	WHEN 'CI' THEN "Cote D'Ivoire"
	WHEN 'HR' THEN 'Croatia'
	WHEN 'CU' THEN 'Cuba'
	WHEN 'CW' THEN 'Curacao'
	WHEN 'CY' THEN 'Cyprus'
	WHEN 'CZ' THEN 'Czech Republic'
	WHEN 'Czech Republic' THEN 'Czech Republic'
	WHEN 'DK' THEN 'Denmark'
	WHEN 'Denmark' THEN 'Denmark'
	WHEN 'DJ' THEN 'Djibouti'
	WHEN 'DM' THEN 'Dominica'
	WHEN 'DO' THEN 'Dominican Republic'
	WHEN 'Republica Dominicana' THEN 'Dominican Republic'
	WHEN 'EC' THEN 'Ecuador'
	WHEN 'Ecuador' THEN 'Ecuador'
	WHEN 'EG' THEN 'Egypt'
	WHEN 'SV' THEN 'El Salvador'
	WHEN 'GQ' THEN 'Equatorial Guinea'
	WHEN 'ER' THEN 'Eritrea'
	WHEN 'EE' THEN 'Estonia'
	WHEN 'Estonia' THEN 'Estonia'
	WHEN 'ET' THEN 'Ethiopia'
	WHEN 'FK' THEN 'Falkland Islands'
	WHEN 'FO' THEN 'Faroe Islands'
	WHEN 'FJ' THEN 'Fiji'
	WHEN 'Fiji' THEN 'Fiji'
	WHEN 'FI' THEN 'Finland'
	WHEN 'FR' THEN 'France'
	WHEN 'FRANCE' THEN 'France'
	WHEN 'GF' THEN 'French Guyana'
	WHEN 'PF' THEN 'French Polynesia'
	WHEN 'TF' THEN 'French Southern Territories'
	WHEN 'GA' THEN 'Gabon'
	WHEN 'GM' THEN 'Gambia'
	WHEN 'GE' THEN 'Georgia'
	WHEN 'DE' THEN 'Germany'
	WHEN 'Deutschland' THEN 'Germany'
	WHEN 'Germany' THEN 'Germany'
	WHEN 'GH' THEN 'Ghana'
	WHEN 'GI' THEN 'Gibraltar'
	WHEN 'GR' THEN 'Greece'
	WHEN 'GREECE' THEN 'Greece'
	WHEN 'GL' THEN 'Greenland'
	WHEN 'GD' THEN 'Grenada'
	WHEN 'GP' THEN 'Guadeloupe'
	WHEN 'GU' THEN 'Guam'
	WHEN 'GT' THEN 'Guatemala'
	WHEN 'GUATEMALA' THEN 'Guatemala'
	WHEN 'GG' THEN 'Guernsey'
	WHEN 'GN' THEN 'Guinea'
	WHEN 'GW' THEN 'Guinea-Bissau'
	WHEN 'GY' THEN 'Guyana'
	WHEN 'HT' THEN 'Haiti'
	WHEN 'HM' THEN 'Heard and McDonald Islands'
	WHEN 'HN' THEN 'Honduras'
	WHEN 'HK' THEN 'Hong Kong'
	WHEN 'HU' THEN 'Hungary'
	WHEN 'Hungary' THEN 'Hungary'
	WHEN 'IS' THEN 'Iceland'
	WHEN 'IN' THEN 'India'
	WHEN 'India' THEN 'India'
	WHEN 'ID' THEN 'Indonesia'
	WHEN 'INDONESIA' THEN 'Indonesia'
	WHEN 'IR' THEN 'Iran'
	WHEN 'IQ' THEN 'Iraq'
	WHEN 'IE' THEN 'Ireland'
	WHEN 'Ireland' THEN 'Ireland'
	WHEN 'IM' THEN 'Isle of Man'
	WHEN 'IL' THEN 'Israel'
	WHEN 'Israel' THEN 'Israel'
	WHEN 'IT' THEN 'Italy'
	WHEN 'Italia' THEN 'Italy'
	WHEN 'ITALY' THEN 'Italy'
	WHEN 'JM' THEN 'Jamaica'
	WHEN 'JP' THEN 'Japan'
	WHEN 'Japan' THEN 'Japan'
	WHEN 'JE' THEN 'Jersey'
	WHEN 'JO' THEN 'Jordan'
	WHEN 'KZ' THEN 'Kazakhstan'
	WHEN 'KE' THEN 'Kenya'
	WHEN 'KI' THEN 'Kiribati'
	WHEN 'KP' THEN 'Korea'
	WHEN 'KW' THEN 'Kuwait'
	WHEN 'KG' THEN 'Kyrgyzstan'
	WHEN 'LA' THEN 'Laos'
	WHEN 'LV' THEN 'Latvia'
	WHEN 'Latvia' THEN 'Latvia'
	WHEN 'LB' THEN 'Lebanon'
	WHEN 'Lebanon' THEN 'Lebanon'
	WHEN 'LS' THEN 'Lesotho'
	WHEN 'LR' THEN 'Liberia'
	WHEN 'LY' THEN 'Libya'
	WHEN 'Libya' THEN 'Libyan Arab Jamahiriya'
	WHEN 'LI' THEN 'Liechtenstein'
	WHEN 'LT' THEN 'Lithuania'
	WHEN 'Lithuania' THEN 'Lithuania'
	WHEN 'LU' THEN 'Luxembourg'
	WHEN 'MO' THEN 'Macau'
	WHEN 'MK' THEN 'Macedonia'
	WHEN 'MG' THEN 'Madagascar'
	WHEN 'MW' THEN 'Malawi'
	WHEN 'MY' THEN 'Malaysia'
	WHEN 'Malaysia' THEN 'Malaysia'
	WHEN 'MV' THEN 'Maldives'
	WHEN 'ML' THEN 'Mali'
	WHEN 'MT' THEN 'Malta'
	WHEN 'MH' THEN 'Marshall Islands'
	WHEN 'MQ' THEN 'Martinique'
	WHEN 'MR' THEN 'Mauritania'
	WHEN 'MU' THEN 'Mauritius'
	WHEN 'YT' THEN 'Mayotte'
	WHEN 'MX' THEN 'Mexico'
	WHEN '77710' THEN 'Mexico'
	WHEN 'Mexico' THEN 'Mexico'
	WHEN 'Mexico D.F (Mexico)' THEN 'Mexico'
	WHEN 'FM' THEN 'Micronesia'
	WHEN 'MD' THEN 'Moldavia'
	WHEN 'MC' THEN 'Monaco'
	WHEN 'MN' THEN 'Mongolia'
	WHEN 'ME' THEN 'Montenegro'
	WHEN 'MS' THEN 'Montserrat'
	WHEN 'MA' THEN 'Morocco'
	WHEN 'Morocco' THEN 'Morocco'
	WHEN 'MZ' THEN 'Mozambique'
	WHEN 'MM' THEN 'Myanmar'
	WHEN 'NA' THEN 'Namibia'
	WHEN 'NR' THEN 'Nauru'
	WHEN 'NP' THEN 'Nepal'
	WHEN 'NL' THEN 'Netherlands'
	WHEN 'Netherlands' THEN 'Netherlands'
	WHEN 'The Netherlands' THEN 'Netherlands'
	WHEN 'NC' THEN 'New Caledonia'
	WHEN 'NZ' THEN 'New Zealand'
	WHEN 'New Zealand' THEN 'New Zealand'
	WHEN 'NI' THEN 'Nicaragua'
	WHEN 'NE' THEN 'Niger'
	WHEN 'NG' THEN 'Nigeria'
	WHEN 'NU' THEN 'Niue'
	WHEN 'NF' THEN 'Norfolk Island'
	WHEN 'MP' THEN 'Northern Mariana Islands'
	WHEN 'NO' THEN 'Norway'
	WHEN 'Norway' THEN 'Norway'
	WHEN 'OM' THEN 'Oman'
	WHEN 'ZZ' THEN 'Other'
	WHEN 'PK' THEN 'Pakistan'
	WHEN 'PW' THEN 'Palau'
	WHEN 'PS' THEN 'Palestine'
	WHEN 'PA' THEN 'Panama'
	WHEN 'Panama' THEN 'Panama'
	WHEN 'PG' THEN 'Papua New Guinea'
	WHEN 'PY' THEN 'Paraguay'
	WHEN 'Paraguay' THEN 'Paraguay'
	WHEN 'PE' THEN 'Peru'
	WHEN 'Peru' THEN 'Peru'
	WHEN 'PH' THEN 'Philippines'
	WHEN 'PN' THEN 'Pitcairn Islands'
	WHEN 'PL' THEN 'Poland'
	WHEN 'Capgemini' THEN 'Poland'
	WHEN 'Krakow' THEN 'Poland'
	WHEN 'Poland' THEN 'Poland'
	WHEN 'Polska' THEN 'Poland'
	WHEN 'PT' THEN 'Portugal'
	WHEN 'Portugal' THEN 'Portugal'
	WHEN 'PR' THEN 'Puerto Rico'
	WHEN 'QA' THEN 'Qatar'
	WHEN 'RE' THEN 'Reunion'
	WHEN 'RO' THEN 'Romania'
	WHEN 'Romania' THEN 'Romania'
	WHEN 'RU' THEN 'Russia'
	WHEN 'Russia' THEN 'Russia'
	WHEN 'Russian Federation' THEN 'Russia'
	WHEN 'RW' THEN 'Rwanda'
	WHEN 'BL' THEN 'Saint Barthelemy'
	WHEN 'SH' THEN 'Saint Helena'
	WHEN 'KN' THEN 'Saint Kitts and Nevis Anguilla'
	WHEN 'LC' THEN 'Saint Lucia'
	WHEN 'MF' THEN 'Saint Martin'
	WHEN 'SX' THEN 'Saint Martin'
	WHEN 'VC' THEN 'Saint Vincent and Grenadines'
	WHEN 'WS' THEN 'Samoa'
	WHEN 'SM' THEN 'San Marino'
	WHEN 'ST' THEN 'Sao Tome and Principe'
	WHEN 'SA' THEN 'Saudi Arabia'
	WHEN 'SN' THEN 'Senegal'
	WHEN 'RS' THEN 'Serbia'
	WHEN 'SC' THEN 'Seychelles'
	WHEN 'SL' THEN 'Sierra Leone'
	WHEN 'SG' THEN 'Singapore'
	WHEN 'SK' THEN 'Slovakia'
	WHEN 'Slovakia' THEN 'Slovakia'
	WHEN 'SI' THEN 'Slovenia'
	WHEN 'Slovenia' THEN 'Slovenia'
	WHEN 'SB' THEN 'Solomon Islands'
	WHEN 'SO' THEN 'Somalia'
	WHEN 'ZA' THEN 'South Africa'
	WHEN 'RSA' THEN 'South Africa'
	WHEN 'South Africa' THEN 'South Africa'
	WHEN 'GS' THEN 'South Georgia and the South Sandwich Islands'
	WHEN 'KR' THEN 'South Korea'
	WHEN 'SS' THEN 'South Sudan'
	WHEN 'ES' THEN 'Spain'
	WHEN 'Espana' THEN 'Spain'
	WHEN 'Spain' THEN 'Spain'
	WHEN 'LK' THEN 'Sri Lanka'
	WHEN 'PM' THEN 'St. Pierre and Miquelon'
	WHEN 'SD' THEN 'Sudan'
	WHEN 'SR' THEN 'Suriname'
	WHEN 'SJ' THEN 'Svalbard and Jan Mayen Islands'
	WHEN 'SZ' THEN 'Swaziland'
	WHEN 'SE' THEN 'Sweden'
	WHEN 'Sweden' THEN 'Sweden'
	WHEN 'CH' THEN 'Switzerland'
	WHEN 'Switzerland' THEN 'Switzerland'
	WHEN 'SY' THEN 'Syrian Arab Republic'
	WHEN 'TW' THEN 'Taiwan'
	WHEN 'Taiwan' THEN 'Taiwan'
	WHEN 'TJ' THEN 'Tajikistan'
	WHEN 'TZ' THEN 'Tanzania'
	WHEN 'Tanzania' THEN 'Tanzania'
	WHEN 'TH' THEN 'Thailand'
	WHEN 'Thailand' THEN 'Thailand'
	WHEN 'TL' THEN 'Timor-Leste'
	WHEN 'TG' THEN 'Togo'
	WHEN 'TK' THEN 'Tokelau'
	WHEN 'TO' THEN 'Tonga'
	WHEN 'TT' THEN 'Trinidad and Tobago'
	WHEN 'TN' THEN 'Tunisia'
	WHEN 'TR' THEN 'Turkey'
	WHEN 'Turkey' THEN 'Turkey'
	WHEN 'TM' THEN 'Turkmenistan'
	WHEN 'TC' THEN 'Turks and Caicos Islands'
	WHEN 'TV' THEN 'Tuvalu'
	WHEN 'UG' THEN 'Uganda'
	WHEN 'UA' THEN 'Ukraine'
	WHEN 'AE' THEN 'United Arab Emirates'
	WHEN 'UAE' THEN 'United Arab Emirates'
	WHEN 'GB' THEN 'United Kingdom'
	WHEN 'England' THEN 'United Kingdom'
	WHEN 'United Kingdom' THEN 'United Kingdom'
	WHEN 'UK' THEN 'United Kingdom'
	WHEN 'US' THEN 'United States'
	WHEN 'United States' THEN 'United States'
	WHEN 'United States of America' THEN 'United States'
	WHEN 'USA' THEN 'United States'
	WHEN 'UM' THEN 'United States Minor Outlying Islands'
	WHEN 'UY' THEN 'Uruguay'
	WHEN 'Uruguay' THEN 'Uruguay'
	WHEN 'UZ' THEN 'Uzbekistan'
	WHEN 'VU' THEN 'Vanuatu'
	WHEN 'VA' THEN 'Vatican City'
	WHEN 'VE' THEN 'Venezuela'
	WHEN 'VN' THEN 'Vietnam'
	WHEN 'VG' THEN 'Virgin Islands'
	WHEN 'VI' THEN 'Virgin Islands'
	WHEN 'WF' THEN 'Wallis and Futuna'
	WHEN 'EH' THEN 'Western Sahara'
	WHEN 'YE' THEN 'Yemen'
	WHEN 'ZM' THEN 'Zambia'
	WHEN 'ZW' THEN 'Zimbabwe'
     ELSE CONCAT('Country ', countryCode)
  END;
RETURN countryName;
END
//



/* Create procedure to optimize rpt_main_02 tables - refresh stats */
CREATE PROCEDURE SMARTSHEET_TABLE_OPTIMIZER()
BEGIN

DECLARE done INT DEFAULT 0;


DECLARE maxClientEventID BIGINT;
DECLARE TableName VARCHAR(200);

DECLARE cur1 CURSOR FOR 
SELECT DISTINCT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'rpt_main_02'
-- AND TABLE_NAME IN ('workItemGroup','reminder')
ORDER BY TABLE_NAME
;


DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

OPEN cur1;



read_loop: LOOP
	FETCH cur1 INTO TableName;
	IF done THEN
	LEAVE read_loop;
END IF;




SELECT TableName;
SET @table_name = TableName;
SET @sql_text = CONCAT('OPTIMIZE TABLE ',@table_name);
PREPARE stmt1 FROM @sql_text;
-- OPTIMIZE TABLE TableName;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;




END LOOP;

CLOSE cur1;

END
//
 
delimiter ;
