# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_organizationUser table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_organizationUser()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_organizationUser//

create procedure etl_rpt_organizationUser(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
                              ,a_newMaxOrganizationUserRoleId int)
begin

# Variable Declaration

declare v_processId int;
call utl_logProcessStart('etl_rpt_organizationUser',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

DROP TABLE IF EXISTS rpt_organizationUser;
CREATE TABLE IF NOT EXISTS rpt_organizationUser(
	userID BIGINT,  
	paymentAdminCount SMALLINT,  
	userAdminCount SMALLINT,  
	dataAdminCount SMALLINT,  
	licenseUserCount SMALLINT,  
	memberCount SMALLINT, 
	resourceManagerCount SMALLINT,
	PRIMARY KEY(userID))
;

/******* Insert all userIds from organizationUserRole - start *******/
INSERT rpt_organizationUser (userID)
	SELECT userID
	FROM ss_core_02.organizationUserRole
	WHERE state = 1 and organizationUserRoleID <= a_newMaxOrganizationUserRoleId
	GROUP BY 1
;

UPDATE rpt_organizationUser rou
SET rou.paymentAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'PAYMENT_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;

/******* Update userAdminCount  on each record *******/
UPDATE rpt_organizationUser rou
SET rou.userAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'USER_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;
	
/******* Update dataAdminCount  on each record *******/
UPDATE rpt_organizationUser rou
SET rou.dataAdminCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'DATA_ADMIN' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;
	
/******* Update licenseUserCount  on each record *******/
UPDATE rpt_organizationUser rou
SET rou.licenseUserCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'LICENSE_USER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;
	
/******* Update memberCount  on each record *******/
UPDATE rpt_organizationUser rou
SET rou.memberCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'MEMBER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;

/******* Update memberCount  on each record *******/
UPDATE rpt_organizationUser rou
SET rou.resourceManagerCount = 
	(SELECT COUNT(*) 
	FROM ss_core_02.organizationUserRole our 
	WHERE our.userID = rou.userID 
	AND our.role = 'RESOURCE_MANAGER' 
	AND our.state = 1
	AND our.organizationUserRoleID <= a_newMaxOrganizationUserRoleId)
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;