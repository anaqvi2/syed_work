# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the histUserAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.



#REPLACE NOT AN OPTION AS THERE'S NO PK ON HIST_USERACCOUNT;
#NOT IN PRODUCTION AS OF 3/7/14

select '### Compiling procedure etl_histUserAccount()' as '' from dual;

delimiter //

drop procedure if exists etl_histUserAccount//

create procedure etl_histUserAccount(a_sourceMaxUserId int
									,a_parentProcessId int
								    ,a_levelCtrlNum tinyint)
begin

# Use this variable to determine the rows we haven't moved from the source table yet.
declare v_destMaxUserId int default (select max(userId) from hist_userAccount);
declare v_destMaxModTime dateTime default (select max(modifyDateTime) from hist_userAccount where userId = v_destMaxUserId);
declare v_processId int;
call utl_logProcessStart('etl_histUserAccount',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);


select count(*)
from
   (select *
    from ss_core_02.hist_userAccount
    where (modifyDateTime > v_destMaxModTime
       or userId > v_destMaxUserId
           )
	   and userId < a_sourceMaxUserId
   ) hua
left outer join ref_localeCountryLanguage rlcl
    on hua.locale = rlcl.localeCode;

replace into hist_userAccount(
    hist_userAccount.userID,
    hist_userAccount.firstName,
    hist_userAccount.lastName,
    hist_userAccount.nickName,
    hist_userAccount.accountType,
    hist_userAccount.emailAddress,
    hist_userAccount.loginPassword,
    hist_userAccount.locale,
    hist_userAccount.timeZone,
    hist_userAccount.newsFlags,
    hist_userAccount.statusFlags,
    hist_userAccount.insertByUserID,
    hist_userAccount.insertDateTime,
    hist_userAccount.modifyByUserID,
    hist_userAccount.modifyDateTime,
    hist_userAccount.sessionLogID,
	hist_userAccount.hist_effectiveThruDateTime,
	hist_userAccount.localeFriendly,
	hist_userAccount.languageFriendly,
	hist_userAccount.countryFriendly,
	hist_userAccount.domain
)
select hua.*
      ,localeName
      ,languageName
	  ,countryName
	  ,substr(emailAddress,instr(emailAddress,'@')+1) as domain
from
   (select *
    from ss_core_02.hist_userAccount
    where (modifyDateTime > v_destMaxModTime
       or userId > v_destMaxUserId
           )
	   and userId < a_sourceMaxUserId
   ) hua
left outer join ref_localeCountryLanguage rlcl
    on hua.locale = rlcl.localeCode;

call utl_logProcessEnd(v_processId);

end//

delimiter ;

