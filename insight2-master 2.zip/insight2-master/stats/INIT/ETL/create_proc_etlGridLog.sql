# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the userAccount table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure etl_gridLog()' as '' from dual;

delimiter //

drop procedure if exists etl_gridLog//

create procedure etl_gridLog(a_parentProcessId int
						    ,a_levelCtrlNum tinyint)
begin

# Use this variable to determine the rows we havent moved from the source table yet.
declare v_destMaxGridLogId int default (select max(gridLogId) from arc_gridLog);
declare v_processId int;
call utl_logProcessStart( 'etl_gridLog',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set transaction isolation level read committed;

insert into gridLog
select g.*
from ss_core_02.gridLog g
where gridLogId > v_destMaxGridLogId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;
