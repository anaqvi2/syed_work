# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_wellQualifiedLeads table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_wellQualifiedLeads()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_wellQualifiedLeads//

create procedure etl_arc_wellQualifiedLeads(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_arc_wellQualifiedLeads',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxModTime = (SELECT MAX(snapshotDate) FROM arc_wellQualifiedLeads);

INSERT arc_wellQualifiedLeads(snapshotDate, userID, loginStrength, lifetimeLogCount, sheetCount, sharingCount, leadStrength, associatedWithPaidAccount)
SELECT 	
CURRENT_DATE(),
userAccount.userID, 
rpt_loginCountTotal.loginStrength,
rpt_clientLogCountsByUserArchived.lifetimeLogCount,
rpt_containerCountsByUser.sheetCount,
rpt_featureCountRollupByUser.sharingCount,
(rpt_loginCountTotal.loginStrength / 3) * (rpt_clientLogCountsByUserArchived.lifetimeLogCount / 1000)  
* (rpt_containerCountsByUser.sheetCount / 3) * (rpt_featureCountRollupByUser.sharingCount + .25) AS leadStrength,

CASE rpt_containerCountsByUser.sheetsSharedFromPaidAccount > 0
	WHEN 1 THEN 1
	ELSE 0 END 

FROM userAccount userAccount
  LEFT OUTER JOIN rpt_paymentProfile  		ON userAccount.userID = rpt_paymentProfile.sourceUserID 
  LEFT OUTER JOIN rpt_loginCountTotal 		ON userAccount.userID = rpt_loginCountTotal.userID
  LEFT OUTER JOIN rpt_clientLogCountsByUserArchived	ON userAccount.userID = rpt_clientLogCountsByUserArchived.userID
  LEFT OUTER JOIN rpt_containerCountsByUser 	ON userAccount.userID = rpt_containerCountsByUser.userID
  LEFT OUTER JOIN rpt_featureCountRollupByUser   	ON userAccount.userID = rpt_featureCountRollupByUser.userID
  
WHERE (rpt_paymentProfile.productID = 1 OR 
     (rpt_paymentProfile.productID = 2 AND DATEDIFF(CURRENT_DATE(), userAccount.insertDateTime) <= 35))
	AND rpt_paymentProfile.accountType != 3
	AND v_destMaxModTime < CURRENT_DATE()

GROUP BY 1,2

HAVING leadStrength > 0.05
;

INSERT arc_DailyWellQualifiedLeads(snapshotDate, random, userID)
SELECT 
MIN(arc_wellQualifiedLeads.snapshotDate) AS minSnapshotDate,
RAND(),
arc_wellQualifiedLeads.userID
FROM arc_wellQualifiedLeads
LEFT OUTER JOIN arc_DailyWellQualifiedLeads ON arc_DailyWellQualifiedLeads.userID = arc_wellQualifiedLeads.userID
WHERE arc_DailyWellQualifiedLeads.snapshotDate IS NULL
GROUP BY 3
HAVING minSnapshotDate = CURRENT_DATE()
;
COMMIT;

UPDATE arc_DailyWellQualifiedLeads
JOIN arc_wellQualifiedLeads ON arc_wellQualifiedLeads.snapshotDate = arc_DailyWellQualifiedLeads.snapshotDate  
	AND arc_wellQualifiedLeads.userID = arc_DailyWellQualifiedLeads.userID
SET arc_DailyWellQualifiedLeads.leadStrength = arc_wellQualifiedLeads.leadStrength
WHERE arc_DailyWellQualifiedLeads.leadStrength IS NULL
;
COMMIT;

SET @num = 0;

UPDATE arc_DailyWellQualifiedLeads
SET dailyCount = @num:=@num + 1	WHERE dailyCount IS NULL AND snapshotDate = CURRENT_DATE()
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;