# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_sessionLog table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_sessionLog()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_sessionLog//

create procedure etl_arc_sessionLog(a_parentProcessId int
                                   ,a_levelCtrlNum tinyint
                                   ,a_newMaxSessionLogId int)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_arc_sessionLog',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT MAX(sessionLogID) FROM arc_sessionLog);

INSERT arc_sessionLog 
SELECT * 
FROM ss_core_02.sessionLog 
WHERE sessionLogID > v_destMaxId 
    and sessionLogID <= a_newMaxSessionLogId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;