# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_signupRequestTrackingItem()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_signupRequestTrackingItem//

create procedure etl_rpt_signupRequestTrackingItem(a_parentProcessId int
                                                  ,a_levelCtrlNum tinyint
												  ,a_newMaxSignupRequestId int
                                                  ,a_newMaxSignupRequestTrackingItemId int
                                                   )
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
declare v_minSRTIId int; 
call utl_logProcessStart('etl_rpt_signupRequestTrackingItem',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select ifnull(max(signupRequestTrackingItemID),0) from rpt_signupRequestTrackingItem);
/* Grab last negative value for signupRequestTrackingItemID to use as starting point for new values to be inserted*/
set v_minSRTIId = (SELECT ifnull(min(signupRequestTrackingItemID),-1) FROM rpt_signupRequestTrackingItem WHERE signupRequestTrackingItemID < 0);

/* copy over the tracking items we care about and decode them at the same time */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	core_TrackingItem.signupRequestTrackingItemID, 
	core_TrackingItem.signupRequestID, 
	core_TrackingItem.itemType, 
	core_TrackingItem.itemName, 
			
	CASE core_TrackingItem.itemValue REGEXP "\\%"
		WHEN 1 THEN 
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
		REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(core_TrackingItem.itemValue, 
						"%25"	, "%"), 
						"%25"	, "%"), /* may be double encoded */
						"%25"	, "%"), /* may be triple encoded */
						"%20"	, " "), 
						"%26"	, "&"), 
						"%27"	, "'"),
						"%2B"	, "+"), 
						"%2c"	, ","), 
						"%2C"	, ","), 
						"%2D"	, "-"), 
						"%2F"	, "/"), 
						"%3A"	, ":"),
						"%3D"	, "="),
						"%3F"	, "?"),
						"%7B"	, "{"),
						"%7D"	, "}"),
						"%C3%A1", "á"),
						"%C3%A2", "â"),
						"%C3%A3", "ã"),
						"%C3%A7", "ç"),
						"%C3%A8", "è"),
						"%C3%A9", "é"),
						"%C3%AA", "ê"),
						"%C3%AD", "í"),
						"%C3%B1", "ñ"), 
						"%C3%B3", "ó") 
						
		ELSE core_TrackingItem.itemValue  /* nothing to decode */
	END 
												
FROM ss_core_02.signupRequestTrackingItem core_TrackingItem
WHERE core_TrackingItem.itemName IN ("c", "s", "m",    	/* high level tracking codes */
	"cv", "lpv", "sbs", "sxt",							/* landing page codes */
	"q", "p", "wd", "terms", "query", 					/* search term parameters */
	"k", "a", "plc", "adp", "mtp", "net",				/* PPC codes */
	"Type",	"u", "Parm1", "ip",							/* Smartsheet system codes */
	"r", "utm_referrer", "url", "src",					/* referrer information, src for pm-sherpa */
	"dev", "devm", "mkwid", "gclid",					/* more PPC codes */
	"utm_expid", "ket",									/* AB testing codes */
	"wsca", 											/* web site chat */
	"rems", "rema", "remm", "remc",						/* remarketing codes */
	"trp")												/* trial path */
AND core_TrackingItem.signupRequestTrackingItemID > v_destMaxId  /* not already done */
and core_TrackingItem.signupRequestTrackingItemID <= a_newMaxSignupRequestTrackingItemId;	/* through the end of the day */		



/* Clean out staging table */
TRUNCATE TABLE stg_signupRequestTrackingItem;

TRUNCATE TABLE stg_signupTrackingData;

INSERT INTO stg_signupTrackingData
SELECT signupRequestID, itemName, 
SPLIT_STR(itemName,"%26",1) as combo1, /* identifies 1st name and value pair */
SPLIT_STR(itemName,"%26",2) as combo2, /* identifies 2nd name and value pair */
SPLIT_STR(itemName,"%26",3) as combo3  /* identifies 3rd name and value pair*/
FROM 
(
/*Identify records that had their itemName incorrectly populated*/
	SELECT signupRequest.signupRequestID, DATE(signupRequest.insertDateTime), signupRequest.insertDateTime, signupRequest.resultStatus, 
	signupRequestTrackingItem.itemName, signupRequestTrackingItem.itemValue
	/*rpt_signupSource.bucket, rpt_signupSource.sourceFriendly, rpt_signupSource.subSourceFriendly*/
	FROM ss_core_02.signupRequestTrackingItem
	JOIN ss_core_02.signupRequest ON signupRequest.signupRequestID = signupRequestTrackingItem.signupRequestID
	/*JOIN rpt_signupSource ON rpt_signupSource.signupRequestID = signupRequest.signupRequestID */
	WHERE itemName LIKE "s\%3D%" 
	AND signupRequest.signupRequestID >= 3907323
	AND signupRequest.signupRequestID <= a_newMaxSignupRequestId
	AND signupRequestTrackingItem.signupRequestTrackingItemID >= v_destMaxId
	and signupRequestTrackingItem.signupRequestTrackingItemID <= a_newMaxSignupRequestTrackingItemId
) A  /*Alias required to run subquery*/
;

set v_minSRTIId = v_minSRTIId-1;
-- First Pass
INSERT INTO stg_signupRequestTrackingItem 
SELECT v_minSRTIId AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo1,'%3D',1) AS itemName1,
substring_index(combo1,'%3D',-1) AS itemValue1, 
NULL AS extraInfo

FROM stg_signupTrackingData
WHERE combo1 IS NOT NULL
AND combo1 != ''
;

-- Second Pass

set v_minSRTIId = v_minSRTIId-1;
INSERT INTO stg_signupRequestTrackingItem 

SELECT v_minSRTIId AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo2,'%3D',1) AS itemName2,
substring_index(combo2,'%3D',-1) AS itemValue2, 
NULL AS extraInfo
FROM stg_signupTrackingData
WHERE combo2 IS NOT NULL
AND combo2 != ''
;


set v_minSRTIId = v_minSRTIId-1;
-- Third Pass
INSERT INTO stg_signupRequestTrackingItem 
SELECT v_minSRTIId AS signupRequestTrackingItemID, signupRequestID, 1 AS itemType,
substring_index(combo3,'%3D',1) AS itemName3,
substring_index(combo3,'%3D',-1) AS itemValue3, 
NULL AS extraInfo
FROM stg_signupTrackingData
WHERE combo3 IS NOT NULL
AND combo3 != ''
;

-- Final Insert
INSERT INTO rpt_signupRequestTrackingItem 
SELECT stg.signupRequestTrackingItemID, stg.signupRequestID, stg.itemType, stg.itemName, stg.itemValue, stg.extraInfo
FROM stg_signupRequestTrackingItem stg
LEFT JOIN rpt_signupRequestTrackingItem srti ON srti.signupRequestID=stg.signupRequestID
	AND srti.itemName=stg.itemName
WHERE srti.signupRequestTrackingItemID IS NULL
;

/* extract out the q parameter embeded in the referrer information */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into queryValue parameter */
	SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "q") 
		
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?q=%' OR  main_trackingItem.itemValue LIKE '%&q=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId    /* not already done */
;

/* extract out the p parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"p", /* < -- going into p parameter, needs more processing before going into queryValue */
	SMARTSHEET_GET_QUERY_PARAMETER(main_trackingItem.itemValue, "p") 	
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?p=%' OR  main_trackingItem.itemValue LIKE '%&p=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* now process p search parameters into queryValue */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,
	"queryValue", 
	main_trackingItem.itemValue		
FROM rpt_signupRequestTrackingItem main_trackingItem
JOIN rpt_signupRequestTrackingItem main_trackingItem2 ON main_trackingItem.signupRequestID = main_trackingItem2.signupRequestID 
	/* there are lots of p parameters that are not search queries, so clean it up */
	AND main_trackingItem2.itemName = 'r' AND main_trackingItem2.itemValue LIKE "%yahoo%" AND main_trackingItem.itemValue NOT LIKE "ht%" 
WHERE main_trackingItem.itemName IN ("p") 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* extract out the 'query' parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into queryValue parameter */
	SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "query") 
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?query=%' OR  main_trackingItem.itemValue LIKE '%&query=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* extract out the 'wd' parameter embeded in the referrer information -- but it is going into queryValueparameter */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,  
	"queryValue", /* < -- but it is going into queryValue parameter */
	SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "wd") 
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?wd=%' OR  main_trackingItem.itemValue LIKE '%&wd=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* extract out the 'terms' parameter embeded in the referrer information -- but it is going into queryValue parameter */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType, 
	"queryValue", /* < -- but it is going into q parameter */
	SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "terms") 
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?terms=%' OR  main_trackingItem.itemValue LIKE '%&terms=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* combine all the new locations for search query information into one parameter: queryValue */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType,
	"queryValue", 
	itemValue
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("q", "wd", "terms", "query")  /* already did "p" earlier since it needed to be cleaned more */
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* extract out the url parameter embeded in the referrer information */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType, 
	"url", 
	SMARTSHEET_GET_QUERY_PARAMETER(itemValue, "url") 
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName IN ("r", "utm_referrer") AND (main_trackingItem.itemValue LIKE '%?url=%' OR  main_trackingItem.itemValue LIKE '%&url=%') 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	itemType,
	"referrerValue", 
	SUBSTRING_INDEX(TRIM(LEADING 'http://' FROM itemValue), "?", 1)
FROM rpt_signupRequestTrackingItem main_trackingItem
WHERE main_trackingItem.itemName = 'r' 
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* this second step uses the utm_referrer value if we have one already */
INSERT rpt_signupRequestTrackingItem(
	signupRequestTrackingItemID, 
	signupRequestID, 
	itemType, 
	itemName, 
	itemValue)
SELECT 
	main_trackingItem.signupRequestTrackingItemID, 
	main_trackingItem.signupRequestID, 
	main_trackingItem.itemType,
	"referrerValue", 
	SUBSTRING_INDEX(TRIM(LEADING 'http://' FROM main_trackingItem.itemValue), "?", 1)
FROM rpt_signupRequestTrackingItem main_trackingItem
LEFT OUTER JOIN rpt_signupRequestTrackingItem main_trackingItemReferrerValue 
	ON main_trackingItem.signupRequestID = main_trackingItemReferrerValue.signupRequestID AND main_trackingItemReferrerValue.itemName = 'referrerValue'
WHERE main_trackingItem.itemName = 'utm_referrer' AND main_trackingItemReferrerValue.itemValue IS NULL
	AND main_trackingItem.itemValue NOT LIKE '%www.smartsheet.%' AND main_trackingItem.itemValue NOT LIKE '%.smartsheet.com%' /* don't count referrals from our site */
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* update the queryValues if it looks like they were a smartsheet search */
UPDATE rpt_signupRequestTrackingItem main_trackingItem
SET extraInfo = 'SmartsheetSearch'
WHERE main_trackingItem.itemName = 'queryValue'  AND   /* try not to false match on spreadsheet or sample sheet */
   (main_trackingItem.itemValue LIKE '%smar_sh%' OR				/* plus or space between words */
	main_trackingItem.itemValue LIKE '%smar__sh%' OR			/* one extra letter between two words or smart(space)sheet */
	main_trackingItem.itemValue LIKE '%smar___sh%' OR			/* two letters between two words */
	main_trackingItem.itemValue LIKE '%samr_sh%' OR				/* transposed m,a */
	main_trackingItem.itemValue LIKE '%samr__sh%' OR			/* transposed m,a */
	main_trackingItem.itemValue LIKE '%samr___sh%' OR			/* transposed m,a */
	main_trackingItem.itemValue LIKE '%smaartsh%' OR			/* extra a */
	main_trackingItem.itemValue LIKE '%smarsh%' OR				/* dropped the t */
	main_trackingItem.itemValue LIKE '%smar_sh%' OR				/* dropped the t, extra letter  */
	main_trackingItem.itemValue LIKE '%smatsh%' OR				/* dropped the r */
	main_trackingItem.itemValue LIKE '%smat_sh%' OR				/* dropped the r, extra letter */
	main_trackingItem.itemValue LIKE '%smartse%' OR				/* dropped the h */
	main_trackingItem.itemValue LIKE '%sartsh%'				/* dropped the m */
	)
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* update the queryValues if it looks like they were a smartsheet search */
UPDATE rpt_signupRequestTrackingItem main_trackingItem
JOIN rpt_signupRequestTrackingItem main_trackingItemURL ON main_trackingItem.signupRequestID = main_trackingItemURL.signupRequestID AND main_trackingItemURL.itemName = 'url'
SET main_trackingItem.extraInfo =  "DeepLink-NotProvided" 	/* queryValueis blank, but the URL indicates the landing page was not the main page, so likely not a smartsheet search */
WHERE main_trackingItem.itemName = 'queryValue'  AND (main_trackingItem.itemValue = '' OR main_trackingItem.itemValue = 'null') 
/* find where they landed - if they went beyond the home page, they were likely to be a not smartsheet search, unless they went to pricing or signup page */
AND (main_trackingItemURL.itemValue LIKE '%www.smartsheet.%/_%')  AND (main_trackingItemURL.itemValue NOT LIKE '%www.smartsheet.%/pricing%') AND (main_trackingItemURL.itemValue NOT LIKE '%www.smartsheet.%/signup%')  
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* clean up s=web that stomped on the PPC tracking codes */
UPDATE rpt_signupRequestTrackingItem main_trackingItem
/* validate it has at least two other PPC tracking codes */
JOIN rpt_signupRequestTrackingItem main_trackingItemC ON main_trackingItem.signupRequestID = main_trackingItemC.signupRequestID AND main_trackingItemC.itemName = 'c'
JOIN rpt_signupRequestTrackingItem main_trackingItemM ON main_trackingItem.signupRequestID = main_trackingItemM.signupRequestID AND main_trackingItemM.itemName = 'm'
SET main_trackingItem.itemValue = "1"   /* google search*/
WHERE main_trackingItem.itemName = 's'  AND main_trackingItem.itemValue = 'web'
AND main_trackingItem.signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* Now process spaces encoded as + in keywords.
   This is needed to try to match the keywords being fed back into the Marin system */

/* fix the keywords without the broad mod+ where spaces are encoded as +*/
UPDATE rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue,"+", " ")
WHERE itemName = 'k' AND itemValue REGEXP ".\\+"  AND NOT itemValue REGEXP "[' ']" AND NOT itemValue REGEXP "\\+\\+"   /* contains + but not space or ++ */
AND signupRequestTrackingItemID > v_destMaxId;    /* not already done */

/* fix issue with bing keywords where + in broad mod is coming through as space */
/* change the spaces into pluses here, then the next update statement will fix the ones that should be spaces  */
UPDATE rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue," ", "+")
WHERE itemName = 'k' AND (itemValue LIKE " %" OR itemValue LIKE "' %") 	/* start with space or single quote then space*/
AND signupRequestTrackingItemID > v_destMaxId;    		/* not already done */

/* fix the keywords that have broad mod+, turn the first + into space but keep the second+ */
UPDATE rpt_signupRequestTrackingItem 
SET itemValue = REPLACE(itemValue,"++", " +")
WHERE itemName = 'k' AND itemValue REGEXP "\\+\\+"    /* contains ++ */
AND signupRequestTrackingItemID > v_destMaxId;    /* not already done */

call utl_logProcessEnd(v_processId);

end//

delimiter ;