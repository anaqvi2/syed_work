# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_ISPDomains table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_ISPDomains()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_ISPDomains//

create procedure etl_arc_ISPDomains(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
call utl_logProcessStart('etl_arc_ISPDomains',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

TRUNCATE arc_ISPDomains; 

INSERT arc_ISPDomains(domain, userCount)
SELECT domain, COUNT(userID)
FROM userAccount

/*Continue regular check of domains in userAccount to see if new domains need to be added*/
WHERE userAccount.domain LIKE '%yahoo%'
OR userAccount.domain LIKE 'live.%'
OR userAccount.domain LIKE 'hotmail.%'
OR userAccount.domain LIKE 'aol.co%'
OR userAccount.domain LIKE '%.rr.com'
OR userAccount.domain LIKE '%.net.il'
OR userAccount.domain LIKE '%comcast%'
OR userAccount.domain IN (
'10gen.com',
'123.com',
'126.com',
'139.com',
'163.com',
'aim.com',
'abv.bg',
'adinet.com.uy',
'alice.it',
'Aol.com', 
'att.net',
'bellsouth.net',
'bell.net',
'bigpond.com',
'bigpond.net.au',
'bigpond.com.au',
'bluewin.ch',
'bk.ru',
'blueyonder.co.uk',
'bol.com.br',
'btconnect.com',
'btinternet.com',
'btopenworld.com',
'charter.net',
'comcast.net', 
'cox.net',
'earthlink.net',
'eircom.net',
'embarqmail.com',
'free.fr',
'globo.com',
'gmail.com', 
'gmx.de',
'googlemail.com', 
'hanmail.net',
'hotmail.co.uk', 
'hotmail.com', 
'hotmail.es', 
'hotmail.fr', 
'ibest.com.br',
'icloud.com',
'ig.com.br',
'iinet.net.au',
'juno.com',
'juno.com',
'laposte.net',
'libero.it',
'live.co.uk',
'live.com', 
'mac.com',
'mail.com',
'mail.ru',
'me.com',
'me.com',
'msn.com', 
'mweb.co.za',
'naver.com',
'ntlworld.com',
'oi.com.br',
'optonline.net',
'optusnet.com.au',
'orange.fr',
'outlook.com',
'prodigy.net.mx',
'qq.com',
'rediffmail.com',
'roadrunner.com',
'rocketmail.com',
'rogers.com',
'sapo.pt',
'sbcglobal.net', 
'sfr.fr',
'shaw.ca',
'sky.com',
'sympatico.ca',
'talktalk.net',
'teksavvy.com',
'telus.net',
'terra.com.br',
'tiscali.co.uk',
'toast.net',
'uol.com.br',
'verizon.net', 
'videotron.ca',
'vodafone.co.nz',
'wanadoo.fr',
'web.de',
'westnet.com.au',
'xtra.co.nz',
'yandex.ru',
'ymail.com',
'zippy-uk.com',
'zippy-au.com',
'zippy-nz.com',
'cableone.net',
'cantv.net',
'centurylink.net',
'centurytel.net',
'clear.net.nz',
'cogeco.ca',
'csas.cz',
'eastlink.ca',
'email.com',
'excite.com',
'fastmail.fm',
'foxmail.com',
'freemail.hu',
'freenet.de',
'frontier.com',
'frontiernet.net',
'fsmail.net',
'globomail.com',
'gmx.com',
'gmx.net',
'in.com',
'inbox.com',
'inbox.lv',
'insightbb.com',
'internode.on.net',
'iol.pt',
'iprimus.com.au',
'klarna.com',
'latinmail.com',
'mailinator.com',
'mindspring.com',
'nate.com',
'netscape.net',
'netspace.net.au',
'netzero.com',
'netzero.net',
'o2.co.uk',
'o2.pl',
'outlook.es',
'ozemail.com.au',
'pacbell.net',
'prodigy.net',
'q.com',
'r7.com',
'rambler.ru',
'rmqkr.net',
'sasktel.net',
'seznam.cz',
'sharklasers.com',
'suddenlink.net',
'talk21.com',
'tds.net',
'telefonica.net',
'telenet.be',
'telkomsa.net',
'tiscali.it',
'tpg.com.au',
'usa.net',
'virgin.net',
'virginmedia.com',
'vodafone.com',
'vodamail.co.za',
'voila.fr',
'vtr.net',
'walla.com',
'webmail.co.za',
'windowslive.com',
'windstream.net',
'wp.pl',
'y7mail.com',
'ya.ru',
'yopmail.com')

GROUP BY 1;

call utl_logProcessEnd(v_processId);

end//

delimiter ;