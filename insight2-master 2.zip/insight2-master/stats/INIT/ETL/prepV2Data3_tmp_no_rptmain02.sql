select "******************************************************************************************************************************", NOW();
select "******** PrepV2Data3 - start ******** ", NOW();

/*  This is the final portion of the main reporting file that is run first to pre-process the data */
/* These reports do not require the replicated database (ss_core_02)*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("PrepV2 #3");


select "******************************************************************************************************************************", NOW();
select "******** Copy client events and server events in request log so we have more than 14 days worth - start ******** ", NOW();

/*DROP TABLE IF EXISTS arc_clientEventTemplateGallerySearch;*/
/*CREATE TABLE IF NOT EXISTS arc_clientEventTemplateGallerySearch LIKE arc_clientEvent;*/
/*DROP TABLE IF EXISTS arc_siteSearchTerms;*/
/*CREATE TABLE IF NOT EXISTS arc_clientEventSiteSearchTerms LIKE arc_clientEvent;*/
/*DROP TABLE IF EXISTS arc_clientEventTemplateGalleryCategories;*/
/*CREATE TABLE IF NOT EXISTS arc_clientEventTemplateGalleryCategories LIKE arc_clientEvent;*/

/*Start arc_clientEventTemplateGallerySearch*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("arc_clientEventTemplateGallerySearch");


SELECT MAX(clientEventID) FROM arc_clientEventTemplateGallerySearch INTO @maxClientEventID;


SET AUTOCOMMIT = 0;
INSERT arc_clientEventTemplateGallerySearch
SELECT * 
FROM arc_clientEvent
WHERE objectID IN (552, 562)
AND actionID = 32 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("arc_clientEventTemplateGallerySearch");




/*Start arc_clientEventSiteSearchTerms*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("arc_clientEventSiteSearchTerms");


SELECT MAX(clientEventID) FROM arc_clientEventSiteSearchTerms INTO @maxClientEventID;

SET AUTOCOMMIT = 0;
INSERT arc_clientEventSiteSearchTerms 
SELECT * 
FROM arc_clientEvent
WHERE objectID = 7050 
AND actionID = 16 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("arc_clientEventSiteSearchTerms");


/*Start arc_clientEventTemplateGalleryCategories*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("arc_clientEventTemplateGalleryCategories");

SELECT MAX(clientEventID) FROM arc_clientEventTemplateGalleryCategories INTO @maxClientEventID;

SET AUTOCOMMIT = 0;
INSERT arc_clientEventTemplateGalleryCategories
SELECT * 
FROM arc_clientEvent
WHERE objectID IN (551,563) 
AND actionID = 22 
AND clientEventID > @maxClientEventID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("arc_clientEventTemplateGalleryCategories");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_clientLogCountsByUserArchived table part2- start ******** ", NOW();


SELECT insertDateTime FROM userAccount WHERE userAccount.userID = @maxuserID INTO @maxinsertDateTime;
	
	
/*Start rpt_clientLogCountsByUserArchived firstLoginDayLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived firstLoginDayLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN rpt_loginCountTotal ON clcua.userID = rpt_loginCountTotal.userID
SET clcua.firstLoginDayLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	WHERE r.insertByUserID = rpt_loginCountTotal.userID AND r.logDate <= DATE_ADD(rpt_loginCountTotal.firstlogin, INTERVAL 12 HOUR) AND rpt_loginCountTotal.firstlogin)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;
	
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived firstLoginDayLogCount");
	
	
/*Start rpt_clientLogCountsByUserArchived firstDayActiveLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived firstDayActiveLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN userAccount u ON clcua.userID = u.userID
SET clcua.firstDayActiveLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	WHERE r.insertByUserID = u.userID AND r.logDate <= DATE_ADD(u.insertDateTime, INTERVAL 12 HOUR) AND r.actionID IN (20,21,22,23,24,31,32))
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived firstDayActiveLogCount");
	
	
/*Start rpt_clientLogCountsByUserArchived firstLoginDayActiveLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived firstLoginDayActiveLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN rpt_loginCountTotal ON clcua.userID = rpt_loginCountTotal.userID
SET clcua.firstLoginDayActiveLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	/* add 12 hours to the insertDate time to make sure user has enough time to try Smartsheet.*/
	/* for example, if the user starts at 11pm, this will give them 25 hours instead of 1 hour.*/
	WHERE r.insertByUserID = rpt_loginCountTotal.userID AND r.logDate <= DATE_ADD(rpt_loginCountTotal.firstlogin, INTERVAL 12 HOUR) AND r.actionID IN (20,21,22,23,24,31,32))
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived firstLoginDayActiveLogCount");

	
/*Start rpt_clientLogCountsByUserArchived firstWeekLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived firstWeekLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
JOIN userAccount u ON clcua.userID = u.userID
SET clcua.firstWeekLogCount =
	(SELECT SUM(logCount) FROM arc_clientEventRollup 
	WHERE insertByUserID = u.userID AND logDate <= DATE_ADD(u.insertDateTime, INTERVAL 7 DAY))
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;
	
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived firstWeekLogCount");


	
/*Start rpt_clientLogCountsByUserArchived lastWeekLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived lastWeekLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
SET clcua.lastWeekLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	WHERE r.insertByUserID = clcua.userID AND r.logDate > DATE_ADD(CURRENT_DATE(), INTERVAL -7 DAY))
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived lastWeekLogCount");


	
/*Start rpt_clientLogCountsByUserArchived last30DayLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived last30DayLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
SET clcua.last30DayLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	WHERE r.insertByUserID = clcua.userID AND r.logDate > DATE_ADD(CURRENT_DATE(), INTERVAL -30 DAY))
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;
	
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived last30DayLogCount");


	
/*Start rpt_clientLogCountsByUserArchived last90DayLogCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived last90DayLogCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua
SET clcua.last90DayLogCount =
	(SELECT SUM(r.logCount) FROM arc_clientEventRollup r
	WHERE r.insertByUserID = clcua.userID AND r.logDate > DATE_ADD(CURRENT_DATE(), INTERVAL -90 DAY)) 
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;
	
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived last90DayLogCount");

	
/*Start rpt_clientLogCountsByUserArchived firstDayStackTraceCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived firstDayStackTraceCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua   	
JOIN userAccount u ON clcua.userID = u.userID
SET clcua.firstDayStackTraceCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr 
WHERE (objectID = 1602 AND actionID = 1 AND parm1String LIKE 'js_stack_trace%' AND glr.insertByUserID = clcua.userID AND glr.logDate <= DATE_ADD(u.insertDateTime, INTERVAL 12 HOUR)))
WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;


/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived firstDayStackTraceCount");


/*Start rpt_clientLogCountsByUserArchived stackTraceCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByUserArchived stackTraceCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_clientLogCountsByUserArchived clcua   	
SET clcua.stackTraceCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr 
WHERE (objectID = 1602 AND actionID = 1 AND parm1String LIKE 'js_stack_trace%' AND glr.insertByUserID = clcua.userID))
WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSaturday";
COMMIT;
SET AUTOCOMMIT = 1;


/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByUserArchived stackTraceCount");

 
/*CREATE INDEX idx_clientLogCountsByUserArchivedPaymentProfileID ON rpt_clientLogCountsByUserArchived (paymentProfileID);*/


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_userSourceIP table - start ******** ", NOW();

/*Start rpt_userSourceIP*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userSourceIP");


-- DROP TABLE IF EXISTS rpt_userSourceIP;
CREATE TABLE IF NOT EXISTS rpt_userSourceIP(
	emailAddress VARCHAR(100), 
	sourceIP VARCHAR(50));
	
/*CREATE INDEX idx_userSourceIPemailAddress ON rpt_userSourceIP (emailAddress);*/
/*CREATE INDEX idx_userSourceIPsourceIP ON rpt_userSourceIP (sourceIP);*/


/******* Insert all distict userID/sourceIP combos from rpt_userSourceIP - start *******/
SET AUTOCOMMIT = 0;
INSERT IGNORE INTO rpt_userSourceIP
(
	emailAddress, 
	sourceIP
)
SELECT DISTINCT
	arc_sessionLog.emailAddress, 
	arc_sessionLog.sourceIP
FROM arc_sessionLog
LEFT OUTER JOIN rpt_userSourceIP ins ON arc_sessionLog.emailAddress=ins.emailAddress
	AND arc_sessionLog.sourceIP=ins.sourceIP
WHERE userID > 0
AND ins.emailAddress IS NULL
AND ins.sourceIP IS NULL
;
COMMIT;
SET AUTOCOMMIT = 1;


/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userSourceIP");


/* This table is to make it easy to resolve to the userAccount for any payment profile */
SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_cancelComments table - start ******** ", NOW();

/*Start rpt_cancelComment*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_cancelComment insert");


DROP TABLE IF EXISTS rpt_cancelComment;
CREATE TABLE rpt_cancelComment (
	userID				BIGINT, 
	cancelComment  		NVARCHAR(4000),
	cancelCommentDate 	DATETIME,
	paymentProfileID 	BIGINT,
	parentPaymentProfileID BIGINT,
	PRIMARY KEY(userID),
	index (parentPaymentProfileID),
	index (cancelCommentDate));

/* Update cancel reason for folks that we have cancel comments for */
SET AUTOCOMMIT = 0;
INSERT rpt_cancelComment (userID, cancelComment, cancelCommentDate)
SELECT userID, valueString, modifyDateTime 
FROM siteSettingElementValue ss
WHERE ss.siteSettingElementName = 'CancelComments'
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_cancelComment insert");



/* Roll up cancel comments from a user to any individual payment profile they had */

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_cancelComment update");

SET AUTOCOMMIT = 0;
UPDATE rpt_cancelComment rc 
  JOIN rpt_paymentProfile pp ON rc.userID = pp.mainContactUserID AND pp.accountType != 3
SET rc.paymentProfileID = pp.paymentProfileID;
COMMIT;

/* Roll up cancel comments from a user's payment profile to their parent profile if they ever had one */
UPDATE rpt_cancelComment rc 
  JOIN hist_paymentProfile hp ON rc.paymentProfileID = hp.paymentProfileID 
  JOIN rpt_paymentProfile pp on hp.parentPaymentProfileID = pp.paymentProfileID
SET rc.parentPaymentProfileID = pp.paymentProfileID;
COMMIT;

/* Update the payment profile with their cancel comments */
UPDATE rpt_paymentProfile rp
  JOIN rpt_cancelComment rc ON rp.paymentProfileID = rc.paymentProfileID
SET rp.cancelPaymentComment = QUOTE(rc.cancelComment);  
COMMIT;

/* Update the PARENT payment profile with their cancel comments */
UPDATE rpt_paymentProfile rp
  JOIN rpt_cancelComment rc ON rp.paymentProfileID = rc.parentPaymentProfileID
SET rp.cancelPaymentComment = rc.cancelComment;  
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_cancelComment update");


SELECT "******************************************************************************************************************************", NOW();
select "******** rpt_userSessionActivityPT table - start ******** ", NOW();

/*Start rpt_userSessionActivityPT*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userSessionActivityPT");


/* convert times to Pacific time zone using rough approximation  +8 hours */
DROP TABLE IF EXISTS rpt_userSessionActivityPT;
 
CREATE TABLE IF NOT EXISTS 
rpt_userSessionActivityPT(
	userID 			INT, 
	firstSessionID 		INT, 
	firstSessionDateTime 	DATETIME, 
	lastSessionID 		INT, 
	lastSessionDateTime 	DATETIME, 
	sessionCount 		INT, 
	PRIMARY KEY(userID));
	
SET AUTOCOMMIT = 0;	
INSERT rpt_userSessionActivityPT(
	userID , 
	firstSessionID, 
	firstSessionDateTime, 
	lastSessionID, 
	lastSessionDateTime, 
	sessionCount)
SELECT 
	usa.userID, 
	usa.firstSessionID, 
	CONVERT_TZ(usa.firstSessionDateTime,'+00:00','+8:00'), 
	usa.lastSessionID, 
	CONVERT_TZ(usa.lastSessionDateTime,'+00:00','+8:00'), 
	usa.sessionCount
FROM arc_userSessionActivity usa
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userSessionActivityPT");




SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_userAdditionHierarchy table - start ******** ", NOW();

/*Start rpt_userAdditionHierarchy*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userAdditionHierarchy");


/* Two step process - first navigate the insertByUserID chain 8 levels deep */
DROP TABLE IF EXISTS rpt_userAdditionHierarchy;
CREATE TABLE IF NOT EXISTS rpt_userAdditionHierarchy
(
lev1 VARCHAR(50), 
lev2 VARCHAR(50), 
lev3 VARCHAR(50), 
lev4 VARCHAR(50), 
lev5 VARCHAR(50), 
lev6 VARCHAR(50), 
lev7 VARCHAR(50), 
lev8 VARCHAR(50)
);

SET AUTOCOMMIT = 0;
INSERT rpt_userAdditionHierarchy(lev1, lev2, lev3, lev4, lev5, lev6, lev7, lev8)
SELECT t1.emailAddress AS lev1, 
	t2.emailAddress AS lev2, 
	t3.emailAddress AS lev3, 
	t4.emailAddress AS lev4, 
	t5.emailAddress AS lev5, 
	t6.emailAddress AS lev6, 
	t7.emailAddress AS lev7, 
	t8.emailAddress AS lev8
FROM userAccount AS t1
LEFT JOIN userAccount AS t2 ON t2.insertByUserID = t1.userID
LEFT JOIN userAccount AS t3 ON t3.insertByUserID = t2.userID
LEFT JOIN userAccount AS t4 ON t4.insertByUserID = t3.userID
LEFT JOIN userAccount AS t5 ON t5.insertByUserID = t4.userID
LEFT JOIN userAccount AS t6 ON t6.insertByUserID = t5.userID
LEFT JOIN userAccount AS t7 ON t7.insertByUserID = t6.userID
LEFT JOIN userAccount AS t8 ON t8.insertByUserID = t7.userID
;
COMMIT;
SET AUTOCOMMIT = 1;

SELECT "******** idx_rpt_userAdditionHierarchy2 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy2 ON rpt_userAdditionHierarchy (lev2);
SELECT "******** idx_rpt_userAdditionHierarchy3 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy3 ON rpt_userAdditionHierarchy (lev3);
SELECT "******** idx_rpt_userAdditionHierarchy4 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy4 ON rpt_userAdditionHierarchy (lev4);
SELECT "******** idx_rpt_userAdditionHierarchy5 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy5 ON rpt_userAdditionHierarchy (lev5);
SELECT "******** idx_rpt_userAdditionHierarchy6 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy6 ON rpt_userAdditionHierarchy (lev6);
SELECT "******** idx_rpt_userAdditionHierarchy7 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy7 ON rpt_userAdditionHierarchy (lev7);
SELECT "******** idx_rpt_userAdditionHierarchy8 - start ******** ", NOW();
CREATE INDEX idx_rpt_userAdditionHierarchy8 ON rpt_userAdditionHierarchy (lev8);

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userAdditionHierarchy");


/* Two step process - then find the user at the end of the chain */
SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_userAncestor table - start ******** ", NOW();

/*Start rpt_userAncestor*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userAncestor");


DROP TABLE IF EXISTS rpt_userAncestor;
CREATE TABLE IF NOT EXISTS rpt_userAncestor(userEmailAddress VARCHAR(100), ancestorEmailAddress VARCHAR(100));

/******* idx_rpt_userAncestorUserEmailAddress - start *******/
CREATE INDEX idx_rpt_userAncestorUserEmailAddress ON rpt_userAncestor (userEmailAddress);

SET AUTOCOMMIT = 0;
INSERT rpt_userAncestor(userEmailAddress, ancestorEmailAddress)
SELECT DISTINCT
	userAccount.emailAddress,
	NULL
FROM userAccount;
COMMIT;

/* First look at the very end of the chain to see if the user was found there. */
UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev8
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

/* Then look at the next spots along the chain */
UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev7
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev6
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev5
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev4
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev3
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;

UPDATE rpt_userAncestor ua JOIN rpt_userAdditionHierarchy uah ON ua.userEmailAddress = uah.lev2
SET ua.ancestorEmailAddress = uah.lev1
WHERE ancestorEmailAddress IS NULL;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userAncestor");



/* We don't need the table from the first step in the process any more.  Let's get that table/index memory back. */
DROP TABLE IF EXISTS rpt_userAdditionHierarchy;


select "******************************************************************************************************************************", NOW();
select "******** rpt_loginCountByType table - start ******** ", NOW();

/*Start rpt_loginCountByType*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_loginCountByType");



DROP TABLE IF EXISTS rpt_loginCountByType;
CREATE TABLE IF NOT EXISTS rpt_loginCountByType(
	userID 	BIGINT, 
	loginType INT, 
	loginTypeDesc VARCHAR(20), 
	firstSessionLogID INT, 
	firstLogin DATETIME, 
	firstLoginYear INT, 
	firstLoginMonth VARCHAR(10), 
	firstLoginWeek INT, 	
	firstLoginDay INT, 
	lastLogin DATETIME, 	
	lastLoginWeek INT, 
	loginCount INT);
	
SET AUTOCOMMIT = 0;	
INSERT rpt_loginCountByType(
	userID, 
	loginType,
	loginTypeDesc, 
	firstSessionLogID, 
	firstLogin, 
	firstLoginYear,
	firstLoginMonth, 
	firstLoginWeek, 
	firstLoginDay, 
	lastLogin, 
	lastLoginWeek,
	loginCount)
SELECT 
	s.userID, 
	s.loginType,
	CASE s.loginType
	  WHEN 2  THEN "Login Form"
	  WHEN 7  THEN "Login Ticket"
	  WHEN 8  THEN "Remember Me"
	  WHEN 9  THEN "API"
	  WHEN 10 THEN "Password Reset"
	  WHEN 11 THEN "Update Request"
	  WHEN 12 THEN "Quick Add"
	  WHEN 13 THEN "Publish - Editable"
	  WHEN 14 THEN "OpenID"
	  WHEN 15 THEN "Publish - Read Only"
	  WHEN 16 THEN "Intuit"
	  WHEN 18 THEN "Gadget Exchange"
	  WHEN 19 THEN "SSO Salesforce"
	  WHEN 20 THEN "SSO SAML"
	  WHEN 21 THEN "Rest User Credentials"
	  WHEN 22 THEN "Rest Access Token"
	  WHEN 23 THEN "Login Ticket Remember Me Mobile"
	  WHEN 24 THEN "API"
	  WHEN 28 THEN "Rest Google Token - Android"
	  ELSE CONCAT("Other: ", s.loginType)
	END,
	MIN(s.sessionLogID),
	MIN(s.insertDateTime), 
	DATE_FORMAT(MIN(s.insertDateTime), '%Y'), 
	DATE_FORMAT(MIN(s.insertDateTime), '%b%y'),
	SMARTSHEET_WEEK(MIN(s.insertDateTime)), 
	DAYOFYEAR(MIN(s.insertDateTime)),
	MAX(s.insertDateTime), 
	SMARTSHEET_WEEK(MAX(s.insertDateTime)),
	COUNT(*)
FROM arc_sessionLog s
WHERE s.loginAuthResult = 1
GROUP BY 1,2,3
;
COMMIT;
SET AUTOCOMMIT = 1;

/******* idx_rpt_loginCountByType_userID  - start *******/
CREATE INDEX idx_rpt_loginCountByType_userID ON rpt_loginCountByType (userID);

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_loginCountByType");


select "******************************************************************************************************************************", NOW();
select "******** rpt_loginCountWeekly table - start ******** ", NOW();

/*Start rpt_loginCountWeekly*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_loginCountWeekly");

DROP TABLE IF EXISTS rpt_loginCountWeekly;
CREATE TABLE IF NOT EXISTS rpt_loginCountWeekly(
	userID BIGINT, 
	loginCount INT, 
	yearWeekNumb INT)
;

SET AUTOCOMMIT = 0;	
INSERT rpt_loginCountWeekly(
	userID, 
	yearWeekNumb, 
	loginCount)
SELECT 
	s.userID, 
	YEARWEEK(s.insertDateTime), 
	count(*)
FROM rpt_sessionLog s
WHERE s.loginAuthResult = 1
GROUP BY 1,2
;
COMMIT;
SET AUTOCOMMIT = 1;

CREATE INDEX idx_loginCountWeeklyUserID ON rpt_loginCountWeekly (userID);

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_loginCountWeekly");


select "******************************************************************************************************************************", NOW();
select "******** rpt_loginFailure table - start ******** ", NOW();

/*Start rpt_loginFailure*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_loginFailure");


DROP TABLE IF EXISTS rpt_loginFailure;
CREATE TABLE IF NOT EXISTS rpt_loginFailure(emailAddress nvarchar(100), loginAuthResult INT, yearWeekNumb INT, failureCount INT);
CREATE INDEX idx_loginFailureEmailAddress ON rpt_loginFailure (emailAddress);

SET AUTOCOMMIT = 0;
INSERT rpt_loginFailure(emailAddress, loginAuthResult, yearWeekNumb, failureCount)
SELECT emailAddress, loginAuthResult, YEARWEEK(s.insertDateTime), count(*) 
FROM rpt_sessionLog s 
WHERE s.loginAuthResult <= 0 AND DATE_FORMAT(CURRENT_DATE(),"%W" ) = "Sunday"
GROUP BY 1,2,3
;
COMMIT;
SET AUTOCOMMIT = 1;


/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_loginFailure");


select "******************************************************************************************************************************", NOW();
select "******** rpt_integrationRollupByPaymentProfile table - start ******** ", NOW();

/*Start rpt_integrationRollupByPaymentProfile*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_integrationRollupByPaymentProfile");


/* Now rollup by payment profile so we can tell which Paid Customers use these features */
DROP TABLE IF EXISTS rpt_integrationRollupByPaymentProfile;
CREATE TABLE IF NOT EXISTS 
rpt_integrationRollupByPaymentProfile(
	paymentProfileID BIGINT, 
	googleFlag TINYINT,
	googleAppsFlag TINYINT,
	salesforceFlag TINYINT,
	zimbraFlag TINYINT,
	PRIMARY KEY(paymentProfileID));

SET AUTOCOMMIT = 0;
INSERT rpt_integrationRollupByPaymentProfile
SELECT p.paymentProfileID, u.googleFlag, u.googleAppsFlag, u.salesforceFlag, u.zimbraFlag
FROM rpt_paymentProfile p 
JOIN rpt_integrationRollupByUser u ON p.ownerID = u.userID
WHERE p.accountType IN (1,2)
AND (u.googleFlag = 1 OR u.googleAppsFlag = 1 OR u.salesforceFlag = 1 OR u.zimbraFlag = 1)
;
COMMIT;

INSERT rpt_integrationRollupByPaymentProfile
SELECT p1.paymentProfileID, MAX(u.googleFlag), MAX(u.googleAppsFlag), MAX(u.salesforceFlag), MAX(u.zimbraFlag)
FROM rpt_paymentProfile p1 
  JOIN rpt_paymentProfile p2 ON p1.paymentProfileID = p2.parentPaymentProfileID 
  JOIN rpt_integrationRollupByUser u ON p2.ownerID = u.userID
WHERE p1.accountType IN (3)
  AND p2.accountTYPE IN (1,2)
  AND (u.googleFlag = 1 OR u.googleAppsFlag = 1 OR u.salesforceFlag = 1 OR u.zimbraFlag = 1)
GROUP BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_integrationRollupByPaymentProfile");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_clientLogCountsByPaymentProfile table - start ******** ", NOW();

/*Start rpt_clientLogCountsByPaymentProfile*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_clientLogCountsByPaymentProfile");


/* Sum the action counts by paymentProfile - this will rollup paymentProfiles to their parent too as the rpt_paymentProfileMaster table includes dup rows for profiles with parents  */
DROP TABLE IF EXISTS rpt_clientLogCountsByPaymentProfile;
CREATE TABLE IF NOT EXISTS rpt_clientLogCountsByPaymentProfile(
	paymentProfileID BIGINT, 
	last90DayLogCount INT, 
	lifetimeLogCount INT, 
	PRIMARY KEY(paymentProfileID))
;

SET AUTOCOMMIT = 0;
INSERT rpt_clientLogCountsByPaymentProfile (
	paymentProfileID, 
	last90DayLogCount, 
	lifetimeLogCount)
SELECT 
	p.masterPaymentProfileID, 
	SUM(last90DayLogCount), 
	SUM(lifetimeLogCount)
FROM rpt_paymentProfileMaster p 
JOIN rpt_clientLogCountsByUserArchived clcua ON p.paymentProfileID = clcua.paymentProfileID
GROUP BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_clientLogCountsByPaymentProfile");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_featureCountFromLogsRollupByUser table - start ******** ", NOW();

/*Start rpt_featureCountFromLogsRollupByUser*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser");


/*DROP TABLE IF EXISTS rpt_featureCountFromLogsRollupByUser;*/
/*CREATE TABLE IF NOT EXISTS 
rpt_featureCountFromLogsRollupByUser(
	userID BIGINT, 
	importCount INT, 
	usedTemplateCount INT,
	uploadFileCount INT,
	discussionSaveCount INT,
	formulaButtonCount INT,
	paymentFormViewCount INT,
	premiumFeaturesFormViewCount INT,
	faqFormViewCount INT,
	upgradeButtonPressCount INT,
	overviewVideoViewCount INT,
	PRIMARY KEY(userID));*/

SELECT MAX(userID) FROM rpt_featureCountFromLogsRollupByUser INTO @maxuserID;

SET AUTOCOMMIT = 0;
INSERT rpt_featureCountFromLogsRollupByUser(userID)
SELECT u.userID 
FROM userAccount u 
WHERE u.userID > @maxuserID
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser");

	

/*Start rpt_featureCountFromLogsRollupByUser importCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser ImportCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.importCount = (SELECT SUM(slr.logCount) 
			FROM arc_serverLogRollup slr
			JOIN arc_serverActionLookup sal ON slr.actionID = sal.actionID
			WHERE sal.formAction = 'fa_import_step2' AND slr.insertByUserID = fcr.userID)
		 WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "Sunday"
;
COMMIT;
SET AUTOCOMMIT = 1;
		 
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser ImportCount");


/*Start rpt_featureCountFromLogsRollupByUser usedTemplateCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser usedTemplateCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.usedTemplateCount = (SELECT SUM(slr.logCount) 
			FROM arc_serverLogRollup slr
			JOIN arc_serverActionLookup sal ON slr.actionID = sal.actionID
			WHERE sal.formAction = 'fa_useTemplate' AND slr.insertByUserID = fcr.userID)
		WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;
		
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser usedTemplateCount");


/*Start rpt_featureCountFromLogsRollupByUser uploadFileCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser uploadFileCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.uploadFileCount = (SELECT SUM(slr.logCount) 
		FROM arc_serverLogRollup slr
		JOIN arc_serverActionLookup sal ON slr.actionID = sal.actionID
		WHERE (sal.formAction = 'fa_createAttachment_flash' 
		OR sal.formAction = 'fa_createAttachmentWithFiles_html' 
		OR sal.formAction = 'fa_createAttachmentWithFiles_html5') 
		AND slr.insertByUserID = fcr.userID)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser uploadFileCount");

	
/*Start rpt_featureCountFromLogsRollupByUser discussionSaveCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser discussionSaveCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.discussionSaveCount = (SELECT SUM(slr.logCount) 
			FROM arc_serverLogRollup slr
			JOIN arc_serverActionLookup sal ON slr.actionID = sal.actionID
			WHERE sal.formAction = 'fa_saveDiscussion' AND slr.insertByUserID = fcr.userID)
		 WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;
		 
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser discussionSaveCount");

			
/*Start rpt_featureCountFromLogsRollupByUser formulaButtonCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser formulaButtonCount");


SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.formulaButtonCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr WHERE objectID = 5030 
	AND glr.insertByUserID = fcr.userID)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;
	
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser formulaButtonCount");


/*Start rpt_featureCountFromLogsRollupByUser paymentFormViewCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser paymentFormViewCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.paymentFormViewCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr WHERE objectID = 7018 
	AND glr.insertByUserID = fcr.userID)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "Sunday"
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser paymentFormViewCount");


/*Start rpt_featureCountFromLogsRollupByUser premiumFeaturesFormViewCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser premiumFeaturesFormViewCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.premiumFeaturesFormViewCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr WHERE objectID = 7030 
	AND glr.insertByUserID = fcr.userID)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser premiumFeaturesFormViewCount");


/*Start rpt_featureCountFromLogsRollupByUser faqFormViewCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser faqFormViewCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
SET fcr.faqFormViewCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr WHERE objectID = 7036 
	AND glr.insertByUserID = fcr.userID)
	WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser faqFormViewCount");


/*Start rpt_featureCountFromLogsRollupByUser upgradeButtonPressCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser upgradeButtonPressCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr
JOIN userAccount u ON fcr.userID = u.userID
SET fcr.upgradeButtonPressCount = 
	(SELECT SUM(logCount) FROM arc_clientEventRollup
	 WHERE parm1String = 'btn_upgrade' AND parm1Int = 7018 AND insertByUserID = u.userID
	 GROUP BY insertByUserID)
	 WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser upgradeButtonPressCount");

		
/*Start rpt_featureCountFromLogsRollupByUser overviewVideoViewCount*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_featureCountFromLogsRollupByUser overviewVideoViewCount");

SET AUTOCOMMIT = 0;
UPDATE rpt_featureCountFromLogsRollupByUser fcr   	/* overview video view count */
SET fcr.overviewVideoViewCount = (SELECT SUM(logCount) FROM arc_clientEventRollup glr WHERE (objectID = 8011  OR objectID = 8021)
AND actionID = 1 AND glr.insertByUserID = fcr.userID)
 WHERE DATE_FORMAT(CURRENT_DATE(),"%W" ) = "XXXSunday"
;
COMMIT;
SET AUTOCOMMIT = 1;
 
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_featureCountFromLogsRollupByUser overviewVideoViewCount");



SELECT "******************************************************************************************************************************", NOW();
SELECT "******** rpt_browserSessionsByUser table - start ******** ", NOW();

/*Start rpt_browserSessionsByUser*/

-- Start Logging 
CALL SMARTSHEET_START_LOG ("rpt_browserSessionsByUser");


DROP TABLE IF EXISTS rpt_browserSessionsByUser;
CREATE TABLE IF NOT EXISTS 
rpt_browserSessionsByUser(
	userID BIGINT, 
	totalCount INT, 
	iPadCount INT, 
	windowsCount INT, 	
	iOSCount INT, 
	androidCount INT, 
	mobileCount INT,
	iOSNativeAppCount INT, 
	androidNativeAppCount INT, 
	PRIMARY KEY(userID));

INSERT rpt_browserSessionsByUser(userID)
SELECT u.userID
FROM userAccount u;

/*UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.totalCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID);

UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.iPadCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND device = 'iPad');
	
UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.windowsCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND operatingSystem = 'Windows');

UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.iOSCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND operatingSystem = 'iOS');

UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.androidCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND operatingSystem = 'Android');*/
	
UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.mobileCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND device != 'Computer');

/*UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.iOSNativeAppCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND browserBucket = "iOS Native App");
	
UPDATE rpt_browserSessionsByUser bsbu
SET bsbu.androidNativeAppCount =
	(SELECT COUNT(*) FROM rpt_sessionLog rsl
	WHERE rsl.userID = bsbu.userID AND browserBucket = "Android Native App");*/
	
-- Stop Logging
CALL SMARTSHEET_STOP_LOG ("rpt_browserSessionsByUser");




select "******************************************************************************************************************************", NOW();
select "******** rpt_domainRollup table - start ******** ", NOW();

/*Start rpt_domainRollup*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_domainRollup insert");


DROP TABLE IF EXISTS rpt_domainRollup;
CREATE TABLE IF NOT EXISTS rpt_domainRollup(
	domain VARCHAR(50), 
	last30DaysLoginCount INT, 
	usersWhoLoggedInCount INT, 
	sheetCreatorsCount INT, 
	sheetCount INT, 
	paidUserCount INT, 
	googleAppsDomain TINYINT DEFAULT 0, 
	PRIMARY KEY(domain))
;

SET AUTOCOMMIT = 0;
INSERT rpt_domainRollup(domain, last30DaysLoginCount, usersWhoLoggedInCount, sheetCreatorsCount, sheetCount, paidUserCount)
SELECT 
	domain, 
	sum(last30DaysLoginCount),
	count(rpt_loginCountTotal.loginCount), 
	count(rpt_paymentProfile.paymentProfileID), 
	sum(rpt_containerCountsByUser.sheetCount),
	sum(CASE WHEN rpt_paymentProfile.productID >= 3 THEN 1 ELSE 0 END)
FROM rpt_containerCountsByUser
  left outer join rpt_featureCountRollupByUser on rpt_featureCountRollupByUser.userID = rpt_containerCountsByUser.userID
  left outer join rpt_loginCountTotal on rpt_loginCountTotal.userID = rpt_containerCountsByUser.userID
  left outer join rpt_paymentProfile on rpt_paymentProfile.mainContactUserID = rpt_featureCountRollupByUser.userID AND rpt_paymentProfile.accountType !=3
GROUP BY 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_domainRollup insert");

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_domainRollup update");

SET AUTOCOMMIT = 0;
UPDATE rpt_domainRollup rd
  JOIN googleAppsDomain gd ON rd.domain = gd.domain
SET rd.googleAppsDomain = 1
;
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_domainRollup update");

select "******************************************************************************************************************************", NOW();
select "******** rpt_paidDomains table - start ******** ", NOW();

/*Might be able to combine with domain rollup table in the future*/

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_paidDomains insert");

DROP TABLE IF EXISTS rpt_paidDomains; 
CREATE TABLE IF NOT EXISTS rpt_paidDomains (mainContactDomain VARCHAR(100), companyName VARCHAR(100), maxProduct VARCHAR(50), PRIMARY KEY (mainContactDomain));
INSERT INTO rpt_paidDomains (mainContactDomain, companyName, maxProduct)
SELECT rpt_paymentProfile.mainContactDomain,
rpt_paymentProfile.companyName,
CASE MAX(SMARTSHEET_PRODUCTRANK(rpt_paymentProfile.productID))
	WHEN 1 THEN "Cancelled"
	WHEN 2 THEN "Trial"
	WHEN 3 THEN "Free"
	WHEN 4 THEN "Basic"
	WHEN 5 THEN "Advanced"
	WHEN 6 THEN "Premium"
	WHEN 7 THEN "Team"
	WHEN 8 THEN "Team Plus"
	WHEN 9 THEN "Enterprise"
END AS maxProduct

FROM rpt_paymentProfile
WHERE rpt_paymentProfile.productID > 2 AND rpt_paymentProfile.paymentType NOT IN (4,5,7) AND paymentTotal > 0
GROUP BY 1
;

UPDATE rpt_paidDomains
LEFT OUTER JOIN rpt_paymentProfile ON rpt_paidDomains.mainContactDomain = rpt_paymentProfile.mainContactDomain
SET rpt_paidDomains.companyName = 
	(SELECT GROUP_CONCAT(companyName) 
	FROM  rpt_paymentProfile 
	WHERE rpt_paidDomains.mainContactDomain = rpt_paymentProfile.mainContactDomain);

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_paidDomains insert");



select "******************************************************************************************************************************", NOW();
select "******** rpt_userPaymentTermChanges table - start ******** ", NOW();


/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userPaymentTermChanges insert");


/* Monthly to Annual Plans */
DROP TABLE IF EXISTS rpt_userPaymentTermChanges;

CREATE TABLE IF NOT EXISTS rpt_userPaymentTermChanges  
(
	paymentProfileID BIGINT,
	IsMonthlyToAnnual varchar(1),
	CohortStartDate datetime,
	PlanSwitchDate datetime,
	DaysToUpgrade int,
	IsCurrentlyCancelled int,
	IsCancelledPriorToUpgrade int,
	IsDifferentParentProfile int,
	IsPlanUpgrade int,
	IsPlanDowngrade int,
	IsAnnualToMonthly tinyint
);

INSERT INTO rpt_userPaymentTermChanges (paymentProfileID, IsMonthlyToAnnual, CohortStartDate, PlanSwitchDate, DaysToUpgrade,
IsCurrentlyCancelled, IsCancelledPriorToUpgrade, IsDifferentParentProfile, IsPlanUpgrade, IsPlanDowngrade)
	SELECT 
	DISTINCT hppNew.paymentProfileID,  
	'1' AS IsMonthlyToAnnual, 
	hppOld.paymentStartDateTime CohortStartDate,
	MIN(hppNew.modifyDateTime) AS PlanSwitchDate,
	DATEDIFF(MIN(hppNew.modifyDateTime),hppOld.paymentStartDateTime) AS DaysToUpgrade,
	CASE 
		WHEN ppCurrent.productID<3 THEN 1
		ELSE 0 
	END AS IsCurrentlyCancelled,
	CASE 
		WHEN (hppCancel.paymentProfileID IS NOT NULL  AND hppCancel.modifyDateTime<MIN(hppNew.modifyDateTime)) THEN 1
		ELSE 0
	END AS IsCancelledPriorToUpgrade,
	CASE 
		WHEN hppNew.parentPaymentProfileID!=hppOld.parentPaymentProfileId THEN 1
		ELSE 0
	END AS IsDifferentParentProfile,
	CASE 
		WHEN hppNew.productID>hppOld.productID THEN 1
		ELSE 0
	END AS IsPlanUpgrade,
	CASE 
		WHEN hppNew.productID<hppOld.productID THEN 1
		ELSE 0
	END AS IsPlanDowngrade	

	FROM hist_paymentProfile hppNew 
		JOIN hist_paymentProfile hppOld 
			ON hppNew.paymentProfileID=hppOld.paymentProfileID AND hppOld.accountType!=3
		LEFT OUTER JOIN hist_paymentProfile hppCancel 
			ON hppNew.paymentProfileID=hppCancel.paymentProfileID AND hppCancel.accountType!=3 AND hppCancel.modifyDateTime>hppOld.paymentStartDateTime AND hppCancel.productID<3
		LEFT OUTER JOIN rpt_paymentProfile ppCurrent
			ON ppCurrent.paymentProfileID = hppNew.paymentProfileID AND ppCurrent.accountType!=3
	WHERE hppOld.modifyDateTime >= '2009-01-01'
	AND hppNew.accountType!=3
	AND hppNew.modifyDateTime > hppOld.modifyDateTime
	AND hppOld.paymentTerm = 1
	AND hppNew.paymentTerm = 12
	GROUP BY 1;

CREATE UNIQUE INDEX TermChanges ON rpt_userPaymentTermChanges (paymentProfileID);

-- ALTER TABLE rpt_userPaymentTermChanges ADD IsAnnualToMonthly TINYINT(2) DEFAULT 0;


/* Insert Into Payment downgrades from Annual to Monthly */
SET AUTOCOMMIT = 0;
INSERT IGNORE INTO rpt_userPaymentTermChanges 
(
	paymentProfileID, 
	CohortStartDate, 
	PlanSwitchDate, 
	DaystoUpgrade,
	IsCurrentlyCancelled, 
	isCancelledPriorToUpgrade,
	isDifferentParentProfile, 
	isPlanUpgrade, 
	isPlanDowngrade, 
	isAnnualtoMonthly
)
	SELECT 
		DISTINCT hppNew.paymentProfileID,  hppOld.paymentStartDateTime CohortStartDate,
		MIN(hppNew.modifyDateTime) AS PlanSwitchDate,
		DATEDIFF(MIN(hppNew.modifyDateTime),hppOld.paymentStartDateTime) AS DaysToUpgrade,
		CASE 
			WHEN ppCurrent.productID<3 THEN 1
			ELSE 0 
		END AS IsCurrentlyCancelled,
		CASE 
			WHEN (hppCancel.paymentProfileID IS NOT NULL  AND hppCancel.modifyDateTime<MIN(hppNew.modifyDateTime)) THEN 1
			ELSE 0
		END AS IsCancelledPriorToUpgrade,
		
		CASE 
			WHEN hppNew.parentPaymentProfileID!=hppOld.parentPaymentProfileId THEN 1
			ELSE 0
		END AS IsDifferentParentProfile,
		CASE 
			WHEN hppNew.productID>hppOld.productID THEN 1
			ELSE 0
		END AS IsPlanUpgrade,
		CASE 
			WHEN hppNew.productID<hppOld.productID THEN 1
			ELSE 0
		END AS IsPlanDowngrade,
		'1' AS IsAnnualtoMonthly 

		FROM hist_paymentProfile hppNew 
			JOIN hist_paymentProfile hppOld 
				ON hppNew.paymentProfileID=hppOld.paymentProfileID AND hppOld.accountType!=3
			LEFT OUTER JOIN hist_paymentProfile hppCancel 
				ON hppNew.paymentProfileID=hppCancel.paymentProfileID AND hppCancel.accountType!=3 AND hppCancel.modifyDateTime>hppOld.paymentStartDateTime AND hppCancel.productID<3
			LEFT OUTER JOIN rpt_paymentProfile ppCurrent
				ON ppCurrent.paymentProfileID = hppNew.paymentProfileID AND ppCurrent.accountType!=3
		WHERE hppOld.modifyDateTime >= '2009-01-01'
		AND hppNew.accountType!=3
		AND hppNew.modifyDateTime > hppOld.modifyDateTime
		AND hppOld.paymentTerm = 12
		AND hppNew.paymentTerm = 1
		GROUP BY 1
;
COMMIT;
		
		
UPDATE rpt_userPaymentTermChanges
SET IsMonthlyToAnnual = 0
WHERE IsMonthlyToAnnual IS NULL
OR IsMonthlyToAnnual = " "
;
COMMIT;
SET AUTOCOMMIT = 1;
		
/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userPaymentTermChanges insert");

select "******************************************************************************************************************************", NOW();
select "******** rpt_userProductTypeChanges table - start ******** ", NOW();

/*Start Logging*/
CALL SMARTSHEET_START_LOG ("rpt_userProductTypeChanges insert");

DROP TABLE IF EXISTS rpt_userProductTypeChanges ;
/* Create table with PaymentProfiles that moved from Individual Plans to Group Plans */

CREATE TABLE IF NOT EXISTS rpt_userProductTypeChanges 
(
	paymentProfileID bigint,
	IsUpgradeToGroup varchar(1),
	CohortStartDate datetime,
	PlanSwitchDate datetime,
	DaysToUpgrade int,
	IsCurrentlyCancelled int,
	IsCancelledPriorToUpgrade int,
	IsCancelledPriorToDowngrade int
)
;

	INSERT INTO rpt_userProductTypeChanges (paymentProfileId, IsUpgradeToGroup, CohortStartDate, PlanSwitchDate, DaysToUpgrade, IsCurrentlyCancelled,
	IsCancelledPriorToUpgrade)
	SELECT 
	DISTINCT hppNew.paymentProfileID, 
	'1' AS IsUpgradeToGroup, 
	hppOld.paymentStartDateTime CohortStartDate,
	MIN(hppNew.modifyDateTime) AS PlanSwitchDate,
	DATEDIFF(MIN(hppNew.modifyDateTime),hppOld.paymentStartDateTime) AS DaysToUpgrade,
	CASE 
		WHEN ppCurrent.productID<3 THEN 1
		ELSE 0 
	END AS IsCurrentlyCancelled,
	CASE 
		WHEN (hppCancel.paymentProfileID IS NOT NULL  AND hppCancel.modifyDateTime<MIN(hppNew.modifyDateTime)) THEN 1
		ELSE 0
	END AS IsCancelledPriorToUpgrade

	FROM hist_paymentProfile hppNew 
		JOIN hist_paymentProfile hppOld 
			ON hppNew.paymentProfileID=hppOld.paymentProfileID AND hppOld.accountType!=3
		LEFT OUTER JOIN hist_paymentProfile hppCancel 
			ON hppNew.paymentProfileID=hppCancel.paymentProfileID AND hppCancel.accountType!=3 AND hppCancel.modifyDateTime>hppOld.paymentStartDateTime AND hppCancel.productID<3
		LEFT OUTER JOIN rpt_paymentProfile ppCurrent
			ON ppCurrent.paymentProfileID = hppNew.paymentProfileID AND ppCurrent.accountType!=3
	WHERE hppOld.modifyDateTime >= '2009-01-01'
	AND hppOld.accountType!=3
	AND hppOld.productID IN(3,4,5)
	AND hppNew.productID IN(6,7,8)
	AND hppNew.modifyDateTime > hppOld.modifyDateTime
	AND hppNew.ProductID>hppOld.productID
	AND hppNew.productID != hppOld.productID
	GROUP BY 1;

CREATE UNIQUE INDEX PlansUpgraded ON rpt_userProductTypeChanges (paymentProfileID);

ALTER TABLE rpt_userProductTypeChanges
	ADD IsTeamtoEnt TINYINT(2) DEFAULT 0, 
	ADD isDifferentParentProfile TINYINT(2) DEFAULT 0;

/* append to table with Users who moved from Team to Ent Plans */
SET AUTOCOMMIT = 0;	
INSERT IGNORE INTO rpt_userProductTypeChanges 
(
	paymentProfileID, 
	CohortStartDate, 
	PlanSwitchDate, 
	DaysToUpgrade, 
	isCurrentlyCancelled, 
	isCancelledPriorToUpgrade, 
	IsTeamtoEnt, 
	isDifferentParentProfile
)
	SELECT 
	DISTINCT hppNew.paymentProfileID,  
	hppOld.paymentStartDateTime CohortStartDate,
	MIN(hppNew.modifyDateTime) AS PlanSwitchDate,
	DATEDIFF(MIN(hppNew.modifyDateTime),hppOld.paymentStartDateTime) AS DaysToUpgrade,
	CASE 
		WHEN ppCurrent.productID<3 THEN 1
		ELSE 0 
	END AS IsCurrentlyCancelled,
	CASE 
		WHEN (hppCancel.paymentProfileID IS NOT NULL  AND hppCancel.modifyDateTime<MIN(hppNew.modifyDateTime)) THEN 1
		ELSE 0
	END AS IsCancelledPriorToUpgrade,
	'1' AS IsTeamtoEnt,
	CASE 
		WHEN hppNew.parentPaymentProfileID!=hppOld.parentPaymentProfileId THEN 1
		ELSE 0
	END AS IsDifferentParentProfile

	FROM hist_paymentProfile hppNew 
		JOIN hist_paymentProfile hppOld 
			ON hppNew.paymentProfileID=hppOld.paymentProfileID AND hppOld.accountType!=3
		LEFT OUTER JOIN hist_paymentProfile hppCancel 
			ON hppNew.paymentProfileID=hppCancel.paymentProfileID AND hppCancel.accountType!=3 AND hppCancel.modifyDateTime>hppOld.paymentStartDateTime AND hppCancel.productID<3
		LEFT OUTER JOIN rpt_paymentProfile ppCurrent
			ON ppCurrent.paymentProfileID = hppNew.paymentProfileID AND ppCurrent.accountType!=3
	WHERE hppOld.modifyDateTime >= '2009-01-01'
	AND hppNew.accountType!=3
	AND hppOld.productID IN(6,8)
	AND hppNew.productID IN(7)
	AND hppNew.modifyDateTime > hppOld.modifyDateTime
	AND hppNew.ProductID>hppOld.productID
	AND hppNew.productID != hppOld.productID
	GROUP BY 1
;
COMMIT;
	
	
UPDATE rpt_userProductTypeChanges
SET IsUpgradeToGroup = 0
WHERE IsUpgradeToGroup IS NULL
OR IsUpgradeToGroup = " "
;	
COMMIT;
SET AUTOCOMMIT = 1;

/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("rpt_userProductTypeChanges insert");


SELECT "******************************************************************************************************************************", NOW();
SELECT "******** End of PrepV2 #3 ******** ", NOW();
/*End*/


/*Stop Logging*/
CALL SMARTSHEET_STOP_LOG ("PrepV2 #3");
