# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_remarketingSource()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_remarketingSource//

create procedure etl_rpt_remarketingSource(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
declare v_processId int;
call utl_logProcessStart('etl_rpt_remarketingSource',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

INSERT INTO rpt_main_02.rpt_remarketingSource
SELECT 
r.userID,
r.signupRequestID, 
r.InsertDateTime,
DATE_FORMAT(r.insertDateTime, '%Y*%m(%b)') AS signupMonth, 
rpt_main_02.SMARTSHEET_WEEK(r.insertDateTime) AS signupWeek, 
DATE_FORMAT(r.insertDateTime, '%Y*%m*%d') AS signupDay, 
CASE source.itemValue 
	WHEN 1 THEN 'Adroll Remarketing'
	WHEN 2 THEN 'Adroll Facebook Remarketing'
	WHEN 3 THEN 'Remarketing List for Search Ads'
	WHEN 4 THEN 'Remarketing List for Search Ads International'
	WHEN 5 THEN 'Google Remarketing'
ELSE NULL END AS RemarketingSource,
ad.itemValue AS adVersion,
-- campaign.itemValue AS RemarketingCampaign,
CONCAT(campaign.itemValue, " - ", IF(campaignLookup.campaignDescription IS NULL, "not found", campaignLookup.campaignDescription)) AS RemarketingCampaign, 
CONCAT(segment.itemValue, " - ", IF(segmentLookup.segmentDescription IS NULL, "not found", segmentLookup.segmentDescription)) AS RemarketingSegment
FROM ss_core_02.signupRequest r
JOIN (SELECT DISTINCT signupRequestID FROM rpt_main_02.rpt_signupRequestTrackingItem WHERE itemName LIKE 'rem%') rem ON r.signupRequestID=rem.signupRequestID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem source ON r.signupRequestID=source.signupRequestID AND source.itemName = 'rems'
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem ad ON r.signupRequestID=ad.signupRequestID AND ad.itemName = 'rema'
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem campaign ON r.signupRequestID=campaign.signupRequestID AND campaign.itemName = 'remc'
LEFT OUTER JOIN rpt_main_02.ref_campaignLookup campaignLookup ON campaign.itemValue=campaignLookup.campaignID
LEFT OUTER JOIN rpt_main_02.rpt_signupRequestTrackingItem segment ON r.signupRequestID=segment.signupRequestID AND segment.itemName = 'remm'
LEFT OUTER JOIN rpt_main_02.ref_campaignSegmentLookup segmentLookup ON segment.itemValue=segmentLookup.segmentID
LEFT OUTER JOIN rpt_main_02.rpt_remarketingSource  ins ON r.signupRequestID =ins.signupRequestID
-- WHERE source.itemValue IS NULL
WHERE r.resultStatus = 1
AND ins.signupRequestID IS NULL
ORDER BY 1
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;