# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
use test;

delimiter //

drop procedure if exists getChildNodes//

create procedure buildDag(in parentNodeId int, out result varchar(4000)) 
begin

# Variable Declaration
declare tmpDestId varchar(50);
declare tmpDestTable varchar(50);
declare tmpDestDb varchar(50);
declare tmpSrcId varchar(50);
declare tmpSrcTable varchar(50);
declare tmpSrcDb varchar(50);
declare tmpThread varchar(50);



set result = tmpFct1;

if st > 0 then
   set tmpFct1 = lastProduct*st;
   call fact(st-1,tmpFct1,tmpFct2);
else 
   #set result = tmpFct1;
   select lastProduct;
   set result = lastProduct;
end if;

end//

delimiter ;

select -1 into @f;
set max_sp_recursion_depth = 20;
call fact(4,1,@f);