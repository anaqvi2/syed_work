# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the siteSettingElementValue table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_siteSettingElementValue()' as '' from dual;

delimiter //

drop procedure if exists etl_siteSettingElementValue//

create procedure etl_siteSettingElementValue(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_siteSettingElementValue',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT MAX(siteSettingElementValueID) FROM siteSettingElementValue);
set v_destMaxModTime = (SELECT MAX(modifyDateTime) FROM siteSettingElementValue);

INSERT INTO rpt_main_02.siteSettingElementValue  
SELECT 
	ssev.siteSettingElementValueID,
	ssev.siteSettingElementName,
	ssev.valueString,
	ssev.valueNumeric,
	ssev.valueBoolean,
	ssev.valueDateTime,
	ssev.userID,
	ssev.shipToUI,
	ssev.insertDateTime,
	ssev.insertByUserID,
	ssev.modifyDateTime,
	ssev.modifyByUserID,
	ssev.sessionLogID,
	ssev.dataTimestamp
FROM ss_core_02.siteSettingElementValue ssev
LEFT OUTER JOIN siteSettingElementValue ins ON ssev.siteSettingElementValueID=ins.siteSettingElementValueID
LEFT OUTER JOIN siteSettingElementValue ins2 ON ssev.userID=ins2.userID AND ssev.siteSettingElementName=ins2.siteSettingElementName
WHERE ins.siteSettingElementValueID IS NULL
AND ins2.userID IS NULL
AND ssev.siteSettingElementValueID > v_destMaxId
;

UPDATE siteSettingElementValue ssev
JOIN ss_core_02.siteSettingElementValue u ON ssev.siteSettingElementValueID=u.siteSettingElementValueID
SET
	ssev.siteSettingElementValueID=u.siteSettingElementValueID,
	ssev.siteSettingElementName=u.siteSettingElementName,
	ssev.valueString=u.valueString,
	ssev.valueBoolean=u.valueBoolean,
	ssev.valueDateTime=u.valueDateTime,
	ssev.userID=u.userID,
	ssev.shipToUI=u.shipToUI,
	ssev.insertDateTime=u.insertDateTime,
	ssev.insertByUserID=u.insertByUserID,
	ssev.modifyDateTime=u.modifyDateTime,
	ssev.modifyByUserID=u.modifyByUserID,
	ssev.sessionLogID=u.sessionLogID,
	ssev.dataTimestamp=u.dataTimestamp
WHERE u.modifyDateTime > v_destMaxModTime
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;