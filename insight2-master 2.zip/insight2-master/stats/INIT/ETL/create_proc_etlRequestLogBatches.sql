# Insight
# Stored Procedure for ETL from ss_log_02
# Moves 30M rows from requestLog table to arc_requestLog.
# Revision History
# 2017-05-26:

drop procedure if exists etl_requestLog_batches;
create procedure PROCEDURE etl_requestLog_batches(a_parentProcessId int
								,a_levelCtrlNum tinyint)
begin

declare maxRequestLogId bigint;
declare v_processId int;
declare v_processIdChild int;
call utl_logProcessStart( 'etl_RequestLog',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set @maxRequestLogId = (SELECT MAX(requestLogID) FROM arc_requestLog);




call utl_logProcessStart('etl_RequestLog',v_processId,'arc_serverActionLookup','DEBUG',a_levelCtrlNum, v_processIdChild);

INSERT IGNORE arc_serverActionLookup(urlActionID, formName, formAction)
select rl.urlActionId, rl.formName, rl.formAction
from
(
SELECT DISTINCT r.urlActionID, r.formName, r.formAction 
FROM ss_log_02.requestLog r 
where  requestLogID > @maxRequestLogId 
and requestLogID <= (@maxRequestLogId+30000000)
) rl
LEFT OUTER JOIN arc_serverActionLookup l 
    ON  rl.urlActionID = l.urlActionID 
	AND rl.formName = l.formName
	AND rl.formAction = l.formAction
where l.urlActionID IS NULL;

call utl_logProcessEnd(v_processIdChild);


INSERT INTO arc_requestLog 
SELECT * 
FROM ss_log_02.requestLog 
WHERE requestLogID > @maxRequestLogId
and requestLogID <= (@maxRequestLogId+30000000)
;

call utl_logProcessEnd(v_processId);

end
