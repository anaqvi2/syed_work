#Create tables that define source and destination tables with associated processes
# Revision History
# 2014-03-05:  BMW:  Init
select count(*), count(concat(destdb, desttable,sourcedb,sourcetable)) 
from etl_dbThread a
where sourceDb != 'local';

select * from etl_dbThread;

use test;

drop table if exists etl_dbThread;
create table if not exists etl_dbThread(
 threadId int not null auto_increment primary key
,destDb varchar(50) not null
,destTable varchar(50) not null
,sourceDb varchar(50) not null
,sourceTable varchar(50) not null
,storedProcedure varchar(50)
,status tinyint not null
,notes varchar(2000)
);
ALTER TABLE etl_dbThread AUTO_INCREMENT = 100;

create table if not exists etl_process (
 processId int auto_increment primary key
,processName varchar(200)
,parentProcessId varchar(20)
,frequency varchar(20)
,status tinyint
,notes varchar(2000)
);

create table if not exists etl_processThreads(
processId int	
,threadId int
,seriesOrder tinyint
,PRIMARY KEY (processId,threadId)
);


# Inserts from DataCorePull.
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','accountChangeTicket','ss_core_02','accountChangeTicket','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','accountChangeTicket','ss_core_02','accountChangeTicket','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_appLog','ss_log_02','appLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEvent','ss_log_02','clientEvent','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_mailDistribution','ss_core_02','mailDistribution','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_requestLogRESTSessions','ss_log_02','requestLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_requestLog','ss_log_02','requestLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_serverActionLookup','ss_log_02','requestLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_serverLogRollup','rpt_main_02','arc_serverActionLookup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_serverLogRollup','ss_log_02','requestLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_sessionLog','ss_core_02','sessionLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_userSessionActivity','rpt_main_02','rpt_newSessionLogRollupByUser','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_userSessionActivity','ss_core_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','brand','ss_core_02','brand','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','contact','rpt_main_02','stg_contact_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','container','ss_core_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','container','rpt_main_02','stg_container_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','currencyExchange','ss_core_02','currencyExchange','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','discussion','rpt_main_02','stg_discussion_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','docAttachment','rpt_main_02','stg_docAttachment_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','googleAppsDomain','ss_core_02','googleAppsDomain','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','grid','ss_core_02','grid','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','gridAccessMap','ss_core_02','gridAccessMap','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','gridAccessMap','rpt_main_02','stg_gridAccessMap_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_currencyExchange','ss_core_02','hist_currencyExchange','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_paymentProfile','rpt_main_02','hist_currencyExchange','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_paymentProfile','ss_core_02','hist_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_paymentProfile','rpt_main_02','stg_histpaymentProfile_update','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_userAccount','ss_core_02','hist_userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','hist_userAccount','rpt_main_02','stg_histuserAccount_update','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','openIDIdentifier','ss_core_02','openIDIdentifier','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','organization','ss_core_02','organization','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','rpt_signupSource','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','rpt_userIPLocation','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','ref_country','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','ref_ipLocation','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','ref_ipNumber','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_localeCountryLanguage','ss_core_02','ref_locale','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_localeCountryLanguage','ss_core_02','ref_Country','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_localeCountryLanguage','ss_core_02','ref_Language','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','ref_ipAddressInfo','rpt_main_02','ref_region','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','reminder','rpt_main_02','stg_reminder_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','accessToken','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','accessTokenSession','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','apiClient','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','apiDeveloper','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','rpt_main_02','arc_requestLogRESTSessions','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','hist_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','organization','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','organizationUserRole','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_apiCallsRollup','ss_core_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerList','rpt_main_02','container','',0,'');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerList','rpt_main_02','grid','',0,'');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerList','rpt_main_02','gridAccessMap','',0,'');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerList','ss_core_02','languageElement','',0,'');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_newSessionLogRollupByUser','ss_core_02','sessionLog','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_organizationUser','ss_core_02','organizationUserRole','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','hist_currencyExchange','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','hist_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','ss_core_02','hist_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','ss_core_02','organization','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','ss_core_02','organizationUserRole','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','ss_core_02','paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','rpt_paymentProfileContact','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','rpt_paymentProfileSheetCount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','ss_core_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileContact','ss_core_02','organization','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileContact','ss_core_02','paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileMaster','rpt_main_02','brand','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileMaster','rpt_main_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileMaster','rpt_main_02','grid','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileMaster','ss_core_02','paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileMaster','rpt_main_02','workspace','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfileSheetCount','rpt_main_02','rpt_paymentProfileMaster','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_remarketingSource','rpt_main_02','ref_campaignLookup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_remarketingSource','rpt_main_02','ref_campaignSegmentLookup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_remarketingSource','rpt_main_02','rpt_signupRequestTrackingItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_remarketingSource','ss_core_02','signupRequest','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupRequestTrackingItem','ss_core_02','signupRequestTrackingItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupRequestTrackingItem','rpt_main_02','stg_signupRequestTrackingItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','ss_core_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','rpt_main_02','ref_campaignLookup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','rpt_main_02','ref_campaignSegmentLookup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','rpt_main_02','ref_ipAddressInfo','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','rpt_main_02','rpt_signupRequestTrackingItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','ss_core_02','signupRequest','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_signupSource','rpt_main_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemGroupInfo','rpt_main_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemGroupInfo','rpt_main_02','rpt_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemGroupInfo','rpt_main_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemGroupInfo','ss_core_02','workItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemGroupInfo','ss_core_02','workItemGroup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemResultSummary','ss_core_02','workItemResult','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemSummary','rpt_main_02','rpt_workItemResultSummary','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_workItemSummary','ss_core_02','workItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','sheetLink','rpt_main_02','stg_sheetLink_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','sheetLink','ss_core_02','sheetLink','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','siteSettingElementValue','ss_core_02','siteSettingElementValue','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_clientEventActions','ss_log_02','clientEvent','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_contact_data','rpt_main_02','contact','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_contact_data','ss_core_02','contact','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_container_data','rpt_main_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_container_data','ss_core_02','container','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_discussion_data','rpt_main_02','discussion','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_discussion_data','ss_core_02','discussion','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_docAttachment_data','rpt_main_02','docAttachment','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_docAttachment_data','ss_core_02','docAttachment','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_histpaymentProfile_update','ss_core_02','hist_paymentProfile','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_histuserAccount_update','ss_core_02','hist_userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_reminder_data','rpt_main_02','reminder','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_reminder_data','ss_core_02','reminder','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sheetLink_data','rpt_main_02','sheetLink','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sheetLink_data','ss_core_02','sheetLink','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_signupRequestTrackingItem','rpt_main_02','stg_signupTrackingData','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_signupTrackingData','ss_core_02','signupRequest','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_signupTrackingData','ss_core_02','signupRequestTrackingItem','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_workItemGroup_data','rpt_main_02','workItemGroup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_workItemGroup_data','ss_core_02','workItemGroup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','userAccount','ss_core_02','userAccount','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','userAccount','rpt_main_02','ref_localeCountryLanguage','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','template','ss_core_02','template','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','workItemGroup','rpt_main_02','stg_workItemGroup_data','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','workItemGroup','ss_core_02','workItemGroup','',1,'dataCorePull');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','workspace','ss_core_02','workspace','',1,'dataCorePull');

insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_users_no_ip_country','rpt_main_02','rpt_userIPLocation','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_users_noIP_lastSession','rpt_main_02','stg_users_no_ip_country','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_users_noIP_lastSession','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_userIPLocationUpdate','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_userIPLocationUpdate','rpt_main_02','rpt_userIPLocation','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sharedSheets','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sharedSheets','rpt_main_02','stg_containerCount_users_update','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sharedSheets','rpt_main_02','rpt_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sharedSheets','rpt_main_02','gridAccessMap','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_sharedSheets','rpt_main_02','container','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_minWinProduct','rpt_main_02','stg_minWinProduct','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_minWinProduct','rpt_main_02','rpt_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_minWinProduct','rpt_main_02','hist_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_dailyClientEvents','rpt_main_02','arc_clientEvent','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_dailyClientEventRollup','rpt_main_02','stg_dailyClientEvents','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_dailyClientEventRollup','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCountsByUser_data','rpt_main_02','stg_sharedSheets','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCountsByUser_data','rpt_main_02','stg_containerCount_users_update','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCountsByUser_data','rpt_main_02','sheetLink','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCountsByUser_data','rpt_main_02','container','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCount_users_update','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCount_users_update','rpt_main_02','stg_gridAccessMap_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCount_users_update','rpt_main_02','stg_container_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','stg_containerCount_users_update','rpt_main_02','rpt_containerCountsByUser','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','stg_users_noIP_lastSession','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','stg_userIPLocationUpdate','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','rpt_userIPLocation','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','rpt_signupSource','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','rpt_loginCountTotal','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','ref_ipAddressInfo','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userIPLocation','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_trials','rpt_main_02','rpt_paymentProfileContact','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_trials','rpt_main_02','hist_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_trials','rpt_main_02','arc_clientEventRollup','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_trials','rpt_main_02','arc_clientEvent','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_sessionLog','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','rpt_paymentProfileContact','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','rpt_loginCountTotal','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_loginCountTotal','rpt_main_02','arc_userSessionActivity','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_integrationRollupByUser','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_integrationRollupByUser','rpt_main_02','rpt_signupSource','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_integrationRollupByUser','rpt_main_02','openIDIdentifier','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','workItemGroup','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_workItemGroup_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_sheetLink_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_reminder_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_gridAccessMap_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_docAttachment_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_discussion_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','stg_contact_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','sheetLink','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','rpt_featureCountRollupByUser','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','reminder','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','gridAccessMap','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','docAttachment','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','discussion','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','container','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountRollupByUser','rpt_main_02','contact','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerCountsByUser','rpt_main_02','stg_containerCountsByUser_data','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_containerCountsByUser','rpt_main_02','rpt_containerCountsByUser','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','stg_dailyClientEventRollup','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','rpt_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','rpt_clientLogCountsByUserArchived','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','arc_clientEventRollup','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientEvent_clean','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientEvent_clean','rpt_main_02','arc_clientEvent','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','rpt_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','rpt_loginCountTotal','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','rpt_featureCountRollupByUser','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','rpt_containerCountsByUser','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_wellQualifiedLeads','rpt_main_02','rpt_clientLogCountsByUserArchived','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_paymentProfile_firstWinProduct','rpt_main_02','stg_minWinProduct','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_paymentProfile_firstWinProduct','rpt_main_02','hist_paymentProfile','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_paidAccountTransfers','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_paidAccountTransfers','rpt_main_02','arc_requestLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEventRollup','rpt_main_02','rpt_clientEvent_clean','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEventRollup','rpt_main_02','arc_sessionLog','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_ISPDomains','rpt_main_02','userAccount','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_DailyWellQualifiedLeads','rpt_main_02','arc_wellQualifiedLeads','',1,'data1');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_DailyWellQualifiedLeads','rpt_main_02','arc_DailyWellQualifiedLeads','',1,'data1');

insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEventTemplateGallerySearch','rpt_main_02','arc_clientEvent','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEventSiteSearchTerms','rpt_main_02','arc_clientEvent','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','arc_clientEventTemplateGalleryCategories','rpt_main_02','arc_clientEvent','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','arc_clientEventRollup','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','rpt_loginCountTotal','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByUserArchived','rpt_main_02','userAccount','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userSourceIP','rpt_main_02','arc_sessionLog','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userSourceIP','rpt_main_02','rpt_userSourceIP','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_cancelComment','rpt_main_02','siteSettingElementValue','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_cancelComment','rpt_main_02','rpt_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paymentProfile','rpt_main_02','rpt_cancelComment','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userSessionActivityPT','rpt_main_02','arc_userSessionActivity','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userAdditionHierarchy','rpt_main_02','userAccount','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userAncestor','rpt_main_02','userAccount','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userAncestor','rpt_main_02','rpt_userAdditionHierarchy','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_loginCountByType','rpt_main_02','arc_sessionLog','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_loginCountWeekly','rpt_main_02','rpt_sessionLog','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_loginFailure','rpt_main_02','rpt_sessionLog','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_integrationRollupByPaymentProfile','rpt_main_02','rpt_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_integrationRollupByPaymentProfile','rpt_main_02','rpt_integrationRollupByUser','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByPaymentProfile','rpt_main_02','rpt_paymentProfileMaster','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_clientLogCountsByPaymentProfile','rpt_main_02','rpt_clientLogCountsByUserArchived','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountFromLogsRollupByUser','rpt_main_02','userAccount','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountFromLogsRollupByUser','rpt_main_02','arc_serverLogRollup','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountFromLogsRollupByUser','rpt_main_02','arc_serverActionLookup','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_featureCountFromLogsRollupByUser','rpt_main_02','arc_clientEventRollup','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_browserSessionsByUser','rpt_main_02','userAccount','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_browserSessionsByUser','rpt_main_02','rpt_sessionLog','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_domainRollup','rpt_main_02','rpt_containerCountsByUser','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_domainRollup','rpt_main_02','rpt_featureCountRollupByUser','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_domainRollup','rpt_main_02','rpt_loginCountTotal','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_domainRollup','rpt_main_02','rpt_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_domainRollup','rpt_main_02','googleAppsDomain','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_paidDomains','rpt_main_02','rpt_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userPaymentTermChanges','rpt_main_02','hist_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userPaymentTermChanges','rpt_main_02','rpt_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userProductTypeChanges','rpt_main_02','hist_paymentProfile','',1,'data3');
insert into etl_dbThread(destDb,destTable,sourceDb,sourceTable,storedProcedure,status,notes) values('rpt_main_02','rpt_userProductTypeChanges','rpt_main_02','rpt_paymentProfile','',1,'data3');


update etl_dbThread
set storedProcedure = concat('etl_',destTable);
