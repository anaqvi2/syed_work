# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_mainDistribution table.
# Does not consider deletes.
#
# Revision Historyarc_mainDistribution
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_mainDistribution()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_mainDistribution//

create procedure etl_arc_mainDistribution(a_parentProcessId int
                         ,a_levelCtrlNum tinyint
						 ,a_newMaxMailDistributionID int)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_arc_mainDistribution',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (SELECT ifnull(MAX(mailDistributionID),0) FROM arc_mailDistribution);

INSERT arc_mailDistribution
SELECT * 
FROM ss_core_02.mailDistribution
WHERE mailDistributionID > v_destMaxId 
   and mailDistributionID <= a_newMaxMailDistributionID
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;