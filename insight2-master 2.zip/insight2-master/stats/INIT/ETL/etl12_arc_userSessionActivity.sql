# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the arc_userSessionActivity table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_arc_userSessionActivity()' as '' from dual;

delimiter //

drop procedure if exists etl_arc_userSessionActivity//

create procedure etl_arc_userSessionActivity(a_parentProcessId int
                                            ,a_levelCtrlNum tinyint
											,a_newMaxSessionLogId int)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxUserId int default 0; 
declare v_destMaxSessionId int default 0; 
call utl_logProcessStart('etl_arc_userSessionActivity',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

/* find starting point for new users */
set v_destMaxUserId = (SELECT ifnull(MAX(userID),0) FROM arc_userSessionActivity);

/* add the new users - default count to zero so we can add to it */
INSERT arc_userSessionActivity(userID, sessionCount)
SELECT u.userID, 0 
FROM ss_core_02.userAccount u
WHERE u.userID > v_destMaxUserId
;

/**************************************/	
/* find starting point for new session */
set v_destMaxSessionId = (SELECT ifnull(MAX(lastSessionID),0) FROM arc_userSessionActivity);


/* create table to hold new session rollup data */
DROP TABLE IF EXISTS rpt_newSessionLogRollupByUser;
CREATE TABLE rpt_newSessionLogRollupByUser (
	userID 				INT, 
	firstSessionID 		INT, 
	firstSessionDateTime DATETIME, 
	lastSessionID 		INT, 
	lastSessionDateTime DATETIME, 
	sessionCount 		INT, 
	PRIMARY KEY(userID))
;
	
	
/* select the new sessions into a table for processing */
INSERT rpt_newSessionLogRollupByUser(
	userID, 
	firstSessionID, 
	firstSessionDateTime, 
	lastSessionId, 
	lastSessionDateTime, 
	sessionCount)
SELECT 
	sl.userID, 
	MIN(sl.sessionLogID), 
	MIN(sl.insertDateTime), 
	MAX(sl.sessionLogID), 
	MAX(sl.insertDateTime), 
	COUNT(sl.sessionLogID)
FROM ss_core_02.sessionLog sl
WHERE sl.sessionLogID > v_destMaxSessionId 
   AND sl.sessionLogID <= a_newMaxSessionLogId 
   AND sl.loginAuthResult = 1
GROUP BY 1
;


/* set the intial values only if null */
UPDATE arc_userSessionActivity usa
JOIN rpt_newSessionLogRollupByUser nsru ON nsru.userID = usa.userID
SET usa.firstSessionID = nsru.firstSessionID, usa.firstSessionDateTime = nsru.firstSessionDateTime
WHERE usa.firstSessionID IS NULL
;

/* update the last values and running count*/
UPDATE arc_userSessionActivity usa
JOIN rpt_newSessionLogRollupByUser nsru ON nsru.userID = usa.userID
SET 
	usa.lastSessionID 		= nsru.lastSessionID, 
	usa.lastSessionDateTime = nsru.lastSessionDateTime,	
	usa.sessionCount 		= nsru.sessionCount  + usa.sessionCount;


call utl_logProcessEnd(v_processId);

end//

delimiter ;