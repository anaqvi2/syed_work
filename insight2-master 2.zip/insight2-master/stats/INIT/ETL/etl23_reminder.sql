# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_reminder()' as '' from dual;

delimiter //

drop procedure if exists etl_reminder//

create procedure etl_reminder(a_parentProcessId int
                             ,a_levelCtrlNum tinyint
							 ,a_newMaxReminderId int)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_reminder',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(reminderId) from reminder);
set v_destMaxModTime = (select modifyDateTime from reminder where reminderId = v_destMaxId);

replace into reminder
select g.*
from ss_core_02.reminder g
where modifyDateTime >= v_destMaxModTime
and reminderId between v_destMaxId and a_newMaxReminderId;

call utl_logProcessEnd(v_processId);

end//

delimiter ;