# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the container table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_container()' as '' from dual;

delimiter //

drop procedure if exists etl_container//

create procedure etl_container(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration
declare v_processId int;
declare v_destMaxId int; 
declare v_destMaxInsTime datetime; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_container',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(containerId) from container);
set v_desMaxInsTime = (select insertDateTime from container where containerId = v_destMaxId);
set v_destMaxModTime = (select modifyDateTime from container where containerId = v_destMaxId);

replace into container
select g.*
from ss_core_02.container g
where modifyDateTime >= v_destMaxModTime
or insertDateTime >= v_destMaxInsTime;

call utl_logProcessEnd(v_processId);

end//

delimiter ;