# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the xxx table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_paymentProfileContact()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_paymentProfileContact//

create procedure etl_rpt_paymentProfileContact(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;

declare v_destMaxId int; 
declare v_destMaxInsTime datetime; 
declare v_destMaxModTime datetime; 
call utl_logProcessStart('etl_rpt_paymentProfileContact',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

#set v_destMaxId = (select max(xxxId) from xxx);
#set v_desMaxInsTime = (select insertDateTime from container where xxxId = v_destMaxId);
#set v_destMaxModTime = (select modifyDateTime from container where xxxId = v_destMaxId);

#replace into xxx
#select g.*
#from ss_core_02.xxx g
#where modifyDateTime >= v_destMaxModTime
#or insertDateTime >= v_destMaxInsTime;


DROP TABLE IF EXISTS rpt_paymentProfileContact;

/******* create rpt_paymentProfileContact table - start *******/
CREATE TABLE IF NOT EXISTS rpt_paymentProfileContact(
paymentProfileID BIGINT, 
userID BIGINT, 
paymentProfileInsertDateTime DATETIME, 
accountType TINYINT, 
hasOrgProfile BOOLEAN,
parentPaymentProfileID BIGINT, /*included parentPaymentProfile in order to use it for update joins in the rpt_paymentProfile*/
PRIMARY KEY(paymentProfileID))
;

/* Insert the paymentProfiles associated with users */

INSERT rpt_main_02.rpt_paymentProfileContact 
SELECT paymentProfileID, ownerID, insertDateTime, accountType, FALSE, parentPaymentProfileID
FROM ss_core_02.paymentProfile p 
WHERE p.accountType != 3 and paymentProfileID <= @NEWmaxPaymentProfileID
;

/* Insert the paymentProfiles associated with organizations. */
/* Pulling through insertByUserID from original user to allow calculations of daysToBuy.  */
/* Using GROUP BY and MIN since sometimes there can be multiples profiles inserted by the
   the same person and that causes duplicate key issues, so just take the first one.     */

INSERT rpt_main_02.rpt_paymentProfileContact 
SELECT p.paymentProfileID, 
org.insertByUserID, 
MIN(p2.insertDateTime), 
p.accountType, 
FALSE,
p.parentPaymentProfileID
FROM ss_core_02.paymentProfile p
JOIN ss_core_02.organization org ON org.organizationID = p.ownerID
JOIN ss_core_02.paymentProfile p2 ON p2.ownerID = org.insertByUserID AND p2.accountType != 3
WHERE p.accountType = 3 
	and p.paymentProfileID <= @NEWmaxPaymentProfileID
	and org.organizationID <= @NewMaxorganizationID
	and p2.paymentProfileID <= @NEWmaxPaymentProfileID
GROUP BY 1, 2
;

CREATE INDEX idx_rpt_paymentProfileContactUserID ON rpt_paymentProfileContact (userID);
CREATE INDEX idx_rpt_paymentProfileparentPaymentProfileID ON rpt_paymentProfileContact (parentPaymentProfileID);

#Add indexes for hasOrgProfile and accountType
UPDATE rpt_main_02.rpt_paymentProfileContact rpt_paymentProfileContact 
JOIN rpt_main_02.rpt_paymentProfileContact rpt_paymentProfileContact2 
SET rpt_paymentProfileContact.hasOrgProfile = TRUE
WHERE rpt_paymentProfileContact2.userID = rpt_paymentProfileContact.userID
AND rpt_paymentProfileContact2.accountType = 3 AND rpt_paymentProfileContact.accountType !=3
; 

call utl_logProcessEnd(v_processId);

end//

delimiter ;