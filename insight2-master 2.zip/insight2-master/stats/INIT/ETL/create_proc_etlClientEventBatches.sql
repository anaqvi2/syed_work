# Insight
# Stored Procedure for ETL from ss_log_02
# Moves 30M rows from clientEvent table to arc_clinetEvent.
# Revision History
# 2017-05-26:
delimiter //

drop procedure if exists etl_clientEvent//
create procedure etl_clientEvent_batches(a_parentProcessId int
								,a_levelCtrlNum tinyint)
begin

declare v_processId int;
call utl_logProcessStart( 'etl_clientEvent_batches',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set transaction isolation level read committed;
set @maxClientEventID = (SELECT MAX(clientEventID) FROM arc_clientEvent);


INSERT arc_clientEvent 
SELECT * 
FROM ss_log_02.clientEvent 
WHERE clientEventID > @maxClientEventID
and clientEventID <= (@maxClientEventID+30000000)
;

call utl_logProcessEnd(v_processId);

end

