# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the googleAppsDomain table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_googleAppsDomain()' as '' from dual;

delimiter //

drop procedure if exists etl_googleAppsDomain//

create procedure etl_googleAppsDomain(a_parentProcessId int
                              ,a_levelCtrlNum tinyint
                             ,a_newMaxgoogleAppsDomainID int)
begin

# Variable Declaration
call utl_logProcessStart('etl_googleAppsDomain',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

DROP TABLE IF EXISTS googleAppsDomain;
CREATE TABLE IF NOT EXISTS googleAppsDomain LIKE ss_core_02.googleAppsDomain;
INSERT googleAppsDomain  
SELECT *  
FROM ss_core_02.googleAppsDomain
where googleAppsDomainID <= a_newMaxgoogleAppsDomainID
;

call utl_logProcessEnd(v_processId);

end//

delimiter ;