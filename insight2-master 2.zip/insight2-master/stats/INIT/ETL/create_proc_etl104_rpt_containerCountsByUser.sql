# Insight
# Stored Procedure for ETL from core
# Moves all inserts and modifications from the rpt_containerCountsByUser table.
# Does not consider deletes.
#
# Revision History
# 2014-02-20:  BMW:  Init.
select '### Compiling procedure  etl_rpt_containerCountsByUser()' as '' from dual;

delimiter //

drop procedure if exists etl_rpt_containerCountsByUser//

create procedure etl_rpt_containerCountsByUser(a_parentProcessId int
                              ,a_levelCtrlNum tinyint)
begin

# Variable Declaration

declare v_processId int;
declare v_destMaxId int; 
call utl_logProcessStart('etl_rpt_containerCountsByUser',a_parentProcessId,'','INFO',a_levelCtrlNum, v_processId);

set v_destMaxId = (select max(userId) from userAccount);

CREATE TABLE IF NOT EXISTS stg_containerCount_users_update (userID BIGINT, PRIMARY KEY (userID));

/*New Users*/
INSERT INTO stg_containerCount_users_update (userID)
SELECT ua.userID
FROM userAccount ua
LEFT OUTER JOIN rpt_containerCountsByUser ins ON ua.userID=ins.userID
WHERE ins.userID IS NULL
AND ua.userID >= v_destMaxId

UNION

/*Users with updated container counts*/
SELECT DISTINCT insertByUserID
FROM stg_container_data

UNION

/*Users with updated sharing counts*/
SELECT DISTINCT userID 
FROM stg_gridAccessMap_data
;

-- Calculate sheets shared from paid accounts
CREATE TABLE IF NOT EXISTS stg_sharedSheets (userID bigint, sheetCount int);

INSERT INTO stg_sharedSheets (userID, sheetCount)
SELECT stg.userID, COUNT(*) AS sheetCount
		FROM stg_containerCount_users_update stg
		JOIN gridAccessMap gam ON stg.userID=gam.userID
		JOIN container c ON c.displayObjectID = gam.gridID AND c.deleteStatus = 0 AND c.containerType = 2
		JOIN rpt_paymentProfile pp ON c.paymentProfileID = pp.paymentProfileID AND pp.productID >= 3
		JOIN userAccount u2 ON u2.userID = pp.ownerID AND pp.accountType != 3
		WHERE gam.deleteStatus = 0
		GROUP BY stg.userID
;

CREATE INDEX ix_userID ON stg_sharedSheets (userID);

-- Stage data for processing inserts and updates
CREATE TABLE IF NOT EXISTS stg_containerCountsByUser_data 
(
	userID bigint,
	workspaceCount int,
	folderCount int,
	lifetimeSheetCount int,
	sheetCount int,
	sheetwithCellLinkCount int,
	reportCount int,
	filterCount int,
	uiObjectCount int,
	sheetShortcutCount int,
	reportShortcutCount int,
	deactivatedSheetCount int,
	sheetsSharedFromPaidAccount int
)
;

INSERT INTO stg_containerCountsByUser_data
SELECT 
	stg.userID,
	SUM(CASE WHEN c.containerType = 0 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS workspaceCount,
	SUM(CASE WHEN c.containerType = 1 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS folderCount,
	SUM(CASE WHEN c.containerType = 2 THEN 1 ELSE 0 END) AS lifetimeSheetCount,
	SUM(CASE WHEN c.containerType = 2 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS sheetCount,
	COUNT(DISTINCT CASE WHEN c.containerType = 2 AND c.deleteStatus = 0 
		AND sl.displayGridID IS NOT NULL THEN c.containerID ELSE NULL END) AS sheetwithCellLinkCount,
	SUM(CASE WHEN c.containerType = 3 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS reportCount,
	SUM(CASE WHEN c.containerType = 4 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS filterCount,
	SUM(CASE WHEN c.containerType = 5 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS uiObjectCount,
	SUM(CASE WHEN c.containerType = 6 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS sheetShortcutCount,
	SUM(CASE WHEN c.containerType = 7 AND c.deleteStatus = 0 THEN 1 ELSE 0 END) AS reportShortcutCount,
	SUM(CASE WHEN c.containerType = 2 AND c.deleteStatus = 0 AND c.inactiveDateTime IS NOT NULL THEN 1 ELSE 0 END) AS deactivatedSheetCount,
	IFNULL(ss.sheetCount,0) AS sheetsSharedFromPaidAccount
	FROM stg_containerCount_users_update stg
	LEFT JOIN container c ON stg.userID=c.InsertByUserID
	LEFT JOIN sheetLink sl ON c.displayObjectID=sl.displayGridID
	LEFT JOIN stg_sharedSheets ss ON stg.userID=ss.userID
GROUP BY stg.userID
;

CREATE INDEX ix_userID ON stg_containerCountsByUser_data (userID);

-- Insert new users
INSERT INTO rpt_containerCountsByUser 
(
	userID,
	workspaceCount,
	folderCount,
	lifetimeSheetCount,
	sheetCount,
	sheetwithCellLinkCount,
	reportCount,
	filterCount,
	uiObjectCount,
	sheetShortcutCount,
	reportShortcutCount,
	deactivatedSheetCount,
	sheetsSharedFromPaidAccount
)
SELECT 
	sel.userID,
	sel.workspaceCount,
	sel.folderCount,
	sel.lifetimeSheetCount,
	sel.sheetCount,
	sel.sheetwithCellLinkCount,
	sel.reportCount,
	sel.filterCount,
	sel.uiObjectCount,
	sel.sheetShortcutCount,
	sel.reportShortcutCount,
	sel.deactivatedSheetCount,
	sel.sheetsSharedFromPaidAccount
FROM stg_containerCountsByUser_data sel
LEFT OUTER JOIN rpt_containerCountsByUser ins ON sel.userID=ins.userID
WHERE ins.userID IS NULL
;

-- Update users whose counts have changed
UPDATE rpt_containerCountsByUser u
JOIN stg_containerCountsByUser_data stg ON u.userID=stg.userID
SET 
	u.workspaceCount=stg.workspaceCount,
	u.folderCount=stg.folderCount,
	u.lifetimeSheetCount=stg.lifetimeSheetCount,
	u.sheetCount=stg.sheetCount,
	u.sheetwithCellLinkCount=stg.sheetwithCellLinkCount,
	u.reportCount=stg.reportCount,
	u.filterCount=stg.filterCount,
	u.uiObjectCount=stg.uiObjectCount,
	u.sheetShortcutCount=stg.sheetShortcutCount,
	u.reportShortcutCount=stg.reportShortcutCount,
	u.deactivatedSheetCount=stg.deactivatedSheetCount,
	u.sheetsSharedFromPaidAccount=stg.sheetsSharedFromPaidAccount
;

-- Drop staging tables
DROP TABLE IF EXISTS stg_sharedSheets;
DROP TABLE IF EXISTS stg_containerCount_users_update;
DROP TABLE IF EXISTS stg_containerCountsByUser_data;


call utl_logProcessEnd(v_processId);

end//

delimiter ;