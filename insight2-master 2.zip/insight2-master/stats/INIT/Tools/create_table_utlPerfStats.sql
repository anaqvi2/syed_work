#Table to capture hourly statistics
drop table utl_perfStats;
CREATE TABLE utl_perfStats (
   process varchar(200),
   day date,
  `dow` int(1) DEFAULT NULL,
  `hod` int(2) DEFAULT NULL,
  `benchmarkCenter` decimal(12,3) DEFAULT NULL,
  `benchmarkSpread` double(20,3) DEFAULT NULL,
  `benchmarkN` bigint(21) NOT NULL DEFAULT '0',
  `sampleCenter` decimal(12,3) DEFAULT NULL,
  `sampleSpread` double(20,3) DEFAULT NULL,
  `sampleN` bigint(21) NOT NULL DEFAULT '0',
  `isError` int(0) DEFAULT NULL,
primary key(process,day,dow,hod)
);
