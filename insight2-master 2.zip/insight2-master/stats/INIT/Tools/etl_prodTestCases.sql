use rpt_main_02;

#####   userAccount #######################################################################################################################
set @idTestRange = 1000;
set @rptMainMaxUserId = (select max(userID) from rpt_main_02.userAccount);
set @ssCoreMaxUserId = (select max(userID) from ss_core_02.userAccount);
set @rptMainMaxModifyDate = (select modifyDateTime from rpt_main_02.userAccount where userId = @rptMainMaxUserId);
set @ssCoreMaxModifyDate = (select modifyDateTime from ss_core_02.userAccount where userId = @rptMainMaxUserId);

#print variables
select @rptMainMaxUserId- @idTestRange, @idTestRange, @rptMainMaxUserId ,@ssCoreMaxUserId, @rptMainMaxModifyDate, @ssCoreMaxModifyDate from dual;

# Check to see if updates/inserts copied over correctly.
# Table checksums should be identical
# Execute within seconds after 'call etl_userAccount() executes.
#  ie; minimize the chance that replication updates the table ss_core_02.userAccount before the test.
drop table if exists tmp5;
create temporary table tmp5 as 
select * from ss_core_02.userAccount 
where userId between  @ssCoreMaxUserId - @idTestRange and @ssCoreMaxUserId - 10;
drop table if exists tmp6;
create temporary table tmp6 as 
select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from rpt_main_02.userAccount 
where userId between  @ssCoreMaxUserId - @idTestRange and @ssCoreMaxUserId - 10;
CHECKSUM TABLE tmp5;
CHECKSUM TABLE tmp6;

# Check to see if updates/inserts copied over correctly.
# Counts and max ids should be identical.
select 'ss_core_02 count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from ss_core_02.userAccount ua1
where ua1.userID >= @ssCoreMaxUserId-@idTestRange 
union
select 'rpt_main_02 count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from rpt_main_02.userAccount ua2
where ua2.userID >= @ssCoreMaxUserId-@idTestRange  
union
select 'union count', count(*) rowCount, max(userId) maxUserId, max(modifyDateTime) maxModifyDateTime
from
(select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from ss_core_02.userAccount
where userID >=  (@ssCoreMaxUserId-@idTestRange)
union
select userAccount.userID,
    userAccount.firstName,
    userAccount.lastName,
    userAccount.nickName,
    userAccount.accountType,
    userAccount.emailAddress,
    userAccount.loginPassword,
    userAccount.locale,
    userAccount.timeZone,
    userAccount.newsFlags,
    userAccount.statusFlags,
    userAccount.insertByUserID,
    userAccount.insertDateTime,
    userAccount.modifyByUserID,
    userAccount.modifyDateTime,
    userAccount.sessionLogID
from rpt_main_02.userAccount
where userID >=  (@ssCoreMaxUserId-@idTestRange)
) x;

# check to see if our additional 4 columns were added correctly.
select userAccount.userID,
	userAccount.locale,
	userAccount.localeFriendly,
	userAccount.languageFriendly,
	userAccount.countryFriendly,
	userAccount.domain
from rpt_main_02.userAccount 
where userID >=  @rptMainMaxUserId-@idTestRange;


select distinct
	userAccount.locale,
	userAccount.localeFriendly,
	userAccount.languageFriendly,
	userAccount.countryFriendly
from rpt_main_02.userAccount 
where userID >=  @rptMainMaxUserId-@idTestRange;

#######  grid  ############################################################
select 'grid rpt_main', max(gridId) from rpt_main_02.grid
union
select 'grid ss_log_02',max(gridId) from ss_core_02.grid
union
select 'difference rptmain-->ssLog',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.grid) xx
inner join 
(select max(gridId)  b
from ss_core_02.grid) yy;

#######  grid  ############################################################
select 'gridAccessMap rpt_main', max(gridId) from rpt_main_02.gridAccessMap
union
select 'gridAccessMap ss_core_02',max(gridId) from ss_core_02.gridAccessMap
union
select 'difference rptmain-->ssCore',  a-b as diff
from
(select max(gridId)  a
from  rpt_main_02.gridAccessMap) xx
inner join 
(select max(gridId)  b
from ss_core_02.gridAccessMap) yy
 ;
#######  requestLog  ############################################################

select 'rpt_main_02 arc_serverActionLookup', count(*) rowCount
from rpt_main_02.arc_serverActionLookup ua1
union
select 'test arc_serverActionLookup', count(*) rowCount
from test.arc_serverActionLookup ua2;

select *
from rpt_main_02.arc_serverActionLookup a
left outer join test.arc_serverActionLookup b
    on a.actionID = b.actionID and a.urlActionID = b.urlActionID and a.formAction = b.formAction and a.formName = b.formname;

select *
from rpt_main_02.arc_serverActionLookup a
right outer join test.arc_serverActionLookup b
    on a.actionID = b.actionID and a.urlActionID = b.urlActionID and a.formAction = b.formAction and a.formName = b.formname;

select 'requestLog test' as tab, max(requestLogId) from rpt_main_02.arc_requestLog
union
select 'requestLog ss_core_02',max(requestLogId) from ss_log_02.requestLog
union
select 'difference',  a-b as diff
from
(select max(requestLogId) a
from rpt_main_02.arc_requestLog) x
inner join 
(select max(requestLogId) b
from ss_log_02.requestLog)
 y;

#######  clientEvents  ############################################################
select 'clientEvent rpt_main', max(clientEventId) from rpt_main_02.arc_clientEvent
union
select 'clientEvent test', max(clientEventId) from test.arc_clientEvent
union
select 'clientEvent ss_log_02',max(clientEventId) from ss_log_02.clientEvent
union
select 'difference test-->sslog',  a-b as diff
from
(select max(clientEventId)  a
from test.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from ss_log_02.clientEvent) yy
union
select 'difference test-->rptmain',  a-b as diff
from
(select max(clientEventId)  a
from  test.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from rpt_main_02.arc_clientEvent)yy
union
select 'difference rptmain-->ssLog',  a-b as diff
from
(select max(clientEventId)  a
from  rpt_main_02.arc_clientEvent) xx
inner join 
(select max(clientEventId)  b
from ss_log_02.clientEvent) yy
 ;



#######  rpt_featureCountRollupByUser  ############################################################
select max(userId) from rpt_featureCountRollupByUser;
select max(userId) from userAccount;

#######  arc_WellQualifiedLeads  ############################################################
#######  arc_DailyWellQualifiedLeads  ############################################################



