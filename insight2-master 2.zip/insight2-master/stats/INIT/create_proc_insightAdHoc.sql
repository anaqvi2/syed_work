# Insight
# Stored Procedure for hacking stuff.  
# DISCLAIMER: This procedure and file may experience destruction at any point in time.
#
# Revision History
# 2014-05-20:  BMW:  Init.

select '### Compiling procedure  insightAdHoc()' as '' from dual;

delimiter //

drop procedure if exists insightAdHoc//

create procedure insightAdHoc()
begin

# Variable Declaration

declare v_processId int;
call utl_logProcessStart('insightAdHoc',NULL,'','INFO',5, v_processId);


#####  Put crappy code here  ####

create index idx_gridLog_gridId on ss_core_02.gridLog(gridId);
create index idx_gridLog_insertByUserID on ss_core_02.gridLog(insertByUserID);

#####  End of crappy code   #####

call utl_logProcessEnd(v_processId);

end//

delimiter;