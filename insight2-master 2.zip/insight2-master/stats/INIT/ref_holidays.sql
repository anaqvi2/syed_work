
/******************  Holiday data ******************/

create table ref_holidays (
	holidayDate date ,
	holiday tinyint (1),
	holidayName varchar (75)
); 

insert into ref_holidays values('2007-12-25','1','Christmas');
insert into ref_holidays values('2008-01-01','1','NewYearsDay');
insert into ref_holidays values('2008-05-26','1','MemorialDay');
insert into ref_holidays values('2008-07-04','1','IndependenceDay');
insert into ref_holidays values('2008-09-01','1','LaborDay');
insert into ref_holidays values('2008-11-27','1','Thanksgiving');
insert into ref_holidays values('2008-11-28','1','DayafterThanksgiving');
insert into ref_holidays values('2008-12-25','1','Christmas');
insert into ref_holidays values('2009-01-01','1','NewYearsDay');
insert into ref_holidays values('2009-05-25','1','MemorialDay');
insert into ref_holidays values('2009-07-04','1','IndependenceDay');
insert into ref_holidays values('2009-09-07','1','LaborDay');
insert into ref_holidays values('2009-11-26','1','Thanksgiving');
insert into ref_holidays values('2009-11-27','1','DayafterThanksgiving');
insert into ref_holidays values('2009-12-25','1','Christmas');
insert into ref_holidays values('2010-01-01','1','NewYearsDay');
insert into ref_holidays values('2010-05-31','1','MemorialDay');
insert into ref_holidays values('2010-07-04','1','IndependenceDay');
insert into ref_holidays values('2010-09-06','1','LaborDay');
insert into ref_holidays values('2010-11-25','1','Thanksgiving');
insert into ref_holidays values('2010-11-26','1','DayafterThanksgiving');
insert into ref_holidays values('2010-12-25','1','Christmas');
insert into ref_holidays values('2011-01-01','1','NewYearsDay');
insert into ref_holidays values('2011-05-30','1','MemorialDay');
insert into ref_holidays values('2011-07-04','1','IndependenceDay');
insert into ref_holidays values('2011-09-05','1','LaborDay');
insert into ref_holidays values('2011-11-24','1','Thanksgiving');
insert into ref_holidays values('2011-11-25','1','DayafterThanksgiving');
insert into ref_holidays values('2011-12-25','1','Christmas');
insert into ref_holidays values('2012-01-01','1','NewYearsDay');
insert into ref_holidays values('2012-05-28','1','MemorialDay');
insert into ref_holidays values('2012-07-04','1','IndependenceDay');
insert into ref_holidays values('2012-09-03','1','LaborDay');
insert into ref_holidays values('2012-11-22','1','Thanksgiving');
insert into ref_holidays values('2012-11-23','1','DayafterThanksgiving');
insert into ref_holidays values('2012-12-25','1','Christmas');
insert into ref_holidays values('2013-01-01','1','NewYearsDay');
insert into ref_holidays values('2013-05-27','1','MemorialDay');
insert into ref_holidays values('2013-07-04','1','IndependenceDay');
insert into ref_holidays values('2013-09-02','1','LaborDay');
insert into ref_holidays values('2013-11-28','1','Thanksgiving');
insert into ref_holidays values('2013-11-29','1','DayafterThanksgiving');
insert into ref_holidays values('2013-12-25','1','Christmas');
insert into ref_holidays values('2014-01-01','1','NewYearsDay');
insert into ref_holidays values('2014-05-26','1','MemorialDay');
insert into ref_holidays values('2014-07-04','1','IndependenceDay');
insert into ref_holidays values('2014-09-01','1','LaborDay');
insert into ref_holidays values('2014-11-27','1','Thanksgiving');
insert into ref_holidays values('2014-11-28','1','DayafterThanksgiving');
insert into ref_holidays values('2014-12-25','1','Christmas');
insert into ref_holidays values('2015-01-01','1','NewYearsDay');
insert into ref_holidays values('2015-05-25','1','MemorialDay');
insert into ref_holidays values('2015-07-04','1','IndependenceDay');
insert into ref_holidays values('2015-09-07','1','LaborDay');
insert into ref_holidays values('2015-11-26','1','Thanksgiving');
insert into ref_holidays values('2015-11-27','1','DayafterThanksgiving');
insert into ref_holidays values('2015-12-25','1','Christmas');
insert into ref_holidays values('2016-01-01','1','NewYearsDay');
insert into ref_holidays values('2016-05-30','1','MemorialDay');
insert into ref_holidays values('2016-07-04','1','IndependenceDay');
insert into ref_holidays values('2016-09-05','1','LaborDay');
insert into ref_holidays values('2016-11-24','1','Thanksgiving');
insert into ref_holidays values('2016-11-25','1','DayafterThanksgiving');
insert into ref_holidays values('2016-12-25','1','Christmas');
