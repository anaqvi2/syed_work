
/******************  Locale Country lookup data ******************/

DROP TABLE IF EXISTS ref_localeCountryLanguage;

CREATE TABLE ref_localeCountryLanguage (
  localeCode varchar(5) NOT NULL DEFAULT '',
  localeName varchar(100) DEFAULT NULL,
  countryCode varchar(52) DEFAULT '',
  countryName varchar(100) DEFAULT NULL,
  currencyCode varchar(10) DEFAULT NULL,
  currencyName varchar(100) DEFAULT NULL,
  languageCode varchar(2) DEFAULT '',
  languageName varchar(100) DEFAULT NULL,
  PRIMARY KEY (localeCode),
  KEY idx_refLocaleCountryLanguage_countryCode (countryCode),
  KEY idx_refLocaleCountryLanguage_currencyCode (currencyCode),
  KEY idx_refLocaleCountryLanguage_languageCode (languageCode)
);


insert  into ref_localeCountryLanguage values ('ar_AE','Arabic (United Arab Emirates)','AE','United Arab Emirates','AED','United Arab Emirates dirham','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_BH','Arabic (Bahrain)','BH','Bahrain','BHD','Bahraini dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_DZ','Arabic (Algeria)','DZ','Algeria','DZD','Algerian dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_EG','Arabic (Egypt)','EG','Egypt','EGP','Egyptian pound','ar','Arabic');;
insert  into ref_localeCountryLanguage values ('ar_IQ','Arabic (Iraq)','IQ','Iraq','IQD','Iraqi dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_JO','Arabic (Jordan)','JO','Jordan','JOD','Jordanian dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_KW','Arabic (Kuwait)','KW','Kuwait','KWD','Kuwaiti dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_LB','Arabic (Lebanon)','LB','Lebanon','LBP','Lebanese pound','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_LY','Arabic (Libya)','LY','Libya','LYD','Libyan dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_MA','Arabic (Morocco)','MA','Morocco','MAD','Moroccan dirham','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_OM','Arabic (Oman)','OM','Oman','OMR','Omani rial','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_QA','Arabic (Qatar)','QA','Qatar','QAR','Qatari riyal','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_SA','Arabic (Saudi Arabia)','SA','Saudi Arabia','SAR','Saudi riyal','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_SD','Arabic (Sudan)','SD','Sudan','SDG','Sudanese pound','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_SY','Arabic (Syria)','SY','Syria','SYP','Syrian pound','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_TN','Arabic (Tunisia)','TN','Tunisia','TND','Tunisian dinar','ar','Arabic');
insert  into ref_localeCountryLanguage values ('ar_YE','Arabic (Yemen)','YE','Yemen','YER','Yemeni rial','ar','Arabic');
insert  into ref_localeCountryLanguage values ('be_BY','Belarusian (Belarus)','BY','Belarus','BYR','Belarusian ruble','be','Belarusian');
insert  into ref_localeCountryLanguage values ('bg_BG','Bulgarian (Bulgaria)','BG','Bulgaria','BGN','Bulgarian lev','bg','Bulgarian');
insert  into ref_localeCountryLanguage values ('ca_ES','Catalan (Spain)','ES','Spain','EUR','Euro','ca','Catalan');
insert  into ref_localeCountryLanguage values ('cs_CZ','Czech (Czech Republic)','CZ','Czech Republic','CZK','Czech koruna','cs','Czech');
insert  into ref_localeCountryLanguage values ('da_DK','Danish (Denmark)','DK','Denmark','DKK','Danish krone','da','Danish');
insert  into ref_localeCountryLanguage values ('de_AT','German (Austria)','AT','Austria','EUR','Euro','de','German');
insert  into ref_localeCountryLanguage values ('de_CH','German (Switzerland)','CH','Switzerland','CHF','Swiss franc','de','German');
insert  into ref_localeCountryLanguage values ('de_DE','German (Germany)','DE','Germany','EUR','Euro','de','German');
insert  into ref_localeCountryLanguage values ('de_LU','German (Luxembourg)','LU','Luxembourg','EUR','Euro','de','German');
insert  into ref_localeCountryLanguage values ('el_CY','Greek (Cyprus)','CY','Cyprus','EUR','Euro','el','Greek');
insert  into ref_localeCountryLanguage values ('el_GR','Greek (Greece)','GR','Greece','EUR','Euro','el','Greek');
insert  into ref_localeCountryLanguage values ('en_AU','English (Australia)','AU','Australia','AUD','Australian dollar','en','English');
insert  into ref_localeCountryLanguage values ('en_CA','English (Canada)','CA','Canada','CAD','Canadian dollar','en','English');
insert  into ref_localeCountryLanguage values ('en_GB','English (United Kingdom)','GB','United Kingdom','GBP','British pound','en','English');
insert  into ref_localeCountryLanguage values ('en_IE','English (Ireland)','IE','Ireland','EUR','Euro','en','English');
insert  into ref_localeCountryLanguage values ('en_IN','English (India)','IN','India','INR','Indian rupee','en','English');
insert  into ref_localeCountryLanguage values ('en_MT','English (Malta)','MT','Malta','EUR','Euro','en','English');
insert  into ref_localeCountryLanguage values ('en_NZ','English (New Zealand)','NZ','New Zealand','NZD','New Zealand dollar','en','English');
insert  into ref_localeCountryLanguage values ('en_PH','English (Philippines)','PH','Philippines','PHP','Philippine peso','en','English');
insert  into ref_localeCountryLanguage values ('en_SG','English (Singapore)','SG','Singapore','BND','Brunei dollar','en','English');
insert  into ref_localeCountryLanguage values ('en_US','English (United States)','US','United States','USD','United States dollar','en','English');
insert  into ref_localeCountryLanguage values ('en_ZA','English (South Africa)','ZA','South Africa','ZAR','South African rand','en','English');
insert  into ref_localeCountryLanguage values ('es_AR','Spanish (Argentina)','AR','Argentina','ARS','Argentine peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_BO','Spanish (Bolivia)','BO','Bolivia','BOB','Bolivian boliviano','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_CL','Spanish (Chile)','CL','Chile','CLP','Chilean peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_CO','Spanish (Colombia)','CO','Colombia','COP','Colombian peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_CR','Spanish (Costa Rica)','CR','Costa Rica','CRC','Costa Rican colón','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_DO','Spanish (Dominican Republic)','DO','Dominican Republic','DOP','Dominican peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_EC','Spanish (Ecuador)','EC','Ecuador','USD','United States dollar','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_ES','Spanish (Spain)','ES','Spain','EUR','Euro','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_GT','Spanish (Guatemala)','GT','Guatemala','GTQ','Guatemalan quetzal','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_HN','Spanish (Honduras)','HN','Honduras','HNL','Honduran lempira','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_MX','Spanish (Mexico)','MX','Mexico','MXN','Mexican peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_NI','Spanish (Nicaragua)','NI','Nicaragua','NIO','Nicaraguan córdoba','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_PA','Spanish (Panama)','PA','Panama','PAB','Panamanian balboa','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_PE','Spanish (Peru)','PE','Peru','PEN','Peruvian nuevo sol','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_PR','Spanish (Puerto Rico)','PR','Puerto Rico','USD','United States dollar','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_PY','Spanish (Paraguay)','PY','Paraguay','PYG','Paraguayan guaraní','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_SV','Spanish (El Salvador)','SV','El Salvador','SVC','Salvadoran colón','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_US','Spanish (United States)','US','United States','USD','United States dollar','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_UY','Spanish (Uruguay)','UY','Uruguay','UYU','Uruguayan peso','es','Spanish');
insert  into ref_localeCountryLanguage values ('es_VE','Spanish (Venezuela)','VE','Venezuela','VEF','Venezuelan bolívar','es','Spanish');
insert  into ref_localeCountryLanguage values ('et_EE','Estonian (Estonia)','EE','Estonia','EUR','Euro','et','Estonian');
insert  into ref_localeCountryLanguage values ('fi_FI','Finnish (Finland)','FI','Finland','EUR','Euro','fi','Finnish');
insert  into ref_localeCountryLanguage values ('fr_BE','French (Belgique)','BE','Belgium','EUR','Euro','fr','French');
insert  into ref_localeCountryLanguage values ('fr_CA','French (Canada)','CA','Canada','CAD','Canadian dollar','fr','French');
insert  into ref_localeCountryLanguage values ('fr_CH','French (Switzerland)','CH','Switzerland','CHF','Swiss franc','fr','French');
insert  into ref_localeCountryLanguage values ('fr_FR','French (France)','FR','France','EUR','Euro','fr','French');
insert  into ref_localeCountryLanguage values ('fr_LU','French (Luxembourg)','LU','Luxembourg','EUR','Euro','fr','French');
insert  into ref_localeCountryLanguage values ('ga_IE','Irish (Ireland)','IE','Ireland','EUR','Euro','ga','Irish');
insert  into ref_localeCountryLanguage values ('hi_IN','Hindi (India)','IN','India','INR','Indian rupee','hi','Hindi');
insert  into ref_localeCountryLanguage values ('hr_HR','Croatian (Croatia)','HR','Croatia','HRK','Croatian kuna','hr','Croatian');
insert  into ref_localeCountryLanguage values ('hu_HU','Hungarian (Hungary)','HU','Hungary','HUF','Hungarian forint','hu','Hungarian');
insert  into ref_localeCountryLanguage values ('in_ID','Indonesian (Indonesia)','ID','Indonesia','IDR','Indonesian rupiah','in','Indonesian');
insert  into ref_localeCountryLanguage values ('is_IS','Icelandic (Iceland)','IS','Iceland','ISK','Icelandic króna','is','Icelandic');
insert  into ref_localeCountryLanguage values ('it_CH','Italian (Switzerland)','CH','Switzerland','CHF','Swiss franc','it','Italian');
insert  into ref_localeCountryLanguage values ('it_IT','Italian (Italy)','IT','Italy','EUR','Euro','it','Italian');
insert  into ref_localeCountryLanguage values ('iw_IL','Hebrew (Israel)','IL','Israel','ILS','Israeli new shekel','iw','Hebrew');
insert  into ref_localeCountryLanguage values ('ja_JP','Japanese (Japan)','JP','Japan','JPY','Japanese yen','ja','Japanese');
insert  into ref_localeCountryLanguage values ('ko_KR','Korean (South Korea)','KR','South Korea','KRW','South Korean won','ko','Korean');
insert  into ref_localeCountryLanguage values ('lt_LT','Lithuanian (Lithuania)','LT','Lithuania','LTL','Lithuanian litas','lt','Lithuanian');
insert  into ref_localeCountryLanguage values ('lv_LV','Latvian (Latvia)','LV','Latvia','LVL','Latvian lats','lv','Latvian');
insert  into ref_localeCountryLanguage values ('mk_MK','Macedonian (Macedonia)','MK','Macedonia','MKD','Macedonian denar','mk','Macedonian');
insert  into ref_localeCountryLanguage values ('ms_MY','Malay (Malaysia)','MY','Malaysia','MYR','Malaysian ringgit','ms','Malay');
insert  into ref_localeCountryLanguage values ('mt_MT','Maltese (Malta)','MT','Malta','EUR','Euro','mt','Maltese');
insert  into ref_localeCountryLanguage values ('nl_BE','Dutch (Belgium)','BE','Belgium','EUR','Euro','nl','Dutch');
insert  into ref_localeCountryLanguage values ('nl_NL','Dutch (Netherlands)','NL','Netherlands','EUR','Euro','nl','Dutch');
insert  into ref_localeCountryLanguage values ('no_NO','Norwegian (Norway)','NO','Norway','NOK','Norwegian krone','no','Norwegian');
insert  into ref_localeCountryLanguage values ('pl_PL','Polish (Poland)','PL','Poland','PLN','Polish zloty','pl','Polish');
insert  into ref_localeCountryLanguage values ('pt_BR','Portuguese (Brasil)','BR','Brazil','BRL','Brazilian real','pt','Portuguese');
insert  into ref_localeCountryLanguage values ('pt_PT','Portuguese (Portugal)','PT','Portugal','EUR','Euro','pt','Portuguese');
insert  into ref_localeCountryLanguage values ('ro_RO','Romanian (Romania)','RO','Romania','RON','Romanian leu','ro','Romanian');
insert  into ref_localeCountryLanguage values ('ru_RU','Russian (Russia)','RU','Russia','RUB','Russian ruble','ru','Russian');
insert  into ref_localeCountryLanguage values ('sk_SK','Slovak (Slovakia)','SK','Slovakia','EUR','Euro','sk','Slovak');
insert  into ref_localeCountryLanguage values ('sl_SI','Slovenian (Slovenia)','SI','Slovenia','EUR','Euro','sl','Slovenian');
insert  into ref_localeCountryLanguage values ('sq_AL','Albanian (Albania)','AL','Albania','ALL','Albanian lek','sq','Albanian');
insert  into ref_localeCountryLanguage values ('sr_BA','Serbian (Bosnia and Herzegovina)','BA','Bosnia and Herzegovina','BAM','Bosnia and Herzegovina convertible mark','sr','Serbian');
insert  into ref_localeCountryLanguage values ('sr_CS','Serbian (Serbia and Montenegro)','CS','Serbia and Montenegro','RSD','Serbian dinar','sr','Serbian');
insert  into ref_localeCountryLanguage values ('sv_SE','Swedish (Sweden)','SE','Sweden','SEK','Swedish krona','sv','Swedish');
insert  into ref_localeCountryLanguage values ('th_US','Thai (Thailand - Common Era)','US','United States','USD','United States dollar','th','Thai');
insert  into ref_localeCountryLanguage values ('tr_TR','Turkish (Turkey)','TR','Turkey','TRY','Turkish lira','tr','Turkish');
insert  into ref_localeCountryLanguage values ('uk_UA','Ukrainian (Ukraine)','UA','Ukraine','UAH','Ukrainian hryvnia','uk','Ukrainian');
insert  into ref_localeCountryLanguage values ('vi_VN','Vietnamese (Vietnam)','VN','Vietnam','VND','Vietnamese dong','vi','Vietnamese');
insert  into ref_localeCountryLanguage values ('zh_CN','Chinese (China)','CN','China','CNY','Chinese yuan','zh','Chinese');
insert  into ref_localeCountryLanguage values ('zh_HK','Chinese (Hong Kong)','HK','Hong Kong','HKD','Hong Kong dollar','zh','Chinese');
insert  into ref_localeCountryLanguage values ('zh_SG','Chinese (Singapore)','SG','Singapore','BND','Brunei dollar','zh','Chinese');
insert  into ref_localeCountryLanguage values ('zh_TW','Chinese (Taiwan)','TW','Taiwan','TWD','New Taiwan dollar','zh','Chinese');
